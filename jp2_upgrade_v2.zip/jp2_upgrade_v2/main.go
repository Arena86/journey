package main

import (
	"jpapi/tig/v1/controllers"
	"jpapi/tig/v1/middlewares"
	ver1 "jpapi/tig/v1/routers"
	"os"

	"github.com/gin-contrib/location"
	"github.com/gin-gonic/gin"
	"github.com/subosito/gotenv"

	"docs"

	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

func init() {
	gotenv.Load()
}

func getPort() string {
	p := os.Getenv("HOST_PORT")
	if p != "" {
		return ":" + p
	}
	return ":3040"
}

func main() {

	// @TODO cronjob
	go func() {
		controllers.CronJob()
	}()
	/* go func() {
		controllers.CronJobTaskScheduler()
	}() */

	port := getPort()
	gin.SetMode(os.Getenv("GIN_MODE"))
	r := gin.Default()
	r.Static("/public/images/logos", "./public/images/logos")
	r.Use(location.Default())
	r.Use(middlewares.CORSMiddleware())
	r.RedirectFixedPath = true
	v1 := r.Group(os.Getenv("ROUTER_V1"))
	{
		// database
		database := v1.Group("")
		database.Use(middlewares.CORSMiddleware())
		{
			ver1.JPDatabaseRoute(database)
		}

		// system
		system := v1.Group("")
		system.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JPRoute(system)
		}

		// business partner
		businesspartner := v1.Group("/businesspartner")
		businesspartner.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.BusinessPartner(businesspartner)
		}

		// location group
		locationgroup := v1.Group("/locationgroup")
		locationgroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.LocationGroup(locationgroup)
		}

		// location
		location := v1.Group("/location")
		location.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Location(location)
		}

		// item
		item := v1.Group("/item")
		item.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Item(item)
		}

		// job
		job := v1.Group("/job")
		job.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Job(job)
		}

		// resource
		resource := v1.Group("/resource")
		resource.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Resource(resource)
		}

		// schedule
		schedule := v1.Group("/schedule")
		schedule.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Schedule(schedule)
		}

		// grid
		grid := v1.Group("/grid")
		grid.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Grid(grid)
		}

		// addresstype
		addresstype := v1.Group("/addresstype")
		addresstype.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AddressType(addresstype)
		}

		// phonetype
		phonetype := v1.Group("/phonetype")
		phonetype.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.PhoneType(phonetype)
		}

		// searchfield
		searchfield := v1.Group("/searchfield")
		searchfield.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.SearchField(searchfield)
		}

		// setting
		setting := v1.Group("/setting")
		setting.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Setting(setting)
		}

		// usersetting
		usersetting := v1.Group("/usersetting")
		usersetting.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.UserSetting(usersetting)
		}

		// udf
		udf := v1.Group("/udf")
		udf.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.UDF(udf)
		}

		// customergroup
		customergroup := v1.Group("/customergroup")
		customergroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.CustomerGroup(customergroup)
		}

		// report
		report := v1.Group("/report")
		report.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Report(report)
		}

		// prefix
		prefix := v1.Group("/prefix")
		prefix.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Prefix(prefix)
		}

		// securitygroup
		securitygroup := v1.Group("/securitygroup")
		securitygroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.SecurityGroup(securitygroup)
		}

		// permission
		permission := v1.Group("/permission")
		permission.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Permission(permission)
		}

		// reportgroup
		reportgroup := v1.Group("/reportgroup")
		reportgroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.ReportGroup(reportgroup)
		}

		// enumerator
		enumerator := v1.Group("/enum")
		enumerator.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Enumerator(enumerator)
		}

		// user
		user := v1.Group("/user")
		user.Use(middlewares.CORSMiddleware())
		{
			ver1.User(user)
		}

		// overridetranslation
		overridetranslation := v1.Group("/overridetranslation")
		overridetranslation.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.OverrideTranslation(overridetranslation)
		}

		// jobtemplate
		jobtemplate := v1.Group("/jobtemplate")
		jobtemplate.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JobTemplate(jobtemplate)
		}

		// notification
		notification := v1.Group("/notification")
		notification.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Notification(notification)
		}

		// servicepricelist
		servicepricelist := v1.Group("/servicepricelist")
		servicepricelist.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.ServicePriceList(servicepricelist)
		}

		// distancepricelist
		distancepricelist := v1.Group("/distancepricelist")
		distancepricelist.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.DistancePriceList(distancepricelist)
		}

		// pricelist
		pricelist := v1.Group("/pricelist")
		pricelist.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.PriceList(pricelist)
		}

		// itemgroup
		itemgroup := v1.Group("/itemgroup")
		itemgroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.ItemGroup(itemgroup)
		}

		// reportstyle
		reportstyle := v1.Group("/reportstyles")
		reportstyle.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.ReportStyle(reportstyle)
		}

		// xero
		xero := v1.Group("/xero")
		xero.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Xero(xero)
		}

		// tax
		tax := v1.Group("/tax")
		tax.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Tax(tax)
		}

		// traveltimechargematrix
		traveltimechargematrix := v1.Group("/traveltimechargematrix")
		traveltimechargematrix.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.TravelTimeChargeMatrix(traveltimechargematrix)
		}

		// gridtemplates
		gridtemplates := v1.Group("/gridstemplates")
		gridtemplates.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.GridTemplates(gridtemplates)
		}

		// searchfieldstemplate
		searchfieldstemplate := v1.Group("/searchfieldstemplates")
		searchfieldstemplate.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.SearchFieldsTemplate(searchfieldstemplate)
		}

		// draftdynamicform
		draftdynamicform := v1.Group("/draftdynamicform")
		draftdynamicform.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.DraftDynamicForm(draftdynamicform)
		}

		// dynamicform
		dynamicform := v1.Group("/dynamicform")
		dynamicform.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.DynamicForm(dynamicform)
		}

		// draftformflow
		draftformflow := v1.Group("/draftformflow")
		draftformflow.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.DraftFormFlow(draftformflow)
		}

		// formflow
		formflow := v1.Group("/formflow")
		formflow.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.FormFlow(formflow)
		}

		// formudt
		formudt := v1.Group("/formudt")
		formudt.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.FormUDT(formudt)
		}

		// vehicleinspection
		vehicleinspection := v1.Group("/vehicleinspection")
		vehicleinspection.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.VehicleInspection(vehicleinspection)
		}

		// vehicleinspectionquestiongroup
		vehicleinspectionquestiongroup := v1.Group("/vehicleinspectionquestiongroup")
		vehicleinspectionquestiongroup.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.VehicleInspectionQuestionGroup(vehicleinspectionquestiongroup)
		}

		// vehiclestocktake
		vehiclestocktake := v1.Group("/vehiclestocktake")
		vehiclestocktake.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.VehicleStocktake(vehiclestocktake)
		}

		// vehicleinspectionshistory
		vehicleinspectionshistory := v1.Group("/vehicleinspectionhistory")
		vehicleinspectionshistory.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.VehicleInspectionsHistory(vehicleinspectionshistory)
		}

		// smstemplate
		smstemplate := v1.Group("/smstemplate")
		smstemplate.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.SMSTemplate(smstemplate)
		}

		// emailtemplate
		emailtemplate := v1.Group("/emailtemplate")
		emailtemplate.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.EmailTemplate(emailtemplate)
		}

		// reason
		reason := v1.Group("/reason")
		reason.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Reason(reason)
		}

		// vehiclestocktakehistory
		vehiclestocktakehistory := v1.Group("/vehiclestocktakehistory")
		vehiclestocktakehistory.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.VehicleStocktakeHistory(vehiclestocktakehistory)
		}

		// templatevariable
		templatevariable := v1.Group("/templatevariable")
		templatevariable.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.KeyTemplateVariable(templatevariable)
		}

		// formchecklist
		formchecklist := v1.Group("/formchecklist")
		formchecklist.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.FormCheckList(formchecklist)
		}

		// formchecklisthistory
		formchecklisthistory := v1.Group("/formchecklisthistory")
		formchecklisthistory.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.FormCheckListHistory(formchecklisthistory)
		}

		// pedserie
		pedserie := v1.Group("/pedserie")
		pedserie.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.PEDSerie(pedserie)
		}

		// jobdetail
		jobdetail := v1.Group("/jobdetail")
		jobdetail.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JobDetail(jobdetail)
		}

		// break
		breakRoute := v1.Group("/break")
		breakRoute.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.BreakRoute(breakRoute)
		}

		// journey
		journeyRoute := v1.Group("/journey")
		journeyRoute.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JourneyRoute(journeyRoute)
		}

		// jobtask
		jobtask := v1.Group("/jobtask")
		jobtask.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JobTask(jobtask)
		}

		// additionalresource
		additionalresource := v1.Group("/additionalresource")
		additionalresource.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AdditionalResource(additionalresource)
		}

		// jobsearchfield
		jobsearchfield := v1.Group("/jobsearchfield")
		jobsearchfield.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.JobSearchField(jobsearchfield)
		}

		// precomputedroute
		precomputedroute := v1.Group("/precomputedroute")
		precomputedroute.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.PrecomputedRoute(precomputedroute)
		}

		// dashboard
		dashboard := v1.Group("/dashboard")
		dashboard.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Dashboard(dashboard)
		}

		// advancedped
		advancedped := v1.Group("/advancedped")
		advancedped.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AdvancedPED(advancedped)
		}

		// advancedsignature
		advancedsignature := v1.Group("/advancedsignature")
		advancedsignature.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AdvancedSignature(advancedsignature)
		}

		// advancedphoto
		advancedphoto := v1.Group("/advancedphoto")
		advancedphoto.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AdvancedPhoto(advancedphoto)
		}

		// advancedrating
		advancedrating := v1.Group("/advancedrating")
		advancedrating.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AdvancedRating(advancedrating)
		}

		// authorization
		authorization := v1.Group("/authorization")
		authorization.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.AuthorizationRoute(authorization)
		}

		// logo
		logo := v1.Group("/logo")
		logo.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Logo(logo)
		}

		// smsmatrix
		smsmatrix := v1.Group("/smsmatrix")
		smsmatrix.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.SMSMatrix(smsmatrix)
		}

		// countrycode
		countrycode := v1.Group("/countrycodes")
		countrycode.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.CountryCode(countrycode)
		}

		// payment
		payment := v1.Group("/payment")
		payment.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Payment(payment)
		}

		// locationpaymentmethod
		locationpaymentmethod := v1.Group("/locationpaymentmethod")
		locationpaymentmethod.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.LocationPaymentMethod(locationpaymentmethod)
		}

		// gpstiledesigner
		gpstiledesigner := v1.Group("/gpstiledesigner")
		gpstiledesigner.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.GPSTileDesigner(gpstiledesigner)
		}

		// plans
		plans := v1.Group("/plans")
		plans.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Plan(plans)
		}

		// device
		device := v1.Group("/device")
		device.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Device(device)
		}

		// companiesinfor
		companiesinfor := v1.Group("/companiesinfor")
		companiesinfor.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.CompanyInfor(companiesinfor)
		}

		// devicestatus
		devicestatus := v1.Group("/devicestatus")
		devicestatus.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.DeviceStatus(devicestatus)
		}

		// subscription
		subscription := v1.Group("/subscriptions")
		subscription.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.Subscription(subscription)
		}

		// chargebee
		chargebee := v1.Group("/chargebee")
		chargebee.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.ChargeBee(chargebee)
		}

		// 4dprice
		_4dprice := v1.Group("/4dprice")
		chargebee.Use(middlewares.CORSMiddleware(), middlewares.ValidateToken())
		{
			ver1.FourDPrice(_4dprice)
		}
	}

	v2 := r.Group(os.Getenv("ROUTER_V2"))
	{
		// system
		system := v2.Group("")
		system.Use(middlewares.CORSMiddleware())
		{
			//ver1.JPRoute(system)
		}
	}

	docs.SwaggerInfo.Title = "Journey Pro API"
	docs.SwaggerInfo.Description = "Journey Pro API"
	docs.SwaggerInfo.Version = "1.0"
	docs.SwaggerInfo.Host = ""
	docs.SwaggerInfo.BasePath = os.Getenv("ROUTER_V1")
	docs.SwaggerInfo.Schemes = []string{"http", "https"}
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	r.Run(port)
	//r.RunTLS(port, "/tmp/certificates/TIGDEV.pem", "/tmp/certificates/TIGDEV.pem")
}
