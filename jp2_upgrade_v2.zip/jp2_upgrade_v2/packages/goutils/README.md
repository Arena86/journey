# goutils
install : go get github.com/printfhome/goutils

`more powerfull`: [new goutils](https://github.com/printfcoder/goutils)
