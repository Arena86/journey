package goutils

/************************
* securerandom
*
*
**************************/

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"strings"
)

// RandomBytes n length of byte array
func RandomBytes(n int) ([]byte, error) {
	bytes := make([]byte, n)
	_, err := rand.Read(bytes)
	if err != nil {
		return nil, err
	}
	return bytes, nil
}

// Base64 Base64
func Base64(n int, padded bool) (string, error) {
	bytes, err := RandomBytes(n)
	if err != nil {
		return "", err
	}
	result := base64.StdEncoding.EncodeToString(bytes)
	result = strings.Replace(result, "\n", "", -1)
	if !padded {
		result = strings.Replace(result, "=", "", -1)
	}
	return result, nil
}

// Hex Hex
func Hex(n int) (string, error) {
	bytes, err := RandomBytes(n)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}
