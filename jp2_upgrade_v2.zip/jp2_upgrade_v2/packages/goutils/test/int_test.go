package test

import (
	"testing"

	"github.com/printfhome/goutils"
)

var (
	in     = []int{22, 4, 7, 9, 3, 5, 999, 23, 35, 67, 35, 67, 53, 82, 3, 5, 82}
	target = 86
)

func TestFindTwoSumForSmallInts(t *testing.T) {

	ret, _ := goutils.FindTwoSumForSmallInts(in, target)

	if ret[0] == 1 && ret[1] == 13 {
		t.Log("TestFindTwoSumForSmallInts OK")
		return
	}

	t.Error("TestFindTwoSumForSmallInts Fail")
}
