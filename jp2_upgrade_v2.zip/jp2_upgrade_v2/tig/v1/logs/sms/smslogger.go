package smslogs

import (
	"os"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/subosito/gotenv"
	lumberjack "gopkg.in/natefinch/lumberjack.v2"
)

//SMSLogger var
var SMSLogger = logrus.New()

func init() {
	gotenv.Load()
	var filePath = os.Getenv("LOGGER_PATH")
	array := strings.Split(filePath, ".")
	if len(array) >= 2 {
		filePath = array[0] + "-sms-" + time.Now().Format("01-02-2006") + "." + array[1]
	}

	SMSLogger.SetFormatter(&logrus.TextFormatter{
		DisableColors:   false,
		TimestampFormat: "02-01-2006 15:04:05",
	})
	SMSLogger.SetOutput(&lumberjack.Logger{
		Filename: filePath,
		MaxSize:  1, // megabytes
	})
}
