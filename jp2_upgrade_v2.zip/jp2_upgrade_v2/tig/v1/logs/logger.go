package logs

import (
	"os"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/subosito/gotenv"
	lumberjack "gopkg.in/natefinch/lumberjack.v2"
)

//Logger var
var Logger = logrus.New()

func init() {
	gotenv.Load()
	var filePath = os.Getenv("LOGGER_PATH")
	array := strings.Split(filePath, ".")
	if len(array) >= 2 {
		filePath = array[0] + time.Now().Format("01-02-2006") + "." + array[1]
	}

	Logger.SetFormatter(&logrus.TextFormatter{
		DisableColors:   false,
		TimestampFormat: "02-01-2006 15:04:05",
	})
	Logger.SetOutput(&lumberjack.Logger{
		Filename: filePath,
		MaxSize:  1, // megabytes
	})
}
