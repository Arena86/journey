package middlewares

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

const LOGIN_MODE_WEB = "web"
const LOGIN_MODE_DEVICE = "device"

// CORSMiddleware func
func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With, auth-session, auth-session-v9, content-type, auth-nonce, auth-nonce-response, userid, token, serverpassword, dbname, dbuser, dbpassword, security, expireddate, subsidiary, accountkey, permissioncode, language, locationid, locationgroupid,companyid,mode")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, DELETE")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}

// ValidateToken func
func ValidateToken() gin.HandlerFunc {
	return func(c *gin.Context) {
		// begin write log file
		defer libs.RecoverError(c, "Validate API")
		var (
			status          = 200
			loggedModel     models.DBLoggedUser
			msg             = ""
			checkHeader     = true
			responseHeader  models.RequestHeader
			errHeader       error
			isIntegrated    = false
			integrationType = ""
		)
		lang := services.GetLanguageKey(c)
		// validate security
		paramsHeader := c.Request.Header.Get("security")
		mode := c.Request.Header.Get("mode")
		isIntegratedRequest := c.Request.Header.Get("isintegrated")
		if isIntegratedRequest != "" {
			isIntegrated, _ = strconv.ParseBool(isIntegratedRequest)
			integrationType = c.Request.Header.Get("integrationtype")
		}
		responseHeader, errHeader = libs.Decrypt(paramsHeader)
		if errHeader != nil {
			checkHeader = false
		}
		if !checkHeader {
			status = 400
			msg = services.GetMessage(lang, "api.header_request_incorrect")
		} else {
			// validate token in table logged
			db := jpdatabase.CheckDBConnection(responseHeader.DBName, responseHeader.DBUser, responseHeader.DBPassword, responseHeader.DBServer, responseHeader.DBPort)
			if !isIntegrated {
				token := c.Request.Header.Get("token")
				if token == "" {
					status = 422
					msg = services.GetMessage(lang, "api.field_required", "Token")
				}
				if status == 200 {
					if mode == LOGIN_MODE_DEVICE {
						resultFindToken := db.Where("DeviceToken = ?", token).First(&loggedModel)
						if resultFindToken.RowsAffected == 0 {
							status = 401
							msg = "TOKEN_INVALID"
						} else {
							if loggedModel.ExpiredDate != nil {
								expiredDate := *loggedModel.ExpiredDate
								// @TODO ree calculate this expiredDate
								if expiredDate.Unix() < time.Now().Unix() {
									// expiredDate
									status = 401 // Unauthorized
									msg = "TOKEN_INVALID"
								} else {
									status = 200
									msg = services.GetMessage(lang, "api.token_expired")
								}
							} else {
								// expiredDate
								status = 401 // Unauthorized
								msg = "TOKEN_INVALID"
							}
						}
					} else {
						resultFindToken := db.Where("Token = ?", token).First(&loggedModel)
						if resultFindToken.RowsAffected == 0 {
							status = 401
							msg = "TOKEN_INVALID"
						} else {
							if loggedModel.ExpiredDate != nil {
								expiredDate := *loggedModel.ExpiredDate
								// @TODO ree calculate this expiredDate
								if expiredDate.Unix() < time.Now().Unix() {
									// expiredDate
									status = 401 // Unauthorized
									msg = "TOKEN_INVALID"
								} else {
									status = 200
									msg = services.GetMessage(lang, "api.token_expired")
								}
							} else {
								// expiredDate
								status = 401 // Unauthorized
								msg = "TOKEN_INVALID"
							}
						}
					}
				}
			} else {
				if integrationType == "" {
					status = 400
					msg = services.GetMessage(lang, "api.header_request_incorrect")
				} else {
					token := c.Request.Header.Get("token")
					if token == "" {
						status = 422
						msg = services.GetMessage(lang, "api.field_required", "Token")
					}
					if status == 200 {
						if integrationType == "jobfile" {
							var jobfile models.JobFileConfig
							resultFindToken := db.Where("AccessToken = ?", token).First(&jobfile)
							if resultFindToken.RowsAffected == 0 {
								status = 401
								msg = "TOKEN_INVALID"
							}
						}
						if integrationType == "xero" {
							//@TODO: handle
						}
					}
				}
			}
		}
		if status == 200 {
			c.Next()
		} else {
			responseData := gin.H{
				"status": status,
				"msg":    msg,
			}
			c.JSON(status, responseData)
			c.Abort()
		}
	}
}
