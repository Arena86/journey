package libs

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"jpapi/tig/v1/logs"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"math"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	jpdatabase "jpapi/tig/v1/databases/jp"

	"github.com/gin-gonic/gin"
	gomail "gopkg.in/gomail.v2"
)

// MYSQLDATE const
const MYSQLDATE = "2006-01-02T15:04:05Z"

// MYSQLDATE2 const
const MYSQLDATE2 = "2006-01-02T15:04:05-07:00"

const FORMATDATE = "2006-01-02"

const FORMATDATETIME = "2006-01-02 15:04"

// RecoverError func
func RecoverError(c *gin.Context, FuncName string) {
	if r := recover(); r != nil {
		responseData := gin.H{
			"status": 500,
			"msg":    r,
		}
		c.JSON(500, responseData)
		logger := logs.Logger
		userToken := c.Request.Header.Get("token")
		paramsHeader := c.Request.Header.Get("security")
		responseHeader, errHeader := Decrypt(paramsHeader)
		if errHeader == nil {
			db := jpdatabase.CheckDBConnection(responseHeader.DBName, responseHeader.DBUser, responseHeader.DBPassword, responseHeader.DBServer, responseHeader.DBPort)

			var loggedUser models.DBLoggedUser
			db.Where("Token = ?", userToken).Find(&loggedUser)
			logger.Error(FuncName + ": " + loggedUser.AccountKey + " - " + fmt.Sprintf("%v", r))
		}
		return
	}
}

// DecodeBase64 func
func DecodeBase64(s string) []byte {
	data, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		panic(err)
	}
	return data
}

// Decrypt func
func Decrypt(cipherText string) (models.RequestHeader, error) {
	var (
		err        error
		resultByte []byte
		resHeader  models.RequestHeader
	)
	cipherByte := DecodeBase64(cipherText)
	key := []byte(os.Getenv("SERCURITY_KEY"))
	c, err := aes.NewCipher(key)
	if err != nil {
		return resHeader, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return resHeader, err
	}
	nonceSize := gcm.NonceSize()
	if len(cipherByte) < nonceSize {
		return resHeader, errors.New(services.GetMessage("", "api.text_too_short"))
	}
	nonce, cipherByte := cipherByte[:nonceSize], cipherByte[nonceSize:]
	resultByte, err = gcm.Open(nil, nonce, cipherByte, nil)
	resultStr := string(resultByte)
	json.Unmarshal([]byte((resultStr)), &resHeader)
	return resHeader, err
}

// SetPagination func
func SetPagination(c *gin.Context) (string, string) {
	var (
		strOffset, strRow string
		intOffset, intRow int
	)
	strOffset = c.Query("offset")
	intOffset, _ = strconv.Atoi(strOffset)
	strRow = c.Query("row")
	intRow, _ = strconv.Atoi(strRow)
	if strOffset == "" && intOffset <= 0 {
		strOffset = "0"
	}
	if strRow == "" && intRow <= 0 {
		strRow = "10"
	}
	return strOffset, strRow
}

// GetQueryParam func
func GetQueryParam(param string, c *gin.Context) (string, bool) {
	vParam, sParam := c.GetQuery(param)
	vParamLower, sParamLower := c.GetQuery(strings.ToLower(param))
	if sParam {
		return vParam, sParam
	}
	if sParamLower {
		return vParamLower, sParamLower
	}
	return "", false
}

// InArrayString func
func InArrayString(i string, arr []string) bool {
	for _, v := range arr {
		if v == i {
			return true
		}
	}
	return false
}

// InArrayInteger func
func InArrayInteger(i int, arr []int) bool {
	for _, v := range arr {
		if v == i {
			return true
		}
	}
	return false
}

// FixMaxString func
func FixMaxString(s string) string {
	if len(s) >= 3 {
		//return s
		return s[0:3]
	}
	lenString := len(s)
	lenLoop := 3 - lenString
	valRes := s
	for i := 0; i < lenLoop; i++ {
		valRes = valRes + " "
	}
	return valRes
}

// RemoveAllSpaceInString func
func RemoveAllSpaceInString(s string) string {
	return strings.Replace(s, " ", "", -1)
}

// SendEmail func
func SendEmail(emailFrom, nameFrom, emailTo, nameTo, subject, body string) (int, string) {
	var (
		status = 200
		msg    string
	)
	m := gomail.NewMessage()
	emailToArray := strings.Split(emailTo, ";")
	if len(emailToArray) > 0 {
		m.SetHeader("To", emailToArray...)
	} else {
		m.SetAddressHeader("To", emailTo, nameTo)
	}
	m.SetAddressHeader("From", emailFrom, nameFrom)

	m.SetHeader("Subject", subject)
	m.SetBody("text/html", body)

	EMAILHOST := os.Getenv("EMAILHOST")
	EMAILPORT := os.Getenv("EMAILPORT")
	EMAILPORTINT, _ := strconv.Atoi(EMAILPORT)
	EMAILUSER := os.Getenv("EMAILUSER")
	EMAILPASS := os.Getenv("EMAILPASS")

	d := gomail.NewDialer(EMAILHOST, EMAILPORTINT, EMAILUSER, EMAILPASS)
	d.TLSConfig = &tls.Config{InsecureSkipVerify: true}

	// Send the email to email.
	if err := d.DialAndSend(m); err != nil {
		status = 500
		msg = err.Error()
	} else {
		msg = services.GetMessage("", "api.success")
	}
	return status, msg
}

// SendEmailWithAttachs func
func SendEmailWithAttachs(emailFrom, nameFrom, emailTo, nameTo, subject, body string, attachs []string) (int, error) {
	var (
		status = 200
		err    error
	)

	m := gomail.NewMessage()
	/* m.SetHeader("From", "testing@example.com")
	m.SetHeader("To", "arena@theinnovationguys.com") */
	m.SetAddressHeader("From", emailFrom, nameFrom)
	m.SetAddressHeader("To", emailTo, nameTo)
	//m.SetAddressHeader("Cc", "dan@example.com", "Dan")
	m.SetHeader("Subject", subject)
	m.SetBody("text/html", body)
	if len(attachs) > 0 {
		for _, file := range attachs {
			fmt.Println("file: ", file)
			m.Attach(file)
		}
	}

	EMAILHOST := os.Getenv("EMAILHOST")
	EMAILPORT := os.Getenv("EMAILPORT")
	EMAILPORTINT, _ := strconv.Atoi(EMAILPORT)
	EMAILUSER := os.Getenv("EMAILUSER")
	EMAILPASS := os.Getenv("EMAILPASS")

	d := gomail.NewDialer(EMAILHOST, EMAILPORTINT, EMAILUSER, EMAILPASS)
	d.TLSConfig = &tls.Config{InsecureSkipVerify: true}

	// Send the email to email.
	if err = d.DialAndSend(m); err != nil {
		status = 500
	}
	return status, err
}

// RequestAPIRee func
func RequestAPIRee(lang string, method string, representURL string, data interface{}, params map[string]interface{}, headers map[string]interface{}) (int, interface{}, []byte) {
	var (
		status       = 200
		msg          interface{}
		responsData  []byte
		bodyDataJSON []byte
		errRes       models.ServerREEResponse
	)

	if data != nil {
		vBodyDataJSON, sBodyDataJSON := json.Marshal(data)
		if sBodyDataJSON == nil {
			bodyDataJSON = vBodyDataJSON
		}
	}
	URL := representURL
	req, err := http.NewRequest(method, URL, bytes.NewBuffer(bodyDataJSON))
	req.Close = true
	if err != nil {
		status = 500
		msg = err.Error()
	} else {
		// add query params
		if params != nil && len(params) > 0 {
			query := url.Values{}
			for k, v := range params {
				query.Add(k, v.(string))
			}
			req.URL.RawQuery = query.Encode()
		}
		// add headers
		if headers == nil {
			headers = make(map[string]interface{})
		}
		if headers != nil {
			for k, v := range headers {
				req.Header.Set(k, v.(string))
			}
		}
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			responsData = body
			msg = services.GetMessage(lang, "api.success")
		} else {
			if resp != nil {
				status = resp.StatusCode
				body, _ := ioutil.ReadAll(resp.Body)
				json.Unmarshal([]byte(string(body)), &errRes)
				msg = errRes.Msg
			} else {
				status = 500
			}
			if err != nil {
				msg = err.Error()
			} else {
				if msg == nil {
					msg = services.GetMessage(lang, "api.request_api_error")
				}
			}
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}

	return status, msg, responsData
}

// RequestAPI func
func RequestAPI(lang string, method string, representURL string, data interface{}, params map[string]interface{}, headers map[string]interface{}) (int, interface{}, []byte) {
	var (
		status       = 200
		msg          interface{}
		responsData  []byte
		bodyDataJSON []byte
	)

	if data != nil {
		vBodyDataJSON, sBodyDataJSON := json.Marshal(data)
		if sBodyDataJSON == nil {
			bodyDataJSON = vBodyDataJSON
		}
	}
	URL := representURL
	req, err := http.NewRequest(method, URL, bytes.NewBuffer(bodyDataJSON))
	req.Close = true
	//fmt.Println("req: ", req)
	//fmt.Println("err: ", err)
	if err != nil {
		status = 500
		msg = err.Error()
	} else {
		// add query params
		if params != nil && len(params) > 0 {
			query := url.Values{}
			for k, v := range params {
				query.Add(k, v.(string))
			}
			req.URL.RawQuery = query.Encode()
		}
		//fmt.Println("params: ", params)
		// add headers
		if headers == nil {
			headers = make(map[string]interface{})
		}
		if headers != nil {
			for k, v := range headers {
				req.Header.Set(k, v.(string))
			}
		}
		//fmt.Println("headers: ", headers)
		client := &http.Client{}
		resp, err := client.Do(req)
		//fmt.Println("req: ", req)
		//fmt.Println("err: ", err)
		//fmt.Println("resp: ", resp)
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			responsData = body
			msg = services.GetMessage(lang, "api.success")
		} else {
			if resp != nil {
				status = resp.StatusCode
				body, _ := ioutil.ReadAll(resp.Body)
				responsData = body
			} else {
				status = 500
			}
			if err != nil {
				msg = err.Error()
			} else {
				if msg == nil {
					msg = services.GetMessage(lang, "api.request_api_error")
				}
			}
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}

	return status, msg, responsData
}

// MinMax func
func MinMax(array []float64) (float64, float64) {
	if array != nil {
		max := array[0]
		min := array[0]
		for _, value := range array {
			if max < value {
				max = value
			}
			if min > value {
				min = value
			}
		}

		return min, max
	}
	return 0, 0
}

// SUM func
func SUM(array []float64) float64 {
	result := 0.0
	if array != nil {
		for _, v := range array {
			result += v
		}
	}
	return result
}

// Average func
func Average(array []float64) float64 {
	result := 0.0
	if array != nil {
		for _, v := range array {
			result += v
		}
	}
	return result / float64(len(array))
}

// FileExists func
func FileExists(filename string) bool {
	info, err := os.Stat(filename)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}

// ToFixedPlaces func
func ToFixedPlaces(num float64, precision int) float64 {
	output := math.Pow(10, float64(precision))
	return float64(Round(num*output)) / output
}

// Round func
func Round(num float64) int {
	return int(num + math.Copysign(0.5, num))
}

// ConvertDateTimeToWeekDay func
func ConvertDateTimeToWeekDay(dateTime time.Time) int {
	weekday := dateTime.Weekday()
	return int(weekday)
}

// FindMaxInArray func
func FindMaxInArray(arr []int) int {
	max := 0
	for _, n := range arr {
		if n > max {
			max = n
		}
	}
	return max
}

// JobMappingStatus func
func JobMappingStatus(jobTaskStatus int) int {
	var (
		jobStatus int
	)
	switch jobTaskStatus {
	case 1:
		jobStatus = 4
	case 2:
		jobStatus = 5
	case 3:
		jobStatus = 6
	case 4:
		jobStatus = 6
	}

	return jobStatus
}

// ChangeUIConditionToMysqlCondition func
func ChangeUIConditionToMysqlCondition(conditionCode string) string {
	switch conditionCode {
	case "eq", "tf":
		return "="
	case "ne":
		return "<>"
	case "nl":
		return "IS NULL"
	case "nn":
		return "IS NOT NULL"
	case "lk":
		return "LIKE"
	case "lt":
		return "<"
	case "gt":
		return ">"
	case "le":
		return "<="
	case "ge":
		return ">="
	default:
		return ""
	}
}

// GetInvalidValidateStatus func
func GetInvalidValidateStatus() int {
	return GetStatusUnprocessableEntity()
}

func PrintJSON(obj interface{}) {
	objJSON, _ := json.MarshalIndent(obj, "", "\t")
	fmt.Println(string(objJSON))
}
