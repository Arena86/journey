package libs

import (
	"encoding/json"
	"jpapi/tig/v1/models"
	"os"
	"strconv"
)

// GetStripeSecretKey func
func GetStripeSecretKey(lang string, accountID int) models.StripeConfig {
	var stripeConfig models.StripeConfig
	URL := os.Getenv("SERVER_REE") + "/" + "getstripesetting" + "/" + strconv.Itoa(accountID)
	statusRee, _, dataRee := RequestAPIRee(lang, "GET", URL, nil, nil, nil)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(dataRee, &reeResponse)
		vStripeConfig, sStripeConfig := reeResponse["data"]
		if sStripeConfig {
			stripeConfigJSON, errStripeConfigJSON := json.Marshal(vStripeConfig)
			if errStripeConfigJSON == nil {
				json.Unmarshal(stripeConfigJSON, &stripeConfig)
			}
		}
	}
	return stripeConfig
}

// GetChargeBeeConfig func
func GetChargeBeeConfig(lang string, accountID int) models.ChargeBeeConfig {
	var chargeBeeConfig models.ChargeBeeConfig
	URL := os.Getenv("SERVER_REE") + "/" + "getchargebeesetting" + "/" + strconv.Itoa(accountID)
	statusRee, _, dataRee := RequestAPIRee(lang, "GET", URL, nil, nil, nil)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(dataRee, &reeResponse)
		vChargeBeeConfig, sChargeBeeConfig := reeResponse["data"]
		if sChargeBeeConfig {
			chargeBeeConfigJSON, errChargeBeeConfigJSON := json.Marshal(vChargeBeeConfig)
			if errChargeBeeConfigJSON == nil {
				json.Unmarshal(chargeBeeConfigJSON, &chargeBeeConfig)
			}
		}
	}
	return chargeBeeConfig
}
