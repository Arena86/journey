package libs

const JobStatusOpen = 0
const JobStatusScheduled = 1
const JobStatusAllocated = 2
const JobStatusPicked = 3
const JobStatusInTransit = 4
const JobStatusArrived = 5
const JobStatusInProgress = 6
const JobStatusCompleted = 7

func GetPositionJobStatus(status int) int {
	position := status
	// map[status]position
	// position[0] = Open
	// position[1] = Scheduled
	// position[2] = Allocated
	// position[3] = Picked
	// position[4] = InTransit
	// position[5] = Arrived
	// position[6] = In Progress
	// position[7] = Completed
	var JobStatusPosition = map[int]int{
		JobStatusOpen: 0, JobStatusScheduled: 1, JobStatusAllocated: 2, JobStatusPicked: 3,
		JobStatusInTransit: 4, JobStatusArrived: 5, JobStatusInProgress: 6, JobStatusCompleted: 7,
	}
	iPosition, hasStatus := JobStatusPosition[status]
	if hasStatus {
		position = iPosition
	}
	return position
}
