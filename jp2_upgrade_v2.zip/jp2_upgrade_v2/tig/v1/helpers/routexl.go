package libs

import (
	"encoding/json"
	"io/ioutil"
	"jpapi/tig/v1/models"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"time"
)

var mapRouteXLServiceConfig = make(map[int]models.RouteXL)

var mapGraphHopperConfig = make(map[int]models.GraphHopperConfig)

var mapTomTomConfig = make(map[int]models.TomTomConfig)

// GetRouteXL func
func GetRouteXL(accountKey int) models.RouteXL {
	//fmt.Printf("mapRouteXLServiceConfig: %+v\n", mapRouteXLServiceConfig)
	// find RouteXL config in global variables
	for key, routeXLConfig := range mapRouteXLServiceConfig {
		if accountKey == key {
			return routeXLConfig
		}
	}
	//fmt.Println("Find RouteXL Config from Ree")
	var (
		routeXLResponse models.RouteXLResponse
		routeXL         models.RouteXL
	)
	serverIP := os.Getenv("CRONJOB_SERVER_IP")
	URL := os.Getenv("SERVER_REE") + "/getroutexl/" + strconv.Itoa(accountKey)
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		query := url.Values{}
		query.Add("ip", serverIP)
		req.URL.RawQuery = query.Encode()
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			json.Unmarshal([]byte(string(body)), &routeXLResponse)
			routeXL = routeXLResponse.Data
			// add RouteXL config to global variable
			mapRouteXLServiceConfig[accountKey] = routeXL
		}
	}
	return routeXL
}

// GetGraphHopper func
func GetGraphHopper(accountKey int) models.GraphHopperConfig {
	for key, graphHopperConfig := range mapGraphHopperConfig {
		if accountKey == key {
			return graphHopperConfig
		}
	}
	var (
		graphHopperConfig models.GraphHopperConfig
	)
	URL := os.Getenv("SERVER_REE") + "/getgraphhopper/" + strconv.Itoa(accountKey)
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			vGraphHopper, sGraphHopper := reeResponse["data"]
			if sGraphHopper {
				graphHopperJSON, errGraphHopperJSON := json.Marshal(vGraphHopper)
				if errGraphHopperJSON == nil {
					json.Unmarshal(graphHopperJSON, &graphHopperConfig)
					// add sms config to global variable
					mapGraphHopperConfig[accountKey] = graphHopperConfig
				}
			}
		}
	}
	return graphHopperConfig
}

// GetTomTom func
func GetTomTom(accountKey int) models.TomTomConfig {
	for key, tomTomConfig := range mapTomTomConfig {
		if accountKey == key {
			return tomTomConfig
		}
	}
	var (
		tomTomConfig models.TomTomConfig
	)
	URL := os.Getenv("SERVER_REE") + "/gettomtom/" + strconv.Itoa(accountKey)
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			vTomTom, sTomTom := reeResponse["data"]
			if sTomTom {
				tomTomJSON, errTomTomJSON := json.Marshal(vTomTom)
				if errTomTomJSON == nil {
					json.Unmarshal(tomTomJSON, &tomTomConfig)
					// add sms config to global variable
					mapTomTomConfig[accountKey] = tomTomConfig
				}
			}
		}
	}
	return tomTomConfig
}
func ConvertSnapPreventionFromJPToGraphHopper(jpSnapPreventions []string) []string {
	var resSnapPreventions = make([]string, 0)
	for _, jpSnap := range jpSnapPreventions {
		var ghSnap string
		switch jpSnap {
		case "motorway":
			ghSnap = "motorway"
		case "trunk":
			ghSnap = "trunk"
		case "bridge":
			ghSnap = "bridge"
		case "ford":
			ghSnap = "ford"
		case "tunnel":
			ghSnap = "tunnel"
		case "ferry":
			ghSnap = "ferry"
		}
		if ghSnap != "" {
			if !InArrayString(ghSnap, resSnapPreventions) {
				resSnapPreventions = append(resSnapPreventions, ghSnap)
			}
		}
	}
	return resSnapPreventions
}

func MappingResourceTypeToGraphHopper(resourceType int) string {
	resData := "truck"
	switch resourceType {
	case 1:
		resData = "truck"
		break
	case 2:
		resData = "car"
		break
	case 3:
		resData = "bike"
		break
	case 4:
		resData = "foot"
		break
	case 7:
		resData = "small_truck"
		break
	case 8:
		resData = "bike"
		break
	case 10:
		resData = "car"
		break
	case 12:
		resData = "truck"
		break
	case 13:
		resData = "truck"
		break
	}
	return resData
}
