package libs

import (
	"encoding/base64"
	"io/ioutil"
	"jpapi/tig/v1/models"
	"strings"
)

// ExportToImageFileFromImageBase64 func
func ExportToImageFileFromImageBase64(fileNamePath string, imageBase64 string) error {
	//fileNamePath := "./output.jpg" > png, jpg
	lenTrim := strings.Index(imageBase64, ",")
	if lenTrim > 0 {
		lenTrim = lenTrim + 1
		imageBase64 = strings.TrimPrefix(imageBase64, imageBase64[0:lenTrim])
	}
	bytImage, err := base64.StdEncoding.DecodeString(imageBase64)
	if err == nil {
		err = ioutil.WriteFile(fileNamePath, bytImage, 0666)
	}
	return err
}

// GetServerEndPointJPServer func
func GetServerEndPointJPServer(requestHeader models.RequestHeader) string {
	return requestHeader.ServerProtocol + "://" + requestHeader.ServerIP + ":" + requestHeader.ServerPort + "/"
}
