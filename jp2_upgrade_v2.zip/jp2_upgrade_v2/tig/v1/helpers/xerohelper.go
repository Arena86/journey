package libs

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/logs"
	xerologs "jpapi/tig/v1/logs/xero"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// CountXero int
var CountXero = 0

// EncodeBase64 func
func EncodeBase64(b []byte) string {
	return base64.StdEncoding.EncodeToString(b)
}

// GetXeroAPIURL func
func GetXeroAPIURL(baseURL string) string {
	return baseURL + "/api.xro/2.0/"
}

// CheckValidAccessToken func
func CheckValidAccessToken(xeroConfig models.XeroConfig, accessToken string) bool {
	var (
		xeroLoggerFailed  = xerologs.XeroLoggerFailed
		xeroLoggerSuccess = xerologs.XeroLoggerSuccess
	)
	CountXero++
	validAccessToken := false
	URL := xeroConfig.BaseURL + "/connections"
	req, err := http.NewRequest("GET", URL, nil)
	req.Close = true
	logger := logs.Logger
	if err == nil {
		token := "Bearer " + accessToken
		req.Header.Set("Authorization", token)
		req.Header.Set("Content-Type", "application/json")
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			validAccessToken = true
			xeroLoggerSuccess.Info("CheckValidAccessToken > req: ", req)
			xeroLoggerSuccess.Info("CheckValidAccessToken > resp: ", resp)
			xeroLoggerSuccess.Info("CheckValidAccessToken > CountXero: ", CountXero)
		} else {
			var xeroLoggerBody []byte
			if resp != nil {
				body, _ := ioutil.ReadAll(resp.Body)
				xeroLoggerBody = body
				logger.Println("CheckValidAccessToken: ", string(body))
			}
			xeroLoggerFailed.Error("CheckValidAccessToken > req: ", req)
			xeroLoggerFailed.Error("CheckValidAccessToken > resp: ", resp)
			xeroLoggerFailed.Error("CheckValidAccessToken > err: ", err)
			xeroLoggerFailed.Error("CheckValidAccessToken > body: ", string(xeroLoggerBody))
			xeroLoggerFailed.Error("CheckValidAccessToken > CountXero: ", CountXero)
		}

		if resp != nil {
			defer resp.Body.Close()
		}
	}
	return validAccessToken
}

// GetXeroAccessToken func
func GetXeroAccessToken(requestHeader models.RequestHeader) (models.XeroConfig, bool) {
	var (
		xeroConfig            models.XeroConfig
		xeroConfigKey         = 1
		validAccessToken      = false
		isInvalidGrant        = false
		refreshAccessTokenRes models.RetrieveAccessTokenResponse
		getAccessTokenRes     models.RetrieveAccessTokenResponse
	)
	logger := logs.Logger
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	resultFindConfig := db.Where("XeroConfigKey = ?", xeroConfigKey).First(&xeroConfig)
	if resultFindConfig.RowsAffected > 0 {
		if xeroConfig.AccessToken != "" {
			// test accesstoken
			validAccessToken = CheckValidAccessToken(xeroConfig, xeroConfig.AccessToken)
		}
		// accesstoken invalid > refresh accesstoken
		if !validAccessToken {
			if xeroConfig.RefreshToken != "" {
				refreshAccessTokenRes, isInvalidGrant = RefreshAccessToken(xeroConfig)
				if refreshAccessTokenRes.AccessToken != "" && refreshAccessTokenRes.RefreshToken != "" {
					// test accesstoken
					validAccessToken = CheckValidAccessToken(xeroConfig, refreshAccessTokenRes.AccessToken)
					if validAccessToken {
						dbRefresh := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
						logger.Println("Refresh Access Token OK - ", refreshAccessTokenRes)
						xeroConfig.AccessToken = refreshAccessTokenRes.AccessToken
						xeroConfig.RefreshToken = refreshAccessTokenRes.RefreshToken
						resultSave := dbRefresh.Save(&xeroConfig)
						if resultSave.Error != nil {
							logger.Println("Save Refresh Access Token Error: ", resultSave.Error.Error())
						}
						var (
							xeroLoggerFailed = xerologs.XeroLoggerFailed
						)
						xeroLoggerFailed.Info("GetXeroAccessToken > RefreshToken > resultSave.Error: ", resultSave.Error)
					}
				}
			}
		}
		// accesstoken invalid > get accesstoken from AuthorizationCode
		if !validAccessToken {
			if xeroConfig.AuthorizationCode != "" {
				getAccessTokenRes, isInvalidGrant = GetAccessTokenFromAuthorizationCode(xeroConfig)
				if getAccessTokenRes.AccessToken != "" && getAccessTokenRes.RefreshToken != "" {
					// test accesstoken
					validAccessToken = CheckValidAccessToken(xeroConfig, getAccessTokenRes.AccessToken)
					if validAccessToken {
						dbRefresh := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
						xeroConfig.AccessToken = getAccessTokenRes.AccessToken
						xeroConfig.RefreshToken = getAccessTokenRes.RefreshToken
						resultSave := dbRefresh.Save(&xeroConfig)
						if resultSave.Error != nil {
							logger.Println("Save New Token Error: ", resultSave.Error.Error())
						}
						var (
							xeroLoggerFailed = xerologs.XeroLoggerFailed
						)
						xeroLoggerFailed.Info("GetXeroAccessToken > AuthorizationCode > resultSave.Error: ", resultSave.Error)
					}
				}
			}
		}
		if isInvalidGrant {
			dbRefresh := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			// reset data
			xeroConfig.AccessToken = ""
			xeroConfig.RefreshToken = ""
			resultSave := dbRefresh.Save(&xeroConfig)
			if resultSave.Error != nil {
				logger.Println("Save Xero Config Error: ", resultSave.Error.Error())
			}
			var (
				xeroLoggerFailed = xerologs.XeroLoggerFailed
			)
			xeroLoggerFailed.Error("GetXeroAccessToken > AuthorizationCode > isInvalidGrant: ", isInvalidGrant)
			xeroLoggerFailed.Printf("GetXeroAccessToken > AuthorizationCode > xeroConfig: %+v\n", xeroConfig)
			xeroLoggerFailed.Error("GetXeroAccessToken > AuthorizationCode > resultSave.Error: ", resultSave.Error)
		}
	}
	return xeroConfig, isInvalidGrant
}

// RefreshAccessToken func
func RefreshAccessToken(xeroConfig models.XeroConfig) (models.RetrieveAccessTokenResponse, bool) {
	var (
		refreshAccessTokenRes models.RetrieveAccessTokenResponse
		errorResponse         models.XeroErrorResponse
		isInvalidGrant        = false
	)
	var (
		xeroLoggerFailed  = xerologs.XeroLoggerFailed
		xeroLoggerSuccess = xerologs.XeroLoggerSuccess
	)
	CountXero++
	currentTime := time.Now()
	logger := logs.Logger
	logger.Println("RefreshAccessToken At: ", currentTime)
	bodyData := url.Values{}
	bodyData.Set("grant_type", "refresh_token")
	bodyData.Set("refresh_token", xeroConfig.RefreshToken)
	URL := xeroConfig.IdentityURL + "/connect/token"
	logger.Println("bodyData: ", strings.NewReader(bodyData.Encode()))
	req, err := http.NewRequest("POST", URL, strings.NewReader(bodyData.Encode()))
	req.Close = true
	if err == nil {
		token := "Basic " + EncodeBase64([]byte(xeroConfig.ClientID+":"+xeroConfig.ClientSecret))
		logger.Println("ClientID: ", xeroConfig.ClientID)
		logger.Println("ClientSecret: ", xeroConfig.ClientSecret)
		//logger.Println("Token: ", token)
		req.Header.Set("authorization", token)
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			json.Unmarshal([]byte(string(body)), &refreshAccessTokenRes)
			xeroLoggerSuccess.Info("RefreshAccessToken > req: ", req)
			xeroLoggerSuccess.Info("RefreshAccessToken > resp: ", resp)
			xeroLoggerSuccess.Info("RefreshAccessToken > CountXero: ", CountXero)
		} else {
			var xeroLoggerBody []byte
			if resp != nil {
				body, _ := ioutil.ReadAll(resp.Body)
				xeroLoggerBody = body
				json.Unmarshal([]byte(string(body)), &errorResponse)
				logger.Println("RefreshAccessToken: ", string(body))

				if errorResponse.Error == "invalid_grant" {
					isInvalidGrant = true
				}
			}
			xeroLoggerFailed.Error("RefreshAccessToken > req: ", req)
			xeroLoggerFailed.Error("RefreshAccessToken > resp: ", resp)
			xeroLoggerFailed.Error("RefreshAccessToken > err: ", err)
			xeroLoggerFailed.Error("RefreshAccessToken > body: ", string(xeroLoggerBody))
			xeroLoggerFailed.Error("RefreshAccessToken > CountXero: ", CountXero)
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}
	return refreshAccessTokenRes, isInvalidGrant
}

// GetAccessTokenFromAuthorizationCode func
func GetAccessTokenFromAuthorizationCode(xeroConfig models.XeroConfig) (models.RetrieveAccessTokenResponse, bool) {
	var (
		refreshAccessTokenRes models.RetrieveAccessTokenResponse
		errorResponse         models.XeroErrorResponse
		isInvalidGrant        = false
	)
	var (
		xeroLoggerFailed  = xerologs.XeroLoggerFailed
		xeroLoggerSuccess = xerologs.XeroLoggerSuccess
	)
	CountXero++
	bodyData := url.Values{}
	bodyData.Set("grant_type", "authorization_code")
	bodyData.Set("code", xeroConfig.AuthorizationCode)
	bodyData.Set("redirect_uri", xeroConfig.RedirectURI)
	URL := xeroConfig.IdentityURL + "/connect/token"
	req, err := http.NewRequest("POST", URL, strings.NewReader(bodyData.Encode()))
	req.Close = true
	if err == nil {
		token := "Basic " + EncodeBase64([]byte(xeroConfig.ClientID+":"+xeroConfig.ClientSecret))
		req.Header.Set("authorization", token)
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			json.Unmarshal([]byte(string(body)), &refreshAccessTokenRes)
			xeroLoggerSuccess.Info("GetAccessTokenFromAuthorizationCode > req: ", req)
			xeroLoggerSuccess.Info("GetAccessTokenFromAuthorizationCode > resp: ", resp)
			xeroLoggerSuccess.Info("GetAccessTokenFromAuthorizationCode > CountXero: ", CountXero)
		} else {
			var xeroLoggerBody []byte
			if resp != nil {
				logger := logs.Logger
				body, _ := ioutil.ReadAll(resp.Body)
				xeroLoggerBody = body
				json.Unmarshal([]byte(string(body)), &errorResponse)
				logger.Println("GetAccessTokenFromAuthorizationCode: ", string(body))

				if errorResponse.Error == "invalid_grant" {
					isInvalidGrant = true
				}
			}
			xeroLoggerFailed.Error("GetAccessTokenFromAuthorizationCode > req: ", req)
			xeroLoggerFailed.Error("GetAccessTokenFromAuthorizationCode > resp: ", resp)
			xeroLoggerFailed.Error("GetAccessTokenFromAuthorizationCode > err: ", err)
			xeroLoggerFailed.Error("GetAccessTokenFromAuthorizationCode > body: ", string(xeroLoggerBody))
			xeroLoggerFailed.Error("GetAccessTokenFromAuthorizationCode > CountXero: ", CountXero)
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}
	return refreshAccessTokenRes, isInvalidGrant
}

// RequestXero func
func RequestXero(requestHeader models.RequestHeader, lang string, method string, representURL string,
	data interface{}, params map[string]interface{}, headers map[string]interface{}, isPDF ...bool) (int, interface{}, []byte) {
	var (
		status      = 200
		msg         interface{}
		responsData []byte
		xeroConfig  models.XeroConfig
	)
	retryTimes := 0
	for {
		xeroConfig, status, msg = AuthorizedXero(requestHeader, lang)
		if status == 200 {
			pdf := false
			if len(isPDF) > 0 && isPDF[0] {
				pdf = isPDF[0]
			}
			status, msg, responsData = RequestXeroAPI(xeroConfig, requestHeader, lang, method, representURL, data, params, headers, pdf)
			if status == 200 || status == 429 {
				break
			}

			retryTimes++
			logger := logs.Logger
			if retryTimes > 3 {
				break
			}
			logger.Println("retryTimes: ", retryTimes)
		} else {
			break
		}
	}

	return status, msg, responsData
}

// AuthorizedXero func
func AuthorizedXero(requestHeader models.RequestHeader, lang string) (models.XeroConfig, int, interface{}) {
	var (
		status         = 200
		msg            interface{}
		xeroConfig     models.XeroConfig
		isInvalidGrant = false
	)
	xeroConfig, isInvalidGrant = GetXeroAccessToken(requestHeader)
	if !isInvalidGrant {
		if xeroConfig.AccessToken == "" {
			status = 404
			msg = services.GetMessage(lang, "api.field_not_found", "AccessToken")
		} else if xeroConfig.TenantID == "" {
			status = 404
			msg = services.GetMessage(lang, "api.field_not_found", "TenantID")
		}
	} else {
		status = 401
		msg = services.GetMessage(lang, "api.xero_invalid_grant", "")
	}
	return xeroConfig, status, msg
}

// RequestXeroAPI func
func RequestXeroAPI(xeroConfig models.XeroConfig, requestHeader models.RequestHeader, lang string, method string, representURL string,
	data interface{}, params map[string]interface{}, headers map[string]interface{}, isPDF ...bool) (int, interface{}, []byte) {
	var (
		status       = 200
		msg          interface{}
		responsData  []byte
		bodyDataJSON []byte
		errRes       models.XeroErrorPostResponse
		errAuthenRes models.XeroErrorConnectionResponse
	)
	logger := logs.Logger
	var (
		xeroLoggerFailed  = xerologs.XeroLoggerFailed
		xeroLoggerSuccess = xerologs.XeroLoggerSuccess
	)
	CountXero++
	if data != nil {
		vBodyDataJSON, sBodyDataJSON := json.Marshal(data)
		if sBodyDataJSON == nil {
			bodyDataJSON = vBodyDataJSON
		}
	}
	URL := GetXeroAPIURL(xeroConfig.BaseURL) + representURL
	req, err := http.NewRequest(method, URL, bytes.NewBuffer(bodyDataJSON))
	req.Close = true
	if err != nil {
		status = 500
		msg = err.Error()
		xeroLoggerFailed.Error("RequestXeroAPI > req: ", req)
		xeroLoggerFailed.Error("RequestXeroAPI > err: ", err)
	} else {
		// add query params
		if params != nil && len(params) > 0 {
			query := url.Values{}
			for k, v := range params {
				query.Add(k, v.(string))
			}
			req.URL.RawQuery = query.Encode()
		}
		// add headers
		if headers == nil {
			headers = make(map[string]interface{})
		}

		if len(isPDF) > 0 && isPDF[0] {
			headers["Accept"] = "application/pdf"
		} else {
			headers["Accept"] = "application/json"
			headers["Content-Type"] = "application/json"
		}
		headers["Authorization"] = "Bearer " + xeroConfig.AccessToken
		headers["Xero-tenant-id"] = xeroConfig.TenantID
		if headers != nil {
			for k, v := range headers {
				req.Header.Set(k, v.(string))
			}
		}
		client := &http.Client{}
		resp, err := client.Do(req)
		logger.Println("API URL - " + URL)
		if resp != nil {
			logger.Println("X-DayLimit-Remaining - " + resp.Header.Get("X-DayLimit-Remaining"))
			logger.Println("X-MinLimit-Remaining - " + resp.Header.Get("X-MinLimit-Remaining"))
			logger.Println("X-AppMinLimit-Remaining - " + resp.Header.Get("X-AppMinLimit-Remaining"))
		}
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			responsData = body
			//fmt.Println(string(responsData))
			//ioutil.WriteFile("file.pdf", responsData, 0666)
			msg = services.GetMessage(lang, "api.success")
			xeroLoggerSuccess.Info("RequestXeroAPI > req: ", req)
			xeroLoggerSuccess.Info("RequestXeroAPI > resp: ", resp)
			xeroLoggerSuccess.Info("RequestXeroAPI > CountXero: ", CountXero)

		} else {
			if resp != nil {
				var xeroLoggerBody []byte

				if resp.StatusCode != 429 {
					body, _ := ioutil.ReadAll(resp.Body)
					xeroLoggerBody = body
					json.Unmarshal([]byte(string(body)), &errRes)
					msg = errRes.Message
					logger.Println("Request Xero Error: ", msg)
				}

				status = resp.StatusCode
				if status == 400 {
					body, _ := ioutil.ReadAll(resp.Body)
					xeroLoggerBody = body
					json.Unmarshal([]byte(string(body)), &errRes)
					var (
						xeroMsgError          string
						xeroErrorPostElements = make([]models.XeroErrorPostElementResponse, 0)
					)
					if errRes.Elements != nil {
						objectJSON, errJSON := json.Marshal(errRes.Elements)
						if errJSON == nil {
							json.Unmarshal(objectJSON, &xeroErrorPostElements)
						}
						for _, element := range xeroErrorPostElements {
							for _, validationErrors := range element.ValidationErrors {
								xeroMsgError = GetStringWithWordBetween(xeroMsgError, validationErrors.Message)
							}
						}
					}
					if xeroMsgError != "" {
						msg = errRes.Message + "\n" + xeroMsgError
					} else {
						msg = errRes.Message
					}
				} else if status == 404 {
					body, _ := ioutil.ReadAll(resp.Body)
					xeroLoggerBody = body
					msg = string(body)
				} else if status == 429 {
					logger.Println("Request Xero Error: ", "Too Many Requests")
					body, _ := ioutil.ReadAll(resp.Body)
					xeroLoggerBody = body
				} else {
					body, _ := ioutil.ReadAll(resp.Body)
					xeroLoggerBody = body
					json.Unmarshal([]byte(string(body)), &errAuthenRes)
					msg = errAuthenRes.Title
				}
				if msg != nil {
					valMsg := fmt.Sprintf("%v", msg)
					if valMsg == "" {
						msg = resp.Status
					}
				}
				xeroLoggerFailed.Error("RequestXeroAPI > req: ", req)
				xeroLoggerFailed.Error("RequestXeroAPI > resp: ", resp)
				xeroLoggerFailed.Error("RequestXeroAPI > err: ", err)
				xeroLoggerFailed.Error("RequestXeroAPI > body: ", string(xeroLoggerBody))
				xeroLoggerFailed.Error("RequestXeroAPI > CountXero: ", CountXero)
			} else {
				status = 500
			}
			if err != nil {
				msg = err.Error()
			} else {
				if msg == nil {
					msg = services.GetMessage(lang, "api.request_api_error")
				}
			}
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}
	return status, msg, responsData
}

// ParseParamsQuery func
func ParseParamsQuery(c *gin.Context) map[string]interface{} {
	var (
		arrParamQuery map[string]interface{}
	)
	arrQuery := c.Request.URL.Query()
	if len(arrQuery) > 0 {
		arrParamQuery = make(map[string]interface{})
		for k, v := range arrQuery {
			if len(v) > 0 {
				arrParamQuery[k] = v[0]
			}
		}
	}
	return arrParamQuery
}

// ConvertTimeToXeroHeaderFilterUTC func
func ConvertTimeToXeroHeaderFilterUTC(time time.Time) string {
	return time.UTC().Format("2006-01-02T15:04:05")
}

// ConvertUpdatedDateUTCXeroToTime func
func ConvertUpdatedDateUTCXeroToTime(updateDateUTCXero string) (time.Time, error) {
	var (
		updateDateUTC time.Time
		err           error
	)
	arr := strings.Split(updateDateUTCXero, "(")
	if len(arr) >= 2 {
		arr = strings.Split(arr[1], "+")
		if len(arr) >= 1 {
			sTimeStamp := arr[0]
			iTimeStamp, eTimeStamp := strconv.ParseInt(sTimeStamp, 0, 64)
			if eTimeStamp == nil {
				timeT := time.Unix(0, iTimeStamp*1000000)
				updateDateUTC = timeT
			} else {
				err = eTimeStamp
			}
		} else {
			err = errors.New("isvalid")
		}
	} else {
		err = errors.New("isvalid")
	}
	return updateDateUTC, err
}
