package libs

import (
	"encoding/json"
	"jpapi/tig/v1/models"
	"os"
	"strconv"

	"github.com/joho/godotenv"
)

var mapRedisServiceConfig = make(map[string]models.RedisDatabaseServerResponse)
var mapDynamoServiceConfig = make(map[string]models.DynamoDatabaseServerResponse)

// GetRedisAddr func
func GetRedisAddr() string {
	godotenv.Load()
	return os.Getenv("REDIS_SERVER") + ":" + os.Getenv("REDIS_PORT")
}

// GetRedisPassword func
func GetRedisPassword() string {
	godotenv.Load()
	return os.Getenv("REDIS_PASSWORD")
}

// GetRedisDB func
func GetRedisDB(dbRedis string) int {
	godotenv.Load()
	db := 0
	sDB := os.Getenv(dbRedis)
	if sDB != "" {
		iDB, eDB := strconv.Atoi(sDB)
		if eDB == nil {
			db = iDB
		}
	}
	return db
}

// GetRedisConfigByCompanyID func
func GetRedisConfigByCompanyID(lang string, accountKey int, token string, companyID string) (int, interface{}, models.RedisDatabaseServerResponse) {
	//fmt.Printf("mapRedisServiceConfig: %+v\n", mapRedisServiceConfig)
	// find redis config in global variables
	for key, redisConfig := range mapRedisServiceConfig {
		if companyID == key {
			return 200, "", redisConfig
		}
	}
	//fmt.Println("Find Redis Config from Ree")
	var (
		redisConfig models.RedisDatabaseServerResponse
	)
	URL := os.Getenv("SERVER_REE") + "/" + "getredisconfigbycompanyid" + "/" + companyID
	statusRee, msgRee, dataRee := RequestAPIRee(lang, "GET", URL, nil, nil, nil)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(dataRee, &reeResponse)
		vRedisConfig, sRedisConfig := reeResponse["data"]
		if sRedisConfig {
			redisConfigJSON, errRedisConfigJSON := json.Marshal(vRedisConfig)
			if errRedisConfigJSON == nil {
				json.Unmarshal(redisConfigJSON, &redisConfig)
				// add redis config to global variable
				mapRedisServiceConfig[companyID] = redisConfig
			}
		}
	}
	return statusRee, msgRee, redisConfig
}

// GetDynamoConfigByCompanyID func
func GetDynamoConfigByCompanyID(lang string, accountKey int, token string, companyID string) (int, interface{}, models.DynamoDatabaseServerResponse) {
	//fmt.Printf("mapDynamoServiceConfig: %+v\n", mapDynamoServiceConfig)
	// find dynamo config in global variables
	for key, dynamoConfig := range mapDynamoServiceConfig {
		if companyID == key {
			return 200, "", dynamoConfig
		}
	}
	//fmt.Println("Find Dynamo Config from Ree")
	var (
		dynamoConfig models.DynamoDatabaseServerResponse
	)
	URL := os.Getenv("SERVER_REE") + "/" + "getdynamoconfigbycompanyid" + "/" + companyID
	statusRee, msgRee, dataRee := RequestAPIRee(lang, "GET", URL, nil, nil, nil)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(dataRee, &reeResponse)
		vDynamoConfig, sDynamoConfig := reeResponse["data"]
		if sDynamoConfig {
			dynamoConfigJSON, errDynamoConfigJSON := json.Marshal(vDynamoConfig)
			if errDynamoConfigJSON == nil {
				json.Unmarshal(dynamoConfigJSON, &dynamoConfig)
				// add dynamo config to global variable
				mapDynamoServiceConfig[companyID] = dynamoConfig
			}
		}
	}
	return statusRee, msgRee, dynamoConfig
}
