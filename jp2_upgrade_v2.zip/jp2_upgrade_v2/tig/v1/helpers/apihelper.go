package libs

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	rad "math/rand"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// GetStatusError func
func GetStatusError() int {
	return 400
}

// GetStatusPartial func
func GetStatusPartial() int {
	return 206
}

// GetStatusBadRequest func
func GetStatusBadRequest() int {
	return 400
}

// GetStatusServerError func
func GetStatusServerError() int {
	return 500
}

// GetStatusSuccess func
func GetStatusSuccess() int {
	return 200
}

// GetStatusNotFound func
func GetStatusNotFound() int {
	return 404
}

// GetStatusUnprocessableEntity func
func GetStatusUnprocessableEntity() int {
	return 422
}

// GenerateTokenAPI func
func GenerateTokenAPI() string {
	b := make([]byte, 32)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}

var arrSearchOriginals = []string{
	"((eq))",
	"((ne))",
	"((nl))",
	"((nn))",
	"((lk))",
	"((lt))",
	"((gt))",
	"((le))",
	"((ge))",
}
var arrSearchReplaces = []string{
	" = ",
	" <> ",
	" IS NULL ",
	" IS NOT NULL ",
	" LIKE ",
	" < ",
	" > ",
	" <= ",
	" >= ",
}

// APIResponseData func
func APIResponseData(responseData models.APIResponseData, c *gin.Context, status int) {
	var (
		requestHeader models.RequestHeader
	)
	ResponseType := c.Request.Header.Get("ResponseType")
	_, _, requestHeader = CheckHeaderInAPI(c)
	companyID := c.Request.Header.Get("companyid")
	if companyID != "" && !ExpiryDateIgnoreAPI(c) {
		lang := services.GetLanguageKey(c)
		_, _, _, _, _, expiredDate := CheckLicenseFunc(requestHeader, lang, companyID, "expired")
		c.Writer.Header().Set("Expiry-Date", expiredDate)
		c.Writer.Header().Set("access-control-expose-headers", "Expiry-Date")
	}
	if ResponseType == "application/xml" {
		c.XML(status, responseData)
	} else {
		c.JSON(status, responseData)
	}
}
func ExpiryDateIgnoreAPI(c *gin.Context) bool {

	arrAPI := []string{
		"notification/getunreadcount", "authorization/getauthrequestcount", "countrycodes", "plans", "getchatcount", "subscriptions", "xerointegrationstatus", "logo", "checklicense",
	}
	rootPath := os.Getenv("ROUTER_V1")
	path := c.Request.URL.Path
	for _, api := range arrAPI {
		ignoreAPI := rootPath + "/" + api
		if strings.Contains(path, ignoreAPI) {
			return true
		}
	}
	return false
}

// ResponseData func
func ResponseData(responseData gin.H, c *gin.Context, status int) {
	var (
		requestHeader models.RequestHeader
	)
	ResponseType := c.Request.Header.Get("ResponseType")
	_, _, requestHeader = CheckHeaderInAPI(c)
	companyID := c.Request.Header.Get("companyid")
	if companyID != "" && !ExpiryDateIgnoreAPI(c) {
		lang := services.GetLanguageKey(c)
		_, _, _, _, _, expiredDate := CheckLicenseFunc(requestHeader, lang, companyID, "expired")
		c.Writer.Header().Set("Expiry-Date", expiredDate)
		c.Writer.Header().Set("access-control-expose-headers", "Expiry-Date")
	}
	if ResponseType == "application/xml" {
		c.XML(status, responseData)
	} else {
		c.JSON(status, responseData)
	}
}

// GetTokenExpiredDays func
func GetTokenExpiredDays() int {
	vDays := os.Getenv("TOKEN_EXPIRED_DAYS")
	iDays, sDays := strconv.Atoi(vDays)
	if sDays == nil {
		return iDays
	}
	return 0
}

// GetTimeOutAmountWhenCallAPI func
func GetTimeOutAmountWhenCallAPI() int {
	timeOut := os.Getenv("TIME_OUT_CALL_API")
	iTimeOut, sTimeOut := strconv.Atoi(timeOut)
	if sTimeOut == nil && iTimeOut > 0 {
		return iTimeOut
	}
	return 30
}

// CheckHeaderInAPI func
func CheckHeaderInAPI(c *gin.Context) (int, gin.H, models.RequestHeader) {
	var (
		status = 200
		msg    string
	)
	paramsHeader := c.Request.Header.Get("security")
	responseHeader, errHeader := Decrypt(paramsHeader)
	if errHeader != nil {
		status = 400
		lang := services.GetLanguageKey(c)
		msg = services.GetMessage(lang, "api.header_request_error")
	}
	return status, gin.H{"status": status, "msg": msg}, responseHeader
}

// RemoveNullResonseData func
func RemoveNullResonseData(data models.APIResponseData) gin.H {
	var (
		mapData gin.H
	)
	bData, sData := json.Marshal(data)
	if sData == nil {
		json.Unmarshal(bData, &mapData)
	}
	if mapData["errors"] == nil {
		delete(mapData, "errors")
	}
	if mapData["msg"] == nil {
		delete(mapData, "msg")
	}
	if mapData["data"] == nil {
		delete(mapData, "data")
	}
	return mapData
}

// StringToArray func
func StringToArray(str string) []int {
	arrID := make([]int, 0)
	strID := strings.TrimSpace(str)
	listID := strings.Split(strID, ",")
	for i := range listID {
		statusID := (strings.TrimSpace(listID[i]))
		valIntID, errID := strconv.Atoi(statusID)
		if errID == nil {
			arrID = append(arrID, valIntID)
		}
	}
	return arrID
}

// StringToArrayString func
func StringToArrayString(str string) []string {
	arrID := make([]string, 0)
	strID := strings.TrimSpace(str)
	listID := strings.Split(strID, ",")
	for i := range listID {
		statusID := (strings.TrimSpace(listID[i]))
		arrID = append(arrID, statusID)
	}
	return arrID
}

// GenerateBusinessPartnerCode func
func GenerateBusinessPartnerCode() string {
	rad.Seed(time.Now().UnixNano())
	digits := "0123456789"
	specials := ""
	all := "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
		"" +
		digits + specials
	length := 8
	buf := make([]byte, length)
	buf[0] = digits[rad.Intn(len(digits))]
	for i := 1; i < length; i++ {
		buf[i] = all[rad.Intn(len(all))]
	}
	rad.Shuffle(len(buf), func(i, j int) {
		buf[i], buf[j] = buf[j], buf[i]
	})
	str := string(buf)
	return str
}

// GetValueOfUDF func
func GetValueOfUDF(requestHeader models.RequestHeader, tableName, udfFieldName, keyFieldName, dataType string, rootID int) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		udfFieldValue string
	)
	sqlQuery := `SELECT ` + udfFieldName + ` FROM ` + tableName + ` WHERE ` + keyFieldName + ` = ?`
	sqlDB, errSqlDB := db.DB()
	if errSqlDB == nil {
		row := sqlDB.QueryRow(sqlQuery, rootID)
		row.Scan(&udfFieldValue)
	}

	return udfFieldValue
}

// ConvertDataTypeUDFValue func
func ConvertDataTypeUDFValue(val, dataType string) interface{} {
	switch strings.ToLower(dataType) {
	case models.ClientTypeSTRING, models.ClientTypeDATE:
		return val
	case models.ClientTypeINTEGER:
		iVal, sVal := strconv.Atoi(val)
		if sVal == nil {
			return iVal
		}
		return val
	case models.ClientTypeDECIMAL:
		iVal, sVal := strconv.ParseFloat(val, 64)
		if sVal == nil {
			return iVal
		}
		return val
	case models.ClientTypeBOOLEAN:
		bVal, sVal := strconv.ParseBool(val)
		if sVal == nil {
			return bVal
		}
		return val
	}
	return val
}

// ConvertDataTypeUDFValueToApplySQL func
func ConvertDataTypeUDFValueToApplySQL(val, dataType string) interface{} {
	switch strings.ToLower(dataType) {
	case models.ClientTypeSTRING:
		return val
	case models.ClientTypeDATE, models.ClientTypeDATETIME:
		iVal, sVal := services.ConvertStringToDateTime(val)
		if sVal == nil {
			return iVal
		}
		return nil
	case models.ClientTypeINTEGER:
		iVal, sVal := strconv.Atoi(val)
		if sVal == nil {
			return iVal
		}
		return val
	case models.ClientTypeDECIMAL:
		iVal, sVal := strconv.ParseFloat(val, 64)
		if sVal == nil {
			return iVal
		}
		return val
	case models.ClientTypeBOOLEAN:
		bVal, sVal := strconv.ParseBool(val)
		if sVal == nil {
			return bVal
		}
		return val
	}
	return val
}

// GetArrayUDFResponseFromJSON func
func GetArrayUDFResponseFromJSON(JSONObject map[string]interface{}) []models.UDFResponse {
	var (
		res interface{}
	)
	arrUDFs := make([]models.UDFResponse, 0)
	_, res = services.ConvertJSONValueToVariable("UDFs", JSONObject)
	if res != nil {
		var (
			udfModels []models.UDFResponse
		)
		udfJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(udfJSON, &udfModels)
			if len(udfModels) > 0 {
				arrUDFs = udfModels
			}
		}
	}
	return arrUDFs
}

// UpdateToSQLByArrayUDFs func
func UpdateToSQLByArrayUDFs(requestHeader models.RequestHeader, arrUDFs []models.UDFResponse, keyFieldName string, rootID int) []error {
	var (
		errors []error
	)
	errors = make([]error, 0)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	for _, udf := range arrUDFs {
		udf.DataField = services.ApplyFormatForDataField(udf.DataField)
		if InArrayString(udf.DataType, []string{models.ClientTypeSTRING, models.ClientTypeDATE, models.ClientTypeDATETIME, models.ClientTypeINTEGER, models.ClientTypeDECIMAL, models.ClientTypeBOOLEAN}) {
			sql := `UPDATE ` + udf.TableNameObj + ` SET ` + udf.DataField + ` = ? WHERE ` + keyFieldName + ` = ?`
			var fieldValue interface{}
			var strValue string
			if udf.DataType == models.ClientTypeBOOLEAN {
				if udf.Value == nil {
					strValue = "false"
				} else {
					strValue = fmt.Sprintf("%v", udf.Value)
				}
			} else if udf.DataType == models.ClientTypeINTEGER {
				if udf.Value == nil || udf.Value == "" {
					strValue = "0"
				} else {
					strValue = fmt.Sprintf("%e\n", udf.Value)
				}
			} else if udf.DataType == models.ClientTypeDECIMAL {
				if udf.Value == nil || udf.Value == "" {
					strValue = "0"
				} else {
					strValue = fmt.Sprintf("%e\n", udf.Value)
				}
			} else if udf.DataType == models.ClientTypeDATE {
				if udf.Value == nil || udf.Value == "" {
					strValue = ""
				} else {
					strValue = fmt.Sprintf("%s", udf.Value)
				}
			} else if udf.DataType == models.ClientTypeDATETIME {
				if udf.Value == nil || udf.Value == "" {
					strValue = ""
				} else {
					strValue = fmt.Sprintf("%s", udf.Value)
				}
			} else {
				if udf.Value == nil {
					strValue = fmt.Sprintf("%s", "")
				} else {
					strValue = fmt.Sprintf("%s", udf.Value)
				}
			}
			fieldValue = ConvertDataTypeUDFValueToApplySQL(strValue, udf.DataType)
			err := db.Exec(sql, fieldValue, rootID).Error
			if err != nil {
				errors = append(errors, err)
			}
		}
	}
	return errors
}

// GetArrayQueryParamsUDFFields func
func GetArrayQueryParamsUDFFields(c *gin.Context, requestHeader models.RequestHeader, tableName string) map[string]models.UDFQueryResponse {
	var (
		arr       map[string]models.UDFQueryResponse
		udfModels []models.UDF
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	arr = make(map[string]models.UDFQueryResponse)
	db.Where("TableName = ?", tableName).Find(&udfModels)
	if len(udfModels) > 0 {
		for _, udf := range udfModels {
			arrQuery := c.Request.URL.Query()
			dataFieldFrom, dataFieldTo := GetDataFieldFromTo(udf.DataField)
			if CheckUDFDateTime(udf) {
				// Process for date, datetime
				for qName, v := range arrQuery {
					qName = strings.ToLower(qName)
					if InArrayString(qName, []string{dataFieldFrom, dataFieldTo}) {
						queryValueUDFs := make([]models.UDFQueryResponseValue, 0)
						var queryUDF models.UDFQueryResponse
						var queryValueUDF models.UDFQueryResponseValue
						var valQuery interface{}
						queryUDF.DataType = udf.DataType
						queryUDF.DateType = udf.DateType
						valQuery = v[0]
						queryValue := ""
						sValue := fmt.Sprintf("%v", v[0])
						vDateValue, errDateValue := ConvertStringToDateTime(sValue)
						if errDateValue == nil {
							queryValue = vDateValue.Format("2006-01-02 15:04:05")
						}
						if queryValue != "" {
							valQuery = queryValue
						}
						queryValueUDF.FieldName = qName
						queryValueUDF.Value = valQuery
						queryValueUDFs = arr[udf.DataField].Value
						queryValueUDFs = append(queryValueUDFs, queryValueUDF)
						queryUDF.Value = queryValueUDFs
						arr[udf.DataField] = queryUDF
					}
				}
			} else {
				// Process for # date, datetime
				for qName, v := range arrQuery {
					if strings.ToLower(udf.DataField) == strings.ToLower(qName) {
						qName = strings.ToLower(qName)
						queryValueUDFs := make([]models.UDFQueryResponseValue, 0)
						var queryUDF models.UDFQueryResponse
						var queryValueUDF models.UDFQueryResponseValue
						var valQuery interface{}
						queryUDF.DataType = udf.DataType
						queryUDF.DateType = udf.DateType
						valQuery = v[0]
						if udf.DataType == models.ClientTypeBOOLEAN {
							sValue := fmt.Sprintf("%v", v[0])
							vValue, errValue := strconv.ParseBool(sValue)
							if errValue == nil {
								valQuery = vValue
							}
						}
						queryValueUDF.FieldName = qName
						queryValueUDF.Value = valQuery
						queryValueUDFs = append(queryValueUDFs, queryValueUDF)
						queryUDF.Value = queryValueUDFs
						arr[udf.DataField] = queryUDF
					}
				}
			}
		}
	}

	return arr
}

// GetSortParamsFromURL func
func GetSortParamsFromURL(sorts string) map[string]string {
	responseSorts := make(map[string]string)
	arrSortObjects := strings.Split(sorts, ",")
	for _, obj := range arrSortObjects {
		arrSort := strings.Split(obj, "|")
		if len(arrSort) >= 2 {
			kSort := arrSort[0]
			vSort := arrSort[1]
			responseSorts[kSort] = vSort
		}
	}
	return responseSorts
}

// FilterBool func
func FilterBool(arrBool []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	for _, key := range arrBool {
		key = strings.TrimSpace(key)
		if key != "" {
			vKey, sKey := GetQueryParam(key, c)
			if sKey {
				bKey, eKey := strconv.ParseBool(vKey)
				if eKey == nil {
					db = db.Where(key+" = ?", bKey)
				}
			}
		}
	}
	return db
}

// FilterString func
func FilterString(arrString []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	for _, key := range arrString {
		key = strings.TrimSpace(key)
		if key != "" {
			vKey, sKey := GetQueryParam(key, c)
			if sKey {
				db = db.Where(key+" LIKE ?", "%"+vKey+"%")
			}
		}
	}
	return db
}

// FilterInteger func
func FilterInteger(arrBool []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	for _, key := range arrBool {
		key = strings.TrimSpace(key)
		if key != "" {
			vKey, sKey := GetQueryParam(key, c)
			if sKey {
				dbOperator, value := GetSearchOperator(vKey, arrSearchOriginals, arrSearchReplaces)
				iKey, eKey := strconv.Atoi(value)
				if eKey == nil {
					db = db.Where(key+" "+dbOperator+" ?", iKey)
				}
			}
		}
	}
	return db
}

// FilterFloat func
func FilterFloat(arrBool []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	for _, key := range arrBool {
		key = strings.TrimSpace(key)
		if key != "" {
			vKey, sKey := GetQueryParam(key, c)
			if sKey {
				dbOperator, value := GetSearchOperator(vKey, arrSearchOriginals, arrSearchReplaces)
				iKey, eKey := strconv.ParseFloat(value, 64)
				if eKey == nil {
					db = db.Where(key+" "+dbOperator+" ?", iKey)
				}
			}
		}
	}
	return db
}

// FilterDateTime func
func FilterDateTime(arrDateTime []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	format := "2006-01-02"
	for _, key := range arrDateTime {
		key = strings.TrimSpace(key)
		if key != "" {
			fromDateKey := key + "From"
			toDateKey := key + "To"
			vFromDate, sFromDate := GetQueryParam(fromDateKey, c)
			if sFromDate {
				dFromDate, errFromDate := ConvertStringToDateTime(vFromDate)
				if errFromDate == nil {
					vFromDate = dFromDate.Format(format)
				}
			}
			vToDate, sToDate := GetQueryParam(toDateKey, c)
			if sToDate {
				dToDate, errToDate := ConvertStringToDateTime(vToDate)
				if errToDate == nil {
					vToDate = dToDate.Format(format)
				}
			}
			if sFromDate && sToDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') >= ? AND DATE_FORMAT("+key+", '%Y-%m-%d') <= ?", vFromDate, vToDate)
			} else if sFromDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') >= ?", vFromDate)
			} else if sToDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') <= ?", vToDate)
			}
		}
	}
	return db
}

func FilterDateTimeWithSpaceInKey(arrDateTime []string, db *gorm.DB, c *gin.Context) *gorm.DB {
	format := "2006-01-02"
	for _, key := range arrDateTime {
		key = strings.TrimSpace(key)
		if key != "" {
			fromDateKey := key + "_From"
			toDateKey := key + "_To"
			vFromDate, sFromDate := GetQueryParam(fromDateKey, c)
			if sFromDate {
				dFromDate, errFromDate := ConvertStringToDateTime(vFromDate)
				if errFromDate == nil {
					vFromDate = dFromDate.Format(format)
				}
			}
			vToDate, sToDate := GetQueryParam(toDateKey, c)
			if sToDate {
				dToDate, errToDate := ConvertStringToDateTime(vToDate)
				if errToDate == nil {
					vToDate = dToDate.Format(format)
				}
			}
			if sFromDate && sToDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') >= ? AND DATE_FORMAT("+key+", '%Y-%m-%d') <= ?", vFromDate, vToDate)
			} else if sFromDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') >= ?", vFromDate)
			} else if sToDate {
				db = db.Where("DATE_FORMAT("+key+", '%Y-%m-%d') <= ?", vToDate)
			}
		}
	}
	return db
}

// FilterUDFs func
func FilterUDFs(arrQueries map[string]models.UDFQueryResponse, db *gorm.DB) *gorm.DB {
	for k, q := range arrQueries {
		if InArrayString(q.DataType, []string{models.ClientTypeDATE, models.ClientTypeDATETIME}) {
			if len(q.Value) > 0 {
				timeFormat := ""
				switch q.DateType {
				case models.ClientTypeTIME:
					{
						timeFormat = "%H:%i:%s"
					}
				case models.ClientTypeDATE:
					{
						timeFormat = "%Y-%m-%d"
					}
				case models.ClientTypeDATETIME:
					{
						timeFormat = "%Y-%m-%d %H:%i:%s"
					}
				}
				if timeFormat != "" {
					dataFieldFrom, dataFieldTo := GetDataFieldFromTo(k)
					var timeFrom, timeTo interface{}
					for _, v := range q.Value {
						if v.FieldName == dataFieldFrom {
							timeFrom = v.Value
						}
						if v.FieldName == dataFieldTo {
							timeTo = v.Value
						}
					}
					if timeFrom != nil && timeTo != nil {
						db = db.Where("DATE_FORMAT("+k+", '"+timeFormat+"') >= DATE_FORMAT(?, '"+timeFormat+"') AND DATE_FORMAT("+k+", '"+timeFormat+"') <= DATE_FORMAT(?, '"+timeFormat+"')", timeFrom, timeTo)
					} else if timeFrom != nil {
						db = db.Where("DATE_FORMAT("+k+", '"+timeFormat+"') >= DATE_FORMAT(?, '"+timeFormat+"')", timeFrom)
					} else if timeTo != nil {
						db = db.Where("DATE_FORMAT("+k+", '"+timeFormat+"') <= DATE_FORMAT(?, '"+timeFormat+"')", timeTo)
					}
				}
			}
		} else {
			if len(q.Value) > 0 {
				if q.DataType != models.ClientTypeSTRING {
					db = db.Where(k+" = ?", q.Value[0].Value)
				} else {
					db = db.Where(k+" LIKE ?", "%"+q.Value[0].Value.(string)+"%")
				}
			}
		}
	}
	return db
}

// ConvertStringToDateTime func
func ConvertStringToDateTime(val string) (time.Time, error) {
	var (
		err      error
		dateTime time.Time
	)
	dateTime, err = time.Parse("2006-01-02T15:04:05Z", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("20060102T15:04:05Z", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("2006-01-02T15:04:05-0700", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("20060102T15:04:05-0700", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("2006-01-02T15:04:05-07:00", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("20060102T15:04:05-07:00", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("2006-01-02 15:04:05", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("2006-01-02 15:04", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("20060102 15:04:05", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("2006-01-02", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("20060102", val)
	if err == nil {
		return dateTime, err
	}
	dateTime, err = time.Parse("15:04:05", val)
	if err == nil {
		return dateTime, err
	}
	return dateTime, err
}

//GetArrayOnBothArray func
func GetArrayOnBothArray(arrRoot []string, arrSecond []string) []string {
	arrRes := make([]string, 0)
	for _, keyRoot := range arrRoot {
		for _, keySecond := range arrSecond {
			if keyRoot == keySecond {
				if !InArrayString(keyRoot, arrRes) {
					arrRes = append(arrRes, keyRoot)
				}
			}
		}
	}
	return arrRes
}

// GetDataFieldFromTo func
func GetDataFieldFromTo(dataField string) (string, string) {
	dataField = strings.ToLower(dataField)
	return dataField + "_from", dataField + "_to"
}

// CheckUDFDateTime func
func CheckUDFDateTime(udf models.UDF) bool {
	if udf.Widget == "dxDateBox" && InArrayString(udf.DateType, GetArrayDateType()) {
		return true
	}
	return false
}

// GetArrayDateType func
func GetArrayDateType() []string {
	return []string{models.ClientTypeTIME, models.ClientTypeDATE, models.ClientTypeDATETIME}
}

// SortDataOnParam func
func SortDataOnParam(db *gorm.DB, c *gin.Context, skipKeys ...string) *gorm.DB {
	vSort, sSort := GetQueryParam("sort", c)
	if sSort {
		arrSorts := GetSortParamsFromURL(vSort)
		for fieldSortObj, vSortObj := range arrSorts {
			fieldSortObj = strings.Replace(fieldSortObj, "UDF.", "", -1)
			if !InArrayString(fieldSortObj, skipKeys) {
				strSort := fieldSortObj + " " + vSortObj
				db = db.Order(strSort)
			}
		}
	}
	return db
}

// GetSortValueFromKey func
func GetSortValueFromKey(c *gin.Context, sortKey string) string {
	vSort, sSort := GetQueryParam("sort", c)
	if sSort {
		arrSorts := GetSortParamsFromURL(vSort)
		for fieldSortObj, vSortObj := range arrSorts {
			if fieldSortObj == sortKey {
				return vSortObj
			}
		}
	}
	return ""
}

// GetStringWithWordBetween func
func GetStringWithWordBetween(msgRoot, newMsg string) string {
	if newMsg == "" {
		return msgRoot
	}
	if msgRoot == "" {
		msgRoot = newMsg
	} else {
		msgRoot = msgRoot + "\n" + newMsg
	}
	return msgRoot
}

// Isset func
func Isset(arr []int, index int) bool {
	return (len(arr) > index)
}

// GetEnum func
func GetEnum(requestHeader models.RequestHeader, status int, fieldName string, lang string) (string, string) {
	var (
		enumModel models.Enumerator
	)
	caption := ""
	icon := ""
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFind := db.Where("FieldName = ? AND Status = ?", fieldName, status).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&enumModel)
	if resultFind.RowsAffected > 0 {
		if enumModel.TranslationKey != "" && enumModel.TranslationKey != services.GetMessage(lang, enumModel.TranslationKey) {
			caption = services.GetMessage(lang, enumModel.TranslationKey)
		} else {
			caption = enumModel.Caption
		}
		icon = enumModel.Icon
	}
	return caption, icon
}

// GetCurrentUser func
func GetCurrentUser(requestHeader models.RequestHeader, accountKey int) models.User {
	var (
		userModel models.User
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	return userModel
}

// SubtractTimeInSeconds func
func SubtractTimeInSeconds(time1, time2 time.Time) int {
	diff := time2.Sub(time1).Seconds()
	return int(diff)
}

// SubtractTimeInMinutes func
func SubtractTimeInMinutes(time1, time2 time.Time) int {
	diff := time2.Sub(time1).Minutes()
	return int(diff)
}

// IntJoin func
func IntJoin(arr []int) string {
	var (
		result string
		sArr   = make([]string, 0)
	)
	if len(arr) > 0 {
		for _, v := range arr {
			sArr = append(sArr, strconv.Itoa(v))
		}
	}
	if len(sArr) > 0 {
		result = strings.Join(sArr, ",")
	}
	return result
}

// GenerateUUID func
func GenerateUUID() string {
	return uuid.New().String()
}

// GenerateToken func
func GenerateToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}

// EncryptEstimate func
func EncryptEstimate(estimateEncrypt models.EstimateEncrypt) (string, error) {
	var (
		encryptData string
		err         error
	)
	estimateEncryptJSON, err := json.Marshal(estimateEncrypt)
	if err != nil {
		return encryptData, err
	}
	key := []byte(os.Getenv("SERCURITY_KEY"))
	c, err := aes.NewCipher(key)
	if err != nil {
		return encryptData, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return encryptData, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return encryptData, err
	}
	estimateEncryptData := gcm.Seal(nonce, nonce, estimateEncryptJSON, nil)
	encryptData = base64.RawURLEncoding.EncodeToString(estimateEncryptData)
	return encryptData, err
}

// DecryptEstimate func
func DecryptEstimate(encryptData string) (models.EstimateEncrypt, error) {
	var (
		estimateEncrypt models.EstimateEncrypt
		err             error
		resultByte      []byte
	)

	cipherByte, err := base64.RawURLEncoding.DecodeString(encryptData)
	if err != nil {
		return estimateEncrypt, err
	}
	key := []byte(os.Getenv("SERCURITY_KEY"))
	c, err := aes.NewCipher(key)
	if err != nil {
		return estimateEncrypt, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return estimateEncrypt, err
	}
	nonceSize := gcm.NonceSize()
	if len(cipherByte) < nonceSize {
		return estimateEncrypt, errors.New("TEXT_TOO_SHORT")
	}
	nonce, cipherByte := cipherByte[:nonceSize], cipherByte[nonceSize:]
	resultByte, err = gcm.Open(nil, nonce, cipherByte, nil)
	resultStr := string(resultByte)
	json.Unmarshal([]byte((resultStr)), &estimateEncrypt)
	return estimateEncrypt, err
}

// StrReplaceWithArray func
func StrReplaceWithArray(str string, original []string, replacement []string) string {
	for i, toreplace := range original {
		r := strings.NewReplacer(toreplace, replacement[i])
		str = r.Replace(str)
	}
	return str
}

// StrReplaceSearchWithArray func
func GetSearchOperator(str string, original []string, replacement []string) (string, string) {
	defaultOperator := "="
	value := str
	for i, toreplace := range original {
		if strings.Contains(str, toreplace) {
			defaultOperator = replacement[i]
			value = strings.Replace(str, toreplace, "", -1)
			break
		}
	}
	return defaultOperator, value
}

// RemoveHTMLTag func
func RemoveHTMLTag(str string) string {
	var regex = `<.*?>`
	reg := regexp.MustCompile(regex)
	return reg.ReplaceAllString(str, "")
}

// RemoveDefaultFieldsOnDynamicGenerateTable func
func RemoveDefaultFieldsOnDynamicGenerateTable(colName string) bool {
	if InArrayString(colName, []string{"CreatedBy", "CreatedDate", "IsArchived", "IsAudit", "IsDeleted", "ModifiedBy", "ModifiedDate"}) {
		return true
	}
	return false
}

// ConvertArrayStringToInt func
func ConvertArrayStringToInt(sa []string) ([]int, error) {
	si := make([]int, 0, len(sa))
	for _, a := range sa {
		i, err := strconv.Atoi(a)
		if err != nil {
			return si, err
		}
		si = append(si, i)
	}
	return si, nil
}

// RequestURL func
func RequestURL(url string) int {
	var status = 200
	req, errRequest := http.NewRequest("GET", url, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		_, err := client.Do(req)
		if err != nil {
			status = 404
		}
	}
	return status
}

// GetTrackAndTrace func
func GetTrackAndTrace(token string) string {
	trackAndTraceLink := os.Getenv("TRACK_AND_TRACE_LINK")
	trackAndTraceLink = strings.TrimSuffix(trackAndTraceLink, "/")
	return trackAndTraceLink + "/" + token
}

// ConvertTrackAndTraceTokenToToken func
func ConvertTrackAndTraceTokenToToken(objToken models.TrackAndTraceToken) (string, error) {
	var (
		err   error
		token string
	)
	securityJSON, _ := json.Marshal(objToken)
	key := []byte(os.Getenv("SERCURITY_KEY"))
	encryptSecurityData, errEncrypt := EncryptJSON(securityJSON, key)
	if errEncrypt == nil {
		token = base64.RawURLEncoding.EncodeToString(encryptSecurityData)
	} else {
		err = errEncrypt
	}
	return token, err
}

// ConvertTokenToTrackAndTraceToken func
func ConvertTokenToTrackAndTraceToken(token string) (models.TrackAndTraceToken, error) {
	var (
		err      error
		objToken models.TrackAndTraceToken
	)
	decodeByte, _ := base64.RawURLEncoding.DecodeString(token)
	key := []byte(os.Getenv("SERCURITY_KEY"))
	jsonByte, errDec := DecryptJSON(decodeByte, key)
	if errDec == nil {
		json.Unmarshal(jsonByte, &objToken)
	} else {
		err = errDec
	}
	return objToken, err
}

// EncryptJSON func
func EncryptJSON(plaintext []byte, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

// DecryptJSON func
func DecryptJSON(ciphertext []byte, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}
	nonceSize := gcm.NonceSize()
	if len(ciphertext) < nonceSize {
		return nil, errors.New("TEXT_TOO_SHORT")
	}
	nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
	return gcm.Open(nil, nonce, ciphertext, nil)
}

// MappingDateFormat func
func MappingDateFormat(val string) string {
	var (
		layout = "2006-01-02"
	)
	switch val {
	case "yyyy-MM-dd":
		layout = "2006-01-02"
		break
	case "yyyy/MM/dd":
		layout = "2006/01/02"
		break
	case "dd-MM-yyyy":
		layout = "02-01-2006"
		break
	case "dd/MM/yyyy":
		layout = "02/01/2006"
		break
	case "MM-dd-yyyy":
		layout = "01-02-2006"
		break
	case "MM/dd/yyyy":
		layout = "01/02/2006"
		break
	}
	return layout
}

// MappingTimeFormat func
func MappingTimeFormat(val string) string {
	var (
		layout = "15:04:05"
	)
	switch val {
	case "HH:mm:ss":
		layout = "15:04:05"
		break
	case "HH:mm:ss SS":
		layout = "15:04:05 PM"
		break
	case "HH:mm":
		layout = "15:04"
		break
	case "HH:mm SS":
		layout = "15:04 PM"
		break
	}

	return layout
}

// CheckLicenseFunc func
func CheckLicenseFunc(requestHeader models.RequestHeader, lang string, companyID string, licenseType string) (int, interface{}, bool, string, int, string) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		status         = 200
		msg            interface{}
		isLicense      = false
		msgData        string
		totalCount     int64
		expiredDateRes string
	)
	hasLicense, license, err := FindLicenseInfo(companyID)
	if hasLicense && err == nil {
		switch licenseType {
		case "job":
			var (
				jobModels []models.Job
			)
			currentTime := time.Now()
			// excluded IsDeleted
			db.Where("IFNULL(IsDeleted, 0) <> 1").Where("DATE_FORMAT(JobDate,'%Y-%m') = DATE_FORMAT(?,'%Y-%m')", currentTime).Where("IsJob = 1").Find(&jobModels).Count(&totalCount)
			fmt.Println("totalCount: ", totalCount)
			if license.MaxMonthlyJobs <= int(totalCount) {
				isLicense = false
				msgData = services.GetMessage(lang, "api.reached_maximum_monthlyjob", strconv.Itoa(license.MaxMonthlyJobs))
			} else {
				isLicense = true
			}
		case "form":
			var (
				draftDynamicForm []models.DraftDynamicForm
			)
			// excluded IsDeleted
			db.Where("IFNULL(IsDeleted, 0) <> 1").Find(&draftDynamicForm).Count(&totalCount)
			fmt.Println("totalCount: ", totalCount)
			if license.MaxDynamicForm <= int(totalCount) {
				isLicense = false
				msgData = services.GetMessage(lang, "api.reached_maximum_dynamicform", strconv.Itoa(license.MaxDynamicForm))
			} else {
				isLicense = true
			}
		case "resource":
			var (
				resourceModels []models.Resource
			)
			// excluded IsDeleted
			db.Where("IFNULL(IsDeleted, 0) <> 1").Find(&resourceModels).Count(&totalCount)
			fmt.Println("totalCount: ", totalCount)
			if int64(license.ResourceQuantity) <= totalCount {
				isLicense = false
				msgData = services.GetMessage(lang, "api.reached_maximum_resource", strconv.Itoa(int(license.ResourceQuantity)))
			} else {
				isLicense = true
			}
		case "user":
			var (
				userModels []models.User
			)
			// excluded IsDeleted
			db.Where("IFNULL(IsDeleted, 0) <> 1").Find(&userModels).Count(&totalCount)
			fmt.Println("totalCount: ", totalCount)
			if int64(license.MaxUser) <= totalCount {
				isLicense = false
				msgData = services.GetMessage(lang, "api.reached_maximum_user", strconv.Itoa(int(license.MaxUser)))
			} else {
				isLicense = true
			}
		case "smartscheduling":
			isLicense = license.IsSmartScheduling
			if !isLicense {
				msgData = services.GetMessage(lang, "api.reached_maximum_smartscheduling", strconv.Itoa(int(license.SmartSchedulingQuantity)))
			}
			totalCount = int64(license.SmartSchedulingQuantity)
		case "additionaldevicelicense":
			var (
				deviceModels []models.Device
			)
			// excluded IsDeleted
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&deviceModels).Count(&totalCount)
			fmt.Println("totalCount: ", totalCount)
			maxDevice := license.ResourceQuantity + license.AdditionalDeviceLicenseQuantity
			if int64(maxDevice) <= totalCount {
				isLicense = false
				msgData = services.GetMessage(lang, "api.reached_maximum_device", strconv.Itoa(int(license.AdditionalDeviceLicenseQuantity)))
			} else {
				isLicense = true
			}
			totalCount = int64(license.AdditionalDeviceLicenseQuantity)
		case "xero":
			isLicense = license.IsXero
			totalCount = 0
		case "microsoftdynamic":
			isLicense = license.IsMicrosoftDynamic
			totalCount = 0
		case "livechat":
			isLicense = license.IsLiveChat
			totalCount = 0
		case "replayroutes":
			isLicense = license.IsReplayRoutes
			totalCount = 0
			msgData = ""
		case "reportdesigner":
			isLicense = license.IsReportDesigner
			totalCount = 0
		case "expired":
			expired := true
			expiryDate := license.ExpiryDate
			dExpiryDate, errExpiryDate := services.ConvertStringToDateTime(expiryDate)
			if errExpiryDate == nil {
				if dExpiryDate.Unix() > time.Now().UTC().Unix() {
					expired = false
					hours := dExpiryDate.Sub(time.Now().UTC()).Hours()
					totalCount = int64(hours / 24)
				}
			}
			isLicense = !expired
			expiredDateRes = dExpiryDate.Format(MYSQLDATE)
		}
	} else {
		if err != nil {
			status = 500
			msg = err.Error()
		} else {
			status = 404
			msg = services.GetMessage(lang, "api.not_found_license_of_comapny", companyID)
		}
	}
	return status, msg, isLicense, msgData, int(totalCount), expiredDateRes
}
