package libs

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	smslogs "jpapi/tig/v1/logs/sms"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

var mapSMSServiceConfig = make(map[int]models.SMSServiceConfig)

// IncreaseSMSFlag func
func IncreaseSMSFlag(accountKey int) {
	var (
		smsLogger = smslogs.SMSLogger
	)
	URL := os.Getenv("SERVER_REE") + "/increasesmsflag/" + strconv.Itoa(accountKey)
	req, errRequest := http.NewRequest("POST", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			smsLogger.Printf("REE: IncreaseSMSFlag: %+v", reeResponse)
		} else {
			smsLogger.Printf("REE > IncreaseSMSFlag > err", err.Error())
		}
	} else {
		smsLogger.Printf("REE > IncreaseSMSFlag > errRequest", errRequest.Error())
	}
}

// GetSMSService func
func GetSMSService(accountKey int) models.SMSServiceConfig {
	//fmt.Printf("mapSMSServiceConfig: %+v\n", mapSMSServiceConfig)
	// find sms config in global variables
	for key, smsConfig := range mapSMSServiceConfig {
		if accountKey == key {
			return smsConfig
		}
	}
	//fmt.Println("Find SMS Config from Ree")
	var (
		smsServiceConfig models.SMSServiceConfig
	)
	URL := os.Getenv("SERVER_REE") + "/getsmsservice/" + strconv.Itoa(accountKey)
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			vSMSService, sSMSService := reeResponse["data"]
			if sSMSService {
				SMSServiceJSON, errSMSServiceJSON := json.Marshal(vSMSService)
				if errSMSServiceJSON == nil {
					json.Unmarshal(SMSServiceJSON, &smsServiceConfig)
					// add sms config to global variable
					mapSMSServiceConfig[accountKey] = smsServiceConfig
				}
			}
		}
	}
	return smsServiceConfig
}

// SendSMSService func
func SendSMSService(accountKey int, lang string, contentSMS string, numberSMS string, smsServiceConfig models.SMSServiceConfig) (int, string) {
	var (
		statusSendSMS = GetStatusSuccess()
		msgSendSMS    string
		bodyDataJSON  []byte
	)

	if smsServiceConfig.SMSKey == "" {
		statusSendSMS = 422
		msgSendSMS = GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_key_required"))
	}
	if smsServiceConfig.SMSPassword == "" {
		statusSendSMS = 422
		msgSendSMS = GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_password_required"))
	}
	if smsServiceConfig.SMSURL == "" {
		statusSendSMS = 422
		msgSendSMS = GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_url_required"))
	}

	if numberSMS == "" {
		statusSendSMS = 422
		msgSendSMS = GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.phone_number_required"))
	}
	if contentSMS == "" {
		statusSendSMS = 422
		msgSendSMS = GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.phone_message_required"))
	}

	if statusSendSMS == 200 {
		// @TODO replace Enter (\n) in TextEditor by \\r
		/* contentSMS = strings.Replace(contentSMS, "\r", "\\r", -1)
		contentSMS = strings.Replace(contentSMS, "\n", "\\r", -1)
		contentSMS = strings.Replace(contentSMS, "\\\r", "\\r", -1) */

		numberSMS = strings.TrimSpace(numberSMS)
		numberSMS = strings.Replace(numberSMS, " ", "", -1)

		bodyContent := make(map[string][]models.MessageSMSPOST)
		messagesBody := make([]models.MessageSMSPOST, 0)

		var messageBody models.MessageSMSPOST
		messageBody.Content = contentSMS
		messageBody.DestinationNumber = numberSMS
		messageBody.Format = "SMS"
		messageBody.DeliveryReport = true
		messagesBody = append(messagesBody, messageBody)
		bodyContent["messages"] = messagesBody
		vBodyDataJSON, sBodyDataJSON := json.Marshal(bodyContent)
		if sBodyDataJSON == nil {
			bodyDataJSON = vBodyDataJSON
			req, err := http.NewRequest("POST", smsServiceConfig.SMSURL, bytes.NewBuffer(bodyDataJSON))
			req.SetBasicAuth(smsServiceConfig.SMSKey, smsServiceConfig.SMSPassword)
			req.Header.Set("Content-Type", "application/json")
			req.Close = true
			client := &http.Client{}
			resp, err := client.Do(req)
			//fmt.Println("bodyDataJSON: ", string(bodyDataJSON))
			/* fmt.Println("bodyDataJSON: ", string(bodyDataJSON))
			fmt.Println("req: ", req)
			fmt.Println("err: ", err)
			fmt.Println("resp: ", resp) */
			if err != nil {
				statusSendSMS = 500
				msgSendSMS = err.Error()
			} else {
				body, _ := ioutil.ReadAll(resp.Body)
				if resp.StatusCode == 400 {
					var messages map[string]interface{}
					json.Unmarshal([]byte(string(body)), &messages)
					var resSMS interface{}
					resSMS = messages["message"]
					msgSendSMS = fmt.Sprintf("%v", resSMS)
					//fmt.Println("messages: ", msgSendSMS)
				} else {
					var messages models.MessagesSMSResponse

					json.Unmarshal([]byte(string(body)), &messages)
					var resSMS interface{}
					if len(messages.Messages) <= 0 {
						msgSendSMS = resp.Status
					} else {
						resSMS = messages.Messages[0]["status"]
						msgSendSMS = fmt.Sprintf("%v", resSMS)
					}
					//fmt.Println("messages: ", messages)
				}
				statusSendSMS = resp.StatusCode
				if statusSendSMS == 202 {
					statusSendSMS = 200
				}
				if statusSendSMS == 200 {
					// @TODO increase send sms flag +1
				}
			}
		} else {
			statusSendSMS = 500
			msgSendSMS = sBodyDataJSON.Error()
		}

		// alway increase sms flag on ree
		IncreaseSMSFlag(accountKey)
	}
	return statusSendSMS, msgSendSMS
}

// GetPhoneNumberAndMessageContentOfCustomer func
func GetPhoneNumberAndMessageContentOfCustomer(requestHeader models.RequestHeader, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) (string, string) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		phoneNumber     string
		messageContent  string
		businessPartner models.BusinessPartner
	)
	messageContent = smsTemplateModel.Body
	resultFindBusinessPartner := db.Preload(
		"Phones",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		models.BusinessPartner{}.TableName(),
	).Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
	if resultFindBusinessPartner.RowsAffected > 0 {
		for _, phone := range businessPartner.Phones {
			// @TODO need condition to get phone number
			// PhoneTypeID = 1 => Mobile
			if phone.PhoneTypeID == 1 {
				phoneNumber = phone.CountryCode + strings.TrimLeft(phone.PhoneNumber, "0")
			}
			break
		}
		if messageContent != "" {
			messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
		}
	}
	return phoneNumber, messageContent
}

// GetPhoneNumberAndMessageContentOfJob func
func GetPhoneNumberAndMessageContentOfJob(requestHeader models.RequestHeader, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) (string, string) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		phoneNumber     string
		messageContent  string
		businessPartner models.BusinessPartner
	)
	phoneNumber = jobModel.CountryCode + strings.TrimLeft(jobModel.ContactPhoneNumber, "0")
	messageContent = smsTemplateModel.Body
	resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
	if resultFindBusinessPartner.RowsAffected > 0 {
		if messageContent != "" {
			messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
		}
	}
	return phoneNumber, messageContent
}

// GetPhoneNumberAndMessageContentOfTask func
func GetPhoneNumberAndMessageContentOfTask(requestHeader models.RequestHeader, lang string, smsTemplateModel models.SMSTemplate, jobID int, jobTaskType int) (string, string) {
	var (
		phoneNumber    string
		messageContent string
		jobModel       models.Job
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Preload(
		"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where(
		"JobID = ?", jobID,
	).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&jobModel)

	switch jobTaskType {
	case 1:
		{
			if jobModel.JobOnSite != nil {
				jobOnSiteModel := *jobModel.JobOnSite
				phoneNumber = jobOnSiteModel.CountryCode + strings.TrimLeft(jobOnSiteModel.ContactPhoneNumber, "0")
				messageContent = smsTemplateModel.Body
				var (
					businessPartner models.BusinessPartner
				)
				resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobOnSiteModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBusinessPartner.RowsAffected > 0 {
					if messageContent != "" {
						messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
					}
				}
			}
		}
	case 2:
		{
			if jobModel.JobPickup != nil {
				jobPickupModel := *jobModel.JobPickup
				phoneNumber = jobPickupModel.CountryCode + strings.TrimLeft(jobPickupModel.ContactPhoneNumber, "0")
				messageContent = smsTemplateModel.Body
				var (
					businessPartner models.BusinessPartner
				)
				resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobPickupModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBusinessPartner.RowsAffected > 0 {
					if messageContent != "" {
						messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
					}
				}
			}
		}
	case 3:
		{
			if jobModel.JobDelivery != nil {
				jobDeliveryModel := *jobModel.JobDelivery
				phoneNumber = jobDeliveryModel.CountryCode + strings.TrimLeft(jobDeliveryModel.ContactPhoneNumber, "0")
				messageContent = smsTemplateModel.Body
				var (
					businessPartner models.BusinessPartner
				)
				resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobDeliveryModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBusinessPartner.RowsAffected > 0 {
					if messageContent != "" {
						messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
					}
				}
			}
		}
	case 7:
		{
			if jobModel.JobResourcePickUp != nil {
				jobResourcePickupModel := *jobModel.JobResourcePickUp
				phoneNumber = jobResourcePickupModel.CountryCode + strings.TrimLeft(jobResourcePickupModel.ContactPhoneNumber, "0")
				messageContent = smsTemplateModel.Body
				var (
					businessPartner models.BusinessPartner
				)
				resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobResourcePickupModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBusinessPartner.RowsAffected > 0 {
					if messageContent != "" {
						messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
					}
				}
			}
		}
	case 8:
		{
			if jobModel.JobResourceDelivery != nil {
				jobResourceDeliveryModel := *jobModel.JobResourceDelivery
				phoneNumber = jobResourceDeliveryModel.CountryCode + strings.TrimLeft(jobResourceDeliveryModel.ContactPhoneNumber, "0")
				messageContent = smsTemplateModel.Body
				var (
					businessPartner models.BusinessPartner
				)
				resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobResourceDeliveryModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBusinessPartner.RowsAffected > 0 {
					if messageContent != "" {
						messageContent = ReplaceTemplateVariableByBusinessPartner(requestHeader, smsTemplateModel, businessPartner, messageContent)
					}
				}
			}
		}
	}
	return phoneNumber, messageContent
}

// GetPhoneNumberAndMessageContentOfManagers func
func GetPhoneNumberAndMessageContentOfManagers(requestHeader models.RequestHeader, smsTemplateModel models.SMSTemplate, jobModel models.Job) []models.PhoneAndMessageOfManager {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		userModels                []models.User
		phoneAndMessageOfManagers = make([]models.PhoneAndMessageOfManager, 0)
	)
	db.Where("LocationID = ? AND IsManager = 1", jobModel.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&userModels)
	messageContent := smsTemplateModel.Body
	for _, user := range userModels {
		var (
			phoneNumberByUser    string
			messageContentByUser string
		)
		phoneNumberByUser = user.CountryCode + strings.TrimLeft(user.PhoneNumber, "0")
		messageContentByUser = ReplaceTemplateVariableByUser(requestHeader, smsTemplateModel, user, messageContent)
		var phoneAndMessageOfManager models.PhoneAndMessageOfManager
		phoneAndMessageOfManager.PhoneNumber = phoneNumberByUser
		phoneAndMessageOfManager.MessageBody = messageContentByUser
		phoneAndMessageOfManager.User = user
		phoneAndMessageOfManagers = append(phoneAndMessageOfManagers, phoneAndMessageOfManager)
	}
	return phoneAndMessageOfManagers
}

// ReplaceTemplateVariableByBusinessPartner func
func ReplaceTemplateVariableByBusinessPartner(requestHeader models.RequestHeader, smsTemplateModel models.SMSTemplate, businessPartner models.BusinessPartner, messageContent string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		keyModels       []models.KeyTemplateVariable
		arrBodyKeys     = make([]string, 0)
		arrBodyContents = make([]string, 0)
	)
	//db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&keyModels)
	db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Find(&keyModels)
	for _, keyVar := range keyModels {
		switch keyVar.DataField {
		case "FirstName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%FirstName%%")
				arrBodyContents = append(arrBodyContents, businessPartner.FirstName)
			}
		case "LastName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%LastName%%")
				arrBodyContents = append(arrBodyContents, businessPartner.LastName)
			}
		}
	}
	messageContent = StrReplaceWithArray(messageContent, arrBodyKeys, arrBodyContents)
	return messageContent
}

// ReplaceTemplateVariableByUser func
func ReplaceTemplateVariableByUser(requestHeader models.RequestHeader, smsTemplateModel models.SMSTemplate, user models.User, messageContent string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		keyModels       []models.KeyTemplateVariable
		arrBodyKeys     = make([]string, 0)
		arrBodyContents = make([]string, 0)
	)
	//db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&keyModels)
	db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Find(&keyModels)
	for _, keyVar := range keyModels {
		switch keyVar.DataField {
		case "FirstName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%FirstName%%")
				arrBodyContents = append(arrBodyContents, user.FirstName)
			}
		case "LastName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%LastName%%")
				arrBodyContents = append(arrBodyContents, user.LastName)
			}
		}
	}
	messageContent = StrReplaceWithArray(messageContent, arrBodyKeys, arrBodyContents)
	return messageContent
}

// SendSMSOfCustomer func
func SendSMSOfCustomer(requestHeader models.RequestHeader, smsServiceConfig models.SMSServiceConfig, accountKey int, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) models.SendSMSResponse {
	numberCustomerSMS, contentCustomerSMS := GetPhoneNumberAndMessageContentOfCustomer(requestHeader, lang, smsTemplateModel, jobModel)
	contentCustomerSMS = ReplaceTemplateVariableByJobAndJobTask(requestHeader, lang, accountKey, smsTemplateModel, jobModel.JobID, contentCustomerSMS)
	resStatusSendSMS, resMsgSendSMS := SendSMSService(accountKey, lang, contentCustomerSMS, numberCustomerSMS, smsServiceConfig)
	var sendSMSResponse models.SendSMSResponse
	sendSMSResponse.Status = resStatusSendSMS
	sendSMSResponse.Message = resMsgSendSMS
	sendSMSResponse.PhoneNumber = numberCustomerSMS
	sendSMSResponse.Type = "Customer"
	return sendSMSResponse
}

// SendSMSOfJob func
func SendSMSOfJob(requestHeader models.RequestHeader, smsServiceConfig models.SMSServiceConfig, accountKey int, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) models.SendSMSResponse {
	numberCustomerSMS, contentCustomerSMS := GetPhoneNumberAndMessageContentOfJob(requestHeader, lang, smsTemplateModel, jobModel)
	contentCustomerSMS = ReplaceTemplateVariableByJobAndJobTask(requestHeader, lang, accountKey, smsTemplateModel, jobModel.JobID, contentCustomerSMS)
	resStatusSendSMS, resMsgSendSMS := SendSMSService(accountKey, lang, contentCustomerSMS, numberCustomerSMS, smsServiceConfig)
	var sendSMSResponse models.SendSMSResponse
	sendSMSResponse.Status = resStatusSendSMS
	sendSMSResponse.Message = resMsgSendSMS
	sendSMSResponse.PhoneNumber = numberCustomerSMS
	sendSMSResponse.Type = "Customer"
	return sendSMSResponse
}

// SendSMSOfManagers func
func SendSMSOfManagers(requestHeader models.RequestHeader, smsServiceConfig models.SMSServiceConfig, accountKey int, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) []models.SendSMSResponse {
	var sendSMSResponses = make([]models.SendSMSResponse, 0)
	phoneAndMessageOfManagers := GetPhoneNumberAndMessageContentOfManagers(requestHeader, smsTemplateModel, jobModel)
	for _, phoneAndMessage := range phoneAndMessageOfManagers {
		numberManagerSMS := phoneAndMessage.PhoneNumber
		contentManagerSMS := phoneAndMessage.MessageBody
		contentManagerSMS = ReplaceTemplateVariableByJobAndJobTask(requestHeader, lang, accountKey, smsTemplateModel, jobModel.JobID, contentManagerSMS)
		resStatusSendSMS, resMsgSendSMS := SendSMSService(accountKey, lang, contentManagerSMS, numberManagerSMS, smsServiceConfig)
		var sendSMSResponse models.SendSMSResponse
		sendSMSResponse.Status = resStatusSendSMS
		sendSMSResponse.Message = resMsgSendSMS
		sendSMSResponse.PhoneNumber = numberManagerSMS
		sendSMSResponse.Type = "Managers"
		sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
	}
	return sendSMSResponses
}

// SendSMSOfTask func
func SendSMSOfTask(requestHeader models.RequestHeader, smsServiceConfig models.SMSServiceConfig, accountKey int, lang string,
	smsTemplateModel models.SMSTemplate, jobModel models.Job, jobTaskType int) models.SendSMSResponse {
	numberTaskSMS, contentTaskSMS := GetPhoneNumberAndMessageContentOfTask(requestHeader, lang, smsTemplateModel, jobModel.JobID, jobTaskType)
	contentTaskSMS = ReplaceTemplateVariableByJobAndJobTask(requestHeader, lang, accountKey, smsTemplateModel, jobModel.JobID, contentTaskSMS)
	resStatusSendSMS, resMsgSendSMS := SendSMSService(accountKey, lang, contentTaskSMS, numberTaskSMS, smsServiceConfig)
	var sendSMSResponse models.SendSMSResponse
	sendSMSResponse.Status = resStatusSendSMS
	sendSMSResponse.Message = resMsgSendSMS
	sendSMSResponse.PhoneNumber = numberTaskSMS
	sendSMSResponse.Type = "Task"
	return sendSMSResponse
}

// SendSMSOfTask2 func
func SendSMSOfTask2(requestHeader models.RequestHeader, smsServiceConfig models.SMSServiceConfig, accountKey int, lang string, smsTemplateModel models.SMSTemplate, jobModel models.Job) models.SendSMSResponse {
	jobTaskType := 3
	numberTask2SMS, contentTask2SMS := GetPhoneNumberAndMessageContentOfTask(requestHeader, lang, smsTemplateModel, jobModel.JobID, jobTaskType)
	contentTask2SMS = ReplaceTemplateVariableByJobAndJobTask(requestHeader, lang, accountKey, smsTemplateModel, jobModel.JobID, contentTask2SMS)
	resStatusSendSMS, resMsgSendSMS := SendSMSService(accountKey, lang, contentTask2SMS, numberTask2SMS, smsServiceConfig)
	var sendSMSResponse models.SendSMSResponse
	sendSMSResponse.Status = resStatusSendSMS
	sendSMSResponse.Message = resMsgSendSMS
	sendSMSResponse.PhoneNumber = numberTask2SMS
	sendSMSResponse.Type = "Task2"
	return sendSMSResponse
}

// ReplaceTemplateVariableByJobAndJobTask func
func ReplaceTemplateVariableByJobAndJobTask(requestHeader models.RequestHeader, lang string, accountKey int, smsTemplateModel models.SMSTemplate, jobID int, messageContent string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		keyModels          []models.KeyTemplateVariable
		arrBodyKeys        = make([]string, 0)
		arrBodyContents    = make([]string, 0)
		jobModel           models.Job
		businessPartners   models.BusinessPartner
		jobTask            models.JobTask
		scheduleModel      models.Schedule
		trackAndTraceToken models.TrackAndTraceToken
		timeZone           models.Timezone
	)
	formatDateAndTime := "2006-01-02 15:04:05"
	formatDate := "2006-01-02"
	jobDate := ""
	scheduleStartDate := ""
	estimatedArrivalDateTime := ""
	endDateTime := ""

	db.Preload(
		"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("JobID = ?", jobID).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&jobModel)

	if len(jobModel.JobTasks) == 1 {
		jobTask = jobModel.JobTasks[0]
	} else if len(jobModel.JobTasks) > 1 {
		if jobModel.JobTasks[0].JobType == 2 {
			jobTask = jobModel.JobTasks[0]
		} else if jobModel.JobTasks[1].JobType == 2 {
			jobTask = jobModel.JobTasks[1]
		} else {
			jobTask = jobModel.JobTasks[0]
		}
	}

	timeZone = GetTimeZoneByAccount(requestHeader, accountKey)

	if timeZone.TimeZoneID > 0 {
		if timeZone.DateFormat != "" && timeZone.TimeFormat != "" {
			formatDateAndTime = MappingDateFormat(timeZone.DateFormat) + " " + MappingTimeFormat(timeZone.TimeFormat)
		}
		if timeZone.DateFormat != "" {
			formatDate = MappingDateFormat(timeZone.DateFormat)
		}
	}
	if jobModel.JobDate != nil {
		vJobDate := *jobModel.JobDate
		//vJobDate = vJobDate.Add(time.Duration(-timeZone.Offset) * time.Hour)
		jobDate = vJobDate.Format(formatDate)
	}
	db.Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?",
		jobModel.BusinessPartnerID,
	).First(&businessPartners)

	resultFindSchedule := db.Where("JobID = ? AND JobTaskID = ?", jobModel.JobID, jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&scheduleModel)
	if resultFindSchedule.RowsAffected > 0 {
		scheduleModel.ScheduleStartDate = scheduleModel.ScheduleStartDate.Add(time.Duration(timeZone.Offset) * time.Hour)
		scheduleStartDate = scheduleModel.ScheduleStartDate.Format(formatDateAndTime)
		trackAndTraceToken.ResourceID = scheduleModel.ResourceID
	}

	jobTypeName, _ := GetEnum(requestHeader, jobModel.JobType, "JobType", lang)

	trackAndTraceToken.JobTaskID = jobTask.JobTaskID
	if jobTask.EstimatedArrivalDateTime != nil {
		dEstimatedArrivalDateTime := *jobTask.EstimatedArrivalDateTime
		dEstimatedArrivalDateTime = dEstimatedArrivalDateTime.Add(time.Duration(-timeZone.Offset) * time.Hour)
		estimatedArrivalDateTime = dEstimatedArrivalDateTime.Format(formatDateAndTime)
	}
	if jobTask.EndDateTime != nil {
		dEndDateTime := *jobTask.EndDateTime
		dEndDateTime = dEndDateTime.Add(time.Duration(-timeZone.Offset) * time.Hour)
		endDateTime = dEndDateTime.Format(formatDateAndTime)
	}

	trackAndTraceToken.AccountKey = accountKey
	token, _ := ConvertTrackAndTraceTokenToToken(trackAndTraceToken)
	trackandTraceLink := GetTrackAndTrace(token)

	//db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&keyModels)
	db.Where("TemplateVariableKey = ?", smsTemplateModel.TemplateVariableKey).Where("Type = ?", "sms").Find(&keyModels)
	for _, keyVar := range keyModels {
		switch keyVar.DataField {
		case "JobNumber":
			{
				arrBodyKeys = append(arrBodyKeys, "%%JobNumber%%")
				arrBodyContents = append(arrBodyContents, jobModel.JobNumber)
			}
		case "JobDate":
			{
				arrBodyKeys = append(arrBodyKeys, "%%JobDate%%") //@TOTO TimeZone
				arrBodyContents = append(arrBodyContents, jobDate)
			}
		case "JobCompanyName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%JobCompanyName%%")
				arrBodyContents = append(arrBodyContents, businessPartners.CompanyName)
			}
		case "JobContactDetail":
			{
				arrBodyKeys = append(arrBodyKeys, "%%JobContactDetail%%")
				arrBodyContents = append(arrBodyContents, jobModel.ContactDetails)
			}
		case "ScheduleStartDate":
			{
				arrBodyKeys = append(arrBodyKeys, "%%ScheduleStartDate%%") //@TOTO TimeZone
				arrBodyContents = append(arrBodyContents, scheduleStartDate)
			}
		case "JobTypeName":
			{
				arrBodyKeys = append(arrBodyKeys, "%%JobTypeName%%")
				arrBodyContents = append(arrBodyContents, jobTypeName)
			}
		case "EstimatedArrivalDateTime":
			{
				arrBodyKeys = append(arrBodyKeys, "%%EstimatedArrivalDateTime%%") //@TOTO TimeZone
				arrBodyContents = append(arrBodyContents, estimatedArrivalDateTime)
			}
		case "EndDateTime":
			{
				arrBodyKeys = append(arrBodyKeys, "%%EndDateTime%%") //@TOTO TimeZone
				arrBodyContents = append(arrBodyContents, endDateTime)
			}
		case "TrackandTraceLink":
			{
				arrBodyKeys = append(arrBodyKeys, "%%TrackandTraceLink%%")
				arrBodyContents = append(arrBodyContents, trackandTraceLink)
			}
		}
	}

	// logger
	var smsLogger = smslogs.SMSLogger
	smsLogger.Printf("arrBodyKeys: %+v", arrBodyKeys)
	smsLogger.Printf("arrBodyContents: %+v", arrBodyContents)

	messageContent = StrReplaceWithArray(messageContent, arrBodyKeys, arrBodyContents)
	return messageContent
}

func GetTimeZoneByAccount(requestHeader models.RequestHeader, accountKey int) models.Timezone {
	var (
		timeZone models.Timezone
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Table("timezones").Joins("join locations on locations.TimeZoneID = timezones.TimeZoneID").
		Joins("join users on users.LocationID = locations.LocationID").
		Where("users.AccountKey = ?", accountKey).
		Scan(&timeZone)
	return timeZone
}

func GetTimeZoneByLocation(requestHeader models.RequestHeader, locationID int) models.Timezone {
	var (
		timeZone models.Timezone
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Table("timezones").Joins("join locations on locations.TimeZoneID = timezones.TimeZoneID").
		Where("locations.LocationID = ?", locationID).
		Scan(&timeZone)
	return timeZone
}
