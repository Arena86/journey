package libs

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"jpapi/tig/v1/models"
	"net/http"
	"os"
	"strings"
	"time"
)

// GetSygicLicense func
func GetSygicLicense() models.SygicLicense {
	var (
		sygicLicense models.SygicLicense
	)
	URL := os.Getenv("SERVER_REE") + "/getsygiclicense"
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			vSygicLicense, sSygicLicense := reeResponse["data"]
			if sSygicLicense {
				sygicLicenseJSON, errSygicLicenseJSON := json.Marshal(vSygicLicense)
				if errSygicLicenseJSON == nil {
					json.Unmarshal(sygicLicenseJSON, &sygicLicense)
				}
			}
		}
	}
	return sygicLicense
}

// GetDatabaseInfoByCompanyID func
func GetDatabaseInfoByCompanyID(lang string, companyID string) (int, string, models.RequestHeader) {
	var (
		requestHeader models.RequestHeader
		msgRee        string
	)
	URL := os.Getenv("SERVER_REE") + "/getcompanyinfobycompany"
	headers := make(map[string]interface{})
	headers["CompanyID"] = companyID
	statusRee, msgReeF, resRee := RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		vReeResponse, sReeResponse := reeResponse["data"]
		if sReeResponse {
			reeResponseJSON, errReeResponseJSON := json.Marshal(vReeResponse)
			if errReeResponseJSON == nil {
				var securityObj map[string]interface{}
				json.Unmarshal(reeResponseJSON, &securityObj)
				vReeResponseSecurity, sReeResponseSecurity := securityObj["Security"]
				if sReeResponseSecurity {
					sSecurity := fmt.Sprintf("%v", vReeResponseSecurity)
					objResponseHeader, errHeader := Decrypt(sSecurity)
					if errHeader == nil {
						requestHeader = objResponseHeader
					} else {
						statusRee = 500
						msgRee = errHeader.Error()
					}
				}
				json.Unmarshal(reeResponseJSON, &requestHeader)
			}
		}
	}
	if msgReeF != nil {
		msgRee = fmt.Sprintf("%v", msgReeF)
	}
	return statusRee, msgRee, requestHeader
}

func GetSygicRootURL(url string) string {
	url = strings.ToLower(url)
	url = strings.TrimSpace(url)
	url = strings.TrimSuffix(url, "/")
	url = strings.TrimSuffix(url, "activate")
	url = strings.TrimSuffix(url, "/")
	return url
}
