package libs

import (
	"fmt"
)

// GetLogDataMessage func
func GetLogDataMessage(funcName string, msg interface{}) string {
	if funcName == "" {
		return fmt.Sprintf("%v", msg)
	}
	return funcName + " " + fmt.Sprintf("%v", msg)
}
