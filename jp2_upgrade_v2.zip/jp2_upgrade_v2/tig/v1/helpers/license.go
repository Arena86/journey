package libs

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"jpapi/tig/v1/models"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

// GlobalLicenses var
var GlobalLicenses = make([]models.LicenseProduct, 0)

// LicenseSeperate const
const LicenseSeperate = "|"

// PathLicenseFolder const
const PathLicenseFolder = "public/licenses"

// LicenseFileName const
const LicenseFileName = "license.jp"

// PathLicenseFileName const
const PathLicenseFileName = PathLicenseFolder + "/" + LicenseFileName

// IssetString func
func IssetString(arr []string, index int) bool {
	return (len(arr) > index)
}

// CreateLicenseFileNameIfNotExist func
func CreateLicenseFileNameIfNotExist() error {
	err := os.MkdirAll(PathLicenseFolder, 0777)
	if err == nil {
		f, err := os.OpenFile(PathLicenseFileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		defer f.Close()
		return err
	}
	return err
}

// UpdateLicenseInfo func
func UpdateLicenseInfo(license models.LicenseProduct) {
	// update in global
	for i, global := range GlobalLicenses {
		if global.CompanyID == license.CompanyID {
			GlobalLicenses[i].MaxMonthlyJobs = license.MaxMonthlyJobs
			GlobalLicenses[i].MaxDynamicForm = license.MaxDynamicForm
			break
		}
	}
	//fmt.Printf("GlobalLicenses: %+v\n", GlobalLicenses)
	// update in file
	var (
		err   error
		lines = make([]string, 0)
	)
	fileLicenses := make([]models.LicenseProduct, 0)
	lines, err = ReadLicenseFile()
	if err == nil {
		for _, line := range lines {
			fileLicense := ConvertLicenseStringToObject(line)
			if fileLicense.CompanyID == license.CompanyID {
				fileLicense.MaxMonthlyJobs = license.MaxMonthlyJobs
				fileLicense.MaxDynamicForm = license.MaxDynamicForm
				fileLicense.ResourceQuantity = license.ResourceQuantity
				fileLicense.MaxUser = license.MaxUser
				fileLicense.IsSmartScheduling = license.IsSmartScheduling
				fileLicense.AdditionalDeviceLicenseQuantity = license.AdditionalDeviceLicenseQuantity
				fileLicense.IsXero = license.IsXero
				fileLicense.IsMicrosoftDynamic = license.IsMicrosoftDynamic
				fileLicense.IsLiveChat = license.IsLiveChat
				fileLicense.IsReplayRoutes = license.IsReplayRoutes
				fileLicense.IsReportDesigner = license.IsReportDesigner
				fileLicense.ExpiryDate = license.ExpiryDate
				fileLicense.PhysicalDeviceQuantity = license.PhysicalDeviceQuantity
				fileLicense.PhysicalDeviceAmount = license.PhysicalDeviceAmount
			}
			fileLicenses = append(fileLicenses, fileLicense)
		}
	}
	if len(fileLicenses) > 0 {
		arrStringLicenses := make([]string, 0)
		for _, licenseObj := range fileLicenses {
			strLicense := ConvertLicenseObjectToString(licenseObj)
			arrStringLicenses = append(arrStringLicenses, strLicense)
		}
		if len(arrStringLicenses) > 0 {
			output := strings.Join(arrStringLicenses, "\n")
			err := CreateLicenseFileNameIfNotExist()
			if err == nil {
				f, errW := os.OpenFile(PathLicenseFileName, os.O_WRONLY, 0644)
				defer f.Close()
				if errW == nil {
					f.WriteString(output)
				}
			}
		}
	}
}

// FindLicenseInfo func
func FindLicenseInfo(companyID string) (bool, models.LicenseProduct, error) {
	// find in global
	hasLicense, licenseResponse, err := FindLicenseInfoInVariableGlobal(companyID)
	if err != nil || !hasLicense {
		// find in license file
		hasLicense, licenseResponse, err = FindLicenseInfoInFileByComapnyID(companyID)
		if err != nil || !hasLicense {
			// find ree
			hasLicense, licenseResponse, err = FindLicenseInfoInReeByCompanyID(companyID)
		}
	}
	return hasLicense, licenseResponse, err
}

// FindLicenseInfoInVariableGlobal func
func FindLicenseInfoInVariableGlobal(companyID string) (bool, models.LicenseProduct, error) {
	var (
		err             error
		hasLicense      = false
		licenseResponse models.LicenseProduct
	)
	//fmt.Printf("GlobalLicenses: %+v\n", GlobalLicenses)
	for _, license := range GlobalLicenses {
		if license.CompanyID == companyID {
			hasLicense = true
			licenseResponse = license
			break
		}
	}
	return hasLicense, licenseResponse, err
}

// FindLicenseInfoInFileByComapnyID func
func FindLicenseInfoInFileByComapnyID(companyID string) (bool, models.LicenseProduct, error) {
	var (
		err             error
		lines           = make([]string, 0)
		hasLicense      = false
		licenseResponse models.LicenseProduct
	)
	lines, err = ReadLicenseFile()
	if err == nil {
		for _, line := range lines {
			license := ConvertLicenseStringToObject(line)
			if license.CompanyID == companyID {
				hasLicense = true
				licenseResponse = license
				break
			}
		}
	}
	//fmt.Printf("lines: %+v\n", lines)
	if hasLicense {
		// add to global
		GlobalLicenses = append(GlobalLicenses, licenseResponse)
	}
	return hasLicense, licenseResponse, err
}

// FindLicenseInfoInReeByCompanyID func
func FindLicenseInfoInReeByCompanyID(companyID string) (bool, models.LicenseProduct, error) {
	var (
		err             error
		hasLicense      = false
		licenseResponse models.LicenseProduct
	)

	URL := os.Getenv("SERVER_REE") + "/getproductlicensebycompanyid/" + companyID
	req, errRequest := http.NewRequest("GET", URL, nil)
	req.Close = true
	if errRequest == nil {
		client := &http.Client{Timeout: time.Duration(GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			var reeResponse map[string]interface{}
			json.Unmarshal([]byte(string(body)), &reeResponse)
			vReeResponse, sReeResponse := reeResponse["data"]
			if sReeResponse {
				reeResponseDataJSON, errReeResponseDataJSON := json.Marshal(vReeResponse)
				if errReeResponseDataJSON == nil {
					var license models.LicenseProduct
					json.Unmarshal(reeResponseDataJSON, &license)
					if license.CompanyID == companyID {
						hasLicense = true
						licenseResponse = license
					}
					if hasLicense {
						// add license to global variable
						GlobalLicenses = append(GlobalLicenses, licenseResponse)
						// add license to license file
						licenseStr := ConvertLicenseObjectToString(licenseResponse)
						err = WriteLicenseFile(licenseStr)
					}
				}
			}
		}
	}

	return hasLicense, licenseResponse, err
}

// ReadLicenseFile func
func ReadLicenseFile() ([]string, error) {
	var (
		err   error
		lines = make([]string, 0)
	)
	err = CreateLicenseFileNameIfNotExist()
	if err == nil {
		f, err := os.Open(PathLicenseFileName)
		defer f.Close()
		if err == nil {
			scanner := bufio.NewScanner(f)
			err = scanner.Err()
			if err == nil {
				for scanner.Scan() {
					lines = append(lines, scanner.Text())
				}
			}
		}
	}
	return lines, err
}

// WriteLicenseFile func
func WriteLicenseFile(str string) error {
	err := CreateLicenseFileNameIfNotExist()
	if err == nil {
		f, errW := os.OpenFile(PathLicenseFileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		defer f.Close()
		if errW == nil {
			f.WriteString(str + "\n")
		} else {
			err = errW
		}
	}
	return err
}

// ConvertLicenseStringToObject func
func ConvertLicenseStringToObject(licenseStr string) models.LicenseProduct {
	var license models.LicenseProduct
	arrStr := strings.Split(licenseStr, LicenseSeperate)
	if IssetString(arrStr, 0) {
		license.CompanyID = arrStr[0]
	}
	if IssetString(arrStr, 1) {
		license.MaxMonthlyJobs, _ = strconv.Atoi(arrStr[1])
	}
	if IssetString(arrStr, 2) {
		license.MaxDynamicForm, _ = strconv.Atoi(arrStr[2])
	}
	if IssetString(arrStr, 3) {
		license.ResourceQuantity, _ = strconv.ParseFloat(arrStr[3], 64)
	}
	if IssetString(arrStr, 4) {
		license.MaxUser, _ = strconv.ParseFloat(arrStr[4], 64)
	}
	if IssetString(arrStr, 5) {
		license.IsSmartScheduling, _ = strconv.ParseBool(arrStr[5])
	}
	if IssetString(arrStr, 6) {
		license.SmartSchedulingQuantity, _ = strconv.ParseFloat(arrStr[6], 64)
	}
	if IssetString(arrStr, 7) {
		license.AdditionalDeviceLicenseQuantity, _ = strconv.ParseFloat(arrStr[7], 64)
	}
	if IssetString(arrStr, 8) {
		license.IsXero, _ = strconv.ParseBool(arrStr[8])
	}
	if IssetString(arrStr, 9) {
		license.IsMicrosoftDynamic, _ = strconv.ParseBool(arrStr[9])
	}
	if IssetString(arrStr, 10) {
		license.IsLiveChat, _ = strconv.ParseBool(arrStr[10])
	}
	if IssetString(arrStr, 11) {
		license.IsReplayRoutes, _ = strconv.ParseBool(arrStr[11])
	}
	if IssetString(arrStr, 12) {
		license.IsReportDesigner, _ = strconv.ParseBool(arrStr[12])
	}
	if IssetString(arrStr, 13) {
		expired := arrStr[13]
		license.ExpiryDate = expired
	}
	if IssetString(arrStr, 14) {
		license.PhysicalDeviceQuantity, _ = strconv.ParseFloat(arrStr[14], 64)
	}
	if IssetString(arrStr, 15) {
		license.PhysicalDeviceAmount, _ = strconv.ParseFloat(arrStr[15], 64)
	}

	return license
}

// ConvertLicenseObjectToString func
func ConvertLicenseObjectToString(license models.LicenseProduct) string {
	return license.CompanyID +
		LicenseSeperate + strconv.Itoa(license.MaxMonthlyJobs) +
		LicenseSeperate + strconv.Itoa(license.MaxDynamicForm) +
		LicenseSeperate + fmt.Sprintf("%f", license.ResourceQuantity) +
		LicenseSeperate + fmt.Sprintf("%f", license.MaxUser) +
		LicenseSeperate + strconv.FormatBool(license.IsSmartScheduling) +
		LicenseSeperate + fmt.Sprintf("%f", license.SmartSchedulingQuantity) +
		LicenseSeperate + fmt.Sprintf("%f", license.AdditionalDeviceLicenseQuantity) +
		LicenseSeperate + strconv.FormatBool(license.IsXero) +
		LicenseSeperate + strconv.FormatBool(license.IsMicrosoftDynamic) +
		LicenseSeperate + strconv.FormatBool(license.IsLiveChat) +
		LicenseSeperate + strconv.FormatBool(license.IsReplayRoutes) +
		LicenseSeperate + strconv.FormatBool(license.IsReportDesigner) +
		LicenseSeperate + license.ExpiryDate +
		LicenseSeperate + fmt.Sprintf("%f", license.PhysicalDeviceQuantity) +
		LicenseSeperate + fmt.Sprintf("%f", license.PhysicalDeviceAmount)
}
