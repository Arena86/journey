package libs

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/models"
	"strconv"
	"strings"
)

// GetDefaultFields func
func GetDefaultFields(sql string, fieldName string) string {
	// primary
	primaryKey := GetPrimaryKeyFieldFromTableName(fieldName)
	sql = sql + primaryKey + ` bigint AUTO_INCREMENT PRIMARY KEY NOT NULL`
	// CreatedBy
	sql = sql + `, CreatedBy bigint NULL`
	// CreatedDate
	sql = sql + `, CreatedDate datetime NULL`
	// ModifiedBy
	sql = sql + `, ModifiedBy bigint NULL`
	// ModifiedDate
	sql = sql + `, ModifiedDate datetime NULL`
	// IsDeleted
	sql = sql + `, IsDeleted tinyint(1) NULL`
	// IsAudit
	sql = sql + `, IsAudit tinyint(1) NULL`
	// IsArchived
	sql = sql + `, IsArchived tinyint(1) NULL`
	// JobID
	sql = sql + `, JobID bigint NULL`
	// JobTaskID
	sql = sql + `, JobTaskID bigint NULL`
	// ItemID
	sql = sql + `, ItemID bigint NULL`
	// Key
	sql = sql + ", `Key` VARCHAR(100) NULL"
	return sql
}

// ConvertToDBDataType func
func ConvertToDBDataType(dataType string) string {
	dbDataType := "varchar"
	switch strings.ToLower(dataType) {
	case "string":
		dbDataType = "varchar"
	case "decimal":
		dbDataType = "decimal"
	case "boolean":
		dbDataType = "tinyint(1)"
	case "datetime":
		dbDataType = "datetime"

	}
	return dbDataType
}

// GetPrimaryKeyFieldFromTableName func
func GetPrimaryKeyFieldFromTableName(fieldName string) string {
	return fieldName + "ID"
}

// GetDefaultColumns func
func GetDefaultColumns(tableName string, primaryFieldName string) []string {
	primaryKey := GetPrimaryKeyFieldFromTableName(primaryFieldName)
	return []string{primaryKey, "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate", "IsDeleted", "IsAudit", "IsArchived", "JobID", "JobTaskID", "ItemID", "Key"}
}

// MappingLengthToDataField func
func MappingLengthToDataField(sql string, lowerCaseType string, length int) string {
	switch lowerCaseType {
	case "varchar", "int", "bigint":
		{
			sql = sql + `(` + strconv.Itoa(length) + `)`
		}
	case "decimal":
		{
			sql = sql + `(18,5)`
		}
	}
	return sql
}

// ChangeValueToDatabaseFormat func
func ChangeValueToDatabaseFormat(objectName string) string {
	objectName = strings.TrimSpace(objectName)
	objectName = RemoveAllSpaceInString(objectName)
	if objectName != "" {
		return "U_" + objectName
	}
	return objectName
}

// ChangeValueFromDatabaseFormatToNormal func
func ChangeValueFromDatabaseFormatToNormal(objectName string) string {
	return strings.Replace(objectName, "u_", "", -1)
}

// ConvertDatabaseValueToResponseValue func
func ConvertDatabaseValueToResponseValue(val string, databaseType string) interface{} {
	switch databaseType {
	case "BIGINT", "INT":
		{
			vVal, sVal := strconv.Atoi(val)
			if sVal == nil {
				return vVal
			}
		}
	case "TINYINT":
		{
			vVal, sVal := strconv.ParseBool(val)
			if sVal == nil {
				return vVal
			}
		}
	case "DECIMAL":
		{
			vVal, sVal := strconv.ParseFloat(val, 64)
			if sVal == nil {
				return vVal
			}
		}
	}
	return val
}

// CheckDatabaseDateTimeByFieldNameAndTableName func
func CheckDatabaseDateTimeByFieldNameAndTableName(requestHeader models.RequestHeader, tableName string, fieldName string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	sqlSelect := `SELECT * FROM ` + tableName
	rows, errQuery := db.Raw(sqlSelect).Rows()
	if errQuery == nil {
		defer rows.Close()
		mapColumsType := make(map[string]string)
		colsType, _ := rows.ColumnTypes()
		for _, ty := range colsType {
			if ty != nil {
				sqlColumType := *ty
				mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
			}
		}
		vFieldType, sFieldType := mapColumsType[fieldName]
		if sFieldType {
			return vFieldType
		}
	}
	return ""
}

// GetTableNameFromUDTID func
func GetTableNameFromUDTID(formUDTID int) string {
	return "u_form_" + strconv.Itoa(formUDTID)
}

// GetPrimaryKeyFromUDTID func
func GetPrimaryKeyFromUDTID(formUDTID int) string {
	return "U_Form_" + strconv.Itoa(formUDTID) + "ID"
}
