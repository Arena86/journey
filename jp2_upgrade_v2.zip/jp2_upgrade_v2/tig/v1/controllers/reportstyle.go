package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetReportStyle godoc
// @Summary Get Report Style
// @Description Get Report Style
// @Tags ReportStyle
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /reportstyles [get]
func GetReportStyle(c *gin.Context) {
	defer libs.RecoverError(c, "GetReportStyle")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.ReportStyle
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"JobTemplateName", "JobTemplateCode", "Description", "ReportStyleName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayReportStyleToArrayResponse(resModels, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetReportStyleByID godoc
// @Summary Get ReportStyle By ID
// @Description Get ReportStyle  By ID
// @Tags ReportStyle
// @Accept  json
// @Produce  json
// @Param id path int true "ReportStyle ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /reportstyles/{id} [get]
func GetReportStyleByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetReportStyleByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.ReportStyle
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ReportStyleID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertReportStyleToResponse(resModel, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateReportStyle godoc
// @Summary Create Report Style
// @Description Create Report Style
// @Tags ReportStyle
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ReportStyle body []models.ReportStyle true "Create Report Style"
// @Success 200 {object} models.APIResponseData
// @Router /reportstyles [post]
func CreateReportStyle(c *gin.Context) {
	defer libs.RecoverError(c, "CreateReportStyle")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.ReportStyle
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.ReportStyle, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				postModel models.ReportStyle
			)
			postModel.PassBodyJSONToModel(bp)
			resultFindReport := db.Where("ReportStyleName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", postModel.ReportStyleName).First(&models.ReportStyle{})
			if resultFindReport.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.reportstylename_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				postModel.CreatedBy = accountKey
				postModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(postModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					// @TODO validate for address
					resultCreate := db.Create(&postModel)
					if resultCreate.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultCreate.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, postModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.ReportStyle
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReportStyleID)
	}
	if len(arrID) > 0 {
		db.Where("ReportStyleID in (?)", arrID).Find(&resModels)
		data = ConvertArrayReportStyleToArrayResponse(resModels, requestHeader)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateReportStyle godoc
// @Summary Update Report Style
// @Description Update Report Style
// @Tags ReportStyle
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ReportStyle body []models.ReportStyle true "Update Report Style"
// @Success 200 {object} models.APIResponseData
// @Router /reportstyles [put]
func UpdateReportStyle(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateReportStyle")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.ReportStyle
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.ReportStyle, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.ReportStyle
			)
			putModel.PassBodyJSONToModel(bp)
			if putModel.ReportStyleName != "" {
				resultFindReport := db.Where("ReportStyleName = ? AND ReportStyleID <> ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", putModel.ReportStyleName, putModel.ReportStyleID).First(&models.ReportStyle{})
				if resultFindReport.RowsAffected > 0 {
					errResponse := GetErrorResponseValidate(lang, k, "api.reportstylename_exist")
					errorsResponse = append(errorsResponse, errResponse)
					continue
				}
			}
			resultFind := db.Where("ReportStyleID = ?", putModel.ReportStyleID).First(&putModel)
			if resultFind.RowsAffected > 0 {
				putModel.PassBodyJSONToModel(bp)
				putModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(putModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultSave := db.Save(&putModel)
					if resultSave.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultSave.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, putModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.ReportStyle
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReportStyleID)
	}
	if len(arrID) > 0 {
		db.Where("ReportStyleID in (?)", arrID).Find(&resModels)
		data = ConvertArrayReportStyleToArrayResponse(resModels, requestHeader)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteReportStyle godoc
// @Summary Delete Report Style
// @Description Delete Report Style
// @Tags ReportStyle
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Report Style ID"
// @Success 200 {object} models.APIResponseData
// @Router /reportstyles/{id} [delete]
func DeleteReportStyle(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteReportStyle")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.ReportStyle
		)
		resultFind := db.Where("ReportStyleID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayReportStyleToArrayResponse func
func ConvertArrayReportStyleToArrayResponse(items []models.ReportStyle, requestHeader models.RequestHeader) []models.ReportStyleResponse {
	responses := make([]models.ReportStyleResponse, 0)
	for _, item := range items {
		response := ConvertReportStyleToResponse(item, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertReportStyleToResponse func
func ConvertReportStyleToResponse(item models.ReportStyle, requestHeader models.RequestHeader) models.ReportStyleResponse {
	var (
		response models.ReportStyleResponse
	)
	response.ReportStyleID = item.ReportStyleID
	response.ReportStyleName = item.ReportStyleName
	response.FontName = item.FontName
	response.FontSize = item.FontSize
	response.FontUnit = item.FontUnit
	response.FontBold = item.FontBold
	response.FontItalic = item.FontItalic
	response.FontUnderline = item.FontUnderline
	response.FontStrikeout = item.FontStrikeout
	response.TextAlignment = item.TextAlignment
	response.BackgroundColorRGBA = item.BackgroundColorRGBA
	response.ForegroundColorRGBA = item.ForegroundColorRGBA
	response.BorderColorRGBA = item.BorderColorRGBA
	response.BorderSides = item.BorderSides
	response.BorderWidth = item.BorderWidth
	response.BorderDashStyle = item.BorderDashStyle
	response.PaddingLeft = item.PaddingLeft
	response.PaddingRight = item.PaddingRight
	response.PaddingBottom = item.PaddingBottom
	response.PaddingTop = item.PaddingTop
	return response
}
