package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetSearchField godoc
// @Summary Get SearchField
// @Description Get SearchField
// @Tags SearchField
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param SearchFieldKey query string false "SearchFieldKey"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /searchfield [get]
func GetSearchField(c *gin.Context) {
	defer libs.RecoverError(c, "GetSearchField")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.SearchField
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Order("Sort ASC")
	bp = bp.Where("AccountKey = ?", accountKey)

	vTableName, sTableName := libs.GetQueryParam("TableName", c)
	if sTableName {
		bp = bp.Where("TableName = ?", vTableName)
	}

	vSearchFieldKey, sSearchFieldKey := libs.GetQueryParam("SearchFieldKey", c)
	if sSearchFieldKey {
		bp = bp.Where("SearchFieldKey = ?", vSearchFieldKey)
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySearchFieldToArrayResponse(resModels, lang, requestHeader)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// UpdateSearchField godoc
// @Summary Update SearchField
// @Description Update SearchField
// @Tags SearchField
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SearchField body []models.SearchFieldResponse true "Create SearchField"
// @Success 200 {object} models.APIResponseData
// @Router /searchfield [put]
func UpdateSearchField(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSearchField")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.SearchField
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.SearchField, 0)
	key := c.Param("key")
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		db.Where("SearchFieldKey = ? AND AccountKey = ?", key, accountKey).Model(&models.SearchField{}).Updates(map[string]interface{}{"Visible": false})
		for k, bp := range objectsJSON {
			var (
				resModel models.SearchField
			)
			resModel.PassBodyJSONToModel(bp)
			resultFind := db.Where("SearchFieldID = ?", resModel.SearchFieldID).First(&resModel)
			resModel.PassBodyJSONToModel(bp)
			resModel.ModifiedBy = accountKey
			resModel.AccountKey = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resModel)
				} else {
					db.Create(&resModel)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.SearchField
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.SearchFieldID)
	}
	if len(arrID) > 0 {
		db.Where("SearchFieldID in (?)", arrID).Find(&resModels)
		data = ConvertArraySearchFieldToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	/* responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status) */
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArraySearchFieldToArrayResponse func
func ConvertArraySearchFieldToArrayResponse(items []models.SearchField, lang string, requestHeader models.RequestHeader) []models.SearchFieldResponse {
	responses := make([]models.SearchFieldResponse, 0)
	for _, item := range items {
		response := ConvertSearchFieldToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertSearchFieldToResponse func
func ConvertSearchFieldToResponse(item models.SearchField, lang string, requestHeader models.RequestHeader) models.SearchFieldResponse {
	var (
		response models.SearchFieldResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.SearchFieldID = item.SearchFieldID
	response.TableNameObj = item.TableNameObj
	response.Parameter = item.Parameter
	if item.TranslationKey != "" && item.TranslationKey != services.GetMessage(lang, item.TranslationKey) {
		response.Label = services.GetMessage(lang, item.TranslationKey)
	} else {
		response.Label = item.Label
	}
	response.MaxLength = item.MaxLength
	response.Widget = item.Widget
	if response.Widget == "dxCheckBox" {
		if item.Value != "true" && item.Value != "false" {
			response.Value = nil
		} else {
			response.Value, _ = strconv.ParseBool(item.Value)
		}
	} else if response.Widget == "dxDateBox" {
		if item.Value == "" {
			response.Value = nil
		} else {
			response.Value = item.Value
		}
	} else if response.Widget == "dxNumberBox" {
		response.Value, _ = strconv.ParseFloat(item.Value, 64)
		response.Value = item.Value
	} else {
		response.Value = item.Value
	}

	response.Visible = item.Visible
	response.Sort = item.Sort
	response.AccountKey = item.AccountKey
	response.Options = item.Options
	response.DateType = item.DateType
	response.Operator = item.Operator
	response.IsEnum = item.IsEnum
	enumDataSources := make([]models.EnumDataSource, 0)
	// Check Enum
	if item.IsEnum {
		var (
			resModels []models.Enumerator
		)
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ?", item.FieldName).Find(&resModels)
		for _, item := range resModels {
			var (
				enumDataSource models.EnumDataSource
			)
			enumDataSource.Status = item.Status
			if item.TranslationKey != "" && item.TranslationKey != services.GetMessage(lang, item.TranslationKey) {
				enumDataSource.Caption = services.GetMessage(lang, item.TranslationKey)
			} else {
				enumDataSource.Caption = item.Caption
			}
			enumDataSources = append(enumDataSources, enumDataSource)
		}
	}
	response.EnumDataSource = enumDataSources
	var options, dataType, dataField, alignment, dateType string
	var numberPrecision int
	sqlJoin := ``
	if libs.InArrayString(item.DateType, libs.GetArrayDateType()) && item.Widget == "dxDateBox" {
		// @TODO if datetime then remove _from/_to on Parameter
		sqlJoin = `SELECT ud.Options, ud.DataType, ud.NumberPrecision, ud.DataField, ud.Alignment, ud.DateType 
		FROM searchfields sf join udfs ud on LOWER(sf.TableName) = LOWER(ud.TableName) and (LOWER(sf.Parameter) = LOWER(CONCAT(ud.DataField, "_from")) OR LOWER(sf.Parameter) = LOWER(CONCAT(ud.DataField, "_to"))) WHERE sf.SearchFieldID = ?`
	} else {
		sqlJoin = `SELECT ud.Options, ud.DataType, ud.NumberPrecision, ud.DataField, ud.Alignment, ud.DateType 
		FROM searchfields sf join udfs ud on LOWER(sf.TableName) = LOWER(ud.TableName) and LOWER(sf.Parameter) = LOWER(ud.DataField) WHERE sf.SearchFieldID = ?`
	}

	rows, err := db.Raw(sqlJoin, item.SearchFieldID).Rows()
	defer rows.Close()
	if err == nil {
		for rows.Next() {
			rows.Scan(&options, &dataType, &numberPrecision, &dataField, &alignment, &dateType)
			response.Options = options
			response.DataType = dataType
			response.NumberPrecision = numberPrecision
			response.DataField = dataField
			response.Alignment = alignment
			response.DateType = dateType

		}
	}
	return response
}
