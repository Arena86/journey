package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// Get4DPricesByItem godoc
// @Summary Get4DPricesByItem
// @Description Get4DPricesByItem
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /get4dpricesbyitem/{itemid} [get]
func Get4DPricesByItem(c *gin.Context) {
	defer libs.RecoverError(c, "Get4DPricesByItem")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FourDPrice
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	itemID, _ := strconv.Atoi(c.Param("itemid"))

	var (
		fourDPriceItemModels  []models.FourDPriceItem
		arr4DPriceIDFromItems = make([]int, 0)
	)
	db.Where("ItemID = ?", itemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&fourDPriceItemModels)
	for it := range fourDPriceItemModels {
		arr4DPriceIDFromItems = append(arr4DPriceIDFromItems, fourDPriceItemModels[it].FourDPriceID)
	}
	if len(arr4DPriceIDFromItems) <= 0 {
		arr4DPriceIDFromItems = append(arr4DPriceIDFromItems, -1)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("FourDimensionsPriceDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("FourDimensionsItems", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter
	bp = bp.Where("4DPriceID in (?)", arr4DPriceIDFromItems)

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArray4DPriceToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetInspection4DPrices godoc
// @Summary GetInspection4DPrices
// @Description GetInspection4DPrices
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getinspection4dprices [get]
func GetInspection4DPrices(c *gin.Context) {
	defer libs.RecoverError(c, "GetInspection4DPrices")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FourDPrice
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	itemID, _ := libs.GetQueryParam("ItemID", c)
	jobID, _ := libs.GetQueryParam("JobID", c)
	key, _ := libs.GetQueryParam("Key", c)
	var (
		job4DPrices           []models.Job4DPrice
		arr4DPriceIDFromItems = make([]int, 0)
		job                   models.Job
	)
	var bpInspectionJob = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bpInspectionJob.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job)
	db.Where("ItemID = ? AND JobID = ? AND `Key` = ?", itemID, job.InspectionForJobID, key).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
	for _, it := range job4DPrices {
		var fourDPrice models.FourDPrice
		db.Where("4DPriceID = ?", it.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&fourDPrice)
		arr4DPriceIDFromItems = append(arr4DPriceIDFromItems, fourDPrice.FourDPriceID)
	}
	if len(arr4DPriceIDFromItems) <= 0 {
		arr4DPriceIDFromItems = append(arr4DPriceIDFromItems, -1)
	}

	// Filter
	var bp = db.Where("4DPriceID in (?)", arr4DPriceIDFromItems)

	// end
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	//itemIDInt, _ := strconv.Atoi(itemID)
	//responses := ConvertArrayInspection4DPriceToArrayResponse(requestHeader, resModels, job.InspectionForJobID, itemIDInt, key)

	responses := make([]models.InspectionFourDPriceResponse, 0)
	for _, item := range resModels {
		var (
			response    models.InspectionFourDPriceResponse
			job4DPrices []models.Job4DPrice
		)
		inspectionJob4DPrices := make([]models.InspectionJob4DPrice, 0)
		db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		response.FourDPriceID = item.FourDPriceID
		response.FourDPriceName = item.FourDPriceName
		response.SurchargeItemID = item.SurchargeItemID

		var surchargeItemModel models.Item
		resultFindSurchargeItem := db.Where("ItemID = ?", item.SurchargeItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&surchargeItemModel)
		if resultFindSurchargeItem.RowsAffected > 0 {
			response.SurchargeItemCode = surchargeItemModel.Code
			response.SurchargeItemName = surchargeItemModel.Name
		}
		response.TaxID = item.TaxID
		response.IncludingTax = item.IncludingTax
		response.DimensionName1 = item.DimensionName1
		response.DimensionName2 = item.DimensionName2
		response.DimensionName3 = item.DimensionName3
		response.DimensionName4 = item.DimensionName4
		response.Dimension1Enable = item.Dimension1Enable
		response.Dimension2Enable = item.Dimension2Enable
		response.Dimension3Enable = item.Dimension3Enable
		response.Dimension4Enable = item.Dimension4Enable
		response.Dimension1DataType = item.Dimension1DataType
		response.Dimension2DataType = item.Dimension2DataType
		response.Dimension3DataType = item.Dimension3DataType
		response.Dimension4DataType = item.Dimension4DataType
		var (
			inspectionJobModel        models.Job
			rootJobModel              models.Job
			job4DPriceModels          []models.Job4DPrice
			arrSurchargeParentItemKey = make([]string, 0)
		)
		var bp = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		resultFindInspectionJob := bp.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&inspectionJobModel)
		if resultFindInspectionJob.RowsAffected > 0 {
			resultFindRootJob := db.Where("JobID = ?", inspectionJobModel.InspectionForJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&rootJobModel)
			if resultFindRootJob.RowsAffected > 0 {
				surchargeParentItemKey := inspectionJobModel.SurchargeParentItemKeys
				if surchargeParentItemKey != "" {
					arrSurchargeParentItemKey = strings.Split(surchargeParentItemKey, SurchargeParentItemKeySeparator)
				}
				if len(arrSurchargeParentItemKey) > 0 {
					resultFindJob4DPrice := db.Debug().Select("ItemID,`Key`,JobTaskID").Where("JobID = ? AND `Key` in (?)", rootJobModel.JobID, arrSurchargeParentItemKey).
						Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Group("ItemID,`Key`,JobTaskID").Find(&job4DPriceModels)
					if resultFindJob4DPrice.RowsAffected > 0 {
						for _, job4DPriceModel := range job4DPriceModels {
							var jobTaskModel models.JobTask
							resultFindJobTask := db.Where("JobTaskID = ? AND JobType = ?", job4DPriceModel.JobTaskID, inspectionJobModel.JobDetails[0].JobTaskType).
								Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
							if resultFindJobTask.RowsAffected > 0 {
								db.Where("4DPriceID = ? AND JobID = ? AND ItemID = ? AND `Key` = ? AND JobTaskID = ?", item.FourDPriceID, job.InspectionForJobID, itemID, key, jobTaskModel.JobTaskID).
									Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
								for _, item := range job4DPrices {
									var inspectionJob4DPrice models.InspectionJob4DPrice
									inspectionJob4DPrice.Job4DPriceID = item.Job4DPriceID
									inspectionJob4DPrice.FourDPriceID = item.FourDPriceID
									inspectionJob4DPrice.JobID = item.JobID
									inspectionJob4DPrice.JobTaskID = item.JobTaskID
									inspectionJob4DPrice.ItemID = item.ItemID
									inspectionJob4DPrice.SurchargeItemID = item.SurchargeItemID
									inspectionJob4DPrice.Dimension1 = ConvertData4DPriceDimensionResponse(item.Dimension1, response.Dimension1DataType)
									inspectionJob4DPrice.Dimension2 = ConvertData4DPriceDimensionResponse(item.Dimension2, response.Dimension2DataType)
									inspectionJob4DPrice.Dimension3 = ConvertData4DPriceDimensionResponse(item.Dimension3, response.Dimension3DataType)
									inspectionJob4DPrice.Dimension4 = ConvertData4DPriceDimensionResponse(item.Dimension4, response.Dimension4DataType)
									inspectionJob4DPrice.TriggerInspection = item.TriggerInspection
									inspectionJob4DPrice.TriggerInspectionCompleted = item.TriggerInspectionCompleted
									inspectionJob4DPrice.Key = item.Key
									inspectionJob4DPrice.TriggerInspectionMode = item.TriggerInspectionMode
									inspectionJob4DPrices = append(inspectionJob4DPrices, inspectionJob4DPrice)
								}
								response.Job4DPrices = inspectionJob4DPrices
							}
						}
					}
				}
			}
		}
		responses = append(responses, response)
	}
	// Get 4DPrice
	var (
		fourDPriceModels     []models.FourDPrice
		fourDPriceItemModels []models.FourDPriceItem

		settingModel             models.Setting
		showAllDimensionOnDevice = false
	)
	resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
	if resultFindSetting.RowsAffected > 0 {
		if settingModel.Value != nil {
			var (
				settingValue models.SettingValue
			)
			errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
			if errSettingValue == nil {
				showAllDimensionOnDevice = settingValue.PriceLists.ShowAllDimensionOnDevice
			}
		}
	}

	if showAllDimensionOnDevice {
		db.Debug().Where("ItemID = ? AND 4DPriceID NOT IN (?)", itemID, arr4DPriceIDFromItems).
			Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&fourDPriceItemModels)
		var arr4DPriceIDExtended = make([]int, 0)
		for _, fdp := range fourDPriceItemModels {
			arr4DPriceIDExtended = append(arr4DPriceIDExtended, fdp.FourDPriceID)
		}
		db.Debug().Where("4DPriceID IN (?)", arr4DPriceIDExtended).
			Where("IFNULL(IsDeleted, 0) <> 1").Find(&fourDPriceModels)
		for _, item := range fourDPriceModels {
			var (
				response models.InspectionFourDPriceResponse
			)
			inspectionJob4DPrices := make([]models.InspectionJob4DPrice, 0)
			db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			response.FourDPriceID = item.FourDPriceID
			response.FourDPriceName = item.FourDPriceName
			response.SurchargeItemID = item.SurchargeItemID

			var surchargeItemModel models.Item
			resultFindSurchargeItem := db.Where("ItemID = ?", item.SurchargeItemID).
				Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&surchargeItemModel)
			if resultFindSurchargeItem.RowsAffected > 0 {
				response.SurchargeItemCode = surchargeItemModel.Code
				response.SurchargeItemName = surchargeItemModel.Name
			}
			response.TaxID = item.TaxID
			response.IncludingTax = item.IncludingTax
			response.DimensionName1 = item.DimensionName1
			response.DimensionName2 = item.DimensionName2
			response.DimensionName3 = item.DimensionName3
			response.DimensionName4 = item.DimensionName4
			response.Dimension1Enable = item.Dimension1Enable
			response.Dimension2Enable = item.Dimension2Enable
			response.Dimension3Enable = item.Dimension3Enable
			response.Dimension4Enable = item.Dimension4Enable
			response.Dimension1DataType = item.Dimension1DataType
			response.Dimension2DataType = item.Dimension2DataType
			response.Dimension3DataType = item.Dimension3DataType
			response.Dimension4DataType = item.Dimension4DataType
			response.Job4DPrices = inspectionJob4DPrices
			responses = append(responses, response)
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// ValidateEditSurcharge godoc
// @Summary ValidateEditSurcharge
// @Description ValidateEditSurcharge
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /validateeditsurcharge [get]
func ValidateEditSurcharge(c *gin.Context) {
	defer libs.RecoverError(c, "ValidateEditSurcharge")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	itemID, _ := libs.GetQueryParam("ItemID", c)
	jobID, _ := libs.GetQueryParam("JobID", c)
	key, _ := libs.GetQueryParam("Key", c)
	jobTaskType, _ := libs.GetQueryParam("JobTaskType", c)
	sql := `SELECT ijo.Status  FROM jobs ijo 
			JOIN jobtasks ijt ON ijo.JobID = ijt.JobID
			JOIN jobdetails ijd ON ijo.JobID = ijd.JobID
			JOIN jobs jo ON ijo.InspectionForJobID = jo.JobID
			JOIN job4dprices jfp ON jo.JobID = jfp.JobID
			JOIN jobtasks jt ON (jt.JobTaskID = jfp.JobTaskID AND ijd.JobTaskType = jt.JobType)
			JOIN jobdetails jd ON (jfp.ItemID = jd.ItemID AND jfp.JobTaskID = jt.JobTaskID AND jo.JobID=jd.JobID)
			WHERE IFNULL(ijo.IsDeleted, 0) <> 1 AND IFNULL(ijo.IsArchived, 0) <> 1 AND ijo.IsInspection = 1 AND jo.JobID = ? AND  jfp.ItemID = ? AND jfp.Key = ? AND ijd.JobTaskType = ?
			GROUP BY jfp.ItemID, jfp.Key, ijo.InspectionForJobID, ijo.Status `

	rowsQuery, errQuery := db.Raw(sql, jobID, itemID, key, jobTaskType).Rows()
	if errQuery == nil {
		defer rowsQuery.Close()
		for rowsQuery.Next() {
			var (
				jobStatus int
			)
			rowsQuery.Scan(&jobStatus)
			/*a) if the inspection job has status 1 = scheduled.
			Message: Surcharge cannot be modified because an inspection job has been already scheduled.
			* the user can remove the inspection from the scheduler and update the surcharge (d))

			b) if the inspection status is > 1 and <> COMPLETED
				Message: Surcharge cannot be modified because an inspection job is currently in progress.

			c) if the inspection status is COMPLETED
				Message: Surcharge cannot be modified because an inspection job has been already completed.*/
			if jobStatus != 0 {
				status = 400
				if jobStatus == 1 {
					msg = services.GetMessage(lang, "api.inspection_job_scheduled")
				} else if jobStatus > 1 && jobStatus < 7 {
					msg = services.GetMessage(lang, "api.inspection_job_in_progress")
				} else if jobStatus == 7 {
					msg = services.GetMessage(lang, "api.inspection_job_completed")
				}
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				msg = services.GetMessage(lang, "api.success")
			}
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = nil
	responsesData["totalcount"] = 0
	libs.ResponseData(responsesData, c, status)
}

// ValidateDeleteSurchargeItem godoc
// @Summary ValidateDeleteSurchargeItem
// @Description ValidateDeleteSurchargeItem
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /validatedeletesurchargeitem [get]
func ValidateDeleteSurchargeItem(c *gin.Context) {
	defer libs.RecoverError(c, "ValidateDeleteSurchargeItem")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	itemID, _ := libs.GetQueryParam("ItemID", c)
	jobID, _ := libs.GetQueryParam("JobID", c)
	key, _ := libs.GetQueryParam("Key", c)
	sql := `SELECT ijo.Status  FROM jobs ijo 
			JOIN jobtasks ijt ON ijo.JobID = ijt.JobID
			JOIN jobdetails ijd ON ijo.JobID = ijd.JobID
			JOIN jobs jo ON ijo.InspectionForJobID = jo.JobID
			JOIN job4dprices jfp ON jo.JobID = jfp.JobID
			JOIN jobtasks jt ON (jt.JobTaskID = jfp.JobTaskID AND ijd.JobTaskType = jt.JobType)
			JOIN jobdetails jd ON (jfp.ItemID = jd.ItemID AND jfp.JobTaskID = jt.JobTaskID AND jo.JobID=jd.JobID)
			WHERE IFNULL(ijo.IsDeleted, 0) <> 1 AND IFNULL(ijo.IsArchived, 0) <> 1 AND ijo.IsInspection = 1 AND jo.JobID = ? AND  jfp.ItemID = ? AND jfp.Key = ?
			GROUP BY jfp.ItemID, jfp.Key, ijo.InspectionForJobID, ijo.Status `

	rowsQuery, errQuery := db.Raw(sql, jobID, itemID, key).Rows()
	if errQuery == nil {
		defer rowsQuery.Close()
		for rowsQuery.Next() {
			var (
				jobStatus int
			)
			rowsQuery.Scan(&jobStatus)
			/*a) if the inspection job has status 1 = scheduled.
			Message: Surcharge cannot be modified because an inspection job has been already scheduled.
			* the user can remove the inspection from the scheduler and update the surcharge (d))

			b) if the inspection status is > 1 and <> COMPLETED
				Message: Surcharge cannot be modified because an inspection job is currently in progress.

			c) if the inspection status is COMPLETED
				Message: Surcharge cannot be modified because an inspection job has been already completed.*/
			if jobStatus != 0 {
				status = 400
				if jobStatus == 1 {
					msg = services.GetMessage(lang, "api.surcharge_item_scheduled")
				} else if jobStatus > 1 && jobStatus < 7 {
					msg = services.GetMessage(lang, "api.surcharge_item_in_progress")
				} else if jobStatus == 7 {
					msg = services.GetMessage(lang, "api.surcharge_item_completed")
				} else {
					msg = services.GetMessage(lang, "api.surcharge_item_used")
				}
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				msg = services.GetMessage(lang, "api.success")
			}
		}
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	libs.APIResponseData(response, c, status)
}

// CheckInspectionJob godoc
// @Summary CheckInspectionJob
// @Description CheckInspectionJob
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkinspectionjob [get]
func CheckInspectionJob(c *gin.Context) {
	defer libs.RecoverError(c, "CheckInspectionJob")
	var (
		status                 = libs.GetStatusSuccess()
		requestHeader          models.RequestHeader
		response               models.APIResponseData
		msg                    interface{}
		inspectionJobModels    []models.InspectionJobResponse
		allInspectionJobModels []models.InspectionJobResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	inspectionJobModels = make([]models.InspectionJobResponse, 0)
	allInspectionJobModels = make([]models.InspectionJobResponse, 0)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	jobID := c.Param("jobid")
	key, _ := libs.GetQueryParam("Key", c)
	//jobTaskType, _ := libs.GetQueryParam("jobtasktype", c)
	sql := `SELECT jo.JobID, jo.JobNumber, jo.Status, sc.ScheduleStartDate, jt.EndDateTime, jo.SurchargeParentItemKeys, jd.JobTaskType  FROM jobs jo
			JOIN schedules sc ON jo.JobID = sc.JobID
			JOIN jobtasks jt ON jo.JobID = jt.JobID
			JOIN jobdetails jd ON jo.JobID = jd.JobID
			WHERE IFNULL(sc.IsDeleted,0) = 0 AND IFNULL(sc.IsArchived,0) = 0 AND IFNULL(jo.IsDeleted,0) = 0 AND IFNULL(jo.IsArchived,0) = 0 
			AND jo.InspectionForJobID =  ? 
			GROUP BY jo.JobID, jo.JobNumber, jo.Status, sc.ScheduleStartDate, jt.EndDateTime, jo.SurchargeParentItemKeys, jd.JobTaskType`
	rowsQuery, errQuery := db.Raw(sql, jobID).Rows()
	if errQuery == nil {
		defer rowsQuery.Close()
		var inspectionJobModel models.InspectionJobResponse
		for rowsQuery.Next() {
			var (
				surchargeParentItemKeys string
			)
			rowsQuery.Scan(&inspectionJobModel.JobID, &inspectionJobModel.JobNumber, &inspectionJobModel.Status,
				&inspectionJobModel.SchedulerStartDate, &inspectionJobModel.CompleteDate, &surchargeParentItemKeys, &inspectionJobModel.JobTaskType)
			statusName, _ := libs.GetEnum(requestHeader, inspectionJobModel.Status, "JobStatus", lang)
			inspectionJobModel.StatusName = statusName
			if key != "" {
				keys := strings.Split(surchargeParentItemKeys, SurchargeParentItemKeySeparator)
				inspectionJobModel.SurchargeParentItemKeys = keys
				for _, k := range keys {
					if k == key {
						inspectionJobModels = append(inspectionJobModels, inspectionJobModel)
					}
					allInspectionJobModels = append(allInspectionJobModels, inspectionJobModel)
				}
			} else {
				inspectionJobModels = append(inspectionJobModels, inspectionJobModel)
			}
		}

		if len(inspectionJobModels) == 0 {
			inspectionJobModels = allInspectionJobModels
		}
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = inspectionJobModels
	responsesData["totalcount"] = len(inspectionJobModels)
	libs.ResponseData(responsesData, c, status)
}

// GetInspection4DPricesByJobTask godoc
// @Summary GetInspection4DPricesByJobTask
// @Description GetInspection4DPricesByJobTask
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getinspection4dpricesbyjobtask [get]
func GetInspection4DPricesByJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetInspection4DPricesByJobTask")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg                interface{}
		arrInspectionItems []models.InspectionItemsResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	//lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	jobTaskID := c.Param("jobtaskid")
	var (
		jobTaskModel models.JobTask
	)
	resultFindJobTask := db.Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
	if resultFindJobTask.RowsAffected > 0 {
		var (
			inspectionJobModel        models.Job
			rootJobModel              models.Job
			job4DPriceModels          []models.Job4DPrice
			arrSurchargeParentItemKey = make([]string, 0)
		)
		jobID := jobTaskModel.JobID
		var bp = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		resultFindInspectionJob := bp.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&inspectionJobModel)
		if resultFindInspectionJob.RowsAffected > 0 {
			resultFindRootJob := db.Where("JobID = ?", inspectionJobModel.InspectionForJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&rootJobModel)
			if resultFindRootJob.RowsAffected > 0 {
				surchargeParentItemKey := inspectionJobModel.SurchargeParentItemKeys
				if surchargeParentItemKey != "" {
					arrSurchargeParentItemKey = strings.Split(surchargeParentItemKey, SurchargeParentItemKeySeparator)
				}
				if len(arrSurchargeParentItemKey) > 0 {
					resultFindJob4DPrice := db.Debug().Select("ItemID,`Key`,JobTaskID").Where("JobID = ? AND `Key` in (?)", rootJobModel.JobID, arrSurchargeParentItemKey).
						Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Group("ItemID,`Key`,JobTaskID").Find(&job4DPriceModels)
					if resultFindJob4DPrice.RowsAffected > 0 {
						for _, job4DPriceModel := range job4DPriceModels {
							var jobTaskModel models.JobTask
							resultFindJobTask := db.Where("JobTaskID = ? AND JobType = ?", job4DPriceModel.JobTaskID, inspectionJobModel.JobDetails[0].JobTaskType).
								Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
							if resultFindJobTask.RowsAffected > 0 {
								var itemModel models.Item
								var inspectionItemsResponse models.InspectionItemsResponse
								resultFindItem := db.Where("ItemID = ?", job4DPriceModel.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&itemModel)
								if resultFindItem.RowsAffected > 0 {
									inspectionItemsResponse.ItemID = itemModel.ItemID
									inspectionItemsResponse.Code = itemModel.Code
									inspectionItemsResponse.Name = itemModel.Name
									inspectionItemsResponse.Description = itemModel.Description
									inspectionItemsResponse.Key = job4DPriceModel.Key
									var (
										job4DPrices []models.Job4DPrice
										responses   = make([]models.InspectionFourDPriceResponse, 0)
									)
									db.Debug().Where("ItemID = ? AND JobID = ? AND `Key` = ? AND JobTaskID = ?", job4DPriceModel.ItemID, rootJobModel.JobID, job4DPriceModel.Key, job4DPriceModel.JobTaskID).
										Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
									for _, it := range job4DPrices {
										var fourDPrice models.FourDPrice
										db.Where("4DPriceID = ?", it.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&fourDPrice)
										response := ConvertInspection4DPriceToResponse(requestHeader, fourDPrice, rootJobModel.JobID, job4DPriceModel.ItemID, job4DPriceModel.Key, job4DPriceModel.JobTaskID)
										responses = append(responses, response)
									}
									inspectionItemsResponse.InspectionJob4DPrices = responses
									arrInspectionItems = append(arrInspectionItems, inspectionItemsResponse)
								}
							}
						}
					}
				}
			}
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = arrInspectionItems
	responsesData["totalcount"] = len(arrInspectionItems)
	libs.ResponseData(responsesData, c, status)
}

// GetInspection4DPricesItems godoc
// @Summary GetInspection4DPricesItems
// @Description GetInspection4DPricesItems
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getinspectionitems [get]
func GetInspection4DPricesItems(c *gin.Context) {
	defer libs.RecoverError(c, "GetInspection4DPricesItems")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg                interface{}
		arrInspectionItems []models.InspectionItemResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse := make([]models.ErrorResponse, 0)

	jobID, _ := libs.GetQueryParam("JobID", c)

	var (
		inspectionJobModel        models.Job
		rootJobModel              models.Job
		job4DPriceModels          []models.Job4DPrice
		arrSurchargeParentItemKey = make([]string, 0)
	)
	var bp = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	resultFindInspectionJob := bp.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&inspectionJobModel)
	if resultFindInspectionJob.RowsAffected > 0 {
		resultFindRootJob := db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
			Where("JobID = ?", inspectionJobModel.InspectionForJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&rootJobModel)
		if resultFindRootJob.RowsAffected > 0 {
			surchargeParentItemKey := inspectionJobModel.SurchargeParentItemKeys
			if surchargeParentItemKey != "" {
				arrSurchargeParentItemKey = strings.Split(surchargeParentItemKey, SurchargeParentItemKeySeparator)
			}
			if len(arrSurchargeParentItemKey) > 0 {
				resultFindJob4DPrice := db.Debug().Select("ItemID,`Key`,JobTaskID").Where("JobID = ? AND `Key` in (?)", rootJobModel.JobID, arrSurchargeParentItemKey).
					Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Group("ItemID,`Key`,JobTaskID").Find(&job4DPriceModels)
				if resultFindJob4DPrice.RowsAffected > 0 {
					for _, job4DPriceModel := range job4DPriceModels {
						var jobTaskModel models.JobTask
						resultFindJobTask := db.Where("JobTaskID = ? AND JobType = ?", job4DPriceModel.JobTaskID, inspectionJobModel.JobDetails[0].JobTaskType).
							Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
						if resultFindJobTask.RowsAffected > 0 {
							var itemModel models.Item
							var inspectionItemResponse models.InspectionItemResponse
							resultFindItem := db.Where("ItemID = ?", job4DPriceModel.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&itemModel)
							if resultFindItem.RowsAffected > 0 {
								inspectionItemResponse.ItemID = itemModel.ItemID
								inspectionItemResponse.Code = itemModel.Code
								inspectionItemResponse.Name = itemModel.Name
								inspectionItemResponse.Description = itemModel.Description
								inspectionItemResponse.Key = job4DPriceModel.Key
								for _, jobDetail := range rootJobModel.JobDetails {
									if jobDetail.ItemID == itemModel.ItemID && jobDetail.Key == job4DPriceModel.Key {
										inspectionItemResponse.FourDPriceDynamicFormID = jobDetail.FourDPriceDynamicFormID
										break
									}
								}
								arrInspectionItems = append(arrInspectionItems, inspectionItemResponse)
							}
						}
					}
				}
			}
		}
	}
	responses := arrInspectionItems
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = len(arrInspectionItems)
	libs.ResponseData(responsesData, c, status)
}

// Get4DPrice godoc
// @Summary Get 4DPrice
// @Description Get 4DPrice
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /4dprice [get]
func Get4DPrice(c *gin.Context) {
	defer libs.RecoverError(c, "Get4DPrice")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FourDPrice
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("FourDimensionsPriceDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("FourDimensionsItems", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"4DPriceName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArray4DPriceToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// Get4DPriceByID godoc
// @Summary Get 4DPrice By ID
// @Description Get 4DPrice By ID
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param id path int true "Distance Price List ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /4dprice/{id} [get]
func Get4DPriceByID(c *gin.Context) {
	defer libs.RecoverError(c, "Get4DPriceByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.FourDPrice
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"FourDimensionsPriceDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"FourDimensionsItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND 4DPriceID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := Convert4DPriceToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// Create4DPrice godoc
// @Summary Create4DPrice
// @Description Create4DPrice
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param 4DPrice body []models.FourDPriceResponse true "Create 4DPrice"
// @Success 200 {object} models.APIResponseData
// @Router /4dprice [post]
func Create4DPrice(c *gin.Context) {
	defer libs.RecoverError(c, "Create4DPrice")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.FourDPrice
	)
	resModel.PassBodyJSONToModel(bp)
	resModel.CreatedBy = accountKey
	resModel.ModifiedBy = accountKey
	for i := range resModel.FourDimensionsPriceDetails {
		resModel.FourDimensionsPriceDetails[i].CreatedBy = accountKey
		resModel.FourDimensionsPriceDetails[i].ModifiedBy = accountKey
	}
	for i := range resModel.FourDimensionsItems {
		resModel.FourDimensionsItems[i].CreatedBy = accountKey
		resModel.FourDimensionsItems[i].ModifiedBy = accountKey
	}
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)

		res2B, _ := json.Marshal(resModel)
		fmt.Println("resModel: ")
		fmt.Println(string(res2B))

		resultCreate := db.Create(&resModel)
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {
			data = Convert4DPriceToResponse(requestHeader, resModel)
			totalUpdatedRecord++
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// Update4DPrice godoc
// @Summary Update4DPrice
// @Description Update4DPrice
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param 4DPrice body []models.FourDPriceResponse true "Update 4DPrice"
// @Success 200 {object} models.APIResponseData
// @Router /4dprice/{id} [put]
func Update4DPrice(c *gin.Context) {
	defer libs.RecoverError(c, "Update4DPrice")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.FourDPrice
	)
	resultFind := db.Preload(
		"FourDimensionsPriceDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"FourDimensionsItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND 4DPriceID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		oldSurchargeItemID := resModel.SurchargeItemID
		resModel.PassBodyJSONToModel(bp)
		newSurchargeItemID := resModel.SurchargeItemID
		var job4DPrice models.Job4DPrice
		resultFindJob4DPrice := db.Where("4DPriceID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPrice)
		if resultFindJob4DPrice.RowsAffected > 0 && oldSurchargeItemID != newSurchargeItemID {
			errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.4dprice_cannot_change_surcharge_item_used"))
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resModel.FourDPriceID = id
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError  string
					arrSkipID     []int
					arrSkipItemID []int
				)
				for i := range resModel.FourDimensionsPriceDetails {
					if resModel.FourDimensionsPriceDetails[i].CreatedBy <= 0 {
						resModel.FourDimensionsPriceDetails[i].CreatedBy = accountKey
					}
					resModel.FourDimensionsPriceDetails[i].ModifiedBy = accountKey
				}
				for i := range resModel.FourDimensionsItems {
					if resModel.FourDimensionsItems[i].CreatedBy <= 0 {
						resModel.FourDimensionsItems[i].CreatedBy = accountKey
					}
					resModel.FourDimensionsItems[i].ModifiedBy = accountKey
				}

				// @TODO need to required > 0 for details
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					for i := range resModel.FourDimensionsPriceDetails {
						arrSkipID = append(arrSkipID, resModel.FourDimensionsPriceDetails[i].FourDPriceDetailID)
					}
					if len(arrSkipID) > 0 {
						db.Where("4DPriceID = ? AND 4DPriceDetailID not in (?)", resModel.FourDPriceID, arrSkipID).Model(&models.FourDPriceDetail{}).Updates(models.FourDPriceDetail{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("4DPriceID = ?", arrSkipID).Model(&models.FourDPriceDetail{}).Updates(models.FourDPriceDetail{IsDeleted: true, ModifiedBy: accountKey})
					}

					for i := range resModel.FourDimensionsItems {
						arrSkipItemID = append(arrSkipItemID, resModel.FourDimensionsItems[i].FourDPriceItemID)
					}
					if len(arrSkipItemID) > 0 {
						db.Where("4DPriceID = ? AND 4DPriceItemID not in (?)", resModel.FourDPriceID, arrSkipItemID).Model(&models.FourDPriceItem{}).Updates(models.FourDPriceItem{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("4DPriceID = ?", arrSkipItemID).Model(&models.FourDPriceItem{}).Updates(models.FourDPriceItem{IsDeleted: true, ModifiedBy: accountKey})
					}
				}
				resultRow := db.Preload(
					"FourDimensionsPriceDetails",
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"FourDimensionsItems",
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND 4DPriceID = ?", id).First(&resModel)
				if resultRow.RowsAffected > 0 {
					responses := Convert4DPriceToResponse(requestHeader, resModel)
					data = responses
				} else {
					errResponse := GetErrorResponseNotFound(lang, 0)
					errorsResponse = append(errorsResponse, errResponse)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// Delete4DPrice godoc
// @Summary Delete 4DPrice
// @Description Delete 4DPrice
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /4dprice/{id} [delete]
func Delete4DPrice(c *gin.Context) {
	defer libs.RecoverError(c, "Delete4DPrice")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.FourDPrice
		)
		resultFind := db.Where("4DPriceID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
		if resultFind.RowsAffected > 0 {
			var (
				job4DPriceModels    []models.Job4DPrice
				arrParentJobID      = make([]int, 0)
				hasDelete           = true
				hasStatus           int
				jobInspectionModels []models.Job
				jobParentModels     []models.Job
			)
			db.Where("4DPriceID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPriceModels)
			for _, job4DPriceModel := range job4DPriceModels {
				arrParentJobID = append(arrParentJobID, job4DPriceModel.JobID)
			}
			if len(arrParentJobID) > 0 {
				db.Where("InspectionForJobID in (?)", arrParentJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobInspectionModels)
				for _, jobInspectionModel := range jobInspectionModels {
					if jobInspectionModel.Status != 0 {
						hasDelete = false
						hasStatus = jobInspectionModel.Status
						break
					}
				}
				if hasDelete {
					db.Where("JobID in (?)", arrParentJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobParentModels)
					for _, jobParentModel := range jobParentModels {
						if jobParentModel.Status != 0 {
							hasDelete = false
							hasStatus = jobParentModel.Status
							break
						}
					}
				}
			}
			if hasDelete {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// @TODO delete detail
					db.Where("4DPriceID = ?", id).Model(&models.FourDPriceDetail{}).Updates(models.FourDPriceDetail{IsDeleted: true, ModifiedBy: accountKey})
					db.Where("4DPriceID = ?", id).Model(&models.FourDPriceItem{}).Updates(models.FourDPriceItem{IsDeleted: true, ModifiedBy: accountKey})
				}
			} else {
				errDeleteMsgKey := ""
				if hasStatus == 1 {
					errDeleteMsgKey = "api.4dprice_job_scheduled"
				} else if hasStatus > 1 && hasStatus < 7 {
					errDeleteMsgKey = "api.4dprice_job_in_progress"
				} else if hasStatus == 7 {
					errDeleteMsgKey = "api.4dprice_job_completed"
				} else {
					errDeleteMsgKey = "api.4dprice_cannot_delete"
				}
				errResponse := GetErrorResponseErrorMessage(k, services.GetMessage(lang, errDeleteMsgKey))
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// Get4DPriceByPOST godoc
// @Summary Get4DPriceByPOST
// @Description Get4DPriceByPOST
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param 4DPrice body []models.FourDPricePOST true "Get4DPriceByPOST"
// @Success 200 {object} models.APIResponseData
// @Router /get4dprice/{itemid} [put]
func Get4DPriceByPOST(c *gin.Context) {
	defer libs.RecoverError(c, "Get4DPriceByPOST")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	// accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	itemID, _ := strconv.Atoi(c.Param("itemid"))
	var (
		arrFourDPricePOST         []models.FourDPricePOST
		arrFourDPricePOSTResponse = make([]models.FourDPricePOSTResponse, 0)
		item                      models.Item
	)

	// Get item
	db.Where(
		"ItemID = ?", itemID,
	).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&item)

	json.NewDecoder(c.Request.Body).Decode(&arrFourDPricePOST)
	for _, fourDPricePOST := range arrFourDPricePOST {
		var fourDPricePOSTResponse models.FourDPricePOSTResponse

		fourDPricePOSTResponse.ItemID = itemID
		fourDPricePOSTResponse.FourDPriceID = fourDPricePOST.FourDPriceID
		fourDPricePOSTResponse.Dimension1 = fourDPricePOST.Dimension1
		fourDPricePOSTResponse.Dimension2 = fourDPricePOST.Dimension2
		fourDPricePOSTResponse.Dimension3 = fourDPricePOST.Dimension3
		fourDPricePOSTResponse.Dimension4 = fourDPricePOST.Dimension4
		fourDPricePOSTResponse.JobTaskType = fourDPricePOST.JobTaskType

		if fourDPricePOST.FourDPriceID > 0 {
			var fourDPriceModel models.FourDPrice
			resultFind4DPrice := db.Where("4DPriceID = ?", fourDPricePOST.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&fourDPriceModel)
			if resultFind4DPrice.RowsAffected > 0 {
				var (
					itemDetailModels        []models.FourDPriceDetail
					exist4DPriceDetailModel models.FourDPriceDetail
				)
				db.Where("4DPriceID = ?", fourDPriceModel.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&itemDetailModels)
				for _, itemDetailModel := range itemDetailModels {
					existPrice := true
					if existPrice {
						if fourDPriceModel.Dimension1Enable {
							dimensionPOST := fourDPricePOST.Dimension1
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension1
							dimensionDataType := fourDPriceModel.Dimension1DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension2Enable {
							dimensionPOST := fourDPricePOST.Dimension2
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension2
							dimensionDataType := fourDPriceModel.Dimension2DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension3Enable {
							dimensionPOST := fourDPricePOST.Dimension3
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension3
							dimensionDataType := fourDPriceModel.Dimension3DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension4Enable {
							dimensionPOST := fourDPricePOST.Dimension4
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension4
							dimensionDataType := fourDPriceModel.Dimension4DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}

					if existPrice {
						if exist4DPriceDetailModel.FourDPriceDetailID > 0 {
							if exist4DPriceDetailModel.Price > itemDetailModel.Price { // Min
								exist4DPriceDetailModel = itemDetailModel
							} else {
								if exist4DPriceDetailModel.Price == itemDetailModel.Price {
									if !itemDetailModel.TriggerInspection {
										exist4DPriceDetailModel = itemDetailModel
									}
								}
							}
						} else {
							exist4DPriceDetailModel = itemDetailModel
						}
					}
				}

				if exist4DPriceDetailModel.FourDPriceDetailID > 0 {
					fourDPricePOSTResponse.FourDPriceDetailID = exist4DPriceDetailModel.FourDPriceDetailID
					fourDPricePOSTResponse.Price = exist4DPriceDetailModel.Price
					fourDPricePOSTResponse.TriggerInspection = exist4DPriceDetailModel.TriggerInspection
				}
				// find SurchargeItem
				var surchargeItemModel models.Item
				resultFindSurchargeItem := db.Preload(
					"RelatedItems", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where(
					"ItemID = ?", fourDPriceModel.SurchargeItemID,
				).Where(
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).First(&surchargeItemModel)
				if resultFindSurchargeItem.RowsAffected > 0 {
					itemResponse := ConvertItemToResponse(requestHeader, surchargeItemModel, lang)
					itemResponse.UnitPrice = fourDPricePOSTResponse.Price
					itemResponse.Description = fourDPriceModel.FourDPriceName + " - " + itemResponse.Description + " - " + item.Name // @TOTO - Calculate - 4DPrice Name - Description - Parent Item Name
					itemResponse.SurchargeParentItemID = itemID
					itemResponse.JobTaskType = fourDPricePOST.JobTaskType
					fourDPricePOSTResponse.SurchargeItem = &itemResponse
					fourDPricePOSTResponse.SurchargeItemID = itemResponse.ItemID
				}
			}
		}
		arrFourDPricePOSTResponse = append(arrFourDPricePOSTResponse, fourDPricePOSTResponse)
		totalUpdatedRecord++
	}
	data = arrFourDPricePOSTResponse
	errors = errorsResponse
	status, msg = GetStatusState("GET", lang, totalUpdatedRecord, len(arrFourDPricePOST), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CalcInspection4DPrices godoc
// @Summary CalcInspection4DPrices
// @Description CalcInspection4DPrices
// @Tags 4DPrice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param 4DPrice body []models.FourDPricePOST true "Calc Inspection 4DPrices"
// @Success 200 {object} models.APIResponseData
// @Router /calcinspection4dprices [put]
func CalcInspection4DPrices(c *gin.Context) {
	defer libs.RecoverError(c, "CalcInspection4DPrices")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array

	var (
		arrCalcInspection4DPricePOST []models.CalcInspection4DPricePOST
		arrJob4DPriceResponse        = make([]models.Job4DPriceResponse, 0)
	)
	json.NewDecoder(c.Request.Body).Decode(&arrCalcInspection4DPricePOST)
	res2B, _ := json.Marshal(arrCalcInspection4DPricePOST)
	fmt.Println(string(res2B))
	for _, calcInspection4DPricePOST := range arrCalcInspection4DPricePOST {
		for _, fourDPrice := range calcInspection4DPricePOST.FourDPrices {
			var (
				job4DPriceResponse models.Job4DPriceResponse
				fourDPriceModel    models.FourDPrice
				newPrice           float64
				triggerInspection  = false
			)
			resultFind4DPrice := db.Where("4DPriceID = ?", fourDPrice.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&fourDPriceModel)
			if resultFind4DPrice.RowsAffected > 0 {
				// find Price
				var (
					itemDetailModels        []models.FourDPriceDetail
					exist4DPriceDetailModel models.FourDPriceDetail
				)
				db.Where("4DPriceID = ?", fourDPriceModel.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&itemDetailModels)
				for _, itemDetailModel := range itemDetailModels {
					existPrice := true
					if existPrice {
						if fourDPriceModel.Dimension1Enable {
							dimensionPOST := fourDPrice.Dimension1
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension1
							dimensionDataType := fourDPriceModel.Dimension1DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension2Enable {
							dimensionPOST := fourDPrice.Dimension2
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension2
							dimensionDataType := fourDPriceModel.Dimension2DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension3Enable {
							dimensionPOST := fourDPrice.Dimension3
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension3
							dimensionDataType := fourDPriceModel.Dimension3DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if fourDPriceModel.Dimension4Enable {
							dimensionPOST := fourDPrice.Dimension4
							fourDPricePOSTDimension := fmt.Sprintf("%v", dimensionPOST)
							dimensionItem := itemDetailModel.Dimension4
							dimensionDataType := fourDPriceModel.Dimension4DataType
							existPrice = Compare4DPriceDimension(fourDPricePOSTDimension, dimensionItem, dimensionDataType)
						}
					}
					if existPrice {
						if exist4DPriceDetailModel.FourDPriceDetailID > 0 {
							if exist4DPriceDetailModel.Price > itemDetailModel.Price { // Min
								exist4DPriceDetailModel = itemDetailModel
							} else {
								if exist4DPriceDetailModel.Price == itemDetailModel.Price {
									if !itemDetailModel.TriggerInspection {
										exist4DPriceDetailModel = itemDetailModel
									}
								}
							}
						} else {
							exist4DPriceDetailModel = itemDetailModel
						}
					}
				}
				if exist4DPriceDetailModel.FourDPriceDetailID > 0 {
					newPrice = exist4DPriceDetailModel.Price
					triggerInspection = exist4DPriceDetailModel.TriggerInspection
				}
			}

			if fourDPrice.Job4DPriceID > 0 {
				var job4DPriceModel models.Job4DPrice
				resultFindJob4DPrice := db.Where("JobID = ? AND JobTaskID = ? AND ItemID = ? AND `Key` = ? AND 4DPriceID = ?",
					calcInspection4DPricePOST.JobID, calcInspection4DPricePOST.JobTaskID, calcInspection4DPricePOST.ItemID, calcInspection4DPricePOST.Key, fourDPrice.FourDPriceID).
					Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPriceModel)
				if !fourDPrice.Skip {
					// Update jobdetail & job info
					UpdateInfoAfterCalcInspection4DPrice(requestHeader, lang, accountKey, calcInspection4DPricePOST, fourDPrice.SurchargeItemID, newPrice)

					if resultFindJob4DPrice.RowsAffected > 0 {
						dimension1 := fmt.Sprintf("%v", fourDPrice.Dimension1)
						dimension2 := fmt.Sprintf("%v", fourDPrice.Dimension2)
						dimension3 := fmt.Sprintf("%v", fourDPrice.Dimension3)
						dimension4 := fmt.Sprintf("%v", fourDPrice.Dimension4)
						job4DPriceModel.Dimension1 = dimension1
						job4DPriceModel.Dimension2 = dimension2
						job4DPriceModel.Dimension3 = dimension3
						job4DPriceModel.Dimension4 = dimension4
						job4DPriceModel.TriggerInspectionCompleted = true
						job4DPriceModel.ModifiedBy = accountKey
						db.Save(&job4DPriceModel)
						job4DPriceResponse = ConvertJob4DPriceToResponse(requestHeader, job4DPriceModel)
						arrJob4DPriceResponse = append(arrJob4DPriceResponse, job4DPriceResponse)
					}
				} else { // Delete Job 4D Price
					if resultFindJob4DPrice.RowsAffected > 0 {
						sqlDelete := `DELETE FROM ` + models.Job4DPrice{}.TableName() + ` WHERE Job4DPriceID = ?`
						err := db.Exec(sqlDelete, fourDPrice.Job4DPriceID).Error
						if err == nil {
							sqlDelete := "DELETE FROM " + models.JobDetail{}.TableName() + " WHERE JobID = ? AND ItemID = ? AND `Key` = ?"
							err := db.Exec(sqlDelete, job4DPriceModel.JobID, job4DPriceModel.SurchargeItemID, job4DPriceModel.Key).Error
							if err == nil { // Recalculate Job
								var jobModel models.Job
								// update job
								var dbJob = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1")
								resultFindJob := dbJob.Where("JobID = ?", job4DPriceModel.JobID).
									Where("IFNULL(IsDeleted, 0) <> 1").First(&jobModel)
								if resultFindJob.RowsAffected > 0 {
									jobModel = CalculateJobAmount(jobModel)
									jobModel = CalculatePrice(requestHeader, jobModel)
									jobModel.ModifiedBy = accountKey
									db.Save(&jobModel)
								}
							}
						}
					}
				}
			} else {
				if !fourDPrice.Skip {
					var surchargeItemModel models.Item
					resultFindSurchargeItem := db.Where(
						"ItemID = ?", fourDPriceModel.SurchargeItemID,
					).Where(
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).First(&surchargeItemModel)
					if resultFindSurchargeItem.RowsAffected > 0 {
						var updatedJob models.Job
						var dbJob = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
						resultFindJob := dbJob.Where("JobID = ?", calcInspection4DPricePOST.JobID).
							Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&updatedJob)
						if resultFindJob.RowsAffected > 0 {
							var (
								jobTask   models.JobTask
								jobdetail models.JobDetail
							)
							itemResponse := ConvertItemToResponse(requestHeader, surchargeItemModel, lang)
							jobdetail.Quantity = 1
							jobdetail.ItemID = itemResponse.ItemID
							jobdetail.Code = itemResponse.Code
							jobdetail.TaxType = itemResponse.TaxType
							jobdetail.TaxName = itemResponse.TaxName
							jobdetail.TaxRate = itemResponse.TaxRate
							jobdetail.SurchargeParentItemID = itemResponse.ItemID

							jobdetail.UnitPrice = newPrice
							jobdetail.Description = fourDPriceModel.FourDPriceName + " - " + surchargeItemModel.Description + " - " + surchargeItemModel.Name // @TOTO - Calculate - 4DPrice Name - Description - Parent Item Name
							jobdetail.SurchargeParentItemID = calcInspection4DPricePOST.ItemID

							// Get Job Task Type
							db.Where(
								"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobTaskID = ?", calcInspection4DPricePOST.JobTaskID,
							).First(&jobTask)
							jobdetail.JobTaskType = &jobTask.JobType

							// Get Key
							for _, jd := range updatedJob.JobDetails {
								if jd.ItemID == calcInspection4DPricePOST.ItemID {
									jobdetail.Key = jd.Key
									break
								}
							}

							updatedJob.JobDetails = append(updatedJob.JobDetails, jobdetail)

							updatedJob = CalculateJobAmount(updatedJob)
							updatedJob = CalculatePrice(requestHeader, updatedJob)
							updatedJob.ModifiedBy = accountKey
							resultSave := db.Save(&updatedJob)
							if resultSave.Error == nil { // Update Job 4DPrice
								var job4DPriceModel models.Job4DPrice
								job4DPriceModel.FourDPriceID = fourDPrice.FourDPriceID
								job4DPriceModel.JobID = calcInspection4DPricePOST.JobID
								job4DPriceModel.JobTaskID = calcInspection4DPricePOST.JobTaskID
								job4DPriceModel.ItemID = calcInspection4DPricePOST.ItemID
								job4DPriceModel.TriggerInspection = triggerInspection
								job4DPriceModel.SurchargeItemID = fourDPrice.SurchargeItemID
								job4DPriceModel.Key = jobdetail.Key
								if fourDPrice.Dimension1 == nil {
									fourDPrice.Dimension1 = ""
								}
								dimension1 := fmt.Sprintf("%v", fourDPrice.Dimension1)

								if fourDPrice.Dimension2 == nil {
									fourDPrice.Dimension2 = ""
								}
								dimension2 := fmt.Sprintf("%v", fourDPrice.Dimension2)

								if fourDPrice.Dimension3 == nil {
									fourDPrice.Dimension3 = ""
								}
								dimension3 := fmt.Sprintf("%v", fourDPrice.Dimension3)

								if fourDPrice.Dimension4 == nil {
									fourDPrice.Dimension4 = ""
								}
								dimension4 := fmt.Sprintf("%v", fourDPrice.Dimension4)
								job4DPriceModel.Dimension1 = dimension1
								job4DPriceModel.Dimension2 = dimension2
								job4DPriceModel.Dimension3 = dimension3
								job4DPriceModel.Dimension4 = dimension4
								job4DPriceModel.TriggerInspectionCompleted = true
								job4DPriceModel.ModifiedBy = accountKey
								db.Create(&job4DPriceModel)
								job4DPriceResponse = ConvertJob4DPriceToResponse(requestHeader, job4DPriceModel)
								arrJob4DPriceResponse = append(arrJob4DPriceResponse, job4DPriceResponse)
							}
						}
					}
				}
			}
		}
		totalUpdatedRecord++
	}

	data = arrJob4DPriceResponse
	errors = errorsResponse
	status, msg = GetStatusState("GET", lang, totalUpdatedRecord, len(arrCalcInspection4DPricePOST), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArray4DPriceToArrayResponse func
func ConvertArray4DPriceToArrayResponse(requestHeader models.RequestHeader, items []models.FourDPrice) []models.FourDPriceResponse {
	responses := make([]models.FourDPriceResponse, 0)
	for _, item := range items {
		response := Convert4DPriceToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// Convert4DPriceToResponse func
func Convert4DPriceToResponse(requestHeader models.RequestHeader, item models.FourDPrice) models.FourDPriceResponse {
	var (
		response models.FourDPriceResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	response.FourDPriceID = item.FourDPriceID
	response.FourDPriceName = item.FourDPriceName
	response.SurchargeItemID = item.SurchargeItemID

	var surchargeItemModel models.Item
	resultFindSurchargeItem := db.Where("ItemID = ?", item.SurchargeItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&surchargeItemModel)
	if resultFindSurchargeItem.RowsAffected > 0 {
		response.SurchargeItemCode = surchargeItemModel.Code
		response.SurchargeItemName = surchargeItemModel.Name
	}
	response.TaxID = item.TaxID
	response.IncludingTax = item.IncludingTax
	response.DimensionName1 = item.DimensionName1
	response.DimensionName2 = item.DimensionName2
	response.DimensionName3 = item.DimensionName3
	response.DimensionName4 = item.DimensionName4
	response.Dimension1Enable = item.Dimension1Enable
	response.Dimension2Enable = item.Dimension2Enable
	response.Dimension3Enable = item.Dimension3Enable
	response.Dimension4Enable = item.Dimension4Enable
	response.Dimension1DataType = item.Dimension1DataType
	response.Dimension2DataType = item.Dimension2DataType
	response.Dimension3DataType = item.Dimension3DataType
	response.Dimension4DataType = item.Dimension4DataType

	details := make([]models.FourDPriceDetailResponse, 0)
	for _, de := range item.FourDimensionsPriceDetails {
		var (
			detail models.FourDPriceDetailResponse
		)
		detail.FourDPriceDetailID = de.FourDPriceDetailID
		detail.FourDPriceID = de.FourDPriceID
		detail.Dimension1 = ConvertData4DPriceDimensionResponse(de.Dimension1, item.Dimension1DataType)
		detail.Dimension2 = ConvertData4DPriceDimensionResponse(de.Dimension2, item.Dimension2DataType)
		detail.Dimension3 = ConvertData4DPriceDimensionResponse(de.Dimension3, item.Dimension3DataType)
		detail.Dimension4 = ConvertData4DPriceDimensionResponse(de.Dimension4, item.Dimension4DataType)
		detail.Price = de.Price
		detail.TriggerInspection = de.TriggerInspection
		details = append(details, detail)
	}
	response.FourDimensionsPriceDetails = details

	detailItems := make([]models.FourDPriceItemResponse, 0)
	for _, it := range item.FourDimensionsItems {
		var detailItem models.FourDPriceItemResponse
		detailItem.FourDPriceItemID = it.FourDPriceItemID
		detailItem.ItemID = it.ItemID
		detailItem.FourDPriceID = it.FourDPriceID
		var itemModel models.Item
		resultFindItem := db.Where("ItemID = ?", it.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&itemModel)
		if resultFindItem.RowsAffected > 0 {
			detailItem.ItemCode = itemModel.Code
			detailItem.ItemName = itemModel.Name
			detailItem.ItemDescription = itemModel.Description
		}
		detailItems = append(detailItems, detailItem)
	}
	response.FourDimensionsItems = detailItems
	return response
}

func ConvertData4DPriceDimensionResponse(dimension string, dimensionDataTypeObj *int) interface{} {
	var resData interface{}
	if dimensionDataTypeObj != nil {
		dimensionDataType := *dimensionDataTypeObj
		switch dimensionDataType {
		case models.DimensionDataTypeInt:
			dDimension, sDimension := strconv.Atoi(dimension)
			if sDimension == nil {
				return dDimension
			}
		case models.DimensionDataTypeFloat:
			fDimension, sDimension := strconv.ParseFloat(dimension, 64)
			if sDimension == nil {
				return fDimension
			}
		case models.DimensionDataTypeBoolean:
			bDimension, sDimension := strconv.ParseBool(dimension)
			if sDimension == nil {
				return bDimension
			}
		}
	}
	resData = dimension
	return resData
}

func Compare4DPriceDimension(dimensionPOST string, dimensionDetail string, dimensionDataTypeObj *int) bool {
	var existPrice = false
	if dimensionDataTypeObj != nil {
		dimensionDataType := *dimensionDataTypeObj
		switch dimensionDataType {
		case models.DimensionDataTypeInt:
			dDimensionPOST, sDimensionPOST := strconv.Atoi(dimensionPOST)
			dDimensionDetail, sDimensionDetail := strconv.Atoi(dimensionDetail)
			if sDimensionPOST == nil && sDimensionDetail == nil {
				if dDimensionPOST < 0 || dDimensionPOST <= dDimensionDetail {
					existPrice = true
				}
			}
		case models.DimensionDataTypeFloat:
			fDimensionPOST, sDimensionPOST := strconv.ParseFloat(dimensionPOST, 64)
			fDimensionDetail, sDimensionDetail := strconv.ParseFloat(dimensionDetail, 64)
			if sDimensionPOST == nil && sDimensionDetail == nil {
				if fDimensionPOST < 0 || fDimensionPOST <= fDimensionDetail {
					existPrice = true
				}
			}
		case models.DimensionDataTypeBoolean:
			bDimensionPOST, sDimensionPOST := strconv.ParseBool(dimensionPOST)
			bDimensionDetail, sDimensionDetail := strconv.ParseBool(dimensionDetail)
			if sDimensionPOST == nil && sDimensionDetail == nil {
				if bDimensionPOST == bDimensionDetail {
					existPrice = true
				}
			}
		}
	}
	return existPrice
}

// ConvertArrayInspection4DPriceToArrayResponse func
func ConvertArrayInspection4DPriceToArrayResponse(requestHeader models.RequestHeader, items []models.FourDPrice, jobID int, itemID int, key string, jobTaskID int) []models.InspectionFourDPriceResponse {
	responses := make([]models.InspectionFourDPriceResponse, 0)
	for _, item := range items {
		response := ConvertInspection4DPriceToResponse(requestHeader, item, jobID, itemID, key, jobTaskID)
		responses = append(responses, response)
	}
	return responses
}

// Convert4DPriceToResponse func
func ConvertInspection4DPriceToResponse(requestHeader models.RequestHeader, item models.FourDPrice, jobID int, itemID int, key string, jobTaskID int) models.InspectionFourDPriceResponse {
	var (
		response    models.InspectionFourDPriceResponse
		job4DPrices []models.Job4DPrice
	)
	inspectionJob4DPrices := make([]models.InspectionJob4DPrice, 0)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	response.FourDPriceID = item.FourDPriceID
	response.FourDPriceName = item.FourDPriceName
	response.SurchargeItemID = item.SurchargeItemID

	var surchargeItemModel models.Item
	resultFindSurchargeItem := db.Where("ItemID = ?", item.SurchargeItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&surchargeItemModel)
	if resultFindSurchargeItem.RowsAffected > 0 {
		response.SurchargeItemCode = surchargeItemModel.Code
		response.SurchargeItemName = surchargeItemModel.Name
	}
	response.TaxID = item.TaxID
	response.IncludingTax = item.IncludingTax
	response.DimensionName1 = item.DimensionName1
	response.DimensionName2 = item.DimensionName2
	response.DimensionName3 = item.DimensionName3
	response.DimensionName4 = item.DimensionName4
	response.Dimension1Enable = item.Dimension1Enable
	response.Dimension2Enable = item.Dimension2Enable
	response.Dimension3Enable = item.Dimension3Enable
	response.Dimension4Enable = item.Dimension4Enable
	response.Dimension1DataType = item.Dimension1DataType
	response.Dimension2DataType = item.Dimension2DataType
	response.Dimension3DataType = item.Dimension3DataType
	response.Dimension4DataType = item.Dimension4DataType
	if jobTaskID > 0 {
		db.Where("4DPriceID = ? AND JobID = ? AND ItemID = ? AND `Key` = ? AND JobTaskID = ?", item.FourDPriceID, jobID, itemID, key, jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
	} else {
		db.Where("4DPriceID = ? AND JobID = ? AND ItemID = ? AND `Key` = ?", item.FourDPriceID, jobID, itemID, key).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
	}

	for _, item := range job4DPrices {
		var inspectionJob4DPrice models.InspectionJob4DPrice
		inspectionJob4DPrice.Job4DPriceID = item.Job4DPriceID
		inspectionJob4DPrice.FourDPriceID = item.FourDPriceID
		inspectionJob4DPrice.JobID = item.JobID
		inspectionJob4DPrice.JobTaskID = item.JobTaskID
		inspectionJob4DPrice.ItemID = item.ItemID
		inspectionJob4DPrice.SurchargeItemID = item.SurchargeItemID
		inspectionJob4DPrice.Dimension1 = ConvertData4DPriceDimensionResponse(item.Dimension1, response.Dimension1DataType)
		inspectionJob4DPrice.Dimension2 = ConvertData4DPriceDimensionResponse(item.Dimension2, response.Dimension2DataType)
		inspectionJob4DPrice.Dimension3 = ConvertData4DPriceDimensionResponse(item.Dimension3, response.Dimension3DataType)
		inspectionJob4DPrice.Dimension4 = ConvertData4DPriceDimensionResponse(item.Dimension4, response.Dimension4DataType)
		inspectionJob4DPrice.TriggerInspection = item.TriggerInspection
		inspectionJob4DPrice.TriggerInspectionCompleted = item.TriggerInspectionCompleted
		inspectionJob4DPrice.Key = item.Key
		inspectionJob4DPrice.TriggerInspectionMode = item.TriggerInspectionMode
		inspectionJob4DPrices = append(inspectionJob4DPrices, inspectionJob4DPrice)
	}
	response.Job4DPrices = inspectionJob4DPrices
	return response
}

func UpdateInfoAfterCalcInspection4DPrice(requestHeader models.RequestHeader, lang string, accountKey int, calcInspection4DPricePOST models.CalcInspection4DPricePOST, surchargeItemID int, newPrice float64) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		jobDetailModel models.JobDetail
		jobModel       models.Job
		jobTask        models.JobTask
	)
	db.Where("JobTaskID = ?", calcInspection4DPricePOST.JobTaskID).
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)

	// update jobdetail
	resultFindJobDetail := db.Where("JobID = ? AND ItemID = ? AND `Key` = ? AND JobTaskType = ?",
		calcInspection4DPricePOST.JobID, surchargeItemID, calcInspection4DPricePOST.Key, jobTask.JobType).
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobDetailModel)
	if resultFindJobDetail.RowsAffected > 0 {
		newUnitPrice := newPrice
		jobDetailModel.UnitPrice = newUnitPrice
		jobDetailModel.LineTotal = newUnitPrice * jobDetailModel.Quantity
		jobDetailModel.LineSubTotal = jobDetailModel.UnitPrice * jobDetailModel.Quantity
		jobDetailModel.DiscountAmount = jobDetailModel.LineSubTotal * (jobDetailModel.DiscountPercent / 100)
		jobDetailModel.BufferAmount = jobDetailModel.LineSubTotal * (jobDetailModel.BufferPercent / 100)
		jobDetailModel.LineTotalTaxExcluded = jobDetailModel.LineSubTotal - jobDetailModel.DiscountAmount + jobDetailModel.BufferAmount
		jobDetailModel.LineTotalTax = jobDetailModel.LineTotalTaxExcluded * (jobDetailModel.TaxRate / 100)
		jobDetailModel.LineTotal = jobDetailModel.LineTotalTaxExcluded + jobDetailModel.LineTotalTax
		jobDetailModel.ModifiedBy = accountKey
		db.Save(&jobDetailModel)
		// update job
		var dbJob = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		resultFindJob := dbJob.Where("JobID = ?", calcInspection4DPricePOST.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected > 0 {
			jobModel = CalculateJobAmount(jobModel)
			jobModel = CalculatePrice(requestHeader, jobModel)
			jobModel.ModifiedBy = accountKey
			db.Save(&jobModel)
		}
	}
}

func ConvertJob4DPriceToResponse(requestHeader models.RequestHeader, job4DPriceModel models.Job4DPrice) models.Job4DPriceResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var job4DPriceResponse models.Job4DPriceResponse
	job4DPriceResponse.Job4DPriceID = job4DPriceModel.Job4DPriceID
	job4DPriceResponse.FourDPriceID = job4DPriceModel.FourDPriceID
	job4DPriceResponse.JobID = job4DPriceModel.JobID
	job4DPriceResponse.JobTaskID = job4DPriceModel.JobTaskID
	job4DPriceResponse.ItemID = job4DPriceModel.ItemID
	job4DPriceResponse.Key = job4DPriceModel.Key
	job4DPriceResponse.SurchargeItemID = job4DPriceModel.SurchargeItemID
	var fourDPriceModel models.FourDPrice
	resultFind4DPrice := db.Where("4DPriceID = ?", job4DPriceModel.FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&fourDPriceModel)
	if resultFind4DPrice.RowsAffected > 0 {
		job4DPriceResponse.Dimension1 = ConvertData4DPriceDimensionResponse(job4DPriceModel.Dimension1, fourDPriceModel.Dimension1DataType)
		job4DPriceResponse.Dimension2 = ConvertData4DPriceDimensionResponse(job4DPriceModel.Dimension2, fourDPriceModel.Dimension2DataType)
		job4DPriceResponse.Dimension3 = ConvertData4DPriceDimensionResponse(job4DPriceModel.Dimension3, fourDPriceModel.Dimension3DataType)
		job4DPriceResponse.Dimension4 = ConvertData4DPriceDimensionResponse(job4DPriceModel.Dimension4, fourDPriceModel.Dimension4DataType)
	} else {
		job4DPriceResponse.Dimension1 = job4DPriceModel.Dimension1
		job4DPriceResponse.Dimension2 = job4DPriceModel.Dimension2
		job4DPriceResponse.Dimension3 = job4DPriceModel.Dimension3
		job4DPriceResponse.Dimension4 = job4DPriceModel.Dimension4
	}
	job4DPriceResponse.TriggerInspection = job4DPriceModel.TriggerInspection
	job4DPriceResponse.TriggerInspectionCompleted = job4DPriceModel.TriggerInspectionCompleted
	job4DPriceResponse.TriggerInspectionMode = job4DPriceModel.TriggerInspectionMode
	return job4DPriceResponse
}
