package controllers

import (
	"encoding/json"
	"io/ioutil"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetXeroPayment godoc
// @Summary Get Xero Payment
// @Description Xero Payment
// @Tags XeroPayment
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/payment [get]
func GetXeroPayment(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroPayment")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	representURL := "Payments"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetXeroPaymentByID godoc
// @Summary Get Xero Payment By ID
// @Description Get Xero Payment By ID
// @Tags XeroPayment
// @Accept  json
// @Produce  json
// @Param id path int true "XeroPayment ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/payment/{id} [get]
func GetXeroPaymentByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroPaymentByID")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	ID := c.Param("id")
	representURL := "Payments/" + ID
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateXeroPayment godoc
// @Summary Create Xero Payment
// @Description Create Xero Payment
// @Tags XeroPayment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Xero Payment"
// @Success 200 {object} models.APIResponseData
// @Router /xero/payment [post]
func CreateXeroPayment(c *gin.Context) {
	defer libs.RecoverError(c, "CreateXeroPayment")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		dataPOST      map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		json.Unmarshal([]byte(string(body)), &dataPOST)
		requestBody := dataPOST
		representURL := "Payments"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "PUT", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			data = dataRes
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
