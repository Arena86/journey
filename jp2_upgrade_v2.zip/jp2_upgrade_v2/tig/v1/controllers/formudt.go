package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetFormUDT godoc
// @Summary Get FormUDT
// @Description Get FormUDT
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt [get]
func GetFormUDT(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormUDT")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormUDT
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("FormUDFs", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"TableName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"DraftDynamicFormID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayFormUDTToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetFormUDTByID godoc
// @Summary Get FormUDT By ID
// @Description Get FormUDT By ID
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param id path int true "Distance Price List ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/getbyid/{id} [get]
func GetFormUDTByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormUDTByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.FormUDT
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"FormUDFs",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormUDTID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertFormUDTToResponse(resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetFormUDTByFormID godoc
// @Summary Get GetFormUDTByFormID
// @Description Get GetFormUDTByFormID
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param id path int true "Form ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/getbyform/{formid} [get]
func GetFormUDTByFormID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormUDTByFormID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormUDT
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	formID := c.Param("formid")
	db.Preload(
		"FormUDFs",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DraftDynamicFormID = ?", formID).Find(&resModels)
	msg = services.GetMessage(lang, "api.success")
	responses := ConvertArrayFormUDTToArrayResponse(resModels)
	data = responses
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetFormUDTByTableName godoc
// @Summary Get GetFormUDTByTableName
// @Description Get GetFormUDTByTableName
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param id path int true "Form ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/getformbytablename/{tablename} [get]
func GetFormUDTByTableName(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormUDTByTableName")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormUDT
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	tableName := c.Param("tablename")
	db.Preload(
		"FormUDFs",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TableName = ?", tableName).Find(&resModels)
	msg = services.GetMessage(lang, "api.success")
	responses := ConvertArrayFormUDTToArrayResponse(resModels)
	data = responses
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateFormUDT godoc
// @Summary Create FormUDT
// @Description Create FormUDT
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormUDT body []models.FormUDTResponse true "Create FormUDT"
// @Success 200 {object} models.APIResponseData
// @Router /formudt [post]
func CreateFormUDT(c *gin.Context) {
	defer libs.RecoverError(c, "CreateFormUDT")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.FormUDT
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate
	resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TableName = ?", resModel.TableNameObj).First(&models.FormUDT{})
	if resultCheckExist.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.tablename_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resModel.CreatedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO validate for details
			validateMap := make(map[string]interface{})
			for i, d := range resModel.FormUDFs {
				resModel.FormUDFs[i].CreatedBy = accountKey
				if _, ok := validateMap[d.DataField]; ok {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.datafield_exist"))
					break
				} else {
					validateMap[d.DataField] = true
				}
			}
			if itemMsgError == "" {
				resultCreate := db.Create(&resModel)
				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {
					data = ConvertFormUDTToResponse(resModel)
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateFormUDT godoc
// @Summary Update FormUDT
// @Description Update FormUDT
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormUDT body []models.FormUDTResponse true "Update FormUDT"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/{id} [put]
func UpdateFormUDT(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateFormUDT")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.FormUDT
	)
	resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormUDTID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TableName = ? AND FormUDTID <> ?", resModel.TableNameObj, resModel.FormUDTID).First(&models.FormUDT{})
		if resultCheckExist.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.tablename_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resModel.FormUDTID = id
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
					res          interface{}
				)
				// @TODO validate for details
				validateMap := make(map[string]interface{})
				for i, d := range resModel.FormUDFs {
					resModel.FormUDFs[i].CreatedBy = accountKey
					if _, ok := validateMap[d.DataField]; ok {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.datafield_exist"))
						break
					} else {
						validateMap[d.DataField] = true
					}
				}
				if itemMsgError == "" {
					resModel.FormUDFs = make([]models.FormUDF, 0)
					var (
						objectsDetails        []map[string]interface{}
						details               []models.FormUDF
						arrSkipID             []int
						arrToDeleteID         []int
						detailsToDeleteModels []models.FormUDF
					)
					details = make([]models.FormUDF, 0)
					_, res = services.ConvertJSONValueToVariable("FormUDFs", bp)
					if res != nil {
						objectsJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(objectsJSON, &objectsDetails)
							if len(objectsDetails) > 0 {
								for _, obj := range objectsDetails {
									var (
										detailModel models.FormUDF
									)
									detailModel.PassBodyJSONToModel(obj)
									resultFindDetails := db.Where("FormUDFID = ? AND FormUDTID = ?", detailModel.FormUDFID, resModel.FormUDTID).First(&detailModel)
									if resultFindDetails.RowsAffected > 0 {
										arrSkipID = append(arrSkipID, detailModel.FormUDFID)
										detailModel.PassBodyJSONToModel(obj)
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(detailModel)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
											}
										} else {
											detailModel.IsDeleted = false
											detailModel.ModifiedBy = accountKey
											details = append(details, detailModel)
										}
									} else {
										detailModel.PassBodyJSONToModel(obj)
										detailModel.CreatedBy = accountKey
										detailModel.FormUDFID = 0
										detailModel.FormUDTID = 0
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(detailModel)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
											}
										} else {
											detailModel.IsDeleted = false
											detailModel.ModifiedBy = accountKey
											details = append(details, detailModel)
										}
									}
								}
							}
						}
					}
					resModel.FormUDFs = details

					if len(arrSkipID) > 0 {
						// delete id not in arrSkipID
						db.Where("FormUDTID = ? AND FormUDFID not in (?)", resModel.FormUDTID, arrSkipID).Find(&detailsToDeleteModels)
					} else {
						// delete all
						db.Where("FormUDTID = ?", resModel.FormUDTID).Find(&detailsToDeleteModels)
					}
					for _, ad := range detailsToDeleteModels {
						arrToDeleteID = append(arrToDeleteID, ad.FormUDFID)
					}
					// @TODO need to required > 0 for details
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							//db.Where("FormUDFID in (?)", arrToDeleteID).Delete(&models.FormUDF{})
							db.Where("FormUDFID in (?)", arrToDeleteID).Model(&models.FormUDF{}).Updates(models.FormUDF{IsDeleted: true, ModifiedBy: accountKey})
						}
					}
					resultRow := db.Preload(
						"FormUDFs",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormUDTID = ?", id).First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertFormUDTToResponse(resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				} else {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteFormUDT godoc
// @Summary Delete FormUDT
// @Description Delete FormUDT
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/{id} [delete]
func DeleteFormUDT(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteFormUDT")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.FormUDT
		)
		resultFind := db.Where("FormUDTID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				//db.Where("FormUDTID = ?", id).Delete(&models.FormUDF{})
				db.Where("FormUDTID = ?", id).Model(&models.FormUDF{}).Updates(models.FormUDF{IsDeleted: true, ModifiedBy: accountKey})
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// GetUDTDataByDraftDynamicFormID godoc
// @Summary GetUDTDataByDraftDynamicFormID
// @Description GetUDTDataByDraftDynamicFormID
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param id path int true "Form ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/getudtdata/{draftdynamicformid} [get]
func GetUDTDataByDraftDynamicFormID(c *gin.Context) {
	defer libs.RecoverError(c, "GetUDTDataByDraftDynamicFormID")
	var (
		status = libs.GetStatusSuccess()
		//resModels             []models.FormUDT
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		msg, data             interface{}
		responsesData         gin.H
		draftDynamicFormModel models.DraftDynamicForm
		formUDTModel          models.FormUDT
		totalCount            = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	draftDynamicFormID := c.Param("draftdynamicformid")
	resultFindDraftForm := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&draftDynamicFormModel)
	if resultFindDraftForm.RowsAffected > 0 {
		resultFindFormUDT := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&formUDTModel)
		if resultFindFormUDT.RowsAffected > 0 {
			tableName := libs.GetTableNameFromUDTID(formUDTModel.DraftDynamicFormID)
			sqlQuery := `SELECT * FROM ` + tableName
			// Filter
			sqlWhere := ``
			vFilter, sFilter := c.GetQuery("filter")
			if sFilter {
				filterStr := vFilter
				if filterStr != "" {
					arrOriginals := []string{
						")AND(",
						")OR(",
						",eq,",
						",ne,",
						",nl",
						",nn",
						",lk,",
						",lt,",
						",gt,",
						",le,",
						",ge,",
					}
					arrReplaces := []string{
						") AND (",
						") OR (",
						" = ",
						" <> ",
						" IS NULL ",
						" IS NOT NULL ",
						" LIKE ",
						" < ",
						" > ",
						" <= ",
						" >= ",
					}
					filterStr = libs.StrReplaceWithArray(filterStr, arrOriginals, arrReplaces)
					if strings.Contains(filterStr, "(key") {
						filterStr = strings.Replace(filterStr, "(key", "(`key`", -1)
					}
					fmt.Println(filterStr)
					if sqlWhere != "" {
						sqlWhere = sqlWhere + ` AND `
					}
					sqlWhere = sqlWhere + filterStr
				}
			}
			if sqlWhere != "" {
				sqlWhere = sqlWhere + ` AND `
			}
			sqlWhere = sqlWhere + "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1"

			// Finished filter
			if sqlWhere != "" {
				sqlQuery = sqlQuery + ` WHERE ` + sqlWhere
			}
			// Paging
			vStart, sStart := libs.GetQueryParam("Start", c)
			vLength, sLength := libs.GetQueryParam("Length", c)
			if !sStart {
				vStart = os.Getenv("PAGE_DEFAULT")
			} else {
				iStart, eStart := strconv.Atoi(vStart)
				if eStart == nil {
					iStart = iStart - 1
					if iStart < 0 {
						iStart = 0
					}
				}
				vStart = strconv.Itoa(iStart)
			}
			if !sLength {
				vLength = os.Getenv("PAGE_SIZE")
			}
			sqlQueryNoLimit := sqlQuery
			sqlQuery = sqlQuery + " LIMIT " + vStart + "," + vLength

			rows, errQuery := db.Raw(sqlQuery).Rows()
			if errQuery == nil {
				ArrayQueryMap := make([]map[string]interface{}, 0)
				defer rows.Close()
				mapColumsType := make(map[string]string)
				colsType, _ := rows.ColumnTypes()
				for _, ty := range colsType {
					if ty != nil {
						sqlColumType := *ty
						mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
					}
				}
				cols, _ := rows.Columns()
				for rows.Next() {
					data := make(map[string]interface{})
					columns := make([]*string, len(cols))
					columnPointers := make([]interface{}, len(cols))
					for i := range columns {
						columnPointers[i] = &columns[i]
					}
					rows.Scan(columnPointers...)
					for i, colName := range cols {
						if !libs.RemoveDefaultFieldsOnDynamicGenerateTable(colName) {
							vColumName, sColumName := mapColumsType[colName]
							if sColumName && columns[i] != nil {
								data[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
							} else {
								data[colName] = columns[i]
							}
						}
					}
					ArrayQueryMap = append(ArrayQueryMap, data)
				}
				primaryKeyFieldName := libs.GetPrimaryKeyFromUDTID(formUDTModel.DraftDynamicFormID)
				data = ConvertArrayUDTDataToArrayResponse(ArrayQueryMap, primaryKeyFieldName)
			} else {
				status = 500
				msg = errQuery.Error()
			}
			if status == 200 {
				// Total count query
				rowsTotalCount, errQueryTotalCount := db.Raw(sqlQueryNoLimit).Rows()
				if errQueryTotalCount == nil {
					defer rowsTotalCount.Close()
					for rowsTotalCount.Next() {
						totalCount = totalCount + 1
					}
				}
			}
		} else {
			status = 404
			msg = services.GetMessage(lang, "api.formudt_not_found")
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "api.drafdynamicformid_not_found")
	}
	if data == nil {
		data = make([]interface{}, 0)
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// UpdateUDTDataByDraftDynamicFormID godoc
// @Summary UpdateUDTDataByDraftDynamicFormID
// @Description UpdateUDTDataByDraftDynamicFormID
// @Tags FormUDT
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formudt/updateudtdata/{draftdynamicformid} [post]
func UpdateUDTDataByDraftDynamicFormID(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateUDTDataByDraftDynamicFormID")
	var (
		status                = libs.GetStatusSuccess()
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		msg, data             interface{}
		errorsResponse        []models.ErrorResponse
		draftDynamicFormModel models.DraftDynamicForm
		formUDTModel          models.FormUDT
		fourDPriceForm        = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	vFourDPriceForm, sFourDPriceForm := libs.GetQueryParam("FourDPriceForm", c)
	if sFourDPriceForm {
		fourDPriceForm, _ = strconv.ParseBool(vFourDPriceForm)
	}
	draftDynamicFormID := c.Param("draftdynamicformid")
	resultFindDraftForm := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&draftDynamicFormModel)
	if resultFindDraftForm.RowsAffected > 0 {
		resultFindFormUDT := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&formUDTModel)
		if resultFindFormUDT.RowsAffected > 0 {
			body, err := ioutil.ReadAll(c.Request.Body)
			if err == nil {
				dateTimeFormat := "2006-01-02 15:04:05"
				timeNow := time.Now().Format(dateTimeFormat)
				primaryKeyVal := 0
				arrValues := make([]interface{}, 0)
				arrFields := make([]string, 0)
				arrInsertKeyFields := make([]string, 0)
				arrInsertValueFields := make([]string, 0)
				tableName := libs.GetTableNameFromUDTID(formUDTModel.DraftDynamicFormID)
				var JSONObject map[string]interface{}
				json.Unmarshal([]byte(string(body)), &JSONObject)
				primaryKeyFieldName := libs.GetPrimaryKeyFromUDTID(formUDTModel.DraftDynamicFormID)
				for k, v := range JSONObject {
					// FormPrimaryKey = FormUDTJSON > FormPrimaryKey
					switch k {
					case "FormPrimaryKey":
						{
							strPrimaryKey := fmt.Sprintf("%v", v)
							vPrimaryKey, sPrimaryKey := strconv.Atoi(strPrimaryKey)
							if sPrimaryKey == nil {
								primaryKeyVal = vPrimaryKey
							}
						}
					case "JobID", "JobTaskID":
						{
							arrFields = append(arrFields, k+` = ?`)
							arrInsertKeyFields = append(arrInsertKeyFields, k)
							arrInsertValueFields = append(arrInsertValueFields, `?`)
							arrValues = append(arrValues, v)
						}
					case "ItemID":
						{
							if fourDPriceForm {
								arrFields = append(arrFields, k+` = ?`)
								arrInsertKeyFields = append(arrInsertKeyFields, k)
								arrInsertValueFields = append(arrInsertValueFields, `?`)
								arrValues = append(arrValues, v)
							}
						}
					case "Key":
						{
							if fourDPriceForm {
								arrFields = append(arrFields, "`Key`"+` = ?`)
								arrInsertKeyFields = append(arrInsertKeyFields, "`Key`")
								arrInsertValueFields = append(arrInsertValueFields, `?`)
								arrValues = append(arrValues, v)
							}
						}
					case "Controls":
						{
							// Remove primary key out of array value
							var controlsJSON []models.FormUDTControl
							objectControlsJSON, errObjectControls := json.Marshal(v)
							if errObjectControls == nil {
								json.Unmarshal(objectControlsJSON, &controlsJSON)
								for _, controlObj := range controlsJSON {
									fieldName := fmt.Sprintf("%v", controlObj.FieldName)
									arrFields = append(arrFields, fieldName+` = ?`)
									arrInsertKeyFields = append(arrInsertKeyFields, fieldName)
									arrInsertValueFields = append(arrInsertValueFields, `?`)
									fieldType := libs.CheckDatabaseDateTimeByFieldNameAndTableName(requestHeader, tableName, fieldName)
									switch fieldType {
									case "DATE", "DATETIME":
										{
											fieldVal := fmt.Sprintf("%v", controlObj.Value)
											dFieldVal, sFieldVal := libs.ConvertStringToDateTime(fieldVal)
											if sFieldVal == nil {
												arrValues = append(arrValues, dFieldVal.Format(dateTimeFormat))
											} else {
												arrValues = append(arrValues, controlObj.Value)
											}
										}
									default:
										arrValues = append(arrValues, controlObj.Value)
									}
								}
							}
						}
					}
				}
				if primaryKeyVal > 0 {
					arrFields = append(arrFields, "ModifiedBy"+` = ?`)
					arrValues = append(arrValues, strconv.Itoa(accountKey))
					arrFields = append(arrFields, "ModifiedDate"+` = ?`)
					arrValues = append(arrValues, timeNow)

					strFields := strings.Join(arrFields, ", ")
					sql := `UPDATE ` + tableName + ` SET ` + strFields
					sql = sql + ` WHERE ` + primaryKeyFieldName + ` = ` + strconv.Itoa(primaryKeyVal) + `;`
					err = db.Exec(sql, arrValues...).Error
					if err != nil {
						status = 500
						msg = err.Error()
					}
				} else {
					arrInsertKeyFields = append(arrInsertKeyFields, "CreatedBy")
					arrInsertValueFields = append(arrInsertValueFields, `?`)
					arrValues = append(arrValues, strconv.Itoa(accountKey))
					arrInsertKeyFields = append(arrInsertKeyFields, "ModifiedBy")
					arrInsertValueFields = append(arrInsertValueFields, `?`)
					arrValues = append(arrValues, strconv.Itoa(accountKey))
					arrInsertKeyFields = append(arrInsertKeyFields, "CreatedDate")
					arrInsertValueFields = append(arrInsertValueFields, `?`)
					arrValues = append(arrValues, timeNow)
					arrInsertKeyFields = append(arrInsertKeyFields, "ModifiedDate")
					arrInsertValueFields = append(arrInsertValueFields, `?`)
					arrValues = append(arrValues, timeNow)

					strKeyFields := strings.Join(arrInsertKeyFields, ", ")
					strValueFields := strings.Join(arrInsertValueFields, ", ")
					sql := `INSERT INTO ` + tableName + ` (` + strKeyFields + `) VALUES (` + strValueFields + `)`
					sqlDB, errSqlDB := db.DB()
					if errSqlDB == nil {
						resExec, errExec := sqlDB.Exec(sql, arrValues...)
						if errExec != nil {
							status = 500
							msg = errExec.Error()
						} else {
							newID, errLast := resExec.LastInsertId()
							if errLast == nil {
								primaryKeyVal = int(newID)
							} else {
								status = 500
								msg = errLast.Error()
							}
						}
					} else {
						status = 500
						msg = errSqlDB.Error()
					}
				}
				if status == 200 {
					sqlSelect := `SELECT * FROM ` + tableName + ` WHERE ` + primaryKeyFieldName + ` = ?`
					rows, errQuery := db.Raw(sqlSelect, primaryKeyVal).Rows()
					if errQuery == nil {
						defer rows.Close()
						ArrayQueryMap := make([]map[string]interface{}, 0)
						mapColumsType := make(map[string]string)
						colsType, _ := rows.ColumnTypes()
						for _, ty := range colsType {
							if ty != nil {
								sqlColumType := *ty
								mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
							}
						}
						cols, _ := rows.Columns()
						for rows.Next() {
							data := make(map[string]interface{})
							columns := make([]*string, len(cols))
							columnPointers := make([]interface{}, len(cols))
							for i := range columns {
								columnPointers[i] = &columns[i]
							}
							rows.Scan(columnPointers...)
							for i, colName := range cols {
								if !libs.RemoveDefaultFieldsOnDynamicGenerateTable(colName) {
									vColumName, sColumName := mapColumsType[colName]
									if sColumName && columns[i] != nil {
										data[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
									} else {
										data[colName] = columns[i]
									}
								}
							}
							ArrayQueryMap = append(ArrayQueryMap, data)
						}
						if len(ArrayQueryMap) > 0 {
							responses := ConvertArrayUDTDataToArrayResponse(ArrayQueryMap, primaryKeyFieldName)
							data = responses[0]
						}
					} else {
						status = 500
						msg = errQuery.Error()
					}
				}
			} else {
				status = 500
				msg = err.Error()
			}
		} else {
			status = 404
			msg = services.GetMessage(lang, "api.formudt_not_found")
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "api.drafdynamicformid_not_found")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// ConvertArrayFormUDTToArrayResponse func
func ConvertArrayFormUDTToArrayResponse(items []models.FormUDT) []models.FormUDTResponse {
	responses := make([]models.FormUDTResponse, 0)
	for _, item := range items {
		response := ConvertFormUDTToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertFormUDTToResponse func
func ConvertFormUDTToResponse(item models.FormUDT) models.FormUDTResponse {
	var (
		response models.FormUDTResponse
	)
	response.FormUDTID = item.FormUDTID
	response.DraftDynamicFormID = item.DraftDynamicFormID
	response.TableNameObj = item.TableNameObj
	details := make([]models.FormUDFResponse, 0)
	for _, de := range item.FormUDFs {
		var (
			detail models.FormUDFResponse
		)
		detail.DataField = de.DataField
		detail.DataType = de.DataType
		detail.Length = de.Length
		detail.ControlID = de.ControlID
		details = append(details, detail)
	}
	response.FormUDFs = details
	return response
}

// ConvertArrayUDTDataToArrayResponse func
func ConvertArrayUDTDataToArrayResponse(data []map[string]interface{}, primaryKey string) []models.FormUDTJSON {
	var (
		items = make([]models.FormUDTJSON, 0)
	)
	for _, dynamicObj := range data {
		var (
			item     models.FormUDTJSON
			controls = make([]models.FormUDTControl, 0)
		)
		for fieldName, fieldValue := range dynamicObj {
			switch fieldName {
			case "JobID":
				{
					item.JobID = fieldValue
				}
			case "JobTaskID":
				{
					item.JobTaskID = fieldValue
				}
			case primaryKey:
				{
					item.FormPrimaryKey = fieldValue
				}
			default:
				{
					var control models.FormUDTControl
					control.FieldName = fieldName
					control.Value = fieldValue
					controls = append(controls, control)
				}
			}
		}
		item.Controls = controls
		items = append(items, item)
	}
	return items
}

// ConvertArrayUDTDataToArrayResponse func
func ConvertArrayUDTDataToArrayResponse4DPrice(data []map[string]interface{}, primaryKey string, requestHeader models.RequestHeader, lang string) []models.FormUDTJSONFor4DPrice {
	var (
		items = make([]models.FormUDTJSONFor4DPrice, 0)
	)
	for _, dynamicObj := range data {
		var (
			item     models.FormUDTJSONFor4DPrice
			controls = make([]models.FormUDTControl, 0)
		)
		for fieldName, fieldValue := range dynamicObj {
			switch fieldName {
			case "JobID":
				{
					item.JobID = fieldValue
				}
			case "JobTaskID":
				{
					item.JobTaskID = fieldValue
				}
			case "DynamicFormID":
				{
					item.DynamicFormID = fieldValue
				}
			case "JobTaskType":
				{
					item.JobTaskType = fieldValue
					jobTaskType, _ := strconv.Atoi(fmt.Sprintf("%v", item.JobTaskType))
					item.JobTaskTypeName, _ = libs.GetEnum(requestHeader, jobTaskType, "JobType", lang)
				}
			case "ItemID":
				{
					item.ItemID = fieldValue
				}
			case "Key":
				{
					item.Key = fieldValue
				}
			case primaryKey:
				{
					item.FormPrimaryKey = fieldValue
				}
			default:
				{
					var control models.FormUDTControl
					control.FieldName = fieldName
					control.Value = fieldValue
					controls = append(controls, control)
				}
			}
		}
		item.Controls = controls
		items = append(items, item)
	}
	return items
}
