package controllers

import (
	"bytes"
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/logs"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"
	"text/template"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetReport godoc
// @Summary Get BReport
// @Description Get Report
// @Tags Report
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /report [get]
func GetReport(c *gin.Context) {
	defer libs.RecoverError(c, "GetReport")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Report
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	//var bp = db
	bp = bp.Where("IFNULL(reports.IsDeleted, 0) <> 1 AND IFNULL(reports.IsArchived, 0) <> 1")

	// Filter
	arrBool := []string{"IsDefault"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"ReportName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"ReportGroupID", "ReportTypeID", "DocumentTypeID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	arrIsTrue := make([]int, 0)
	arrIsFalse := make([]int, 0)

	vIsDocument, sIsDocument := libs.GetQueryParam("isdocument", c)
	if sIsDocument {
		bIsDocument, eIsDocument := strconv.ParseBool(vIsDocument)
		if eIsDocument == nil {
			if bIsDocument {
				arrIsTrue = append(arrIsTrue, 1)
			} else {
				arrIsFalse = append(arrIsFalse, 1)
			}
		}
	}

	vIsReport, sIsReport := libs.GetQueryParam("isreport", c)
	if sIsReport {
		bIsReport, eIsReport := strconv.ParseBool(vIsReport)
		if eIsReport == nil {
			if bIsReport {
				arrIsTrue = append(arrIsTrue, 2)
			} else {
				arrIsFalse = append(arrIsFalse, 2)
			}
		}
	}

	vIsLabel, sIsLabel := libs.GetQueryParam("islabel", c)
	if sIsLabel {
		bIsLabel, eIsLabel := strconv.ParseBool(vIsLabel)
		if eIsLabel == nil {
			if bIsLabel {
				arrIsTrue = append(arrIsTrue, 3)
			} else {
				arrIsFalse = append(arrIsFalse, 3)
			}
		}
	}
	if len(arrIsTrue) > 0 {
		bp = bp.Where("ReportTypeID in (?)", arrIsTrue)
	}
	if len(arrIsFalse) > 0 {
		bp = bp.Where("ReportTypeID not in (?)", arrIsFalse)
	}

	arrIsTrue = make([]int, 0)
	arrIsFalse = make([]int, 0)

	vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
	if sIsInvoice {
		bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
		if eIsInvoice == nil {
			if bIsInvoice {
				arrIsTrue = append(arrIsTrue, 1)
			} else {
				arrIsFalse = append(arrIsFalse, 1)
			}
		}
	}

	vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
	if sIsEstimate {
		bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
		if eIsEstimate == nil {
			if bIsEstimate {
				arrIsTrue = append(arrIsTrue, 2)
			} else {
				arrIsFalse = append(arrIsFalse, 2)
			}
		}
	}

	vIsCreditNote, sIsCreditNote := libs.GetQueryParam("iscreditnote", c)
	if sIsCreditNote {
		bIsCreditNote, eIsCreditNote := strconv.ParseBool(vIsCreditNote)
		if eIsCreditNote == nil {
			if bIsCreditNote {
				arrIsTrue = append(arrIsTrue, 3)
			} else {
				arrIsFalse = append(arrIsFalse, 3)
			}
		}
	}

	vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
	if sIsJob {
		bIsJob, eIsJob := strconv.ParseBool(vIsJob)
		if eIsJob == nil {
			if bIsJob {
				arrIsTrue = append(arrIsTrue, 4)
			} else {
				arrIsFalse = append(arrIsFalse, 4)
			}
		}
	}

	vIsCustomer, sIsCustomer := libs.GetQueryParam("iscustomer", c)
	if sIsCustomer {
		bIsCustomer, eIsCustomer := strconv.ParseBool(vIsCustomer)
		if eIsCustomer == nil {
			if bIsCustomer {
				arrIsTrue = append(arrIsTrue, 5)
			} else {
				arrIsFalse = append(arrIsFalse, 5)
			}
		}
	}

	vIsVendor, sIsVendor := libs.GetQueryParam("isvendor", c)
	if sIsVendor {
		bIsVendor, eIsVendor := strconv.ParseBool(vIsVendor)
		if eIsVendor == nil {
			if bIsVendor {
				arrIsTrue = append(arrIsTrue, 6)
			} else {
				arrIsFalse = append(arrIsFalse, 6)
			}
		}
	}

	vIsContractor, sIsContractor := libs.GetQueryParam("iscontractor", c)
	if sIsContractor {
		bIsContractor, eIsContractor := strconv.ParseBool(vIsContractor)
		if eIsContractor == nil {
			if bIsContractor {
				arrIsTrue = append(arrIsTrue, 7)
			} else {
				arrIsFalse = append(arrIsFalse, 7)
			}
		}
	}

	if len(arrIsTrue) > 0 {
		bp = bp.Where("DocumentTypeID in (?)", arrIsTrue)
	}
	if len(arrIsFalse) > 0 {
		bp = bp.Where("DocumentTypeID not in (?)", arrIsFalse)
	}

	// Sort
	//bp = libs.SortDataOnParam(bp, c)

	vSort, sSort := libs.GetQueryParam("sort", c)
	if sSort {
		arrSorts := libs.GetSortParamsFromURL(vSort)
		for fieldSortObj, vSortObj := range arrSorts {
			if fieldSortObj == "Caption" {
				strSort := "enums.Caption " + vSortObj
				bp = bp.Joins("left join enums on enums.Status = reports.DocumentTypeID AND enums.FieldName = 'DocumentTypeID'").Order(strSort)
			} else if fieldSortObj == "ReportGroupName" {
				strSort := "reportgroups.ReportGroupName " + vSortObj
				bp = bp.Joins("left join reportgroups on reportgroups.ReportGroupID = reports.ReportGroupID").Order(strSort)
			} else {
				strSort := fieldSortObj + " " + vSortObj
				bp = bp.Order(strSort)
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayReportsToArrayResponse(resModels, requestHeader, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetReportByID godoc
// @Summary Get Report By ID
// @Description Get Report  By ID
// @Tags Report
// @Accept  json
// @Produce  json
// @Param id path int true "Report ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /report/id/{id} [get]
func GetReportByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetReportByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Report
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ReportID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertReportToResponse(resModel, requestHeader, lang)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetReportByDocumentTypeID godoc
// @Summary Get Report By DocumentType ID
// @Description Get Report DocumentType  By ID
// @Tags Report
// @Accept  json
// @Produce  json
// @Param id path int true "Report DocumentType ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /report/documenttypeid/{id} [get]
func GetReportByDocumentTypeID(c *gin.Context) {
	defer libs.RecoverError(c, "GetReportByDocumentTypeID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Report
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	documentTypeID := c.Param("id")

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	//var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	bp = bp.Where("DocumentTypeID = ?", documentTypeID)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayReportsToArrayResponseForGetAll(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// CreateReport godoc
// @Summary Create Report
// @Description Create Report
// @Tags Report
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Report body []models.Report true "Create Report"
// @Success 200 {object} models.APIResponseData
// @Router /report [post]
func CreateReport(c *gin.Context) {
	defer libs.RecoverError(c, "CreateReport")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Report
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Report, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				postModel models.Report
			)
			postModel.PassBodyJSONToModel(bp)
			resultFindReport := db.Where("ReportName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", postModel.ReportName).First(&models.Report{})
			if resultFindReport.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.reportname_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				postModel.CreatedBy = accountKey
				postModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(postModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					// If ReportTypeID 1 = document,  3 = label => Ignore ReportGroupID, Only valid DocumentTypeID (Required)
					if libs.InArrayInteger(postModel.ReportTypeID, []int{1, 3}) && postModel.DocumentTypeID <= 0 {
						errResponse := GetErrorResponseValidate(lang, k, "report.documenttypeidisrequired")
						errorsResponse = append(errorsResponse, errResponse)
						continue
					}
					// If Report Type ID 2 = report => Ignore DocumentTypeID, Only valid  ReportGroupID (Required)
					if libs.InArrayInteger(postModel.ReportTypeID, []int{2}) && postModel.ReportGroupID <= 0 {
						errResponse := GetErrorResponseValidate(lang, k, "report.reportgroupidisrequired")
						errorsResponse = append(errorsResponse, errResponse)
						continue
					}
					var (
						itemMsgError string
					)
					// @TODO validate for address
					resultCreate := db.Create(&postModel)
					if resultCreate.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultCreate.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, postModel)

						// @TODO add or update translation table
						//ProcessTranslationForObject(requestHeader, models.Report{}.TableName(), postModel.ReportID, accountKey, bp)
						var (
							transModel      models.Translation
							transPOST       []models.TranslationResponse
							objectID        = postModel.ReportID
							objectTableName = models.Report{}.TableName()
							objectInterface = bp
						)
						resultFindTrans := db.Where("TypeID = ? AND TypeName = ?", objectID, objectTableName).First(&transModel)
						_, resTrans := services.ConvertJSONValueToVariable("Translations", objectInterface)
						if resTrans != nil {
							jsonTrans, errTrans := json.Marshal(resTrans)
							if errTrans == nil {
								json.Unmarshal(jsonTrans, &transPOST)
								for _, v := range transPOST {
									switch strings.ToLower(v.Language) {
									case models.LanguageEN:
										transModel.EN = v.Value
									case models.LanguageIT:
										transModel.IT = v.Value
									case models.LanguageNL:
										transModel.NL = v.Value
									}
								}
							}
						} else {
							transModel.EN = postModel.ReportName
							transModel.IT = postModel.ReportName
							transModel.NL = postModel.ReportName
						}
						if resultFindTrans.RowsAffected > 0 {
							transModel.TypeID = objectID
							transModel.TypeName = objectTableName
							transModel.ModifiedBy = accountKey
							db.Save(&transModel)
						} else {
							transModel.TypeID = objectID
							transModel.TypeName = objectTableName
							transModel.CreatedBy = accountKey
							db.Create(&transModel)
						}

						// @TODO Set default
						SetDefaultValueOnReport(requestHeader, postModel)
						// @TODO add permission
						// add one row for every group by SecurityGroupID
						var (
							securityModel models.SecurityGroup
						)
						db.Where("IsAdministrator = 1 AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&securityModel)
						arrSecurityGroupIDGrouped := make([]int, 0)
						rowsGroup, errGroup := db.Table(models.Permission{}.TableName()).Select("SecurityGroupID").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Group("SecurityGroupID").Rows()
						if errGroup == nil {
							for rowsGroup.Next() {
								var (
									securityGroupIDGrouped int
								)
								rowsGroup.Scan(&securityGroupIDGrouped)
								if securityGroupIDGrouped > 0 {
									arrSecurityGroupIDGrouped = append(arrSecurityGroupIDGrouped, securityGroupIDGrouped)
								}
							}
						}
						groupAdmin := securityModel.SecurityGroupID
						if len(arrSecurityGroupIDGrouped) > 0 {
							for _, groupID := range arrSecurityGroupIDGrouped {
								var (
									perModel models.Permission
								)
								perModel.SecurityGroupID = groupID
								perModel.ReportID = &postModel.ReportID
								perModel.Area = postModel.ReportName
								perModel.CreatedBy = accountKey
								bTrue := true
								bFalse := false
								if groupID == groupAdmin {
									perModel.CanAccess = &bTrue
									perModel.CanCreate = &bTrue
									perModel.CanDelete = &bTrue
									perModel.CanArchive = &bTrue
									perModel.CanEdit = &bTrue
									perModel.CanExport = &bTrue
									perModel.CanPrint = &bTrue
									perModel.CanView = &bTrue
								} else {
									perModel.CanAccess = &bFalse
									perModel.CanCreate = &bFalse
									perModel.CanDelete = &bFalse
									perModel.CanArchive = &bFalse
									perModel.CanEdit = &bFalse
									perModel.CanExport = &bFalse
									perModel.CanPrint = &bFalse
									perModel.CanView = &bFalse
								}

								var maxSort int
								row := db.Table(models.Permission{}.TableName()).Select("max(PermissionGroupSort)").Where("SecurityGroupID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", groupID).Row()
								row.Scan(&maxSort)
								maxSort = maxSort + 1
								perModel.PermissionGroupSort = maxSort

								var checkPerModel models.Permission
								db.Where("SecurityGroupID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", groupID).First(&checkPerModel)
								perModel.PermissionGroup = "Analytics" //checkPerModel.PermissionGroup
								//perModel.TranslationTypeID = checkPerModel.TranslationTypeID
								permissionGroupTranslationKey := "permissiongroup.analytics"
								perModel.PermissionGroupTranslationKey = &permissionGroupTranslationKey

								resultCreatePermission := db.Create(&perModel)
								if resultCreatePermission.Error != nil {
									errResponse := GetErrorResponseErrorMessage(k, resultCreatePermission.Error.Error())
									errorsResponse = append(errorsResponse, errResponse)
								}
							}
						}
						// @TODO end add permission

					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Report
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReportID)
	}
	if len(arrID) > 0 {
		db.Where("ReportID in (?)", arrID).Find(&resModels)
		data = ConvertArrayReportsToArrayResponse(resModels, requestHeader, lang)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateReport godoc
// @Summary Update Report
// @Description Update Report
// @Tags Report
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Report body []models.Report true "Update Report"
// @Success 200 {object} models.APIResponseData
// @Router /report [put]
func UpdateReport(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateReport")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Report
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Report, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.Report
			)
			putModel.PassBodyJSONToModel(bp)
			if putModel.ReportName != "" {
				resultFindReport := db.Where("ReportName = ? AND ReportID <> ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", putModel.ReportName, putModel.ReportID).First(&models.Report{})
				if resultFindReport.RowsAffected > 0 {
					errResponse := GetErrorResponseValidate(lang, k, "api.reportname_exist")
					errorsResponse = append(errorsResponse, errResponse)
					continue
				}
			}
			resultFind := db.Where("ReportID = ?", putModel.ReportID).First(&putModel)
			if resultFind.RowsAffected > 0 {
				putModel.PassBodyJSONToModel(bp)
				putModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(putModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultSave := db.Save(&putModel)
					if resultSave.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultSave.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, putModel)

						// @TODO add or update translation table
						//ProcessTranslationForObject(requestHeader, models.Report{}.TableName(), putModel.ReportID, accountKey, bp)
						var (
							transModel      models.Translation
							transPOST       []models.TranslationResponse
							objectID        = putModel.ReportID
							objectTableName = models.Report{}.TableName()
							objectInterface = bp
						)
						resultFindTrans := db.Where("TypeID = ? AND TypeName = ?", objectID, objectTableName).First(&transModel)
						_, resTrans := services.ConvertJSONValueToVariable("Translations", objectInterface)
						if resTrans != nil {
							jsonTrans, errTrans := json.Marshal(resTrans)
							if errTrans == nil {
								json.Unmarshal(jsonTrans, &transPOST)
								for _, v := range transPOST {
									switch strings.ToLower(v.Language) {
									case models.LanguageEN:
										transModel.EN = v.Value
									case models.LanguageIT:
										transModel.IT = v.Value
									case models.LanguageNL:
										transModel.NL = v.Value
									}
								}
							}
						} else {
							transModel.EN = putModel.ReportName
							transModel.IT = putModel.ReportName
							transModel.NL = putModel.ReportName
						}
						if resultFindTrans.RowsAffected > 0 {
							transModel.TypeID = objectID
							transModel.TypeName = objectTableName
							transModel.ModifiedBy = accountKey
							db.Save(&transModel)
						} else {
							transModel.TypeID = objectID
							transModel.TypeName = objectTableName
							transModel.CreatedBy = accountKey
							db.Create(&transModel)
						}

						// @TODO Set default
						SetDefaultValueOnReport(requestHeader, putModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Report
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReportID)
	}
	if len(arrID) > 0 {
		db.Where("ReportID in (?)", arrID).Find(&resModels)
		data = ConvertArrayReportsToArrayResponse(resModels, requestHeader, lang)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteReport godoc
// @Summary Delete Report
// @Description Delete Report
// @Tags Report
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Report ID"
// @Success 200 {object} models.APIResponseData
// @Router /report/{id} [delete]
func DeleteReport(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteReport")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Report
		)
		resultFind := db.Where("ReportID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				//@TODO delete translation table
				DeleteTranslationOnObject(requestHeader, models.Report{}.TableName(), uModel.ReportID)
				totalUpdatedRecord++

				// @TODO delete permission
				db.Where("ReportID = ? AND Area = ?", uModel.ReportID, uModel.ReportName).Delete(&models.Permission{})
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// SendReport godoc
// @Summary Send Report
// @Description Send Report
// @Tags Report
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Report ID"
// @Success 200 {object} models.APIResponseData
// @Router /report/sendreport/{id} [get]
func SendReport(c *gin.Context) {
	defer libs.RecoverError(c, "SendReport")
	logger := logs.Logger
	logger.Println("SendReport...")
	var (
		status = libs.GetStatusSuccess()
		msg    interface{}
		//requestHeader  models.RequestHeader
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		errors         interface{}
		//totalUpdatedRecord = 0
		reportServerResponse models.ReportServerResponse
		err                  error
	)
	/* statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	} */
	/* db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	 */

	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	security := c.Request.Header.Get("security")
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationgroupid, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	locationid, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse = make([]models.ErrorResponse, 0)
	reportID := c.Param("reportid")
	URL := os.Getenv("SERVER_REPORT") + "/export/" + reportID
	headers := map[string]interface{}{
		"token":           token,
		"security":        security,
		"accountKey":      strconv.Itoa(accountKey),
		"language":        lang,
		"locationgroupid": strconv.Itoa(locationgroupid),
		"locationid":      strconv.Itoa(locationid),
	}
	params := map[string]interface{}{}
	resStatus, resMsg, resData := libs.RequestAPI(lang, "GET", URL, nil, params, headers)
	json.Unmarshal(resData, &reportServerResponse)

	if resStatus == 200 {
		fmt.Println("reportServerResponse: ", reportServerResponse)
		pathFile := reportServerResponse.Data

		emailFrom := os.Getenv("EMAILSYSTEM")
		nameFrom := os.Getenv("EMAILSENDERNAME")
		emailTo := "arena862013@gmail.com"
		nameTo := ""
		subject := "testing"

		content := ""
		templatePath := "public/pdf/templates"
		fileName := "emailContent.html"
		pathTemplate := "./" + templatePath + "/" + fileName
		t := template.New(fileName)
		t, err = t.ParseFiles(pathTemplate)
		if err != nil {
			logger.Error("Email template > err: ", err)
		} else {
			var tpl bytes.Buffer
			arrayVariablesEmailContent := make(map[string]interface{})
			if err = t.Execute(&tpl, arrayVariablesEmailContent); err != nil {
				logger.Error("Email template > err: ", err)
			} else {
				content = tpl.String()
			}
		}

		attachs := make([]string, 0)

		fmt.Println("pathFile: ", pathFile)
		fmt.Println("FileExists: ", libs.FileExists(pathFile))

		//if libs.FileExists(pathFile) {
		attachs = append(attachs, pathFile)
		//}
		_, err = libs.SendEmailWithAttachs(emailFrom, nameFrom, emailTo, nameTo, subject, content, attachs)
		if err != nil {
			logger.Error("SendEmailWithAttachs > "+emailTo+" > err: ", err)
		} else {
			logger.Info("SendEmailWithAttachs > " + emailTo + " > success")
		}
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		if reportServerResponse.Msg != "" {
			msg = reportServerResponse.Msg
		}
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayReportsToArrayResponse func
func ConvertArrayReportsToArrayResponse(items []models.Report, requestHeader models.RequestHeader, lang string) []models.ReportResponse {
	responses := make([]models.ReportResponse, 0)
	for _, item := range items {
		response := ConvertReportToResponse(item, requestHeader, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertReportToResponse func
func ConvertReportToResponse(item models.Report, requestHeader models.RequestHeader, lang string) models.ReportResponse {
	var (
		response         models.ReportResponse
		reportGroupModel models.ReportGroup
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.ReportID = item.ReportID
	response.ReportName = item.ReportName
	response.ReportGroupID = item.ReportGroupID
	db.Where("ReportGroupID = ?", item.ReportGroupID).First(&reportGroupModel)
	response.ReportGroupName = reportGroupModel.ReportGroupName
	response.ReportTypeID = item.ReportTypeID
	response.DocumentTypeID = item.DocumentTypeID

	var (
		jobDocumentType models.Enumerator
	)
	db.Where("FieldName = ? AND Status = ?", "DocumentTypeID", item.DocumentTypeID).First(&jobDocumentType)
	if jobDocumentType.TranslationKey != "" && jobDocumentType.TranslationKey != services.GetMessage(lang, jobDocumentType.TranslationKey) {
		response.Caption = services.GetMessage(lang, jobDocumentType.TranslationKey)
	} else {
		response.Caption = jobDocumentType.Caption
	}

	response.IsDefault = item.IsDefault
	response.Report = item.Report
	var (
		translationResponses []models.TranslationResponse
	)
	translationResponses = make([]models.TranslationResponse, 0)
	translationResponses = GetTranslationResponse(requestHeader, models.Report{}.TableName(), item.ReportID)
	response.Translations = translationResponses
	return response
}

// ConvertArrayReportsToArrayResponseForGetAll func
func ConvertArrayReportsToArrayResponseForGetAll(items []models.Report) []models.ReportResponseForGetAll {
	responses := make([]models.ReportResponseForGetAll, 0)
	for _, item := range items {
		response := ConvertReportToResponseForGetAll(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertReportToResponseForGetAll func
func ConvertReportToResponseForGetAll(item models.Report) models.ReportResponseForGetAll {
	var (
		response models.ReportResponseForGetAll
	)
	response.ReportID = item.ReportID
	response.ReportName = item.ReportName
	response.IsDefault = item.IsDefault
	return response
}

// SetDefaultValueOnReport func
func SetDefaultValueOnReport(requestHeader models.RequestHeader, postModel models.Report) {
	// if IsDefault = true and ReportTypeID 1 = document,  3 = label
	// 1.Reset IsDefault = false where DocumentTypeID = @DocumentTypeID
	// 2.Update IsDefault = true where ReportID = @ReportID
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	if libs.InArrayInteger(postModel.ReportTypeID, []int{1, 3}) && postModel.IsDefault {
		sqlReset := `Update ` + models.Report{}.TableName() + ` set IsDefault = 0 Where DocumentTypeID = ?`
		db.Exec(sqlReset, postModel.DocumentTypeID)
		sqlUpdate := `Update ` + models.Report{}.TableName() + ` set IsDefault = 1 Where ReportID = ?`
		db.Exec(sqlUpdate, postModel.ReportID)
	}
}
