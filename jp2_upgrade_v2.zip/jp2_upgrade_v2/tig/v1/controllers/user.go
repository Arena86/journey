package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetUser godoc
// @Summary Get User
// @Description Get User
// @Tags User
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /user [get]
func GetUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetUser")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	//var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)
	// Filter
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}

	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"FirstName", "LastName", "Email"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayUserToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUserByID godoc
// @Summary Get User By ID
// @Description Get User  By ID
// @Tags User
// @Accept  json
// @Produce  json
// @Param id path int true "User ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /user/{id} [get]
func GetUserByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetUserByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND UserID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertUserToResponse(requestHeader, resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetLoggedUser godoc
// @Summary Get User By ID
// @Description Get User  By ID
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getloggeduser [get]
func GetLoggedUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetLoggedUser")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND AccountKey = ?", accountKey)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertUserToResponse(requestHeader, resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetUserChatInfor godoc
// @Summary Get User Chat Information
// @Description Get User Chat Information
// @Tags User
// @Accept  json
// @Produce  json
// @Param id path int true "User ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getuserchatInfo [get]
func GetUserChatInfor(c *gin.Context) {
	defer libs.RecoverError(c, "GetUserChatInfor")
	var (
		status        = libs.GetStatusSuccess()
		resModel      []models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	vAccountKey, sAccountKey := libs.GetQueryParam("AccountKeys", c)
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1")
	fmt.Println(vAccountKey)
	if sAccountKey {
		arrID := libs.StringToArray(vAccountKey)
		bp = bp.Where("AccountKey IN (?)", arrID)
	}
	resultRow := bp.Find(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertArrayChatUserToArrayResponse(requestHeader, resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateUser godoc
// @Summary Create User
// @Description Create User
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param User body []models.User true "Create User"
// @Success 200 {object} models.APIResponseData
// @Router /user [post]
func CreateUser(c *gin.Context) {
	defer libs.RecoverError(c, "CreateUser")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.User
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")

	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		postModel models.User
	)
	postModel.PassBodyJSONToModel(objectsJSON)
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Email = ?", postModel.Email).First(&models.User{})
	if resultFindUser.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.email_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		postModel.AccountKey = 0
		postModel.CreatedBy = accountKey
		postModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(postModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO validate for address
			resultCreate := db.Create(&postModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				// @TODO call jpree to createadditionalnewuser
				additionalNewUser := make(map[string]interface{})
				additionalNewUser["FirstName"] = postModel.FirstName
				additionalNewUser["LastName"] = postModel.LastName
				additionalNewUser["EmailAddress"] = postModel.Email
				additionalNewUser["PhoneNumber"] = postModel.PhoneNumber
				additionalNewUser["AccountKey"] = accountKey
				additionalNewUser["LocationID"] = postModel.LocationID
				if postModel.Language == "" {
					postModel.Language = lang
				}
				additionalNewUser["Language"] = postModel.Language
				additionalNewUser["CountryCode"] = postModel.CountryCode

				var locationModel models.Location
				resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", postModel.LocationID).First(&locationModel)
				if resultFindLocation.RowsAffected > 0 {
					additionalNewUser["LocationGroupID"] = locationModel.LocationGroupID
				}
				additionalNewUser["IsManager"] = postModel.IsManager

				companies := make([]map[string]interface{}, 0)
				company := map[string]interface{}{"companyid": companyID}
				companies = append(companies, company)
				additionalNewUser["Companies"] = companies
				URL := os.Getenv("SERVER_REE") + "/" + "createadditionalnewuser"
				statusRee, msgRee, _ := libs.RequestAPIRee(lang, "POST", URL, additionalNewUser, nil, nil)
				if statusRee != 200 {
					// Delete account
					db.Delete(&postModel)
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprint(msgRee))
				} else {
					totalUpdatedRecord++
					dataResponse = postModel
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	if len(errorsResponse) == 0 {
		var (
			resModels models.User
		)
		if dataResponse.UserID > 0 {
			db.Where("UserID = ?", dataResponse.UserID).First(&resModels)
			data = ConvertUserToResponse(requestHeader, resModels)
			CopyDefaultValueOfTemplatesForUser(requestHeader, resModels.AccountKey)
			// run script to add only usersettings data
			jpdatabase.GenerateDataWithAccountKey(db, resModels.AccountKey, "usersettings")
			// add menu to this user

			// update menu for
			_, res := services.ConvertJSONValueToVariable("Menus", objectsJSON)
			if res != nil {
				menuJSON, err := json.Marshal(res)
				if err == nil {
					var arrMenuID []int
					json.Unmarshal(menuJSON, &arrMenuID)
					if len(arrMenuID) >= 0 {
						var (
							userMenuModels    = make([]models.UserMenu, 0)
							arrSkipUserMenuID = make([]int, 0)
						)
						for _, menuID := range arrMenuID {
							var menuModel models.DeviceMenu
							resultFindMenu := db.Where("MenuID = ?", menuID).Where("IFNULL(IsDeleted, 0) <> 1").First(&menuModel)
							if resultFindMenu.RowsAffected > 0 {
								var userMenuModel models.UserMenu
								resultFindUserMenu := db.Where("UserID = ? AND MenuID = ?", resModels.UserID, menuID).Where("IFNULL(IsDeleted, 0) <> 1").First(&userMenuModel)
								if resultFindUserMenu.RowsAffected > 0 {
									arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
									userMenuModels = append(userMenuModels, userMenuModel)
								} else {
									userMenuModel.UserID = resModels.UserID
									userMenuModel.MenuID = menuID
									userMenuModel.CreatedBy = accountKey
									userMenuModel.ModifiedBy = accountKey
									resultCreate := db.Create(&userMenuModel)
									if resultCreate.Error == nil {
										arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
										userMenuModels = append(userMenuModels, userMenuModel)
									}
								}
							}
						}
						if len(arrSkipUserMenuID) > 0 {
							db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ? AND UserMenuID not in (?)`, resModels.UserID, arrSkipUserMenuID)
						} else {
							db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ?`, resModels.UserID)
						}
					}
				}
			}

		} else {
			data = dataResponse
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateUser godoc
// @Summary Update User
// @Description Update User
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param User body []models.User true "Update User"
// @Success 200 {object} models.APIResponseData
// @Router /user [put]
func UpdateUser(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateUser")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.User
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		putModel    models.User
		backupModel models.User
	)
	putModel.PassBodyJSONToModel(objectsJSON)
	resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND Email = ?", putModel.Email).First(&putModel)
	if resultFind.RowsAffected > 0 {
		backupModel = putModel
		putModel.PassBodyJSONToModel(objectsJSON)
		putModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(putModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			resultSave := db.Save(&putModel)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				// @TODO call jpree to createadditionalnewuser
				additionalNewUser := make(map[string]interface{})
				additionalNewUser["FirstName"] = putModel.FirstName
				additionalNewUser["LastName"] = putModel.LastName
				additionalNewUser["PhoneNumber"] = putModel.PhoneNumber
				additionalNewUser["LocationID"] = putModel.LocationID
				if putModel.Language == "" {
					putModel.Language = lang
				}
				additionalNewUser["Language"] = putModel.Language
				additionalNewUser["CountryCode"] = putModel.CountryCode

				var locationModel models.Location
				resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", putModel.LocationID).First(&locationModel)
				if resultFindLocation.RowsAffected > 0 {
					additionalNewUser["LocationGroupID"] = locationModel.LocationGroupID
				}
				additionalNewUser["IsManager"] = putModel.IsManager

				companies := make([]map[string]interface{}, 0)
				company := map[string]interface{}{"companyid": companyID}
				companies = append(companies, company)
				additionalNewUser["Companies"] = companies

				URL := os.Getenv("SERVER_REE") + "/" + "accounts/" + strconv.Itoa(putModel.AccountKey)
				statusRee, msgRee, _ := libs.RequestAPIRee(lang, "PUT", URL, additionalNewUser, nil, nil)
				if statusRee != 200 {
					// delelte account
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprint(msgRee))
					db.Save(&backupModel)
				} else {
					totalUpdatedRecord++
					dataResponse = putModel

					// update menu for
					_, res := services.ConvertJSONValueToVariable("Menus", objectsJSON)
					if res != nil {
						menuJSON, err := json.Marshal(res)
						if err == nil {
							var arrMenuID []int
							json.Unmarshal(menuJSON, &arrMenuID)
							if len(arrMenuID) >= 0 {
								var (
									userMenuModels    = make([]models.UserMenu, 0)
									arrSkipUserMenuID = make([]int, 0)
								)
								for _, menuID := range arrMenuID {
									var menuModel models.DeviceMenu
									resultFindMenu := db.Where("MenuID = ?", menuID).Where("IFNULL(IsDeleted, 0) <> 1").First(&menuModel)
									if resultFindMenu.RowsAffected > 0 {
										var userMenuModel models.UserMenu
										resultFindUserMenu := db.Where("UserID = ? AND MenuID = ?", putModel.UserID, menuID).Where("IFNULL(IsDeleted, 0) <> 1").First(&userMenuModel)
										if resultFindUserMenu.RowsAffected > 0 {
											arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
											userMenuModels = append(userMenuModels, userMenuModel)
										} else {
											userMenuModel.UserID = putModel.UserID
											userMenuModel.MenuID = menuID
											userMenuModel.CreatedBy = accountKey
											userMenuModel.ModifiedBy = accountKey
											resultCreate := db.Create(&userMenuModel)
											if resultCreate.Error == nil {
												arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
												userMenuModels = append(userMenuModels, userMenuModel)
											}
										}
									}
								}
								if len(arrSkipUserMenuID) > 0 {
									db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ? AND UserMenuID not in (?)`, putModel.UserID, arrSkipUserMenuID)
								} else {
									db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ?`, putModel.UserID)
								}
							}
						}
					}

				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	if len(errorsResponse) == 0 {
		var (
			resModels models.User
		)
		if dataResponse.UserID > 0 {
			db.Where("UserID = ?", dataResponse.UserID).Find(&resModels)
			data = ConvertUserToResponse(requestHeader, resModels)
		} else {
			data = dataResponse
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateUserDevice godoc
// @Summary Update User Device
// @Description Update User Device
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param User body []models.User true "Update User"
// @Success 200 {object} models.APIResponseData
// @Router /user/userdevice [put]
func UpdateUserDevice(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateUserDevice")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		putModel models.User
	)
	resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND AccountKey = ?", accountKey).First(&putModel)
	if resultFind.RowsAffected > 0 {
		putModel.PassBodyJSONToModel(objectsJSON)
		putModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(putModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			db.Save(&putModel)
			totalUpdatedRecord++
			data = ConvertUserToResponse(requestHeader, putModel)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteUser godoc
// @Summary Delete User
// @Description Delete User
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "User ID"
// @Success 200 {object} models.APIResponseData
// @Router /user/{id} [delete]
func DeleteUser(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteUser")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.User
		)
		resultFind := db.Where("UserID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			if uModel.IsMaster {
				errResponse := GetErrorResponseValidate(lang, k, "api.userismaster")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				statusDelete := uModel.ValidateDelete(db, lang)
				if statusDelete.Status == 200 {
					uModel.IsDeleted = true
					uModel.ModifiedBy = accountKey
					deletedResult := db.Save(&uModel)
					if deletedResult.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						if uModel.AccountKey > 0 {
							// @TODO delete on jpree
							URL := os.Getenv("SERVER_REE") + "/" + "accounts/" + strconv.Itoa(uModel.AccountKey)
							statusRee, msgRee, _ := libs.RequestAPIRee(lang, "DELETE", URL, nil, nil, nil)
							if statusRee != 200 {
								errResponse := GetErrorResponseErrorMessage(k, msgRee)
								errorsResponse = append(errorsResponse, errResponse)
								// if delete on jpree has error then reset on jpapi
								uModel.IsDeleted = false
								uModel.ModifiedBy = accountKey
								db.Save(&uModel)
							} else {
								totalUpdatedRecord++
							}
						} else {
							totalUpdatedRecord++
						}
					}
				} else {
					errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// DeleteUserByAccountKey godoc
// @Summary Delete User By AccountKey
// @Description Delete User ByAccountKey
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "User ID"
// @Success 200 {object} models.APIResponseData
// @Router /user/{id}/accountkey [delete]
func DeleteUserByAccountKey(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteUserByAccountKey")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, acckey := range arrID {
		var (
			checkUserModel models.User
			errResponse    models.ErrorResponse
		)
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND AccountKey = ?", acckey).First(&checkUserModel)
		if resultFindUser.RowsAffected > 0 {
			if checkUserModel.IsMaster {
				errResponse := GetErrorResponseValidate(lang, k, "api.userismaster")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				err := db.Where("AccountKey = ?", acckey).Model(&models.User{}).Updates(models.User{IsDeleted: true, ModifiedBy: accountKey}).Error
				if err != nil {
					errResponse.Index = k
					errResponse.Message = err.Error()
					errResponse.Type = models.ErrorResponseTypeError
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					if acckey > 0 {
						// @TODO delete on jpree
						URL := os.Getenv("SERVER_REE") + "/" + "accounts/" + strconv.Itoa(acckey)
						statusRee, msgRee, _ := libs.RequestAPIRee(lang, "DELETE", URL, nil, nil, nil)
						if statusRee != 200 {
							errResponse := GetErrorResponseErrorMessage(k, msgRee)
							errorsResponse = append(errorsResponse, errResponse)
							// if delete on jpree has error then reset on jpapi
							db.Where("AccountKey = ?", acckey).Model(&models.User{}).Updates(models.User{IsDeleted: false, ModifiedBy: accountKey})
						} else {
							totalUpdatedRecord++
						}
					} else {
						totalUpdatedRecord++
					}
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	if totalUpdatedRecord == 0 {
		status = libs.GetStatusError()
		msg = services.GetMessage(lang, "api.full_failed")
	} else if totalUpdatedRecord < len(arrID) {
		status = libs.GetStatusPartial()
		msg = services.GetMessage(lang, "api.partial_success")
	} else {
		msg = services.GetMessage(lang, "api.delete_success")
		if len(errorsResponse) > 0 {
			status = libs.GetStatusPartial()
			msg = services.GetMessage(lang, "api.partial_success")
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// AllocatedUser godoc
// @Summary Allocated User
// @Description Allocated User
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /allocateduser [get]
func AllocatedUser(c *gin.Context) {
	defer libs.RecoverError(c, "AllocatedUser")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
		errResponse   models.ErrorResponse
		isAllocated   = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	vUserID, sUserID := libs.GetQueryParam("UserID", c)
	vSchedulerDate, sSchedulerDate := libs.GetQueryParam("SchedulerDate", c)
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	errorsResponse := make([]models.ErrorResponse, 0)
	errResponse.Index = 0
	errResponse.Type = models.ErrorResponseTypeError
	if sUserID && sSchedulerDate && sFromDate && sToDate {
		var (
			scheduleruser      models.SchedulerUser
			firstName          = ""
			lastName           = ""
			resourceName       = ""
			locationName       = ""
			scheduleLocationID = 0
		)

		// Check scheduler users table
		resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND UserID = ? AND DATE_FORMAT(SchedulerDate, '%Y-%m-%d') = DATE_FORMAT(?, '%Y-%m-%d')",
			vUserID, vSchedulerDate).First(&scheduleruser)
		if resultRow.RowsAffected > 0 {
			sql := `SELECT us.FirstName, us.LastName, rs.ResourceName, lc.LocationName FROM schedulerusers sh JOIN users us ON sh.UserID = us.UserID
			JOIN resources rs ON sh.ResourceID = rs.ResourceID
			JOIN locations lc ON lc.LocationID = rs.LocationID WHERE sh.UserID = ? AND sh.ResourceID = ?`
			rows, err := db.Raw(sql, scheduleruser.UserID, scheduleruser.ResourceID).Rows()
			if err == nil {
				for rows.Next() {
					rows.Scan(
						&firstName, &lastName, &resourceName, &locationName,
					)
				}
			}
			if scheduleruser.LocationID == locationID {
				isAllocated = true
				msg = services.GetMessage(lang, "api.scheduler_user_same_location", firstName, lastName, resourceName, locationName)
			} else {
				isAllocated = true
				msg = services.GetMessage(lang, "api.scheduler_user_not_same_location", firstName, lastName, resourceName, locationName)
			}
		} else { // Check additional users table
			sql := `SELECT sc.LocationID, us.FirstName, us.LastName, rs.ResourceName, lc.LocationName FROM additionalusers au JOIN users us ON au.UserID = us.UserID
			JOIN schedules sc ON sc.ScheduleID = au.ScheduleID
			JOIN resources rs ON sc.ResourceID = rs.ResourceID
			JOIN locations lc ON lc.LocationID = rs.LocationID
			WHERE au.UserID = ? AND ScheduleEndDate > ? AND ScheduleStartDate < ?`
			rows, err := db.Raw(sql, vUserID, vFromDate, vToDate).Rows()
			if err == nil {
				for rows.Next() {
					rows.Scan(&scheduleLocationID,
						&firstName, &lastName, &resourceName, &locationName,
					)
				}
				if scheduleLocationID > 0 {
					if scheduleLocationID == locationID {
						isAllocated = true
						msg = services.GetMessage(lang, "api.additional_user_same_location", firstName, lastName, resourceName, locationName)
					} else {
						isAllocated = true
						msg = services.GetMessage(lang, "api.additional_user_not_same_location", firstName, lastName, resourceName, locationName)
					}
				}
			}
		}
	} else {
		status = 400
		msg = services.GetMessage(lang, "api.additional_user_missing_params")
	}

	if !isAllocated {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse.Message = msg
		errorsResponse = append(errorsResponse, errResponse)
	}
	resData := map[string]interface{}{
		"IsAllocated": isAllocated,
	}
	data = resData
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayUserToArrayResponse func
func ConvertArrayUserToArrayResponse(requestHeader models.RequestHeader, items []models.User) []models.UserResponse {
	responses := make([]models.UserResponse, 0)
	for _, item := range items {
		response := ConvertUserToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertUserToResponse func
func ConvertUserToResponse(requestHeader models.RequestHeader, item models.User) models.UserResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		response           models.UserResponse
		locationModel      models.Location
		locationGroupModel models.LocationGroup
	)
	response.UserID = item.UserID
	response.AccountKey = item.AccountKey
	response.FirstName = item.FirstName
	response.LastName = item.LastName
	response.Email = item.Email
	response.Language = item.Language
	response.LocationID = item.LocationID
	response.DeviceID = item.DeviceID
	response.DeviceName = item.DeviceName
	response.DeviceModel = item.DeviceModel
	response.DeviceVersion = item.DeviceVersion
	response.AppVersion = item.AppVersion
	resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", item.LocationID).First(&locationModel)
	if resultFindLocation.RowsAffected > 0 {
		response.LocationName = locationModel.LocationName
		resultFindLocationGroup := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationGroupID = ?", locationModel.LocationGroupID).First(&locationGroupModel)
		if resultFindLocationGroup.RowsAffected > 0 {
			response.LocationGroupName = locationGroupModel.LocationGroupName
		}
	}
	response.SecurityGroupID = item.SecurityGroupID
	response.IsMaster = item.IsMaster
	response.LoginPIN = item.LoginPIN
	response.UsePIN = item.UsePIN
	response.CountryCode = item.CountryCode
	response.PhoneNumber = item.PhoneNumber
	response.IsManager = item.IsManager
	response.AllowPanicReset = item.AllowPanicReset
	var (
		userDeviceMenuModels []models.UserMenu
		arrMenuID            = make([]int, 0)
	)
	db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1").Find(&userDeviceMenuModels)
	for _, userDeviceMenuModel := range userDeviceMenuModels {
		arrMenuID = append(arrMenuID, userDeviceMenuModel.MenuID)
	}
	response.Menus = arrMenuID
	return response
}

// ConvertScheduleUserToResponse func
func ConvertScheduleUserToResponse(requestHeader models.RequestHeader, item models.User) models.ScheduleUserResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		response           models.ScheduleUserResponse
		locationModel      models.Location
		locationGroupModel models.LocationGroup
	)
	response.UserID = item.UserID
	response.AccountKey = item.AccountKey
	response.FirstName = item.FirstName
	response.LastName = item.LastName
	response.Email = item.Email
	response.LocationID = item.LocationID
	resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", item.LocationID).First(&locationModel)
	if resultFindLocation.RowsAffected > 0 {
		response.LocationName = locationModel.LocationName
		resultFindLocationGroup := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationGroupID = ?", locationModel.LocationGroupID).First(&locationGroupModel)
		if resultFindLocationGroup.RowsAffected > 0 {
			response.LocationGroupName = locationGroupModel.LocationGroupName
		}
	}
	response.CountryCode = item.CountryCode
	response.PhoneNumber = item.PhoneNumber
	return response
}

// CopyDefaultValueOfTemplatesForListUser func
func CopyDefaultValueOfTemplatesForListUser(requestHeader models.RequestHeader, arrUserID []int) []models.ResponseTemplatesCopy {
	var (
		responses []models.ResponseTemplatesCopy
	)
	responses = make([]models.ResponseTemplatesCopy, 0)
	for _, userID := range arrUserID {
		var response models.ResponseTemplatesCopy
		response.UserID = userID
		response.Error = CopyDefaultValueOfTemplatesForUser(requestHeader, userID)

	}
	return responses
}

// CopyDefaultValueOfTemplatesForUser func
func CopyDefaultValueOfTemplatesForUser(requestHeader models.RequestHeader, userID int) error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		err                 error
		defaultGrids        []models.GridTemplate
		grids               []models.Grid
		defaultSearchFields []models.SearchFieldsTemplate
		searchFields        []models.SearchField
	)
	db.Find(&defaultGrids)
	grids = models.ConvertGridTemplatesToGrid(userID, defaultGrids)
	if len(grids) > 0 {
		for _, grid := range grids {
			db.Create(&grid)
		}
	}
	db.Find(&defaultSearchFields)
	searchFields = models.ConvertSearchFieldTemplatesToSearchField(userID, defaultSearchFields)
	if len(searchFields) > 0 {
		for _, searchField := range searchFields {
			db.Create(&searchField)
		}
	}
	return err
}
