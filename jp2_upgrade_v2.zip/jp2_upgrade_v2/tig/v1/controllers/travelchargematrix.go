package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetTravelTimeChargeMatrix godoc
// @Summary Get TravelTimeChargeMatrix
// @Description Get TravelTimeChargeMatrix
// @Tags TravelTimeChargeMatrix
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /traveltimechargematrix [get]
func GetTravelTimeChargeMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "GetTravelTimeChargeMatrix")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.TravelTimeChargeMatrix
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"Description"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"Unit"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayTravelTimeChargeMatrixToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetTravelTimeChargeMatrixByID godoc
// @Summary Get TravelTimeChargeMatrix By ID
// @Description Get TravelTimeChargeMatrix  By ID
// @Tags TravelTimeChargeMatrix
// @Accept  json
// @Produce  json
// @Param id path int true "TravelTimeChargeMatrix ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /traveltimechargematrix/{id} [get]
func GetTravelTimeChargeMatrixByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetTravelTimeChargeMatrixByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.TravelTimeChargeMatrix
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("TravelTimeChargeMatrixID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertTravelTimeChargeMatrixToResponse(resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateTravelTimeChargeMatrix godoc
// @Summary Create TravelTimeChargeMatrix
// @Description Create TravelTimeChargeMatrix
// @Tags TravelTimeChargeMatrix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param TravelTimeChargeMatrix body []models.TravelTimeChargeMatrix true "Create TravelTimeChargeMatrix"
// @Success 200 {object} models.APIResponseData
// @Router /traveltimechargematrix [post]
func CreateTravelTimeChargeMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "CreateTravelTimeChargeMatrix")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.TravelTimeChargeMatrix
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.TravelTimeChargeMatrix, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				postModel models.TravelTimeChargeMatrix
			)
			postModel.PassBodyJSONToModel(bp)
			postModel.CreatedBy = accountKey
			postModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(postModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				// @TODO validate for address
				resultCreate := db.Create(&postModel)
				if resultCreate.Error != nil {
					if itemMsgError == "" {
						itemMsgError = resultCreate.Error.Error()
					} else {
						itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
					}
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, postModel)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.TravelTimeChargeMatrix
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.TravelTimeChargeMatrixID)
	}
	if len(arrID) > 0 {
		db.Where("TravelTimeChargeMatrixID in (?)", arrID).Find(&resModels)
		data = ConvertArrayTravelTimeChargeMatrixToArrayResponse(resModels)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateTravelTimeChargeMatrix godoc
// @Summary Update TravelTimeChargeMatrix
// @Description Update TravelTimeChargeMatrix
// @Tags TravelTimeChargeMatrix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param TravelTimeChargeMatrix body []models.TravelTimeChargeMatrix true "Update TravelTimeChargeMatrix"
// @Success 200 {object} models.APIResponseData
// @Router /traveltimechargematrix [put]
func UpdateTravelTimeChargeMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateTravelTimeChargeMatrix")
	var (
		status                = libs.GetStatusSuccess()
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		msg, data, errors     interface{}
		errorsResponse        []models.ErrorResponse
		dataResponse          []models.TravelTimeChargeMatrix
		totalUpdatedRecord    = 0
		arrSkipID             []int
		detailsToDeleteModels []models.TravelTimeChargeMatrix
		arrToDeleteID         []int
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.TravelTimeChargeMatrix, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel   models.TravelTimeChargeMatrix
				checkModel models.TravelTimeChargeMatrix
			)
			putModel.PassBodyJSONToModel(bp)

			if putModel.Description == "" {
				errResponse := GetErrorResponseValidate(lang, 0, "api.traveltimechargematrix_required")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resultCheckExist := db.Where("Description = ? AND TravelTimeChargeMatrixID <> ?", putModel.Description, putModel.TravelTimeChargeMatrixID).First(&checkModel)
				if resultCheckExist.RowsAffected > 0 {
					errResponse := GetErrorResponseValidate(lang, 0, "api.traveltimechargematrix_exist")
					errorsResponse = append(errorsResponse, errResponse)
					arrSkipID = append(arrSkipID, checkModel.TravelTimeChargeMatrixID)
					dataResponse = append(dataResponse, checkModel)
				} else {
					if putModel.TravelTimeChargeMatrixID != 0 {
						db.Where("TravelTimeChargeMatrixID = ?", putModel.TravelTimeChargeMatrixID).First(&putModel)
						arrSkipID = append(arrSkipID, putModel.TravelTimeChargeMatrixID)
						putModel.ModifiedBy = accountKey
					} else {
						putModel.CreatedBy = accountKey
					}

					putModel.PassBodyJSONToModel(bp)

					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(putModel)
					if err != nil {
						var (
							errValid interface{}
						)
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							errValid = e.Translate(trans)
						}
						errResponse := GetErrorResponseErrorMessage(k, errValid)
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						var (
							itemMsgError string
						)

						if len(arrSkipID) > 0 {
							db.Where("TravelTimeChargeMatrixID not in (?)", arrSkipID).Find(&detailsToDeleteModels)
						}

						resultSave := db.Save(&putModel)
						if resultSave.Error != nil {
							if itemMsgError == "" {
								itemMsgError = resultSave.Error.Error()
							} else {
								itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
							}
						} else {
							arrSkipID = append(arrSkipID, putModel.TravelTimeChargeMatrixID)
							totalUpdatedRecord++
							dataResponse = append(dataResponse, putModel)
						}
						if itemMsgError != "" {
							errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
			}
		}
	}

	// Delete
	for _, ad := range detailsToDeleteModels {
		arrToDeleteID = append(arrToDeleteID, ad.TravelTimeChargeMatrixID)
	}
	if len(arrToDeleteID) > 0 {
		db.Where("TravelTimeChargeMatrixID in (?)", arrToDeleteID).Delete(&models.TravelTimeChargeMatrix{})
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.TravelTimeChargeMatrix
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.TravelTimeChargeMatrixID)
	}
	if len(arrID) > 0 {
		db.Where("TravelTimeChargeMatrixID in (?)", arrID).Find(&resModels)
		data = ConvertArrayTravelTimeChargeMatrixToArrayResponse(resModels)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteTravelTimeChargeMatrix godoc
// @Summary Delete TravelTimeChargeMatrix
// @Description Delete TravelTimeChargeMatrix
// @Tags TravelTimeChargeMatrix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "TravelTimeChargeMatrix ID"
// @Success 200 {object} models.APIResponseData
// @Router /traveltimechargematrix/{id} [delete]
func DeleteTravelTimeChargeMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteTravelTimeChargeMatrix")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.TravelTimeChargeMatrix
		)
		resultFind := db.Where("TravelTimeChargeMatrixID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayTravelTimeChargeMatrixToArrayResponse func
func ConvertArrayTravelTimeChargeMatrixToArrayResponse(items []models.TravelTimeChargeMatrix) []models.TravelTimeChargeMatrixResponse {
	responses := make([]models.TravelTimeChargeMatrixResponse, 0)
	for _, item := range items {
		response := ConvertTravelTimeChargeMatrixToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertTravelTimeChargeMatrixToResponse func
func ConvertTravelTimeChargeMatrixToResponse(item models.TravelTimeChargeMatrix) models.TravelTimeChargeMatrixResponse {
	var (
		response models.TravelTimeChargeMatrixResponse
	)
	response.TravelTimeChargeMatrixID = item.TravelTimeChargeMatrixID
	response.Unit = item.Unit
	response.Price = item.Price
	response.Description = item.Description
	response.DiscountPercent = item.DiscountPercent
	response.BufferPercent = item.BufferPercent
	response.IsIncludeTax = item.IsIncludeTax
	response.TaxID = item.TaxID
	return response
}
