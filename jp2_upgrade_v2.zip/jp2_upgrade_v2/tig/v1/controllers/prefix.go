package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetPrefix godoc
// @Summary Get Prefix
// @Description Get Prefix
// @Tags Prefix
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /prefix [get]
func GetPrefix(c *gin.Context) {
	defer libs.RecoverError(c, "GetPrefix")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Prefix
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	bp = bp.Order("PrefixID ASC")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPrefixesToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPrefixByID godoc
// @Summary Get Prefix By ID
// @Description Get Prefix  By ID
// @Tags Prefix
// @Accept  json
// @Produce  json
// @Param id path int true "Prefix ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /prefix/{id} [get]
func GetPrefixByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPrefixByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Prefix
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("PrefixID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertPrefixToResponse(resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePrefix godoc
// @Summary Create Prefix
// @Description Create Prefix
// @Tags Prefix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Prefix body []models.PrefixResponse true "Create Prefix"
// @Success 200 {object} models.APIResponseData
// @Router /prefix [post]
func CreatePrefix(c *gin.Context) {
	defer libs.RecoverError(c, "CreatePrefix")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Prefix
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.Prefix, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.Prefix
			)
			resModel.PassBodyJSONToModel(bp)
			resultFind := db.Where("PrefixID = ? OR DocumentSequence = ?", resModel.PrefixID, resModel.DocumentSequence).First(&resModel)
			resModel.PassBodyJSONToModel(bp)
			resModel.CreatedBy = accountKey
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resModel)
				} else {
					db.Create(&resModel)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Prefix
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.PrefixID)
	}
	if len(arrID) > 0 {
		db.Where("PrefixID in (?)", arrID).Find(&resModels)
		data = ConvertArrayPrefixesToArrayResponse(resModels)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePrefix godoc
// @Summary Update Prefix
// @Description Update Prefix
// @Tags Prefix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Prefix body []models.PrefixResponse true "Update Prefix"
// @Success 200 {object} models.APIResponseData
// @Router /prefix [put]
func UpdatePrefix(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePrefix")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Prefix
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Prefix, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.Prefix
			)
			resModel.PUTPassBodyJSONToModel(bp)
			resultFind := db.Where("PrefixID = ? OR DocumentSequence = ?", resModel.PrefixID, resModel.DocumentSequence).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
			resModel.PUTPassBodyJSONToModel(bp)
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					resModel.ModifiedBy = accountKey
					db.Save(&resModel)
				} else {
					resModel.CreatedBy = accountKey
					db.Create(&resModel)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Prefix
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.PrefixID)
	}
	if len(arrID) > 0 {
		db.Where("PrefixID in (?)", arrID).Find(&resModels)
		data = ConvertArrayPrefixesToArrayResponse(resModels)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePrefix godoc
// @Summary Delete Prefix
// @Description Delete Prefix
// @Tags Prefix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Prefix ID"
// @Success 200 {object} models.APIResponseData
// @Router /prefix/{id} [delete]
func DeletePrefix(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePrefix")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Prefix
		)
		resultFind := db.Where("PrefixID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			/* uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel) */
			deletedResult := db.Delete(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPrefixesToArrayResponse func
func ConvertArrayPrefixesToArrayResponse(items []models.Prefix) []models.PrefixResponse {
	responses := make([]models.PrefixResponse, 0)
	for _, item := range items {
		response := ConvertPrefixToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPrefixToResponse func
func ConvertPrefixToResponse(item models.Prefix) models.PrefixResponse {
	var (
		response models.PrefixResponse
	)
	response.PrefixID = item.PrefixID
	response.DocumentSequence = item.DocumentSequence
	response.Prefix = item.Prefix
	response.Length = item.Length
	return response
}

// ResetDocumentSequencesIfGreaterLength func
func ResetDocumentSequencesIfGreaterLength(requestHeader models.RequestHeader) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		sequenceModel  models.DocumentSequency
		prefixModels   []models.Prefix
		updateSequence = false
	)
	resultFindSequence := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequenceModel)
	if resultFindSequence.RowsAffected > 0 {
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&prefixModels)
		for _, prefix := range prefixModels {
			switch prefix.DocumentSequence {
			case "JobNumber":
				{
					nextJobNumber := sequenceModel.JobNumber
					if len(strconv.Itoa(nextJobNumber)) > prefix.Length {
						sequenceModel.JobNumber = 1
						updateSequence = true
					}
				}
			case "EstimateNumber":
				{
					nextEstimateNumber := sequenceModel.EstimateNumber
					if len(strconv.Itoa(nextEstimateNumber)) > prefix.Length {
						sequenceModel.EstimateNumber = 1
						updateSequence = true
					}
				}
			case "InvoiceNumber":
				{
					nextInvoiceNumber := sequenceModel.InvoiceNumber
					if len(strconv.Itoa(nextInvoiceNumber)) > prefix.Length {
						sequenceModel.InvoiceNumber = 1
						updateSequence = true
					}
				}
			case "CreditNoteNumber":
				{
					nextCreditNoteNumber := sequenceModel.CreditNoteNumber
					if len(strconv.Itoa(nextCreditNoteNumber)) > prefix.Length {
						sequenceModel.CreditNoteNumber = 1
						updateSequence = true
					}
				}
			case "CustomerCode":
				{
					nextCustomerCode := sequenceModel.CustomerCode
					if len(strconv.Itoa(nextCustomerCode)) > prefix.Length {
						sequenceModel.CustomerCode = 1
						updateSequence = true
					}
				}
			case "VendorCode":
				{
					nextVendorCode := sequenceModel.VendorCode
					if len(strconv.Itoa(nextVendorCode)) > prefix.Length {
						sequenceModel.VendorCode = 1
						updateSequence = true
					}
				}
			case "ContractorCode":
				{
					nextContractorCode := sequenceModel.ContractorCode
					if len(strconv.Itoa(nextContractorCode)) > prefix.Length {
						sequenceModel.ContractorCode = 1
						updateSequence = true
					}
				}
			case "ResourceCode":
				{
					nextResourceCode := sequenceModel.ResourceCode
					if len(strconv.Itoa(nextResourceCode)) > prefix.Length {
						sequenceModel.ResourceCode = 1
						updateSequence = true
					}
				}
			}

		}
		if updateSequence {
			db.Save(&sequenceModel)
		}
	}
}
