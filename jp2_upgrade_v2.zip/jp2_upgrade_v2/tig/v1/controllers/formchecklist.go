package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetFormCheckList godoc
// @Summary Get FormCheckList
// @Description Get FormCheckList
// @Tags FormCheckList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklist [get]
func GetFormCheckList(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormCheckList")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormCheckList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}

	var bp = db
	if sStart && sLength {
		vStartInt, _ := strconv.Atoi(vStart)
		vLengthInt, _ := strconv.Atoi(vLength)
		bp = bp.Limit(vLengthInt).Offset(vStartInt)
	}
	bp = bp.Preload("QuestionGroups", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
	})
	bp = bp.Preload("QuestionGroups.Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Question ASC")
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"FormCheckListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayFormCheckListToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetFormCheckListByID godoc
// @Summary Get FormCheckList By ID
// @Description Get FormCheckList By ID
// @Tags FormCheckList
// @Accept  json
// @Produce  json
// @Param id path int true "FormCheckList ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklist/{id} [get]
func GetFormCheckListByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormCheckListByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.FormCheckList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"QuestionGroups",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Preload(
		"QuestionGroups.Questions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND FormCheckListID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertFormCheckListToResponse(resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateFormCheckList godoc
// @Summary Create FormCheckList
// @Description Create FormCheckList
// @Tags FormCheckList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormCheckList body models.FormCheckListResponse true "Create FormCheckList"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklist [post]
func CreateFormCheckList(c *gin.Context) {
	// @TODO if post exist FormCheckListquestiongroups => override old data
	defer libs.RecoverError(c, "CreateFormCheckList")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.FormCheckList
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		itemMsgError = FormCheckListValidation(requestHeader, lang, resModel, itemMsgError)
		if itemMsgError == "" {
			for i := range resModel.QuestionGroups {
				resModel.QuestionGroups[i].CreatedBy = accountKey
				if len(resModel.QuestionGroups[i].Questions) > 0 {
					for k := range resModel.QuestionGroups[i].Questions {
						resModel.QuestionGroups[i].Questions[k].CreatedBy = accountKey
					}
				}
			}
		}
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				data = ConvertFormCheckListToResponse(resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateFormCheckList godoc
// @Summary Update FormCheckList
// @Description Update FormCheckList
// @Tags FormCheckList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormCheckList body models.FormCheckListResponse true "Update FormCheckList"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklist/{id} [put]
func UpdateFormCheckList(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateFormCheckList")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.FormCheckList
	)
	resultFind := db.Where("FormCheckListID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.FormCheckListID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			itemMsgError = FormCheckListValidation(requestHeader, lang, resModel, itemMsgError)
			if itemMsgError == "" {
				timeNow := time.Now()
				for i := range resModel.QuestionGroups {
					if resModel.QuestionGroups[i].CreatedBy <= 0 {
						resModel.QuestionGroups[i].CreatedBy = accountKey
						resModel.QuestionGroups[i].CreatedDate = &timeNow
					}
					resModel.QuestionGroups[i].ModifiedBy = accountKey
					resModel.QuestionGroups[i].ModifiedDate = &timeNow
					if len(resModel.QuestionGroups[i].Questions) > 0 {
						for k := range resModel.QuestionGroups[i].Questions {
							if resModel.QuestionGroups[i].Questions[k].CreatedBy <= 0 {
								resModel.QuestionGroups[i].Questions[k].CreatedBy = accountKey
								resModel.QuestionGroups[i].Questions[k].CreatedDate = &timeNow
							}
							resModel.QuestionGroups[i].Questions[k].ModifiedBy = accountKey
							resModel.QuestionGroups[i].Questions[k].ModifiedDate = &timeNow
						}
					}
				}
			}
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					var (
						arrSkipGroupID []string
					)
					for _, questionGroup := range resModel.QuestionGroups {
						var (
							arrSkipQuestionID []int
						)
						if len(questionGroup.Questions) > 0 {
							for _, question := range questionGroup.Questions {
								arrSkipQuestionID = append(arrSkipQuestionID, question.FormCheckListQuestionID)
							}
						}
						if len(arrSkipQuestionID) > 0 {
							db.Where("FormCheckListQuestionGroupID = ? AND FormCheckListQuestionID not in (?)", questionGroup.FormCheckListQuestionGroupID, arrSkipQuestionID).Model(&models.FormCheckListQuestion{}).Updates(models.FormCheckListQuestion{IsDeleted: true, ModifiedBy: accountKey})
						} else {
							db.Where("FormCheckListQuestionGroupID = ?", questionGroup.FormCheckListQuestionGroupID).Model(&models.FormCheckListQuestion{}).Updates(models.FormCheckListQuestion{IsDeleted: true, ModifiedBy: accountKey})
						}
						arrSkipGroupID = append(arrSkipGroupID, questionGroup.FormCheckListQuestionGroupID)
					}
					var (
						deleteGroupModels []models.FormCheckListQuestionGroup
						deleteGroupIDs    []string
					)
					if len(arrSkipGroupID) > 0 {
						db.Where("FormCheckListID = ? AND FormCheckListQuestionGroupID not in (?)", resModel.FormCheckListID, arrSkipGroupID).Find(&deleteGroupModels)
						// @TODO delete on groups
						db.Where("FormCheckListID = ? AND FormCheckListQuestionGroupID not in (?)", resModel.FormCheckListID, arrSkipGroupID).Model(&models.FormCheckListQuestionGroup{}).Updates(models.FormCheckListQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("FormCheckListID = ?", resModel.FormCheckListID).Find(&deleteGroupModels)
						// @TODO delete on groups
						db.Where("FormCheckListID = ?", resModel.FormCheckListID).Model(&models.FormCheckListQuestionGroup{}).Updates(models.FormCheckListQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})
					}
					// @TODO delete on questions
					for _, g := range deleteGroupModels {
						deleteGroupIDs = append(deleteGroupIDs, g.FormCheckListQuestionGroupID)
					}
					if len(deleteGroupIDs) > 0 {
						db.Where("FormCheckListQuestionGroupID in (?)", deleteGroupIDs).Model(&models.FormCheckListQuestion{}).Updates(models.FormCheckListQuestion{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"QuestionGroups",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Preload(
						"QuestionGroups.Questions",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("IFNULL(IsDeleted, 0) <> 1 AND FormCheckListID = ?", id).First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertFormCheckListToResponse(resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteFormCheckList godoc
// @Summary Delete FormCheckList
// @Description Delete FormCheckList
// @Tags FormCheckList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklist/{id} [delete]
func DeleteFormCheckList(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteFormCheckList")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.FormCheckList
		)
		resultFind := db.Preload(
			"QuestionGroups",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"QuestionGroups.Questions",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("FormCheckListID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				for _, questionGroup := range resModel.QuestionGroups {
					db.Where("FormCheckListQuestionGroupID = ?", questionGroup.FormCheckListQuestionGroupID).Model(&models.FormCheckListQuestion{}).Updates(models.FormCheckListQuestion{IsDeleted: true, ModifiedBy: accountKey})
				}
				db.Where("FormCheckListID = ?", resModel.FormCheckListID).Model(&models.FormCheckListQuestionGroup{}).Updates(models.FormCheckListQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})

			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayFormCheckListToArrayResponse func
func ConvertArrayFormCheckListToArrayResponse(items []models.FormCheckList) []models.FormCheckListResponse {
	responses := make([]models.FormCheckListResponse, 0)
	for _, item := range items {
		response := ConvertFormCheckListToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertFormCheckListToResponse func
func ConvertFormCheckListToResponse(item models.FormCheckList) models.FormCheckListResponse {
	var (
		response models.FormCheckListResponse
	)
	response.FormCheckListID = item.FormCheckListID
	response.FormCheckListName = item.FormCheckListName
	response.IsCommentVisible = item.IsCommentVisible
	response.IsCommentMandatory = item.IsCommentMandatory

	details := make([]models.FormCheckListQuestionGroupResponse, 0)
	questionDetails := make([]models.FormCheckListQuestionResponse, 0)
	for _, v := range item.QuestionGroups {
		var detail models.FormCheckListQuestionGroupResponse
		detail.FormCheckListQuestionGroupID = v.FormCheckListQuestionGroupID
		detail.FormCheckListID = v.FormCheckListID
		detail.GroupName = v.GroupName
		detail.Sort = v.Sort
		for _, d := range v.Questions {
			var questionDetail models.FormCheckListQuestionResponse
			questionDetail.FormCheckListQuestionID = d.FormCheckListQuestionID
			questionDetail.FormCheckListQuestionGroupID = d.FormCheckListQuestionGroupID
			questionDetail.Question = d.Question
			questionDetail.IsPhotoEnable = d.IsPhotoEnable
			questionDetail.IsMandatory = d.IsMandatory
			questionDetail.RowID = d.FormCheckListQuestionID
			questionDetails = append(questionDetails, questionDetail)
		}
		details = append(details, detail)
	}
	response.QuestionGroups = details
	response.Questions = questionDetails
	response.FormCheckListID = item.FormCheckListID

	return response
}

// FormCheckListValidation func
func FormCheckListValidation(requestHeader models.RequestHeader, lang string, resModel models.FormCheckList, itemMsgError string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	mappingGroupID := make(map[string]interface{})
	if len(resModel.QuestionGroups) <= 0 {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.formchecklist_need_least_one_group"))
	} else {
		for _, group := range resModel.QuestionGroups {
			if group.FormCheckListQuestionGroupID == "" {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.formchecklistquestiongroupid_required"))
			} else {
				hasQuestion := false
				for _, question := range group.Questions {
					if group.FormCheckListQuestionGroupID == question.FormCheckListQuestionGroupID {
						hasQuestion = true
						break
					}
				}
				if !hasQuestion {
					//itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.formchecklist_need_least_one_question_for_group", group.FormCheckListQuestionGroupID))
				} else {
					// find group in db
					resultFindGroupID := db.Where("FormCheckListQuestionGroupID = ? AND FormCheckListID <> ? AND IFNULL(IsDeleted, 0) <> 1", group.FormCheckListQuestionGroupID, resModel.FormCheckListID).First(&models.FormCheckListQuestionGroup{})
					if resultFindGroupID.RowsAffected > 0 {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.formchecklistquestiongroupid_exist_db", group.FormCheckListQuestionGroupID))
					} else {
						// find group in body params
						if _, ok := mappingGroupID[group.FormCheckListQuestionGroupID]; ok {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.formchecklistquestiongroupid_exist_param", group.FormCheckListQuestionGroupID))
						} else {
							mappingGroupID[group.FormCheckListQuestionGroupID] = group.FormCheckListQuestionGroupID
						}
					}
				}
			}
		}
	}
	return itemMsgError
}
