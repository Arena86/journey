package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetBusinessPartner godoc
// @Summary Get Business Partner
// @Description Get Business Partner
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param IsVendor query string false "IsVendor"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner [get]
func GetBusinessPartner(c *gin.Context) {
	defer libs.RecoverError(c, "GetBusinessPartner")
	var (
		status           = libs.GetStatusSuccess()
		businessPartners []models.BusinessPartner
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		msg              interface{}
		isArchived       = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	getAllBP := false
	vIsCompany, sIsCompany := libs.GetQueryParam("IsCompany", c)
	if sIsCompany {
		bIsCompany, eIsCompany := strconv.ParseBool(vIsCompany)
		if eIsCompany == nil {
			getAllBP = bIsCompany
		}
	}
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Addresses", func(dbAdr *gorm.DB) *gorm.DB {
		dbAdr = dbAdr.Where("Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
		postalCodeSort := libs.GetSortValueFromKey(c, "PostalCode")
		if postalCodeSort != "" {
			dbAdr = dbAdr.Order("PostalCode " + postalCodeSort)
		}
		return dbAdr
	})
	bp = bp.Preload("CustomerGroups", func(dbAdr *gorm.DB) *gorm.DB {
		dbAdr = dbAdr.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		customerGroupNameSort := libs.GetSortValueFromKey(c, "CustomerGroupName")
		if customerGroupNameSort != "" {
			dbAdr = dbAdr.Order("CustomerGroupName " + customerGroupNameSort)
		}
		return dbAdr
	})

	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)
	if locationID > 0 && !getAllBP {
		bp = bp.Where("FIND_IN_SET(?, LocationID)", locationID)
	}

	vIsVendor, sIsVendor := libs.GetQueryParam("IsVendor", c)
	vIsCustomer, sIsCustomer := libs.GetQueryParam("IsCustomer", c)
	vIsContractor, sIsContractor := libs.GetQueryParam("IsContractor", c)

	// filter vendor,customer,contractor
	businessTypeWhere := ``
	if sIsVendor {
		bIsVendor, eIsVendor := strconv.ParseBool(vIsVendor)
		if eIsVendor == nil {
			if bIsVendor {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IsVendor = 1"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IsVendor = 1"
				}
			} else {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IFNULL(IsVendor, 0) = 0"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IFNULL(IsVendor, 0) = 0"
				}
			}
		}
	}
	if sIsContractor {
		bIsContractor, eIsContractor := strconv.ParseBool(vIsContractor)
		if eIsContractor == nil {
			if bIsContractor {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IsContractor = 1"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IsContractor = 1"
				}
			} else {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IFNULL(IsContractor, 0) = 0"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IFNULL(IsContractor, 0) = 0"
				}
			}
		}
	}
	if sIsCustomer {
		bIsCustomer, eIsCustomer := strconv.ParseBool(vIsCustomer)
		if eIsCustomer == nil {
			if bIsCustomer {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IsCustomer = 1"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IsCustomer = 1"
				}
			} else {
				if businessTypeWhere == "" {
					businessTypeWhere = businessTypeWhere + "IFNULL(IsCustomer, 0) = 0"
				} else {
					businessTypeWhere = businessTypeWhere + " OR IFNULL(IsCustomer, 0) = 0"
				}
			}
		}
	}
	if businessTypeWhere != "" {
		bp = bp.Where(businessTypeWhere)
	}
	// end
	//arrBool := []string{"IsPrivate", "IsContractor", "IsCustomer", "IsVendor"}
	arrBool := []string{"IsPrivate"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{
		"TaxNumber", "EmailAddress", "LastName", "FirstName", "CompanyName",
		"BusinessPartnerCode", "DefaultCurrency",
	}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	vPhone, sPhone := libs.GetQueryParam("PhoneNumber", c)
	if sPhone {
		dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		var (
			phones []models.Phone
		)
		businessPartnerTableName := models.BusinessPartner{}.TableName()
		arrPartnersOnPhonesID := make([]int, 0)
		dbP.Where("PhoneNumber like ?", "%"+vPhone+"%").Find(&phones)
		for _, p := range phones {
			if p.Entity == businessPartnerTableName {
				if !libs.InArrayInteger(p.EntityID, arrPartnersOnPhonesID) {
					arrPartnersOnPhonesID = append(arrPartnersOnPhonesID, p.EntityID)
				}
			}
		}
		if len(arrPartnersOnPhonesID) <= 0 {
			arrPartnersOnPhonesID = append(arrPartnersOnPhonesID, -1)
		}
		bp = bp.Where("BusinessPartnerID in (?)", arrPartnersOnPhonesID)
	}

	vPostalCode, sPostalCode := libs.GetQueryParam("PostalCode", c)
	if sPostalCode {
		dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		var (
			address []models.Address
		)
		businessPartnerTableName := models.BusinessPartner{}.TableName()
		arrPartnersOnAddressID := make([]int, 0)
		dbP.Where("PostalCode LIKE ?", "%"+vPostalCode+"%").Find(&address)
		for _, p := range address {
			if p.Entity == businessPartnerTableName {
				arrPartnersOnAddressID = append(arrPartnersOnAddressID, p.EntityID)
			}
		}
		if len(arrPartnersOnAddressID) <= 0 {
			arrPartnersOnAddressID = append(arrPartnersOnAddressID, -1)
		}
		bp = bp.Where("BusinessPartnerID in (?)", arrPartnersOnAddressID)
	}

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.BusinessPartner{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c, "PostalCode", "CustomerGroupName", "PriceListName")

	reasonSort := libs.GetSortValueFromKey(c, "PriceListName")
	if reasonSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		var priceLists []models.PriceList
		arrReasonIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("PriceListName " + reasonSort).Find(&priceLists)
		for _, priceList := range priceLists {
			arrReasonIDSort = append(arrReasonIDSort, priceList.PriceListID)
		}
		bp = bp.Order("PriceListID " + reasonSort)
		if len(arrReasonIDSort) > 0 {
			strJoin := libs.IntJoin(arrReasonIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(PriceListID," + strJoin + ")")
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&businessPartners).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(businessPartners) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	businessPartnersResponse := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, businessPartners)
	for i, b := range businessPartnersResponse {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())

		udfParams := make([]string, 0)
		if sIsVendor {
			bIsVendor, eIsVendor := strconv.ParseBool(vIsVendor)
			if eIsVendor == nil {
				if bIsVendor {
					udfParams = append(udfParams, "vendors")
				}
			}
		}
		if sIsCustomer {
			bIsCustomer, eIsCustomer := strconv.ParseBool(vIsCustomer)
			if eIsCustomer == nil {
				if bIsCustomer {
					udfParams = append(udfParams, "customers")
				}
			}
		}
		if sIsContractor {
			bIsContractor, eIsContractor := strconv.ParseBool(vIsContractor)
			if eIsContractor == nil {
				if bIsContractor {
					udfParams = append(udfParams, "contractors")
				}
			}
		}

		if len(udfParams) > 0 {
			dbu = dbu.Where("UDFKey in (?)", udfParams)
		}

		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		businessPartnersResponse[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			businessPartnersResponse[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		businessPartnersResponse[i].UDFs = udfResponses
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = businessPartnersResponse
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetBusinessPartnerByID godoc
// @Summary Get Business Partner By ID
// @Description Get Business Partner By ID
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param id path int true "Business Partner ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner/{id} [get]
func GetBusinessPartnerByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetBusinessPartnerByID")
	var (
		status           = libs.GetStatusSuccess()
		businessPartners models.BusinessPartner
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		msg, data        interface{}
		responsesData    gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Addresses",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		models.BusinessPartner{}.TableName(),
	).Preload(
		"Phones",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		models.BusinessPartner{}.TableName(),
	).Preload(
		"Locations",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?", ID).First(&businessPartners)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		businessPartnersResponse := ConvertBusinessPartnerToResponse(requestHeader, businessPartners)
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())

		udfParams := make([]string, 0)

		vIsVendor, sIsVendor := libs.GetQueryParam("IsVendor", c)
		vIsCustomer, sIsCustomer := libs.GetQueryParam("IsCustomer", c)
		vIsContractor, sIsContractor := libs.GetQueryParam("IsContractor", c)

		if sIsVendor {
			bIsVendor, eIsVendor := strconv.ParseBool(vIsVendor)
			if eIsVendor == nil {
				if bIsVendor {
					udfParams = append(udfParams, "vendors")
				}
			}
		}
		if sIsCustomer {
			bIsCustomer, eIsCustomer := strconv.ParseBool(vIsCustomer)
			if eIsCustomer == nil {
				if bIsCustomer {
					udfParams = append(udfParams, "customers")
				}
			}
		}
		if sIsContractor {
			bIsContractor, eIsContractor := strconv.ParseBool(vIsContractor)
			if eIsContractor == nil {
				if bIsContractor {
					udfParams = append(udfParams, "contractors")
				}
			}
		}

		if len(udfParams) > 0 {
			dbu = dbu.Where("UDFKey in (?)", udfParams)
		}

		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)

		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		businessPartnersResponse.UDF = make(map[string]interface{}) // declare field as a map[string]string

		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, businessPartnersResponse.BusinessPartnerID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			businessPartnersResponse.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		businessPartnersResponse.UDFs = udfResponses
		data = businessPartnersResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateBusinessPartner godoc
// @Summary Create Business Partner
// @Description Create Business Partner
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param BusinessPartner body []models.BusinessPartnerResponse true "Create Business Partner"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner [post]
func CreateBusinessPartner(c *gin.Context) {
	apiName := "CreateBusinessPartner"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.BusinessPartner
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	dataResponse = make([]models.BusinessPartner, 0)
	errorsResponse = make([]models.ErrorResponse, 0)

	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				partner models.BusinessPartner
			)
			partner.PassBodyJSONToModel(bp)

			if !partner.IsPrivate {
				resultFindBP := db.Where("CompanyName = ? AND IsDeleted = 0", partner.CompanyName).First(&models.BusinessPartner{})
				if resultFindBP.RowsAffected > 0 {
					errResponse := GetErrorResponseValidate(lang, k, "api.businesspartner_companyname")
					errorsResponse = append(errorsResponse, errResponse)
					continue
				}
			}

			partner.CreatedBy = accountKey
			partner.ModifiedBy = accountKey
			partner.LocationID = strconv.Itoa(locationID)
			ResetDocumentSequencesIfGreaterLength(requestHeader)
			CheckDocumentSequencesBeforeCreate(requestHeader)
			var (
				sequencyModel    models.DocumentSequency
				customerPrefix   models.Prefix
				vendorPrefix     models.Prefix
				contractorPrefix models.Prefix
			)
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
			db.Where("DocumentSequence = ?", "CustomerCode").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&customerPrefix)
			db.Where("DocumentSequence = ?", "VendorCode").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&vendorPrefix)
			db.Where("DocumentSequence = ?", "ContractorCode").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&contractorPrefix)
			partner.GenerateDefaultValue(sequencyModel, customerPrefix, vendorPrefix, contractorPrefix)

			// @TODO validate for partner
			errBusinessName := ""
			if partner.IsPrivate {
				errBusinessName = partner.FirstName + " " + partner.LastName
			} else {
				errBusinessName = partner.CompanyName
			}
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(partner)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = errBusinessName + " - " + e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				// @TODO validate for address
				if len(partner.Addresses) > 0 {
					addressValid := make([]models.Address, 0)
					for _, address := range partner.Addresses {
						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(address)
						if err != nil {
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								itemMsgError = itemMsgError + e.Translate(trans) + "\n"
							}
						} else {
							address.Entity = models.BusinessPartner{}.TableName()
							address.CreatedBy = accountKey
							addressValid = append(addressValid, address)
						}
					}
					partner.Addresses = addressValid
				}
				// @TODO validate for phone
				if len(partner.Phones) > 0 {
					phonesValid := make([]models.Phone, 0)
					for _, phone := range partner.Phones {

						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(phone)
						if err != nil {
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								itemMsgError = itemMsgError + e.Translate(trans) + "\n"
							}
						} else {
							phone.Entity = models.BusinessPartner{}.TableName()
							phone.CreatedBy = accountKey
							phonesValid = append(phonesValid, phone)
						}
					}
					partner.Phones = phonesValid
				}

				var (
					objectsLocation []int
					locations       []models.BusinessPartnerLocation
					res             interface{}
					strLocations    []string
				)
				locations = make([]models.BusinessPartnerLocation, 0)

				_, res = services.ConvertJSONValueToVariable("LocationIDs", bp)
				if res != nil {
					locationJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(locationJSON, &objectsLocation)
						if len(objectsLocation) > 0 {
							for _, locationID := range objectsLocation {
								var (
									partnerLocation models.BusinessPartnerLocation
									location        models.Location
								)
								resultFindLocation := db.Where("LocationID = ?", locationID).First(&location)
								if resultFindLocation.RowsAffected > 0 {
									partnerLocation.LocationGroupID = location.LocationGroupID
								}
								partnerLocation.LocationID = locationID
								partnerLocation.CreatedBy = accountKey
								validate, trans := services.GetValidatorTranslate()
								err := validate.Struct(partnerLocation)
								if err != nil {
									errs := err.(validator.ValidationErrors)
									for _, e := range errs {
										itemMsgError = itemMsgError + e.Translate(trans) + "\n"
									}
								} else {
									locations = append(locations, partnerLocation)
									strLocations = append(strLocations, strconv.Itoa(partnerLocation.LocationID))
								}
							}
						}
					}
				}
				partner.Locations = locations
				partner.LocationID = strings.Join(strLocations, ",")
				// @TODO need to required > 0 for address, phone

				// Generate BP Code
				if partner.BusinessPartnerCode == "" {
					for {
						partner.BusinessPartnerCode = libs.GenerateBusinessPartnerCode()
						resultFindCheckPartner := db.Where("BusinessPartnerCode = ?", partner.BusinessPartnerCode).First(&models.BusinessPartner{})
						if resultFindCheckPartner.RowsAffected == 0 {
							break
						}
					}
				} else {
					for {
						resultFindCheckPartner := db.Where("BusinessPartnerCode = ?", partner.BusinessPartnerCode).First(&models.BusinessPartner{})
						if resultFindCheckPartner.RowsAffected == 0 {
							break
						}
						partner.BusinessPartnerCode = libs.GenerateBusinessPartnerCode()
					}
				}

				// @TODO Update to xero
				var (
					createParnerSuccess = false
					xeroConfig          models.XeroConfig
				)
				resultFindXeroConfig := db.First(&xeroConfig)
				if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
					resultCreate := db.Create(&partner)
					if resultCreate.Error == nil {
						contacts := make([]models.BusinessPartner, 0)
						contacts = append(contacts, partner)
						xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, contacts)
						if len(xeroResponses) > 0 {
							contactResponse := xeroResponses[0]
							if contactResponse.Status == 200 {
								createParnerSuccess = true
								var xeroContactResponse models.BusinessPartner
								dataContact, errContact := json.Marshal(contactResponse.Data)
								if errContact == nil {
									json.Unmarshal(dataContact, &xeroContactResponse)
									partner = xeroContactResponse
								}
							} else {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", contactResponse.Msg))
								partner.IsIntegrationPending = true
								partner.IntegrationError = fmt.Sprintf("%v", contactResponse.Msg)
								resultCreate := db.Save(&partner)
								if resultCreate.Error == nil {
									createParnerSuccess = true
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
								}
							}
						} else {
							// add error message
						}
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					}
				} else {
					resultCreate := db.Create(&partner)
					if resultCreate.Error == nil {
						createParnerSuccess = true
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					}
				}
				// end
				if createParnerSuccess {
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					totalUpdatedRecord++
					dataResponse = append(dataResponse, partner)
					IncreaseDocumentSequencesAfterCreatePartner(requestHeader)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "BusinessPartnerID", partner.BusinessPartnerID)
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
						}
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		businessPartners []models.BusinessPartner
	)
	arrPartnersID := make([]int, 0)
	for _, v := range dataResponse {
		arrPartnersID = append(arrPartnersID, v.BusinessPartnerID)
	}
	if len(arrPartnersID) > 0 {
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload("Locations").Where("BusinessPartnerID in (?)", arrPartnersID).Find(&businessPartners)
		dataResponses := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, businessPartners)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())
			udfParams := make([]string, 0)
			if b.IsVendor {
				udfParams = append(udfParams, "vendors")
			}
			if b.IsCustomer {
				udfParams = append(udfParams, "customers")
			}
			if b.IsContractor {
				udfParams = append(udfParams, "contractors")
			}
			if len(udfParams) > 0 {
				dbu = dbu.Where("UDFKey in (?)", udfParams)
			}
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateBusinessPartner godoc
// @Summary Update Business Partner
// @Description Update Business Partner
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param BusinessPartner body []models.BusinessPartnerResponse true "Create Business Partner"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner [put]
func UpdateBusinessPartner(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateBusinessPartner")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.BusinessPartner
		totalUpdatedRecord = 0
		//xeroConfig         models.XeroConfig
		//xeroIntegration    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	// Get Xero Config
	/*resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
		xeroIntegration = true
	}*/

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.BusinessPartner, 0)
	/*isQuickCustomer := false
	vQuickCustomer, sQuickCustomer := libs.GetQueryParam("isquickcustomer", c)
	if sQuickCustomer {
		bQuickCustomer, eQuickCustomer := strconv.ParseBool(vQuickCustomer)
		if eQuickCustomer == nil {
			isQuickCustomer = bQuickCustomer
		}
	}*/
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				partner models.BusinessPartner
			)
			partner.PassBodyJSONToModel(bp)
			resultFind := db.Where("BusinessPartnerID = ?", partner.BusinessPartnerID).First(&partner)
			if resultFind.RowsAffected > 0 {
				partner.PassBodyJSONToModel(bp)
				partner.ModifiedBy = accountKey
				// @TODO Check duplicated BusinessPartnerCode
				if partner.BusinessPartnerCode != "" {
					var checkPartnerModel models.BusinessPartner
					resultFindCheckPartner := db.Where("BusinessPartnerCode = ? AND BusinessPartnerID <> ?", partner.BusinessPartnerCode, partner.BusinessPartnerID).First(&checkPartnerModel)
					if resultFindCheckPartner.RowsAffected > 0 {
						errResponse := GetErrorResponseValidate(lang, k, "api.partner_code_exist")
						errorsResponse = append(errorsResponse, errResponse)
						break
					}
				}

				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(partner)
				errBusinessName := ""
				if partner.IsPrivate {
					errBusinessName = partner.FirstName + " " + partner.LastName
				} else {
					errBusinessName = partner.CompanyName
				}
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = errBusinessName + " - " + e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
						res          interface{}
					)
					// @TODO validate for address
					// set address empty
					partner.Addresses = make([]models.Address, 0)
					var (
						objectsAddress        []map[string]interface{}
						addresses             []models.Address
						arrAddressSkipID      []int
						arrAddressToDeleteID  []int
						addressToDeleteModels []models.Address
					)
					addresses = make([]models.Address, 0)
					_, res = services.ConvertJSONValueToVariable("Addresses", bp)
					if res != nil {
						addressJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(addressJSON, &objectsAddress)
							if len(objectsAddress) > 0 {
								for _, objAddress := range objectsAddress {
									var (
										address models.Address
									)
									address.PassBodyJSONToModel(objAddress)
									resultFindAddress := db.Where("AddressID = ?", address.AddressID).First(&address)
									if resultFindAddress.RowsAffected > 0 {
										arrAddressSkipID = append(arrAddressSkipID, address.AddressID)
										address.PassBodyJSONToModel(objAddress)
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(address)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = itemMsgError + e.Translate(trans) + "\n"
											}
										} else {
											address.Entity = models.BusinessPartner{}.TableName()
											address.ModifiedBy = accountKey
											addresses = append(addresses, address)
										}
									} else {
										address.PassBodyJSONToModel(objAddress)
										address.Entity = models.BusinessPartner{}.TableName()
										address.CreatedBy = accountKey
										addresses = append(addresses, address)
									}
								}
							}
						}
					}
					partner.Addresses = addresses
					if len(arrAddressSkipID) > 0 {
						// delete id not in arrAddressSkipID
						db.Where("EntityID = ? AND Entity = ? AND AddressID not in (?)", partner.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrAddressSkipID).Find(&addressToDeleteModels)
					} else {
						// delete all
						db.Where("EntityID = ? AND Entity = ? ", partner.BusinessPartnerID, models.BusinessPartner{}.TableName()).Find(&addressToDeleteModels)
					}
					for _, ad := range addressToDeleteModels {
						arrAddressToDeleteID = append(arrAddressToDeleteID, ad.AddressID)
					}

					// @TODO validate for phone
					// set phone empty
					partner.Phones = make([]models.Phone, 0)
					var (
						objectsPhone        []map[string]interface{}
						phones              []models.Phone
						arrPhoneSkipID      []int
						arrPhoneToDeleteID  []int
						phoneToDeleteModels []models.Phone
					)
					phones = make([]models.Phone, 0)
					_, res = services.ConvertJSONValueToVariable("Phones", bp)
					if res != nil {
						phoneJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(phoneJSON, &objectsPhone)
							if len(objectsPhone) > 0 {
								for _, objPhone := range objectsPhone {
									var (
										phone models.Phone
									)
									phone.PassBodyJSONToModel(objPhone)
									resultFindPhone := db.Where("PhoneID = ?", phone.PhoneID).First(&phone)
									if resultFindPhone.RowsAffected > 0 {
										arrPhoneSkipID = append(arrPhoneSkipID, phone.PhoneID)
										phone.PassBodyJSONToModel(objPhone)
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(phone)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = itemMsgError + e.Translate(trans) + "\n"
											}
										} else {
											phone.Entity = models.BusinessPartner{}.TableName()
											phone.ModifiedBy = accountKey
											phones = append(phones, phone)
										}
									} else {
										phone.PassBodyJSONToModel(objPhone)
										phone.Entity = models.BusinessPartner{}.TableName()
										phone.CreatedBy = accountKey
										phones = append(phones, phone)
									}
								}
							}
						}
					}
					partner.Phones = phones
					if len(arrPhoneSkipID) > 0 {
						// delete id not in arrPhoneSkipID
						db.Where("EntityID = ? AND Entity = ? AND PhoneID not in (?)", partner.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrPhoneSkipID).Find(&phoneToDeleteModels)
					} else {
						// delete all
						db.Where("EntityID = ? AND Entity = ?", partner.BusinessPartnerID, models.BusinessPartner{}.TableName()).Find(&phoneToDeleteModels)
					}
					for _, pd := range phoneToDeleteModels {
						arrPhoneToDeleteID = append(arrPhoneToDeleteID, pd.PhoneID)
					}

					// @TODO validate for locations
					// set locations empty
					partner.Locations = make([]models.BusinessPartnerLocation, 0)
					var (
						objectsLocation        []int
						locations              []models.BusinessPartnerLocation
						arrLocationSkipID      []int
						arrLocationToDeleteID  []int
						locationToDeleteModels []models.BusinessPartnerLocation
						strLocations           []string
					)
					locations = make([]models.BusinessPartnerLocation, 0)
					_, res = services.ConvertJSONValueToVariable("LocationIDs", bp)
					if res != nil {
						locationJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(locationJSON, &objectsLocation)
							if len(objectsLocation) > 0 {
								for _, locationID := range objectsLocation {
									var (
										partnerLocation models.BusinessPartnerLocation
										location        models.Location
									)
									resultFindLocation := db.Where("BusinessPartnerID = ? AND LocationID = ?", partner.BusinessPartnerID, locationID).First(&partnerLocation)
									if resultFindLocation.RowsAffected > 0 {
										arrLocationSkipID = append(arrLocationSkipID, partnerLocation.BusinessPartnerLocationID)
										resultFindLocation := db.Where("LocationID = ?", locationID).First(&location)
										if resultFindLocation.RowsAffected > 0 {
											partnerLocation.LocationGroupID = location.LocationGroupID
										}
										partnerLocation.ModifiedBy = accountKey
										partnerLocation.IsDeleted = false
										partnerLocation.IsArchived = false
									} else {
										// @TODO can comment
										resultFindLocation := db.Where("LocationID = ?", locationID).First(&location)
										if resultFindLocation.RowsAffected > 0 {
											partnerLocation.LocationGroupID = location.LocationGroupID
										}
										partnerLocation.LocationID = locationID
										partnerLocation.CreatedBy = accountKey
									}
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(partnerLocation)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = itemMsgError + e.Translate(trans) + "\n"
										}
									} else {
										locations = append(locations, partnerLocation)
										strLocations = append(strLocations, strconv.Itoa(partnerLocation.LocationID))
									}
								}
							}
						}
					}
					partner.Locations = locations
					partner.LocationID = strings.Join(strLocations, ",")
					if len(arrLocationSkipID) > 0 {
						// delete id not in arrLocationSkipID
						db.Where("BusinessPartnerID = ? AND BusinessPartnerLocationID not in (?)", partner.BusinessPartnerID, arrLocationSkipID).Find(&locationToDeleteModels)
					} else {
						// delete all
						db.Where("BusinessPartnerID = ?", partner.BusinessPartnerID).Find(&locationToDeleteModels)
					}
					for _, ld := range locationToDeleteModels {
						arrLocationToDeleteID = append(arrLocationToDeleteID, ld.BusinessPartnerLocationID)
					}

					// @TODO need to required > 0 for address, phone

					// @TODO Update to xero
					var (
						createParnerSuccess = false
						xeroConfig          models.XeroConfig
					)
					resultFindXeroConfig := db.First(&xeroConfig)
					if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
						contacts := make([]models.BusinessPartner, 0)
						contacts = append(contacts, partner)
						resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
						if resultSave.Error == nil {
							xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, contacts)
							if len(xeroResponses) > 0 {
								contactResponse := xeroResponses[0]
								if contactResponse.Status == 200 {
									createParnerSuccess = true
									var xeroContactResponse models.BusinessPartner
									dataContact, errContact := json.Marshal(contactResponse.Data)
									if errContact == nil {
										json.Unmarshal(dataContact, &xeroContactResponse)
										partner = xeroContactResponse
									}
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", contactResponse.Msg))
									partner.IsIntegrationPending = true
									partner.IntegrationError = fmt.Sprintf("%v", contactResponse.Msg)
									resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
									if resultSave.Error == nil {
										createParnerSuccess = true
									} else {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
									}
								}
							} else {
								// add error message
							}
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						}
					} else {
						resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
						if resultSave.Error == nil {
							createParnerSuccess = true
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						}
					}
					// end
					if createParnerSuccess {
						// @TODO process for UDFs
						arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
						totalUpdatedRecord++
						dataResponse = append(dataResponse, partner)
						// @TODO update data for UDFs
						errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "BusinessPartnerID", partner.BusinessPartnerID)
						if len(errUDFs) > 0 {
							for _, e := range errUDFs {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
							}
						}
						// @TODO delete address/phone
						if len(arrAddressToDeleteID) > 0 {
							db.Where("AddressID in (?)", arrAddressToDeleteID).Delete(&models.Address{})
						}
						if len(arrPhoneToDeleteID) > 0 {
							db.Where("PhoneID in (?)", arrPhoneToDeleteID).Delete(&models.Phone{})
						}
						if len(arrLocationToDeleteID) > 0 {
							db.Where("BusinessPartnerLocationID in (?)", arrLocationToDeleteID).Delete(&models.BusinessPartnerLocation{})
						}
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		businessPartners []models.BusinessPartner
	)
	arrPartnersID := make([]int, 0)
	for _, v := range dataResponse {
		arrPartnersID = append(arrPartnersID, v.BusinessPartnerID)
	}
	if len(arrPartnersID) > 0 {
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Locations",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("BusinessPartnerID in (?)", arrPartnersID).Find(&businessPartners)
		dataResponses := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, businessPartners)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())
			udfParams := make([]string, 0)
			if b.IsVendor {
				udfParams = append(udfParams, "vendors")
			}
			if b.IsCustomer {
				udfParams = append(udfParams, "customers")
			}
			if b.IsContractor {
				udfParams = append(udfParams, "contractors")
			}
			if len(udfParams) > 0 {
				dbu = dbu.Where("UDFKey in (?)", udfParams)
			}
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteBusinessPartner godoc
// @Summary Delete Business Partner
// @Description Delete Business Partner
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Business Partner ID"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner/{id} [delete]
func DeleteBusinessPartner(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteBusinessPartner")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			partner models.BusinessPartner
		)
		resultFind := db.Where("BusinessPartnerID = ?", id).First(&partner)
		if resultFind.RowsAffected > 0 {
			statusDelete := partner.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				partner.IsDeleted = true
				partner.ModifiedBy = accountKey
				deletedResult := db.Save(&partner)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				// Skip or flag as archived archived customer in Xero. Archived Customer in JP should not be selectable
				if partner.ErpKey != "" {
					partner.IsArchived = true
					partner.ModifiedBy = accountKey
					deletedResult := db.Save(&partner)
					if deletedResult.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						totalUpdatedRecord++
					}
				} else {
					errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	//responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateBusinessPartner godoc
// @Summary Update Business Partner
// @Description Update Business Partner
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param BusinessPartner body []models.BusinessPartnerResponse true "Create Business Partner"
// @Success 200 {object} models.APIResponseData
// @Router /businesspartner/changelocation [put]
func ChangeLocation(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateBusinessPartner")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.BusinessPartner
		totalUpdatedRecord = 0
		//xeroConfig         models.XeroConfig
		//xeroIntegration    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	// Get Xero Config
	/*resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
		xeroIntegration = true
	}*/

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.BusinessPartner, 0)
	/*isQuickCustomer := false
	vQuickCustomer, sQuickCustomer := libs.GetQueryParam("isquickcustomer", c)
	if sQuickCustomer {
		bQuickCustomer, eQuickCustomer := strconv.ParseBool(vQuickCustomer)
		if eQuickCustomer == nil {
			isQuickCustomer = bQuickCustomer
		}
	}*/
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				partner models.BusinessPartner
			)
			partner.PassBodyJSONToModel(bp)
			resultFind := db.Where("BusinessPartnerID = ?", partner.BusinessPartnerID).First(&partner)
			if resultFind.RowsAffected > 0 {
				partner.PassBodyJSONToModel(bp)
				partner.ModifiedBy = accountKey
				// @TODO Check duplicated BusinessPartnerCode
				if partner.BusinessPartnerCode != "" {
					var checkPartnerModel models.BusinessPartner
					resultFindCheckPartner := db.Where("BusinessPartnerCode = ? AND BusinessPartnerID <> ?", partner.BusinessPartnerCode, partner.BusinessPartnerID).First(&checkPartnerModel)
					if resultFindCheckPartner.RowsAffected > 0 {
						errResponse := GetErrorResponseValidate(lang, k, "api.partner_code_exist")
						errorsResponse = append(errorsResponse, errResponse)
						break
					}
				}

				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(partner)
				errBusinessName := ""
				if partner.IsPrivate {
					errBusinessName = partner.FirstName + " " + partner.LastName
				} else {
					errBusinessName = partner.CompanyName
				}
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = errBusinessName + " - " + e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
						res          interface{}
					)
					// @TODO validate for address
					// set address empty
					partner.Addresses = make([]models.Address, 0)
					var (
						objectsAddress        []map[string]interface{}
						addresses             []models.Address
						arrAddressSkipID      []int
						arrAddressToDeleteID  []int
						addressToDeleteModels []models.Address
					)
					addresses = make([]models.Address, 0)
					_, res = services.ConvertJSONValueToVariable("Addresses", bp)
					if res != nil {
						addressJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(addressJSON, &objectsAddress)
							if len(objectsAddress) > 0 {
								for _, objAddress := range objectsAddress {
									var (
										address models.Address
									)
									address.PassBodyJSONToModel(objAddress)
									resultFindAddress := db.Where("AddressID = ?", address.AddressID).First(&address)
									if resultFindAddress.RowsAffected > 0 {
										arrAddressSkipID = append(arrAddressSkipID, address.AddressID)
										address.PassBodyJSONToModel(objAddress)
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(address)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = itemMsgError + e.Translate(trans) + "\n"
											}
										} else {
											address.Entity = models.BusinessPartner{}.TableName()
											address.ModifiedBy = accountKey
											addresses = append(addresses, address)
										}
									} else {
										address.PassBodyJSONToModel(objAddress)
										address.Entity = models.BusinessPartner{}.TableName()
										address.CreatedBy = accountKey
										addresses = append(addresses, address)
									}
								}
							}
						}
					}
					partner.Addresses = addresses
					if len(arrAddressSkipID) > 0 {
						// delete id not in arrAddressSkipID
						db.Where("EntityID = ? AND Entity = ? AND AddressID not in (?)", partner.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrAddressSkipID).Find(&addressToDeleteModels)
					} else {
						// delete all
						db.Where("EntityID = ? AND Entity = ? ", partner.BusinessPartnerID, models.BusinessPartner{}.TableName()).Find(&addressToDeleteModels)
					}
					for _, ad := range addressToDeleteModels {
						arrAddressToDeleteID = append(arrAddressToDeleteID, ad.AddressID)
					}

					// @TODO validate for phone
					// set phone empty
					partner.Phones = make([]models.Phone, 0)
					var (
						objectsPhone        []map[string]interface{}
						phones              []models.Phone
						arrPhoneSkipID      []int
						arrPhoneToDeleteID  []int
						phoneToDeleteModels []models.Phone
					)
					phones = make([]models.Phone, 0)
					_, res = services.ConvertJSONValueToVariable("Phones", bp)
					if res != nil {
						phoneJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(phoneJSON, &objectsPhone)
							if len(objectsPhone) > 0 {
								for _, objPhone := range objectsPhone {
									var (
										phone models.Phone
									)
									phone.PassBodyJSONToModel(objPhone)
									resultFindPhone := db.Where("PhoneID = ?", phone.PhoneID).First(&phone)
									if resultFindPhone.RowsAffected > 0 {
										arrPhoneSkipID = append(arrPhoneSkipID, phone.PhoneID)
										phone.PassBodyJSONToModel(objPhone)
										validate, trans := services.GetValidatorTranslate()
										err := validate.Struct(phone)
										if err != nil {
											errs := err.(validator.ValidationErrors)
											for _, e := range errs {
												itemMsgError = itemMsgError + e.Translate(trans) + "\n"
											}
										} else {
											phone.Entity = models.BusinessPartner{}.TableName()
											phone.ModifiedBy = accountKey
											phones = append(phones, phone)
										}
									} else {
										phone.PassBodyJSONToModel(objPhone)
										phone.Entity = models.BusinessPartner{}.TableName()
										phone.CreatedBy = accountKey
										phones = append(phones, phone)
									}
								}
							}
						}
					}
					partner.Phones = phones
					if len(arrPhoneSkipID) > 0 {
						// delete id not in arrPhoneSkipID
						db.Where("EntityID = ? AND Entity = ? AND PhoneID not in (?)", partner.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrPhoneSkipID).Find(&phoneToDeleteModels)
					} else {
						// delete all
						db.Where("EntityID = ? AND Entity = ?", partner.BusinessPartnerID, models.BusinessPartner{}.TableName()).Find(&phoneToDeleteModels)
					}
					for _, pd := range phoneToDeleteModels {
						arrPhoneToDeleteID = append(arrPhoneToDeleteID, pd.PhoneID)
					}

					// @TODO validate for locations
					// set locations empty
					partner.Locations = make([]models.BusinessPartnerLocation, 0)
					var (
						objectsLocation        []int
						locations              []models.BusinessPartnerLocation
						arrLocationSkipID      []int
						arrLocationToDeleteID  []int
						locationToDeleteModels []models.BusinessPartnerLocation
						strLocations           []string
					)
					locations = make([]models.BusinessPartnerLocation, 0)
					_, res = services.ConvertJSONValueToVariable("LocationIDs", bp)
					if res != nil {
						locationJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(locationJSON, &objectsLocation)
							if len(objectsLocation) > 0 {
								for _, locationID := range objectsLocation {
									var (
										partnerLocation models.BusinessPartnerLocation
										location        models.Location
									)
									resultFindLocation := db.Where("BusinessPartnerID = ? AND LocationID = ?", partner.BusinessPartnerID, locationID).First(&partnerLocation)
									if resultFindLocation.RowsAffected > 0 {
										arrLocationSkipID = append(arrLocationSkipID, partnerLocation.BusinessPartnerLocationID)
										resultFindLocation := db.Where("LocationID = ?", locationID).First(&location)
										if resultFindLocation.RowsAffected > 0 {
											partnerLocation.LocationGroupID = location.LocationGroupID
										}
										partnerLocation.ModifiedBy = accountKey
										partnerLocation.IsDeleted = false
										partnerLocation.IsArchived = false
									} else {
										// @TODO can comment
										resultFindLocation := db.Where("LocationID = ?", locationID).First(&location)
										if resultFindLocation.RowsAffected > 0 {
											partnerLocation.LocationGroupID = location.LocationGroupID
										}
										partnerLocation.LocationID = locationID
										partnerLocation.CreatedBy = accountKey
									}
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(partnerLocation)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = itemMsgError + e.Translate(trans) + "\n"
										}
									} else {
										locations = append(locations, partnerLocation)
										strLocations = append(strLocations, strconv.Itoa(partnerLocation.LocationID))
									}
								}
							}
						}
					}
					partner.Locations = locations
					partner.LocationID = strings.Join(strLocations, ",")
					if len(arrLocationSkipID) > 0 {
						// delete id not in arrLocationSkipID
						db.Where("BusinessPartnerID = ? AND BusinessPartnerLocationID not in (?)", partner.BusinessPartnerID, arrLocationSkipID).Find(&locationToDeleteModels)
					} else {
						// delete all
						db.Where("BusinessPartnerID = ?", partner.BusinessPartnerID).Find(&locationToDeleteModels)
					}
					for _, ld := range locationToDeleteModels {
						arrLocationToDeleteID = append(arrLocationToDeleteID, ld.BusinessPartnerLocationID)
					}

					// @TODO need to required > 0 for address, phone

					// @TODO Update to xero
					var (
						createParnerSuccess = false
						xeroConfig          models.XeroConfig
					)
					resultFindXeroConfig := db.First(&xeroConfig)
					if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
						contacts := make([]models.BusinessPartner, 0)
						contacts = append(contacts, partner)
						resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
						if resultSave.Error == nil {
							xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, contacts)
							if len(xeroResponses) > 0 {
								contactResponse := xeroResponses[0]
								if contactResponse.Status == 200 {
									createParnerSuccess = true
									var xeroContactResponse models.BusinessPartner
									dataContact, errContact := json.Marshal(contactResponse.Data)
									if errContact == nil {
										json.Unmarshal(dataContact, &xeroContactResponse)
										partner = xeroContactResponse
									}
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", contactResponse.Msg))
									partner.IsIntegrationPending = true
									partner.IntegrationError = fmt.Sprintf("%v", contactResponse.Msg)
									resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
									if resultSave.Error == nil {
										createParnerSuccess = true
									} else {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
									}
								}
							} else {
								// add error message
							}
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						}
					} else {
						resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&partner)
						if resultSave.Error == nil {
							createParnerSuccess = true
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						}
					}
					// end
					if createParnerSuccess {
						// @TODO process for UDFs
						arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
						totalUpdatedRecord++
						dataResponse = append(dataResponse, partner)
						// @TODO update data for UDFs
						errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "BusinessPartnerID", partner.BusinessPartnerID)
						if len(errUDFs) > 0 {
							for _, e := range errUDFs {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
							}
						}
						// @TODO delete address/phone
						if len(arrAddressToDeleteID) > 0 {
							db.Where("AddressID in (?)", arrAddressToDeleteID).Delete(&models.Address{})
						}
						if len(arrPhoneToDeleteID) > 0 {
							db.Where("PhoneID in (?)", arrPhoneToDeleteID).Delete(&models.Phone{})
						}
						if len(arrLocationToDeleteID) > 0 {
							db.Where("BusinessPartnerLocationID in (?)", arrLocationToDeleteID).Delete(&models.BusinessPartnerLocation{})
						}
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		businessPartners []models.BusinessPartner
	)
	arrPartnersID := make([]int, 0)
	for _, v := range dataResponse {
		arrPartnersID = append(arrPartnersID, v.BusinessPartnerID)
	}
	if len(arrPartnersID) > 0 {
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Locations",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("BusinessPartnerID in (?)", arrPartnersID).Find(&businessPartners)
		dataResponses := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, businessPartners)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())
			udfParams := make([]string, 0)
			if b.IsVendor {
				udfParams = append(udfParams, "vendors")
			}
			if b.IsCustomer {
				udfParams = append(udfParams, "customers")
			}
			if b.IsContractor {
				udfParams = append(udfParams, "contractors")
			}
			if len(udfParams) > 0 {
				dbu = dbu.Where("UDFKey in (?)", udfParams)
			}
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayBusinessPartnerToArrayResponse func
func ConvertArrayBusinessPartnerToArrayResponse(requestHeader models.RequestHeader, businessPartners []models.BusinessPartner) []models.BusinessPartnerResponse {
	businessPartnerResponses := make([]models.BusinessPartnerResponse, 0)
	for _, partner := range businessPartners {
		response := ConvertBusinessPartnerToResponse(requestHeader, partner)
		businessPartnerResponses = append(businessPartnerResponses, response)
	}
	return businessPartnerResponses
}

// ConvertBusinessPartnerToResponse func
func ConvertBusinessPartnerToResponse(requestHeader models.RequestHeader, businessPartner models.BusinessPartner) models.BusinessPartnerResponse {
	var (
		businessPartnerResponse models.BusinessPartnerResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	businessPartnerResponse.BusinessPartnerID = businessPartner.BusinessPartnerID
	businessPartnerResponse.BusinessPartnerCode = businessPartner.BusinessPartnerCode
	businessPartnerResponse.ErpKey = businessPartner.ErpKey
	businessPartnerResponse.CompanyName = businessPartner.CompanyName
	businessPartnerResponse.FirstName = businessPartner.FirstName
	businessPartnerResponse.LastName = businessPartner.LastName
	businessPartnerResponse.EmailAddress = businessPartner.EmailAddress
	businessPartnerResponse.IsVendor = businessPartner.IsVendor
	businessPartnerResponse.IsCustomer = businessPartner.IsCustomer
	businessPartnerResponse.IsContractor = businessPartner.IsContractor
	businessPartnerResponse.IsPrivate = businessPartner.IsPrivate
	businessPartnerResponse.TaxNumber = businessPartner.TaxNumber
	businessPartnerResponse.DefaultCurrency = businessPartner.DefaultCurrency
	businessPartnerResponse.PriceListID = businessPartner.PriceListID

	if businessPartner.PriceListID != nil && *businessPartner.PriceListID > 0 {
		var (
			priceList models.PriceList
		)
		resultFind := db.Where("PriceListID = ?", businessPartner.PriceListID).First(&priceList)
		if resultFind.RowsAffected > 0 {
			businessPartnerResponse.PriceListName = priceList.PriceListName
		}
	} else {
		/*var (
			priceList          models.PriceList
			customerGroupModel models.CustomerGroup
		)
		resultFindCustomerGroup := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND CustomerGroupID = ?", businessPartner.CustomerGroupID).
			First(&customerGroupModel)
		if resultFindCustomerGroup.RowsAffected > 0 {
			if customerGroupModel.PriceListID != nil && *customerGroupModel.PriceListID > 0 {
				resultFind := db.Where("PriceListID = ?", customerGroupModel.PriceListID).First(&priceList)
				if resultFind.RowsAffected > 0 {
					businessPartnerResponse.PriceListName = priceList.PriceListName
				}
			}
		}*/
	}

	businessPartnerResponse.DefaultDiscountPercent = businessPartner.DefaultDiscountPercent
	businessPartnerResponse.IsDeleted = businessPartner.IsDeleted
	businessPartnerResponse.IsAudit = businessPartner.IsAudit
	businessPartnerResponse.IsArchived = businessPartner.IsArchived
	addresses := make([]models.AddressResponse, 0)
	for _, ad := range businessPartner.Addresses {
		var (
			address     models.AddressResponse
			addressType models.AddressType
		)
		address.AddressID = ad.AddressID
		address.AddressTypeID = ad.AddressTypeID
		db.Where("AddressTypeID = ?", ad.AddressTypeID).First(&addressType)
		address.AddressTypeName = addressType.AddressTypeName
		address.AddressLine1 = ad.AddressLine1
		address.AddressLine2 = ad.AddressLine2
		address.AddressLine3 = ad.AddressLine3
		address.AddressLine4 = ad.AddressLine4
		address.City = ad.City
		address.PostalCode = ad.PostalCode
		address.State = ad.State
		address.Country = ad.Country
		address.AttentionTo = ad.AttentionTo
		address.IsDeleted = ad.IsDeleted
		address.IsArchived = ad.IsArchived
		address.EntityID = ad.EntityID
		address.Entity = ad.Entity
		address.IsDefaultBilling = ad.IsBilling
		address.IsDefaultDepot = ad.IsDepot
		address.NavigationAddress = ad.NavigationAddress
		addresses = append(addresses, address)
	}
	businessPartnerResponse.Addresses = addresses
	phones := make([]models.PhoneResponse, 0)
	for _, ph := range businessPartner.Phones {
		var (
			phone     models.PhoneResponse
			phoneType models.PhoneType
		)
		phone.PhoneID = ph.PhoneID
		phone.PhoneTypeID = ph.PhoneTypeID
		db.Where("PhoneTypeID = ?", ph.PhoneTypeID).First(&phoneType)
		phone.PhoneTypeName = phoneType.PhoneTypeName
		phone.CountryCode = ph.CountryCode
		phone.PhoneNumber = ph.PhoneNumber
		phone.Extension = ph.Extension
		phone.EntityID = ph.EntityID
		phone.Entity = ph.Entity
		phone.IsDeleted = ph.IsDeleted
		phone.IsArchived = ph.IsArchived
		phone.IsDefaultContact = ph.IsDefault
		phones = append(phones, phone)
	}
	businessPartnerResponse.Phones = phones
	locations := make([]models.BusinessPartnerLocationResponse, 0)
	locationIDs := make([]int, 0)
	for _, lo := range businessPartner.Locations {
		var (
			location      models.BusinessPartnerLocationResponse
			locationGroup models.LocationGroup
			locationName  models.Location
		)
		location.BusinessPartnerLocationID = lo.BusinessPartnerLocationID
		location.IsAudit = lo.IsAudit
		location.IsDeleted = lo.IsDeleted
		location.BusinessPartnerID = lo.BusinessPartnerID
		location.LocationGroupID = lo.LocationGroupID
		db.Where("LocationGroupID = ?", lo.LocationGroupID).First(&locationGroup)
		location.LocationGroupName = locationGroup.LocationGroupName
		location.LocationID = lo.LocationID
		db.Where("LocationID = ?", lo.LocationID).First(&locationName)
		location.LocationName = locationName.LocationName
		locations = append(locations, location)
		locationIDs = append(locationIDs, lo.LocationID)
	}
	//businessPartnerResponse.Locations = locations
	businessPartnerResponse.LocationIDs = locationIDs
	businessPartnerResponse.Note = businessPartner.Note
	if businessPartner.CustomerGroupID > 0 {
		businessPartnerResponse.CustomerGroupID = &businessPartner.CustomerGroupID
	}
	if businessPartner.CustomerGroups != nil {
		businessPartnerResponse.CustomerGroupName = businessPartner.CustomerGroups.CustomerGroupName
	}

	return businessPartnerResponse
}

// IncreaseDocumentSequencesAfterCreatePartner func
func IncreaseDocumentSequencesAfterCreatePartner(requestHeader models.RequestHeader) {
	var (
		resModel models.DocumentSequency
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFind := db.First(&resModel)
	resModel.CustomerCode = resModel.CustomerCode + 1
	resModel.VendorCode = resModel.VendorCode + 1
	resModel.ContractorCode = resModel.ContractorCode + 1
	if resultFind.RowsAffected > 0 {
		db.Save(&resModel)
	} else {
		db.Create(&resModel)
	}
}
