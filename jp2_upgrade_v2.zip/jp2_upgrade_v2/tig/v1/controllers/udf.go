package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetUDF godoc
// @Summary Get UDF
// @Description Get UDF
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /udf [get]
func GetUDF(c *gin.Context) {
	defer libs.RecoverError(c, "GetUDF")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.UDF
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter
	vTableName, sTableName := libs.GetQueryParam("TableName", c)
	if sTableName {
		bp = bp.Where("TableName LIKE ?", "%"+vTableName+"%")
	}
	vDataField, sDataField := libs.GetQueryParam("DataField", c)
	if sDataField {
		bp = bp.Where("DataField LIKE ?", "%"+vDataField+"%")
	}
	vLabel, sLabel := libs.GetQueryParam("Label", c)
	if sLabel {
		bp = bp.Where("Label LIKE ?", "%"+vLabel+"%")
	}
	vDataType, sDataType := libs.GetQueryParam("DataType", c)
	if sDataType {
		bp = bp.Where("DataType LIKE ?", "%"+vDataType+"%")
	}
	vIsRequired, sIsRequired := libs.GetQueryParam("IsRequired", c)
	if sIsRequired {
		bIsRequired, eIsRequired := strconv.ParseBool(vIsRequired)
		if eIsRequired == nil {
			bp = bp.Where("IsRequired = ?", bIsRequired)
		}
	}
	vInSearch, sInSearch := libs.GetQueryParam("InSearch", c)
	if sInSearch {
		bInSearch, eInSearch := strconv.ParseBool(vInSearch)
		if eInSearch == nil {
			bp = bp.Where("InSearch = ?", bInSearch)
		}
	}
	vInList, sInList := libs.GetQueryParam("InList", c)
	if sInList {
		bInList, eInList := strconv.ParseBool(vInList)
		if eInList == nil {
			bp = bp.Where("InList = ?", bInList)
		}
	}
	vUDFKey, sUDFKey := libs.GetQueryParam("UDFKey", c)
	if sUDFKey {
		bp = bp.Where("UDFKey = ?", vUDFKey)
	}
	// Sort
	bp = bp.Order("Sort ASC")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayUDFToArrayResponse(resModels, lang, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUDFByID godoc
// @Summary Get UDF By ID
// @Description Get UDF By ID
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param id path int true "UDF ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /udf/{id} [get]
func GetUDFByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetUDFByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.UDF
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	db = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND UDFID = ?", ID)
	resultRow := db.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemResponse := ConvertUDFToResponse(resModel, lang, requestHeader)
		itemResponse.DataField = strings.Replace(itemResponse.DataField, "U_", "", -1)
		data = itemResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateUDF godoc
// @Summary Create UDF
// @Description Create UDF
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param UDF body []models.UDFResponse true "Create UDF"
// @Success 200 {object} models.APIResponseData
// @Router /udf [post]
func CreateUDF(c *gin.Context) {
	apiName := "CreateUDF"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.UDF
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//
	if db != nil {

	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	dataResponse = make([]models.UDF, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				bodyJSONModel models.UDF
			)

			bodyJSONModel.PassBodyJSONToModel(bp)
			bodyJSONModel.DataField = services.StripSpaces(strings.Title(bodyJSONModel.DataField))

			// @TODO search udf with TableName,DataField
			resultFindUDF := db.Where("TableName = ? AND DataField = ?", bodyJSONModel.TableNameObj, bodyJSONModel.DataField).First(&models.UDF{})
			if resultFindUDF.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.udf_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				bodyJSONModel.CreatedBy = accountKey
				bodyJSONModel.ModifiedBy = accountKey

				if bodyJSONModel.IsRequired {
					bodyJSONModel.Visible = true
				}
				// @TODO validate for partner
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(bodyJSONModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						errInsertRow string
					)
					var maxSort int
					row := db.Table(models.UDF{}.TableName()).Select("max(Sort)").Row()
					row.Scan(&maxSort)
					maxSort = maxSort + 1
					bodyJSONModel.Sort = maxSort
					resultCreate := db.Create(&bodyJSONModel)
					if resultCreate.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, resultCreate.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						// @TODO insert this field to tablename
						sqlAlter := models.GetSQLAlterNewField(bodyJSONModel)
						errAlter := db.Exec(sqlAlter).Error
						if errAlter != nil {
							errInsertRow = libs.GetStringWithWordBetween(errInsertRow, errAlter.Error())
							// @TODO delete row to udf
							sqlDeleteUDF := `DELETE FROM ` + models.UDF{}.TableName() + ` WHERE TableName = ? AND DataField = ? AND UDFKey = ?`
							db.Exec(sqlDeleteUDF, bodyJSONModel.TableNameObj, bodyJSONModel.DataField, bodyJSONModel.UDFKey)
						} else {
							if bodyJSONModel.InSearch {
								// @TODO add row to searchfield table
								errInsertRowRes := CreateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey, true, true)
								errInsertRow = libs.GetStringWithWordBetween(errInsertRow, errInsertRowRes)
								// @TODO add row to searchfieldtemplate table
								errInsertRowTemplateRes := CreateSearchFieldTemplateFunc(requestHeader, bodyJSONModel, true, true)
								errInsertRow = libs.GetStringWithWordBetween(errInsertRow, errInsertRowTemplateRes)
							}
							if bodyJSONModel.InList {
								// @TODO add row to grids table
								errInsertGridRes := CreateGridFunc(requestHeader, bodyJSONModel, accountKey)
								errInsertRow = libs.GetStringWithWordBetween(errInsertRow, errInsertGridRes)
								// @TODO add row to gridstemplate table
								errInsertGridTemplateRes := CreateGridTemplateFunc(requestHeader, bodyJSONModel)
								errInsertRow = libs.GetStringWithWordBetween(errInsertRow, errInsertGridTemplateRes)
							}
							if errInsertRow != "" {
								// @TODO delete row to searchfield table
								DeleteSearchFieldFunc(requestHeader, bodyJSONModel, accountKey)
								// @TODO delete row to searchfieldtemplate table
								DeleteSearchFieldTemplateFunc(requestHeader, bodyJSONModel)
								// @TODO delete row to grids table
								DeleteGridFunc(requestHeader, bodyJSONModel, accountKey)
								// @TODO delete row to gridstemplate table
								DeleteGridTemplateFunc(requestHeader, bodyJSONModel)
								// @TODO delete this field to tablename
								ssqlDeleteTableName := `ALTER TABLE ` + bodyJSONModel.TableNameObj + ` DROP ` + bodyJSONModel.DataField + `;`
								db.Exec(ssqlDeleteTableName)
								// @TODO delete row to udf
								sqlDeleteUDF := `DELETE FROM ` + models.UDF{}.TableName() + ` WHERE TableName = ? AND DataField = ? AND UDFKey = ?`
								db.Exec(sqlDeleteUDF, bodyJSONModel.TableNameObj, bodyJSONModel.DataField, bodyJSONModel.UDFKey)
							}
						}
						if errInsertRow != "" {
							errResponse := GetErrorResponseErrorMessage(k, errInsertRow)
							errorsResponse = append(errorsResponse, errResponse)
						} else {
							// @TODO add or update translation table
							ProcessTranslationForObject(requestHeader, models.UDF{}.TableName(), bodyJSONModel.UDFID, accountKey, bp)
							totalUpdatedRecord++
							dataResponse = append(dataResponse, bodyJSONModel)
						}
					}
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.UDF
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.UDFID)
	}
	if len(arrID) > 0 {
		db = db.Where("UDFID in (?)", arrID).Find(&resModels)
		//data = resModels
		data = ConvertArrayUDFToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateUDF godoc
// @Summary Update UDF
// @Description Update UDF
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param UDF body []models.UDFResponse true "Update UDF"
// @Success 200 {object} models.APIResponseData
// @Router /udf [put]
func UpdateUDF(c *gin.Context) {
	apiName := "UpdateUDF"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.UDF
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	dataResponse = make([]models.UDF, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	key := c.Param("key")
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)

	if len(objectsJSON) > 0 {
		var (
			bodyJSONModelCheck models.UDF
		)
		bodyJSONModelCheck.PassBodyJSONToModelForUpdate(objectsJSON[0])
		db.Where("TableName = ? AND UDFKey = ?", key, bodyJSONModelCheck.UDFKey).Model(&models.UDF{}).Updates(map[string]interface{}{"Visible": false})
		for k, bp := range objectsJSON {
			var (
				bodyJSONModel models.UDF
			)
			bodyJSONModel.PassBodyJSONToModelForUpdate(bp)
			resultFind := db.Where("UDFID = ?", bodyJSONModel.UDFID).First(&bodyJSONModel)
			if resultFind.RowsAffected > 0 {
				bodyJSONModel.PassBodyJSONToModelForUpdate(bp)
				bodyJSONModel.ModifiedBy = accountKey
				bodyJSONModel.DataField = services.ApplyFormatForDataField(bodyJSONModel.DataField)
				// @TODO validate for partner
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(bodyJSONModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						errDeleteRow string
					)
					resultSave := db.Save(&bodyJSONModel)
					if resultSave.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, resultSave.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, bodyJSONModel)
						ProcessTranslationForObject(requestHeader, models.UDF{}.TableName(), bodyJSONModel.UDFID, accountKey, bp)
						// @TODO check to remove row in searchfield table
						if !bodyJSONModel.InSearch {
							// @TODO delete searchfields
							DeleteSearchFieldFunc(requestHeader, bodyJSONModel, accountKey)
							// @TODO delete searchfieldstemplate
							DeleteSearchFieldTemplateFunc(requestHeader, bodyJSONModel)
						} else {
							// @TODO add/update searchfields
							errInsertSearchFieldRes := CreateOrUpdateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertSearchFieldRes)
							// @TODO add/update searchfieldstemplate
							errInsertSearchFieldTemplateRes := CreateOrUpdateSearchFieldTemplateFunc(requestHeader, bodyJSONModel)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertSearchFieldTemplateRes)
						}
						if !bodyJSONModel.InList {
							// @TODO delete grid
							DeleteGridFunc(requestHeader, bodyJSONModel, accountKey)
							// @TODO delete gridtemplate
							DeleteGridTemplateFunc(requestHeader, bodyJSONModel)
						} else {
							// @TODO add/update grid
							errInsertGridRes := CreateOrUpdateGridFunc(requestHeader, bodyJSONModel, accountKey)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertGridRes)
							// @TODO add/update gridtemplate
							errInsertGridTemplateRes := CreateOrUpdateGridTemplateFunc(requestHeader, bodyJSONModel)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertGridTemplateRes)
						}
						if errDeleteRow != "" {
							errResponse := GetErrorResponseErrorMessage(k, errDeleteRow)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.UDF
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.UDFID)
	}
	if len(arrID) > 0 {
		db = db.Where("UDFID in (?)", arrID).Find(&resModels)
		//data = resModels
		data = ConvertArrayUDFToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateUDFV2 godoc
// @Summary Update UDF
// @Description Update UDF
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param UDF body []models.UDFResponse true "Update UDF"
// @Success 200 {object} models.APIResponseData
// @Router /udf [put]
func UpdateUDFV2(c *gin.Context) {
	apiName := "UpdateUDFV2"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.UDF
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	dataResponse = make([]models.UDF, 0)
	errorsResponse = make([]models.ErrorResponse, 0)

	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				bodyJSONModel models.UDF
			)
			bodyJSONModel.PassBodyJSONToModelForUpdate(bp)
			resultFind := db.Where("UDFID = ?", bodyJSONModel.UDFID).First(&bodyJSONModel)
			if resultFind.RowsAffected > 0 {
				bodyJSONModel.PassBodyJSONToModelForUpdate(bp)
				bodyJSONModel.ModifiedBy = accountKey
				bodyJSONModel.DataField = services.ApplyFormatForDataField(bodyJSONModel.DataField)
				// @TODO validate for partner
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(bodyJSONModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						errDeleteRow string
					)
					resultSave := db.Save(&bodyJSONModel)
					if resultSave.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, resultSave.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, bodyJSONModel)
						ProcessTranslationForObject(requestHeader, models.UDF{}.TableName(), bodyJSONModel.UDFID, accountKey, bp)
						// @TODO check to remove row in searchfield table
						if !bodyJSONModel.InSearch {
							// @TODO delete searchfields
							DeleteSearchFieldFunc(requestHeader, bodyJSONModel, accountKey)
							// @TODO delete searchfieldstemplate
							DeleteSearchFieldTemplateFunc(requestHeader, bodyJSONModel)
						} else {
							// @TODO add/update searchfields
							errInsertSearchFieldRes := CreateOrUpdateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertSearchFieldRes)
							// @TODO add/update searchfieldstemplate
							errInsertSearchFieldTemplateRes := CreateOrUpdateSearchFieldTemplateFunc(requestHeader, bodyJSONModel)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertSearchFieldTemplateRes)
						}
						if !bodyJSONModel.InList {
							// @TODO delete grid
							DeleteGridFunc(requestHeader, bodyJSONModel, accountKey)
							// @TODO delete gridtemplate
							DeleteGridTemplateFunc(requestHeader, bodyJSONModel)
						} else {
							// @TODO add/update grids
							errInsertGridRes := CreateOrUpdateGridFunc(requestHeader, bodyJSONModel, accountKey)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertGridRes)
							// @TODO add/update gridstemplate
							errInsertGridTemplateRes := CreateOrUpdateGridTemplateFunc(requestHeader, bodyJSONModel)
							errDeleteRow = libs.GetStringWithWordBetween(errDeleteRow, errInsertGridTemplateRes)
						}
						if errDeleteRow != "" {
							errResponse := GetErrorResponseErrorMessage(k, errDeleteRow)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.UDF
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.UDFID)
	}
	if len(arrID) > 0 {
		db = db.Where("UDFID in (?)", arrID).Find(&resModels)
		//data = resModels
		data = ConvertArrayUDFToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteUDF godoc
// @Summary Delete UDF
// @Description Delete UDF
// @Tags UDF
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Business Partner ID"
// @Success 200 {object} models.APIResponseData
// @Router /udf/{id} [delete]
func DeleteUDF(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteUDF")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	errorsResponse = make([]models.ErrorResponse, 0)

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db2 := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)

	confirmedParam := false
	vConfirmed, sConfirmed := libs.GetQueryParam("confirmed", c)
	if sConfirmed {
		bConfirmed, eConfirmed := strconv.ParseBool(vConfirmed)
		if eConfirmed == nil {
			confirmedParam = bConfirmed
		}
	}

	for k, id := range arrID {
		var (
			resModel models.UDF
		)
		resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND UDFID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			readyDelete := false
			if confirmedParam {
				readyDelete = true
			} else {
				// @TODO check from table with tablename , check all row if only row has data => false
				sqlSelect := `SELECT ` + resModel.DataField + ` FROM ` + resModel.TableNameObj
				rowsSelect, errSelect := db2.Raw(sqlSelect).Rows()
				if errSelect == nil {
					defer rowsSelect.Close()
					hasValue := false
					for rowsSelect.Next() {
						var (
							val string
						)
						rowsSelect.Scan(&val)
						if val != "" {
							hasValue = true
							break
						}
					}
					if !hasValue {
						readyDelete = true
					}
				} else {
					// not found field
					readyDelete = true
				}
			}
			if readyDelete {
				deletedResult := db.Delete(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					//@TODO delete translation table
					DeleteTranslationOnObject(requestHeader, models.UDF{}.TableName(), resModel.UDFID)
					totalUpdatedRecord++

					// @TODO delete datafield in tableNameObj
					sqlDeleteField := `ALTER TABLE ` + resModel.TableNameObj + ` DROP COLUMN ` + resModel.DataField + `;`
					db.Exec(sqlDeleteField)
					// @TODO delete row in searchfield
					DeleteSearchFieldFunc(requestHeader, resModel, accountKey)
					// @TODO delete row in searchfieldtemplate
					DeleteSearchFieldTemplateFunc(requestHeader, resModel)
					// @TODO delete row in grid
					DeleteGridFunc(requestHeader, resModel, accountKey)
					// @TODO delete row in gridtemplate
					DeleteGridTemplateFunc(requestHeader, resModel)
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, services.GetMessage(lang, "api.confirm_delete_udf", resModel.Label))
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	if totalUpdatedRecord == 0 {
		status = 207
		msg = services.GetMessage(lang, "api.full_failed")
	} else {
		status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	libs.APIResponseData(response, c, status)
}

// ConvertArrayUDFToArrayResponse func
func ConvertArrayUDFToArrayResponse(items []models.UDF, lang string, requestHeader models.RequestHeader) []models.UDFResponse {
	responses := make([]models.UDFResponse, 0)
	for _, item := range items {
		response := ConvertUDFToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertUDFToResponse func
func ConvertUDFToResponse(item models.UDF, lang string, requestHeader models.RequestHeader) models.UDFResponse {
	var (
		response             models.UDFResponse
		translationResponses []models.TranslationResponse
	)
	response.UDFID = item.UDFID
	response.TableNameObj = item.TableNameObj
	response.DataField = item.DataField
	response.Label = item.Label
	response.DataType = item.DataType
	response.DefaultValue = item.DefaultValue
	response.MaxLength = item.MaxLength
	response.IsRequired = item.IsRequired
	response.Widget = item.Widget
	response.Visible = item.Visible
	response.Sort = item.Sort
	response.InSearch = item.InSearch
	response.InList = item.InList
	response.Options = item.Options
	response.UDFKey = item.UDFKey
	response.NumberPrecision = item.NumberPrecision
	translationResponses = make([]models.TranslationResponse, 0)
	translationResponses = GetTranslationResponse(requestHeader, models.UDF{}.TableName(), item.UDFID)
	response.Translations = translationResponses
	response.DateType = item.DateType
	response.Alignment = item.Alignment
	response.AllowGrouping = item.AllowGrouping
	return response
}

// CreateSearchFieldFunc func
func CreateSearchFieldFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int, hasFrom bool, hasTo bool) string {
	var (
		errInsertRow string
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// From
		var (
			newSearchField models.SearchField
		)
		newSearchField.SearchFieldKey = bodyJSONModel.UDFKey
		newSearchField.Parameter = dataFieldFrom
		newSearchField.TableNameObj = strings.ToLower(bodyJSONModel.TableNameObj)
		newSearchField.Label = bodyJSONModel.Label + " From"
		newSearchField.MaxLength = bodyJSONModel.MaxLength
		newSearchField.Widget = bodyJSONModel.Widget
		//newSearchField.Visible = bodyJSONModel.Visible
		newSearchField.Visible = false
		newSearchField.Sort = bodyJSONModel.Sort
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + dataFieldFrom
		newSearchField.AccountKey = accountKey
		newSearchField.Options = bodyJSONModel.Options
		newSearchField.IsEnum = false
		newSearchField.DateType = bodyJSONModel.DateType
		if hasFrom {
			errInsertFieldFrom := db.Create(&newSearchField).Error
			if errInsertFieldFrom != nil {
				if errInsertRow == "" {
					errInsertRow = errInsertFieldFrom.Error()
				} else {
					errInsertRow = errInsertRow + "\n" + errInsertFieldFrom.Error()
				}
			}
		}

		// To
		newSearchField.SearchFieldID = 0
		newSearchField.Parameter = dataFieldTo
		newSearchField.Label = bodyJSONModel.Label + " To"
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + dataFieldTo
		newSearchField.Visible = false
		if hasTo {
			errInsertFieldTo := db.Create(&newSearchField).Error
			if errInsertFieldTo != nil {
				if errInsertRow == "" {
					errInsertRow = errInsertFieldTo.Error()
				} else {
					errInsertRow = errInsertRow + "\n" + errInsertFieldTo.Error()
				}
			}
		}
	} else {
		var (
			newSearchField models.SearchField
		)
		newSearchField.SearchFieldKey = bodyJSONModel.UDFKey
		newSearchField.Parameter = strings.ToLower(bodyJSONModel.DataField)
		newSearchField.TableNameObj = strings.ToLower(bodyJSONModel.TableNameObj)
		newSearchField.Label = bodyJSONModel.Label
		newSearchField.MaxLength = bodyJSONModel.MaxLength
		newSearchField.Widget = bodyJSONModel.Widget
		//newSearchField.Visible = bodyJSONModel.Visible
		newSearchField.Visible = false
		newSearchField.Sort = bodyJSONModel.Sort
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + strings.ToLower(bodyJSONModel.DataField)
		newSearchField.AccountKey = accountKey
		newSearchField.Options = bodyJSONModel.Options
		newSearchField.IsEnum = false
		newSearchField.DateType = bodyJSONModel.DateType
		errInsertField := db.Create(&newSearchField).Error
		if errInsertField != nil {
			if errInsertRow == "" {
				errInsertRow = errInsertField.Error()
			} else {
				errInsertRow = errInsertRow + "\n" + errInsertField.Error()
			}
		}
	}
	return errInsertRow
}

// CreateSearchFieldTemplateFunc func
func CreateSearchFieldTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, hasFrom bool, hasTo bool) string {
	var (
		errInsertRow string
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// From
		var (
			newSearchField models.SearchFieldsTemplate
		)
		newSearchField.SearchFieldKey = bodyJSONModel.UDFKey
		newSearchField.Parameter = dataFieldFrom
		newSearchField.TableNameObj = strings.ToLower(bodyJSONModel.TableNameObj)
		newSearchField.Label = bodyJSONModel.Label + " From"
		newSearchField.MaxLength = bodyJSONModel.MaxLength
		newSearchField.Widget = bodyJSONModel.Widget
		//newSearchField.Visible = bodyJSONModel.Visible
		newSearchField.Visible = false
		newSearchField.Sort = bodyJSONModel.Sort
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + dataFieldFrom
		newSearchField.Options = bodyJSONModel.Options
		newSearchField.IsEnum = false
		newSearchField.DateType = bodyJSONModel.DateType
		if hasFrom {
			errInsertFieldFrom := db.Create(&newSearchField).Error
			if errInsertFieldFrom != nil {
				if errInsertRow == "" {
					errInsertRow = errInsertFieldFrom.Error()
				} else {
					errInsertRow = errInsertRow + "\n" + errInsertFieldFrom.Error()
				}
			}
		}

		// To
		newSearchField.SearchFieldTemplateID = 0
		newSearchField.Parameter = dataFieldTo
		newSearchField.Label = bodyJSONModel.Label + " To"
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + dataFieldTo
		newSearchField.Visible = false
		if hasTo {
			errInsertFieldTo := db.Create(&newSearchField).Error
			if errInsertFieldTo != nil {
				if errInsertRow == "" {
					errInsertRow = errInsertFieldTo.Error()
				} else {
					errInsertRow = errInsertRow + "\n" + errInsertFieldTo.Error()
				}
			}
		}
	} else {
		var (
			newSearchField models.SearchFieldsTemplate
		)
		newSearchField.SearchFieldKey = bodyJSONModel.UDFKey
		newSearchField.Parameter = strings.ToLower(bodyJSONModel.DataField)
		newSearchField.TableNameObj = strings.ToLower(bodyJSONModel.TableNameObj)
		newSearchField.Label = bodyJSONModel.Label
		newSearchField.MaxLength = bodyJSONModel.MaxLength
		newSearchField.Widget = bodyJSONModel.Widget
		//newSearchField.Visible = bodyJSONModel.Visible
		newSearchField.Visible = false
		newSearchField.Sort = bodyJSONModel.Sort
		newSearchField.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + strings.ToLower(bodyJSONModel.DataField)
		newSearchField.Options = bodyJSONModel.Options
		newSearchField.IsEnum = false
		newSearchField.DateType = bodyJSONModel.DateType
		errInsertField := db.Create(&newSearchField).Error
		if errInsertField != nil {
			if errInsertRow == "" {
				errInsertRow = errInsertField.Error()
			} else {
				errInsertRow = errInsertRow + "\n" + errInsertField.Error()
			}
		}
	}
	return errInsertRow
}

// CreateGridFunc func
func CreateGridFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int) string {
	var (
		newGrid      models.Grid
		errInsertRow string
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	newGrid.AccountKey = accountKey
	newGrid.GridKey = bodyJSONModel.UDFKey
	newGrid.DataField = bodyJSONModel.DataField //strings.ToLower(bodyJSONModel.DataField)
	newGrid.Caption = bodyJSONModel.Label
	newGrid.DataType = bodyJSONModel.DataType
	newGrid.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + strings.ToLower(bodyJSONModel.DataField)
	newGrid.NumberPrecision = bodyJSONModel.NumberPrecision
	if bodyJSONModel.IsRequired {
		newGrid.Visible = true
	} else {
		newGrid.Visible = bodyJSONModel.Visible
	}
	newGrid.ShowInColumnChooser = true
	newGrid.Width = "100%"
	if bodyJSONModel.Alignment != "" {
		newGrid.Alignment = bodyJSONModel.Alignment
	} else {
		newGrid.Alignment = "left"
	}
	newGrid.AllowGrouping = bodyJSONModel.AllowGrouping
	errInsertGrid := db.Create(&newGrid).Error
	if errInsertGrid != nil {
		if errInsertRow == "" {
			errInsertRow = errInsertGrid.Error()
		} else {
			errInsertRow = errInsertRow + "\n" + errInsertGrid.Error()
		}
	}
	return errInsertRow
}

// CreateGridTemplateFunc func
func CreateGridTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF) string {
	var (
		newGrid      models.GridTemplate
		errInsertRow string
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	newGrid.GridKey = bodyJSONModel.UDFKey
	newGrid.DataField = strings.ToLower(bodyJSONModel.DataField)
	newGrid.Caption = bodyJSONModel.Label
	newGrid.DataType = bodyJSONModel.DataType
	newGrid.TranslationKey = "db." + strings.ToLower(bodyJSONModel.TableNameObj) + "." + strings.ToLower(bodyJSONModel.DataField)
	newGrid.NumberPrecision = bodyJSONModel.NumberPrecision
	newGrid.Visible = false
	newGrid.ShowInColumnChooser = true
	newGrid.Width = "100%"
	if bodyJSONModel.Alignment != "" {
		newGrid.Alignment = bodyJSONModel.Alignment
	} else {
		newGrid.Alignment = "left"
	}
	newGrid.AllowGrouping = bodyJSONModel.AllowGrouping
	errInsertGrid := db.Create(&newGrid).Error
	if errInsertGrid != nil {
		if errInsertRow == "" {
			errInsertRow = errInsertGrid.Error()
		} else {
			errInsertRow = errInsertRow + "\n" + errInsertGrid.Error()
		}
	}
	return errInsertRow
}

// DeleteSearchFieldFunc func
func DeleteSearchFieldFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// From
		sqlDeleteSearchFieldFrom := `DELETE FROM ` + models.SearchField{}.TableName() + ` WHERE AccountKey = ? AND TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchFieldFrom, accountKey, strings.ToLower(bodyJSONModel.TableNameObj), dataFieldFrom, bodyJSONModel.UDFKey)
		// To
		sqlDeleteSearchFieldTo := `DELETE FROM ` + models.SearchField{}.TableName() + ` WHERE AccountKey = ? AND TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchFieldTo, accountKey, strings.ToLower(bodyJSONModel.TableNameObj), dataFieldTo, bodyJSONModel.UDFKey)
	} else {
		sqlDeleteSearchField := `DELETE FROM ` + models.SearchField{}.TableName() + ` WHERE AccountKey = ? AND TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchField, accountKey, strings.ToLower(bodyJSONModel.TableNameObj), strings.ToLower(bodyJSONModel.DataField), bodyJSONModel.UDFKey)
	}
}

// DeleteSearchFieldTemplateFunc func
func DeleteSearchFieldTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// From
		sqlDeleteSearchFieldFrom := `DELETE FROM ` + models.SearchFieldsTemplate{}.TableName() + ` WHERE TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchFieldFrom, strings.ToLower(bodyJSONModel.TableNameObj), dataFieldFrom, bodyJSONModel.UDFKey)
		// To
		sqlDeleteSearchFieldTo := `DELETE FROM ` + models.SearchFieldsTemplate{}.TableName() + ` WHERE TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchFieldTo, strings.ToLower(bodyJSONModel.TableNameObj), dataFieldTo, bodyJSONModel.UDFKey)
	} else {
		sqlDeleteSearchField := `DELETE FROM ` + models.SearchFieldsTemplate{}.TableName() + ` WHERE TableName = ? AND Parameter = ? AND SearchFieldKey = ?`
		db.Exec(sqlDeleteSearchField, strings.ToLower(bodyJSONModel.TableNameObj), strings.ToLower(bodyJSONModel.DataField), bodyJSONModel.UDFKey)
	}
}

// DeleteGridFunc func
func DeleteGridFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	sqlDeleteGrid := `DELETE FROM ` + models.Grid{}.TableName() + ` WHERE AccountKey = ? AND GridKey = ? AND DataField = ?`
	db.Exec(sqlDeleteGrid, accountKey, bodyJSONModel.UDFKey, strings.ToLower(bodyJSONModel.DataField))
}

// DeleteGridTemplateFunc func
func DeleteGridTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	sqlDeleteGrid := `DELETE FROM ` + models.GridTemplate{}.TableName() + ` WHERE GridKey = ? AND DataField = ?`
	db.Exec(sqlDeleteGrid, bodyJSONModel.UDFKey, strings.ToLower(bodyJSONModel.DataField))
}

// CreateOrUpdateSearchFieldFunc func
func CreateOrUpdateSearchFieldFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		errDeleteRow string
	)
	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// @TODO searchfields
		// From
		var (
			rmSearchFieldFrom models.SearchField
		)
		resultFindSearchFrom := db.Where("AccountKey = ? AND TableName = ? AND SearchFieldKey = ? AND Parameter = ?", accountKey, bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, dataFieldFrom).First(&rmSearchFieldFrom)
		if resultFindSearchFrom.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey, true, false)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchFieldFrom.Label = bodyJSONModel.Label + " From"
			rmSearchFieldFrom.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchFieldFrom)
		}
		// To
		var (
			rmSearchFieldTo models.SearchField
		)
		resultFindSearchTo := db.Where("AccountKey = ? AND TableName = ? AND SearchFieldKey = ? AND Parameter = ?", accountKey, bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, dataFieldTo).First(&rmSearchFieldTo)
		if resultFindSearchTo.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey, false, true)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchFieldTo.Label = bodyJSONModel.Label + " To"
			rmSearchFieldTo.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchFieldTo)
		}
	} else {
		var (
			rmSearchField models.SearchField
		)
		resultFindSearch := db.Where("AccountKey = ? AND TableName = ? AND SearchFieldKey = ? AND Parameter = ?", accountKey, bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, bodyJSONModel.DataField).First(&rmSearchField)
		if resultFindSearch.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldFunc(requestHeader, bodyJSONModel, accountKey, false, false)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchField.Label = bodyJSONModel.Label
			rmSearchField.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchField)
		}
	}
	return errDeleteRow
}

// CreateOrUpdateSearchFieldTemplateFunc func
func CreateOrUpdateSearchFieldTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		errDeleteRow string
	)
	dataFieldFrom, dataFieldTo := libs.GetDataFieldFromTo(bodyJSONModel.DataField)
	if libs.InArrayString(bodyJSONModel.DateType, libs.GetArrayDateType()) && bodyJSONModel.Widget == "dxDateBox" {
		// @TODO searchfields
		// From
		var (
			rmSearchFieldFrom models.SearchFieldsTemplate
		)
		resultFindSearchFrom := db.Where("TableName = ? AND SearchFieldKey = ? AND Parameter = ?", bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, dataFieldFrom).First(&rmSearchFieldFrom)
		if resultFindSearchFrom.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldTemplateFunc(requestHeader, bodyJSONModel, true, false)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchFieldFrom.Label = bodyJSONModel.Label + " From"
			rmSearchFieldFrom.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchFieldFrom)
		}
		// To
		var (
			rmSearchFieldTo models.SearchFieldsTemplate
		)
		resultFindSearchTo := db.Where("TableName = ? AND SearchFieldKey = ? AND Parameter = ?", bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, dataFieldTo).First(&rmSearchFieldTo)
		if resultFindSearchTo.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldTemplateFunc(requestHeader, bodyJSONModel, false, true)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchFieldTo.Label = bodyJSONModel.Label + " To"
			rmSearchFieldTo.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchFieldTo)
		}
	} else {
		var (
			rmSearchField models.SearchFieldsTemplate
		)
		resultFindSearch := db.Where("TableName = ? AND SearchFieldKey = ? AND Parameter = ?", bodyJSONModel.TableNameObj, bodyJSONModel.UDFKey, bodyJSONModel.DataField).First(&rmSearchField)
		if resultFindSearch.RowsAffected <= 0 {
			// @TODO add row to searchfield table
			errInsertRowRes := CreateSearchFieldTemplateFunc(requestHeader, bodyJSONModel, false, false)
			if errDeleteRow == "" {
				errDeleteRow = errInsertRowRes
			} else {
				errDeleteRow = errDeleteRow + "\n" + errInsertRowRes
			}
		} else {
			rmSearchField.Label = bodyJSONModel.Label
			rmSearchField.SearchFieldKey = bodyJSONModel.UDFKey
			db.Save(&rmSearchField)
		}
	}
	return errDeleteRow
}

// CreateOrUpdateGridFunc func
func CreateOrUpdateGridFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF, accountKey int) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		rmGrid       models.Grid
		errDeleteRow string
	)
	resultFindGrid := db.Where("AccountKey = ? AND GridKey = ? AND DataField = ?", accountKey, bodyJSONModel.UDFKey,
		strings.ToLower(bodyJSONModel.DataField)).First(&rmGrid)
	if resultFindGrid.RowsAffected <= 0 {
		// @TODO add row to grids table
		errInsertGridRes := CreateGridFunc(requestHeader, bodyJSONModel, accountKey)
		if errDeleteRow == "" {
			errDeleteRow = errInsertGridRes
		} else {
			errDeleteRow = errDeleteRow + "\n" + errInsertGridRes
		}
	} else {
		rmGrid.Caption = bodyJSONModel.Label
		rmGrid.GridKey = bodyJSONModel.UDFKey
		rmGrid.Alignment = bodyJSONModel.Alignment
		rmGrid.AllowGrouping = bodyJSONModel.AllowGrouping
		db.Save(&rmGrid)
	}
	return errDeleteRow
}

// CreateOrUpdateGridTemplateFunc func
func CreateOrUpdateGridTemplateFunc(requestHeader models.RequestHeader, bodyJSONModel models.UDF) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		rmGrid       models.GridTemplate
		errDeleteRow string
	)
	resultFindGrid := db.Where("GridKey = ? AND DataField = ?", bodyJSONModel.UDFKey,
		strings.ToLower(bodyJSONModel.DataField)).First(&rmGrid)
	if resultFindGrid.RowsAffected <= 0 {
		// @TODO add row to grids table
		errInsertGridRes := CreateGridTemplateFunc(requestHeader, bodyJSONModel)
		if errDeleteRow == "" {
			errDeleteRow = errInsertGridRes
		} else {
			errDeleteRow = errDeleteRow + "\n" + errInsertGridRes
		}
	} else {
		rmGrid.Caption = bodyJSONModel.Label
		rmGrid.GridKey = bodyJSONModel.UDFKey
		rmGrid.Alignment = bodyJSONModel.Alignment
		rmGrid.AllowGrouping = bodyJSONModel.AllowGrouping
		db.Save(&rmGrid)
	}
	return errDeleteRow
}
