package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetServicePriceListOnlyMaster godoc
// @Summary Get Service Price List
// @Description Get Service Price List
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist [get]
func GetServicePriceListOnlyMaster(c *gin.Context) {
	defer libs.RecoverError(c, "GetServicePriceListOnlyMaster")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.ServicePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("ServicePriceListDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"ServicePriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.ServicePriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayServicePriceListToArrayResponseOnlyMaster(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetServicePriceListWithDetails godoc
// @Summary Get Service Price List
// @Description Get Service Price List
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist/details [get]
func GetServicePriceListWithDetails(c *gin.Context) {
	defer libs.RecoverError(c, "GetServicePriceListWithDetails")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.ServicePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("ServicePriceListDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"ServicePriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.ServicePriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayServicePriceListToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetServicePriceListByID godoc
// @Summary Get Service Price List By ID
// @Description Get Service Price List By ID
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param id path int true "Service Price List ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist/id/{id} [get]
func GetServicePriceListByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetServicePriceListByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.ServicePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"ServicePriceListDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND ServicePriceListID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertServicePriceListToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateServicePriceList godoc
// @Summary Create Service Price List
// @Description Create Service Price List
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ServicePriceList body models.ServicePriceListResponse true "Create Service Price List"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist [post]
func CreateServicePriceList(c *gin.Context) {
	apiName := "CreateServicePriceList"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var bp map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &bp)
	var (
		obj models.ServicePriceList
	)
	obj.PassBodyJSONToModel(bp)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND ServicePriceListName = ?", obj.ServicePriceListName).First(&models.ServicePriceList{})
	if resultCheckExist.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.servicepricelistname_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(obj)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError   string
				itemMsgWarning string
			)
			// @TODO validate for Detail
			objDetailsValid := make([]models.ServicePriceListDetail, 0)
			for _, objDetail := range obj.ServicePriceListDetails {
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(objDetail)
				if err != nil {
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
					}
				} else {
					// @ vaidate data in details
					validateDetail := ValidateServicePriceListDetails(lang, objDetail)
					itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
					if validateDetail != "" {
						continue
					}
					objDetail.CreatedBy = accountKey
					objDetailsValid = append(objDetailsValid, objDetail)
				}
			}
			obj.ServicePriceListDetails = objDetailsValid
			if len(obj.ServicePriceListDetails) <= 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.servicepricelistdetails_required")
				errorsResponse = append(errorsResponse, errResponse)
			}
			if len(errorsResponse) <= 0 {
				if itemMsgWarning != "" {
					errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
					errorsResponse = append(errorsResponse, errResponse)
				}
				if itemMsgError == "" {
					// @TODO need to required > 0 for address, phone
					resultCreate := db.Create(&obj)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						totalUpdatedRecord++
						data = ConvertServicePriceListToResponse(requestHeader, obj)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateServicePriceList godoc
// @Summary Update Service Price List
// @Description Update Service Price List
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ServicePriceList body models.ServicePriceListResponse true "Update Service PriceList"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist/{id} [put]
func UpdateServicePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateServicePriceList")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.ServicePriceList
	)
	resultFind := db.Where("ServicePriceListID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND ServicePriceListName = ? AND ServicePriceListID <> ?", resModel.ServicePriceListName, resModel.ServicePriceListID).First(&models.ServicePriceList{})
		if resultCheckExist.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.servicepricelistname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resModel.ServicePriceListID = id
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError   string
					res            interface{}
					itemMsgWarning string
				)
				// @TODO validate for details
				// set details empty
				resModel.ServicePriceListDetails = make([]models.ServicePriceListDetail, 0)
				var (
					objectsDetails        []map[string]interface{}
					details               []models.ServicePriceListDetail
					arrSkipID             []int
					arrToDeleteID         []int
					detailsToDeleteModels []models.ServicePriceListDetail
				)
				details = make([]models.ServicePriceListDetail, 0)
				_, res = services.ConvertJSONValueToVariable("ServicePriceListDetails", bp)
				if res != nil {
					objectsJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(objectsJSON, &objectsDetails)
						if len(objectsDetails) > 0 {
							for _, obj := range objectsDetails {
								var (
									detailModel models.ServicePriceListDetail
								)
								detailModel.PassBodyJSONToModel(obj)
								resultFindDetails := db.Where("ServicePriceListDetailID = ? AND ServicePriceListID = ?", detailModel.ServicePriceListDetailID, resModel.ServicePriceListID).First(&detailModel)
								if resultFindDetails.RowsAffected > 0 {
									arrSkipID = append(arrSkipID, detailModel.ServicePriceListDetailID)
									detailModel.PassBodyJSONToModel(obj)
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											if itemMsgError == "" {
												itemMsgError = itemMsgError + e.Translate(trans)
											} else {
												itemMsgError = itemMsgError + "\n" + e.Translate(trans)
											}
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidateServicePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								} else {
									detailModel.PassBodyJSONToModel(obj)
									detailModel.CreatedBy = accountKey
									detailModel.ServicePriceListDetailID = 0
									detailModel.ServicePriceListID = 0
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidateServicePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								}
							}
						}
					}
				}
				resModel.ServicePriceListDetails = details

				if itemMsgWarning != "" {
					errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
					errorsResponse = append(errorsResponse, errResponse)
				}

				if len(resModel.ServicePriceListDetails) <= 0 {
					errResponse := GetErrorResponseValidate(lang, 0, "api.servicepricelistdetails_required")
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					if len(arrSkipID) > 0 {
						// delete id not in arrSkipID
						db.Where("ServicePriceListID = ? AND ServicePriceListDetailID not in (?)", resModel.ServicePriceListID, arrSkipID).Find(&detailsToDeleteModels)
					} else {
						// delete all
						db.Where("ServicePriceListID = ?", resModel.ServicePriceListID).Find(&detailsToDeleteModels)
					}
					for _, ad := range detailsToDeleteModels {
						arrToDeleteID = append(arrToDeleteID, ad.ServicePriceListDetailID)
					}
					// @TODO need to required > 0 for details
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							db.Where("ServicePriceListDetailID in (?)", arrToDeleteID).Delete(&models.ServicePriceListDetail{})
							//db.Where("ServicePriceListDetailID in (?)", arrToDeleteID).Model(&models.ServicePriceListDetail{}).Updates(models.ServicePriceListDetail{IsDeleted: true})
						}
						//data = ConvertServicePriceListToResponse(requestHeader, resModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}

			resultRow := db.Preload(
				"ServicePriceListDetails",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("IFNULL(IsDeleted, 0) <> 1 AND ServicePriceListID = ?", id).First(&resModel)
			if resultRow.RowsAffected > 0 {
				responses := ConvertServicePriceListToResponse(requestHeader, resModel)
				data = responses
			} else {
				errResponse := GetErrorResponseNotFound(lang, 0)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteServicePriceList godoc
// @Summary Delete Service Price List
// @Description Delete Service Price List
// @Tags ServicePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Service Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /servicepricelist/{id} [delete]
func DeleteServicePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteServicePriceList")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.ServicePriceList
		)
		resultFind := db.Where("ServicePriceListID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			// @TODO DELETE - If the pricelist is assigned to a pricematrix cannot be deleted
			var totalCountAssigned int64
			totalCountAssigned = 0
			db.Model(&models.PriceListDetail{}).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ServicePriceListID = ?", resModel.ServicePriceListID).Count(&totalCountAssigned)
			if totalCountAssigned > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.confirm_delete_servicepricelist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// @TODO delete detail
					//db.Where("ServicePriceListID = ?", id).Delete(&models.ServicePriceListDetail{})
					db.Where("ServicePriceListID = ?", id).Model(&models.ServicePriceListDetail{}).Updates(models.ServicePriceListDetail{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayServicePriceListToArrayResponseOnlyMaster func
func ConvertArrayServicePriceListToArrayResponseOnlyMaster(items []models.ServicePriceList) []models.ServicePriceListResponseMaster {
	responses := make([]models.ServicePriceListResponseMaster, 0)
	for _, item := range items {
		response := ConvertServicePriceListToResponseOnlyMaster(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertServicePriceListToResponseOnlyMaster func
func ConvertServicePriceListToResponseOnlyMaster(item models.ServicePriceList) models.ServicePriceListResponseMaster {
	var (
		response models.ServicePriceListResponseMaster
	)
	response.ServicePriceListID = item.ServicePriceListID
	response.ServicePriceListName = item.ServicePriceListName
	return response
}

// ConvertArrayServicePriceListToArrayResponse func
func ConvertArrayServicePriceListToArrayResponse(requestHeader models.RequestHeader, items []models.ServicePriceList) []models.ServicePriceListResponse {
	responses := make([]models.ServicePriceListResponse, 0)
	for _, item := range items {
		response := ConvertServicePriceListToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertServicePriceListToResponse func
func ConvertServicePriceListToResponse(requestHeader models.RequestHeader, item models.ServicePriceList) models.ServicePriceListResponse {
	var (
		response models.ServicePriceListResponse
	)

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.ServicePriceListID = item.ServicePriceListID
	response.ServicePriceListName = item.ServicePriceListName
	response.IsIncludeTax = item.IsIncludeTax
	details := make([]models.ServicePriceListDetailResponse, 0)
	for _, de := range item.ServicePriceListDetails {
		var (
			detail models.ServicePriceListDetailResponse
		)

		var (
			item models.Item
		)
		db.Where("ItemID = ?", de.ItemID).First(&item)
		if item.ItemID != 0 {
			detail.ItemCode = item.Code
			detail.ItemName = item.Name
			detail.Description = item.Description
		}

		detail.ServicePriceListDetailID = de.ServicePriceListDetailID
		detail.ServicePriceListID = de.ServicePriceListID
		detail.ItemID = de.ItemID
		detail.Unit = de.Unit
		detail.DefaultQuantity = de.DefaultQuantity
		detail.Price = de.Price
		detail.DiscountPercent = de.DiscountPercent
		detail.BufferPercent = de.BufferPercent
		details = append(details, detail)
	}
	response.ServicePriceListDetails = details
	return response
}

// ValidateServicePriceListDetails func
func ValidateServicePriceListDetails(lang string, detail models.ServicePriceListDetail) string {
	var itemMsgWarning string
	if detail.DefaultQuantity < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.defaultquantity_greater_zero"))
	}
	if detail.Price <= 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.price_greater_zero"))
	}
	if detail.DiscountPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.discountpercent_greater_zero"))
	}
	if detail.BufferPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.bufferpercent_greater_zero"))
	}
	return itemMsgWarning
}
