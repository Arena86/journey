package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetReason godoc
// @Summary Get Reason
// @Description Get Reason
// @Tags Reason
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param ReasonEntity query string false "Reasonentity=1,2,3"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /reason [get]
func GetReason(c *gin.Context) {
	defer libs.RecoverError(c, "GetReason")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Reason
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsVisible, 1) <> 0 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"Reason"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	vReasonEntity, sReasonEntity := libs.GetQueryParam("ReasonEntity", c)
	if sReasonEntity {
		arrReasonEntity := libs.StringToArray(vReasonEntity)
		if len(arrReasonEntity) <= 0 {
			arrReasonEntity = append(arrReasonEntity, -1)
		}
		bp = bp.Where("ReasonEntity in (?)", arrReasonEntity)
	}

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayReasonToArrayResponse(requestHeader, resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetReasonByID godoc
// @Summary Get Reason By ID
// @Description Get Reason By ID
// @Tags Reason
// @Accept  json
// @Produce  json
// @Param id path int true "Reason ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /reason/{id} [get]
func GetReasonByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetReasonByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Reason
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND ReasonID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertReasonToResponse(requestHeader, resModel, lang)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateReason godoc
// @Summary Create Reason
// @Description Create Reason
// @Tags Reason
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Reason body []models.ReasonResponse true "Create Reason"
// @Success 200 {object} models.APIResponseData
// @Router /reason [post]
func CreateReason(c *gin.Context) {
	apiName := "CreateReason"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Reason
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Reason, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				obj models.Reason
			)
			obj.PassBodyJSONToModel(bp)
			resultFindReason := db.Where("ReasonEntity = ? AND Reason = ?", obj.ReasonEntity, obj.Reason).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Reason{})
			if resultFindReason.RowsAffected > 0 {
				errResponse := GetErrorResponseErrorMessage(k, services.GetMessage(lang, "api.reason_exist"))
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				obj.CreatedBy = accountKey
				obj.ModifiedBy = accountKey
				// @TODO validate
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(obj)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultCreate := db.Create(&obj)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, obj)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		objs []models.Reason
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReasonID)
	}
	if len(arrID) > 0 {
		db.Where("ReasonID in (?)", arrID).Find(&objs)
		dataResponses := ConvertArrayReasonToArrayResponse(requestHeader, objs, lang)
		data = dataResponses
	} else {
		data = dataResponse
	}
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateReason godoc
// @Summary Update Reason
// @Description Update Reason
// @Tags Reason
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Reason body []models.ReasonResponse true "Update Reason"
// @Success 200 {object} models.APIResponseData
// @Router /reason [put]
func UpdateReason(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateReason")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Reason
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Reason, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.Reason
			)
			putModel.PassBodyJSONToModel(bp)
			resultFind := db.Where("ReasonID = ?", putModel.ReasonID).First(&putModel)
			if resultFind.RowsAffected > 0 {
				putModel.PassBodyJSONToModel(bp)
				resultFindReason := db.Where("ReasonEntity = ? AND Reason = ? AND ReasonID <> ?", putModel.ReasonEntity, putModel.Reason, putModel.ReasonID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Reason{})
				if resultFindReason.RowsAffected > 0 {
					errResponse := GetErrorResponseErrorMessage(k, services.GetMessage(lang, "api.reason_exist"))
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					putModel.ModifiedBy = accountKey
					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(putModel)
					if err != nil {
						var (
							errValid interface{}
						)
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							errValid = e.Translate(trans)
						}
						errResponse := GetErrorResponseErrorMessage(k, errValid)
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						var (
							itemMsgError string
						)
						resultSave := db.Save(&putModel)
						if resultSave.Error != nil {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						} else {
							totalUpdatedRecord++
							dataResponse = append(dataResponse, putModel)
						}
						if itemMsgError != "" {
							errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Reason
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ReasonID)
	}
	if len(arrID) > 0 {
		db.Where("ReasonID in (?)", arrID).Find(&resModels)
		dataResponses := ConvertArrayReasonToArrayResponse(requestHeader, resModels, lang)
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteReason godoc
// @Summary Delete Reason
// @Description Delete Reason
// @Tags Reason
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Reason ID"
// @Success 200 {object} models.APIResponseData
// @Router /reason/{id} [delete]
func DeleteReason(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteReason")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.Reason
		)
		resultFind := db.Where("ReasonID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayReasonToArrayResponse func
func ConvertArrayReasonToArrayResponse(requestHeader models.RequestHeader, items []models.Reason, lang string) []models.ReasonResponse {
	responses := make([]models.ReasonResponse, 0)
	for _, item := range items {
		response := ConvertReasonToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertReasonToResponse func
func ConvertReasonToResponse(requestHeader models.RequestHeader, item models.Reason, lang string) models.ReasonResponse {
	var (
		response         models.ReasonResponse
		reasonEntityEnum models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.ReasonID = item.ReasonID
	response.ReasonEntity = item.ReasonEntity
	db.Where("FieldName = ? AND Status = ?", "ReasonEntity", item.ReasonEntity).First(&reasonEntityEnum)
	if reasonEntityEnum.TranslationKey != "" && reasonEntityEnum.TranslationKey != services.GetMessage(lang, reasonEntityEnum.TranslationKey) {
		response.ReasonEntityName = services.GetMessage(lang, reasonEntityEnum.TranslationKey)
	} else {
		response.ReasonEntityName = reasonEntityEnum.Caption
	}
	response.Reason = item.Reason
	return response
}
