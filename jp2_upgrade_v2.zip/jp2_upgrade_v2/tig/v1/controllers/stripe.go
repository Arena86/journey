package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/stripe/stripe-go"
	"github.com/stripe/stripe-go/charge"
	"github.com/stripe/stripe-go/token"
)

// CreateStripePayment godoc
// @Summary Create Stripe Payment
// @Description Create Stripe Payment
// @Tags Stripe
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SMSTemplate body []models.SMSTemplateResponse true "Create SMSTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /stripe/payment [post]
func CreateStripePayment(c *gin.Context) {
	defer libs.RecoverError(c, "CreateStripePayment")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data         interface{}
		errorsResponse    []models.ErrorResponse
		stripePaymentPOST models.StripePaymentJP
		stripePaymentID   string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &stripePaymentPOST)

	// @TODO check exist InvoiceID
	var jobModel models.Job
	resultFindJob := db.Where("ErpInvoiceKey = ?", stripePaymentPOST.InvoiceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
	if resultFindJob.RowsAffected > 0 {
		paidStatus := "PAID"
		if jobModel.ErpInvoiceStatus != &paidStatus {
			invoiceNum := ""
			representURL := "Invoices/" + stripePaymentPOST.InvoiceID
			resStatus, _, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil, false)
			if resStatus == 200 {
				var dataRes map[string]interface{}
				json.Unmarshal([]byte(string(resData)), &dataRes)
				var invoiceRes = make([]interface{}, 0)
				objectJSON, errJSON := json.Marshal(dataRes["Invoices"])
				if errJSON == nil {
					json.Unmarshal(objectJSON, &invoiceRes)
					if len(invoiceRes) > 0 {
						var xeroData interface{}
						xeroData = invoiceRes[0]
						invoiceData := xeroData.(map[string]interface{})
						invoiceNum = fmt.Sprintf("%v", invoiceData["InvoiceNumber"])
					}
				}
			}
			status, msg, stripePaymentID = StripePayment(lang, accountKey, invoiceNum+"/"+stripePaymentPOST.InvoiceID, stripePaymentPOST)
			if status == 200 {
				// Create Payment on Xero
				var xeroPayment models.XeroPaymentPOST
				xeroPayment.Invoice.InvoiceID = stripePaymentPOST.InvoiceID
				// @TODO hardcode to testing and need add to config
				accountCode := "880"
				xeroPayment.Account.Code = &accountCode
				xeroPayment.Date = time.Now().Format(libs.FORMATDATE)
				xeroPayment.Amount = stripePaymentPOST.Amount
				xeroPayment.Reference = &stripePaymentID
				representURL := "Payments"
				resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "PUT", representURL, xeroPayment, nil, nil)
				fmt.Println(resMsg)
				if resStatus == 200 {
					var xeroPaymentRes models.XeroPaymentResponse
					json.Unmarshal([]byte(string(resData)), &xeroPaymentRes)
					if len(xeroPaymentRes.Payments) > 0 {
						paymentObj := xeroPaymentRes.Payments[0]
						jobModel.ErpInvoiceStatus = &paymentObj.Invoice.Status
						db.Save(&jobModel)
					}
				} else {
					status = resStatus
					msg = resMsg
				}
			}
		}
	} else { // Create Payment Without Invoice
		status = 404
		msg = services.GetMessage(lang, "api.invoiceid_not_found")
	}

	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// StripePayment func
func StripePayment(lang string, accountKey int, description string, stripePaymentPOST models.StripePaymentJP) (int, interface{}, string) {
	var (
		status          = libs.GetStatusSuccess()
		msg             interface{}
		errStripeErr    models.StripeResponseError
		tokenID         string
		stripePaymentID string
	)

	stripeConfig := libs.GetStripeSecretKey(lang, accountKey)
	stripe.Key = stripeConfig.SecretKey
	// Create token on Stripe
	paramToken := &stripe.TokenParams{
		Card: &stripe.CardParams{
			Number:   stripe.String(stripePaymentPOST.Card.Number),
			ExpMonth: stripe.String(strconv.Itoa(stripePaymentPOST.Card.ExpMonth)),
			ExpYear:  stripe.String(strconv.Itoa(stripePaymentPOST.Card.ExpYear)),
			CVC:      stripe.String(stripePaymentPOST.Card.CVC),
		},
	}
	t, err := token.New(paramToken)
	if err == nil {
		if t != nil {
			tokenID = t.ID
		}
	} else {
		status = 500
		msg = err.Error()
	}
	if tokenID != "" {
		if stripePaymentPOST.Currency == "" {
			stripePaymentPOST.Currency = os.Getenv("DEFAULT_CURRENCY")
		}
		paramCharge := &stripe.ChargeParams{
			Amount:              stripe.Int64(int64(stripePaymentPOST.Amount * 100)),
			Currency:            stripe.String(stripePaymentPOST.Currency),
			Description:         stripe.String(description),
			Source:              &stripe.SourceParams{Token: stripe.String(tokenID)},
			StatementDescriptor: stripe.String(stripePaymentPOST.Card.FirstName + stripePaymentPOST.Card.LastName),
		}
		chargeRes, err := charge.New(paramCharge)
		if err != nil {
			status = 500
			json.Unmarshal([]byte(err.Error()), &errStripeErr)
			msg = errStripeErr.Message
		} else {
			if chargeRes != nil {
				stripePaymentID = chargeRes.ID
			}
		}
	}
	return status, msg, stripePaymentID
}
