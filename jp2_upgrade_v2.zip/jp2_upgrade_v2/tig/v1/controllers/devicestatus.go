package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetDeviceStatus godoc
// @Summary Get DeviceStatus By ID
// @Description Get DeviceStatus  By ID
// @Tags DeviceStatus
// @Accept  json
// @Produce  json
// @Param id path int true "DeviceStatus ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /devicestatus [get]
func GetDeviceStatus(c *gin.Context) {
	defer libs.RecoverError(c, "GetDeviceStatus")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DeviceStatus
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
		userModel     models.User
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	vScheduleDate, sScheduleDate := libs.GetQueryParam("ScheduleDate", c)
	if sScheduleDate {
		dScheduleDate, errScheduleDate := services.ConvertStringToDateTime(vScheduleDate)
		if errScheduleDate == nil {
			vScheduleDate = dScheduleDate.Format("2006-01-02")
		}
	}
	if vScheduleDate == "" {
		vScheduleDate = time.Now().Format("2006-01-02")
	}
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		resultRow := db.Where("UserID = ? AND DATE_FORMAT(ScheduleDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", userModel.UserID, vScheduleDate).First(&resModel)
		if resultRow.RowsAffected > 0 {
			msg = services.GetMessage(lang, "api.success")
			itemsResponse := ConvertDeviceStatusToResponse(resModel, lang)
			data = itemsResponse
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateDeviceStatus godoc
// @Summary Create DeviceStatus
// @Description Create DeviceStatus
// @Tags DeviceStatus
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DeviceStatus body []models.DeviceStatusResponse true "Create DeviceStatus"
// @Success 200 {object} models.APIResponseData
// @Router /devicestatus [post]
func CreateDeviceStatus(c *gin.Context) {
	defer libs.RecoverError(c, "CreateDeviceStatus")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.DeviceStatus
		totalUpdatedRecord = 0
		userModel          models.User
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.DeviceStatus, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		var (
			resModel models.DeviceStatus
		)
		resModel.PassBodyJSONToModel(objectsJSON)
		resultFind := db.Where("UserID = ?", userModel.UserID).First(&resModel)
		resModel.PassBodyJSONToModel(objectsJSON)
		resModel.UserID = userModel.UserID
		resModel.CreatedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			if resultFind.RowsAffected > 0 {
				db.Save(&resModel)
			} else {
				db.Create(&resModel)
			}
			totalUpdatedRecord++
			dataResponse = append(dataResponse, resModel)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)
	var (
		resModels []models.DeviceStatus
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.DeviceStatusID)
	}
	if len(arrID) > 0 {
		db.Where("DeviceStatusID in (?)", arrID).Find(&resModels)
		data = ConvertArrayDeviceStatusToArrayResponse(resModels, lang)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayDeviceStatusToArrayResponse func
func ConvertArrayDeviceStatusToArrayResponse(items []models.DeviceStatus, lang string) []models.DeviceStatusResponse {
	responses := make([]models.DeviceStatusResponse, 0)
	for _, item := range items {
		response := ConvertDeviceStatusToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDeviceStatusToResponse func
func ConvertDeviceStatusToResponse(item models.DeviceStatus, lang string) models.DeviceStatusResponse {
	var (
		response models.DeviceStatusResponse
	)
	response.UserID = item.UserID
	response.Value = item.Value
	response.ScheduleDate = item.ScheduleDate
	return response
}
