package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

const (
	FrequencyDaily            = 1
	FrequencyWeekly           = 2
	FrequencyMonthly          = 3
	FrequencyDailyName        = "Daily"
	FrequencyWeeklyName       = "Weekly"
	FrequencyMonthlyName      = "Monthly"
	RecurringStatusNotStarted = 0
	RecurringStatusInProgress = 1
	RecurringStatusEnded      = 2
	RecurringStatusPaused     = 3
)

func GetListScheduleFromRecurringJob(requestHeader models.RequestHeader, lang string, c *gin.Context, accountKey int) []models.ScheduleResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		recurringJobs             []models.RecurringJob
		fromDate, toDate          *time.Time
		arrSchedulesResponseTotal = make([]models.ScheduleResponse, 0)
	)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	format := libs.MYSQLDATE
	shortDayFormat := libs.FORMATDATE
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			fromDate = &dFromDate
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			toDate = &dToDate
		}
	}
	if fromDate != nil && toDate != nil {
		db.Where("IFNULL(IsPaused, 0) <> 1").Where("IFNULL(recurringjobs.IsDeleted, 0) <> 1 AND IFNULL(recurringjobs.IsArchived, 0) <> 1").
			Joins(" JOIN jobs ON jobs.JobID = recurringjobs.JobID").
			Where("IFNULL(jobs.IsDeleted, 0) <> 1 AND IFNULL(jobs.IsArchived, 0) <> 1 AND IFNULL(jobs.IsRecurring, 0) = 1 AND jobs.LocationID = ?", locationID).
			Find(&recurringJobs)
		for _, recurringJob := range recurringJobs {
			if recurringJob.StartDate != nil {
				dFromDate := *fromDate
				dToDate := *toDate
				dStartDate := *recurringJob.StartDate
				sStartDate := dStartDate.Format(libs.FORMATDATE)
				sStartTime := recurringJob.StartTime.Format("15:04:05")
				sStartDateTime := sStartDate + " " + sStartTime
				dStartDateTime, errStartDateTime := libs.ConvertStringToDateTime(sStartDateTime)
				if recurringJob.EndDate != nil {
					dEndDate := *recurringJob.EndDate
					if dEndDate.Unix() < dToDate.Unix() {
						dToDate = dEndDate
					}
				}
				if errStartDateTime == nil {
					/* if dToDate.Unix() < dStartDateTime.Unix() {
						continue
					} */
				} else {
					continue
				}
				every := recurringJob.Every
				if every <= 0 {
					every = 1
				}
				arrWeekDay := make([]string, 0)
				sWeekDay := strings.TrimSpace(recurringJob.WeekDay)
				if sWeekDay != "" {
					arrWeekDay = strings.Split(sWeekDay, ",")
				}
				for i := range arrWeekDay {
					arrWeekDay[i] = strings.TrimSpace(arrWeekDay[i])
				}
				arrWeekDay = UniqueDayRepeatInArray(arrWeekDay)
				for i := range arrWeekDay {
					arrWeekDay[i] = strings.ToLower(arrWeekDay[i])
				}
				dFromDateOnlyDay, _ := libs.ConvertStringToDateTime(dFromDate.Format(shortDayFormat))
				dToDateOnlyDay, _ := libs.ConvertStringToDateTime(dToDate.Format(shortDayFormat))
				switch recurringJob.Frequency {
				case FrequencyDaily:
					i := 0
					for {
						dNextStartDateTime := dStartDateTime.AddDate(0, 0, i)
						dNextStartDateTimeOnlyDay, _ := libs.ConvertStringToDateTime(dNextStartDateTime.Format(shortDayFormat))
						if dNextStartDateTimeOnlyDay.Unix() > dToDateOnlyDay.Unix() {
							break
						}
						// add to list
						if dNextStartDateTimeOnlyDay.Unix() >= dFromDateOnlyDay.Unix() {
							fmt.Println("dNextStartDateTime: ", dNextStartDateTime.Format(format))
							arrSchedulesResponse := GetScheduleInfoFromRecurringJob(requestHeader, lang, recurringJob, dNextStartDateTime)
							if len(arrSchedulesResponse) > 0 {
								arrSchedulesResponseTotal = append(arrSchedulesResponseTotal, arrSchedulesResponse...)
							}
						}
						i = i + every
					}
				case FrequencyWeekly:
					i := 0
					for {
						dNextStartDateTime := dStartDateTime.AddDate(0, 0, i)
						dNextStartDateTimeOnlyDay, _ := libs.ConvertStringToDateTime(dNextStartDateTime.Format(shortDayFormat))
						if dNextStartDateTimeOnlyDay.Unix() > dToDateOnlyDay.Unix() {
							break
						}
						weekDay := dNextStartDateTime.Weekday().String()
						shortWeekDay := GetShortWeekDay(weekDay)
						shortWeekDay = strings.ToLower(shortWeekDay)
						if libs.InArrayString(shortWeekDay, arrWeekDay) {
							// add to list
							if dNextStartDateTimeOnlyDay.Unix() >= dFromDateOnlyDay.Unix() {
								fmt.Println("shortWeekDay: ", shortWeekDay)
								fmt.Println("dNextStartDateTime: ", dNextStartDateTime.Format(format))
								arrSchedulesResponse := GetScheduleInfoFromRecurringJob(requestHeader, lang, recurringJob, dNextStartDateTime)
								if len(arrSchedulesResponse) > 0 {
									arrSchedulesResponseTotal = append(arrSchedulesResponseTotal, arrSchedulesResponse...)
								}
							}
						}
						if shortWeekDay != "sun" {
							i = (i + 1)
						} else {
							// go to first of week
							i = ((i - 6) + every*7)
						}
					}
				case FrequencyMonthly:
					i := 0
					j := 0
					for {
						dNextStartDateTime := dStartDateTime.AddDate(0, i, j)
						dNextStartDateTimeOnlyDay, _ := libs.ConvertStringToDateTime(dNextStartDateTime.Format(shortDayFormat))
						if dNextStartDateTimeOnlyDay.Unix() > dToDateOnlyDay.Unix() {
							break
						}
						dayInMonth := dNextStartDateTime.Day()
						if recurringJob.MonthDay > 0 {
							if dayInMonth == recurringJob.MonthDay {
								// add to list
								if dNextStartDateTimeOnlyDay.Unix() >= dFromDateOnlyDay.Unix() {
									fmt.Println("dNextStartDateTime: ", dNextStartDateTime.Format(format))
									arrSchedulesResponse := GetScheduleInfoFromRecurringJob(requestHeader, lang, recurringJob, dNextStartDateTime)
									if len(arrSchedulesResponse) > 0 {
										arrSchedulesResponseTotal = append(arrSchedulesResponseTotal, arrSchedulesResponse...)
									}
								}
							}
						} else {
							/* zoneName, zoneOffset := dNextStartDateTime.Zone()
							beginningOfTheMonth := time.Date(dNextStartDateTime.Year(), dNextStartDateTime.Month(), 1, 1, 1, 1, 1, time.FixedZone(zoneName, zoneOffset))
							_, thisWeek := dNextStartDateTime.ISOWeek()
							_, beginningWeek := beginningOfTheMonth.ISOWeek()
							numberOfTheWeekInMonth := 1 + thisWeek - beginningWeek
							if numberOfTheWeekInMonth == recurringJob.MonthFSTFL {
								weekDay := dNextStartDateTime.Weekday().String()
								shortWeekDay := GetShortWeekDay(weekDay)
								shortWeekDay = strings.ToLower(shortWeekDay)
								if libs.InArrayString(shortWeekDay, arrWeekDay) {
									if dNextStartDateTimeOnlyDay.Unix() >= dFromDateOnlyDay.Unix() {
										fmt.Println("dNextStartDateTime: ", dNextStartDateTime.Format(format))
										fmt.Println("shortWeekDay: ", shortWeekDay)
										fmt.Println("numberOfTheWeekInMonth: ", numberOfTheWeekInMonth)
										arrSchedulesResponse := GetScheduleInfoFromRecurringJob(requestHeader, lang, recurringJob, dNextStartDateTime)
										if len(arrSchedulesResponse) > 0 {
											arrSchedulesResponseTotal = append(arrSchedulesResponseTotal, arrSchedulesResponse...)
										}
									}
								}
							} */

							// recurringJob.MonthFSTFL => index of Weekday
							// eg: Weekday: Mon , MonthFSTFL: 2 => Mon of 2 index
							// if MonthFSTFL: 5 but this month has: 4 index => MonthFSTFL: 4

							if len(arrWeekDay) > 0 {
								firstWeekDay := arrWeekDay[0]
								weekDay := dNextStartDateTime.Weekday().String()
								shortWeekDay := GetShortWeekDay(weekDay)
								shortWeekDay = strings.ToLower(shortWeekDay)
								if shortWeekDay == firstWeekDay {
									totalIndexWeekDay, currentIndexWeekDay := GetIndexWeekDayInMonth(dNextStartDateTime)
									indexOfMonth := recurringJob.MonthFSTFL
									if totalIndexWeekDay < indexOfMonth {
										indexOfMonth = totalIndexWeekDay
									}
									/* fmt.Println("dNextStartDateTimeOnlyDay: ", dNextStartDateTimeOnlyDay.Format(format))
									fmt.Println("dFromDateOnlyDay: ", dFromDateOnlyDay.Format(format))
									fmt.Println("indexOfMonth: ", indexOfMonth)
									fmt.Println("currentIndexWeekDay: ", currentIndexWeekDay) */
									if currentIndexWeekDay == indexOfMonth {
										if dNextStartDateTimeOnlyDay.Unix() >= dFromDateOnlyDay.Unix() {
											fmt.Println("dNextStartDateTime: ", dNextStartDateTime.Format(format))
											fmt.Println("shortWeekDay: ", shortWeekDay)
											fmt.Println("currentIndexWeekDay: ", currentIndexWeekDay)
											fmt.Println()
											arrSchedulesResponse := GetScheduleInfoFromRecurringJob(requestHeader, lang, recurringJob, dNextStartDateTime)
											if len(arrSchedulesResponse) > 0 {
												arrSchedulesResponseTotal = append(arrSchedulesResponseTotal, arrSchedulesResponse...)
											}
										}
									}

								}
							}
						}
						endOfMonth := dNextStartDateTime.AddDate(0, 1, -dNextStartDateTime.Day())
						dayEndOfMonth := endOfMonth.Day()
						dayInMonthOfStartDateTime := dStartDateTime.Day()
						if dayInMonth != dayEndOfMonth {
							j = j + 1
						} else {
							j = (-dayInMonthOfStartDateTime + 1)
							i = i + every
						}
					}
				}
			}
		}
	}

	return arrSchedulesResponseTotal
}

func GetScheduleInfoFromRecurringJob(requestHeader models.RequestHeader, lang string, recurringModel models.RecurringJob, startDateTime time.Time) []models.ScheduleResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		arrScheduleObj     = make([]models.ScheduleResponse, 0)
		jobModel           models.Job
		jobTaskModels      []models.JobTask
		recurringSkipModel []models.RecurringSkip
	)
	resultFindRecurringSkip := db.Where("RecurringJobID = ? AND DATE_FORMAT(SkipFromDate,'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d') AND DATE_FORMAT(?,'%Y-%m-%d') <= DATE_FORMAT(SkipToDate,'%Y-%m-%d')", recurringModel.RecurringJobID, startDateTime.Format(libs.FORMATDATE), startDateTime.Format(libs.FORMATDATE)).
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&recurringSkipModel)
	if resultFindRecurringSkip.RowsAffected > 0 {
		return arrScheduleObj
	}
	resultFindJob := db.Where("JobID = ?", recurringModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
	if resultFindJob.RowsAffected > 0 {
		db.Where("JobID = ?", recurringModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTaskModels)
		for _, jobTask := range jobTaskModels {
			var (
				scheduleObj    models.ScheduleResponse
				jobTaskSummary models.JobTaskSummary
				jobSummary     models.JobSummary
			)
			scheduleObj.ScheduleStartDate = startDateTime
			serviceTimeInMinutes := jobTask.ServiceTimeInMinutes
			scheduleObj.ScheduleEndDate = startDateTime.Add(time.Minute * time.Duration(serviceTimeInMinutes))
			scheduleObj.LocationID = jobModel.LocationID
			scheduleObj.ResourceID = recurringModel.ResourceID
			scheduleObj.JobID = jobModel.JobID
			scheduleObj.JobTaskID = jobTask.JobTaskID
			//scheduleObj.JourneyCode =
			//scheduleObj.JobStatus = jobModel.Status
			scheduleObj.JobStatus = 1
			scheduleObj.JobStatusName, scheduleObj.JobStatusIcon = libs.GetEnum(requestHeader, scheduleObj.JobStatus, "JobStatus", lang)
			jobSummary.JobNumber = jobModel.JobNumber
			jobSummary.JobID = jobModel.JobID
			jobSummary.JobType = jobModel.JobType
			jobSummary.JobTypeName, jobSummary.JobTypeIcon = libs.GetEnum(requestHeader, jobModel.JobType, "JobType", lang)
			jobSummary.JobDate = jobModel.JobDate
			jobSummary.ContactDetails = jobModel.ContactDetails
			jobSummary.ContactPhoneNumber = jobModel.ContactPhoneNumber
			jobSummary.Comment = jobModel.Comment
			jobSummary.Priority = jobModel.Priority
			jobSummary.PriorityName, jobSummary.PriorityIcon = libs.GetEnum(requestHeader, jobModel.Priority, "Priority", lang)
			jobSummary.IsCombinedChild = jobModel.IsCombinedChild
			jobSummary.IsRecurring = jobModel.IsRecurring
			jobSummary.RecurringJobID = jobModel.RecurringJobID
			jobSummary.OptimizeJob = jobModel.OptimizeJob
			var bp models.BusinessPartner
			resultFindBP := db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&bp)
			if resultFindBP.RowsAffected > 0 {
				jobSummary.CompanyName = bp.CompanyName
				jobSummary.FirstName = bp.FirstName
				jobSummary.LastName = bp.LastName
			}
			jobTaskSummary.Status = jobTask.Status
			jobTaskSummary.StatusName, jobTaskSummary.StatusIcon = libs.GetEnum(requestHeader, jobTask.Status, "JobTaskStatus", lang)
			jobTaskSummary.NavigationAddress = jobTask.NavigationAddress
			jobTaskSummary.JobType = jobTask.JobType
			jobTaskSummary.JobTypeName, jobTaskSummary.JobTypeIcon = libs.GetEnum(requestHeader, jobTask.JobType, "JobType", lang)
			jobTaskSummary.AdditionalInformation = jobTask.AdditionalInformation
			jobTaskSummary.ServiceTimeInMinutes = jobTask.ServiceTimeInMinutes
			jobTaskSummary.ContactDetails, jobTaskSummary.ContactPhoneNumber = GetJobContactDetail(jobTask, db)
			jobSummary.JobTask = jobTaskSummary
			scheduleObj.JobSummary = jobSummary
			scheduleObj.AdditionalUsers = make([]models.AdditionalUserResponse, 0)
			arrScheduleObj = append(arrScheduleObj, scheduleObj)
		}
	}
	return arrScheduleObj
}

//func CommitScheduleRecurring(requestHeader models.RequestHeader, lang string, accountKey int, c *gin.Context, objectsJSON []models.JourneyBodyJSON) []models.JourneyBodyJSON {
func CommitScheduleRecurring(requestHeader models.RequestHeader, lang string, accountKey int, c *gin.Context, mapObjects []map[string]interface{}) []models.JourneyBodyJSON {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var objectsJSON = make([]models.JourneyBodyJSON, 0)
	for _, mapObject := range mapObjects {
		var objectJSON models.JourneyBodyJSON
		mapObjectJSON, err := json.Marshal(mapObject)
		if err == nil {
			json.Unmarshal([]byte(string(mapObjectJSON)), &objectJSON)
			if objectJSON.ScheduleID <= 0 {
				scheduleObjPOST := objectJSON
				//create job
				var (
					parentJobModel models.Job
					newJobModel    models.Job
					err            error
				)
				parentJobID := scheduleObjPOST.JobID
				parentJobTaskID := scheduleObjPOST.JobTaskID
				parentJobTaskType := 0
				newJobTaskID := 0
				resultFindParentJob := db.Preload(
					"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where(
					"JobID = ?", parentJobID,
				).Where(
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).First(&parentJobModel)
				if resultFindParentJob.RowsAffected > 0 {
					// need to job Task
					if len(parentJobModel.JobTasks) > 0 {
						newJobModel = parentJobModel
						newJobModel.IsRecurring = false
						newJobModel.JobID = 0
						newJobModel.RecurringJobID = parentJobModel.JobID

						CheckDocumentSequencesBeforeCreate(requestHeader)
						var (
							sequencyModel models.DocumentSequency
							jobNumPrefix  models.Prefix
						)
						ResetDocumentSequencesIfGreaterLength(requestHeader)
						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
						db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
						jobNumberFirstConfig := jobNumPrefix.Prefix
						lenJobNumberConfig := jobNumPrefix.Length
						sqJobNumber := sequencyModel.JobNumber
						newJobModel.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)

						for i := range newJobModel.JobTasks {
							if newJobModel.JobTasks[i].JobTaskID == parentJobTaskID {
								parentJobTaskType = newJobModel.JobTasks[i].JobType
							}
							newJobModel.JobTasks[i].JobID = 0
							newJobModel.JobTasks[i].JobTaskID = 0
							newJobModel.JobTasks[i].CreatedBy = accountKey
							newJobModel.JobTasks[i].ModifiedBy = accountKey
						}
						for i := range newJobModel.JobDetails {
							newJobModel.JobDetails[i].JobID = 0
							newJobModel.JobDetails[i].JobDetailID = 0
							newJobModel.JobDetails[i].CreatedBy = accountKey
							newJobModel.JobDetails[i].ModifiedBy = accountKey
						}
						if newJobModel.JobPickup != nil {
							newJobModel.JobPickup.JobID = 0
							newJobModel.JobPickup.CreatedBy = accountKey
							newJobModel.JobPickup.ModifiedBy = accountKey
						}
						if newJobModel.JobDelivery != nil {
							newJobModel.JobDelivery.JobID = 0
							newJobModel.JobDelivery.JobDeliveryID = 0
							newJobModel.JobDelivery.CreatedBy = accountKey
							newJobModel.JobDelivery.ModifiedBy = accountKey
						}
						if newJobModel.JobOnSite != nil {
							newJobModel.JobOnSite.JobID = 0
							newJobModel.JobOnSite.JobOnSiteID = 0
							newJobModel.JobOnSite.CreatedBy = accountKey
							newJobModel.JobOnSite.ModifiedBy = accountKey
						}
						if newJobModel.JobInStore != nil {
							newJobModel.JobInStore.JobID = 0
							newJobModel.JobInStore.CreatedBy = accountKey
							newJobModel.JobInStore.ModifiedBy = accountKey
						}
						if newJobModel.JobMultiple != nil {
							newJobModel.JobMultiple.JobID = 0
							newJobModel.JobMultiple.JobMultipleID = 0
							newJobModel.JobMultiple.CreatedBy = accountKey
							newJobModel.JobMultiple.ModifiedBy = accountKey
						}
						if newJobModel.JobCombined != nil {
							newJobModel.JobCombined.JobID = 0
							newJobModel.JobCombined.JobCombinedID = 0
							newJobModel.JobCombined.CreatedBy = accountKey
							newJobModel.JobCombined.ModifiedBy = accountKey
						}
						if newJobModel.JobResourcePickUp != nil {
							newJobModel.JobResourcePickUp.JobID = 0
							newJobModel.JobResourcePickUp.JobResourcePickupID = 0
							newJobModel.JobResourcePickUp.CreatedBy = accountKey
							newJobModel.JobResourcePickUp.ModifiedBy = accountKey
						}
						if newJobModel.JobResourceDelivery != nil {
							newJobModel.JobResourceDelivery.JobID = 0
							newJobModel.JobResourceDelivery.JobResourceDeliveryID = 0
							newJobModel.JobResourceDelivery.CreatedBy = accountKey
							newJobModel.JobResourceDelivery.ModifiedBy = accountKey
						}
						if newJobModel.JobMap != nil {
							newJobModel.JobMap.JobID = 0
							newJobModel.JobMap.JobMapID = 0
							newJobModel.JobMap.CreatedBy = accountKey
							newJobModel.JobMap.ModifiedBy = accountKey
						}
						newJobModel.CreatedBy = accountKey
						newJobModel.ModifiedBy = accountKey
						err = db.Create(&newJobModel).Error
						if err == nil {
							IncreaseDocumentSequencesAfterCreateJob(true, false, false, false, requestHeader)
							for i := range newJobModel.JobTasks {
								if newJobModel.JobTasks[i].JobType == parentJobTaskType {
									newJobTaskID = newJobModel.JobTasks[i].JobTaskID
								}
							}
							//create schedule
							if newJobTaskID > 0 {
								var scheduleObj models.Schedule
								if scheduleObjPOST.ScheduleStartDate != nil {
									scheduleObj.ScheduleStartDate = *scheduleObjPOST.ScheduleStartDate
								}
								if scheduleObjPOST.ScheduleEndDate != nil {
									scheduleObj.ScheduleEndDate = *scheduleObjPOST.ScheduleEndDate
								}
								scheduleObj.LocationID = scheduleObjPOST.LocationID
								scheduleObj.ResourceID = scheduleObjPOST.ResourceID
								scheduleObj.UserID = scheduleObjPOST.UserID
								scheduleObj.JobID = newJobModel.JobID
								scheduleObj.JobTaskID = newJobTaskID
								scheduleObj.ScheduleStartDateTimeZone = scheduleObjPOST.ScheduleStartDateTimeZone
								scheduleObj.ScheduleEndDateTimeZone = scheduleObjPOST.ScheduleEndDateTimeZone
								scheduleObj.CreatedBy = accountKey
								scheduleObj.ModifiedBy = accountKey
								err = db.Create(&scheduleObj).Error
								if err == nil {
									// update job status = 1=Scheduled by jobid on schedules table
									UpdateJobStatus(requestHeader, scheduleObj.JobID, 1, accountKey, c)
									// update job status for master job combined
									UpdateJobStatusForMasterJobCombined(requestHeader, scheduleObj.JobID, accountKey)

									// update schedule start date & end date
									var (
										jobTask models.JobTask
									)
									resultFindJobTask := db.Where("JobTaskID = ?", scheduleObj.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
									if resultFindJobTask.RowsAffected > 0 {
										jobTask.ModifiedBy = accountKey
										jobTask.ScheduleStartDateTime = &scheduleObj.ScheduleStartDate
										jobTask.ScheduleEndDateTime = &scheduleObj.ScheduleEndDate
										db.Save(&jobTask)
									}

									// Update additional users
									UpdateAdditionalUser(accountKey, scheduleObj, requestHeader, mapObject)

									objectJSON.ScheduleID = scheduleObj.ScheduleID
									objectJSON.JobID = scheduleObj.JobID
									objectJSON.JobTaskID = scheduleObj.JobTaskID
								}
							}
						}
					}
				}
			}
			objectsJSON = append(objectsJSON, objectJSON)
		}
	}
	return objectsJSON
}

func GetIndexWeekDayInMonth(currentDateTime time.Time) (int, int) {
	var (
		totalIndexWeekDay   int
		currentIndexWeekDay int
	)
	timeLocation := currentDateTime.Location()
	firstOfMonth := time.Date(currentDateTime.Year(), currentDateTime.Month(), 1, 1, 1, 1, 1, timeLocation)
	//fmt.Println("firstOfMonth: ", firstOfMonth)
	lastOfMonth := firstOfMonth.AddDate(0, 1, -1)
	//fmt.Println("lastOfMonth: ", lastOfMonth)
	weekDayCurrentOfMonth := currentDateTime.Weekday().String()
	shortWeekDayCurrentOfMonth := GetShortWeekDay(weekDayCurrentOfMonth)
	shortWeekDayCurrentOfMonth = strings.ToLower(shortWeekDayCurrentOfMonth)
	for {
		if firstOfMonth.Unix() > lastOfMonth.Unix() {
			break
		}
		weekDayFirstOfMonth := firstOfMonth.Weekday().String()
		shortWeekDayFirstOfMonth := GetShortWeekDay(weekDayFirstOfMonth)
		shortWeekDayFirstOfMonth = strings.ToLower(shortWeekDayFirstOfMonth)
		if shortWeekDayFirstOfMonth == shortWeekDayCurrentOfMonth {
			totalIndexWeekDay++
			if currentDateTime.Day() == firstOfMonth.Day() {
				currentIndexWeekDay = totalIndexWeekDay
			}
		}
		firstOfMonth = firstOfMonth.AddDate(0, 0, 1)
	}
	return totalIndexWeekDay, currentIndexWeekDay
}

// CreateSkipRecurring godoc
// @Summary Create Skip Recurring
// @Description Create Skip Recurring
// @Tags Recurring
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param RecurringSkipPOST body []models.RecurringSkipPOST true "Create Skip Recurring"
// @Success 200 {object} models.APIResponseData
// @Router /skiprecurring/{jobid} [post]
func CreateSkipRecurring(c *gin.Context) {
	defer libs.RecoverError(c, "CreateSkipRecurring")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		data, errors   interface{}
		errorsResponse []models.ErrorResponse
		msg            string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	jobID, _ := strconv.Atoi(c.Param("jobid"))

	var (
		recurringSkipPOST models.RecurringSkipPOST
		dSkipFromDate     time.Time
		dSkipToDate       time.Time
		validateMsgError  string
	)
	json.NewDecoder(c.Request.Body).Decode(&recurringSkipPOST)
	if recurringSkipPOST.FromDate != "" {
		vdSkipFromDate, errSkipDate := libs.ConvertStringToDateTime(recurringSkipPOST.FromDate)
		if errSkipDate == nil {
			dSkipFromDate = vdSkipFromDate
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		}
	} else {
		status = 422
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}
	if recurringSkipPOST.ToDate != "" {
		vdSkipToDate, errSkipDate := libs.ConvertStringToDateTime(recurringSkipPOST.ToDate)
		if errSkipDate == nil {
			dSkipToDate = vdSkipToDate
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
		}
	} else {
		status = 422
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
	}

	if status == 200 {
		var (
			recurringJobModel models.RecurringJob
			job               models.Job
		)
		db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1").First(&job)
		resultFindRecurringJob := db.Where("JobID = ?", job.RecurringJobID).Where("IFNULL(IsDeleted, 0) <> 1").First(&recurringJobModel)
		var recurringSkip models.RecurringSkip
		if resultFindRecurringJob.RowsAffected > 0 {
			recurringSkip.RecurringJobID = recurringJobModel.RecurringJobID
		}
		recurringSkip.SkipFromDate = dSkipFromDate
		recurringSkip.SkipToDate = dSkipToDate
		recurringSkip.CreatedBy = accountKey
		recurringSkip.ModifiedBy = accountKey
		resultCreate := db.Create(&recurringSkip)
		if resultCreate.Error == nil {
			var recurringSkipResponse models.RecurringSkipResponse
			recurringSkipResponse.RecurringSkipID = recurringSkip.RecurringSkipID
			recurringSkipResponse.RecurringJobID = recurringSkip.RecurringJobID
			recurringSkipResponse.SkipFromDate = recurringSkip.SkipFromDate
			recurringSkipResponse.SkipToDate = recurringSkip.SkipToDate
			data = recurringSkipResponse
			msg = services.GetMessage(lang, "api.success")
			// delete schedules & jobs
			if recurringJobModel.RecurringJobID > 0 {
				var jobChilds []models.Job
				arrChildsJobID := make([]int, 0)
				resourceID := recurringJobModel.ResourceID
				db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1").Find(&jobChilds)
				for _, jobChild := range jobChilds {
					arrChildsJobID = append(arrChildsJobID, jobChild.JobID)
				}
				if len(jobChilds) > 0 {
					// delete jobs
					db.Exec(`DELETE FROM `+models.Job{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobDetail{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobTask{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobPickup{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobDelivery{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobOnSite{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobInStore{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobMultiple{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobCombined{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobResourcePickup{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobResourceDelivery{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)
					db.Exec(`DELETE FROM `+models.JobSelection{}.TableName()+` WHERE JobID in (?)`, arrChildsJobID)

					// delete schedule
					var (
						scheduleDeleteModels []models.Schedule
						arrScheduleDeleteID  = make([]int, 0)
					)
					db.Where(
						"JobID in (?) AND ResourceID = ?", arrChildsJobID, resourceID,
					).Where(
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsReschedule, 0) <> 1",
					).Find(&scheduleDeleteModels)
					for _, scheduleDeleteModel := range scheduleDeleteModels {
						arrScheduleDeleteID = append(arrScheduleDeleteID, scheduleDeleteModel.ScheduleID)
					}
					if len(arrScheduleDeleteID) > 0 {
						db.Exec(`DELETE FROM `+models.Schedule{}.TableName()+` WHERE ScheduleID in (?)`, arrScheduleDeleteID)
					}
				}
			}
		} else {
			status = 500
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, resultCreate.Error.Error())
		}
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	if status == 200 {
		if msg == "" {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}
