package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetEmailTemplate godoc
// @Summary Get EmailTemplate
// @Description Get EmailTemplate
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /emailtemplate [get]
func GetEmailTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "GetEmailTemplate")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.EmailTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	arrString := []string{"Name"}
	bp = libs.FilterString(arrString, bp, c)
	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayEmailTemplateToArrayResponse(resModels, lang, requestHeader)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetEmailTemplateByID godoc
// @Summary Get EmailTemplate By ID
// @Description Get EmailTemplate  By ID
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param id path int true "EmailTemplate ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /emailtemplate/{id} [get]
func GetEmailTemplateByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetEmailTemplateByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.EmailTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IsDeleted = 0 AND EmailTemplateID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertEmailTemplateToResponse(resModel, lang, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)

	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateEmailTemplate godoc
// @Summary Create EmailTemplate
// @Description Create EmailTemplate
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param EmailTemplate body []models.EmailTemplateResponse true "Create EmailTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /emailtemplate [post]
func CreateEmailTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "CreateEmailTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.EmailTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	var (
		resModel models.EmailTemplate
	)
	resModel.PassBodyJSONToModel(objectsJSON)

	resultFindItemGroupCode := db.Where("Name = ? AND IsDeleted = 0", resModel.Name).First(&models.EmailTemplate{})
	if resultFindItemGroupCode.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.EmailTemplatename_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resModel.CreatedBy = accountKey
		resModel.ModifiedBy = accountKey
		resultFind := db.Where("EmailTemplateID = ?", resModel.EmailTemplateID).First(&resModel)
		resModel.PassBodyJSONToModel(objectsJSON)
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			if resultFind.RowsAffected > 0 {
				db.Save(&resModel)
			} else {
				db.Create(&resModel)
			}
			totalUpdatedRecord++
			dataResponse = resModel
		}
		var (
			resModels models.EmailTemplate
		)

		db.Where("EmailTemplateID in (?)", dataResponse.EmailTemplateID).Find(&resModels)
		data = ConvertEmailTemplateToResponse(resModels, lang, requestHeader)
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateEmailTemplate godoc
// @Summary Update EmailTemplate
// @Description Update EmailTemplate
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param EmailTemplate body []models.EmailTemplateResponse true "Update EmailTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /emailtemplate/{id} [put]
func UpdateEmailTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateEmailTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.EmailTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		resModel models.EmailTemplate
	)
	resModel.PassBodyJSONToModel(objectsJSON)

	resultFindItemGroupCode := db.Where("Name = ? AND IsDeleted = 0  AND EmailTemplateID <> ?", resModel.Name, ID).First(&models.EmailTemplate{})
	if resultFindItemGroupCode.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.EmailTemplatename_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resultFind := db.Where("EmailTemplateID = ?", ID).First(&resModel)
		resModel.PassBodyJSONToModel(objectsJSON)
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			if resultFind.RowsAffected > 0 {
				db.Save(&resModel)
			} else {
				db.Create(&resModel)
			}
			totalUpdatedRecord++
			dataResponse = resModel

			var (
				resModels models.EmailTemplate
			)
			db.Where("EmailTemplateID in (?)", dataResponse.EmailTemplateID).Find(&resModels)
			data = ConvertEmailTemplateToResponse(resModels, lang, requestHeader)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteEmailTemplate godoc
// @Summary Delete EmailTemplate
// @Description Delete EmailTemplate
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "EmailTemplate ID"
// @Success 200 {object} models.APIResponseData
// @Router /emailtemplate/{id} [delete]
func DeleteEmailTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteEmailTemplate")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.EmailTemplate
		)
		resultFind := db.Where("EmailTemplateID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// CheckVariableTemplate godoc
// @Summary CheckVariableTemplate
// @Description CheckVariableTemplate
// @Tags EmailTemplate
// @Accept  json
// @Produce  json
// @Param TemplateID query int true "TemplateID"
// @Param Type query string true "Type - sms/email"
// @Param DataField query string true "DataField"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkvariabletemplate [get]
func CheckVariableTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "CheckVariableTemplate")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		msg, data     interface{}
		response      models.APIResponseData
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var (
		templateID       int
		templateType     string
		dataField        string
		validateMsgError string
	)
	vTemplateID, sTemplateID := libs.GetQueryParam("TemplateID", c)
	if sTemplateID {
		iTemplateID, eTemplateID := strconv.Atoi(vTemplateID)
		if eTemplateID == nil {
			templateID = iTemplateID
		} else {
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.param_invalid", "TemplateID"))
			status = 422
		}
	} else {
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.param_required", "TemplateID"))
		status = 422
	}
	vType, sType := libs.GetQueryParam("Type", c)
	if !sType {
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.param_required", "Type"))
		status = 422
	} else {
		templateType = vType
	}
	vDataField, sDataField := libs.GetQueryParam("DataField", c)
	if !sDataField {
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.param_required", "DataField"))
		status = 422
	} else {
		dataField = vDataField
	}

	if status == 200 {
		switch templateType {
		case "email":
			{
				var (
					resModel models.EmailTemplate
				)
				resultFind := db.Where("EmailTemplateID = ?", templateID).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
				if resultFind.RowsAffected > 0 {
					var dataResponse = make(map[string]bool)
					if strings.Contains(strings.ToLower(resModel.Body), "%%"+strings.ToLower(dataField)+"%%") {
						dataResponse["HasDataField"] = true
					} else {
						dataResponse["HasDataField"] = false
					}
					msg = services.GetMessage(lang, "api.success")
					data = dataResponse
				} else {
					msg = services.GetMessage(lang, "api.no_record_found")
					status = libs.GetStatusNotFound()
					errResponse := GetErrorResponseNotFound(lang, 0)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		case "sms":
			{
				var (
					resModel models.SMSTemplate
				)
				resultFind := db.Where("SMSTemplateID = ?", templateID).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
				if resultFind.RowsAffected > 0 {
					var dataResponse = make(map[string]bool)
					if strings.Contains(strings.ToLower(resModel.Body), "%%"+strings.ToLower(dataField)+"%%") {
						dataResponse["HasDataField"] = true
					} else {
						dataResponse["HasDataField"] = false
					}
					msg = services.GetMessage(lang, "api.success")
					data = dataResponse
				} else {
					msg = services.GetMessage(lang, "api.no_record_found")
					status = libs.GetStatusNotFound()
					errResponse := GetErrorResponseNotFound(lang, 0)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		default:
			{
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.param_invalid", "Type"))
				status = 422
			}
		}
	}

	if validateMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, validateMsgError)
		errorsResponse = append(errorsResponse, errResponse)
		msg = validateMsgError
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayEmailTemplateToArrayResponse func
func ConvertArrayEmailTemplateToArrayResponse(items []models.EmailTemplate, lang string, requestHeader models.RequestHeader) []models.EmailTemplateResponse {
	responses := make([]models.EmailTemplateResponse, 0)
	for _, item := range items {
		response := ConvertEmailTemplateToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertEmailTemplateToResponse func
func ConvertEmailTemplateToResponse(item models.EmailTemplate, lang string, requestHeader models.RequestHeader) models.EmailTemplateResponse {
	var (
		response models.EmailTemplateResponse
		enum     models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.EmailTemplateID = item.EmailTemplateID
	response.Name = item.Name
	response.Body = item.Body
	response.Subject = item.Subject
	response.TemplateVariableKey = item.TemplateVariableKey
	db.Where("FieldName = ? AND Status = ?", "EmailTemplateVariableKey", item.TemplateVariableKey).First(&enum)
	if enum.TranslationKey != "" && enum.TranslationKey != services.GetMessage(lang, enum.TranslationKey) {
		response.TemplateVariableKeyName = services.GetMessage(lang, enum.TranslationKey)
	} else {
		response.TemplateVariableKeyName = enum.Caption
	}
	return response
}
