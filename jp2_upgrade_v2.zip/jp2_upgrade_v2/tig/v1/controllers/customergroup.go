package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetCustomerGroup godoc
// @Summary Get CustomerGroup
// @Description Get CustomerGroup
// @Tags CustomerGroup
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /customergroup [get]
func GetCustomerGroup(c *gin.Context) {
	defer libs.RecoverError(c, "GetCustomerGroup")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.CustomerGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)

	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	arrString := []string{"CustomerGroupName"}
	bp = libs.FilterString(arrString, bp, c)
	vPriceListName, sPriceListName := libs.GetQueryParam("PriceListName", c)
	if sPriceListName {
		dbPriceList := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		var (
			priceList []models.PriceList
		)
		arrPriceListID := make([]int, 0)
		dbPriceList.Where("PriceListName like ?", "%"+vPriceListName+"%").Find(&priceList)
		for _, p := range priceList {
			arrPriceListID = append(arrPriceListID, p.PriceListID)
		}
		bp = bp.Where("PriceLisID in (?)", arrPriceListID)
	}
	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayCustomerGroupToArrayResponse(resModels, lang, requestHeader)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetCustomerGroupByID godoc
// @Summary Get CustomerGroup By ID
// @Description Get CustomerGroup  By ID
// @Tags CustomerGroup
// @Accept  json
// @Produce  json
// @Param id path int true "CustomerGroup ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /customergroup/{id} [get]
func GetCustomerGroupByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetCustomerGroupByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.CustomerGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("CustomerGroupID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertCustomerGroupToResponse(resModel, lang, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)

	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateCustomerGroup godoc
// @Summary Create CustomerGroup
// @Description Create CustomerGroup
// @Tags CustomerGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param CustomerGroup body []models.CustomerGroupResponse true "Create CustomerGroup"
// @Success 200 {object} models.APIResponseData
// @Router /customergroup [post]
func CreateCustomerGroup(c *gin.Context) {
	defer libs.RecoverError(c, "CreateCustomerGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.CustomerGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.CustomerGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.CustomerGroup
			)
			resModel.PassBodyJSONToModel(bp)
			resModel.CreatedBy = accountKey
			resModel.ModifiedBy = accountKey
			resultFind := db.Where("CustomerGroupID = ?", resModel.CustomerGroupID).First(&resModel)
			resModel.PassBodyJSONToModel(bp)
			//resModel.CreatedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resModel)
				} else {
					db.Create(&resModel)
				}
				// @TODO add or update translation table
				ProcessTranslationForObject(requestHeader, models.CustomerGroup{}.TableName(), resModel.CustomerGroupID, accountKey, bp)
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.CustomerGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.CustomerGroupID)
	}
	if len(arrID) > 0 {
		db.Where("CustomerGroupID in (?)", arrID).Find(&resModels)
		data = ConvertArrayCustomerGroupToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateCustomerGroup godoc
// @Summary Update CustomerGroup
// @Description Update CustomerGroup
// @Tags CustomerGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param CustomerGroup body []models.CustomerGroupResponse true "Update CustomerGroup"
// @Success 200 {object} models.APIResponseData
// @Router /customergroup [put]
func UpdateCustomerGroup(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateCustomerGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.CustomerGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.CustomerGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.CustomerGroup
			)
			resModel.PassBodyJSONToModel(bp)
			resultFind := db.Where("CustomerGroupID = ?", resModel.CustomerGroupID).First(&resModel)
			resModel.PassBodyJSONToModel(bp)
			//resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resModel)
				} else {
					db.Create(&resModel)
				}
				// @TODO add or update translation table
				ProcessTranslationForObject(requestHeader, models.CustomerGroup{}.TableName(), resModel.CustomerGroupID, accountKey, bp)
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.CustomerGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.CustomerGroupID)
	}
	if len(arrID) > 0 {
		db.Where("CustomerGroupID in (?)", arrID).Find(&resModels)
		data = ConvertArrayCustomerGroupToArrayResponse(resModels, lang, requestHeader)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteCustomerGroup godoc
// @Summary Delete CustomerGroup
// @Description Delete CustomerGroup
// @Tags CustomerGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "CustomerGroup ID"
// @Success 200 {object} models.APIResponseData
// @Router /customergroup/{id} [delete]
func DeleteCustomerGroup(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteCustomerGroup")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.CustomerGroup
		)
		resultFind := db.Where("CustomerGroupID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := uModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				uModel.IsDeleted = true
				uModel.ModifiedBy = accountKey
				deletedResult := db.Save(&uModel)
				//deletedResult := db.Delete(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					//@TODO delete translation table
					DeleteTranslationOnObject(requestHeader, models.CustomerGroup{}.TableName(), uModel.CustomerGroupID)
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayCustomerGroupToArrayResponse func
func ConvertArrayCustomerGroupToArrayResponse(items []models.CustomerGroup, lang string, requestHeader models.RequestHeader) []models.CustomerGroupResponse {
	responses := make([]models.CustomerGroupResponse, 0)
	for _, item := range items {
		response := ConvertCustomerGroupToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertCustomerGroupToResponse func
func ConvertCustomerGroupToResponse(item models.CustomerGroup, lang string, requestHeader models.RequestHeader) models.CustomerGroupResponse {
	var (
		response models.CustomerGroupResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.CustomerGroupID = item.CustomerGroupID
	response.CustomerGroupName = item.CustomerGroupName
	response.PriceListID = item.PriceListID
	if item.PriceListID != nil {
		priceListID := *item.PriceListID
		var priceListModel models.PriceList
		resultFindPriceList := db.Where("PriceListID = ?", priceListID).First(&priceListModel)
		if resultFindPriceList.RowsAffected > 0 {
			response.PriceListName = &priceListModel.PriceListName
		}
	}
	var (
		translationResponses []models.TranslationResponse
	)
	translationResponses = make([]models.TranslationResponse, 0)
	translationResponses = GetTranslationResponse(requestHeader, models.CustomerGroup{}.TableName(), item.CustomerGroupID)
	response.Translations = translationResponses
	return response
}
