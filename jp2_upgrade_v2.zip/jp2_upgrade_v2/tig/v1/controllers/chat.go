package controllers

import (
	"encoding/json"
	"fmt"
	redisdynamic "jpapi/tig/v1/databases/drivers/redisdynamic"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/aws/aws-sdk-go/service/dynamodb/expression"
	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"gorm.io/gorm"
)

// GetChatContact func
func GetChatContact(c *gin.Context) {
	defer libs.RecoverError(c, "GetChatContact")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	//var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND AccountKey <> ?", accountKey)
	// Filter
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayChatUserToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetChat godoc
// @Summary GetChat
// @Description GetChat
// @Tags System
// @Accept  json
// @Produce  json
// @Param from query string false "from"
// @Param to query string false "to"
// @Param fromdate query string false "fromdate"
// @Param todate query string false "todate"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getchat [get]
func GetChat_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetChat")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
		totalCount     = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// get dynamic connection
		conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseChat)
		arrKeys := make([]string, 0)
		arrDateKey := make([]string, 0)
		arrPatternKey := make([]string, 0)
		arrJPObjectsPaging := make([]models.ChatHistoryResponse, 0)

		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		pattern := "tb|cha*"

		vToID, sToID := libs.GetQueryParam("To", c)
		if sToID {
			pattern = pattern + "to|" + vToID + "|*"
		}

		vFromID, sFromID := libs.GetQueryParam("From", c)
		if sFromID && sToID {
			pattern = pattern + "fr|" + vFromID + "|*"
		} else if sFromID && !sToID {
			pattern = pattern + "|fr|" + vFromID + "|*"
		}

		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			}
		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			}
		}
		if fromDate != nil && toDate == nil {
			toDate = &timeNow
		}
		if toDate != nil && fromDate == nil {
			fromDate = &timeNow
		}

		if fromDate != nil && toDate != nil {
			dFromDate := *fromDate
			fromDateUnix := dFromDate.Unix()
			dToDate := *toDate
			toDateUnix := dToDate.Unix()
			if fromDateUnix > toDateUnix {
				temp := dFromDate
				dFromDate = dToDate
				dToDate = temp
			}
			dToDate, _ = libs.ConvertStringToDateTime(dToDate.Format("2006-01-02"))
			i := 0
			for {
				newDate := dFromDate.AddDate(0, 0, i)
				newDate, _ = libs.ConvertStringToDateTime(newDate.Format("2006-01-02"))
				if newDate.Unix() > dToDate.Unix() {
					break
				}
				arrDateKey = append(arrDateKey, newDate.Format("20060102"))
				i++
			}
		}
		if len(arrDateKey) > 0 {
			for _, k := range arrDateKey {
				newPatternKey := ``
				newPatternKey = pattern + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey)
			}
		} else {
			newPatternKey := pattern
			arrPatternKey = append(arrPatternKey, newPatternKey)
		}
		fmt.Println("arrPatternKey: ", arrPatternKey)
		fmt.Println("time.Now:     find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		lenArrayPattern := len(arrPatternKey)
		cResponseGetRedisKey := make(chan models.CronJobResponseRedisKey, lenArrayPattern)
		for _, pattern := range arrPatternKey {
			go func(cResponseGetRedisKey chan models.CronJobResponseRedisKey, connn *redis.Client, pattern string) {
				var responseGetRedisKey models.CronJobResponseRedisKey
				resRedis := connn.Do(redisdynamic.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						var arrSearchKeys = make([]string, 0)
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrSearchKeys = append(arrSearchKeys, key)
							}
						}
						responseGetRedisKey.Keys = arrSearchKeys
						responseGetRedisKey.Status = 200
					}
				} else {
					responseGetRedisKey.Status = 500
					responseGetRedisKey.Message = resRedis.Err().Error()
				}
				cResponseGetRedisKey <- responseGetRedisKey
			}(cResponseGetRedisKey, conn, pattern)
		}
		for range arrPatternKey {
			objectKey := <-cResponseGetRedisKey
			if objectKey.Status == 200 {
				if len(objectKey.Keys) > 0 {
					arrKeys = append(arrKeys, objectKey.Keys...)
				}
			} else if objectKey.Status == 500 {
				status = objectKey.Status
				msg = objectKey.Message
			}
		}
		fmt.Println("time.Now: End find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now     find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			if len(arrKeys) > 0 {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				lenArrayKey := len(arrKeys)
				cResponseGetRedisData := make(chan models.CronJobResponseRedisData, lenArrayKey)
				for i, key := range arrKeys {
					if i > 0 && i%1000 == 0 {
						//time.Sleep(50 * time.Millisecond)
						//fmt.Println("i: ", i)
					}
					go func(cResponseGetRedisData chan models.CronJobResponseRedisData, conn *redis.Client, key string) {
						var responseGetRedisData models.CronJobResponseRedisData
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.ChatHistoryRedis
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								jbObject := ConvertMessageRedisToJP(redisObject)
								responseGetRedisData.Data = jbObject
								responseGetRedisData.Status = 200
								responseGetRedisData.Message = services.GetMessage(lang, "api.success")
							} else {
								responseGetRedisData.Status = 500
								responseGetRedisData.Message = errJSON.Error()
							}
						} else {
							responseGetRedisData.Status = statusSub
							responseGetRedisData.Message = errSub.Error()
						}
						cResponseGetRedisData <- responseGetRedisData
					}(cResponseGetRedisData, conn, key)
				}
				for range arrKeys {
					object := <-cResponseGetRedisData
					if object.Status == 200 {
						arrJPObjects = append(arrJPObjects, object.Data)
					} else {
						status = object.Status
						msg = object.Message
					}
				}
				if status == 200 {
					fmt.Println("time.Now     calculate time: ", time.Now().Format("2006-01-02 15:04:05.000"))
					if len(arrJPObjects) > 0 {
						totalCount = len(arrJPObjects)
						sort.Slice(arrJPObjects, func(i, j int) bool {
							if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
								timeI := *arrJPObjects[i].DateTime
								timeJ := *arrJPObjects[j].DateTime
								// min-max
								//return timeI.Before(timeJ)
								// max-min
								return timeI.After(timeJ)
							} else if arrJPObjects[i].DateTime != nil {
								return true
							}
							return false
						})
						for i := 0; i < pagingLength; i++ {
							//position := (pagingStart-1)*pagingLength + i
							// no need because minus above
							//position := (pagingStart)*pagingLength + i
							// @TODO currently, get by position not paging
							position := (pagingStart) + i
							if position < len(arrJPObjects) {
								arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjects[position])
							}
						}
					}
					// get user info
					if len(arrJPObjectsPaging) > 0 {
						fmt.Println("time.Now     find user info: ", time.Now().Format("2006-01-02 15:04:05.000"))
						for i, objectsPaging := range arrJPObjectsPaging {
							arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
						}
						fmt.Println("time.Now end find user info: ", time.Now().Format("2006-01-02 15:04:05.000"))
					}
				}
			}
		}
		fmt.Println("time.Now end find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			data = arrJPObjectsPaging
			if msg == nil {
				msg = services.GetMessage(lang, "api.success")
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

func GetChat(c *gin.Context) {
	defer libs.RecoverError(c, "GetChat")
	var (
		status             = libs.GetStatusSuccess()
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		msg, data          interface{}
		totalCount         = 0
		validateMsgError   string
		arrJPObjectsPaging = make([]models.ChatHistoryResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			}
		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			}
		}
		if fromDate != nil && toDate == nil {
			toDate = &timeNow
		}
		if toDate != nil && fromDate == nil {
			fromDate = &timeNow
		}

		if fromDate != nil && toDate != nil {
			dynamoTable := dynamoConfig.DatabaseNameChat
			sess, err := session.NewSession(&aws.Config{
				Region: aws.String(dynamoConfig.Region),
				Credentials: credentials.NewStaticCredentials(
					dynamoConfig.AccessKeyID,
					dynamoConfig.SecretAccessKey,
					"",
				),
			})
			if err == nil {
				svc := dynamodb.New(sess)
				hasFilter := false

				expressionNewBuilder := expression.NewBuilder()

				filterDataFormat := "20060102"
				prefixFromNumber := "000000000"
				prefixToNumber := "999999999"

				dFromDate := *fromDate
				sFromDate := dFromDate.Format(filterDataFormat)
				sFromDate = sFromDate + prefixFromNumber
				nFromDate, _ := strconv.Atoi(sFromDate)

				dToDate := *toDate
				sToDate := dToDate.Format(filterDataFormat)
				sToDate = sToDate + prefixToNumber
				nToDate, _ := strconv.Atoi(sToDate)

				filter := expression.And(
					expression.Name("datetime").GreaterThanEqual(expression.Value(nFromDate)),
					expression.Name("datetime").LessThanEqual(expression.Value(nToDate)),
				)

				vToID, sToID := libs.GetQueryParam("To", c)
				if sToID {
					iToID, _ := strconv.Atoi(vToID)
					filter = filter.And(expression.Name("to").Equal(expression.Value(iToID)))
					hasFilter = true
				}

				vFromID, sFromID := libs.GetQueryParam("From", c)
				if sFromID {
					iFromID, _ := strconv.Atoi(vFromID)
					filter = filter.And(expression.Name("from").Equal(expression.Value(iFromID)))
					hasFilter = true
				}

				expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
				hasFilter = true

				var params dynamodb.ScanInput
				if hasFilter {
					expr, err := expressionNewBuilder.Build()
					if err == nil {
						params = dynamodb.ScanInput{
							ExpressionAttributeNames:  expr.Names(),
							ExpressionAttributeValues: expr.Values(),
							FilterExpression:          expr.Filter(),
							ProjectionExpression:      expr.Projection(),
							TableName:                 aws.String(dynamoTable),
						}
					}
				} else {
					params = dynamodb.ScanInput{
						TableName: aws.String(dynamoTable),
					}
				}
				libs.PrintJSON(params)
				result, err := svc.Scan(&params)
				if err == nil {
					arrJPObjects := make([]models.ChatHistoryResponse, 0)
					for _, i := range result.Items {
						var item models.ChatHistoryRedis
						errItem := dynamodbattribute.UnmarshalMap(i, &item)
						if errItem == nil {
							jbObject := ConvertMessageRedisToJP(item)
							arrJPObjects = append(arrJPObjects, jbObject)
						}
					}
					if len(arrJPObjects) > 0 {
						totalCount = len(arrJPObjects)
						sort.Slice(arrJPObjects, func(i, j int) bool {
							if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
								timeI := *arrJPObjects[i].DateTime
								timeJ := *arrJPObjects[j].DateTime
								// min-max
								//return timeI.Before(timeJ)
								// max-min
								return timeI.After(timeJ)
							} else if arrJPObjects[i].DateTime != nil {
								return true
							}
							return false
						})
						for i := 0; i < pagingLength; i++ {
							//position := (pagingStart-1)*pagingLength + i
							// no need because minus above
							//position := (pagingStart)*pagingLength + i
							// @TODO currently, get by position not paging
							position := (pagingStart) + i
							if position < len(arrJPObjects) {
								arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjects[position])
							}
						}
					}
					// get user info
					if len(arrJPObjectsPaging) > 0 {
						fmt.Println("time.Now     find user info: ", time.Now().Format("2006-01-02 15:04:05.000"))
						for i, objectsPaging := range arrJPObjectsPaging {
							arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
						}
						fmt.Println("time.Now end find user info: ", time.Now().Format("2006-01-02 15:04:05.000"))
					}
					data = arrJPObjectsPaging
				} else {
					status = 500
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
				}
			} else {
				status = 500
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
			}
		}
	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetChatHistory godoc
// @Summary Get Chat History
// @Description Get Chat History
// @Tags System
// @Accept  json
// @Produce  json
// @Param AccountKey query int true "AccountKey"
// @Param HistoryDays query int false "HistoryDays"
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getchathistory [get]
func GetChatHistory_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetChatHistory")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
		totalCount     = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// get dynamic connection
		conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseChat)
		arrJPObjectsPaging := make([]models.ChatHistoryResponse, 0)
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		arrKeys := make([]string, 0)
		arrDateKey := make([]string, 0)
		arrPatternKey := make([]string, 0)
		pattern := "tb|cha*"
		fromID := accountKey
		toID := 0
		historyDays := 10
		vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
		if sHistoryDays {
			historyDays, _ = strconv.Atoi(vHistoryDays)
		}
		vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
		if sAccountKey {
			toID, _ = strconv.Atoi(vAccountKey)
		}
		pattern1 := pattern + "to|" + strconv.Itoa(toID) + "|fr|" + strconv.Itoa(fromID) + "|*"
		pattern2 := pattern + "to|" + strconv.Itoa(fromID) + "|fr|" + strconv.Itoa(toID) + "|*"
		timeNow := time.Now()
		for i := 0; i < historyDays; i++ {
			newDate := timeNow.AddDate(0, 0, -(i))
			arrDateKey = append(arrDateKey, newDate.Format("20060102"))
		}
		if len(arrDateKey) > 0 {
			for _, k := range arrDateKey {
				newPatternKey1 := ``
				newPatternKey1 = pattern1 + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey1)
				newPatternKey2 := ``
				newPatternKey2 = pattern2 + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey2)
			}
		} else {
			newPatternKey1 := pattern1
			arrPatternKey = append(arrPatternKey, newPatternKey1)
			newPatternKey2 := pattern2
			arrPatternKey = append(arrPatternKey, newPatternKey2)
		}
		fmt.Println("time.Now: find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		lenArrayPattern := len(arrPatternKey)
		cResponseGetRedisKey := make(chan models.CronJobResponseRedisKey, lenArrayPattern)
		for _, pattern := range arrPatternKey {
			go func(cResponseGetRedisKey chan models.CronJobResponseRedisKey, connn *redis.Client, pattern string) {
				var responseGetRedisKey models.CronJobResponseRedisKey
				resRedis := connn.Do(redisdynamic.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						var arrSearchKeys = make([]string, 0)
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrSearchKeys = append(arrSearchKeys, key)
							}
						}
						responseGetRedisKey.Keys = arrSearchKeys
						responseGetRedisKey.Status = 200
					}
				} else {
					responseGetRedisKey.Status = 500
					responseGetRedisKey.Message = resRedis.Err().Error()
				}
				cResponseGetRedisKey <- responseGetRedisKey
			}(cResponseGetRedisKey, conn, pattern)
		}
		for range arrPatternKey {
			objectKey := <-cResponseGetRedisKey
			if objectKey.Status == 200 {
				if len(objectKey.Keys) > 0 {
					arrKeys = append(arrKeys, objectKey.Keys...)
				}
			} else if objectKey.Status == 500 {
				status = objectKey.Status
				msg = objectKey.Message
			}
		}
		fmt.Println("time.Now: End find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			if len(arrKeys) > 0 {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				lenArrayKey := len(arrKeys)
				cResponseGetRedisData := make(chan models.CronJobResponseRedisData, lenArrayKey)
				for _, key := range arrKeys {
					go func(cResponseGetRedisData chan models.CronJobResponseRedisData, conn *redis.Client, key string) {
						var responseGetRedisData models.CronJobResponseRedisData
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.ChatHistoryRedis
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								jbObject := ConvertMessageRedisToJP(redisObject)
								responseGetRedisData.Data = jbObject
								responseGetRedisData.Status = 200
								responseGetRedisData.Message = services.GetMessage(lang, "api.success")
							} else {
								responseGetRedisData.Status = 500
								responseGetRedisData.Message = errJSON.Error()
							}
						} else {
							responseGetRedisData.Status = statusSub
							responseGetRedisData.Message = errSub.Error()
						}
						cResponseGetRedisData <- responseGetRedisData
					}(cResponseGetRedisData, conn, key)
				}
				for range arrKeys {
					object := <-cResponseGetRedisData
					if object.Status == 200 {
						arrJPObjects = append(arrJPObjects, object.Data)
					} else {
						status = object.Status
						msg = object.Message
					}
				}
				if status == 200 {
					if len(arrJPObjects) > 0 {
						totalCount = len(arrJPObjects)
						sort.Slice(arrJPObjects, func(i, j int) bool {
							if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
								timeI := *arrJPObjects[i].DateTime
								timeJ := *arrJPObjects[j].DateTime
								// min-max
								//return timeI.Before(timeJ)
								// max-min
								return timeI.After(timeJ)
							} else if arrJPObjects[i].DateTime != nil {
								return true
							}
							return false
						})
						for i := 0; i < pagingLength; i++ {
							//position := (pagingStart-1)*pagingLength + i
							// no need because minus above
							//position := (pagingStart)*pagingLength + i
							// @TODO currently, get by position not paging
							position := (pagingStart) + i
							if position < len(arrJPObjects) {
								arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjects[position])
							}
						}
					}
					// get user info
					if len(arrJPObjectsPaging) > 0 {
						for i, objectsPaging := range arrJPObjectsPaging {
							arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
						}
						// sort min - max
						sort.Slice(arrJPObjectsPaging, func(i, j int) bool {
							if arrJPObjectsPaging[i].DateTime != nil && arrJPObjectsPaging[j].DateTime != nil {
								timeI := *arrJPObjectsPaging[i].DateTime
								timeJ := *arrJPObjectsPaging[j].DateTime
								// min-max
								return timeI.Before(timeJ)
								// max-min
								//return timeI.After(timeJ)
							} else if arrJPObjectsPaging[i].DateTime != nil {
								return true
							}
							return false
						})
					}
				}
			}
		}
		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now: End: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			data = arrJPObjectsPaging
			if msg == nil {
				msg = services.GetMessage(lang, "api.success")
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

func GetChatHistory(c *gin.Context) {
	defer libs.RecoverError(c, "GetChatHistory")
	var (
		status             = libs.GetStatusSuccess()
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		msg, data          interface{}
		totalCount         = 0
		validateMsgError   string
		arrJPObjectsPaging = make([]models.ChatHistoryResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		dynamoTable := dynamoConfig.DatabaseNameChat
		sess, err := session.NewSession(&aws.Config{
			Region: aws.String(dynamoConfig.Region),
			Credentials: credentials.NewStaticCredentials(
				dynamoConfig.AccessKeyID,
				dynamoConfig.SecretAccessKey,
				"",
			),
		})
		if err == nil {
			svc := dynamodb.New(sess)
			hasFilter := false

			expressionNewBuilder := expression.NewBuilder()

			filterDataFormat := "20060102"
			prefixFromNumber := "000000000"
			prefixToNumber := "999999999"

			historyDays := 10
			vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
			if sHistoryDays {
				historyDays, _ = strconv.Atoi(vHistoryDays)
			}

			timeNow := time.Now()

			dFromDate := timeNow.AddDate(0, 0, -(historyDays))
			sFromDate := dFromDate.Format(filterDataFormat)
			sFromDate = sFromDate + prefixFromNumber
			nFromDate, _ := strconv.Atoi(sFromDate)

			dToDate := timeNow
			sToDate := dToDate.Format(filterDataFormat)
			sToDate = sToDate + prefixToNumber
			nToDate, _ := strconv.Atoi(sToDate)

			filter := expression.And(
				expression.Name("datetime").GreaterThanEqual(expression.Value(nFromDate)),
				expression.Name("datetime").LessThanEqual(expression.Value(nToDate)),
			)

			fromID := accountKey
			hasFilter = true

			toID := 0
			vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
			if sAccountKey {
				toID, _ = strconv.Atoi(vAccountKey)
			}

			filter = filter.And(
				expression.Or(
					expression.And(
						expression.Name("from").Equal(expression.Value(fromID)),
						expression.Name("to").Equal(expression.Value(toID)),
					),
					expression.And(
						expression.Name("from").Equal(expression.Value(toID)),
						expression.Name("to").Equal(expression.Value(fromID)),
					),
				),
			)

			expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
			hasFilter = true

			var params dynamodb.ScanInput
			if hasFilter {
				expr, err := expressionNewBuilder.Build()
				if err == nil {
					params = dynamodb.ScanInput{
						ExpressionAttributeNames:  expr.Names(),
						ExpressionAttributeValues: expr.Values(),
						FilterExpression:          expr.Filter(),
						ProjectionExpression:      expr.Projection(),
						TableName:                 aws.String(dynamoTable),
					}
				}
			} else {
				params = dynamodb.ScanInput{
					TableName: aws.String(dynamoTable),
				}
			}
			libs.PrintJSON(params)
			result, err := svc.Scan(&params)
			if err == nil {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				for _, i := range result.Items {
					var item models.ChatHistoryRedis
					errItem := dynamodbattribute.UnmarshalMap(i, &item)
					if errItem == nil {
						jbObject := ConvertMessageRedisToJP(item)
						arrJPObjects = append(arrJPObjects, jbObject)
					}
				}
				if len(arrJPObjects) > 0 {
					totalCount = len(arrJPObjects)
					sort.Slice(arrJPObjects, func(i, j int) bool {
						if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
							timeI := *arrJPObjects[i].DateTime
							timeJ := *arrJPObjects[j].DateTime
							// min-max
							//return timeI.Before(timeJ)
							// max-min
							return timeI.After(timeJ)
						} else if arrJPObjects[i].DateTime != nil {
							return true
						}
						return false
					})
					for i := 0; i < pagingLength; i++ {
						//position := (pagingStart-1)*pagingLength + i
						// no need because minus above
						//position := (pagingStart)*pagingLength + i
						// @TODO currently, get by position not paging
						position := (pagingStart) + i
						if position < len(arrJPObjects) {
							arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjects[position])
						}
					}
				}
				// get user info
				if len(arrJPObjectsPaging) > 0 {
					for i, objectsPaging := range arrJPObjectsPaging {
						arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
					}
					// sort min - max
					sort.Slice(arrJPObjectsPaging, func(i, j int) bool {
						if arrJPObjectsPaging[i].DateTime != nil && arrJPObjectsPaging[j].DateTime != nil {
							timeI := *arrJPObjectsPaging[i].DateTime
							timeJ := *arrJPObjectsPaging[j].DateTime
							// min-max
							return timeI.Before(timeJ)
							// max-min
							//return timeI.After(timeJ)
						} else if arrJPObjectsPaging[i].DateTime != nil {
							return true
						}
						return false
					})
				}
				data = arrJPObjectsPaging
			} else {
				status = 500
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
			}
		} else {
			status = 500
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
		}

	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetLastChats godoc
// @Summary Get Last Chats
// @Description Get Last Chats
// @Tags System
// @Accept  json
// @Produce  json
// @Param HistoryDays query int false "HistoryDays"
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getlastchats [get]
func GetLastChats_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetLastChats")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
		totalCount     = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// get dynamic connection
		conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseChat)
		arrJPObjectsPaging := make([]models.ChatHistoryResponse, 0)
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		arrKeys := make([]string, 0)
		arrDateKey := make([]string, 0)
		arrPatternKey := make([]string, 0)
		pattern := "tb|cha*"
		fromID := accountKey
		historyDays := 10
		vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
		if sHistoryDays {
			historyDays, _ = strconv.Atoi(vHistoryDays)
		}
		pattern1 := pattern + "|to|" + strconv.Itoa(fromID) + "|*"
		pattern2 := pattern + "|fr|" + strconv.Itoa(fromID) + "|*"
		timeNow := time.Now()
		for i := 0; i < historyDays; i++ {
			newDate := timeNow.AddDate(0, 0, -(i))
			arrDateKey = append(arrDateKey, newDate.Format("20060102"))
		}
		if len(arrDateKey) > 0 {
			for _, k := range arrDateKey {
				newPatternKey1 := ``
				newPatternKey1 = pattern1 + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey1)
				newPatternKey2 := ``
				newPatternKey2 = pattern2 + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey2)
			}
		} else {
			newPatternKey1 := pattern1
			arrPatternKey = append(arrPatternKey, newPatternKey1)
			newPatternKey2 := pattern2
			arrPatternKey = append(arrPatternKey, newPatternKey2)
		}
		fmt.Println("arrPatternKey: ", arrPatternKey)
		fmt.Println("time.Now: find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		lenArrayPattern := len(arrPatternKey)
		cResponseGetRedisKey := make(chan models.CronJobResponseRedisKey, lenArrayPattern)
		for _, pattern := range arrPatternKey {
			go func(cResponseGetRedisKey chan models.CronJobResponseRedisKey, connn *redis.Client, pattern string) {
				var responseGetRedisKey models.CronJobResponseRedisKey
				resRedis := connn.Do(redisdynamic.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						var arrSearchKeys = make([]string, 0)
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrSearchKeys = append(arrSearchKeys, key)
							}
						}
						responseGetRedisKey.Keys = arrSearchKeys
						responseGetRedisKey.Status = 200
					}
				} else {
					responseGetRedisKey.Status = 500
					responseGetRedisKey.Message = resRedis.Err().Error()
				}
				cResponseGetRedisKey <- responseGetRedisKey
			}(cResponseGetRedisKey, conn, pattern)
		}
		for range arrPatternKey {
			objectKey := <-cResponseGetRedisKey
			if objectKey.Status == 200 {
				if len(objectKey.Keys) > 0 {
					arrKeys = append(arrKeys, objectKey.Keys...)
				}
			} else if objectKey.Status == 500 {
				status = objectKey.Status
				msg = objectKey.Message
			}
		}
		fmt.Println("time.Now: End find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		//fmt.Println("arrKeys: ", arrKeys)

		if status == 200 {
			if len(arrKeys) > 0 {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				lenArrayKey := len(arrKeys)
				cResponseGetRedisData := make(chan models.CronJobResponseRedisData, lenArrayKey)
				for _, key := range arrKeys {
					go func(cResponseGetRedisData chan models.CronJobResponseRedisData, conn *redis.Client, key string) {
						var responseGetRedisData models.CronJobResponseRedisData
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.ChatHistoryRedis
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								jbObject := ConvertMessageRedisToJP(redisObject)
								responseGetRedisData.Data = jbObject
								responseGetRedisData.Status = 200
								responseGetRedisData.Message = services.GetMessage(lang, "api.success")
							} else {
								responseGetRedisData.Status = 500
								responseGetRedisData.Message = errJSON.Error()
							}
						} else {
							responseGetRedisData.Status = statusSub
							responseGetRedisData.Message = errSub.Error()
						}
						cResponseGetRedisData <- responseGetRedisData
					}(cResponseGetRedisData, conn, key)
				}
				for range arrKeys {
					object := <-cResponseGetRedisData
					if object.Status == 200 {
						arrJPObjects = append(arrJPObjects, object.Data)
					} else {
						status = object.Status
						msg = object.Message
					}
				}
				if status == 200 {
					if len(arrJPObjects) > 0 {

						sort.Slice(arrJPObjects, func(i, j int) bool {
							if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
								timeI := *arrJPObjects[i].DateTime
								timeJ := *arrJPObjects[j].DateTime
								// min-max
								//return timeI.Before(timeJ)
								// max-min
								return timeI.After(timeJ)
							} else if arrJPObjects[i].DateTime != nil {
								return true
							}
							return false
						})

						var arrJPObjetsLastChat = make([]models.ChatHistoryResponse, 0)
						var mapJPObjetsLastChat = make(map[string]string)
						for _, objLastChat := range arrJPObjects {
							/* lastChatKeyFrom := strconv.Itoa(objLastChat.From) + ":" + strconv.Itoa(objLastChat.To)
							_, sLastChat := mapJPObjetsLastChat[lastChatKeyFrom]
							if !sLastChat {
								// add for from
								arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChat)
								mapJPObjetsLastChat[lastChatKeyFrom] = objLastChat.Key
							}
							// add for to
							lastChatKeyTo := strconv.Itoa(objLastChat.To) + ":" + strconv.Itoa(objLastChat.From)
							_, sLastChatTo := mapJPObjetsLastChat[lastChatKeyTo]
							if !sLastChatTo {
								objLastChatTo := objLastChat
								objLastChatTo.From = objLastChat.To
								objLastChatTo.To = objLastChat.From
								arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChatTo)
								mapJPObjetsLastChat[lastChatKeyTo] = objLastChatTo.Key
							} */

							lastChatKeyFrom := strconv.Itoa(objLastChat.From) + ":" + strconv.Itoa(objLastChat.To)
							_, sLastChat := mapJPObjetsLastChat[lastChatKeyFrom]
							if !sLastChat {
								// add for from
								lastChatKeyTo := strconv.Itoa(objLastChat.To) + ":" + strconv.Itoa(objLastChat.From)
								_, sLastChatTo := mapJPObjetsLastChat[lastChatKeyTo]
								if !sLastChatTo {
									arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChat)
									mapJPObjetsLastChat[lastChatKeyFrom] = objLastChat.MessageKey
								}
							}
						}
						totalCount = len(mapJPObjetsLastChat)
						for i := 0; i < pagingLength; i++ {
							//position := (pagingStart-1)*pagingLength + i
							// no need because minus above
							//position := (pagingStart)*pagingLength + i
							// @TODO currently, get by position not paging
							position := (pagingStart) + i
							if position < len(arrJPObjetsLastChat) {
								arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjetsLastChat[position])
							}
						}
					}
					// get user info
					if len(arrJPObjectsPaging) > 0 {
						for i, objectsPaging := range arrJPObjectsPaging {
							arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
						}
					}
				}
			}
		}
		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now: End: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			data = arrJPObjectsPaging
			if msg == nil {
				msg = services.GetMessage(lang, "api.success")
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

func GetLastChats(c *gin.Context) {
	defer libs.RecoverError(c, "GetLastChats")
	var (
		status             = libs.GetStatusSuccess()
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		msg, data          interface{}
		totalCount         = 0
		validateMsgError   string
		arrJPObjectsPaging = make([]models.ChatHistoryResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		pagingStart, _ := strconv.Atoi(vStart)
		if pagingStart < 0 {
			pagingStart = 0
		}
		pagingLength, _ := strconv.Atoi(vLength)
		if pagingLength <= 0 {
			pagingLength = 20
		}

		dynamoTable := dynamoConfig.DatabaseNameChat
		sess, err := session.NewSession(&aws.Config{
			Region: aws.String(dynamoConfig.Region),
			Credentials: credentials.NewStaticCredentials(
				dynamoConfig.AccessKeyID,
				dynamoConfig.SecretAccessKey,
				"",
			),
		})
		if err == nil {
			svc := dynamodb.New(sess)
			hasFilter := false

			expressionNewBuilder := expression.NewBuilder()

			filterDataFormat := "20060102"
			prefixFromNumber := "000000000"
			prefixToNumber := "999999999"

			historyDays := 10
			vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
			if sHistoryDays {
				historyDays, _ = strconv.Atoi(vHistoryDays)
			}

			timeNow := time.Now()

			dFromDate := timeNow.AddDate(0, 0, -(historyDays))
			sFromDate := dFromDate.Format(filterDataFormat)
			sFromDate = sFromDate + prefixFromNumber
			nFromDate, _ := strconv.Atoi(sFromDate)

			dToDate := timeNow
			sToDate := dToDate.Format(filterDataFormat)
			sToDate = sToDate + prefixToNumber
			nToDate, _ := strconv.Atoi(sToDate)

			filter := expression.And(
				expression.Name("datetime").GreaterThanEqual(expression.Value(nFromDate)),
				expression.Name("datetime").LessThanEqual(expression.Value(nToDate)),
			)

			fromID := accountKey

			filter = filter.And(
				expression.Or(expression.Name("from").Equal(expression.Value(fromID)), expression.Name("to").Equal(expression.Value(fromID))),
			)

			expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
			hasFilter = true

			var params dynamodb.ScanInput
			if hasFilter {
				expr, err := expressionNewBuilder.Build()
				if err == nil {
					params = dynamodb.ScanInput{
						ExpressionAttributeNames:  expr.Names(),
						ExpressionAttributeValues: expr.Values(),
						FilterExpression:          expr.Filter(),
						ProjectionExpression:      expr.Projection(),
						TableName:                 aws.String(dynamoTable),
					}
				}
			} else {
				params = dynamodb.ScanInput{
					TableName: aws.String(dynamoTable),
				}
			}
			libs.PrintJSON(params)
			result, err := svc.Scan(&params)
			if err == nil {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				for _, i := range result.Items {
					var item models.ChatHistoryRedis
					errItem := dynamodbattribute.UnmarshalMap(i, &item)
					if errItem == nil {
						jbObject := ConvertMessageRedisToJP(item)
						arrJPObjects = append(arrJPObjects, jbObject)
					}
				}
				if len(arrJPObjects) > 0 {

					sort.Slice(arrJPObjects, func(i, j int) bool {
						if arrJPObjects[i].DateTime != nil && arrJPObjects[j].DateTime != nil {
							timeI := *arrJPObjects[i].DateTime
							timeJ := *arrJPObjects[j].DateTime
							// min-max
							//return timeI.Before(timeJ)
							// max-min
							return timeI.After(timeJ)
						} else if arrJPObjects[i].DateTime != nil {
							return true
						}
						return false
					})

					var arrJPObjetsLastChat = make([]models.ChatHistoryResponse, 0)
					var mapJPObjetsLastChat = make(map[string]string)
					for _, objLastChat := range arrJPObjects {
						/* lastChatKeyFrom := strconv.Itoa(objLastChat.From) + ":" + strconv.Itoa(objLastChat.To)
						_, sLastChat := mapJPObjetsLastChat[lastChatKeyFrom]
						if !sLastChat {
							// add for from
							arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChat)
							mapJPObjetsLastChat[lastChatKeyFrom] = objLastChat.Key
						}
						// add for to
						lastChatKeyTo := strconv.Itoa(objLastChat.To) + ":" + strconv.Itoa(objLastChat.From)
						_, sLastChatTo := mapJPObjetsLastChat[lastChatKeyTo]
						if !sLastChatTo {
							objLastChatTo := objLastChat
							objLastChatTo.From = objLastChat.To
							objLastChatTo.To = objLastChat.From
							arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChatTo)
							mapJPObjetsLastChat[lastChatKeyTo] = objLastChatTo.Key
						} */

						lastChatKeyFrom := strconv.Itoa(objLastChat.From) + ":" + strconv.Itoa(objLastChat.To)
						_, sLastChat := mapJPObjetsLastChat[lastChatKeyFrom]
						if !sLastChat {
							// add for from
							lastChatKeyTo := strconv.Itoa(objLastChat.To) + ":" + strconv.Itoa(objLastChat.From)
							_, sLastChatTo := mapJPObjetsLastChat[lastChatKeyTo]
							if !sLastChatTo {
								arrJPObjetsLastChat = append(arrJPObjetsLastChat, objLastChat)
								mapJPObjetsLastChat[lastChatKeyFrom] = objLastChat.MessageKey
							}
						}
					}
					totalCount = len(mapJPObjetsLastChat)
					for i := 0; i < pagingLength; i++ {
						//position := (pagingStart-1)*pagingLength + i
						// no need because minus above
						//position := (pagingStart)*pagingLength + i
						// @TODO currently, get by position not paging
						position := (pagingStart) + i
						if position < len(arrJPObjetsLastChat) {
							arrJPObjectsPaging = append(arrJPObjectsPaging, arrJPObjetsLastChat[position])
						}
					}
				}
				// get user info
				if len(arrJPObjectsPaging) > 0 {
					for i, objectsPaging := range arrJPObjectsPaging {
						arrJPObjectsPaging[i] = GetUserInfomationForMessageJP(db, objectsPaging)
					}
				}
				data = arrJPObjectsPaging
			} else {
				status = 500
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
			}
		} else {
			status = 500
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
		}

	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUnreadChatCount godoc
// @Summary Get Unread Chat Count
// @Description Get Unread Chat Count
// @Tags System
// @Accept  json
// @Produce  json
// @Param HistoryDays query int false "HistoryDays"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getchatcount [get]
func GetUnreadChatCount_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetUnreadChatCount")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
		totalCount     = 0
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	//db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//
	//
	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// @TODO testing accountKey
	//accountKey = 2
	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// get dynamic connection
		conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseChat)
		//arrJPObjectsPaging := make([]models.ChatHistoryResponse, 0)
		arrKeys := make([]string, 0)
		arrDateKey := make([]string, 0)
		arrPatternKey := make([]string, 0)
		pattern := "tb|cha*"
		historyDays := 0
		vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
		if sHistoryDays {
			historyDays, _ = strconv.Atoi(vHistoryDays)
		}
		pattern = pattern + "|to|" + strconv.Itoa(accountKey) + "|*"
		timeNow := time.Now()
		for i := 0; i < historyDays; i++ {
			newDate := timeNow.AddDate(0, 0, -(i))
			arrDateKey = append(arrDateKey, newDate.Format("20060102"))
		}
		if len(arrDateKey) > 0 {
			for _, k := range arrDateKey {
				newPatternKey := ``
				newPatternKey = pattern + "|dt|" + k + "*"
				arrPatternKey = append(arrPatternKey, newPatternKey)
			}
		} else {
			newPatternKey := pattern
			arrPatternKey = append(arrPatternKey, newPatternKey)
		}
		fmt.Println("arrPatternKey: ", arrPatternKey)
		fmt.Println("time.Now: find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		lenArrayPattern := len(arrPatternKey)
		cResponseGetRedisKey := make(chan models.CronJobResponseRedisKey, lenArrayPattern)
		for _, pattern := range arrPatternKey {
			go func(cResponseGetRedisKey chan models.CronJobResponseRedisKey, connn *redis.Client, pattern string) {
				var responseGetRedisKey models.CronJobResponseRedisKey
				resRedis := connn.Do(redisdynamic.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						var arrSearchKeys = make([]string, 0)
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrSearchKeys = append(arrSearchKeys, key)
							}
						}
						responseGetRedisKey.Keys = arrSearchKeys
						responseGetRedisKey.Status = 200
					}
				} else {
					responseGetRedisKey.Status = 500
					responseGetRedisKey.Message = resRedis.Err().Error()
				}
				cResponseGetRedisKey <- responseGetRedisKey
			}(cResponseGetRedisKey, conn, pattern)
		}
		for range arrPatternKey {
			objectKey := <-cResponseGetRedisKey
			if objectKey.Status == 200 {
				if len(objectKey.Keys) > 0 {
					arrKeys = append(arrKeys, objectKey.Keys...)
				}
			} else if objectKey.Status == 500 {
				status = objectKey.Status
				msg = objectKey.Message
			}
		}
		fmt.Println("time.Now: find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		//fmt.Println("arrKeys: ", arrKeys)
		if status == 200 {
			if len(arrKeys) > 0 {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				lenArrayKey := len(arrKeys)
				cResponseGetRedisData := make(chan models.CronJobResponseRedisData, lenArrayKey)
				for i, key := range arrKeys {
					if i > 0 && i%1000 == 0 {
						//time.Sleep(50 * time.Millisecond)
					}
					go func(cResponseGetRedisData chan models.CronJobResponseRedisData, conn *redis.Client, key string) {
						var responseGetRedisData models.CronJobResponseRedisData
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.ChatHistoryRedis
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								jbObject := ConvertMessageRedisToJP(redisObject)
								responseGetRedisData.Data = jbObject
								responseGetRedisData.Status = 200
								responseGetRedisData.Message = services.GetMessage(lang, "api.success")
							} else {
								responseGetRedisData.Status = 500
								responseGetRedisData.Message = errJSON.Error()
							}
						} else {
							responseGetRedisData.Status = statusSub
							responseGetRedisData.Message = errSub.Error()
						}
						cResponseGetRedisData <- responseGetRedisData
					}(cResponseGetRedisData, conn, key)
				}
				for range arrKeys {
					object := <-cResponseGetRedisData
					if object.Status == 200 {
						if libs.InArrayInteger(object.Data.Status, []int{0, 1, 2}) {
							arrJPObjects = append(arrJPObjects, object.Data)
						}
					} else {
						status = object.Status
						msg = object.Message
					}
				}
				if status == 200 {
					if len(arrJPObjects) > 0 {
						totalCount = len(arrJPObjects)
					}
				}
			}
		}

		fmt.Println("time.Now find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
		fmt.Println("time.Now:             End: ", time.Now().Format("2006-01-02 15:04:05.999"))
		if status == 200 {
			if msg == nil {
				msg = services.GetMessage(lang, "api.success")
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	data = map[string]interface{}{"Count": totalCount}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

func GetUnreadChatCount(c *gin.Context) {
	defer libs.RecoverError(c, "GetUnreadChatCount")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		errorsResponse   []models.ErrorResponse
		msg, data        interface{}
		totalCount       = 0
		validateMsgError string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	//db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//
	//
	fmt.Println("time.Now: start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// @TODO testing accountKey
	//accountKey = 2
	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		// Paging
		dynamoTable := dynamoConfig.DatabaseNameChat
		sess, err := session.NewSession(&aws.Config{
			Region: aws.String(dynamoConfig.Region),
			Credentials: credentials.NewStaticCredentials(
				dynamoConfig.AccessKeyID,
				dynamoConfig.SecretAccessKey,
				"",
			),
		})
		if err == nil {
			svc := dynamodb.New(sess)
			hasFilter := false

			expressionNewBuilder := expression.NewBuilder()

			filterDataFormat := "20060102"
			prefixFromNumber := "000000000"
			prefixToNumber := "999999999"

			historyDays := 10
			vHistoryDays, sHistoryDays := libs.GetQueryParam("HistoryDays", c)
			if sHistoryDays {
				historyDays, _ = strconv.Atoi(vHistoryDays)
			}

			timeNow := time.Now()

			dFromDate := timeNow.AddDate(0, 0, -(historyDays))
			sFromDate := dFromDate.Format(filterDataFormat)
			sFromDate = sFromDate + prefixFromNumber
			nFromDate, _ := strconv.Atoi(sFromDate)

			dToDate := timeNow
			sToDate := dToDate.Format(filterDataFormat)
			sToDate = sToDate + prefixToNumber
			nToDate, _ := strconv.Atoi(sToDate)

			filter := expression.And(
				expression.Name("datetime").GreaterThanEqual(expression.Value(nFromDate)),
				expression.Name("datetime").LessThanEqual(expression.Value(nToDate)),
			)

			filter = filter.And(expression.Name("to").Equal(expression.Value(accountKey)))

			expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
			hasFilter = true

			var params dynamodb.ScanInput
			if hasFilter {
				expr, err := expressionNewBuilder.Build()
				if err == nil {
					params = dynamodb.ScanInput{
						ExpressionAttributeNames:  expr.Names(),
						ExpressionAttributeValues: expr.Values(),
						FilterExpression:          expr.Filter(),
						ProjectionExpression:      expr.Projection(),
						TableName:                 aws.String(dynamoTable),
					}
				}
			} else {
				params = dynamodb.ScanInput{
					TableName: aws.String(dynamoTable),
				}
			}
			libs.PrintJSON(params)
			result, err := svc.Scan(&params)
			if err == nil {
				arrJPObjects := make([]models.ChatHistoryResponse, 0)
				for _, i := range result.Items {
					var item models.ChatHistoryRedis
					errItem := dynamodbattribute.UnmarshalMap(i, &item)
					if errItem == nil {
						jbObject := ConvertMessageRedisToJP(item)
						if libs.InArrayInteger(jbObject.Status, []int{0, 1, 2}) {
							arrJPObjects = append(arrJPObjects, jbObject)
						}
					}
				}
				if len(arrJPObjects) > 0 {
					totalCount = len(arrJPObjects)
				}
			} else {
				status = 500
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
			}
		} else {
			status = 500
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
		}
	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	data = map[string]interface{}{"Count": totalCount}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUserInfomationForMessageJP func
func GetUserInfomationForMessageJP(db *gorm.DB, item models.ChatHistoryResponse) models.ChatHistoryResponse {
	//fmt.Println("time.Now find user info: ", time.Now().Format("2006-01-02 15:04:05.999"))
	if item.From > 0 {
		var (
			user     models.User
			location models.Location
		)
		resultFindUser := db.Where(
			"AccountKey = ?",
			item.From,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).First(&user)
		if resultFindUser.RowsAffected > 0 {
			item.FromFirstName = user.FirstName
			item.FromLastName = user.LastName
			if user.LocationID > 0 {
				resultFindLocation := db.Where(
					"LocationID = ?",
					user.LocationID,
				).Where(
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).First(&location)
				if resultFindLocation.RowsAffected > 0 {
					item.FromLocationName = location.LocationName
				}
			}
		}
	}
	if item.To > 0 {
		var (
			user     models.User
			location models.Location
		)
		resultFindUser := db.Where(
			"AccountKey = ?",
			item.To,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).First(&user)
		if resultFindUser.RowsAffected > 0 {
			item.ToFirstName = user.FirstName
			item.ToLastName = user.LastName
			if user.LocationID > 0 {
				resultFindLocation := db.Where(
					"LocationID = ?",
					user.LocationID,
				).Where(
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).First(&location)
				if resultFindLocation.RowsAffected > 0 {
					item.ToLocationName = location.LocationName
				}
			}
		}
	}
	//fmt.Println("time.Now end find user info: ", time.Now().Format("2006-01-02 15:04:05.999"))
	return item
}

// ConvertMessageRedisToJP func
func ConvertMessageRedisToJP(redisObject models.ChatHistoryRedis) models.ChatHistoryResponse {
	// do not get user info in this function by very slow
	var (
		chatHistoryResponse models.ChatHistoryResponse
	)
	chatHistoryResponse.From, _ = strconv.Atoi(redisObject.From)
	bTo, iTo := ConvertRedisStringToNumber(redisObject.To)
	if bTo {
		chatHistoryResponse.To = iTo
	}
	//chatHistoryResponse.Key = redisObject.Key[len(redisObject.Key)-36:]
	chatHistoryResponse.MessageKey = redisObject.MessageKey
	chatHistoryResponse.Message = redisObject.Message
	chatHistoryResponse.Status, _ = strconv.Atoi(redisObject.Status)

	if redisObject.DateTime != "" {
		if len(redisObject.DateTime) >= 17 {
			redisDateTime, errRedisDateTime := time.Parse("20060102150405.000", redisObject.DateTime[0:14]+"."+redisObject.DateTime[len(redisObject.DateTime)-3:])
			if errRedisDateTime == nil {
				chatHistoryResponse.DateTime = &redisDateTime
			}
		} else {
			redisDateTime, errRedisDateTime := time.Parse("20060102150405", redisObject.DateTime)
			if errRedisDateTime == nil {
				chatHistoryResponse.DateTime = &redisDateTime
			}
		}
	}

	return chatHistoryResponse
}

// ConvertRedisStringToNumber func
func ConvertRedisStringToNumber(strNumber string) (bool, int) {
	// `["402"]`
	re := regexp.MustCompile("[0-9]+")
	arr := re.FindAllString(strNumber, -1)
	if len(arr) > 0 {
		nNum, _ := strconv.Atoi(arr[0])
		return true, nNum
	}
	return false, 0
}

// ConvertArrayChatUserToArrayResponse func
func ConvertArrayChatUserToArrayResponse(requestHeader models.RequestHeader, items []models.User) []models.UserChatResponse {
	responses := make([]models.UserChatResponse, 0)
	for _, item := range items {
		response := ConvertChatUserToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertChatUserToResponse func
func ConvertChatUserToResponse(requestHeader models.RequestHeader, item models.User) models.UserChatResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		response           models.UserChatResponse
		locationModel      models.Location
		locationGroupModel models.LocationGroup
	)
	response.UserID = item.UserID
	response.AccountKey = item.AccountKey
	response.FirstName = item.FirstName
	response.LastName = item.LastName
	response.Email = item.Email
	response.LocationID = item.LocationID
	resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND LocationID = ?", item.LocationID).First(&locationModel)
	if resultFindLocation.RowsAffected > 0 {
		response.LocationName = locationModel.LocationName
		resultFindLocationGroup := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND LocationGroupID = ?", locationModel.LocationGroupID).First(&locationGroupModel)
		if resultFindLocationGroup.RowsAffected > 0 {
			response.LocationGroupName = locationGroupModel.LocationGroupName
		}
	}
	response.PhoneNumber = item.PhoneNumber
	return response
}
