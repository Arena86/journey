package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetVehicleInspectionQuestionGroupByVehicleInspectionID godoc
// @Summary Get GetVehicleInspectionQuestionGroupByVehicleInspectionID
// @Description Get GetVehicleInspectionQuestionGroupByVehicleInspectionID
// @Tags VehicleInspectionQuestionGroup
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionquestiongroup/{vehicleinspectionid} [get]
func GetVehicleInspectionQuestionGroupByVehicleInspectionID(c *gin.Context) {
	defer libs.RecoverError(c, "GetVehicleInspectionQuestionGroupByVehicleInspectionID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.VehicleInspectionQuestionGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	ID := c.Param("id")

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Questions", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND VehicleInspectionID = ?", ID)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	//bp = libs.SortDataOnParam(bp, c)
	bp = bp.Order("Sort ASC")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayVehicleInspectionQuestionGroupToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayVehicleInspectionQuestionGroupToArrayResponse func
func ConvertArrayVehicleInspectionQuestionGroupToArrayResponse(items []models.VehicleInspectionQuestionGroup) []models.OnlyQuestionGroupResponse {
	responses := make([]models.OnlyQuestionGroupResponse, 0)
	for _, item := range items {
		response := ConvertVehicleInspectionQuestionGroupToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertVehicleInspectionQuestionGroupToResponse func
func ConvertVehicleInspectionQuestionGroupToResponse(item models.VehicleInspectionQuestionGroup) models.OnlyQuestionGroupResponse {
	var (
		response models.OnlyQuestionGroupResponse
	)
	response.InspectionQuestionGroupID = item.InspectionQuestionGroupID
	response.VehicleInspectionID = item.VehicleInspectionID
	response.GroupName = item.GroupName
	response.Sort = item.Sort
	questionDetails := make([]models.VehicleInspectionQuestionResponse, 0)
	for _, d := range item.Questions {
		var questionDetail models.VehicleInspectionQuestionResponse
		questionDetail.InspectionQuestionID = d.InspectionQuestionID
		questionDetail.InspectionQuestionGroupID = d.InspectionQuestionGroupID
		questionDetail.Question = d.Question
		questionDetail.IsPhotoEnable = d.IsPhotoEnable
		questionDetail.IsMandatory = d.IsMandatory
		questionDetails = append(questionDetails, questionDetail)
	}
	response.Questions = questionDetails
	return response
}
