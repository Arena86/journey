package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

var postingGridTemplate = false

// GetGridTemplatesByKey godoc
// @Summary Get GridTemplates By Key
// @Description Get GridTemplates By Key
// @Tags GridTemplates
// @Accept  json
// @Produce  json
// @Param key path int true "GridTemplates Key"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /gridtemplates/{key} [get]
func GetGridTemplatesByKey(c *gin.Context) {
	defer libs.RecoverError(c, "GetGridTemplatesByKey")
	var (
		status        = libs.GetStatusSuccess()
		grids         []models.GridTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	// @TODO waiting post finished

	// Paging
	/*vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}*/
	//if !sLength {
	//		vLength = os.Getenv("PAGE_SIZE")
	//}
	//key := c.Param("key")
	var totalCount int64
	totalCount = 0
	//var bp = db.Limit(vLength).Offset(vStart)
	var bp = db
	//bp = bp.Where("GridKey = ?", key)
	resultRow := bp.Find(&grids).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(grids) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = ConvertGridTemplateToGridTemplateGET(grids, lang)
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// UpdateGridTemplatesByKey godoc
// @Summary Update GridTemplates By Key
// @Description Update GridTemplates By Key
// @Tags GridTemplates
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Grid body []models.GridTemplate true "Create Grid"
// @Success 200 {object} models.APIResponseData
// @Router /gridtemplates/:key [put]
func UpdateGridTemplatesByKey(c *gin.Context) {
	// @TODO waiting post finished
	postingGridTemplate = true
	defer libs.RecoverError(c, "UpdateGridTemplatesByKey")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.GridTemplate
		totalUpdatedRecord = 0
		totalRecord        = 0
	)

	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	//key := c.Param("key")
	dataResponse = make([]models.GridTemplate, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		type GridKeyObject struct {
			Data   []map[string]interface{}
			Indexs []int
			Index  int
		}

		// pass same Gridkey to array map - index of item pass to array Indexs
		arrPOSTGroupByGridKey := make(map[string]GridKeyObject)
		for k, mapJSON := range objectsJSON {
			val, res := services.ConvertJSONValueToVariable("GridKey", mapJSON)
			if res != nil {
				_, hasMap := arrPOSTGroupByGridKey[val]
				var obj GridKeyObject
				arrIndexs := make([]int, 0)
				arrData := make([]map[string]interface{}, 0)
				if hasMap {
					obj = arrPOSTGroupByGridKey[val]
					arrData = obj.Data
					arrIndexs = obj.Indexs
				}
				arrData = append(arrData, mapJSON)
				obj.Data = arrData

				arrIndexs = append(arrIndexs, k)
				obj.Indexs = arrIndexs
				obj.Index = k
				arrPOSTGroupByGridKey[val] = obj
			}

		}

		for key, obj := range arrPOSTGroupByGridKey {
			indexs := obj.Indexs
			dataResponseSub := make([]models.GridTemplate, 0)
			resultFindKey := db.Where("GridKey = ?", key).First(&models.GridTemplate{})
			if resultFindKey.RowsAffected > 0 {
				objectsJSONSub := obj.Data
				if len(objectsJSONSub) > 0 {
					var (
						rollbackGrids             []models.GridTemplate
						hasRollBack               = false
						arrIDNeedDeleteAtRollBack = make([]int, 0)
					)
					db.Where("GridKey = ?", key).Find(&rollbackGrids)
					db.Where("GridKey = ?", key).Model(&models.GridTemplate{}).Updates(map[string]interface{}{"Visible": false, "Width": "100%"})
					for k, bp := range objectsJSONSub {
						var (
							grid models.GridTemplate
						)
						indexsPOST := obj.Index
						if libs.Isset(indexs, k) {
							indexsPOST = indexs[k]
						}
						totalRecord = totalRecord + 1
						grid.PassBodyJSONToModel(bp)
						resultFind := db.Where("GridKey = ? AND DataField = ?", key, grid.DataField).First(&grid)
						grid.PassBodyJSONToModel(bp)
						grid.GridKey = key
						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(grid)
						if err != nil {
							var (
								errValid interface{}
							)
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								errValid = e.Translate(trans)
							}
							errResponse := GetErrorResponseErrorMessage(indexsPOST, errValid)
							errorsResponse = append(errorsResponse, errResponse)
							// @TODO rollback data
							hasRollBack = true
							break
						} else {
							if resultFind.RowsAffected > 0 {
								resultSave := db.Where("GridKey = ? AND DataField = ?", grid.GridKey, grid.DataField).Save(&grid)
								if resultSave.Error != nil {
									errResponse := GetErrorResponseErrorMessage(indexsPOST, resultSave.Error.Error())
									errorsResponse = append(errorsResponse, errResponse)
									// @TODO rollback data
									hasRollBack = true
									break
								} else {
									dataResponseSub = append(dataResponseSub, grid)
									totalUpdatedRecord++
								}
							} else {
								resultCreate := db.Create(&grid)
								if resultCreate.Error != nil {
									errResponse := GetErrorResponseErrorMessage(indexsPOST, resultCreate.Error.Error())
									errorsResponse = append(errorsResponse, errResponse)
									// @TODO rollback data
									hasRollBack = true
									break
								} else {
									arrIDNeedDeleteAtRollBack = append(arrIDNeedDeleteAtRollBack, grid.GridTemplateID)
									dataResponseSub = append(dataResponseSub, grid)
									totalUpdatedRecord++
								}
							}
						}
					}
					if hasRollBack {
						if len(arrIDNeedDeleteAtRollBack) > 0 {
							db.Where("GridTemplateID in (?)", arrIDNeedDeleteAtRollBack).Delete(&models.GridTemplate{})
						}
						for _, v := range rollbackGrids {
							db.Save(&v)
						}
						dataResponseSub = rollbackGrids
					}
				}
			} else {
				indexsPOST := obj.Index
				for k := range obj.Data {
					totalRecord = totalRecord + 1
					if libs.Isset(indexs, k) {
						indexsPOST = indexs[k]
					}
					errResponse := GetErrorResponseNotFound(lang, indexsPOST)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}

			for _, sub := range dataResponseSub {
				dataResponse = append(dataResponse, sub)
			}
		}

		// old code
		/* resultFindKey := db.Where("GridKey = ?", key).First(&models.GridTemplate{})
		if resultFindKey.RowsAffected > 0 {
			if len(objectsJSON) > 0 {
				var (
					rollbackGrids             []models.GridTemplate
					hasRollBack               = false
					arrIDNeedDeleteAtRollBack = make([]int, 0)
				)
				db.Where("GridKey = ?", key).Find(&rollbackGrids)
				db.Where("GridKey = ?", key).Model(models.GridTemplate{}).Updates(map[string]interface{}{"Visible": false, "Width": "100%"})
				for k, bp := range objectsJSON {
					var (
						grid models.GridTemplate
					)
					totalRecord = totalRecord + 1
					grid.PassBodyJSONToModel(bp)
					resultFind := db.Where("GridKey = ? AND DataField = ?", key, grid.DataField).First(&grid)
					grid.PassBodyJSONToModel(bp)
					grid.GridKey = key
					validate := validator.New()
					err := validate.Struct(grid)
					if err != nil {
						errResponse := GetErrorResponseErrorMessage(k, err.Error())
						errorsResponse = append(errorsResponse, errResponse)
						// @TODO rollback data
						hasRollBack = true
						break
					} else {
						if resultFind.RowsAffected > 0 {
							resultSave := db.Where("GridKey = ? AND DataField = ?", grid.GridKey, grid.DataField).Save(&grid)
							if resultSave.Error != nil {
								errResponse := GetErrorResponseErrorMessage(k, resultSave.Error.Error())
								errorsResponse = append(errorsResponse, errResponse)
								// @TODO rollback data
								hasRollBack = true
								break
							} else {
								dataResponse = append(dataResponse, grid)
								totalUpdatedRecord++
							}
						} else {
							resultCreate := db.Create(&grid)
							if resultCreate.Error != nil {
								errResponse := GetErrorResponseErrorMessage(k, resultCreate.Error.Error())
								errorsResponse = append(errorsResponse, errResponse)
								// @TODO rollback data
								hasRollBack = true
								break
							} else {
								arrIDNeedDeleteAtRollBack = append(arrIDNeedDeleteAtRollBack, grid.GridTemplateID)
								dataResponse = append(dataResponse, grid)
								totalUpdatedRecord++
							}
						}
					}
				}
				if hasRollBack {
					if len(arrIDNeedDeleteAtRollBack) > 0 {
						db.Where("GridTemplateID in (?)", arrIDNeedDeleteAtRollBack).Delete(&models.GridTemplate{})
					}
					for _, v := range rollbackGrids {
						db.Save(&v)
					}
					dataResponse = rollbackGrids
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		} */
		// end old code
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, totalRecord, errorsResponse, false)
	data = ConvertGridTemplateToGridTemplateGET(dataResponse, lang)

	// @TODO waiting post finished
	//time.Sleep(7 * time.Second)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertGridTemplateToGridTemplateGET func
func ConvertGridTemplateToGridTemplateGET(grids []models.GridTemplate, lang string) []models.GridTemplateGET {
	gridsGET := make([]models.GridTemplateGET, 0)
	if len(grids) > 0 {
		for _, v := range grids {
			var (
				gridGET models.GridTemplateGET
			)
			gridGET.GridKey = v.GridKey
			if v.GridNameTranslationKey != "" && v.GridNameTranslationKey != services.GetMessage(lang, v.GridNameTranslationKey) {
				gridGET.GridName = services.GetMessage(lang, v.GridNameTranslationKey)
			} else {
				gridGET.GridName = v.GridNameTranslationKey
			}
			gridGET.DataField = v.DataField
			if v.TranslationKey != "" && v.TranslationKey != services.GetMessage(lang, v.TranslationKey) {
				gridGET.Caption = services.GetMessage(lang, v.TranslationKey)
			} else {
				gridGET.Caption = v.Caption
			}
			gridGET.Visible = v.Visible
			gridGET.VisibleIndex = v.VisibleIndex
			gridGET.Width = v.Width
			gridGET.Format = v.Format
			gridGET.DataType = v.DataType
			gridGET.Alignment = v.Alignment
			gridGET.ShowInColumnChooser = v.ShowInColumnChooser
			gridGET.AllowGrouping = v.AllowGrouping
			gridGET.SortIndex = v.SortIndex
			gridGET.SortOrder = v.SortOrder
			gridGET.NumberPrecision = v.NumberPrecision
			gridGET.CellTemplate = v.CellTemplate
			gridGET.GroupIndex = v.GroupIndex
			gridsGET = append(gridsGET, gridGET)
		}
	}
	return gridsGET
}
