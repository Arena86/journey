package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetJobDetailByJob godoc
// @Summary Get Job Detail By Job
// @Description Get Job Detail By Job
// @Tags JobDetail
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param JobID path int true "Job ID"
// @Success 200 {object} []models.JobDetail
// @Router /jobdetail/byjob/{jobid} [get]
func GetJobDetailByJob(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobDetailByJob")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg            interface{}
		errorsResponse []models.ErrorResponse
		jobDetails     []models.JobDetail
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	sJobID := c.Param("jobid")
	jobID, _ := strconv.Atoi(sJobID)

	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", jobID)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobDetails).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(jobDetails) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayJobDetailToArrayResponse(requestHeader, jobDetails)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetJobDetailByJobTask godoc
// @Summary Get Job Detail By Job Task
// @Description Get Job Detail By Job Task
// @Tags JobDetail
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param JobID path int true "Job ID"
// @Success 200 {object} []models.JobDetail
// @Router /jobdetail/byjobtask/{jobid} [get]
func GetJobDetailByJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobDetailByJobTask")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg            interface{}
		errorsResponse []models.ErrorResponse
		jobDetails     []models.JobDetail
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	sJobTaskID := c.Param("jobtaskid")
	jobTaskID, _ := strconv.Atoi(sJobTaskID)
	var bp = db.Joins("JOIN jobs ON jobs.JobID = jobdetails.JobID").
		Joins("JOIN jobtasks ON jobs.JobID = jobtasks.JobID").
		Where("jobtasks.JobTaskID = ? AND IFNULL(jobdetails.IsDeleted, 0) <> 1 AND IFNULL(jobdetails.IsArchived, 0) <> 1", jobTaskID)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobDetails).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(jobDetails) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayJobDetailToArrayResponse(requestHeader, jobDetails)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// UpdateJobDetail godoc
// @Summary Update JobDetail
// @Description Update JobDetail
// @Tags JobDetail
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Type path int true "Item Movement Type"
// @Param JobDetail body []models.JobDetailJSONResponse true "Update JobDetail"
// @Success 200 {object} models.APIResponseData
// @Router /jobdetail/{type} [put]
func UpdateJobDetail(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJobDetail")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.JobDetail
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.JobDetail, 0)
	sJobDetailType := c.Param("type")
	jobDetailType, _ := strconv.Atoi(sJobDetailType)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				obj models.JobDetail
			)
			obj.PassBodyJSONToModel(bp)
			resultFind := db.Where("JobDetailID = ?", obj.JobDetailID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&obj)
			if resultFind.RowsAffected > 0 {
				obj.ModifiedBy = accountKey
				obj.PassBodyJSONToModel(bp)
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(obj)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultSave := db.Save(&obj)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, obj)
						// always create new
						var (
							objectsMovement []map[string]interface{}
						)
						_, res := services.ConvertJSONValueToVariable("ItemMovements", bp)
						if res != nil {
							movementsJSON, err := json.Marshal(res)
							if err == nil {
								json.Unmarshal(movementsJSON, &objectsMovement)
								if len(objectsMovement) > 0 {
									for _, objMovement := range objectsMovement {
										var (
											movementModel models.ItemMovement
										)
										movementModel.PassBodyJSONToModel(objMovement)
										if movementModel.JobDetailID == obj.JobDetailID {
											movementModel.CreatedBy = accountKey
											movementModel.ModifiedBy = accountKey
											movementModel.Type = jobDetailType
											db.Create(&movementModel)
										}
									}
								}
							}
						}
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.JobDetail
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.JobDetailID)
	}
	if len(arrID) > 0 {
		db.Where("JobDetailID in (?)", arrID).Find(&resModels)
		dataResponses := ConvertArrayJobDetailToArrayResponse(requestHeader, resModels)
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayJobDetailToArrayResponse func
func ConvertArrayJobDetailToArrayResponse(requestHeader models.RequestHeader, items []models.JobDetail) []models.JobDetailJSONResponse {
	responses := make([]models.JobDetailJSONResponse, 0)
	for _, item := range items {
		response := ConvertJobDetailToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJobDetailToResponse func
func ConvertJobDetailToResponse(requestHeader models.RequestHeader, item models.JobDetail) models.JobDetailJSONResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		response       models.JobDetailJSONResponse
		movementModels []models.ItemMovement
		it             models.Item
	)
	response.JobDetailID = item.JobDetailID
	response.JobID = item.JobID
	response.ItemID = item.ItemID
	response.Code = item.Code
	response.LineNum = item.LineNum
	response.Description = item.Description
	response.UnitPrice = item.UnitPrice
	response.Quantity = item.Quantity
	response.TaxType = item.TaxType
	response.TaxName = item.TaxName
	response.TaxRate = item.TaxRate
	response.DiscountAmount = item.DiscountAmount
	response.DiscountPercent = item.DiscountPercent
	response.BufferAmount = item.BufferAmount
	response.BufferPercent = item.BufferPercent
	response.LineTotal = item.LineTotal
	response.DiscountAmt = item.DiscountAmt
	response.BufferAmt = item.BufferAmt
	response.LineTotalTax = item.LineTotalTax
	response.LineSubTotal = item.LineSubTotal
	response.LineTotalTaxExcluded = item.LineTotalTaxExcluded
	response.QuantityPicked = item.QuantityPicked
	response.QuantityDelivered = item.QuantityDelivered
	response.ParentItemID = item.ParentItemID
	response.FourDPriceDynamicFormID = item.FourDPriceDynamicFormID
	response.TriggerInspectionMode = item.TriggerInspectionMode
	movements := make([]models.ItemMovementResponse, 0)
	db.Where("JobDetailID = ?", item.JobDetailID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&movementModels)
	for _, m := range movementModels {
		var movement models.ItemMovementResponse
		movement.ItemMovementID = m.ItemMovementID
		movement.JobDetailID = m.JobDetailID
		movement.Type = m.Type
		movement.Quantity = m.Quantity
		movements = append(movements, movement)
	}
	db.Where("ItemID = ?", item.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&it)
	response.ItemType = it.ItemType
	response.ItemMovements = movements
	return response
}
