package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// CreateCompanyInfor godoc
// @Summary CreateCompanyInfor
// @Description CreateCompanyInfor
// @Tags CompanyInfor
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param CompanyInfor body []models.CompanyInforResponse true "CreateCompanyInfor"
// @Success 200 {object} models.APIResponseData
// @Router /companiesinfor [post]
func CreateCompanyInfor(c *gin.Context) {
	apiName := "CreateCompanyInfor"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.CompanyInfor
		totalUpdatedRecord = 0
		isNew              = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.CompanyInfor
	)
	obj.PassBodyJSONToModelPOST(objectsJSON)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
			resultCreate *gorm.DB
		)
		resultFind := db.Where("CompanyID = ?", obj.CompanyID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&obj)
		if resultFind.RowsAffected <= 0 {
			obj.PassBodyJSONToModel(objectsJSON)
			resultCreate = db.Create(&obj)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			totalUpdatedRecord++
		}
	}
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND CompanyInforID = ?", obj.CompanyInforID).First(&obj)
	dataResponse = obj
	errors = errorsResponse
	if isNew {
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	} else {
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	}
	dataResponses := ConvertCompanyInforToResponse(requestHeader, dataResponse, lang)
	data = dataResponses
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateCompanyInfor godoc
// @Summary Update CompanyInfor
// @Description Update CompanyInfor
// @Tags CompanyInfor
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param CompanyInfor body []models.CompanyInforResponse true "Update CompanyInfor"
// @Success 200 {object} models.APIResponseData
// @Router /companiesinfor [put]
func UpdateCompanyInfor(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateCompanyInfor")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.CompanyInfor
	)
	resultFind := db.Where("CompanyInforID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModelUPDATE(bp)
		statusRee, msgRee := UpdateCompanyInforToJPREE(lang, resModel)
		if statusRee == 200 {
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				resultSave := db.Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// reload data
					responses := ConvertCompanyInforToResponse(requestHeader, resModel, lang)
					data = responses
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			status = statusRee
			msg = msgRee
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateCompanyInforToJPREE func
func UpdateCompanyInforToJPREE(lang string, companyInfor models.CompanyInfor) (int, interface{}) {
	var (
		status = 200
		msg    interface{}
	)
	reeHost := os.Getenv("SERVER_REE")
	reeHost = strings.TrimSuffix(reeHost, "/")
	URL := reeHost + "/companiesinfor"
	bodyJSON := make(map[string]interface{})
	bodyJSON["CompanyId"] = companyInfor.CompanyID
	bodyJSON["SupportPhone"] = companyInfor.SupportPhone
	statusRee, msgRee, _ := libs.RequestAPIRee(lang, "PUT", URL, bodyJSON, nil, nil)
	if statusRee != 200 {
		status = statusRee
		/* var reeResponse map[string]interface{}
		json.Unmarshal(dataRee, &reeResponse)
		vMsgRee, sMsgRee := reeResponse["msg"]
		if sMsgRee {
			msg = vMsgRee
		} */
		msg = msgRee
	}
	return status, msg
}

// ConvertCompanyInforToResponse func
func ConvertCompanyInforToResponse(requestHeader models.RequestHeader, item models.CompanyInfor, lang string) models.CompanyInforResponse {
	var (
		response models.CompanyInforResponse
	)
	response.CompanyInforID = item.CompanyInforID
	response.CompanyID = item.CompanyID
	response.TaxNumber = item.TaxNumber
	response.Address = item.Address
	response.SupportPhone = item.SupportPhone
	return response
}
