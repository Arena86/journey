package controllers

import (
	"encoding/json"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetPlan godoc
// @Summary GetPlan
// @Description GetPlan
// @Tags Plan
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /plans/{id} [get]
func GetPlansByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPlan")
	var (
		status    = libs.GetStatusSuccess()
		response  models.APIResponseData
		msg, data interface{}
	)
	ID := c.Param("id")
	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	URL := os.Getenv("SERVER_REE") + "/" + "plans" + "/" + ID
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data = reeResponse["data"]
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetPlan godoc
// @Summary GetPlan
// @Description GetPlan
// @Tags Plan
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /plans [get]
func GetPlan(c *gin.Context) {
	defer libs.RecoverError(c, "GetPlan")
	var (
		status    = libs.GetStatusSuccess()
		response  models.APIResponseData
		msg, data interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	URL := os.Getenv("SERVER_REE") + "/" + "plans"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		var dataPlans map[string]interface{}
		data = reeResponse["data"]
		subObj, _ := json.Marshal(data)
		json.Unmarshal([]byte(subObj), &dataPlans)
		dataPlans["PlansLine1"] = services.GetMessage(lang, "api.plan_plansline1")
		dataPlans["PlansLine2"] = services.GetMessage(lang, "api.plan_plansline2")
		data = dataPlans
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePlan godoc
// @Summary UpdatePlan
// @Description UpdatePlan
// @Tags Plan
// @Accept json
// @Produce json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PlanJSON body models.PlanJSON true "Update Plan"
// @Success 200 {object} models.APIResponseData
// @Router /plans [put]
func UpdatePlan(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePlan")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		msg, data      interface{}
		errorsResponse []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	var planJSON models.PlanJSON
	json.NewDecoder(c.Request.Body).Decode(&planJSON)
	URL := os.Getenv("SERVER_REE") + "/" + "plans"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "PUT", URL, planJSON, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
	} else {
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		vReeResponse, sReeResponse := reeResponse["data"]
		if sReeResponse {
			reeResponseDataJSON, errReeResponseDataJSON := json.Marshal(vReeResponse)
			if errReeResponseDataJSON == nil {
				msg = services.GetMessage(lang, "api.success")
				var license models.LicenseProduct
				json.Unmarshal(reeResponseDataJSON, &license)
				data = license
				// update license to memory, file
				libs.UpdateLicenseInfo(license)
			} else {
				status = 500
				msg = errReeResponseDataJSON.Error()
			}
		} else {
			status = 500
			msg = services.GetMessage(lang, "api.license_data_invalid")
		}
	}

	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
