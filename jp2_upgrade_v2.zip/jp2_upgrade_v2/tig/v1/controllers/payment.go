package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetPayment godoc
// @Summary Get Payment
// @Description Get Payment
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /payment [get]
func GetPayment(c *gin.Context) {
	defer libs.RecoverError(c, "GetPayment")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Payment
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("PaymentDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"JobID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPaymentToArrayResponse(requestHeader, lang, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPaymentByID godoc
// @Summary Get Payment By ID
// @Description Get Payment By ID
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param id path int true "Payment ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /payment/{id} [get]
func GetPaymentByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPaymentByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Payment
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"PaymentDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND PaymentID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertPaymentToResponse(requestHeader, lang, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePayment godoc
// @Summary Create Payment
// @Description Create Payment
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Payment body models.PaymentResponse true "Create Payment"
// @Success 200 {object} models.APIResponseData
// @Router /payment [post]
func CreatePayment(c *gin.Context) {
	apiName := "CreatePayment"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var bp map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &bp)
	var (
		obj models.Payment
	)
	obj.PassBodyJSONToModel(bp)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	for i := range obj.PaymentDetails {
		obj.PaymentDetails[i].CreatedBy = accountKey
		obj.PaymentDetails[i].ModifiedBy = accountKey
	}
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		resultCreate := db.Create(&obj)
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {
			totalUpdatedRecord++
			data = ConvertPaymentToResponse(requestHeader, lang, obj)
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePayment godoc
// @Summary Update Payment
// @Description Update Payment
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Payment body models.PaymentResponse true "Update Payment"
// @Success 200 {object} models.APIResponseData
// @Router /payment/{id} [put]
func UpdatePayment(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePayment")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.Payment
	)
	resultFind := db.Preload(
		"PaymentDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("PaymentID = ?", id).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		resModel.PaymentID = id
		resModel.ModifiedBy = accountKey
		for i := range resModel.PaymentDetails {
			resModel.PaymentDetails[i].CreatedBy = accountKey
			resModel.PaymentDetails[i].ModifiedBy = accountKey
		}
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO need to required > 0 for details
			resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				totalUpdatedRecord++
				// @TODO delete details
				var (
					arrSkipID []int
				)
				for _, detail := range resModel.PaymentDetails {
					arrSkipID = append(arrSkipID, detail.PaymentDetailID)
				}
				if len(arrSkipID) > 0 {
					// @TODO delete
					db.Where("PaymentID = ? AND PaymentDetailID not in (?)", resModel.PaymentID, arrSkipID).Model(&models.PaymentDetail{}).Updates(models.PaymentDetail{IsDeleted: true, ModifiedBy: accountKey})
				} else {
					// @TODO delete
					db.Where("PaymentID = ?", resModel.PaymentID).Model(&models.PaymentDetail{}).Updates(models.PaymentDetail{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
		resultRow := db.Preload(
			"PaymentDetails",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND PaymentID = ?", id).First(&resModel)
		if resultRow.RowsAffected > 0 {
			responses := ConvertPaymentToResponse(requestHeader, lang, resModel)
			data = responses
		} else {
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePayment godoc
// @Summary Delete Payment
// @Description Delete Payment
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Payment ID"
// @Success 200 {object} models.APIResponseData
// @Router /payment/{id} [delete]
func DeletePayment(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePayment")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.Payment
		)
		resultFind := db.Preload(
			"PaymentDetails",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("PaymentID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				db.Where("PaymentID = ?", resModel.PaymentID).Model(&models.PaymentDetail{}).Updates(models.PaymentDetail{IsDeleted: true, ModifiedBy: accountKey})
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// UpdatePaymentWithStripe godoc
// @Summary Update Payment With Stripe
// @Description Update Payment With Stripe
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Payment body models.PaymentResponse true "Update Payment"
// @Success 200 {object} models.APIResponseData
// @Router /updatepayment/{jobid} [post]
func UpdatePaymentWithStripe(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePaymentWithStripe")
	var (
		status                 = libs.GetStatusSuccess()
		requestHeader          models.RequestHeader
		response               models.APIResponseData
		msg, data, errors      interface{}
		errorsResponse         []models.ErrorResponse
		totalUpdatedRecord     = 0
		job                    models.Job
		resModel               models.Payment
		stripePaymentPOST      models.StripePaymentJP
		paymentRequest         models.PaymentRequest
		paymentDetail          models.PaymentDetail
		paymentDetails         []models.PaymentDetail
		locationPaymentMethods []models.LocationPaymentMethod
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &paymentRequest)

	sID := c.Param("jobid")
	jobID, _ := strconv.Atoi(sID)
	fmt.Println(jobID)
	resultFindJob := db.Select("JobID").Where("JobID = ?", jobID).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&job)

	if resultFindJob.RowsAffected > 0 {
		resultFind := db.Where("JobID = ?", jobID).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).First(&resModel)
		if resultFind.RowsAffected <= 0 {
			resModel.ModifiedBy = accountKey
			resModel.CreatedBy = accountKey
		} else {
			resModel.ModifiedBy = accountKey
		}

		// @TOTO Mapping Payment Method
		var (
			paymentMethods []models.Enumerator
			allowPayment   = false
		)
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ?", "PaymentMethod").Find(&paymentMethods)
		if len(paymentMethods) > 0 {
			for _, i := range paymentMethods {
				if strings.EqualFold(i.Caption, paymentRequest.PaymentMethodName) {
					paymentRequest.PaymentMethod = i.Status
					break
				}
			}
		}

		db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&locationPaymentMethods)

		if len(locationPaymentMethods) > 0 {
			for _, i := range locationPaymentMethods {
				if i.PaymentMethod == paymentRequest.PaymentMethod {
					allowPayment = true
					break
				}
			}
		}
		if allowPayment {
			resModel.JobID = jobID
			paymentDetail.CreatedBy = accountKey
			paymentDetail.ModifiedBy = accountKey
			paymentDetail.Amount = paymentRequest.Amount
			paymentDetail.PaymentMethod = paymentRequest.PaymentMethod
			paymentDetails = append(paymentDetails, paymentDetail)
			resModel.PaymentDetails = paymentDetails

			stripePaymentPOST.Amount = paymentRequest.Amount
			stripePaymentPOST.Currency = paymentRequest.Currency
			stripePaymentPOST.Card.FirstName = paymentRequest.Card.FirstName
			stripePaymentPOST.Card.LastName = paymentRequest.Card.LastName
			stripePaymentPOST.Card.Number = paymentRequest.Card.Number
			stripePaymentPOST.Card.ExpMonth = paymentRequest.Card.ExpMonth
			stripePaymentPOST.Card.ExpYear = paymentRequest.Card.ExpYear
			stripePaymentPOST.Card.CVC = paymentRequest.Card.CVC

			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				if paymentDetail.PaymentMethod != 1 {
					stripePaymentStatus, stripePaymentMsg, stripePaymentID := StripePayment(lang, accountKey, strconv.Itoa(jobID), stripePaymentPOST)
					if stripePaymentStatus == 200 {
						for i := range resModel.PaymentDetails {
							resModel.PaymentDetails[i].OnlinePaymentID = stripePaymentID
						}
						var resultSave *gorm.DB
						if resModel.PaymentID > 0 {
							resultSave = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
						} else {
							resultSave = db.Create(&resModel)
						}
						if resultSave.Error != nil {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						} else {
							totalUpdatedRecord++
							data = ConvertPaymentToResponse(requestHeader, lang, resModel)
						}
						if itemMsgError != "" {
							errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
							errorsResponse = append(errorsResponse, errResponse)
						}
					} else {
						errResponse := GetErrorResponseErrorMessage(0, stripePaymentMsg)
						errorsResponse = append(errorsResponse, errResponse)
					}
				} else {
					var resultSave *gorm.DB
					if resModel.PaymentID > 0 {
						resultSave = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					} else {
						resultSave = db.Create(&resModel)
					}
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						data = ConvertPaymentToResponse(requestHeader, lang, resModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}

			}

			if len(errorsResponse) == 0 {
				resultRow := db.Preload(
					"PaymentDetails",
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", jobID).First(&resModel)
				if resultRow.RowsAffected > 0 {
					responses := ConvertPaymentToResponse(requestHeader, lang, resModel)
					data = responses
				}
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.payment.method_not_allow_for_location"))
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePaymentDetail godoc
// @Summary Delete Payment Detail
// @Description Delete Payment Detail
// @Tags Payment
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Payment ID"
// @Success 200 {object} models.APIResponseData
// @Router /deletepayment/{id} [delete]
func DeletePaymentDetail(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePaymentDetail")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")

	var (
		resModel models.PaymentDetail
	)
	resultFind := db.Where("PaymentDetailID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", strID).First(&resModel)
	if resultFind.RowsAffected > 0 {
		if resModel.PaymentMethod == 1 { // CASH
			resultSave := db.Where("PaymentDetailID = ? AND PaymentMethod = 1", strID).Model(&models.PaymentDetail{}).Updates(&models.PaymentDetail{IsDeleted: true, ModifiedBy: accountKey})
			if resultSave.Error != nil {
				errResponse := GetErrorResponseErrorMessage(0, resultSave.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.payment.cannot_delete_card"))
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPaymentToArrayResponse func
func ConvertArrayPaymentToArrayResponse(requestHeader models.RequestHeader, lang string, items []models.Payment) []models.PaymentResponse {
	responses := make([]models.PaymentResponse, 0)
	for _, item := range items {
		response := ConvertPaymentToResponse(requestHeader, lang, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPaymentToResponse func
func ConvertPaymentToResponse(requestHeader models.RequestHeader, lang string, item models.Payment) models.PaymentResponse {
	var (
		response models.PaymentResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.PaymentID = item.PaymentID
	response.JobID = item.JobID
	details := make([]models.PaymentDetailResponse, 0)
	for _, de := range item.PaymentDetails {
		var (
			detail models.PaymentDetailResponse
		)
		detail.PaymentDetailID = de.PaymentDetailID
		detail.PaymentID = de.PaymentID
		detail.PaymentMethod = de.PaymentMethod
		detail.Amount = de.Amount
		var enumPaymentMethod models.Enumerator
		resultFindEnumeratorPayment := db.Where("FieldName = ? AND Status = ?", "PaymentMethod", de.PaymentMethod).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&enumPaymentMethod)
		if resultFindEnumeratorPayment.RowsAffected > 0 {
			if enumPaymentMethod.TranslationKey != "" && enumPaymentMethod.TranslationKey != services.GetMessage(lang, enumPaymentMethod.TranslationKey) {
				detail.PaymentMethodName = services.GetMessage(lang, enumPaymentMethod.TranslationKey)
			} else {
				detail.PaymentMethodName = enumPaymentMethod.Caption
			}
		}
		details = append(details, detail)
	}
	response.PaymentDetails = details
	return response
}
