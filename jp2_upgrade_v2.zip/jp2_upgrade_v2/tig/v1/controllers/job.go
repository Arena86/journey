package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	smslogs "jpapi/tig/v1/logs/sms"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"github.com/printfhome/goutils"
	"github.com/tomasen/realip"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// SelectAllJobs godoc
// @Summary Select All Jobs
// @Description Select All Jobs
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /selectalljobs [get]
func SelectAllJobs(c *gin.Context) {
	defer libs.RecoverError(c, "SelectAllJobs")
	var (
		status          = libs.GetStatusSuccess()
		jobs            []models.Job
		requestHeader   models.RequestHeader
		response        models.APIResponseData
		msg             interface{}
		isSearch        = false
		includeCombined = true
		includeMultiple = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	vSearch, sSearch := libs.GetQueryParam("Search", c)
	if sSearch {
		isSearch = true
	}
	vIncludeCombined, sIncludeCombined := libs.GetQueryParam("includecombined", c)
	if sIncludeCombined {
		includeCombined, _ = strconv.ParseBool(vIncludeCombined)
	}
	vIncludeMultiple, sIncludeMultiple := libs.GetQueryParam("includemultiple", c)
	if sIncludeMultiple {
		includeMultiple, _ = strconv.ParseBool(vIncludeMultiple)
	}

	isrecurring := false
	vIsrecurring, sIsrecurring := libs.GetQueryParam("isrecurring", c)
	if sIsrecurring {
		isrecurring, _ = strconv.ParseBool(vIsrecurring)
	}

	// Paging
	/*vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)*/

	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	if !includeCombined {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsCombinedChild, 0) = 0")
	}

	if !includeMultiple {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1  AND IFNULL(IsMultipleChild, 0) = 0")
	}
	// Filter
	bp = bp.Where("IsRecurring = ?", isrecurring)
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}
	if isSearch {
		var (
			jobDateSearchs []models.JobSearchField
		)
		dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//dbP.LogMode(true)
		dbP.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsSelected, 0) <> 0").Find(&jobDateSearchs)
		sqlQuery := ""
		sqlWhere := ""
		concatString := "CONCAT("
		for _, p := range jobDateSearchs {
			if p.FieldName == "JobTypeName" || p.FieldName == "Priority" {
				p.FieldName = "Caption"
			}
			concatString += p.FieldName
			concatString += ","
			concatString += "' '"
			concatString += ","
		}
		concatString = strings.TrimSuffix(concatString, ",")
		concatString += ")"
		sqlQuery = `SELECT jo.JobID FROM jobs jo 
		LEFT JOIN businesspartners bp ON jo.BusinessPartnerID = bp.BusinessPartnerID
		LEFT JOIN jobtasks jt ON jo.JobID = jt.JobTaskID
		LEFT JOIN phones ph ON  (ph.EntityID = bp.BusinessPartnerID AND ph.Entity = 'businesspartners')
		LEFT JOIN enums en ON (jo.JobType = en.Status AND en.FieldName = 'JobType') OR  (jo.Priority = en.Status AND en.FieldName = 'Priority')
		`
		sqlWhere += "WHERE " + concatString + ` LIKE '%` + vSearch + `%'`

		arrID := make([]int, 0)
		sqlQuery += sqlWhere + `  GROUP BY jo.JobID`
		rows, err := dbP.Raw(sqlQuery).Rows()
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var ID int
				rows.Scan(&ID)
				if ID > 0 {
					arrID = append(arrID, ID)
				}
			}
		}

		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		bp = bp.Where("JobID IN (?)", arrID)
	} else {
		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		arrString := []string{
			"EstimateNumber", "JobNumber", "InvoiceNumber", "CreditNoteNumber", "AdditionalResources",
		}
		bp = libs.FilterString(arrString, bp, c)
		arrInteger := []string{
			"JobType", "LocationID", "BusinessPartnerID", "Status", "InProgressStatus",
			"PrimaryResource", "EstimatedTravelTime", "EstimatedDistance",
		}
		bp = libs.FilterInteger(arrInteger, bp, c)
		/* arrDateTime := []string{
			"PreferredDateTime", "JobDate", "ScheduleStartDateTime",
			"ScheduleEndDateTime", "DepartureDateTime", "EstimatedArrivalDateTime",
			"EstimatedArrivalDateTimeAfterDeparture", "ArrivalDateTime",
			"JobStartDateTime", "JobEndDateTime",
		}
		bp = libs.FilterDateTime(arrDateTime, bp, c) */

		arrDateTime := []string{
			"JobDate", "ScheduleStartDateTime", "ScheduleEndDateTime",
		}
		bp = libs.FilterDateTimeWithSpaceInKey(arrDateTime, bp, c)

		jobDateSearch := "JobDate"
		jobPeriod, statusPeriod := libs.GetQueryParam("Period", c)
		if statusPeriod {
			timeNow := time.Now()
			if jobPeriod == models.TW {
				// this week from get all jobs
				beginningOfTWeek := goutils.TimeBeginningOfWeek(timeNow, false).Format("2006-01-02")
				endOfTWeek := goutils.TimeEndOfWeek(timeNow, false).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfTWeek, endOfTWeek)
			} else if jobPeriod == models.NW {
				// next week from get all jobs
				beginningOfNextWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				endOfNextWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfNextWeek, endOfNextWeek)
			} else if jobPeriod == models.FT {
				// Future from get all jobs
				toDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') > DATE_FORMAT(?,'%Y-%m-%d')", toDay)
			} else if jobPeriod == models.LW {
				// last week
				beginningOfLastWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				endOfLastWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfLastWeek, endOfLastWeek)
			} else if jobPeriod == models.TM {
				// tomorrow - only tomorrow
				tomorrowDay := timeNow.AddDate(0, 0, 1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", tomorrowDay)
			} else if jobPeriod == models.YD {
				// only yester day
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.PV {
				// previous from yesterday and before -> yesterday -> past
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.TD {
				todayDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", todayDay)
			}
		}

		vCompanyName, sCompanyName := libs.GetQueryParam("CompanyName", c)
		if sCompanyName {
			dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

			var (
				partners []models.BusinessPartner
			)
			arrID := make([]int, 0)
			dbP.Where("CompanyName like ?", "%"+vCompanyName+"%").Find(&partners)
			for _, p := range partners {
				arrID = append(arrID, p.BusinessPartnerID)
			}
			if len(arrID) <= 0 {
				arrID = append(arrID, -1)
			}
			bp = bp.Where("BusinessPartnerID in (?)", arrID)
		}

		// Sort
		bp = libs.SortDataOnParam(bp, c, "CompanyName")
		companySort := libs.GetSortValueFromKey(c, "CompanyName")
		if companySort != "" {
			dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			//

			var partners []models.BusinessPartner
			arrBusinessPartnerIDSort := make([]int, 0)
			dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("CompanyName " + companySort).Find(&partners)
			for _, partner := range partners {
				arrBusinessPartnerIDSort = append(arrBusinessPartnerIDSort, partner.BusinessPartnerID)
			}
			if len(arrBusinessPartnerIDSort) > 0 {
				strJoin := libs.IntJoin(arrBusinessPartnerIDSort)
				if strJoin != "" {
					bp = bp.Order("FIELD(BusinessPartnerID," + strJoin + ")")
				}
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobs).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(jobs) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySelectJobsToArrayResponse(requestHeader, jobs, lang, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetJob godoc
// @Summary Get Job
// @Description Get Job
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /job [get]
func GetJob(c *gin.Context) {
	defer libs.RecoverError(c, "GetJob")
	var (
		status            = libs.GetStatusSuccess()
		jobs              []models.Job
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg               interface{}
		isSearch          = false
		includeCombined   = true
		includeMultiple   = true
		includeInspection = true
		forList           = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	vSearch, sSearch := libs.GetQueryParam("Search", c)
	if sSearch {
		isSearch = true
	}
	vIncludeCombined, sIncludeCombined := libs.GetQueryParam("includecombined", c)
	if sIncludeCombined {
		includeCombined, _ = strconv.ParseBool(vIncludeCombined)
	}
	vIncludeMultiple, sIncludeMultiple := libs.GetQueryParam("includemultiple", c)
	if sIncludeMultiple {
		includeMultiple, _ = strconv.ParseBool(vIncludeMultiple)
	}
	vIncludeInspection, sIncludInspection := libs.GetQueryParam("includeinspection", c)
	if sIncludInspection {
		includeInspection, _ = strconv.ParseBool(vIncludeInspection)
	}
	vForList, sForList := libs.GetQueryParam("list", c)
	if sForList {
		forList, _ = strconv.ParseBool(vForList)
	}
	isrecurring := false
	vIsrecurring, sIsrecurring := libs.GetQueryParam("isrecurring", c)
	if sIsrecurring {
		isrecurring, _ = strconv.ParseBool(vIsrecurring)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	if !forList {
		bp = bp.Preload("AdditionalFiles", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("RecurringJob", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp = bp.Preload("RecurringJob.RecurringSkips", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	} else {
		bp = bp.Select("JobID,JobNumber,BusinessPartnerID, JobNumber,JobDate,JobType,ContactDetails,ContactPhoneNumber,CreditNoteNumber,EstimateNumber,InvoiceNumber,ResourceType,TravelCharge,TravelChargeMode,Status,InProgressStatus,JobTaskStatus,ErpInvoiceStatus,DistanceChargeTaxRate,Subtotal,TotalBufferAmount,InvoiceNumber,TotalDiscountAmount,TotalJob,TotalTax,TravelTimeChargeTaxRate,Priority,IsInspection,InspectionForJobID")
	}
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	if !includeCombined {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsCombinedChild, 0) = 0")
	}

	if !includeMultiple {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1  AND IFNULL(IsMultipleChild, 0) = 0")
	}
	// Filter
	bp = bp.Where("IsRecurring = ?", isrecurring)
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}
	if isSearch {
		var (
			jobDateSearchs []models.JobSearchField
		)
		dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//dbP.LogMode(true)
		dbP.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsSelected, 0) <> 0").Find(&jobDateSearchs)
		sqlQuery := ""
		sqlWhere := ""
		concatString := "CONCAT("
		for _, p := range jobDateSearchs {
			if p.FieldName == "JobTypeName" || p.FieldName == "Priority" {
				p.FieldName = "Caption"
			}
			concatString += p.FieldName
			concatString += ","
			concatString += "' '"
			concatString += ","
		}
		concatString = strings.TrimSuffix(concatString, ",")
		concatString += ")"
		sqlQuery = `SELECT jo.JobID FROM jobs jo 
		LEFT JOIN businesspartners bp ON jo.BusinessPartnerID = bp.BusinessPartnerID
		LEFT JOIN jobtasks jt ON jo.JobID = jt.JobTaskID
		LEFT JOIN phones ph ON  (ph.EntityID = bp.BusinessPartnerID AND ph.Entity = 'businesspartners')
		LEFT JOIN enums en ON (jo.JobType = en.Status AND en.FieldName = 'JobType') OR  (jo.Priority = en.Status AND en.FieldName = 'Priority')
		`
		sqlWhere += "WHERE " + concatString + ` LIKE '%` + vSearch + `%'`

		arrID := make([]int, 0)
		sqlQuery += sqlWhere + `  GROUP BY jo.JobID`
		rows, err := dbP.Raw(sqlQuery).Rows()
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var ID int
				rows.Scan(&ID)
				if ID > 0 {
					arrID = append(arrID, ID)
				}
			}
		}

		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		bp = bp.Where("JobID IN (?)", arrID)
	} else {
		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		arrString := []string{
			"EstimateNumber", "JobNumber", "InvoiceNumber", "CreditNoteNumber", "AdditionalResources", "InProgressStatus",
		}
		bp = libs.FilterString(arrString, bp, c)
		arrInteger := []string{
			"JobType", "LocationID", "BusinessPartnerID", "Status",
			"PrimaryResource", "EstimatedTravelTime", "EstimatedDistance",
		}
		bp = libs.FilterInteger(arrInteger, bp, c)
		/* arrDateTime := []string{
			"PreferredDateTime", "JobDate", "ScheduleStartDateTime",
			"ScheduleEndDateTime", "DepartureDateTime", "EstimatedArrivalDateTime",
			"EstimatedArrivalDateTimeAfterDeparture", "ArrivalDateTime",
			"JobStartDateTime", "JobEndDateTime",
		}
		bp = libs.FilterDateTime(arrDateTime, bp, c) */

		arrDateTime := []string{
			"JobDate", "ScheduleStartDateTime", "ScheduleEndDateTime",
		}
		bp = libs.FilterDateTimeWithSpaceInKey(arrDateTime, bp, c)

		jobDateSearch := "JobDate"
		jobPeriod, statusPeriod := libs.GetQueryParam("Period", c)
		if statusPeriod {
			timeNow := time.Now()
			if jobPeriod == models.TW {
				// this week from get all jobs
				beginningOfTWeek := goutils.TimeBeginningOfWeek(timeNow, false).Format("2006-01-02")
				endOfTWeek := goutils.TimeEndOfWeek(timeNow, false).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfTWeek, endOfTWeek)
			} else if jobPeriod == models.NW {
				// next week from get all jobs
				beginningOfNextWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				endOfNextWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfNextWeek, endOfNextWeek)
			} else if jobPeriod == models.FT {
				// Future from get all jobs
				toDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') > DATE_FORMAT(?,'%Y-%m-%d')", toDay)
			} else if jobPeriod == models.LW {
				// last week
				beginningOfLastWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				endOfLastWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfLastWeek, endOfLastWeek)
			} else if jobPeriod == models.TM {
				// tomorrow - only tomorrow
				tomorrowDay := timeNow.AddDate(0, 0, 1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", tomorrowDay)
			} else if jobPeriod == models.YD {
				// only yester day
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.PV {
				// previous from yesterday and before -> yesterday -> past
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.TD {
				todayDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", todayDay)
			}
		}

		vCompanyName, sCompanyName := libs.GetQueryParam("CompanyName", c)
		if sCompanyName {
			dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			var (
				partners []models.BusinessPartner
			)
			arrID := make([]int, 0)
			dbP.Where("CompanyName like ?", "%"+vCompanyName+"%").Find(&partners)
			for _, p := range partners {
				arrID = append(arrID, p.BusinessPartnerID)
			}
			if len(arrID) <= 0 {
				arrID = append(arrID, -1)
			}
			bp = bp.Where("BusinessPartnerID in (?)", arrID)
		}

		// UDFs
		arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Job{}.TableName())
		bp = libs.FilterUDFs(arrQueries, bp)
		// Sort
		bp = libs.SortDataOnParam(bp, c, "CompanyName")
		companySort := libs.GetSortValueFromKey(c, "CompanyName")
		if companySort != "" {
			dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			var partners []models.BusinessPartner
			arrBusinessPartnerIDSort := make([]int, 0)
			dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("CompanyName " + companySort).Find(&partners)
			for _, partner := range partners {
				arrBusinessPartnerIDSort = append(arrBusinessPartnerIDSort, partner.BusinessPartnerID)
			}
			if len(arrBusinessPartnerIDSort) > 0 {
				strJoin := libs.IntJoin(arrBusinessPartnerIDSort)
				if strJoin != "" {
					bp = bp.Order("FIELD(BusinessPartnerID," + strJoin + ")")
				}
			}
		}
	}

	if !includeInspection {
		bp = bp.Where("JobID not in (SELECT  InspectionForJobID FROM `jobs` WHERE InspectionForJobID > 0 AND Status <> 7  AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 GROUP BY InspectionForJobID)")
	}

	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobs).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(jobs) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayJobsToArrayResponse(requestHeader, jobs, lang, false, includeInspection, forList)
	//if !forList {
	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Job{}.TableName())

		udfParams := make([]string, 0)

		vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
		if sIsInvoice {
			bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
			if eIsInvoice == nil {
				if bIsInvoice {
					udfParams = append(udfParams, "invoices")
				}
			}
		}

		vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
		if sIsEstimate {
			bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
			if eIsEstimate == nil {
				if bIsEstimate {
					udfParams = append(udfParams, "estimates")
				}
			}
		}

		vIsCreditnote, sIsCreditnote := libs.GetQueryParam("iscreditnote", c)
		if sIsCreditnote {
			bIsCreditnote, eIsCreditnote := strconv.ParseBool(vIsCreditnote)
			if eIsCreditnote == nil {
				if bIsCreditnote {
					udfParams = append(udfParams, "creditnotes")
				}
			}
		}

		vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
		if sIsJob {
			bIsJob, eIsJob := strconv.ParseBool(vIsJob)
			if eIsJob == nil {
				if bIsJob {
					udfParams = append(udfParams, "jobs")
				}
			}
		}

		if len(udfParams) > 0 {
			dbu = dbu.Where("UDFKey in (?)", udfParams)
		}

		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		// @TOTO Move UDF to outsite
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, b.JobID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}
	//}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetJobByID godoc
// @Summary Get Job By ID
// @Description Get Job  By ID
// @Tags Job
// @Accept  json
// @Produce  json
// @Param id path int true "Job ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /job/{id} [get]
func GetJobByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobByID")
	var (
		status        = libs.GetStatusSuccess()
		jobs          models.Job
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Preload("AdditionalFiles", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("RecurringJob", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("RecurringJob.RecurringSkips", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", ID)
	resultRow := bp.First(&jobs)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertJobToResponse(requestHeader, jobs, lang, false)

		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Job{}.TableName())

		udfParams := make([]string, 0)

		vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
		if sIsInvoice {
			bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
			if eIsInvoice == nil {
				if bIsInvoice {
					udfParams = append(udfParams, "invoices")
				}
			}
		}

		vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
		if sIsEstimate {
			bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
			if eIsEstimate == nil {
				if bIsEstimate {
					udfParams = append(udfParams, "estimates")
				}
			}
		}

		vIsCreditnote, sIsCreditnote := libs.GetQueryParam("iscreditnote", c)
		if sIsCreditnote {
			bIsCreditnote, eIsCreditnote := strconv.ParseBool(vIsCreditnote)
			if eIsCreditnote == nil {
				if bIsCreditnote {
					udfParams = append(udfParams, "creditnotes")
				}
			}
		}

		vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
		if sIsJob {
			bIsJob, eIsJob := strconv.ParseBool(vIsJob)
			if eIsJob == nil {
				if bIsJob {
					udfParams = append(udfParams, "jobs")
				}
			}
		}
		if len(udfParams) > 0 {
			dbu = dbu.Where("UDFKey in (?)", udfParams)
		}
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		itemsResponse.UDF = make(map[string]interface{}) // declare field as a map[string]string
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, itemsResponse.JobID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			itemsResponse.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		itemsResponse.UDFs = udfResponses
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateJob godoc
// @Summary Create Job
// @Description Create Job
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Job body models.Job true "Create Job"
// @Success 200 {object} models.APIResponseData
// @Router /job [post]
func CreateJob(c *gin.Context) {
	defer libs.RecoverError(c, "CreateJob")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Job
		totalUpdatedRecord = 0
		inspectionJobs     = make([]models.Job, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Job, 0)
	// Convert json body to object
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		job models.Job
	)
	job.PassBodyJSONToModel(bp)

	// validate license
	var (
		isLicense = false
		msgData   string
	)
	companyID := c.Request.Header.Get("companyid")
	licenseType := ""
	if job.IsJob {
		licenseType = "job"
	}

	if licenseType != "" {
		status, msg, isLicense, msgData, _, _ = libs.CheckLicenseFunc(requestHeader, lang, companyID, licenseType)
		if status == 200 {
			if !isLicense {
				status = 422
				msg = msgData
			}
		}
	}
	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
		errors = errorsResponse
	}
	// validate license end

	if status == 200 {
		job.CreatedBy = accountKey
		job.ModifiedBy = accountKey
		CheckDocumentSequencesBeforeCreate(requestHeader)
		var (
			sequencyModel     models.DocumentSequency
			jobNumPrefix      models.Prefix
			estimateNumPrefix models.Prefix
			invoiceNumPrefix  models.Prefix
			creditNotePrefix  models.Prefix
		)
		ResetDocumentSequencesIfGreaterLength(requestHeader)
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
		db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
		db.Where("DocumentSequence = ?", "EstimateNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&estimateNumPrefix)
		db.Where("DocumentSequence = ?", "InvoiceNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&invoiceNumPrefix)
		db.Where("DocumentSequence = ?", "CreditNoteNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&creditNotePrefix)
		job.GenerateDefaultValue(sequencyModel, jobNumPrefix, estimateNumPrefix, invoiceNumPrefix, creditNotePrefix)
		job.GenerateNewSequenceNumberIfExistInSameDay(db, jobNumPrefix, estimateNumPrefix, invoiceNumPrefix, creditNotePrefix)
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(job)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO validate for address
			if len(job.JobDetails) > 0 {
				jobDetailValid := make([]models.JobDetail, 0)
				for _, jobDetail := range job.JobDetails {
					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(jobDetail)
					if err != nil {
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
						}
					} else {
						jobDetail.LineSubTotal = jobDetail.UnitPrice * jobDetail.Quantity
						jobDetail.DiscountAmount = jobDetail.LineSubTotal * (jobDetail.DiscountPercent / 100)
						jobDetail.BufferAmount = jobDetail.LineSubTotal * (jobDetail.BufferPercent / 100)
						jobDetail.LineTotalTaxExcluded = jobDetail.LineSubTotal - jobDetail.DiscountAmount + jobDetail.BufferAmount
						jobDetail.LineTotalTax = jobDetail.LineTotalTaxExcluded * (jobDetail.TaxRate / 100)
						jobDetailValid = append(jobDetailValid, jobDetail)
					}
				}
				job.JobDetails = jobDetailValid
			}
			if job.JobPickup != nil {
				job.JobPickup.CreatedBy = accountKey
				job.JobPickup.ModifiedBy = accountKey
			}
			if job.JobDelivery != nil {
				job.JobDelivery.CreatedBy = accountKey
				job.JobDelivery.ModifiedBy = accountKey
			}
			if job.JobOnSite != nil {
				job.JobOnSite.CreatedBy = accountKey
				job.JobOnSite.ModifiedBy = accountKey
			}
			if job.JobInStore != nil {
				job.JobInStore.CreatedBy = accountKey
				job.JobInStore.ModifiedBy = accountKey
			}
			if job.JobMultiple != nil {
				job.JobMultiple.CreatedBy = accountKey
				job.JobMultiple.ModifiedBy = accountKey
			}
			if job.JobCombined != nil {
				job.JobCombined.CreatedBy = accountKey
				job.JobCombined.ModifiedBy = accountKey
			}
			if job.JobResourcePickUp != nil {
				job.JobResourcePickUp.CreatedBy = accountKey
				job.JobResourcePickUp.ModifiedBy = accountKey
			}
			if job.JobResourceDelivery != nil {
				job.JobResourceDelivery.CreatedBy = accountKey
				job.JobResourceDelivery.ModifiedBy = accountKey
			}
			if len(job.JobDetails) > 0 {
				for i := range job.JobDetails {
					job.JobDetails[i].CreatedBy = accountKey
					job.JobDetails[i].ModifiedBy = accountKey
				}
			}
			if len(job.JobTasks) > 0 {
				for i := range job.JobTasks {
					job.JobTasks[i].CreatedBy = accountKey
					job.JobTasks[i].ModifiedBy = accountKey
					if job.JobMultiple != nil {
						job.JobTasks[i].IsSuburb = false
						job.JobTasks[i].IsFullAddress = true
					}
					if job.JobCombined != nil {
						job.JobTasks[i].IsSuburb = false
						job.JobTasks[i].IsFullAddress = true
					}
				}
			}
			if job.RecurringJob != nil {
				job.RecurringJob.CreatedBy = accountKey
				job.RecurringJob.ModifiedBy = accountKey
				for i := range job.RecurringJob.RecurringSkips {
					job.RecurringJob.RecurringSkips[i].CreatedBy = accountKey
					job.RecurringJob.RecurringSkips[i].ModifiedBy = accountKey
				}
			}

			// @TODO check for jobcombined & jobMultible
			var (
				res interface{}
				val string
			)
			var arrMultipleJobID []int
			val, res = services.ConvertJSONValueToVariable("isMultiple", bp)
			if res != nil {
				isMultiple, _ := strconv.ParseBool(val)
				if isMultiple {
					val, res = services.ConvertJSONValueToVariable("jobMultiple", bp)
					if res != nil {
						var objectsJobMultiple models.JobMultipleRequest
						jobMultipleJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(jobMultipleJSON, &objectsJobMultiple)
							if len(objectsJobMultiple.MultipleJobs) > 0 {
								var jobSelections []models.JobSelection
								serviceTimeInMinutes := 0
								for _, jobMultipleID := range objectsJobMultiple.MultipleJobs {
									var jobSelection models.JobSelection
									jobSelection.CreatedBy = accountKey
									jobSelection.ModifiedBy = accountKey
									jobSelection.RelatedJobID = jobMultipleID.JobID
									jobSelection.Sort = jobMultipleID.Sort
									jobSelections = append(jobSelections, jobSelection)
									arrMultipleJobID = append(arrMultipleJobID, jobMultipleID.JobID)
									var (
										mJobTask []models.JobTask
									)
									resultFindJobTask := db.Where("JobID = ?", jobMultipleID.JobID).
										Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&mJobTask)
									if resultFindJobTask.RowsAffected > 0 {
										for _, jt := range mJobTask {
											serviceTimeInMinutes = serviceTimeInMinutes + jt.ServiceTimeInMinutes
										}
									}
								}
								if len(job.JobTasks) > 0 {
									job.JobTasks[0].ServiceTimeInMinutes = serviceTimeInMinutes
								}
								job.JobSelections = jobSelections
							}
						}
					}
				}
			}
			var arrCombinedJobID []int
			val, res = services.ConvertJSONValueToVariable("isCombined", bp)
			if res != nil {
				isCombined, _ := strconv.ParseBool(val)
				if isCombined {
					val, res = services.ConvertJSONValueToVariable("jobCombined", bp)
					if res != nil {
						var objectsJobCombined models.JobCombinedRequest
						jobCombinedJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(jobCombinedJSON, &objectsJobCombined)
							if len(objectsJobCombined.CombinedJobs) > 0 {
								var jobSelections []models.JobSelection
								for _, jobCombinedID := range objectsJobCombined.CombinedJobs {
									var jobSelection models.JobSelection
									jobSelection.CreatedBy = accountKey
									jobSelection.ModifiedBy = accountKey
									jobSelection.RelatedJobID = jobCombinedID.JobID
									jobSelection.HasSequence = jobCombinedID.HasSequence
									jobSelection.Sort = jobCombinedID.Sort
									jobSelections = append(jobSelections, jobSelection)
									arrCombinedJobID = append(arrCombinedJobID, jobCombinedID.JobID)
								}
								job.JobSelections = jobSelections
							}
						}
					}
				}
			}

			errMsgInspectionJob := ValidateInspectionJobSettingBeforeProcessJob(requestHeader, lang, accountKey, job, bp)
			if errMsgInspectionJob == "" {
				resultCreate := db.Create(&job)

				/* totalUpdatedRecord++
				dataResponse = append(dataResponse, job) */

				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {

					// Update Job Combined
					if len(arrCombinedJobID) > 0 {
						db.Where("JobID IN (?)", arrCombinedJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsCombinedChild": true})
					}

					// Update Job Multiple
					if len(arrMultipleJobID) > 0 {
						db.Where("JobID IN (?)", arrMultipleJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsMultipleChild": true})
					}
					totalUpdatedRecord++
					dataResponse = append(dataResponse, job)
					IncreaseDocumentSequencesAfterCreateJob(job.IsJob, job.IsEstimate, job.IsInvoice, job.IsCreditNote, requestHeader)
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "JobID", job.JobID)
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
						}
					}
					// @TODO assign customer to businesspartnerlocation
					var (
						businessLocationModel  models.BusinessPartnerLocation
						locationModel          models.Location
						strLocations           []string
						businessLocationModels []models.BusinessPartnerLocation
					)
					db.Where("LocationID = ?", job.LocationID).First(&locationModel)
					if job.BusinessPartnerID > 0 && job.LocationID > 0 {
						resultFindBusinessLocation := db.Where("BusinessPartnerID = ? AND LocationID = ?", job.BusinessPartnerID, job.LocationID).First(&businessLocationModel)
						if resultFindBusinessLocation.RowsAffected <= 0 {
							db.Where("LocationID = ?", job.LocationID).First(&locationModel)
							businessLocationModel.BusinessPartnerID = job.BusinessPartnerID
							businessLocationModel.LocationID = job.LocationID
							businessLocationModel.LocationGroupID = locationModel.LocationGroupID
							businessLocationModel.CreatedBy = accountKey
							db.Create(&businessLocationModel)
						} else {
							businessLocationModel.LocationGroupID = locationModel.LocationGroupID
							businessLocationModel.ModifiedBy = accountKey

							db.Save(&businessLocationModel)
						}

						// @TODO Update BP location
						resultFindBusinessLocations := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Find(&businessLocationModels)
						if resultFindBusinessLocations.RowsAffected > 0 {
							var businessPartner models.BusinessPartner
							for _, location := range businessLocationModels {
								strLocations = append(strLocations, strconv.Itoa(location.LocationID))
							}
							resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Find(&businessPartner)
							if resultFindBusinessPartner.RowsAffected > 0 {
								businessPartner.LocationID = strings.Join(strLocations, ",")
								db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&businessPartner)
							}
						}
					}

					// @TODO update travel calculation
					//CreateTravelCalculation(requestHeader, job.TravelCalculation, job.JobID)
					// @TODO update jobtaskID to jobpickups, jobdeliveries,...
					UpdateJobTaskIDToSubJobAfterProcessJob(requestHeader, job)

					// @TODO create job4dprices
					var job4DPriceModels = make([]models.Job4DPrice, 0)
					job4DPriceModels = GetAllJob4DPricesFromJSON(requestHeader, accountKey, job, bp)
					if len(job4DPriceModels) > 0 {
						db.Create(&job4DPriceModels)
						// @TODO create inspection job
						var inspectionJobForSkips []models.InspectionJobForSkip
						inspectionJobs = CreateInspectionJobFunc(requestHeader, lang, accountKey, job4DPriceModels, "", inspectionJobForSkips)
					}

					// Update 4DPrice Dynamic Form
					UpdateDynamicFormFor4DPrice(requestHeader, accountKey, job, bp, lang)

					// @TODO create new job for estimate
					//AutoGenerateNewJobByJobEstimate(requestHeader, lang, accountKey, job.JobID)

					// Async data To DynamoDB
					if job.IsJob || job.IsEstimate {
						var auditModel models.AuditDynamoDB
						auditModel.JobID = job.JobID
						auditModel.UserID = libs.GetUserIDFromAccountKey(requestHeader, accountKey)
						if job.IsJob {
							auditModel.DocType = models.AuditDocTypeJob
						} else {
							auditModel.DocType = models.AuditDocTypeEstimate
						}
						auditModel.Type = models.AuditTypeInsert

						objectJson := ""
						byeObjectJson, errObjectJson := json.Marshal(bp)
						if errObjectJson == nil {
							objectJson = string(byeObjectJson)
						}
						auditModel.ObjectJson = objectJson

						libs.AsyncToDynamoDB(c, auditModel)
					}

				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, errMsgInspectionJob)
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
		errors = errorsResponse
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
		var (
			jobRes models.Job
		)
		arrID := make([]int, 0)
		for _, v := range dataResponse {
			arrID = append(arrID, v.JobID)
		}
		if len(arrID) > 0 {
			db.Preload(
				"AdditionalFiles",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobDetails",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobTasks",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobPickup",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobDelivery",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobOnSite",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobInStore",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobMultiple",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobCombined",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobResourcePickUp",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"JobResourceDelivery",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"RecurringJob",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Preload(
				"RecurringJob.RecurringSkips",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("JobID in (?)", arrID).First(&jobRes)
			dataResponses := ConvertJobToResponse(requestHeader, jobRes, lang, true)
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Job{}.TableName())
			udfParams := make([]string, 0)
			if jobRes.IsInvoice {
				udfParams = append(udfParams, "invoices")
			}
			if jobRes.IsEstimate {
				udfParams = append(udfParams, "estimates")
			}
			if jobRes.IsCreditNote {
				udfParams = append(udfParams, "creditnotes")
			}
			if jobRes.IsJob {
				udfParams = append(udfParams, "jobs")
			}
			if len(udfParams) > 0 {
				dbu = dbu.Where("UDFKey in (?)", udfParams)
			}
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses.UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, jobRes.JobID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses.UDFs = udfResponses
			var arrInsJob = make([]models.InspectionJobDateResponse, 0)

			for _, insJob := range inspectionJobs {
				var inspectionJobsResponse models.InspectionJobDateResponse
				inspectionJobsResponse.JobID = insJob.JobID
				inspectionJobsResponse.JobNumber = insJob.JobNumber
				inspectionJobsResponse.JobDate = insJob.JobDate
				if len(insJob.JobDetails) > 0 {
					inspectionJobsResponse.ForJobTaskType = *insJob.JobDetails[0].JobTaskType
					inspectionJobsResponse.ForJobTaskTypeName, inspectionJobsResponse.ForJobTaskTypeIcon = libs.GetEnum(requestHeader, inspectionJobsResponse.ForJobTaskType, "JobType", lang)
				}
				if insJob.JobOnSite != nil {
					inspectionJobsResponse.Address = insJob.JobOnSite.Address
					inspectionJobsResponse.ContactDetails = insJob.JobOnSite.ContactDetails
					inspectionJobsResponse.ContactPhoneNumber = insJob.JobOnSite.ContactPhoneNumber
				}

				arrInsJob = append(arrInsJob, inspectionJobsResponse)
			}

			dataResponses.InspectionJobs = arrInsJob
			data = dataResponses
		} else {
			data = dataResponse
		}

	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJob godoc
// @Summary Update Job
// @Description Update Job
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Job body models.Job true "Update Job"
// @Success 200 {object} models.APIResponseData
// @Router /job/{id} [put]
func UpdateJob(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJob")
	var (
		status                          = libs.GetStatusSuccess()
		requestHeader                   models.RequestHeader
		response                        models.APIResponseData
		msg, data, errors               interface{}
		errorsResponse                  []models.ErrorResponse
		dataResponse                    []models.Job
		arrSkipJobSelectionRelatedJobID = make([]int, 0)
		totalUpdatedRecord              = 0
		inspectionJobs                  = make([]models.Job, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Job, 0)
	// Convert json body to object
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)

	id := c.Param("id")

	//if len(objectsJSON) > 0 {
	//for k, bp := range objectsJSON {
	var (
		job models.Job
	)
	//job.PassBodyJSONToModel(bp)
	resultFind := db.Preload(
		"AdditionalFiles",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobTasks",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobPickup",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDelivery",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobOnSite",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobInStore",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobMultiple",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobCombined",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourcePickUp",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourceDelivery",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"RecurringJob",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"RecurringJob.RecurringSkips",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("JobID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFind.RowsAffected > 0 {
		job.PassBodyJSONToModel(bp)
		job.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(job)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO validate for details
			if job.JobPickup != nil {
				job.JobPickup.ModifiedBy = accountKey
			}
			if job.JobDelivery != nil {
				job.JobDelivery.ModifiedBy = accountKey
			}
			if job.JobOnSite != nil {
				job.JobOnSite.ModifiedBy = accountKey
			}
			if job.JobInStore != nil {
				job.JobInStore.ModifiedBy = accountKey
			}
			if job.JobMultiple != nil {
				job.JobMultiple.ModifiedBy = accountKey
			}
			if job.JobCombined != nil {
				job.JobCombined.ModifiedBy = accountKey
			}
			if job.JobResourcePickUp != nil {
				job.JobResourcePickUp.ModifiedBy = accountKey
			}
			if job.JobResourceDelivery != nil {
				job.JobResourceDelivery.ModifiedBy = accountKey
			}
			if len(job.JobDetails) > 0 {
				for i := range job.JobDetails {
					job.JobDetails[i].LineSubTotal = job.JobDetails[i].UnitPrice * job.JobDetails[i].Quantity
					job.JobDetails[i].DiscountAmount = job.JobDetails[i].LineSubTotal * (job.JobDetails[i].DiscountPercent / 100)
					job.JobDetails[i].BufferAmount = job.JobDetails[i].LineSubTotal * (job.JobDetails[i].BufferPercent / 100)
					job.JobDetails[i].LineTotalTaxExcluded = job.JobDetails[i].LineSubTotal - job.JobDetails[i].DiscountAmount + job.JobDetails[i].BufferAmount
					job.JobDetails[i].LineTotalTax = job.JobDetails[i].LineTotalTaxExcluded * (job.JobDetails[i].TaxRate / 100)
					job.JobDetails[i].ModifiedBy = accountKey
					if job.JobDetails[i].CreatedBy <= 0 {
						job.JobDetails[i].CreatedBy = accountKey
					}
				}
			}
			if len(job.JobTasks) > 0 {
				for i := range job.JobTasks {
					job.JobTasks[i].ModifiedBy = accountKey
					if job.JobMultiple != nil {
						job.JobTasks[i].IsSuburb = false
						job.JobTasks[i].IsFullAddress = true
					}
					if job.JobCombined != nil {
						job.JobTasks[i].IsSuburb = false
						job.JobTasks[i].IsFullAddress = true
					}
				}
			}
			if job.RecurringJob != nil {
				job.RecurringJob.ModifiedBy = accountKey
				for i := range job.RecurringJob.RecurringSkips {
					if job.RecurringJob.RecurringSkips[i].CreatedBy <= 0 {
						job.RecurringJob.RecurringSkips[i].CreatedBy = accountKey
					}
					job.RecurringJob.RecurringSkips[i].ModifiedBy = accountKey
				}
			}

			// @TODO check for jobcombined & jobMultible
			var (
				res interface{}
				val string
			)
			var arrMultipleJobID []int
			val, res = services.ConvertJSONValueToVariable("isMultiple", bp)
			if res != nil {
				isMultiple, _ := strconv.ParseBool(val)
				if isMultiple {
					val, res = services.ConvertJSONValueToVariable("jobMultiple", bp)
					if res != nil {
						var objectsJobMultiple models.JobMultipleRequest
						jobMultipleJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(jobMultipleJSON, &objectsJobMultiple)
							if len(objectsJobMultiple.MultipleJobs) > 0 {
								var jobSelections []models.JobSelection
								serviceTimeInMinutes := 0
								for _, jobMultipleID := range objectsJobMultiple.MultipleJobs {
									arrSkipJobSelectionRelatedJobID = append(arrSkipJobSelectionRelatedJobID, jobMultipleID.JobID)
									var jobSelection models.JobSelection
									resultFindJobMultiple := db.Where("JobID = ? AND RelatedJobID = ?", job.JobID, jobMultipleID.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
									if resultFindJobMultiple.RowsAffected > 0 {
										jobSelection.ModifiedBy = accountKey
										jobSelection.Sort = jobMultipleID.Sort
									} else {
										jobSelection.CreatedBy = accountKey
										jobSelection.ModifiedBy = accountKey
										jobSelection.RelatedJobID = jobMultipleID.JobID
										jobSelection.Sort = jobMultipleID.Sort
									}
									jobSelections = append(jobSelections, jobSelection)
									arrMultipleJobID = append(arrMultipleJobID, jobMultipleID.JobID)
									var (
										mJobTask []models.JobTask
									)
									resultFindJobTask := db.Where("JobID = ?", jobMultipleID.JobID).
										Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&mJobTask)
									if resultFindJobTask.RowsAffected > 0 {
										for _, jt := range mJobTask {
											serviceTimeInMinutes = serviceTimeInMinutes + jt.ServiceTimeInMinutes
										}
									}
								}
								if len(job.JobTasks) > 0 {
									job.JobTasks[0].ServiceTimeInMinutes = serviceTimeInMinutes
								}
								job.JobSelections = jobSelections
							}
						}
					}
				}
			}
			var arrCombinedJobID []int
			val, res = services.ConvertJSONValueToVariable("isCombined", bp)
			if res != nil {
				isCombined, _ := strconv.ParseBool(val)
				if isCombined {
					val, res = services.ConvertJSONValueToVariable("jobCombined", bp)
					if res != nil {
						var objectsJobCombined models.JobCombinedRequest
						jobCombinedJSON, err := json.Marshal(res)
						if err == nil {
							json.Unmarshal(jobCombinedJSON, &objectsJobCombined)
							if len(objectsJobCombined.CombinedJobs) > 0 {
								var jobSelections []models.JobSelection
								for _, jobCombinedID := range objectsJobCombined.CombinedJobs {
									arrSkipJobSelectionRelatedJobID = append(arrSkipJobSelectionRelatedJobID, jobCombinedID.JobID)
									var jobSelection models.JobSelection
									resultFindJobCombined := db.Where("JobID = ? AND RelatedJobID = ?", job.JobID, jobCombinedID.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
									if resultFindJobCombined.RowsAffected > 0 {
										jobSelection.ModifiedBy = accountKey
										jobSelection.HasSequence = jobCombinedID.HasSequence
										jobSelection.Sort = jobCombinedID.Sort
									} else {
										jobSelection.CreatedBy = accountKey
										jobSelection.ModifiedBy = accountKey
										jobSelection.RelatedJobID = jobCombinedID.JobID
										jobSelection.HasSequence = jobCombinedID.HasSequence
										jobSelection.Sort = jobCombinedID.Sort
									}
									arrCombinedJobID = append(arrCombinedJobID, jobCombinedID.JobID)
									jobSelections = append(jobSelections, jobSelection)
								}
								job.JobSelections = jobSelections
							}
						}
					}
				}
			}

			var (
				jobsTasks []models.JobTask
			)
			// Get JobTask ID
			resultFindJobTasks := db.Where("JobID = ?", job.JobID).
				Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobsTasks)
			if resultFindJobTasks.RowsAffected > 0 {
				for _, v := range jobsTasks {
					for i, v1 := range job.JobTasks {
						if v.JobType == v1.JobType {
							job.JobTasks[i].JobTaskID = v.JobTaskID
							break
						}
					}
				}
			}

			errMsgInspectionJob := ValidateInspectionJobSettingBeforeProcessJob(requestHeader, lang, accountKey, job, bp)
			if errMsgInspectionJob == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&job)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, job)
					if len(job.JobTasks) > 0 {
						val, res := services.ConvertJSONValueToVariable("isOnSite", bp)
						if res != nil {
							isOnSite, _ := strconv.ParseBool(val)
							if isOnSite {
								_, res = services.ConvertJSONValueToVariable("jobOnSite", bp)
								if res != nil {
									UpdateServiceTimeForMultiple(job, db, accountKey)
								}
							}
						}
					}
					// @TOTO Update serviceTimeInMinutes for Parent Job Task

					// @TODO delete jobdetails & jobtasks
					arrSkipJobDetailID := make([]int, 0)
					arrSkipJobTaskID := make([]int, 0)
					arrSkipAddditionalFileID := make([]int, 0)

					for _, v := range job.JobDetails {
						arrSkipJobDetailID = append(arrSkipJobDetailID, v.JobDetailID)
					}
					for _, v := range job.JobTasks {
						arrSkipJobTaskID = append(arrSkipJobTaskID, v.JobTaskID)
					}
					for _, v := range job.AdditionalFiles {
						arrSkipAddditionalFileID = append(arrSkipAddditionalFileID, v.AdditionalFileID)
					}
					if len(arrSkipJobDetailID) > 0 {
						db.Where("JobID = ? AND JobDetailID not in (?)", job.JobID, arrSkipJobDetailID).Model(&models.JobDetail{}).Updates(models.JobDetail{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("JobID = ?", job.JobID).Model(&models.JobDetail{}).Updates(models.JobDetail{IsDeleted: true, ModifiedBy: accountKey})
					}
					if len(arrSkipJobTaskID) > 0 {
						db.Where("JobID = ? AND JobTaskID not in (?)", job.JobID, arrSkipJobTaskID).Model(&models.JobTask{}).Updates(models.JobTask{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("JobID = ?", job.JobID).Model(&models.JobTask{}).Updates(models.JobTask{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobPickup != nil {
						db.Where("JobID = ? AND JobPickupID <> ?", job.JobID, job.JobPickup.JobPickupID).Model(&models.JobPickup{}).Updates(models.JobPickup{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobDelivery != nil {
						db.Where("JobID = ? AND JobDeliveryID <> ?", job.JobID, job.JobDelivery.JobDeliveryID).Model(&models.JobDelivery{}).Updates(models.JobDelivery{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobOnSite != nil {
						db.Where("JobID = ? AND JobOnSiteID <> ?", job.JobID, job.JobOnSite.JobOnSiteID).Model(&models.JobOnSite{}).Updates(models.JobOnSite{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobInStore != nil {
						db.Where("JobID = ? AND JobInStoreID <> ?", job.JobID, job.JobInStore.JobInStoreID).Model(&models.JobInStore{}).Updates(models.JobInStore{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobMultiple != nil {
						db.Where("JobID = ? AND JobMultipleID <> ?", job.JobID, job.JobMultiple.JobMultipleID).Model(&models.JobMultiple{}).Updates(models.JobMultiple{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobCombined != nil {
						db.Where("JobID = ? AND JobCombinedID <> ?", job.JobID, job.JobCombined.JobCombinedID).Model(&models.JobCombined{}).Updates(models.JobCombined{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobResourcePickUp != nil {
						db.Where("JobID = ? AND JobResourcePickUpID <> ?", job.JobID, job.JobResourcePickUp.JobResourcePickupID).Model(&models.JobResourcePickup{}).Updates(models.JobResourcePickup{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.JobResourceDelivery != nil {
						db.Where("JobID = ? AND JobResourceDeliveryID <> ?", job.JobID, job.JobResourceDelivery.JobResourceDeliveryID).Model(&models.JobResourceDelivery{}).Updates(models.JobResourceDelivery{IsDeleted: true, ModifiedBy: accountKey})
					}

					if len(arrSkipJobSelectionRelatedJobID) > 0 {
						db.Where("JobID = ? AND RelatedJobID not in (?)", job.JobID, arrSkipJobSelectionRelatedJobID).Model(&models.JobSelection{}).Updates(models.JobSelection{IsDeleted: true, ModifiedBy: accountKey})
					}
					if len(arrSkipAddditionalFileID) > 0 {
						db.Where("JobID = ? AND AdditionalFileID not in (?)", job.JobID, arrSkipAddditionalFileID).Model(&models.AdditionalFile{}).Updates(models.AdditionalFile{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("JobID = ?", job.JobID).Model(&models.AdditionalFile{}).Updates(models.AdditionalFile{IsDeleted: true, ModifiedBy: accountKey})
					}
					if job.RecurringJob != nil {
						arrRecurringSkipToSkip := make([]int, 0)
						for _, recurringSkipToSkip := range job.RecurringJob.RecurringSkips {
							arrRecurringSkipToSkip = append(arrRecurringSkipToSkip, recurringSkipToSkip.RecurringSkipID)
						}
						if len(arrRecurringSkipToSkip) > 0 {
							db.Where("RecurringJobID = ? AND RecurringSkipID not in (?)", job.RecurringJob.RecurringJobID, arrRecurringSkipToSkip).Model(&models.RecurringSkip{}).Updates(models.RecurringSkip{IsDeleted: true, ModifiedBy: accountKey})
						} else {
							db.Where("RecurringJobID = ?", job.RecurringJob.RecurringJobID).Model(&models.RecurringSkip{}).Updates(models.RecurringSkip{IsDeleted: true, ModifiedBy: accountKey})
						}
						db.Where("JobID = ? AND RecurringJobID <> ?", job.JobID, job.RecurringJob.RecurringJobID).Model(&models.RecurringJob{}).Updates(models.RecurringJob{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						var findRecurringJob models.RecurringJob
						resultFindRecurringJob := db.Where("JobID = ?", job.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&findRecurringJob)
						if resultFindRecurringJob.RowsAffected > 0 {
							db.Where("RecurringJobID = ?", findRecurringJob.RecurringJobID).Model(&models.RecurringSkip{}).Updates(models.RecurringSkip{IsDeleted: true, ModifiedBy: accountKey})
						}
						db.Where("JobID = ?", job.JobID).Model(&models.RecurringJob{}).Updates(models.RecurringJob{IsDeleted: true, ModifiedBy: accountKey})
					}

					// Update Job Combined
					if len(arrCombinedJobID) > 0 {
						db.Where("JobID IN (?)", arrCombinedJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsCombinedChild": true})
					}

					// Update Job Multiple
					if len(arrMultipleJobID) > 0 {
						db.Where("JobID IN (?)", arrMultipleJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsMultipleChild": true})
					}
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "JobID", job.JobID)
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
						}
					}

					// @TODO assign customer to businesspartnerlocation
					var (
						businessLocationModel  models.BusinessPartnerLocation
						locationModel          models.Location
						strLocations           []string
						businessLocationModels []models.BusinessPartnerLocation
					)
					db.Where("LocationID = ?", job.LocationID).First(&locationModel)
					if job.BusinessPartnerID > 0 && job.LocationID > 0 {
						resultFindBusinessLocation := db.Where("BusinessPartnerID = ? AND LocationID = ?", job.BusinessPartnerID, job.LocationID).First(&businessLocationModel)
						if resultFindBusinessLocation.RowsAffected <= 0 {
							db.Where("LocationID = ?", job.LocationID).First(&locationModel)
							businessLocationModel.BusinessPartnerID = job.BusinessPartnerID
							businessLocationModel.LocationID = job.LocationID
							businessLocationModel.LocationGroupID = locationModel.LocationGroupID
							businessLocationModel.CreatedBy = accountKey
							db.Create(&businessLocationModel)
						} else {
							businessLocationModel.LocationGroupID = locationModel.LocationGroupID
							businessLocationModel.ModifiedBy = accountKey
							db.Save(&businessLocationModel)
						}

						// @TODO Update BP location
						resultFindBusinessLocations := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Find(&businessLocationModels)
						if resultFindBusinessLocations.RowsAffected > 0 {
							var businessPartner models.BusinessPartner
							for _, location := range businessLocationModels {
								strLocations = append(strLocations, strconv.Itoa(location.LocationID))
							}
							resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Find(&businessPartner)
							if resultFindBusinessPartner.RowsAffected > 0 {
								businessPartner.LocationID = strings.Join(strLocations, ",")
								db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&businessPartner)
							}
						}
					}

					// Delete TravelCalculation
					db.Where("JobID = ?", job.JobID).Delete(&models.TravelCalculation{})

					// @TODO update travel calculation
					//CreateTravelCalculation(requestHeader, job.TravelCalculation, job.JobID)

					// @TODO update jobtaskID to jobpickups, jobdeliveries,...
					UpdateJobTaskIDToSubJobAfterProcessJob(requestHeader, job)

					// @TODO update job4dprices
					var job4DPriceModels = make([]models.Job4DPrice, 0)
					job4DPriceModels = GetAllJob4DPricesFromJSON(requestHeader, accountKey, job, bp)
					inspectionJobs = UpdateInspectionJobFunc(requestHeader, lang, accountKey, job4DPriceModels, job)

					// Update 4DPrice Dynamic Form
					UpdateDynamicFormFor4DPrice(requestHeader, accountKey, job, bp, lang)
					// Async data To DynamoDB
					if job.IsJob || job.IsEstimate {
						var auditModel models.AuditDynamoDB
						auditModel.JobID = job.JobID
						auditModel.UserID = libs.GetUserIDFromAccountKey(requestHeader, accountKey)
						if job.IsJob {
							auditModel.DocType = models.AuditDocTypeJob
						} else {
							auditModel.DocType = models.AuditDocTypeEstimate
						}
						auditModel.Type = models.AuditTypeUpdate

						objectJson := ""
						byeObjectJson, errObjectJson := json.Marshal(bp)
						if errObjectJson == nil {
							objectJson = string(byeObjectJson)
						}
						auditModel.ObjectJson = objectJson

						libs.AsyncToDynamoDB(c, auditModel)
					}
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, errMsgInspectionJob)
			}

			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	//}
	//}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	var (
		jobs models.Job
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.JobID)
	}
	if len(arrID) > 0 {
		db.Preload(
			"AdditionalFiles",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobDetails",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobTasks",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobPickup",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobDelivery",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobOnSite",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobInStore",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobMultiple",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobCombined",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobResourcePickUp",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobResourceDelivery",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"RecurringJob",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"RecurringJob.RecurringSkips",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("JobID in (?)", arrID).First(&jobs)
		dataResponses := ConvertJobToResponse(requestHeader, jobs, lang, true)
		//for i, b := range dataResponses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Job{}.TableName())
		udfParams := make([]string, 0)
		if jobs.IsInvoice {
			udfParams = append(udfParams, "invoices")
		}
		if jobs.IsEstimate {
			udfParams = append(udfParams, "estimates")
		}
		if jobs.IsCreditNote {
			udfParams = append(udfParams, "creditnotes")
		}
		if jobs.IsJob {
			udfParams = append(udfParams, "jobs")
		}
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		dataResponses.UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, jobs.JobID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			dataResponses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		dataResponses.UDFs = udfResponses
		//}
		var arrInsJob = make([]models.InspectionJobDateResponse, 0)

		for _, insJob := range inspectionJobs {
			var inspectionJobsResponse models.InspectionJobDateResponse
			inspectionJobsResponse.JobID = insJob.JobID
			inspectionJobsResponse.JobNumber = insJob.JobNumber
			inspectionJobsResponse.JobDate = insJob.JobDate
			if len(insJob.JobDetails) > 0 {
				inspectionJobsResponse.ForJobTaskType = *insJob.JobDetails[0].JobTaskType
				inspectionJobsResponse.ForJobTaskTypeName, inspectionJobsResponse.ForJobTaskTypeIcon = libs.GetEnum(requestHeader, inspectionJobsResponse.ForJobTaskType, "JobType", lang)
			}
			if insJob.JobOnSite != nil {
				inspectionJobsResponse.Address = insJob.JobOnSite.Address
				inspectionJobsResponse.ContactDetails = insJob.JobOnSite.ContactDetails
				inspectionJobsResponse.ContactPhoneNumber = insJob.JobOnSite.ContactPhoneNumber
			}

			arrInsJob = append(arrInsJob, inspectionJobsResponse)
		}

		dataResponses.InspectionJobs = arrInsJob
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ApproveEstimate godoc
// @Summary Update Job
// @Description Update Job
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Job body models.Job true "Update Job"
// @Success 200 {object} models.APIResponseData
// @Router /approveestimate/{jobid} [put]
func ApproveEstimate(c *gin.Context) {
	defer libs.RecoverError(c, "ApproveEstimate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Job
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Job, 0)
	// Convert json body to object
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)

	id := c.Param("jobid")
	arrID := libs.StringToArray(id)
	for k, id := range arrID {
		var (
			job models.Job
		)
		resultFind := db.Where("JobID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFind.RowsAffected > 0 {
			oldIsCustomerApproved := job.IsCustomerApproved
			job.PassBodyJSONToModel(bp)
			if job.IsManagerApproved {
				status = 400
				msg = services.GetMessage(lang, "api.manager_approved")
				var (
					errResponse models.ErrorResponse
				)
				errResponse.Index = k
				errResponse.Type = models.ErrorResponseTypeError
				errResponse.Message = msg
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if !oldIsCustomerApproved {
					timeNow := time.Now()
					job.CustomerApprovalDate = &timeNow
					job.IsCustomerApproved = true
					job.IsRejected = false
					job.RejectedDate = nil
					job.Token = nil
					clientIP := realip.FromRequest(c.Request)
					job.SubmittedIP = &clientIP
				}
				job.IsManagerApproved = true
				job.IsJob = true
				CheckDocumentSequencesBeforeCreate(requestHeader)
				var (
					sequencyModel     models.DocumentSequency
					jobNumPrefix      models.Prefix
					estimateNumPrefix models.Prefix
					invoiceNumPrefix  models.Prefix
					creditNotePrefix  models.Prefix
				)
				ResetDocumentSequencesIfGreaterLength(requestHeader)
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
				db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
				db.Where("DocumentSequence = ?", "EstimateNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&estimateNumPrefix)
				db.Where("DocumentSequence = ?", "InvoiceNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&invoiceNumPrefix)
				db.Where("DocumentSequence = ?", "CreditNoteNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&creditNotePrefix)
				jobNumberFirstConfig := jobNumPrefix.Prefix
				lenJobNumberConfig := jobNumPrefix.Length
				sqJobNumber := sequencyModel.JobNumber
				job.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)
				job.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(job)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)

					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&job)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, job)
						IncreaseDocumentSequencesAfterCreateJob(true, false, false, false, requestHeader)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
		errors = errorsResponse
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
		if status == 200 {
			msg = services.GetMessage(lang, "api.success")
			data = map[string]interface{}{"JobNumber": job.JobNumber}
		} else {
			errResponse := GetErrorResponseErrorMessage(k, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteJob godoc
// @Summary Delete Job
// @Description Delete Job
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Job ID"
// @Success 200 {object} models.APIResponseData
// @Router /job/{id} [delete]
func DeleteJob(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteJob")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Job
		)
		resultFind := db.Where("JobID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&uModel)
		if resultFind.RowsAffected > 0 {
			if uModel.IsJob && uModel.IsEstimate {
				uModel.IsJob = false
				uModel.IsManagerApproved = false
				uModel.JobNumber = ""
				uModel.CustomerApprovalDate = nil
				uModel.IsCustomerApproved = true
				uModel.IsRejected = false
				uModel.RejectedDate = nil
				uModel.Token = nil
				uModel.SubmittedIP = nil
				uModel.ModifiedBy = accountKey
				deletedResult := db.Save(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				statusDelete := uModel.ValidateDelete(db, lang)
				validateMessage := ""
				if statusDelete.Status == 200 {
					var canDelete = true

					if uModel.IsCombinedChild || uModel.IsMultipleChild { // Combined Job && Multiple Job
						sql := `SELECT COUNT(RelatedJobID) AS Count FROM jobsselection js JOIN ( 
						SELECT JobID FROM jobsselection 
						WHERE IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND RelatedJobID = ?) AS jo ON js.JobID = jo.JobID
						WHERE  IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1`

						rows, err := db.Raw(sql, id).Rows()
						if rows != nil {
							defer rows.Close()
						}
						if err == nil {
							for rows.Next() {
								var (
									count = 0
								)
								rows.Scan(&count)
								if count <= 2 {
									canDelete = false
									if uModel.IsCombinedChild {
										validateMessage = services.GetMessage(lang, "api.cannotdeletejobselectioncombined")
									}
									if uModel.IsMultipleChild {
										validateMessage = services.GetMessage(lang, "api.cannotdeletejobselectionmultiple")
									}
								}
							}
						}
					} else if uModel.IsMultipleChild { // Multiple Job
						resultFindPrimary := db.Where("PrimaryJobID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.JobMultiple{})
						if resultFindPrimary.RowsAffected > 0 {
							canDelete = false
							validateMessage = services.GetMessage(lang, "api.cannotdeleteprimaryjob")
						}
					}

					if canDelete {
						uModel.IsDeleted = true
						uModel.ModifiedBy = accountKey
						deletedResult := db.Save(&uModel)
						if deletedResult.Error != nil {
							errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
							errorsResponse = append(errorsResponse, errResponse)
						} else {
							totalUpdatedRecord++
						}

						// @TODO delete detail
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobDetail{}).Updates(models.JobDetail{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobTask{}).Updates(models.JobTask{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobPickup{}).Updates(models.JobPickup{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobDelivery{}).Updates(models.JobDelivery{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobOnSite{}).Updates(models.JobOnSite{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobInStore{}).Updates(models.JobInStore{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobMultiple{}).Updates(models.JobMultiple{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobCombined{}).Updates(models.JobCombined{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobResourcePickup{}).Updates(models.JobResourcePickup{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobResourceDelivery{}).Updates(models.JobResourceDelivery{IsDeleted: true, ModifiedBy: accountKey})
						db.Where("JobID = ?", uModel.JobID).Model(&models.JobSelection{}).Updates(models.JobSelection{IsDeleted: true, ModifiedBy: accountKey})

						var recurringJob models.RecurringJob
						resultFindRecurringJob := db.Where("JobID = ?", uModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&recurringJob)
						if resultFindRecurringJob.RowsAffected > 0 {
							db.Where("RecurringJobID = ?", recurringJob.RecurringJobID).Model(&models.RecurringSkip{}).Updates(models.RecurringSkip{IsDeleted: true, ModifiedBy: accountKey})
						}
						db.Where("JobID = ?", uModel.JobID).Model(&models.RecurringJob{}).Updates(models.RecurringJob{IsDeleted: true, ModifiedBy: accountKey})

						//@TODO Reset IsMultiple & IsCombined in jobs table
						var (
							jobSelection []models.JobSelection
						)

						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND RelatedJobID = ?", uModel.JobID).Find(&jobSelection)

						if len(jobSelection) > 0 {
							for _, id := range jobSelection {
								if uModel.IsCombinedChild {
									db.Where("JobID = ?", id.RelatedJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsCombinedChild": false, "ModifiedBy": accountKey})
								} else if uModel.IsMultipleChild {
									db.Where("JobID = ?", id.RelatedJobID).Model(&models.Job{}).Updates(map[string]interface{}{"IsMultipleChild": false, "ModifiedBy": accountKey})
								}
								db.Where("JobSelectionID = ?", id.JobSelectionID).Model(&models.JobSelection{}).Updates(models.JobSelection{IsDeleted: true, ModifiedBy: accountKey})
							}
						}
						if uModel.IsMultipleChild {
							UpdateServiceTimeForMultiple(uModel, db, accountKey)
						}
						// Delete TravelCalculation
						db.Where("JobID = ?", id).Delete(&models.TravelCalculation{})
						// Delete Job4DPrice
						db.Exec(`DELETE FROM `+models.Job4DPrice{}.TableName()+` WHERE JobID = ?`, id)
						// Delete InspectionJob
						DeleteInspectionJobByInspectionForJobIDFunc(requestHeader, id)

						// Async data To DynamoDB
						if uModel.IsJob || uModel.IsEstimate {
							var auditModel models.AuditDynamoDB
							auditModel.JobID = uModel.JobID
							auditModel.UserID = libs.GetUserIDFromAccountKey(requestHeader, accountKey)
							if uModel.IsJob {
								auditModel.DocType = models.AuditDocTypeJob
							} else {
								auditModel.DocType = models.AuditDocTypeEstimate
							}
							auditModel.Type = models.AuditTypeDelete
							objectJson := ""
							auditModel.ObjectJson = objectJson
							libs.AsyncToDynamoDB(c, auditModel)
						}
					} else {
						errResponse := GetErrorResponseErrorMessage(k, validateMessage)
						errorsResponse = append(errorsResponse, errResponse)
					}
				} else {
					errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

func UpdateServiceTimeForMultiple(job models.Job, db *gorm.DB, accountKey int) {
	sql := `SELECT SUM(ServiceTimeInMinutes) AS ServiceTimeInMinutes FROM jobtasks jt
					WHERE JobID IN ( 
					SELECT RelatedJobID FROM jobsselection js JOIN ( 
					SELECT js.JobID FROM jobsselection js JOIN jobmultiples jm ON js.JobID = jm.JobID
					WHERE  IFNULL(js.IsDeleted, 0) <> 1 AND IFNULL(js.IsArchived, 0) <> 1 AND js.RelatedJobID = ?) AS jo ON js.JobID = jo.JobID)`
	rows, err := db.Raw(sql, job.JobID).Rows()
	if rows != nil {
		defer rows.Close()
	}
	if err == nil {
		for rows.Next() {
			var serviceTimeInMinutes = 0
			rows.Scan(&serviceTimeInMinutes)
			sql = `SELECT JobID, jt.JobTaskID
							FROM jobtasks jt
							WHERE JobID IN ( 
							SELECT js.JobID FROM jobsselection js JOIN ( 
							SELECT js.JobID FROM jobsselection js JOIN jobmultiples jm ON js.JobID = jm.JobID
							WHERE  IFNULL(js.IsDeleted, 0) <> 1 AND IFNULL(js.IsArchived, 0) <> 1 AND js.RelatedJobID = ?) AS jo ON js.JobID = jo.JobID)`
			rows, err := db.Raw(sql, job.JobID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var (
						jobID     = 0
						jobTaskID = 0
					)
					rows.Scan(&jobID, &jobTaskID)
					db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ? AND JobTaskID = ?", jobID, jobTaskID).Model(&models.JobTask{}).
						Updates(models.JobTask{ServiceTimeInMinutes: serviceTimeInMinutes, ModifiedBy: accountKey})
				}
			}
		}
	}
}

// UpdateJobStatus func
func UpdateJobStatus(requestHeader models.RequestHeader, jobID int, status int, accountKey int, c *gin.Context) *gorm.DB {
	var (
		job           models.Job
		resultSaveJob *gorm.DB
	)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := c.Request.Header.Get("language")
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFindJob.RowsAffected > 0 {
		job.ModifiedBy = accountKey
		job.Status = status
		resultSaveJob = db.Save(&job)
		// Call Socket jpJobStatus
		if resultSaveJob.RowsAffected > 0 {
			var msg models.JobStatusMessage
			msg.JobID = jobID
			//msg.CompanyID = companyID
			/* err := SendJobStatusToSocket(msg, token, accountKey, companyID, locationID)
			fmt.Println("Socket error: ", err) */
			go SendJobStatusToSocket(msg, token, accountKey, companyID, locationID)
			smsMatrixID := 0
			// Send SMS
			if status == 7 {
				smsMatrixID = 7
			} else if status == 2 {
				smsMatrixID = 1
			}

			if smsMatrixID > 0 {
				jobID := jobID
				resStatus, resMsg, resSendSMS := SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobID)
				// logger
				var smsLogger = smslogs.SMSLogger
				smsLogger.Println("jobID: ", jobID)
				smsLogger.Println("smsMatrixID: ", smsMatrixID)
				smsLogger.Println("resStatus: ", resStatus)
				smsLogger.Println("resMsg: ", resMsg)
				smsLogger.Printf("resSendSMS: %+v", resSendSMS)
			}
		}
	}
	return resultSaveJob
}

// updateinspectionjobdate func
func UpdateInspectionJobDate(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateInspectionJobDate")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for _, insjob := range objectsJSON {
			jobID, res := services.ConvertJSONValueToVariable("JobID", insjob)
			if res != nil {

				var job models.Job
				resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", jobID).First(&job)

				if resultFind.RowsAffected > 0 {
					job.ModifiedBy = accountKey
					val, res := services.ConvertJSONValueToVariable("Date", insjob)
					if res != nil {
						vJobDate, sJobDate := services.ConvertStringToDateTime(val)
						if sJobDate == nil {
							job.JobDate = &vJobDate
							db.Save(&job)
						}
					}
				}
				totalUpdatedRecord++
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = objectsJSON
	libs.APIResponseData(response, c, status)
}

// GetUnPickJob godoc
// @Summary GetJobByUser
// @Description GetJobByUser
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getunpickjobbyschedule [get]
// App
func GetUnPickJob(c *gin.Context) {
	defer libs.RecoverError(c, "GetUnPickJob")
	var (
		status           = libs.GetStatusSuccess()
		userModel        models.User
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		msg, data        interface{}
		itemMsgError     string
		schedulesJobs    []models.ScheduleJobResponse
		fromDate, toDate time.Time
		journeyCode      string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	//todayDate := time.Now().Format(libs.FORMATDATE)
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}

	vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
	if !sJourneyCode {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.param_required", "Journey Code"))
		status = 422
	} else {
		journeyCode = vJourneyCode
	}

	if status == 200 {
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
		if resultFindUser.RowsAffected > 0 {
			userID := userModel.UserID

			// Only Job Status = 2  - Allocated
			sql := `SELECT 
				IFNULL(s.JobID,0) AS JobID,
				IFNULL(j.JobNumber,'') AS JobNumber, 
				IFNULL(j.Status,0) AS Status, 
				IFNULL(r.NavigationAddress,'') AS NavigationAddress,
				IFNULL(b.CompanyName,'') AS CompanyName,
				SUM(jd.Quantity - jd.QuantityPicked) AS ToPickQuantity
				FROM schedules s
				LEFT JOIN jobs j ON s.JobID = j.JobID
				LEFT JOIN resources r ON s.ResourceID = r.ResourceID 
				LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
				JOIN jobdetails jd ON jd.JobID = j.JobID
				WHERE j.Status IN (8,2) AND IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
				AND jd.Quantity > jd.QuantityPicked AND IFNULL(jd.IsDeleted, 0) <> 1 AND IFNULL(jd.IsArchived, 0) <> 1
				AND s.UserID = ? AND (DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s'))
				AND s.JourneyCode = ? AND IFNULL(j.IsInspection , 0)  = 0
				GROUP BY s.JobID,j.JobNumber, j.Status, r.NavigationAddress, b.CompanyName`
			rows, err := db.Debug().Raw(sql, userID, fromDate, toDate, journeyCode).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var scheduleJob models.ScheduleJobResponse
					ToPickQuantity := 0
					rows.Scan(&scheduleJob.JobID, &scheduleJob.JobNumber,
						&scheduleJob.Status, &scheduleJob.NavigationAddress, &scheduleJob.CompanyName, &ToPickQuantity,
					)
					schedulesJobs = append(schedulesJobs, scheduleJob)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
			}
			if len(schedulesJobs) > 0 {
				data = schedulesJobs
				msg = services.GetMessage(lang, "api.success")
			} else {
				//status = libs.GetStatusNotFound()
				msg = services.GetMessage(lang, "api.no_record_found")
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
			}
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	}

	if itemMsgError != "" {
		msg = itemMsgError
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// GetJobAppByID godoc
// @Summary GetJobAppByID
// @Description GetJobAppByID
// @Tags Job
// @Accept  json
// @Produce  json
// @Param id path int true "Job ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /job/{id} [get]
func GetJobAppByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobAppByID")
	var (
		status        = libs.GetStatusSuccess()
		jobs          models.Job
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("jobid")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", ID)
	resultRow := bp.First(&jobs)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"JobID": jobs.JobID, "JobNumber": jobs.JobNumber, "TotalJob": jobs.TotalJob}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetCurrentJobStatus godoc
// @Summary GetJobAppByID
// @Description GetJobAppByID
// @Tags Job
// @Accept  json
// @Produce  json
// @Param id path int true "Job ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getcurrentjobstatus/{jobid} [get]
func GetCurrentJobStatus(c *gin.Context) {
	defer libs.RecoverError(c, "GetCurrentJobStatus")
	var (
		status        = libs.GetStatusSuccess()
		jobs          models.Job
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("jobid")
	var bp = db
	bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?", ID)
	resultRow := bp.First(&jobs)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		data = ConvertJobStatusToResponse(requestHeader, jobs, lang)
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// SendJobStatusToSocket func
func SendJobStatusToSocket(msg models.JobStatusMessage, token string, accountKey int, companyID string, locationID int) error {
	var (
		err error
	)
	socketURL := os.Getenv("SOCKET_JOBSTATUS_PATH")
	socketURL = socketURL + "?token=" + token + "&accountkey=" + strconv.Itoa(accountKey) + "&companyid=" + companyID + "&locationid=" + strconv.Itoa(locationID)
	conn, _, err := websocket.DefaultDialer.Dial(socketURL, nil)
	if err != nil {
		return err
	}
	fmt.Printf("msg: %+v\n", msg)
	err = conn.WriteJSON(msg)
	conn.Close()
	return err
}

// ConvertArrayJobsToArrayResponse func
func ConvertArrayJobsToArrayResponse(requestHeader models.RequestHeader, items []models.Job, lang string, isUpdate bool, includeInspection bool, forList ...bool) []models.JobResponse {
	list := false
	if len(forList) > 0 {
		list = forList[0]
	}
	responses := make([]models.JobResponse, 0)
	for _, item := range items {
		response := ConvertJobToResponse(requestHeader, item, lang, isUpdate, list)
		responses = append(responses, response)
	}
	return responses
}

// GetBusinessPartnerAddress func
func GetBusinessPartnerAddress(db *gorm.DB, businessPartnerID int) []models.AddressJobResponse {
	var (
		addresses []models.Address
	)
	addressesResponse := make([]models.AddressJobResponse, 0)
	db.Where("Entity = ? AND EntityID = ?", models.BusinessPartner{}.TableName(), businessPartnerID).Find(&addresses)
	for _, ad := range addresses {
		var (
			address     models.AddressJobResponse
			addressType models.AddressType
		)
		address.AddressTypeID = ad.AddressTypeID
		db.Where("AddressTypeID = ?", ad.AddressTypeID).First(&addressType)
		address.AddressTypeName = addressType.AddressTypeName

		address.NavigationAddress = ad.NavigationAddress
		addressesResponse = append(addressesResponse, address)
	}
	return addressesResponse
}

// ConvertJobToResponse func
func ConvertJobToResponse(requestHeader models.RequestHeader, item models.Job, lang string, isUpdate bool, forList ...bool) models.JobResponse {
	var (
		response                    models.JobResponse
		jobHeaderResponse           models.JobHeaderResponse
		jobPickupResponse           models.JobPickupResponse
		jobDeliveryResponse         models.JobDeliveryResponse
		jobOnSiteResponse           models.JobOnSiteResponse
		jobInStoreResponse          models.JobInStoreResponse
		jobMultipleResponse         models.JobMultipleResponse
		jobCombinedResponse         models.JobCombinedResponse
		jobResourcePickupResponse   models.JobResourcePickupResponse
		jobResourceDeliveryResponse models.JobResourceDeliveryResponse
		jobMapResponse              models.JobMapResponse
		jobCommentResponse          models.JobCommentResponse
		jobTotalResponse            models.JobTotalResponse
		businessPartner             models.BusinessPartner
		//travelCalculation          []models.TravelCalculation
		//travelCalculationsResponse []models.TravelCalculationResponse
	)
	list := false
	if len(forList) > 0 {
		list = forList[0]
	}
	// TravelCalculation
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.JobID = item.JobID
	response.IsJob = item.IsJob
	response.IsEstimate = item.IsEstimate
	response.IsInvoice = item.IsInvoice
	response.IsCreditNote = item.IsCreditNote
	response.JobType = item.JobType
	response.JobTypeName, response.JobTypeIcon = libs.GetEnum(requestHeader, item.JobType, "JobType", lang)
	response.TravelChargeMode = item.TravelChargeMode
	response.LocationID = item.LocationID
	response.Status = item.Status
	response.StatusName, response.StatusIcon = libs.GetEnum(requestHeader, item.Status, "JobStatus", lang)
	response.InProgressStatus = item.InProgressStatus
	response.JobTaskStatus = item.JobTaskStatus
	response.EstimateDate = item.EstimateDate
	response.InvoiceDate = item.InvoiceDate
	response.CreditNoteDate = item.CreditNoteDate
	response.EstimateDueDate = item.EstimateDueDate
	response.InvoiceDueDate = item.InvoiceDueDate
	response.CustomerApprovalDate = item.CustomerApprovalDate
	response.ManagerApprovalDate = item.ManagerApprovalDate
	response.RejectedDate = item.RejectedDate
	response.IsSent = item.IsSent
	response.IsCustomerApproved = item.IsCustomerApproved
	response.IsManagerApproved = item.IsManagerApproved
	response.IsRejected = item.IsRejected
	response.Signature = item.Signature
	response.SubmittedIP = item.SubmittedIP
	response.JobFormsNavigation = ConvertJobFormsNavigationToResponse(requestHeader, lang, item.JobID, item.JobFormsNavigation)
	response.ErpInvoiceKey = item.ErpInvoiceKey
	response.ErpInvoiceStatus = item.ErpInvoiceStatus
	response.ErpCreditNoteKey = item.ErpCreditNoteKey
	response.EstimatedDistance = item.EstimatedDistance
	response.EstimatedTravelTime = item.EstimatedTravelTime
	response.InspectionForJobID = item.InspectionForJobID
	response.IsInspection = item.IsInspection
	response.SurchargeParentItemKeys = item.SurchargeParentItemKeys
	jobHeaderResponse.BusinessPartnerID = item.BusinessPartnerID
	jobHeaderResponse.JobDate = item.JobDate
	jobHeaderResponse.EstimateDate = item.EstimateDate
	jobHeaderResponse.EstimateDueDate = item.EstimateDueDate
	jobHeaderResponse.JobNumber = item.JobNumber
	jobHeaderResponse.EstimateNumber = item.EstimateNumber
	jobHeaderResponse.InvoiceNumber = item.InvoiceNumber
	jobHeaderResponse.CreditNoteNumber = item.CreditNoteNumber
	jobHeaderResponse.ContactDetails = item.ContactDetails
	jobHeaderResponse.CountryCode = item.CountryCode
	jobHeaderResponse.ContactPhoneNumber = item.ContactPhoneNumber
	jobHeaderResponse.ResourceType = item.ResourceType
	jobHeaderResponse.ResourceTypeName, jobHeaderResponse.ResourceTypeIcon = libs.GetEnum(requestHeader, item.ResourceType, "ResourceType", lang)
	jobHeaderResponse.Priority = item.Priority
	jobHeaderResponse.PriorityName, jobHeaderResponse.PriorityIcon = libs.GetEnum(requestHeader, item.Priority, "Priority", lang)
	var bp = db
	if !list {
		bp = bp.Preload("Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
		bp = bp.Preload("Phones", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
	}
	resultFindBP := bp.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
	if resultFindBP.RowsAffected > 0 {
		jobHeaderResponse.CompanyName = businessPartner.CompanyName
		jobHeaderResponse.EmailAddress = businessPartner.EmailAddress

		addresses := make([]models.AddressResponse, 0)
		for _, ad := range businessPartner.Addresses {
			var (
				address     models.AddressResponse
				addressType models.AddressType
			)
			address.AddressID = ad.AddressID
			address.AddressTypeID = ad.AddressTypeID
			db.Where("AddressTypeID = ?", ad.AddressTypeID).First(&addressType)
			address.AddressTypeName = addressType.AddressTypeName
			address.AddressLine1 = ad.AddressLine1
			address.AddressLine2 = ad.AddressLine2
			address.AddressLine3 = ad.AddressLine3
			address.AddressLine4 = ad.AddressLine4
			address.City = ad.City
			address.PostalCode = ad.PostalCode
			address.State = ad.State
			address.Country = ad.Country
			address.AttentionTo = ad.AttentionTo
			address.IsDeleted = ad.IsDeleted
			address.IsArchived = ad.IsArchived
			address.EntityID = ad.EntityID
			address.Entity = ad.Entity
			address.IsDefaultBilling = ad.IsBilling
			address.IsDefaultDepot = ad.IsDepot
			address.NavigationAddress = ad.NavigationAddress
			addresses = append(addresses, address)
		}
		jobHeaderResponse.Addresses = addresses

		phones := make([]models.PhoneResponse, 0)
		for _, ph := range businessPartner.Phones {
			var (
				phone     models.PhoneResponse
				phoneType models.PhoneType
			)
			phone.PhoneID = ph.PhoneID
			phone.PhoneTypeID = ph.PhoneTypeID
			db.Where("PhoneTypeID = ?", ph.PhoneTypeID).First(&phoneType)
			phone.PhoneTypeName = phoneType.PhoneTypeName
			phone.CountryCode = ph.CountryCode
			phone.PhoneNumber = ph.PhoneNumber
			phone.Extension = ph.Extension
			phone.EntityID = ph.EntityID
			phone.Entity = ph.Entity
			phone.IsDeleted = ph.IsDeleted
			phone.IsArchived = ph.IsArchived
			phone.IsDefaultContact = ph.IsDefault
			phones = append(phones, phone)
		}
		jobHeaderResponse.Phones = phones
	}

	jobHeaderResponse.TravelCharge = item.TravelCharge
	jobHeaderResponse.TravelChargeName, _ = libs.GetEnum(requestHeader, item.TravelCharge, "TravelCharge", lang)

	jobHeaderResponse.IsRecurring = item.IsRecurring
	jobHeaderResponse.RecurringJobID = item.RecurringJobID
	jobHeaderResponse.OptimizeJob = item.OptimizeJob

	response.JobHeader = jobHeaderResponse

	//if !isUpdate {
	jobTasks := make([]models.JobTaskForJobListResponse, 0)
	for _, jt := range item.JobTasks {
		var (
			jobTask models.JobTaskForJobListResponse
		)
		jobTask.JobTaskID = jt.JobTaskID
		jobTask.JobType = jt.JobType
		jobTask.JobTypeName, jobTask.JobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
		jobTask.Status = jt.Status
		jobTask.StatusName, jobTask.StatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
		jobTask.NavigationAddress = jt.NavigationAddress
		jobTask.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
		jobTask.FormFlowID = jt.FormFlowID

		jobTask.ScheduleStartDateTime = jt.ScheduleStartDateTime
		jobTask.ScheduleEndDateTime = jt.ScheduleEndDateTime
		jobTask.DepartureDateTime = jt.DepartureDateTime
		jobTask.EstimatedArrivalDateTime = jt.EstimatedArrivalDateTime
		jobTask.ArrivalDateTime = jt.ArrivalDateTime
		jobTask.StartDateTime = jt.StartDateTime
		jobTask.EndDateTime = jt.EndDateTime
		jobTask.AdditionalInformation = jt.AdditionalInformation
		jobTask.JobTimeInSeconds = jt.JobTimeInSeconds
		jobTask.Longitude = jt.Longitude
		jobTask.Latitude = jt.Latitude
		jobTask.IsSuburb = jt.IsSuburb
		jobTask.IsFullAddress = jt.IsFullAddress
		jobTasks = append(jobTasks, jobTask)
	}
	response.JobTasks = &jobTasks
	//}

	if item.JobPickup != nil {
		jobPickupResponse.AdditionalInformation = item.JobPickup.AdditionalInformation
		jobPickupResponse.AddressTypeID = item.JobPickup.AddressTypeID
		jobPickupResponse.Address = item.JobPickup.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobPickup.BusinessPartnerID > 0 {
			jobPickupResponse.BusinessPartnerID = &item.JobPickup.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobPickupResponse.BusinessPartnerID)
		}
		jobPickupResponse.Addresses = addressesResponse
		jobPickupResponse.ContactDetails = item.JobPickup.ContactDetails
		jobPickupResponse.CountryCode = item.JobPickup.CountryCode
		jobPickupResponse.ContactPhoneNumber = item.JobPickup.ContactPhoneNumber
		jobPickupResponse.IsBussinessPartner = item.JobPickup.IsBussinessPartner
		jobPickupResponse.PreferredDateTime = item.JobPickup.PreferredDateTime
		for _, jt := range item.JobTasks {
			if jt.JobType == 2 && jt.JobTaskID == item.JobPickup.JobTaskID { // 2 = Pickup
				jobPickupResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				jobPickupResponse.IsSuburb = jt.IsSuburb
				jobPickupResponse.IsFullAddress = jt.IsFullAddress
				break
			}
		}
		response.JobPickup = &jobPickupResponse
		response.IsPickUp = true
	} else {
		response.JobPickup = &jobPickupResponse
	}

	if item.JobDelivery != nil {
		jobDeliveryResponse.AdditionalInformation = item.JobDelivery.AdditionalInformation
		jobDeliveryResponse.AddressTypeID = item.JobDelivery.AddressTypeID
		jobDeliveryResponse.Address = item.JobDelivery.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobDelivery.BusinessPartnerID > 0 {
			jobDeliveryResponse.BusinessPartnerID = &item.JobDelivery.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobDeliveryResponse.BusinessPartnerID)
		}
		jobDeliveryResponse.Addresses = addressesResponse
		jobDeliveryResponse.ContactDetails = item.JobDelivery.ContactDetails
		jobDeliveryResponse.CountryCode = item.JobDelivery.CountryCode
		jobDeliveryResponse.ContactPhoneNumber = item.JobDelivery.ContactPhoneNumber
		jobDeliveryResponse.IsBussinessPartner = item.JobDelivery.IsBussinessPartner
		jobDeliveryResponse.PreferredDateTime = item.JobDelivery.PreferredDateTime
		for _, jt := range item.JobTasks {
			if jt.JobType == 3 && jt.JobTaskID == item.JobDelivery.JobTaskID { // 3 = Delivery
				jobDeliveryResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				jobDeliveryResponse.IsSuburb = jt.IsSuburb
				jobDeliveryResponse.IsFullAddress = jt.IsFullAddress
				break
			}
		}
		response.JobDelivery = &jobDeliveryResponse
		response.IsDelivery = true
	} else {
		response.JobDelivery = &jobDeliveryResponse
	}

	if item.JobOnSite != nil {
		jobOnSiteResponse.AdditionalInformation = item.JobOnSite.AdditionalInformation
		jobOnSiteResponse.AddressTypeID = item.JobOnSite.AddressTypeID
		jobOnSiteResponse.Address = item.JobOnSite.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobOnSite.BusinessPartnerID > 0 {
			jobOnSiteResponse.BusinessPartnerID = &item.JobOnSite.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobOnSiteResponse.BusinessPartnerID)
		}
		jobOnSiteResponse.Addresses = addressesResponse
		jobOnSiteResponse.ContactDetails = item.JobOnSite.ContactDetails
		jobOnSiteResponse.CountryCode = item.JobOnSite.CountryCode
		jobOnSiteResponse.ContactPhoneNumber = item.JobOnSite.ContactPhoneNumber
		jobOnSiteResponse.IsBussinessPartner = item.JobOnSite.IsBussinessPartner
		jobOnSiteResponse.PreferredDateTime = item.JobOnSite.PreferredDateTime
		jobOnSiteResponse.LotNo = item.JobOnSite.LotNo
		for _, jt := range item.JobTasks {
			if jt.JobType == 1 && jt.JobTaskID == item.JobOnSite.JobTaskID { // 1 = OnSite
				jobOnSiteResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				jobOnSiteResponse.IsSuburb = jt.IsSuburb
				jobOnSiteResponse.IsFullAddress = jt.IsFullAddress
				break
			}
		}
		response.JobOnSite = &jobOnSiteResponse
		response.IsOnSite = true
	} else {
		response.JobOnSite = &jobOnSiteResponse
	}

	if item.JobInStore != nil {
		jobInStoreResponse.Note = item.JobInStore.Note
		jobInStoreResponse.AddressTypeID = item.JobInStore.AddressTypeID
		jobInStoreResponse.Address = item.JobInStore.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobInStore.BusinessPartnerID > 0 {
			jobInStoreResponse.BusinessPartnerID = &item.JobInStore.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobInStoreResponse.BusinessPartnerID)
		}
		jobInStoreResponse.Addresses = addressesResponse
		jobInStoreResponse.ContactDetails = item.JobInStore.ContactDetails
		jobInStoreResponse.CountryCode = item.JobInStore.CountryCode
		jobInStoreResponse.ContactPhoneNumber = item.JobInStore.ContactPhoneNumber
		jobInStoreResponse.IsBussinessPartner = item.JobInStore.IsBussinessPartner
		jobInStoreResponse.PreferredDateTime = item.JobInStore.PreferredDateTime
		jobInStoreResponse.Note = item.JobInStore.Note
		response.JobInStore = &jobInStoreResponse
		response.IsInStore = true
	} else {
		response.JobInStore = &jobInStoreResponse
	}

	jobdetails := make([]models.JobDetailForJobResponse, 0)
	for _, jd := range item.JobDetails {
		var (
			jobdetail models.JobDetailForJobResponse
		)
		jobdetail.JobDetailID = jd.JobDetailID
		jobdetail.LineNum = jd.LineNum
		jobdetail.ItemID = jd.ItemID
		jobdetail.Code = jd.Code
		var item models.Item
		db.Where("ItemID = ?", jd.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&item)
		jobdetail.Name = item.Name
		jobdetail.Description = jd.Description
		jobdetail.UnitPrice = jd.UnitPrice
		jobdetail.Quantity = jd.Quantity
		jobdetail.TaxRate = jd.TaxRate
		jobdetail.DiscountPercent = jd.DiscountPercent
		jobdetail.BufferPercent = jd.BufferPercent
		jobdetail.LineTotal = jd.LineTotal
		jobdetail.ParentItemID = jd.ParentItemID
		jobdetail.SurchargeParentItemID = jd.SurchargeParentItemID
		jobdetail.Key = jd.Key
		storeItemID := make(map[int]int)
		jobdetail.RelatedItems = GetRelatedItemByItemID(requestHeader, lang, jd.ItemID, storeItemID)
		jobdetail.JobTaskType = jd.JobTaskType
		jobdetail.FourDPriceDynamicFormID = jd.FourDPriceDynamicFormID
		jobdetail.TriggerInspectionMode = jd.TriggerInspectionMode
		jobdetail.ServiceTimeInMinutes = item.ServiceTimeInMinutes
		jobdetails = append(jobdetails, jobdetail)
	}
	response.JobDetails = jobdetails

	// @TODO need to add data
	if item.JobMultiple != nil {
		if item.JobMultiple.PrimaryJobID > 0 {
			jobMultipleResponse.PrimaryJobID = &item.JobMultiple.PrimaryJobID
		}

		// get jobselection
		var (
			jobSelections         []models.JobSelection
			jobSelectionResponses []models.JobSelectionResponse
		)
		db.Where("JobID = ?", item.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC").Find(&jobSelections)
		for _, js := range jobSelections {
			var (
				job      models.Job
				jobTasks []models.JobTask
			)
			resultFind := db.Where("JobID = ?", js.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)

			if resultFind.RowsAffected > 0 {
				var (
					jobSelectionResponse         models.JobSelectionResponse
					jobSelectionHeaderResponse   models.JobSelectionHeaderResponse
					jobSelectionJobTotalResponse models.JobSelectionJobTotalResponse
					businessPartner              models.BusinessPartner
				)
				jobSelectionResponse.JobID = job.JobID
				jobSelectionResponse.HasSequence = js.HasSequence
				jobSelectionResponse.Sort = js.Sort
				jobSelectionHeaderResponse.JobNumber = job.JobNumber
				jobSelectionHeaderResponse.JobDate = job.JobDate
				jobSelectionResponse.JobType = job.JobType

				resultFindBP := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBP.RowsAffected > 0 {
					jobSelectionHeaderResponse.CompanyName = businessPartner.CompanyName
				}
				jobSelectionHeaderResponse.ResourceType = job.ResourceType
				jobSelectionResponse.Status = job.Status
				jobSelectionResponse.TotalJob = job.TotalJob
				jobSelectionResponse.LocationID = job.LocationID
				jobSelectionResponse.BusinessPartnerID = job.BusinessPartnerID

				jobSelectionResponse.JobTypeName, jobSelectionResponse.JobTypeIcon = libs.GetEnum(requestHeader, job.JobType, "JobType", lang)
				jobSelectionHeaderResponse.ResourceTypeName, jobSelectionHeaderResponse.ResourceTypeIcon = libs.GetEnum(requestHeader, job.ResourceType, "ResourceType", lang)
				jobSelectionResponse.StatusName, jobSelectionResponse.StatusIcon = libs.GetEnum(requestHeader, job.Status, "JobStatus", lang)
				jobSelectionJobTotalResponse.TotalJob = job.TotalJob
				jobSelectionHeaderResponse.Priority = job.Priority
				jobSelectionHeaderResponse.PriorityName, jobSelectionHeaderResponse.PriorityIcon = libs.GetEnum(requestHeader, job.Priority, "Priority", lang)
				jobSelectionResponse.JobHeader = jobSelectionHeaderResponse
				jobSelectionResponse.JobTotals = jobSelectionJobTotalResponse

				resultFindJobTask := db.Where("JobID = ?", js.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTasks)
				if resultFindJobTask.RowsAffected > 0 {
					for _, jt := range jobTasks {
						var jobTaskSelectionResponse models.JobTaskSelectionResponse
						jobTaskSelectionResponse.JobTaskID = jt.JobTaskID
						jobTaskSelectionResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
						jobTaskSelectionResponse.Status = jt.Status
						jobTaskSelectionResponse.StatusName, jobTaskSelectionResponse.StatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
						jobTaskSelectionResponse.JobType = jt.JobType
						jobTaskSelectionResponse.JobTypeName, jobTaskSelectionResponse.JobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
						jobTaskSelectionResponse.NavigationAddress = jt.NavigationAddress
						jobSelectionResponse.JobTasks = append(jobSelectionResponse.JobTasks, jobTaskSelectionResponse)
					}
				} else {
					jobSelectionResponse.JobTasks = make([]models.JobTaskSelectionResponse, 0)
				}

				jobSelectionResponses = append(jobSelectionResponses, jobSelectionResponse)
			}
		}
		if len(jobSelectionResponses) > 0 {
			jobMultipleResponse.MultipleJobs = jobSelectionResponses
		} else {
			jobMultipleResponse.MultipleJobs = make([]models.JobSelectionResponse, 0)
		}

		response.JobMultiple = &jobMultipleResponse
		response.IsMultiple = true

	} else {
		jobMultipleResponse.MultipleJobs = make([]models.JobSelectionResponse, 0)
		response.JobMultiple = &jobMultipleResponse
	}

	// @TODO need to add data
	if item.JobCombined != nil {
		// get jobselection
		var (
			jobSelections         []models.JobSelection
			jobSelectionResponses []models.JobSelectionResponse
		)
		db.Where("JobID = ?", item.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC").Find(&jobSelections)
		for _, js := range jobSelections {
			var (
				job      models.Job
				jobTasks []models.JobTask
			)
			resultFind := db.Where("JobID = ?", js.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)

			if resultFind.RowsAffected > 0 {
				var (
					jobSelectionResponse         models.JobSelectionResponse
					businessPartner              models.BusinessPartner
					jobSelectionHeaderResponse   models.JobSelectionHeaderResponse
					jobSelectionJobTotalResponse models.JobSelectionJobTotalResponse
				)
				jobSelectionResponse.JobID = job.JobID
				jobSelectionResponse.HasSequence = js.HasSequence
				jobSelectionResponse.Sort = js.Sort
				jobSelectionHeaderResponse.JobNumber = job.JobNumber
				jobSelectionHeaderResponse.JobDate = job.JobDate
				jobSelectionResponse.JobType = job.JobType
				resultFindBP := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
				if resultFindBP.RowsAffected > 0 {
					jobSelectionHeaderResponse.CompanyName = businessPartner.CompanyName
				}
				jobSelectionHeaderResponse.ResourceType = job.ResourceType
				jobSelectionResponse.Status = job.Status
				jobSelectionResponse.TotalJob = job.TotalJob
				jobSelectionResponse.LocationID = job.LocationID
				jobSelectionResponse.IsCombinedChild = job.IsCombinedChild
				jobSelectionResponse.BusinessPartnerID = job.BusinessPartnerID
				jobSelectionResponse.JobTypeName, jobSelectionResponse.JobTypeIcon = libs.GetEnum(requestHeader, job.JobType, "JobType", lang)
				jobSelectionHeaderResponse.ResourceTypeName, jobSelectionHeaderResponse.ResourceTypeIcon = libs.GetEnum(requestHeader, job.ResourceType, "ResourceType", lang)
				jobSelectionResponse.StatusName, jobSelectionResponse.StatusIcon = libs.GetEnum(requestHeader, job.Status, "JobStatus", lang)
				jobSelectionJobTotalResponse.TotalJob = job.TotalJob
				jobSelectionHeaderResponse.Priority = job.Priority
				jobSelectionHeaderResponse.PriorityName, jobSelectionHeaderResponse.PriorityIcon = libs.GetEnum(requestHeader, job.Priority, "Priority", lang)
				jobSelectionResponse.JobHeader = jobSelectionHeaderResponse
				jobSelectionResponse.JobTotals = jobSelectionJobTotalResponse

				resultFindJobTask := db.Where("JobID = ?", js.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTasks)
				if resultFindJobTask.RowsAffected > 0 {
					for _, jt := range jobTasks {
						var jobTaskSelectionResponse models.JobTaskSelectionResponse
						jobTaskSelectionResponse.JobTaskID = jt.JobTaskID
						jobTaskSelectionResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
						jobTaskSelectionResponse.Status = jt.Status
						jobTaskSelectionResponse.StatusName, jobTaskSelectionResponse.StatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
						jobTaskSelectionResponse.JobType = jt.JobType
						jobTaskSelectionResponse.JobTypeName, jobTaskSelectionResponse.JobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
						jobTaskSelectionResponse.NavigationAddress = jt.NavigationAddress
						jobSelectionResponse.JobTasks = append(jobSelectionResponse.JobTasks, jobTaskSelectionResponse)
					}
				} else {
					jobSelectionResponse.JobTasks = make([]models.JobTaskSelectionResponse, 0)
				}

				jobSelectionResponses = append(jobSelectionResponses, jobSelectionResponse)
			}
		}
		if len(jobSelectionResponses) > 0 {
			jobCombinedResponse.CombinedJobs = jobSelectionResponses
		} else {
			jobCombinedResponse.CombinedJobs = make([]models.JobSelectionResponse, 0)
		}

		jobCombinedResponse.Note = item.JobCombined.Note
		jobCombinedResponse.OnTheSameRoute = item.JobCombined.OnTheSameRoute
		jobCombinedResponse.Sequence = item.JobCombined.Sequence
		response.JobCombined = &jobCombinedResponse
		response.IsCombined = true
	} else {
		jobCombinedResponse.CombinedJobs = make([]models.JobSelectionResponse, 0)
		response.JobCombined = &jobCombinedResponse
	}

	if item.JobResourcePickUp != nil {
		jobResourcePickupResponse.AdditionalInformation = item.JobResourcePickUp.AdditionalInformation
		jobResourcePickupResponse.AddressTypeID = item.JobResourcePickUp.AddressTypeID
		jobResourcePickupResponse.Address = item.JobResourcePickUp.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobResourcePickUp.BusinessPartnerID > 0 {
			jobResourcePickupResponse.BusinessPartnerID = &item.JobResourcePickUp.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobResourcePickupResponse.BusinessPartnerID)
		}
		jobResourcePickupResponse.Addresses = addressesResponse
		jobResourcePickupResponse.ContactDetails = item.JobResourcePickUp.ContactDetails
		jobResourcePickupResponse.CountryCode = item.JobResourcePickUp.CountryCode
		jobResourcePickupResponse.ContactPhoneNumber = item.JobResourcePickUp.ContactPhoneNumber
		jobResourcePickupResponse.IsBussinessPartner = item.JobResourcePickUp.IsBussinessPartner
		jobResourcePickupResponse.PreferredDateTime = item.JobResourcePickUp.PreferredDateTime
		jobResourcePickupResponse.Note = item.JobResourcePickUp.Note
		for _, jt := range item.JobTasks {
			if jt.JobType == 7 && jt.JobTaskID == item.JobResourcePickUp.JobTaskID { // 7 = Resource Pick Up
				jobResourcePickupResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				jobResourcePickupResponse.IsSuburb = jt.IsSuburb
				jobResourcePickupResponse.IsFullAddress = jt.IsFullAddress
				break
			}
		}
		response.JobResourcePickUp = &jobResourcePickupResponse
		response.IsResourcePickUp = true
	} else {
		response.JobResourcePickUp = &jobResourcePickupResponse
	}

	if item.JobResourceDelivery != nil {
		jobResourceDeliveryResponse.AdditionalInformation = item.JobResourceDelivery.AdditionalInformation
		jobResourceDeliveryResponse.AddressTypeID = item.JobResourceDelivery.AddressTypeID
		jobResourceDeliveryResponse.Address = item.JobResourceDelivery.Address
		addressesResponse := make([]models.AddressJobResponse, 0)
		if item.JobResourceDelivery.BusinessPartnerID > 0 {
			jobResourceDeliveryResponse.BusinessPartnerID = &item.JobResourceDelivery.BusinessPartnerID
			addressesResponse = GetBusinessPartnerAddress(db, *jobResourceDeliveryResponse.BusinessPartnerID)
		}
		jobResourceDeliveryResponse.Addresses = addressesResponse
		jobResourceDeliveryResponse.ContactDetails = item.JobResourceDelivery.ContactDetails
		jobResourceDeliveryResponse.CountryCode = item.JobResourceDelivery.CountryCode
		jobResourceDeliveryResponse.ContactPhoneNumber = item.JobResourceDelivery.ContactPhoneNumber
		jobResourceDeliveryResponse.IsBussinessPartner = item.JobResourceDelivery.IsBussinessPartner
		jobResourceDeliveryResponse.PreferredDateTime = item.JobResourceDelivery.PreferredDateTime
		jobResourceDeliveryResponse.Note = item.JobResourceDelivery.Note
		for _, jt := range item.JobTasks {
			if jt.JobType == 8 && jt.JobTaskID == item.JobResourceDelivery.JobTaskID { // 8 = Resource Delivery
				jobResourceDeliveryResponse.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				jobResourceDeliveryResponse.IsSuburb = jt.IsSuburb
				jobResourceDeliveryResponse.IsFullAddress = jt.IsFullAddress
				break
			}
		}
		response.JobResourceDelivery = &jobResourceDeliveryResponse
		response.IsResourceDelivery = true
	} else {
		response.JobResourceDelivery = &jobResourceDeliveryResponse
	}

	jobMapResponse.Distance = item.Distance
	jobMapResponse.DistanceCharge = item.DistanceCharge
	jobMapResponse.TravelTime = item.TravelTime
	jobMapResponse.TravelTimeCharge = item.TravelTimeCharge
	if item.JobMap != nil {
		jobMapResponse.JobMapImage = item.JobMap.JobMapImage
	}
	response.JobMap = jobMapResponse

	jobCommentResponse.Comment = item.Comment
	response.JobComment = jobCommentResponse

	jobTotalResponse.Subtotal = item.Subtotal
	jobTotalResponse.TotalTax = item.TotalTax
	jobTotalResponse.TotalTravelAmount = item.TravelTimeCharge + item.DistanceCharge
	jobTotalResponse.TravelTimeTaxAmount = item.TravelTimeChargeTaxRate / 100 * (item.TravelTimeCharge)
	jobTotalResponse.TravelTimeChargeTaxRate = item.TravelTimeChargeTaxRate
	jobTotalResponse.DistanceTaxAmount = item.DistanceChargeTaxRate / 100 * (item.DistanceCharge)
	jobTotalResponse.DistanceChargeTaxRate = item.DistanceChargeTaxRate
	jobTotalResponse.TotalDiscountAmount = item.TotalDiscountAmount
	jobTotalResponse.TotalBufferAmount = item.TotalBufferAmount
	jobTotalResponse.TotalJob = item.TotalJob
	response.JobTotal = jobTotalResponse
	response.IsCombinedChild = item.IsCombinedChild
	response.IsMultipleChild = item.IsMultipleChild
	response.InvoiceMode = item.InvoiceMode
	response.InvoiceTravelCostMode = item.InvoiceTravelCostMode
	response.InvoiceModeName, _ = libs.GetEnum(requestHeader, item.InvoiceMode, "InvoiceMode", lang)
	response.InvoiceTravelCostModeName, _ = libs.GetEnum(requestHeader, item.InvoiceTravelCostMode, "InvoiceTravelCostMode", lang)
	response.JobPrecomputedRoute = item.JobPrecomputedRoute

	var arrRecurringSkipsResponse = make([]models.RecurringSkipResponse, 0)
	if item.RecurringJob != nil {
		recurringJob := *item.RecurringJob
		var recurringJobResponse models.RecurringJobResponse
		recurringJobResponse.RecurringJobID = recurringJob.RecurringJobID
		recurringJobResponse.JobID = recurringJob.JobID
		recurringJobResponse.StartDate = recurringJob.StartDate
		recurringJobResponse.EndDate = recurringJob.EndDate
		recurringJobResponse.ResourceID = recurringJob.ResourceID

		var resourceModel models.Resource
		resultFindResource := db.Where("ResourceID = ?", recurringJob.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
		if resultFindResource.RowsAffected > 0 {
			recurringJobResponse.ResourceName = resourceModel.ResourceName
			recurringJobResponse.ResourceColor = resourceModel.ResourceColor
			recurringJobResponse.ResourceType = resourceModel.ResourceType
			recurringJobResponse.ResourceTypeName, recurringJobResponse.ResourceTypeIcon = libs.GetEnum(requestHeader, resourceModel.ResourceType, "ResourceType", lang)

		}
		recurringJobResponse.IsInfinite = recurringJob.IsInfinite
		recurringJobResponse.IsPaused = recurringJob.IsPaused
		recurringJobResponse.StartTime = recurringJob.StartTime
		recurringJobResponse.Frequency = recurringJob.Frequency
		frequencyName := ""
		keyFrequencyNameTranslated := ""
		switch recurringJob.Frequency {
		case FrequencyDaily:
			frequencyName = FrequencyDailyName
			keyFrequencyNameTranslated = "recurringjobs.frequency_" + strings.ToLower(FrequencyDailyName)
		case FrequencyWeekly:
			frequencyName = FrequencyWeeklyName
			keyFrequencyNameTranslated = "recurringjobs.frequency_" + strings.ToLower(FrequencyWeeklyName)
		case FrequencyMonthly:
			frequencyName = FrequencyMonthlyName
			keyFrequencyNameTranslated = "recurringjobs.frequency_" + strings.ToLower(FrequencyMonthlyName)
		}
		recurringJobResponse.FrequencyName = frequencyName
		if keyFrequencyNameTranslated != "" {
			recurringJobResponse.FrequencyNameTranslated = services.GetMessage(lang, keyFrequencyNameTranslated)
		}
		arrWeekDay := make([]string, 0)
		sWeekDay := strings.TrimSpace(recurringJob.WeekDay)
		if sWeekDay != "" {
			arrWeekDay = strings.Split(sWeekDay, ",")
		}
		for i := range arrWeekDay {
			arrWeekDay[i] = strings.TrimSpace(arrWeekDay[i])
		}
		recurringJobResponse.WeekDay = arrWeekDay
		recurringJobResponse.MonthDay = recurringJob.MonthDay
		recurringJobResponse.MonthFSTFL = recurringJob.MonthFSTFL
		recurringJobResponse.Every = recurringJob.Every
		recurringJobResponse.Comment = recurringJob.Comment

		var recurringStatus int
		if recurringJob.IsPaused {
			recurringStatus = 3
		} else {
			dCurrentDay, _ := services.ConvertStringToDateTime(time.Now().Format(libs.FORMATDATE))
			if recurringJob.StartDate != nil {
				startDate := *recurringJob.StartDate
				dStartDate, _ := services.ConvertStringToDateTime(startDate.Format(libs.FORMATDATE))
				if dCurrentDay.Unix() < dStartDate.Unix() {
					recurringStatus = 0
				} else {
					if recurringJob.IsInfinite {
						recurringStatus = 1
					} else {
						if recurringJob.EndDate != nil {
							endDate := *recurringJob.EndDate
							dEndDate, _ := services.ConvertStringToDateTime(endDate.Format(libs.FORMATDATE))
							if dCurrentDay.Unix() <= dEndDate.Unix() {
								recurringStatus = 1
							} else {
								recurringStatus = 2
							}
						}
					}
				}
			}
		}

		recurringJobResponse.RecurringStatus = recurringStatus
		recurringStatusName := ""
		switch recurringStatus {
		case RecurringStatusNotStarted:
			recurringStatusName = services.GetMessage(lang, "recurringjobs.recurringstatus_notstarted")
		case RecurringStatusInProgress:
			recurringStatusName = services.GetMessage(lang, "recurringjobs.recurringstatus_inprogress")
		case RecurringStatusEnded:
			recurringStatusName = services.GetMessage(lang, "recurringjobs.recurringstatus_ended")
		case RecurringStatusPaused:
			recurringStatusName = services.GetMessage(lang, "recurringjobs.recurringstatus_paused")
		}
		recurringJobResponse.RecurringStatusTranslated = recurringStatusName
		response.RecurringJob = &recurringJobResponse

		// RecurringSkip section
		recurringSkips := recurringJob.RecurringSkips
		for _, recurringSkip := range recurringSkips {
			var recurringSkipResponse models.RecurringSkipResponse
			recurringSkipResponse.RecurringSkipID = recurringSkip.RecurringSkipID
			recurringSkipResponse.RecurringJobID = recurringSkip.RecurringJobID
			recurringSkipResponse.SkipFromDate = recurringSkip.SkipFromDate
			recurringSkipResponse.SkipToDate = recurringSkip.SkipToDate
			arrRecurringSkipsResponse = append(arrRecurringSkipsResponse, recurringSkipResponse)
		}
	}

	response.RecurringSkips = arrRecurringSkipsResponse

	resourceTypes := make([]string, 0)
	if item.ExtraResources != "" {
		resourceTypes = strings.Split(item.ExtraResources, ",")
	}
	arrResourceTypes, _ := libs.ConvertArrayStringToInt(resourceTypes)
	extraResourcesResponse := make([]models.ExtraResourcesResponse, 0)
	if len(arrResourceTypes) > 0 {
		for _, resType := range arrResourceTypes {
			var extraResources models.ExtraResourcesResponse
			extraResources.ResourceType = resType
			extraResources.ResourceTypeName, extraResources.ResourceTypeIcon = libs.GetEnum(requestHeader, resType, "ResourceType", lang)
			extraResourcesResponse = append(extraResourcesResponse, extraResources)
		}
	}
	response.ExtraResources = extraResourcesResponse

	if response.JobTasks != nil {
		responseJobTasks := *response.JobTasks
		for i := range responseJobTasks {
			var (
				job4DPrices            []models.Job4DPrice
				job4DPricesResponse    = make([]models.Job4DPriceResponse, 0)
				formUDTJSONFor4DPrices = make([]models.FormUDTJSONFor4DPrice, 0)
			)
			db.Where("JobID = ? AND JobTaskID = ?", response.JobID, responseJobTasks[i].JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&job4DPrices)
			for j := range job4DPrices {
				var job4DPriceResponse models.Job4DPriceResponse
				job4DPriceResponse.Job4DPriceID = job4DPrices[j].Job4DPriceID
				job4DPriceResponse.FourDPriceID = job4DPrices[j].FourDPriceID
				job4DPriceResponse.JobID = job4DPrices[j].JobID
				job4DPriceResponse.JobTaskID = job4DPrices[j].JobTaskID
				job4DPriceResponse.ItemID = job4DPrices[j].ItemID
				job4DPriceResponse.Key = job4DPrices[j].Key
				job4DPriceResponse.SurchargeItemID = job4DPrices[j].SurchargeItemID
				var fourDPriceModel models.FourDPrice
				resultFind4DPrice := db.Where("4DPriceID = ?", job4DPrices[j].FourDPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&fourDPriceModel)
				if resultFind4DPrice.RowsAffected > 0 {
					job4DPriceResponse.Dimension1 = ConvertData4DPriceDimensionResponse(job4DPrices[j].Dimension1, fourDPriceModel.Dimension1DataType)
					job4DPriceResponse.Dimension2 = ConvertData4DPriceDimensionResponse(job4DPrices[j].Dimension2, fourDPriceModel.Dimension2DataType)
					job4DPriceResponse.Dimension3 = ConvertData4DPriceDimensionResponse(job4DPrices[j].Dimension3, fourDPriceModel.Dimension3DataType)
					job4DPriceResponse.Dimension4 = ConvertData4DPriceDimensionResponse(job4DPrices[j].Dimension4, fourDPriceModel.Dimension4DataType)
				} else {
					job4DPriceResponse.Dimension1 = job4DPrices[j].Dimension1
					job4DPriceResponse.Dimension2 = job4DPrices[j].Dimension2
					job4DPriceResponse.Dimension3 = job4DPrices[j].Dimension3
					job4DPriceResponse.Dimension4 = job4DPrices[j].Dimension4
				}
				job4DPriceResponse.TriggerInspection = job4DPrices[j].TriggerInspection
				job4DPriceResponse.TriggerInspectionCompleted = job4DPrices[j].TriggerInspectionCompleted
				job4DPriceResponse.JobTaskType = responseJobTasks[i].JobType
				job4DPriceResponse.TriggerInspectionMode = job4DPrices[j].TriggerInspectionMode
				job4DPricesResponse = append(job4DPricesResponse, job4DPriceResponse)
			}
			responseJobTasks[i].FourDPrice = job4DPricesResponse

			// Get 4DPrice Form
			for _, jobDetail := range response.JobDetails {
				if jobDetail.FourDPriceDynamicFormID != nil {
					var (
						draftDynamicFormModel models.DraftDynamicForm
						formUDTModel          models.FormUDT
					)
					draftDynamicFormID := jobDetail.FourDPriceDynamicFormID
					resultFindDraftForm := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&draftDynamicFormModel)
					if resultFindDraftForm.RowsAffected > 0 {
						resultFindFormUDT := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&formUDTModel)
						if resultFindFormUDT.RowsAffected > 0 {
							tableName := libs.GetTableNameFromUDTID(formUDTModel.DraftDynamicFormID)
							sqlQuery := `SELECT * FROM ` + tableName
							// Filter
							sqlWhere := "JobTaskID = ? AND ItemID = ? AND `Key` = ?"
							if sqlWhere != "" {
								sqlWhere = sqlWhere + ` AND `
							}
							sqlWhere = sqlWhere + "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1"

							// Finished filter
							if sqlWhere != "" {
								sqlQuery = sqlQuery + ` WHERE ` + sqlWhere
							}
							rows, errQuery := db.Raw(sqlQuery, responseJobTasks[i].JobTaskID, jobDetail.ItemID, jobDetail.Key).Rows()
							if errQuery == nil {
								ArrayQueryMap := make([]map[string]interface{}, 0)
								defer rows.Close()
								mapColumsType := make(map[string]string)
								colsType, _ := rows.ColumnTypes()
								for _, ty := range colsType {
									if ty != nil {
										sqlColumType := *ty
										mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
									}
								}
								cols, _ := rows.Columns()
								for rows.Next() {
									data := make(map[string]interface{})
									columns := make([]*string, len(cols))
									columnPointers := make([]interface{}, len(cols))
									for i := range columns {
										columnPointers[i] = &columns[i]
									}
									rows.Scan(columnPointers...)
									for i, colName := range cols {
										if !libs.RemoveDefaultFieldsOnDynamicGenerateTable(colName) {
											vColumName, sColumName := mapColumsType[colName]
											if sColumName && columns[i] != nil {
												data[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
											} else {
												data[colName] = columns[i]
											}
										}
									}
									data["DynamicFormID"] = draftDynamicFormID
									data["JobTaskType"] = responseJobTasks[i].JobType
									ArrayQueryMap = append(ArrayQueryMap, data)
								}

								primaryKeyFieldName := libs.GetPrimaryKeyFromUDTID(formUDTModel.DraftDynamicFormID)
								daformUDTJSONFor4DPrice := ConvertArrayUDTDataToArrayResponse4DPrice(ArrayQueryMap, primaryKeyFieldName, requestHeader, lang)
								if len(daformUDTJSONFor4DPrice) > 0 {
									formUDTJSONFor4DPrices = append(formUDTJSONFor4DPrices, daformUDTJSONFor4DPrice[0])
								}
							}
						}
					}
				}
			}
			responseJobTasks[i].FourDPriceForm = formUDTJSONFor4DPrices
		}
		response.JobTasks = &responseJobTasks
	}
	additionalFiles := make([]models.AdditionalFileResponse, 0)
	for _, jd := range item.AdditionalFiles {
		var (
			addFile models.AdditionalFileResponse
		)
		addFile.AdditionalFileID = jd.AdditionalFileID
		addFile.Type = jd.Type
		addFile.JobNumber = item.JobNumber
		addFile.JobID = jd.JobID
		addFile.Name = jd.Name
		addFile.FileKey = jd.FileKey
		addFile.ETag = jd.ETag
		addFile.FileSize = jd.FileSize
		addFile.FileURL = jd.FileURL
		additionalFiles = append(additionalFiles, addFile)
	}
	response.AdditionalFiles = additionalFiles
	return response
}

// ConvertArrayJobsToArrayResponse func
func ConvertArraySelectJobsToArrayResponse(requestHeader models.RequestHeader, items []models.Job, lang string, isUpdate bool) models.SelectJobResponse {
	var responses models.SelectJobResponse
	for _, item := range items {
		responses.JobID = append(responses.JobID, item.JobID)
	}
	return responses
}

// CheckDocumentSequencesBeforeCreate func
func CheckDocumentSequencesBeforeCreate(requestHeader models.RequestHeader) {
	var (
		resModel models.DocumentSequency
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected <= 0 {
		resModel.JobNumber = 1
		resModel.EstimateNumber = 1
		resModel.InvoiceNumber = 1
		resModel.CreditNoteNumber = 1
		resModel.CustomerCode = 1
		resModel.VendorCode = 1
		resModel.ContractorCode = 1
		resModel.ResourceCode = 1
		db.Create(&resModel)
	}
}

// IncreaseDocumentSequencesAfterCreateJob func
func IncreaseDocumentSequencesAfterCreateJob(isJob, isEstimate, isInvoice, isCreditNote bool, requestHeader models.RequestHeader) {
	var (
		resModel models.DocumentSequency
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFind := db.First(&resModel)
	if isJob {
		resModel.JobNumber = resModel.JobNumber + 1
	}
	if isEstimate {
		resModel.EstimateNumber = resModel.EstimateNumber + 1
	}
	if isInvoice {
		resModel.InvoiceNumber = resModel.InvoiceNumber + 1
	}
	if isCreditNote {
		resModel.CreditNoteNumber = resModel.CreditNoteNumber + 1
	}
	if resultFind.RowsAffected > 0 {
		db.Save(&resModel)
	} else {
		db.Create(&resModel)
	}
}

// CreateTravelCalculation func
func CreateTravelCalculation(requestHeader models.RequestHeader, travelCalculation []models.TravelCalculation, jobID int) {
	if len(travelCalculation) > 0 {
		db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		for _, travelCalc := range travelCalculation {
			var (
				travelCalculation models.TravelCalculation
			)
			travelCalculation.JobID = jobID
			travelCalculation.TravelCalculationMode = travelCalc.TravelCalculationMode
			travelCalculation.ItemID = travelCalc.ItemID
			travelCalculation.TravelDistanceAmount = travelCalc.TravelDistanceAmount
			travelCalculation.TravelTimeAmount = travelCalc.TravelTimeAmount
			db.Create(&travelCalculation)
		}
	}
}

// UpdateJobTaskIDToSubJobAfterProcessJob func
func UpdateJobTaskIDToSubJobAfterProcessJob(requestHeader models.RequestHeader, job models.Job) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	if len(job.JobTasks) > 0 {
		for _, jobTask := range job.JobTasks {
			switch jobTask.JobType {
			case models.JobTypeOnSite:
				if job.JobOnSite != nil {
					jobSub := *job.JobOnSite
					if jobSub.JobOnSiteID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			case models.JobTypePickup:
				if job.JobPickup != nil {
					jobSub := *job.JobPickup
					if jobSub.JobPickupID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			case models.JobTypeDelivery:
				if job.JobDelivery != nil {
					jobSub := *job.JobDelivery
					if jobSub.JobDeliveryID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			case models.JobTypeInStore:
				if job.JobInStore != nil {
					jobSub := *job.JobInStore
					if jobSub.JobInStoreID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			case models.JobTypeResourcePickUp:
				if job.JobResourcePickUp != nil {
					jobSub := *job.JobResourcePickUp
					if jobSub.JobResourcePickupID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			case models.JobTypeResourceDelivery:
				if job.JobResourceDelivery != nil {
					jobSub := *job.JobResourceDelivery
					if jobSub.JobResourceDeliveryID > 0 {
						jobSub.JobTaskID = jobTask.JobTaskID
						db.Save(&jobSub)
					}
				}
			}
		}
	}
}

// ConvertJobFormsNavigationToResponse func
func ConvertJobFormsNavigationToResponse(requestHeader models.RequestHeader, lang string, jobID int, navigation *string) models.JobFormNavigationResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		response       models.JobFormNavigationResponse
		jobNavigations = make([]models.JobFormNavigation, 0)
	)
	if navigation != nil {
		jobFormsNavigation := *navigation
		json.Unmarshal([]byte(jobFormsNavigation), &jobNavigations)
	}
	if len(jobNavigations) > 1 {
		// filter
		sort.Slice(jobNavigations, func(i, j int) bool {
			return jobNavigations[i].Task.JobType < jobNavigations[j].Task.JobType
		})
	}
	response.Tasks = jobNavigations
	resultFindPayment := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Payment{})
	if resultFindPayment.RowsAffected > 0 {
		response.HasPayment = true
	}
	for i, task := range response.Tasks {
		if task.BreakForms == nil || len(task.BreakForms) == 0 {
			response.Tasks[i].BreakForms = make([]models.BreakFormsNavigationForm, 0)
		}
	}
	return response
}

// ConvertJobStatusToResponse func
func ConvertJobStatusToResponse(requestHeader models.RequestHeader, item models.Job, lang string) models.JobStatusResponse {
	var (
		response models.JobStatusResponse
	)
	response.JobID = item.JobID
	response.Status = item.Status
	response.StatusName, _ = libs.GetEnum(requestHeader, item.Status, "JobStatus", lang)
	response.InProgressStatus = item.InProgressStatus
	response.JobTaskStatus = item.JobTaskStatus
	jobTasks := make([]models.JobTaskForJobStatusResponse, 0)
	for _, jt := range item.JobTasks {
		var (
			jobTask models.JobTaskForJobStatusResponse
		)
		jobTask.JobTaskID = jt.JobTaskID
		jobTask.JobType = jt.JobType
		jobTask.JobTypeName, _ = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
		jobTask.Status = jt.Status
		jobTask.StatusName, _ = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
		jobTasks = append(jobTasks, jobTask)
	}
	response.JobTasks = &jobTasks

	return response
}

func GetAllJob4DPricesFromJSON(requestHeader models.RequestHeader, accountKey int, job models.Job, bp map[string]interface{}) []models.Job4DPrice {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var job4DPriceModels = make([]models.Job4DPrice, 0)
	_, res := services.ConvertJSONValueToVariable("jobTasks", bp)
	if res != nil {
		var (
			fourDPriceObjJobTask []map[string]interface{}
		)
		fourDPriceObjJobTaskJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(fourDPriceObjJobTaskJSON, &fourDPriceObjJobTask)
			for _, fourDPriceObjJobTaskVar := range fourDPriceObjJobTask {
				_, res4DPrice := services.ConvertJSONValueToVariable("FourDPrice", fourDPriceObjJobTaskVar)
				if res4DPrice != nil {
					var (
						fourDPriceObj []map[string]interface{}
					)
					fourDPriceObjJSON, err := json.Marshal(res4DPrice)
					if err == nil {
						json.Unmarshal(fourDPriceObjJSON, &fourDPriceObj)
						for _, fourDPriceObjVar := range fourDPriceObj {
							var job4DPrice models.Job4DPrice
							job4DPrice.PassBodyJSONToModel(fourDPriceObjVar)
							if job4DPrice.Job4DPriceID > 0 {
								db.Where("Job4DPriceID = ?", job4DPrice.Job4DPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPrice)
								job4DPrice.PassBodyJSONToModel(fourDPriceObjVar)
							}
							if job4DPrice.Job4DPriceID <= 0 {
								job4DPrice.CreatedBy = accountKey
								job4DPrice.ModifiedBy = accountKey
							} else {
								job4DPrice.ModifiedBy = accountKey
							}
							job4DPrice.JobID = job.JobID
							vJobTaskType, resJobTaskType := services.ConvertJSONValueToVariable("JobTaskType", fourDPriceObjVar)
							if resJobTaskType != nil {
								dJobTaskType, _ := strconv.Atoi(vJobTaskType)
								for i := range job.JobTasks {
									if dJobTaskType == job.JobTasks[i].JobType {
										job4DPrice.JobTaskID = job.JobTasks[i].JobTaskID
									}
								}
							}
							job4DPriceModels = append(job4DPriceModels, job4DPrice)
						}
					}
				}
			}
		}
	}
	return job4DPriceModels
}

func UpdateDynamicFormFor4DPrice(requestHeader models.RequestHeader, accountKey int,
	job models.Job, bp map[string]interface{}, lang string) ([]models.FormUDTJSONFor4DPrice, []models.ErrorResponse) {
	var (
		responses      []models.FormUDTJSONFor4DPrice
		errorsResponse []models.ErrorResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	_, res := services.ConvertJSONValueToVariable("jobTasks", bp)
	if res != nil {
		var (
			fourDPriceObjJobTask []map[string]interface{}
		)

		fourDPriceObjJobTaskJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(fourDPriceObjJobTaskJSON, &fourDPriceObjJobTask)
			for _, fourDPriceObjJobTaskVar := range fourDPriceObjJobTask {
				_, res4DPrice := services.ConvertJSONValueToVariable("FourDPriceForm", fourDPriceObjJobTaskVar)
				if res4DPrice != nil {
					var (
						fourDPriceObj []models.FormUDTJSONFor4DPrice
						arrSkipUDTID  []int
					)
					fourDPriceObjJSON, err := json.Marshal(res4DPrice)
					if err == nil {
						json.Unmarshal(fourDPriceObjJSON, &fourDPriceObj)
						if len(fourDPriceObj) > 0 {
							for _, fourDPriceObjVar := range fourDPriceObj {
								var (
									draftDynamicFormModel models.DraftDynamicForm
									formUDTModel          models.FormUDT
									status                = libs.GetStatusSuccess()
									msg                   interface{}
								)
								draftDynamicFormID := fourDPriceObjVar.DynamicFormID
								resultFindDraftForm := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&draftDynamicFormModel)
								if resultFindDraftForm.RowsAffected > 0 {
									resultFindFormUDT := db.Where("DraftDynamicFormID = ?", draftDynamicFormID).First(&formUDTModel)
									if resultFindFormUDT.RowsAffected > 0 {
										if err == nil {
											dateTimeFormat := "2006-01-02 15:04:05"
											timeNow := time.Now().Format(dateTimeFormat)
											primaryKeyVal := 0
											arrValues := make([]interface{}, 0)
											arrFields := make([]string, 0)
											arrInsertKeyFields := make([]string, 0)
											arrInsertValueFields := make([]string, 0)
											tableName := libs.GetTableNameFromUDTID(formUDTModel.DraftDynamicFormID)
											var JSONObject map[string]interface{}
											inrec, _ := json.Marshal(fourDPriceObjVar)
											json.Unmarshal(inrec, &JSONObject)
											primaryKeyFieldName := libs.GetPrimaryKeyFromUDTID(formUDTModel.DraftDynamicFormID)
											for k, v := range JSONObject {
												switch k {
												case "FormPrimaryKey":
													{
														strPrimaryKey := fmt.Sprintf("%v", v)
														vPrimaryKey, sPrimaryKey := strconv.Atoi(strPrimaryKey)
														if sPrimaryKey == nil {
															primaryKeyVal = vPrimaryKey
														}
													}
												case "JobID":
													{
														if primaryKeyVal > 0 {
															arrFields = append(arrFields, k+` = ?`)
															arrInsertKeyFields = append(arrInsertKeyFields, k)
															arrInsertValueFields = append(arrInsertValueFields, `?`)
															arrValues = append(arrValues, v)
														} else {
															arrFields = append(arrFields, k+` = ?`)
															arrInsertKeyFields = append(arrInsertKeyFields, k)
															arrInsertValueFields = append(arrInsertValueFields, `?`)
															arrValues = append(arrValues, job.JobID)
														}
													}
												case "JobTaskID":
													{
														if primaryKeyVal > 0 {
															arrFields = append(arrFields, k+` = ?`)
															arrInsertKeyFields = append(arrInsertKeyFields, k)
															arrInsertValueFields = append(arrInsertValueFields, `?`)
															arrValues = append(arrValues, v)
														} else {
															arrFields = append(arrFields, k+` = ?`)
															arrInsertKeyFields = append(arrInsertKeyFields, k)
															arrInsertValueFields = append(arrInsertValueFields, `?`)
															jobTaskType, _ := strconv.Atoi(fmt.Sprintf("%v", fourDPriceObjVar.JobTaskType))
															for i := range job.JobTasks {
																if jobTaskType == job.JobTasks[i].JobType {
																	arrValues = append(arrValues, job.JobTasks[i].JobTaskID)
																	break
																}
															}
														}
													}
												case "ItemID":
													{
														arrFields = append(arrFields, k+` = ?`)
														arrInsertKeyFields = append(arrInsertKeyFields, k)
														arrInsertValueFields = append(arrInsertValueFields, `?`)
														arrValues = append(arrValues, v)
													}
												case "Key":
													{
														arrFields = append(arrFields, "`Key`"+` = ?`)
														arrInsertKeyFields = append(arrInsertKeyFields, "`Key`")
														arrInsertValueFields = append(arrInsertValueFields, `?`)
														arrValues = append(arrValues, v)
													}
												case "Controls":
													{
														// Remove primary key out of array value
														var controlsJSON []models.FormUDTControl
														objectControlsJSON, errObjectControls := json.Marshal(v)
														if errObjectControls == nil {
															json.Unmarshal(objectControlsJSON, &controlsJSON)
															for _, controlObj := range controlsJSON {
																fieldName := fmt.Sprintf("%v", controlObj.FieldName)
																arrFields = append(arrFields, fieldName+` = ?`)
																arrInsertKeyFields = append(arrInsertKeyFields, fieldName)
																arrInsertValueFields = append(arrInsertValueFields, `?`)
																fieldType := libs.CheckDatabaseDateTimeByFieldNameAndTableName(requestHeader, tableName, fieldName)
																switch fieldType {
																case "DATE", "DATETIME":
																	{
																		fieldVal := fmt.Sprintf("%v", controlObj.Value)
																		dFieldVal, sFieldVal := libs.ConvertStringToDateTime(fieldVal)
																		if sFieldVal == nil {
																			arrValues = append(arrValues, dFieldVal.Format(dateTimeFormat))
																		} else {
																			arrValues = append(arrValues, controlObj.Value)
																		}
																	}
																default:
																	arrValues = append(arrValues, controlObj.Value)
																}
															}
														}
													}
												}
											}
											if primaryKeyVal > 0 {
												arrSkipUDTID = append(arrSkipUDTID, primaryKeyVal)
												arrFields = append(arrFields, "ModifiedBy"+` = ?`)
												arrValues = append(arrValues, strconv.Itoa(accountKey))
												arrFields = append(arrFields, "ModifiedDate"+` = ?`)
												arrValues = append(arrValues, timeNow)

												strFields := strings.Join(arrFields, ", ")
												sql := `UPDATE ` + tableName + ` SET ` + strFields
												sql = sql + ` WHERE ` + primaryKeyFieldName + ` = ` + strconv.Itoa(primaryKeyVal) + `;`
												err = db.Exec(sql, arrValues...).Error
												if err != nil {
													status = 500
													msg = err.Error()
												}
											} else {
												arrInsertKeyFields = append(arrInsertKeyFields, "CreatedBy")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, strconv.Itoa(accountKey))
												arrInsertKeyFields = append(arrInsertKeyFields, "ModifiedBy")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, strconv.Itoa(accountKey))
												arrInsertKeyFields = append(arrInsertKeyFields, "CreatedDate")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, timeNow)
												arrInsertKeyFields = append(arrInsertKeyFields, "ModifiedDate")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, timeNow)
												arrInsertKeyFields = append(arrInsertKeyFields, "IsDeleted")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, 0)
												arrInsertKeyFields = append(arrInsertKeyFields, "IsAudit")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, 0)
												arrInsertKeyFields = append(arrInsertKeyFields, "IsArchived")
												arrInsertValueFields = append(arrInsertValueFields, `?`)
												arrValues = append(arrValues, 0)
												strKeyFields := strings.Join(arrInsertKeyFields, ", ")
												strValueFields := strings.Join(arrInsertValueFields, ", ")
												sql := `INSERT INTO ` + tableName + ` (` + strKeyFields + `) VALUES (` + strValueFields + `)`
												fmt.Println(sql)
												sqlDB, errSqlDB := db.Debug().DB()
												if errSqlDB == nil {
													resExec, errExec := sqlDB.Exec(sql, arrValues...)
													if errExec != nil {
														status = 500
														msg = errExec.Error()
													} else {
														newID, errLast := resExec.LastInsertId()
														if errLast == nil {
															primaryKeyVal = int(newID)
															arrSkipUDTID = append(arrSkipUDTID, primaryKeyVal)
														} else {
															status = 500
															msg = errLast.Error()
															errResponse := GetErrorResponseErrorMessage(0, msg)
															errorsResponse = append(errorsResponse, errResponse)
														}
													}
												} else {
													status = 500
													msg = errSqlDB.Error()
													errResponse := GetErrorResponseErrorMessage(0, msg)
													errorsResponse = append(errorsResponse, errResponse)
												}
											}
											if status == 200 {
												sqlSelect := `SELECT * FROM ` + tableName + ` WHERE ` + primaryKeyFieldName + ` = ?`
												rows, errQuery := db.Raw(sqlSelect, primaryKeyVal).Rows()
												if errQuery == nil {
													defer rows.Close()
													ArrayQueryMap := make([]map[string]interface{}, 0)
													mapColumsType := make(map[string]string)
													colsType, _ := rows.ColumnTypes()
													for _, ty := range colsType {
														if ty != nil {
															sqlColumType := *ty
															mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
														}
													}
													cols, _ := rows.Columns()
													for rows.Next() {
														data := make(map[string]interface{})
														columns := make([]*string, len(cols))
														columnPointers := make([]interface{}, len(cols))
														for i := range columns {
															columnPointers[i] = &columns[i]
														}
														rows.Scan(columnPointers...)
														for i, colName := range cols {
															if !libs.RemoveDefaultFieldsOnDynamicGenerateTable(colName) {
																vColumName, sColumName := mapColumsType[colName]
																if sColumName && columns[i] != nil {
																	data[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
																} else {
																	data[colName] = columns[i]
																}
															}
														}
														ArrayQueryMap = append(ArrayQueryMap, data)
													}
													if len(ArrayQueryMap) > 0 {
														response := ConvertArrayUDTDataToArrayResponse4DPrice(ArrayQueryMap, primaryKeyFieldName, requestHeader, lang)
														responses = append(responses, response[0])
													}
												} else {
													status = 500
													msg = errQuery.Error()
													errResponse := GetErrorResponseErrorMessage(0, msg)
													errorsResponse = append(errorsResponse, errResponse)
												}
											}
										} else {
											status = 500
											msg = err.Error()
										}
									} else {
										status = 404
										msg = services.GetMessage(lang, "api.formudt_not_found")
										errResponse := GetErrorResponseErrorMessage(0, msg)
										errorsResponse = append(errorsResponse, errResponse)
									}
								} else {
									status = 404
									msg = services.GetMessage(lang, "api.drafdynamicformid_not_found")
									errResponse := GetErrorResponseErrorMessage(0, msg)
									errorsResponse = append(errorsResponse, errResponse)
								}
								if status == 200 {
									msg = services.GetMessage(lang, "api.success")
								} else {
									errResponse := GetErrorResponseErrorMessage(0, msg)
									errorsResponse = append(errorsResponse, errResponse)
								}
							}
						} else {
							for _, jobDetail := range job.JobDetails {
								if jobDetail.FourDPriceDynamicFormID != nil {
									tableName := libs.GetTableNameFromUDTID(*jobDetail.FourDPriceDynamicFormID)
									if tableName != "" {
										// Delete all 4D Price form data
										db.Exec("DELETE FROM `"+tableName+"` WHERE JobID = ? AND ItemID IS  NOT NULL AND `Key` Is NOT NULL", job.JobID)
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return responses, errorsResponse
}

func ValidateInspectionJobSettingBeforeProcessJob(requestHeader models.RequestHeader, lang string, accountKey int, job models.Job, bp map[string]interface{}) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		job4DPriceModels        = make([]models.Job4DPrice, 0)
		hasCreateInspectionJob  = false
		settingInspectionItemID int
		settingJobTemplateID    int
		errMsg                  string
	)
	job4DPriceModels = GetAllJob4DPricesFromJSON(requestHeader, accountKey, job, bp)
	for _, job4DPriceModel := range job4DPriceModels {
		if job4DPriceModel.TriggerInspection {
			hasCreateInspectionJob = true
			break
		}
	}
	if hasCreateInspectionJob {
		var (
			settingModel models.Setting
		)
		resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
		if resultFindSetting.RowsAffected > 0 {
			if settingModel.Value != nil {
				var (
					settingValue models.SettingValue
				)
				errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
				if errSettingValue == nil {
					settingInspectionItemID = settingValue.PriceLists.FDPricesInspectionServiceItem
					if settingValue.PriceLists.FDPricesInspectionJobTemplate != nil {
						settingJobTemplateID = *settingValue.PriceLists.FDPricesInspectionJobTemplate
					}
				}
			}
		}
		if settingInspectionItemID <= 0 {
			errMsg = libs.GetStringWithWordBetween(errMsg, services.GetMessage(lang, "api.inspection_itemid_required"))
		}
		if settingJobTemplateID <= 0 {
			errMsg = libs.GetStringWithWordBetween(errMsg, services.GetMessage(lang, "api.inspection_jobtemplateid_required"))
		}
	}
	return errMsg
}
