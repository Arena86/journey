package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// GetStatusStateBP func
func GetStatusStateBP(method string, lang string, totalUpdatedRecords int, totalObjects int, errResponses []models.ErrorResponse, hasChild bool) (int, interface{}) {
	var (
		status      = libs.GetStatusSuccess()
		msg         interface{}
		totalErrors int
	)
	totalErrors = len(errResponses)
	if totalUpdatedRecords == 0 {
		status = libs.GetStatusError()
		msg = services.GetMessage(lang, "api.full_failed")
	} else if totalUpdatedRecords < totalObjects {
		msg = services.GetMessage(lang, "api.create_success")
	} else {
		keySuccess := "api.success"
		if strings.ToLower(method) == "post" {
			keySuccess = "api.create_success"
		} else if strings.ToLower(method) == "put" {
			keySuccess = "api.update_success"
		} else if strings.ToLower(method) == "delete" {
			keySuccess = "api.delete_success"
		}
		msg = services.GetMessage(lang, keySuccess)
		if hasChild {
			if totalErrors > 0 {
				msg = services.GetMessage(lang, "api.create_success")
			}
		}
	}
	return status, msg
}

// GetStatusState func
func GetStatusState(method string, lang string, totalUpdatedRecords int, totalObjects int, errResponses []models.ErrorResponse, hasChild bool) (int, interface{}) {
	var (
		status      = libs.GetStatusSuccess()
		msg         interface{}
		totalErrors int
	)
	totalErrors = len(errResponses)
	if totalUpdatedRecords == 0 {
		status = libs.GetStatusError()
		msg = services.GetMessage(lang, "api.full_failed")
	} else if totalUpdatedRecords < totalObjects {
		status = libs.GetStatusPartial()
		msg = services.GetMessage(lang, "api.partial_success")
	} else {
		keySuccess := "api.success"
		if strings.ToLower(method) == "post" {
			keySuccess = "api.create_success"
		} else if strings.ToLower(method) == "put" {
			keySuccess = "api.update_success"
		} else if strings.ToLower(method) == "delete" {
			keySuccess = "api.delete_success"
		}
		msg = services.GetMessage(lang, keySuccess)
		if hasChild {
			if totalErrors > 0 {
				status = libs.GetStatusPartial()
				msg = services.GetMessage(lang, "api.partial_success")
			}
		}
	}
	return status, msg
}

// GetErrorResponseNotFound func
func GetErrorResponseNotFound(lang string, index int) models.ErrorResponse {
	var (
		errResponse models.ErrorResponse
	)
	errResponse.Index = index
	errResponse.Message = services.GetMessage(lang, "api.no_record_found")
	errResponse.Type = models.ErrorResponseTypeError
	return errResponse
}

// GetErrorResponseWarningMessage func
func GetErrorResponseWarningMessage(index int, message interface{}) models.ErrorResponse {
	var (
		errResponse models.ErrorResponse
	)
	errResponse.Index = index
	errResponse.Message = message
	errResponse.Type = models.ErrorResponseTypeWarning
	return errResponse
}

// GetErrorResponseErrorMessage func
func GetErrorResponseErrorMessage(index int, message interface{}) models.ErrorResponse {
	var (
		errResponse models.ErrorResponse
	)
	errResponse.Index = index
	errResponse.Message = message
	errResponse.Type = models.ErrorResponseTypeError
	return errResponse
}

// GetErrorResponseValidate func
func GetErrorResponseValidate(lang string, index int, key string) models.ErrorResponse {
	var (
		errResponse models.ErrorResponse
	)
	errResponse.Index = index
	errResponse.Message = services.GetMessage(lang, key)
	errResponse.Type = models.ErrorResponseTypeError
	return errResponse
}

// GetPermissionByAccountKey func
func GetPermissionByAccountKey(requestHeader models.RequestHeader, c *gin.Context, method string, permissionArea string) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		userModel       models.User
		permissionModel models.Permission
		securityGroupID = 0
		permission      = false
	)
	accountKeyHeader, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND AccountKey = ?", accountKeyHeader).First(&userModel)
	securityGroupID = userModel.SecurityGroupID
	if securityGroupID > 0 {
		db.Where("SecurityGroupID = ? AND Area = ?", securityGroupID, permissionArea).First(&permissionModel)
		switch strings.ToLower(method) {
		case "get":
			{
				if permissionModel.CanView != nil {
					if *permissionModel.CanView {
						permission = true
					}
				}
			}
		case "post":
			{
				if permissionModel.CanCreate != nil {
					if *permissionModel.CanCreate {
						permission = true
					}
				}
			}
		case "put":
			{
				if permissionModel.CanEdit != nil {
					if *permissionModel.CanEdit {
						permission = true
					}
				}
			}
		case "delete":
			{
				if permissionModel.CanDelete != nil {
					if *permissionModel.CanDelete {
						permission = true
					}
				}
			}
		}

	}
	return permission
}

// GetResponseNotPermission func
func GetResponseNotPermission(c *gin.Context) (int, models.APIResponseData) {
	var (
		response models.APIResponseData
		status   = libs.GetStatusError()
		//errResponse models.ErrorResponse
	)
	lang := services.GetLanguageKey(c)
	message := services.GetMessage(lang, "api.notpermission")

	errorsResponse := make([]models.ErrorResponse, 0)
	/* errResponse.Index = 0
	errResponse.Message = message
	errResponse.Type = models.ErrorResponseTypeError
	errorsResponse = append(errorsResponse, errResponse) */

	response.Status = status
	response.Data = nil
	response.Errors = errorsResponse
	response.Message = message
	return status, response
}
