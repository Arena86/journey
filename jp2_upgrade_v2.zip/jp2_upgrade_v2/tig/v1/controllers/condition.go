package controllers

import (
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// CheckFormCondition godoc
// @Summary CheckFormCondition
// @Description CheckFormCondition
// @Tags FormCondition
// @Accept  json
// @Produce  json
// @Param JobID query int true "JobID"
// @Param JobTaskID query int true "JobTaskID"
// @Param id path int true "Condition ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkformcondition/{conditionid} [get]
func CheckFormCondition(c *gin.Context) {
	defer libs.RecoverError(c, "CheckFormCondition")
	var (
		status           = libs.GetStatusSuccess()
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		msg              interface{}
		data             interface{}
		validateMsgError string
		jobID            int
		jobTaskID        int
		formID           string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != libs.GetStatusSuccess() {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	conditionID := c.Param("conditionid")
	vJobID, sJobID := libs.GetQueryParam("JobID", c)
	if sJobID {
		dJobID, errJobID := strconv.Atoi(vJobID)
		if errJobID == nil {
			jobID = dJobID
		}
	}
	if jobID <= 0 {
		status = libs.GetInvalidValidateStatus()
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobid_required"))
	}
	vJobTaskID, sJobTaskID := libs.GetQueryParam("JobTaskID", c)
	if sJobTaskID {
		dJobTaskID, errJobTaskID := strconv.Atoi(vJobTaskID)
		if errJobTaskID == nil {
			jobTaskID = dJobTaskID
		}
	}
	if jobTaskID <= 0 {
		status = libs.GetInvalidValidateStatus()
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtaskid_required"))
	}

	if status == libs.GetStatusSuccess() {
		var resStatus int
		formID, validateMsgError, resStatus = CheckFormConditionFunc(requestHeader, lang, conditionID, jobID, jobTaskID)
		if validateMsgError != "" {
			status = resStatus
		} else {
			data = map[string]interface{}{"FormID": formID}
		}
	}

	if status == libs.GetStatusSuccess() {
		msg = services.GetMessage(lang, "api.success")
	} else {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CheckFormConditionFunc func
func CheckFormConditionFunc(requestHeader models.RequestHeader, lang string, conditionID string, jobID int, jobTaskID int) (string, string, int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		status              = libs.GetStatusSuccess()
		validateMsgError    string
		formConditionModels []models.FormCondition
		findStatus          bool
		formID              string
	)
	db.Where("ConditionID = ?", conditionID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&formConditionModels)
	if len(formConditionModels) > 0 {
		// group by conditiongroup
		var arrConditionGroupSort = make([]models.ConditionGroupSort, 0)
		for _, formCondition := range formConditionModels {
			var hasGroup = false
			for j, groupSort := range arrConditionGroupSort {
				if formCondition.ConditionGroup == groupSort.Group {
					hasGroup = true
					arrConditionGroupSort[j].Conditions = append(arrConditionGroupSort[j].Conditions, formCondition)
				}
			}
			if !hasGroup {
				var conditionGroupSort models.ConditionGroupSort
				conditionGroupSort.Group = formCondition.ConditionGroup
				conditionGroupSort.Conditions = append(conditionGroupSort.Conditions, formCondition)
				arrConditionGroupSort = append(arrConditionGroupSort, conditionGroupSort)
			}
		}
		for _, groupCondition := range arrConditionGroupSort {
			// @TODO current process with multi group
			var resStatus int
			findStatus, validateMsgError, resStatus = CheckFormConditionByGroupFunc(requestHeader, lang, groupCondition.Conditions, jobID, jobTaskID)
			if validateMsgError != "" {
				status = resStatus
				break
			} else {
				if findStatus {
					//formID = formConditionModels[0].ToForm
					formID = groupCondition.Conditions[0].ToForm
					break
				}
			}
			// @TODO test 1 group
			//break
		}
		if formID == "" {
			if len(arrConditionGroupSort) > 0 {
				if len(arrConditionGroupSort[0].Conditions) > 0 {
					formID = arrConditionGroupSort[0].Conditions[0].DefaultToForm
				}
			}
		}
	} else {
		formID = "end"
		//status = libs.GetInvalidValidateStatus()
		//validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.conditionid_not_found"))
	}
	return formID, validateMsgError, status
}

// CheckFormConditionByGroupFunc func
func CheckFormConditionByGroupFunc(requestHeader models.RequestHeader, lang string, groupCondition []models.FormCondition, jobID int, jobTaskID int) (bool, string, int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		firstConditionPointer        *models.FormCondition
		validateMsgError             string
		groupConditionOperator       = make([]models.FormCondition, 0)
		findStatus                   bool
		status                       = libs.GetStatusSuccess()
		hasMultiFormIDInGroup        = false
		whereSQL                     string
		arrQueryValues               = make([]interface{}, 0)
		mapGroupDynamicFormTableName = make(map[int]models.FormUDT)
	)
	// find first condition and group condition valid format
	for _, condition := range groupCondition {
		conditionOperator := strings.TrimSpace(condition.Operator)
		if conditionOperator == "" {
			if firstConditionPointer == nil {
				// need to create new variable to store pointer, if not will get last condition because pointer
				firstConditionTemp := condition
				firstConditionPointer = &firstConditionTemp
			} else {
				status = libs.GetInvalidValidateStatus()
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.formcondition_invalid_operator"))
				break
			}
		} else {
			groupConditionOperator = append(groupConditionOperator, condition)
		}
	}
	if firstConditionPointer == nil {
		status = libs.GetInvalidValidateStatus()
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.formcondition_invalid_operator"))
	}
	if validateMsgError == "" {
		hasMultiFormIDInGroup = HasMultipleDynamicFormInGroup(groupCondition)
		// first conditons
		firstCondition := *firstConditionPointer
		hasFirstUDT, firstUDTModel := GetUDTFromDynamicFormID(requestHeader, firstCondition.FormID)
		if !hasFirstUDT {
			status = libs.GetInvalidValidateStatus()
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.formudt_not_found"))
		} else {
			var (
				whereSQLFirstRow string
			)
			firstCondition := *firstConditionPointer
			alias := GetAliasNameFromCondition(firstUDTModel.DraftDynamicFormID)
			whereSQLFirstRow, arrQueryValues = GetConditionQuery(firstCondition, arrQueryValues, hasMultiFormIDInGroup, alias)
			whereSQL = whereSQLFirstRow
			mapGroupDynamicFormTableName[firstCondition.FormID] = firstUDTModel
		}
		// sub group conditions
		if len(groupConditionOperator) > 0 {
			for _, conditionOperator := range groupConditionOperator {
				hasSubUDT, subUDTModel := GetUDTFromDynamicFormID(requestHeader, conditionOperator.FormID)
				if !hasSubUDT {
					status = libs.GetInvalidValidateStatus()
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.formudt_not_found"))
					break
				} else {
					var whereSQLRow string
					aliasSub := GetAliasNameFromCondition(subUDTModel.DraftDynamicFormID)
					whereSQLRow, arrQueryValues = GetConditionQuery(conditionOperator, arrQueryValues, hasMultiFormIDInGroup, aliasSub)
					whereSQL = whereSQL + ` ` + strings.ToUpper(conditionOperator.Operator) + ` ` + whereSQLRow
					mapGroupDynamicFormTableName[conditionOperator.FormID] = subUDTModel
				}
			}
		}
		aliasValue := GetAliasValueFormCondition(hasMultiFormIDInGroup, GetAliasNameFromCondition(firstUDTModel.DraftDynamicFormID))
		// filter JobID & JobTaskID
		if whereSQL != "" {
			whereSQL = whereSQL + ` AND ` + aliasValue + `JobID = ? AND ` + aliasValue + `JobTaskID = ?`
			arrQueryValues = append(arrQueryValues, jobID)
			arrQueryValues = append(arrQueryValues, jobTaskID)
		}
	}
	if validateMsgError == "" {
		sqlQuery := `SELECT * FROM`
		first := true
		tableFirst := ""
		aliasFirst := ""
		validateDelete := ""
		for _, udtModel := range mapGroupDynamicFormTableName {
			tableName := libs.GetTableNameFromUDTID(udtModel.DraftDynamicFormID)
			alias := GetAliasNameFromCondition(udtModel.DraftDynamicFormID)
			aliasValue := GetAliasValueFormCondition(hasMultiFormIDInGroup, GetAliasNameFromCondition(udtModel.DraftDynamicFormID))
			if hasMultiFormIDInGroup {
				if first {
					tableFirst = tableName
					aliasFirst = alias
					sqlQuery = sqlQuery + ` ` + tableFirst + ` ` + aliasFirst
				} else {
					sqlQuery = sqlQuery + ` join ` + tableName + ` ` + alias + ` ON ` + aliasFirst + `.JobID = ` + alias + `.JobID AND ` + aliasFirst + `.JobTaskID = ` + alias + `.JobTaskID`
				}
				first = false
			} else {
				sqlQuery = sqlQuery + ` ` + tableName
				// one group - filter IsDeleted & IsArchived
				validateDelete = `IFNULL(` + aliasValue + `IsDeleted, 0) <> 1 AND IFNULL(` + aliasValue + `IsArchived, 0) <> 1`
				break
			}
			// multi group - filter IsDeleted & IsArchived
			if validateDelete == "" {
				validateDelete = `IFNULL(` + aliasValue + `IsDeleted, 0) <> 1 AND IFNULL(` + aliasValue + `IsArchived, 0) <> 1`
			} else {
				validateDelete = validateDelete + ` AND IFNULL(` + aliasValue + `IsDeleted, 0) <> 1 AND IFNULL(` + aliasValue + `IsArchived, 0) <> 1`
			}
		}
		if whereSQL != "" {
			whereSQL = whereSQL + ` AND ` + validateDelete
		}
		if whereSQL != "" {
			sqlQuery = sqlQuery + ` WHERE ` + whereSQL
		}
		totalCount := 0
		rowsQuery, errQuery := db.Raw(sqlQuery, arrQueryValues...).Rows()
		if errQuery == nil {
			defer rowsQuery.Close()
			for rowsQuery.Next() {
				totalCount = totalCount + 1
			}
		} else {
			status = libs.GetStatusServerError()
			validateMsgError = errQuery.Error()
		}
		// have data in dynamic table with condition data
		if totalCount > 0 {
			findStatus = true
		}
	}
	return findStatus, validateMsgError, status
}

// GetConditionQuery func
func GetConditionQuery(condition models.FormCondition, arrQueryValues []interface{}, hasMultiFormIDInGroup bool, alias string) (string, []interface{}) {
	var (
		sqlQueryValue string
		whereSQL      string
	)
	aliasValue := GetAliasValueFormCondition(hasMultiFormIDInGroup, alias)
	sqlQueryValue, arrQueryValues = GetValueConditionQuery(condition.ConditionCode, condition.ConditionValue, arrQueryValues)
	if sqlQueryValue != "" {
		whereSQL = aliasValue + FormatUDFField(condition.DataField) + ` ` + libs.ChangeUIConditionToMysqlCondition(condition.ConditionCode) + ` ` + sqlQueryValue
	} else {
		whereSQL = aliasValue + FormatUDFField(condition.DataField) + ` ` + libs.ChangeUIConditionToMysqlCondition(condition.ConditionCode)
	}
	return whereSQL, arrQueryValues
}

// GetValueConditionQuery func
func GetValueConditionQuery(conditionCode string, conditionValue interface{}, arrQueryValues []interface{}) (string, []interface{}) {
	var (
		conditionValueQuery string
	)
	switch conditionCode {
	case "nl", "nn":
		break
	case "lk":
		{
			conditionValueQuery = `?`
			strValue := fmt.Sprintf("%v", conditionValue)
			arrQueryValues = append(arrQueryValues, `%`+strValue+`%`)
		}
	case "tf":
		{
			var tfValueDefault = 0
			conditionValueQuery = `?`
			strValue := fmt.Sprintf("%v", conditionValue)
			strValue = strings.ToLower(strValue)
			switch strValue {
			case "yes":
				tfValueDefault = 1
			case "no":
				tfValueDefault = 0
			}
			arrQueryValues = append(arrQueryValues, tfValueDefault)
		}
	default:
		{
			conditionValueQuery = `?`
			arrQueryValues = append(arrQueryValues, conditionValue)
		}
	}
	return conditionValueQuery, arrQueryValues
}

// HasMultipleDynamicFormInGroup func
func HasMultipleDynamicFormInGroup(formConditionModels []models.FormCondition) bool {
	var (
		mapConditionGroup = make(map[int][]models.FormCondition)
	)
	for _, formCondition := range formConditionModels {
		vMapConditionGroup, _ := mapConditionGroup[formCondition.FormID]
		vMapConditionGroup = append(vMapConditionGroup, formCondition)
		mapConditionGroup[formCondition.FormID] = vMapConditionGroup
	}
	if len(mapConditionGroup) > 1 {
		return true
	}
	return false
}

// GetUDTFromDynamicFormID func
func GetUDTFromDynamicFormID(requestHeader models.RequestHeader, dynamicFormID int) (bool, models.FormUDT) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		dynamicFormModel      models.DynamicForm
		draftDynamicFormModel models.DraftDynamicForm
		formUDTModel          models.FormUDT
	)
	resultFindDynamicForm := db.Where("DynamicFormID = ?", dynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&dynamicFormModel)
	if resultFindDynamicForm.RowsAffected > 0 {
		resultFindDraftDynamic := db.Where("DraftDynamicFormID = ?", dynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&draftDynamicFormModel)
		if resultFindDraftDynamic.RowsAffected > 0 {
			resultFindFormUDT := db.Where("DraftDynamicFormID = ?", draftDynamicFormModel.DraftDynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&formUDTModel)
			if resultFindFormUDT.RowsAffected > 0 {
				return true, formUDTModel
			}
		}
	}
	return false, formUDTModel
}

// GetAliasValueFormCondition func
func GetAliasValueFormCondition(hasMultiFormIDInGroup bool, alias string) string {
	if hasMultiFormIDInGroup {
		return alias + "."
	}
	return ""
}

// GetAliasNameFromCondition func
func GetAliasNameFromCondition(formUDTID int) string {
	return "u" + strconv.Itoa(formUDTID)
}

// FormatUDFField func
func FormatUDFField(dataField string) string {
	if !strings.HasPrefix(dataField, "U_") {
		dataField = "U_" + dataField
	}
	return dataField
}
