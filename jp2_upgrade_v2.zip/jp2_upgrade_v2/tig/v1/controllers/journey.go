package controllers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// UpdateJourneyDateTime godoc
// @Summary UpdateJourneyDateTime
// @Description UpdateJourneyDateTime
// @Tags Journey
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Journey body []models.JourneyBodyJSON true "Commit Journey"
// @Success 200 {object} models.APIResponseData
// @Router /updatejourneytime/{journeycode} [post]
func UpdateJourneyDateTime(c *gin.Context) {
	defer libs.RecoverError(c, "CommitJourney")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, errors        interface{}
		errorsResponse     []models.ErrorResponse
		itemMsgError       string
		totalUpdatedRecord = 0
		dataResponses      = make([]models.JourneyResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	journeyCode := c.Param("journeycode")
	var objectsJSON models.JourneyTimeJSON
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	result := UpdateJourneyTime(requestHeader, journeyCode,
		objectsJSON.StartJourneyDateTime, objectsJSON.EndJourneyDateTime, objectsJSON.StartBackToDepotDateTime, objectsJSON.EndBackToDepotDateTime, accountKey, c)
	if result.Error == nil {
		totalUpdatedRecord++
	} else {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, result.Error.Error())
	}
	if itemMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = dataResponses
	libs.APIResponseData(response, c, status)
}

// CommitJourney godoc
// @Summary CommitJourney
// @Description CommitJourney
// @Tags Journey
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Journey body []models.JourneyBodyJSON true "Commit Journey"
// @Success 200 {object} models.APIResponseData
// @Router /journey/commitjourney [post]
func CommitJourney(c *gin.Context) {
	defer libs.RecoverError(c, "CommitJourney")
	var (
		status              = libs.GetStatusSuccess()
		requestHeader       models.RequestHeader
		response            models.APIResponseData
		msg, errors         interface{}
		errorsResponse      []models.ErrorResponse
		dataResponses       = make([]models.JourneyResponse, 0)
		totalUpdatedRecord  = 0
		arrJourneyIDSuccess = make([]int, 0)
		arrJobIDSuccess     = make([]int, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	lengthArrayObject := 0
	// Convert json body to object
	type ResourceObject struct {
		ResourceID        int
		ScheduleStartDate *time.Time
		ScheduleEndDate   *time.Time
	}
	body, _ := ioutil.ReadAll(c.Request.Body)
	var objectsJSON []models.JourneyBodyJSON
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var mapObjectsJSON []map[string]interface{}
	json.Unmarshal([]byte(string(body)), &mapObjectsJSON)
	if len(objectsJSON) > 0 {
		//objectsJSON := CommitScheduleRecurring(requestHeader, lang, accountKey, c, mapObjectsJSON)
		mapResourceID := make(map[int]ResourceObject)
		// group ResourceID
		for _, obj := range objectsJSON {
			if obj.ScheduleID > 0 {
				var resourceObject ResourceObject
				_, sResource := mapResourceID[obj.ResourceID]
				if !sResource {
					resourceObject.ResourceID = obj.ResourceID
					resourceObject.ScheduleStartDate = obj.ScheduleStartDate
					resourceObject.ScheduleEndDate = obj.ScheduleEndDate
					mapResourceID[obj.ResourceID] = resourceObject
				} else {
					resourceObject = mapResourceID[obj.ResourceID]
					if obj.ScheduleStartDate != nil {
						if resourceObject.ScheduleStartDate != nil {
							oldScheduleStartDate := *resourceObject.ScheduleStartDate
							newScheduleStartDate := *obj.ScheduleStartDate
							if newScheduleStartDate.Unix() < oldScheduleStartDate.Unix() {
								resourceObject.ScheduleStartDate = obj.ScheduleStartDate
							}
						} else {
							resourceObject.ScheduleStartDate = obj.ScheduleStartDate
						}
					}
					if obj.ScheduleEndDate != nil {
						if resourceObject.ScheduleEndDate != nil {
							oldScheduleEndDate := *resourceObject.ScheduleEndDate
							newScheduleEndDate := *obj.ScheduleEndDate
							if newScheduleEndDate.Unix() > oldScheduleEndDate.Unix() {
								resourceObject.ScheduleEndDate = obj.ScheduleEndDate
							}
						} else {
							resourceObject.ScheduleEndDate = obj.ScheduleEndDate
						}
					}
					mapResourceID[obj.ResourceID] = resourceObject
				}
			}
		}
		// loop ResourceID to generate Journey Code
		for k, resourceObject := range mapResourceID {
			lengthArrayObject++
			var (
				journey                models.Journey
				journeyCode            string
				itemMsgError           string
				journeyRollBack        models.Journey
				journeyDetailsRollBack = make([]models.JourneyDetail, 0)
				schedulesRollBack      = make([]models.Schedule, 0)
				jobsRollBack           = make([]models.Job, 0)
			)
			for {
				journeyCode = libs.GenerateUUID()
				resultCheckJourneyCode := db.Where("JourneyCode = ?", journeyCode).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Journey{})
				if resultCheckJourneyCode.RowsAffected <= 0 {
					break
				}
			}
			journey.CreatedBy = accountKey
			journey.ModifiedBy = accountKey
			journey.JourneyCode = journeyCode
			journey.ResourceID = resourceObject.ResourceID
			journey.LocationID = locationID
			journey.StartJourneyDateTime = resourceObject.ScheduleStartDate
			journey.EndJourneyDateTime = resourceObject.ScheduleEndDate
			// create Journey
			resultCreateJourney := db.Create(&journey)
			if resultCreateJourney.Error == nil {
				journeyRollBack = journey
				var (
					schedules []models.Schedule
				)
				for _, obj := range objectsJSON {
					// find and update schedules with Journey Code
					db.Where("ResourceID = ? AND ScheduleID = ?", resourceObject.ResourceID, obj.ScheduleID).
						Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&schedules)
					// loop schedules
					for _, schedule := range schedules {
						var (
							journeyDetail models.JourneyDetail
						)
						journeyDetail.CreatedBy = accountKey
						journeyDetail.ModifiedBy = accountKey
						journeyDetail.JourneyID = journey.JourneyID
						journeyDetail.ScheduleID = schedule.ScheduleID
						// create JourneyDetail
						resultCreateJourneyDetail := db.Create(&journeyDetail)
						if resultCreateJourneyDetail.Error == nil {
							journeyDetailsRollBack = append(journeyDetailsRollBack, journeyDetail)
							// update journeycode to schedule
							schedule.ModifiedBy = accountKey
							schedule.JourneyCode = &journey.JourneyCode
							resultSaveSchedule := db.Save(&schedule)
							if resultSaveSchedule.Error == nil {
								schedulesRollBack = append(schedulesRollBack, schedule)
								if !libs.InArrayInteger(schedule.JobID, arrJobIDSuccess) {
									arrJobIDSuccess = append(arrJobIDSuccess, schedule.JobID)
								}
							} else {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSaveSchedule.Error.Error())
								break
							}
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreateJourneyDetail.Error.Error())
							break
						}
					}
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreateJourney.Error.Error())
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
				// RollBack
				// delete journey
				if journeyRollBack.JourneyID > 0 {
					journeyRollBack.IsDeleted = true
					journeyRollBack.ModifiedBy = accountKey
					db.Save(&journeyRollBack)
				}
				// delete journeydetail
				for _, journeyDetailRollBack := range journeyDetailsRollBack {
					journeyDetailRollBack.IsDeleted = true
					journeyDetailRollBack.ModifiedBy = accountKey
					db.Save(&journeyDetailRollBack)
				}
				for _, scheduleRollBack := range schedulesRollBack {
					db.Save(&scheduleRollBack)
				}
				for _, jobRollBack := range jobsRollBack {
					db.Save(&jobRollBack)
				}
			} else {
				totalUpdatedRecord++
				arrJourneyIDSuccess = append(arrJourneyIDSuccess, journey.JourneyID)
			}
		}
	}
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, lengthArrayObject, errorsResponse, false)
	errors = errorsResponse
	if len(arrJourneyIDSuccess) > 0 {
		var resModels []models.Journey
		db.Where("JourneyID in (?)", arrJourneyIDSuccess).Find(&resModels)
		dataResponses = ConvertArrayJourneysToArrayResponse(requestHeader, resModels)
	}

	if len(arrJobIDSuccess) > 0 {
		for _, jobID := range arrJobIDSuccess {
			var (
				job models.Job
			)
			// update job status 2=Allocated by jobid on schedules table
			resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
			if resultFindJob.RowsAffected > 0 {
				UpdateJobStatus(requestHeader, jobID, 2, accountKey, c) // 2=Allocated
				// update job status for master job combined
				UpdateJobStatusForMasterJobCombined(requestHeader, jobID, accountKey)
			}
		}
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = dataResponses
	libs.APIResponseData(response, c, status)
}

// DeleteJourney godoc
// @Summary DeleteJourney
// @Description DeleteJourney
// @Tags Journey
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Resource body models.JourneyDELETE true "Delete Journey"
// @Success 200 {object} models.APIResponseData
// @Router /journey/deletejourney [put]
func DeleteJourney(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteJourney")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	//journeyCode := c.Param("journeycode")
	var objectsJSON models.JourneyDELETE
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	for _, journeyID := range objectsJSON.JourneyIDs {
		var (
			journey                models.Journey
			journeyDetails         []models.JourneyDetail
			itemMsgError           string
			journeyRollBack        models.Journey
			journeyDetailsRollBack = make([]models.JourneyDetail, 0)
			schedulesRollBack      = make([]models.Schedule, 0)
			jobsRollBack           = make([]models.Job, 0)
		)
		resultFindJourney := db.Where("JourneyID = ?", journeyID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&journey)
		if resultFindJourney.Error == nil {

			// Validate job status
			hasInProgressJob := false

			sql := `SELECT COUNT(*) AS ProgressedJob FROM journeydetails jo
			JOIN schedules sc ON jo.ScheduleID = sc.ScheduleID
			JOIN jobs jb on sc.JobID = jb.JobID
			WHERE jb.Status > 1 AND jp.JourneyID = ?`

			rows, err := db.Raw(sql, journeyID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					hasInProgressJob = true
				}
				if hasInProgressJob {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.journey_cannot_delete"))
					status = 500
				}
			}
			if status == 200 {
				journeyRollBack = journey
				journey.IsDeleted = true
				journey.ModifiedBy = accountKey
				// delete journey
				resultSaveJourney := db.Save(&journey)
				if resultSaveJourney.Error == nil {
					db.Where("JourneyID = ?", journey.JourneyID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&journeyDetails)
					for _, journeyDetail := range journeyDetails {
						var (
							schedule models.Schedule
							job      models.Job
						)
						journeyDetailsRollBack = append(journeyDetailsRollBack, journeyDetail)
						journeyDetail.IsDeleted = true
						journeyDetail.ModifiedBy = accountKey
						// delete journeydetails
						resultSaveJourneyDetail := db.Save(&journeyDetail)
						if resultSaveJourneyDetail.Error == nil {
							resultFindSchedule := db.Where("ScheduleID = ?", journeyDetail.ScheduleID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&schedule)
							if resultFindSchedule.RowsAffected > 0 {
								schedulesRollBack = append(schedulesRollBack, schedule)
								schedule.JourneyCode = nil
								// reset journeycode on schedule
								resultSaveSchedule := db.Save(&schedule)
								if resultSaveSchedule.Error == nil {
									resultFindJob := db.Where("JobID = ?", schedule.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
									if resultFindJob.Error == nil {
										jobsRollBack = append(jobsRollBack, job)
										//job.Status = 1
										// reset job status on job
										resultSaveJob := UpdateJobStatus(requestHeader, schedule.JobID, 1, accountKey, c)
										if resultSaveJob.Error != nil {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSaveJob.Error.Error())
											status = 500
											break
										}
									} else {
										if errors.Is(resultFindJob.Error, gorm.ErrRecordNotFound) {
											//itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.no_record_found"))
										} else {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultFindJob.Error.Error())
											status = 500
											break
										}
									}
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSaveSchedule.Error.Error())
									status = 500
									break
								}
							}
						} else {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSaveJourneyDetail.Error.Error())
							status = 500
							break
						}
					}
				} else {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSaveJourney.Error.Error())
					status = 500
				}
			}
		} else {
			if errors.Is(resultFindJourney.Error, gorm.ErrRecordNotFound) {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.no_record_found"))
				status = 404
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultFindJourney.Error.Error())
				status = 500
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
			msg = itemMsgError
			// RollBack
			if journeyRollBack.JourneyID > 0 {
				db.Save(&journeyRollBack)
			}
			for _, journeyDetailRollBack := range journeyDetailsRollBack {
				db.Save(&journeyDetailRollBack)
			}
			for _, scheduleRollBack := range schedulesRollBack {
				db.Save(&scheduleRollBack)
			}
			for _, jobRollBack := range jobsRollBack {
				db.Save(&jobRollBack)
			}
		} else {
			totalUpdatedRecord++
		}
	}
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON.JourneyIDs), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// GetJourneyCodeForDeletion godoc
// @Summary DeleteJourney
// @Description DeleteJourney
// @Tags Journey
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param journeycode path string true "JourneyCode"
// @Success 200 {object} models.APIResponseData
// @Router /journey/journeyfordeletion [get]
func GetJourneyCodeForDeletion(c *gin.Context) {
	defer libs.RecoverError(c, "GetJourneyCodeForDeletion")
	var (
		status        = libs.GetStatusSuccess()
		userModel     models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		itemMsgError  string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	resourceIDs, _ := libs.GetQueryParam("ResourceID", c)
	format := libs.FORMATDATE
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			vFromDate = dFromDate.Format(format)
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			vToDate = dToDate.Format(format)
		}
	}
	// Paging
	/*vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}*/
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		journeys := make([]models.JourneyDeletionResponse, 0)

		sql := `SELECT jo.JourneyID, jo.JourneyCode, jo.ResourceID, rs.ResourceName, jo.StartJourneyDateTime, jo.EndJourneyDateTime
		FROM journeys jo JOIN journeydetails jd ON jo.JourneyID = jd.JourneyID
		JOIN schedules sh ON sh.ScheduleID = jd.ScheduleID
		JOIN jobs jb ON sh.JobID = jb.JobID
		JOIN resources rs ON rs.ResourceID = jo.ResourceID
		WHERE IFNULL(jo.IsDeleted, 0) <> 1 AND IFNULL(jo.IsArchived, 0) <> 1 AND IFNULL(sh.IsDeleted, 0) <> 1 AND IFNULL(sh.IsArchived, 0) <> 1 AND jb.Status = 2 `
		if resourceIDs != "" {
			sql += ` AND jo.ResourceID IN (` + resourceIDs + `) `
		}
		if sFromDate && sToDate {
			sql += ` AND DATE_FORMAT(sh.ScheduleStartDate, '%Y-%m-%d') >= '` + vFromDate + `' AND DATE_FORMAT(sh.ScheduleStartDate, '%Y-%m-%d') <= '` + vToDate + `'`
		} else if sFromDate {
			sql += ` AND DATE_FORMAT(sh.ScheduleStartDate, '%Y-%m-%d') >= '` + vFromDate + `'`
		} else if sToDate {
			sql += ` AND DATE_FORMAT(sh.ScheduleStartDate, '%Y-%m-%d') <= '` + vToDate + `'`
		}

		sql += ` GROUP BY jo.JourneyID, jo.JourneyCode, jo.ResourceID, rs.ResourceName, jo.StartJourneyDateTime, jo.EndJourneyDateTime`
		//sql += ` LIMIT '` + vLength + `' OFFSET '` + vStart + `'`
		rows, err := db.Raw(sql).Rows()
		if rows != nil {
			defer rows.Close()
		}
		if err == nil {
			for rows.Next() {
				var journey models.JourneyDeletionResponse
				rows.Scan(
					&journey.JourneyID, &journey.JourneyCode,
					&journey.ResourceID, &journey.ResourceName,
					&journey.StartJourneyDateTime, &journey.EndJourneyDateTime,
				)
				journeys = append(journeys, journey)
			}
		} else {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
		}
		if len(journeys) > 0 {
			data = journeys
			msg = services.GetMessage(lang, "api.success")
		} else {
			data = make([]int, 0)
			//status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.no_record_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	} else {
		status = libs.GetStatusNotFound()
		msg = services.GetMessage(lang, "api.accountkey_not_found")
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJourneyTime func
func UpdateJourneyTime(requestHeader models.RequestHeader, journeyCode string,
	startTime *time.Time, endTime *time.Time, startDepotTime *time.Time, endDepotTime *time.Time, accountKey int, c *gin.Context) *gorm.DB {
	var (
		journey models.Journey
		result  *gorm.DB
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	resultFindJourney := db.Where("JourneyCode = ?", journeyCode).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&journey)
	if resultFindJourney.RowsAffected > 0 {
		journey.ModifiedBy = accountKey
		if startTime != nil {
			journey.StartJourneyDateTime = startTime
		}
		if endTime != nil {
			journey.EndJourneyDateTime = endTime
		}
		if startDepotTime != nil {
			journey.StartBackToDepotDateTime = startDepotTime
		}
		if endDepotTime != nil {
			journey.EndBackToDepotDateTime = endDepotTime
		}
		result = db.Save(&journey)
	}
	return result
}

// ConvertArrayJourneysToArrayResponse func
func ConvertArrayJourneysToArrayResponse(requestHeader models.RequestHeader, items []models.Journey) []models.JourneyResponse {
	responses := make([]models.JourneyResponse, 0)
	for _, item := range items {
		response := ConvertJourneyToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJourneyToResponse func
func ConvertJourneyToResponse(requestHeader models.RequestHeader, item models.Journey) models.JourneyResponse {
	var (
		response       models.JourneyResponse
		journeyDetails []models.JourneyDetail
	)
	response.JourneyID = item.JourneyID
	response.JourneyCode = item.JourneyCode
	response.ResourceID = item.ResourceID
	response.LocationID = item.LocationID
	response.Status = item.Status
	response.StartJourneyDateTime = item.StartJourneyDateTime
	response.EndJourneyDateTime = item.EndJourneyDateTime
	response.StartBackToDepotDateTime = item.StartBackToDepotDateTime
	response.EndBackToDepotDateTime = item.EndBackToDepotDateTime

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var resourceModel models.Resource
	resultFindResource := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
	if resultFindResource.RowsAffected > 0 {
		response.ResourceName = resourceModel.ResourceName
	}

	details := make([]models.JourneyDetailResponse, 0)
	db.Where("JourneyID = ?", item.JourneyID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&journeyDetails)
	for _, journeyDetail := range journeyDetails {
		var detail models.JourneyDetailResponse
		detail.JourneyDetailID = journeyDetail.JourneyDetailID
		detail.JourneyID = journeyDetail.JourneyID
		detail.ScheduleID = journeyDetail.ScheduleID
		details = append(details, detail)
	}
	response.JourneyDetails = details

	return response
}
