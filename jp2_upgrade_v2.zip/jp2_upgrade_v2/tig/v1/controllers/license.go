package controllers

import (
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strings"

	"github.com/gin-gonic/gin"
)

// CheckLicense godoc
// @Summary CheckLicense
// @Description CheckLicense
// @Tags License
// @Accept  json
// @Produce  json
// @Param Type query string false "Type"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checklicense [get]
func CheckLicense(c *gin.Context) {
	defer libs.RecoverError(c, "CheckLicense")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	companyID := c.Request.Header.Get("companyid")

	var (
		licenseType  string
		isLicense    = false
		msgData      string
		currentCount int
		expiredDate  string
	)
	vType, sType := libs.GetQueryParam("Type", c)
	if sType {
		licenseType = vType
		if licenseType != "" {
			licenseType = strings.ToLower(licenseType)
		}
		switch licenseType {
		case "job", "form", "resource", "user", "smartscheduling",
			"additionaldevicelicense", "xero", "microsoftdynamic", "livechat",
			"replayroutes", "reportdesigner", "expired":
		default:
			status = 422
			msg = services.GetMessage(lang, "api.license_type_invalid")
		}
	} else {
		status = 422
		msg = services.GetMessage(lang, "api.license_type_required")
	}

	if status == 200 {
		status, msg, isLicense, msgData, currentCount, expiredDate = libs.CheckLicenseFunc(requestHeader, lang, companyID, licenseType)
	}
	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
		if licenseType == "expired" {
			data = map[string]interface{}{
				"daysleft":   currentCount,
				"expirydate": expiredDate,
				"message":    msgData,
				"isLicense":  isLicense,
			}
		} else {
			data = map[string]interface{}{
				"currentCount": currentCount,
				"message":      msgData,
				"isLicense":    isLicense,
			}
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
