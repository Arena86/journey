package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	smslogs "jpapi/tig/v1/logs/sms"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetRequestAuthorizationCount godoc
// @Summary Get Authorization
// @Description Get Authorization
// @Tags Authorization
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getrequestcount [get]
func GetRequestAuthorizationCount(c *gin.Context) {
	defer libs.RecoverError(c, "GetRequestAuthorizationCount")
	var (
		status                     = libs.GetStatusSuccess()
		resModels                  []models.Authorization
		requestHeader              models.RequestHeader
		response                   models.APIResponseData
		authorizationResquestCount models.AuthorizationResquestCount
		msg                        interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND LocationID = ? AND Status = 1", locationID)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	authorizationResquestCount.Count = int(totalCount)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = authorizationResquestCount
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetAuthorization godoc
// @Summary Get Authorization
// @Description Get Authorization
// @Tags Authorization
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /authorization [get]
func GetAuthorization(c *gin.Context) {
	defer libs.RecoverError(c, "GetAuthorization")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Authorization
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	vStatus, sStatus := libs.GetQueryParam("Status", c)
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND LocationID = ?", locationID)
	if sStatus {
		bp = bp.Where("Status = 1", vStatus)
	}

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"UserID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	//bp = libs.SortDataOnParam(bp, c)
	bp = bp.Order("CreatedDate DESC")

	locationSort := libs.GetSortValueFromKey(c, "LocationName")
	if locationSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		var locations []models.Location
		arrLocationIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("LocationName " + locationSort).Find(&locations)
		for _, location := range locations {
			arrLocationIDSort = append(arrLocationIDSort, location.LocationID)
		}
		if len(arrLocationIDSort) > 0 {
			strJoin := libs.IntJoin(arrLocationIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(LocationID," + strJoin + ")")
			}
		}
	}

	jobSort := libs.GetSortValueFromKey(c, "JobNumber")
	if jobSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		var jobs []models.Job
		arrJobIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("JobID " + jobSort).Find(&jobs)
		for _, job := range jobs {
			arrJobIDSort = append(arrJobIDSort, job.JobID)
		}
		if len(arrJobIDSort) > 0 {
			strJoin := libs.IntJoin(arrJobIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(JobID," + strJoin + ")")
			}
		}
	}
	reasonSort := libs.GetSortValueFromKey(c, "ReasonName")
	if reasonSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//

		var reasons []models.Reason
		arrReasonIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Reason " + reasonSort).Find(&reasons)
		for _, reason := range reasons {
			arrReasonIDSort = append(arrReasonIDSort, reason.ReasonID)
		}
		if len(arrReasonIDSort) > 0 {
			strJoin := libs.IntJoin(arrReasonIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(ReasonID," + strJoin + ")")
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayAuthorizationToArrayResponse(requestHeader, resModels)

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetAuthorizationByID godoc
// @Summary Get Authorization By ID
// @Description Get Authorization By ID
// @Tags Authorization
// @Accept  json
// @Produce  json
// @Param id path int true "Authorization ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /authorization/{id} [get]
func GetAuthorizationByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetRequestAuthorizationByJobID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Authorization
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND AuthorizationID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertAuthorizationToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetRequestAuthorizationByJobID godoc
// @Summary Get Authorization By Job ID
// @Description Get Authorization By Job ID
// @Tags Authorization
// @Accept  json
// @Produce  json
// @Param jobid path int true "Job ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getauthorizationrequest/{jobid} [get]
func GetRequestAuthorizationByJobID(c *gin.Context) {
	defer libs.RecoverError(c, "GetRequestAuthorizationByJobID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Authorization
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("jobid")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Status = 1 AND JobID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertAuthorizationToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateAuthorization godoc
// @Summary Create Authorization
// @Description Create Authorization
// @Tags Authorization
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Authorization body models.AuthorizationResponse true "Create Authorization"
// @Success 200 {object} models.APIResponseData
// @Router /authorization [post]
func CreateAuthorization(c *gin.Context) {
	apiName := "CreateAuthorization"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
		progressed         = false
		isNew              = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.Authorization
	)
	obj.PassBodyJSONToModel(objectsJSON)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
			resModel     models.Authorization
		)
		resultFind := db.Where("Status = 1 AND JobID = ?", obj.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
		if resultFind.RowsAffected > 0 {

			progressed = true
			if obj.Status == 1 { // Requested
				resModel.Status = 5 // Expired
			} else {
				isNew = false
				resModel.Status = obj.Status // Update status
				resModel.ResponseComment = obj.ResponseComment
			}
			resultUpdate := db.Save(&resModel)

			if resultUpdate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultUpdate.Error.Error())
			} else {
				totalUpdatedRecord++
				dataResponses := ConvertAuthorizationToResponse(requestHeader, resModel)
				data = dataResponses

				// Reset data
				if resModel.Status == 3 { // Approved
					itemMsgError = ResetJob(obj.JobID, obj.ReasonID, obj.Comment, accountKey, requestHeader, itemMsgError, c)
					if itemMsgError != "" {
						// Send SMS
						smsMatrixID := 6
						jobID := resModel.JobID
						resStatus, resMsg, resSendSMS := SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobID)
						// logger
						var smsLogger = smslogs.SMSLogger
						smsLogger.Println("jobID: ", jobID)
						smsLogger.Println("smsMatrixID: ", smsMatrixID)
						smsLogger.Println("resStatus: ", resStatus)
						smsLogger.Println("resMsg: ", resMsg)
						smsLogger.Printf("resSendSMS: %+v", resSendSMS)
					}
				}
			}
		} else {
			resultFind := db.Where("Status = 2 AND JobID = ?", obj.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Authorization{})
			if resultFind.RowsAffected > 0 {
				msg = services.GetMessage(lang, "api.authorization_cancelled")
			} else {
				msg = services.GetMessage(lang, "api.no_record_found")
			}
		}

		if obj.Status == 1 { // Requested
			progressed = true
			obj.LocationID = locationID
			resultCreate := db.Create(&obj)

			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				totalUpdatedRecord++
				dataResponses := ConvertAuthorizationToResponse(requestHeader, obj)
				data = dataResponses
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	if progressed {
		if isNew {
			status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
		} else {
			status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
		}
	} else {
		status = libs.GetStatusError()
	}
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ResetJob func
func ResetJob(jobID int, reasonID int, comment string, accountKey int, requestHeader models.RequestHeader, itemMsgError string, c *gin.Context) string {
	var (
		job       models.Job
		userModel models.User
		userID    = 0
		jobTasks  []models.JobTask
		schedules []models.Schedule
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		userID = userModel.UserID
	}
	currentTime := time.Now()
	// Job
	resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFindJob.RowsAffected > 0 {
		job.InProgressStatus = ""
		job.JobTaskStatus = ""
		job.JobFormsNavigation = nil
		resultSave := db.Save(&job)
		if resultSave.Error == nil {
			UpdateJobStatus(requestHeader, jobID, 0, accountKey, c)
		} else {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
		}

		// Job Task
		//resultFindJobTask := db.Where("Status <> 4 AND JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTasks)
		resultFindJobTask := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTasks)
		if resultFindJobTask.RowsAffected > 0 {
			for _, jobtask := range jobTasks {
				var (
					dynamicFormFlows []models.DynamicFormFlow
				)

				if job.JobType != jobtask.JobType {
					if jobtask.JobType == 2 { // Pickup
						var quantity float64
						db.Table(models.JobDetail{}.TableName()).Select("SUM(QuantityPicked) AS quantity").Row().Scan(&quantity)
						if quantity > 0 {
							jobtask.Status = 5 // Partial
						} else {
							jobtask.Status = 0 // Open
						}
						jobtask.Status = 0 // Open @TODO TBD
					} else if jobtask.JobType == 3 { // Delivery
						var quantity float64
						db.Table(models.JobDetail{}.TableName()).Select("SUM(QuantityDelivered) AS quantity").Row().Scan(&quantity)
						if quantity > 0 {
							jobtask.Status = 5 // Partial
						} else {
							jobtask.Status = 0 // Open
						}
						jobtask.Status = 0 // Open @TODO TBD
					} else {
						jobtask.Status = 0 // Open
					}
				} else {
					jobtask.Status = 0 // Open
				}
				jobtask.ScheduleStartDateTime = nil
				jobtask.ScheduleEndDateTime = nil
				jobtask.DepartureDateTime = nil
				jobtask.EstimatedArrivalDateTime = nil
				jobtask.ArrivalDateTime = nil
				jobtask.StartDateTime = nil
				jobtask.EndDateTime = nil
				jobtask.JobTimeInSeconds = 0

				resultSave := db.Save(&jobtask)
				if resultSave.Error == nil {
					// advancedpeds
					timeNow := time.Now()
					resultSave = db.Where("JobID = ? AND JobTaskID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", jobID, jobtask.JobTaskID).
						Model(&models.AdvancedPED{}).Updates(models.AdvancedPED{IsDeleted: true, IsReschedule: true, RescheduleDate: &timeNow})
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}
					// advancedsignatures
					resultSave = db.Where("JobID = ? AND JobTaskID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", jobID, jobtask.JobTaskID).
						Model(&models.AdvancedSignature{}).Updates(models.AdvancedSignature{IsDeleted: true, IsReschedule: true, RescheduleDate: &timeNow})
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}
					// advancedphotos
					resultSave = db.Where("JobID = ? AND JobTaskID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", jobID, jobtask.JobTaskID).
						Model(&models.AdvancedPhoto{}).Updates(models.AdvancedPhoto{IsDeleted: true, IsReschedule: true, RescheduleDate: &timeNow})
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}
					// advancedpedratings
					resultSave = db.Where("JobID = ? AND JobTaskID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", jobID, jobtask.JobTaskID).
						Model(&models.AdvancedRating{}).Updates(models.AdvancedRating{IsDeleted: true, IsReschedule: true, RescheduleDate: &timeNow})
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}

					// update precomputedroutes
					sqlResetprecomputedroutes := `DELETE FROM ` + models.PrecomputedRoute{}.TableName() + ` WHERE TaskID = ?`
					db.Exec(sqlResetprecomputedroutes, jobtask.JobTaskID)

					// Dynamic Form
					resultFindFormFlow := db.Where("FormFlowID = ?", jobtask.FormFlowID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&dynamicFormFlows)
					if resultFindFormFlow.RowsAffected > 0 {
						for _, dynamicFormFlow := range dynamicFormFlows {
							tableName := "u_form_" + strconv.Itoa(dynamicFormFlow.DynamicFormID)
							sql := `UPDATE ` + tableName + " SET IsDeleted = 1 WHERE IsDeleted = 0 AND JobID = ? AND JobTaskID = ?"
							db.Exec(sql, jobID, jobtask.JobTaskID)
						}
					}
				} else {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				}
			}
		}
	}
	db.Where("IFNULL(IsReschedule, 0) = 0 AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ? ", jobID).Find(&schedules)

	for _, schedule := range schedules {
		// update additionalusers
		sqlResetAddUser := `DELETE FROM ` + models.AdditionalUser{}.TableName() + ` WHERE ScheduleID = ?`
		db.Exec(sqlResetAddUser, schedule.ScheduleID)
		schedule.IsDeleted = true
		schedule.IsReschedule = true
		schedule.RescheduleReasonID = reasonID
		schedule.RescheduleComment = comment
		schedule.RescheduleDateTime = &currentTime
		schedule.RescheduleUserID = userID
		resultSave := db.Save(&schedule)
		if resultSave.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
		}
	}

	// job combined master
	UpdateJobStatusForMasterJobCombinedAfterResetJob(requestHeader, jobID, accountKey)

	return itemMsgError
}

// ConvertArrayAuthorizationToArrayResponse func
func ConvertArrayAuthorizationToArrayResponse(requestHeader models.RequestHeader, items []models.Authorization) []models.AuthorizationResponse {
	responses := make([]models.AuthorizationResponse, 0)
	for _, item := range items {
		response := ConvertAuthorizationToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertAuthorizationToResponse func
func ConvertAuthorizationToResponse(requestHeader models.RequestHeader, item models.Authorization) models.AuthorizationResponse {
	var (
		response models.AuthorizationResponse
		job      models.Job
		location models.Location
		reason   models.Reason
		bp       models.BusinessPartner
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.AuthorizationID = item.AuthorizationID
	response.Type = item.Type
	response.JobID = item.JobID
	response.CreatedDate = item.CreatedDate
	resultFind := db.Where("JobID = ?", item.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFind.RowsAffected > 0 {
		response.JobNumber = job.JobNumber

		resultFind = db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&bp)
		if resultFind.RowsAffected > 0 {
			response.FullName = bp.FirstName + " " + bp.LastName
		}
	}
	response.LocationID = item.LocationID
	resultFind = db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
	if resultFind.RowsAffected > 0 {
		response.LocationName = location.LocationName
	}
	response.ReasonID = item.ReasonID
	resultFind = db.Where("ReasonID = ?", item.ReasonID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&reason)
	if resultFind.RowsAffected > 0 {
		response.ReasonName = reason.Reason
	}
	response.Comment = item.Comment
	response.Status = item.Status
	response.ResponseComment = item.ResponseComment

	return response
}
