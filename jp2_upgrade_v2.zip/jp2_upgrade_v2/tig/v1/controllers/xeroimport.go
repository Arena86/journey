package controllers

import (
	"encoding/json"
	"errors"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// IsInitRunning var
var IsInitRunning = false

// IsCronRunning var
var IsCronRunning = false

// XeroImportItem godoc
// @Summary Get Xero Item
// @Description Xero Item
// @Tags XeroItem
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/import/item [get]
func XeroImportItem(c *gin.Context) {
	defer libs.RecoverError(c, "XeroImportItem")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		//dataRes          map[string]interface{}
		xeroItemResponse   models.XeroItemResponse
		dataResponse       []interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	dataResponse = make([]interface{}, 0)
	representURL := "Items"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroItemResponse)
		if len(xeroItemResponse.Items) > 0 {
			for k, xero := range xeroItemResponse.Items {
				var (
					itemModel  models.Item
					errProcess error
					taxModel   models.Tax
				)
				//db.Where("TaxType = ? AND TaxName = ?", xero.TaxType, xero.Name).First(&taxModel)
				db.Where("TaxType = ?", xero.SalesDetails.TaxType).First(&taxModel)
				resultFind := db.Where("ErpKey = ?", xero.ItemID).First(&itemModel)
				itemModel.ConvertXeroToDatabaseModel(xero)
				if resultFind.RowsAffected > 0 {
					itemModel.TaxID = taxModel.TaxID
					itemModel.ModifiedBy = &accountKey
					itemModel.IsArchived = false
					itemModel.IsAudit = false
					itemModel.IsDeleted = false
					errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&itemModel).Error
				} else {
					itemModel.TaxID = taxModel.TaxID
					itemModel.CreatedBy = &accountKey
					itemModel.ModifiedBy = &accountKey
					errProcess = db.Create(&itemModel).Error
				}
				if errProcess != nil {
					errResponse := GetErrorResponseErrorMessage(k, errProcess.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					itemResponse := ConvertItemToResponse(requestHeader, itemModel, lang)
					dataResponse = append(dataResponse, itemResponse)
					totalUpdatedRecord++
				}
			}
		}
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(xeroItemResponse.Items), errorsResponse, true)
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	data = dataResponse
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// XeroImportBusinessPartner godoc
// @Summary Get Xero Item
// @Description Xero Item
// @Tags XeroItem
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/import/businesspartner [get]
func XeroImportBusinessPartner(c *gin.Context) {
	defer libs.RecoverError(c, "XeroImportBusinessPartner")
	var (
		status              = libs.GetStatusSuccess()
		requestHeader       models.RequestHeader
		response            models.APIResponseData
		msg                 interface{}
		data                interface{}
		xeroContactResponse models.XeroContactResponse
		dataResponse        []models.BusinessPartner
		totalUpdatedRecord  = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	dataResponse = make([]models.BusinessPartner, 0)
	representURL := "Contacts"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
		if len(xeroContactResponse.Contacts) > 0 {
			for k, xero := range xeroContactResponse.Contacts {
				var (
					businessPartnerModel models.BusinessPartner
					errProcess           error
				)
				resultFind := db.Where("ErpKey = ?", xero.ContactID).First(&businessPartnerModel)
				businessPartnerModel.ConvertXeroToDatabaseModel(db, accountKey, xero)
				if resultFind.RowsAffected > 0 {
					businessPartnerModel.ModifiedBy = accountKey
					if len(businessPartnerModel.Addresses) > 0 {
						validAddresses := make([]models.Address, 0)
						for _, address := range businessPartnerModel.Addresses {
							resultFindAddress := db.Where("EntityID = ? AND Entity = ? AND AddressLine1 = ?", businessPartnerModel.BusinessPartnerID, models.BusinessPartner{}.TableName(), address.AddressLine1).First(&models.Address{})
							if resultFindAddress.RowsAffected <= 0 {
								validAddresses = append(validAddresses, address)
							}
						}
						businessPartnerModel.Addresses = validAddresses
					}
					if len(businessPartnerModel.Phones) > 0 {
						validPhones := make([]models.Phone, 0)
						for _, phone := range businessPartnerModel.Phones {
							resultFindPhone := db.Where("EntityID = ? AND Entity = ? AND PhoneNumber = ?", businessPartnerModel.BusinessPartnerID, models.BusinessPartner{}.TableName(), phone.PhoneNumber).First(&models.Phone{})
							if resultFindPhone.RowsAffected <= 0 {
								validPhones = append(validPhones, phone)
							}
						}
						businessPartnerModel.Phones = validPhones
					}

					errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&businessPartnerModel).Error
				} else {
					businessPartnerModel.CreatedBy = accountKey
					errProcess = db.Create(&businessPartnerModel).Error
				}
				if errProcess != nil {
					errResponse := GetErrorResponseErrorMessage(k, errProcess.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, businessPartnerModel)
				}
			}
		}
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(xeroContactResponse.Contacts), errorsResponse, true)
		var (
			businessPartners []models.BusinessPartner
		)
		arrPartnersID := make([]int, 0)
		for _, v := range dataResponse {
			arrPartnersID = append(arrPartnersID, v.BusinessPartnerID)
		}
		if len(arrPartnersID) > 0 {
			db.Preload(
				"Addresses",
				"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				models.BusinessPartner{}.TableName(),
			).Preload(
				"Phones",
				"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				models.BusinessPartner{}.TableName(),
			).Preload(
				"Locations",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("BusinessPartnerID in (?)", arrPartnersID).Find(&businessPartners)
			dataResponses := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, businessPartners)
			for i, b := range dataResponses {
				var (
					udfModels []models.UDF
				)
				dbu := db
				dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())
				udfParams := make([]string, 0)
				if b.IsVendor {
					udfParams = append(udfParams, "vendors")
				}
				if b.IsCustomer {
					udfParams = append(udfParams, "customers")
				}
				if b.IsContractor {
					udfParams = append(udfParams, "contractors")
				}
				if len(udfParams) > 0 {
					dbu = dbu.Where("UDFKey in (?)", udfParams)
				}
				dbu = dbu.Order("Sort ASC")
				dbu = dbu.Find(&udfModels)
				udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
				dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string

				for k, v := range udfResponses {
					val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
					udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
					dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
				}
				dataResponses[i].UDFs = udfResponses
			}
			data = dataResponses
		} else {
			data = dataResponse
		}
	} else {
		status = resStatus
		msg = resMsg
		data = dataResponse
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// IntegrationInitial godoc
// @Summary Get Integration Initial
// @Description Integration Initial
// @Tags Xero
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/initialize [get]
func IntegrationInitial(c *gin.Context) {
	defer libs.RecoverError(c, "IntegrationInitial")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		//rChannel      []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	errorsResponse := make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	var (
		xeroConfig models.XeroConfig
	)
	resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
		lang := services.GetLanguageKey(c)
		if IsInitRunning {
			status = 422
			msg = services.GetMessage(lang, "api.xero_initialize_running")
			response.Status = status
			response.Message = msg
			response.Errors = errorsResponse
			response.Data = data
			libs.APIResponseData(response, c, status)
			return
		}
		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		go Initialize(xeroConfig, accountKey, lang, requestHeader, nil, nil)
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.xeroconfig_inactive"))
		errorsResponse = append(errorsResponse, errResponse)
		status = libs.GetStatusError()
		msg = services.GetMessage(lang, "api.full_failed")
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
func UpdatePendingData(xeroConfig models.XeroConfig, accountKey int, lang string, requestHeader models.RequestHeader,
	timeFilterHeaderItem *time.Time, timeFilterHeaderCustomer *time.Time) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	// @TOTO - Update pending item from JP to Xero
	go func() {
		var (
			items []models.Item
		)
		db.Preload(
			"RelatedItems",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsIntegrationPending, 0) = 1").Find(&items)

		if len(items) > 0 {
			for _, item := range items {
				// Check modified date
				if item.ErpKey != "" {
					var (
						xeroItemResponse models.XeroItemResponse
					)
					representURL := "Items/" + item.ErpKey
					resStatus, _, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
					if resStatus == 200 {
						json.Unmarshal([]byte(string(resData)), &xeroItemResponse)
						if len(xeroItemResponse.Items) > 0 {
							xeroUpdatedTime, _ := libs.ConvertUpdatedDateUTCXeroToTime(xeroItemResponse.Items[0].UpdatedDateUTC)
							fmt.Println(xeroUpdatedTime.Format("2006-01-02 15:04:05"))
							fmt.Println(item.ModifiedDate.Format("2006-01-02 15:04:05"))
							if xeroUpdatedTime.After(*item.ModifiedDate) {
								item.IsIntegrationPending = false
								item.IntegrationError = ""
								db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
								continue
							}
						}
					}
				}
				var (
					processItems []models.Item
				)
				processItems = append(processItems, item)
				xeroResponses := UpdateItemFromDatabaseToXero(requestHeader, lang, processItems)
				for _, res := range xeroResponses {
					if res.Status == 200 {
						item.IsIntegrationPending = false
						item.IntegrationError = ""
					} else {
						item.IntegrationError = fmt.Sprintf("%v", res.Msg)
					}
					db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
					break
				}
			}
		}
	}()

	go func() {
		// @TOTO - Update pending business partner from JP to Xero
		var (
			businessPartners []models.BusinessPartner
		)
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			models.BusinessPartner{}.TableName(),
		).Preload("Locations").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1  AND IFNULL(IsIntegrationPending, 0) = 1").Find(&businessPartners)

		if len(businessPartners) > 0 {
			// Check modified date
			for _, bp := range businessPartners {
				// Check modified date
				if bp.ErpKey != "" {
					var (
						xeroContactResponse models.XeroContactResponse
					)
					representURL := "Contacts/" + bp.ErpKey
					resStatus, _, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
					if resStatus == 200 {
						json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
						if len(xeroContactResponse.Contacts) > 0 {
							xeroUpdatedTime, _ := libs.ConvertUpdatedDateUTCXeroToTime(xeroContactResponse.Contacts[0].UpdatedDateUTC)
							fmt.Println(xeroUpdatedTime.Format("2006-01-02 15:04:05"))
							fmt.Println(bp.ModifiedDate.Format("2006-01-02 15:04:05"))
							if xeroUpdatedTime.After(*bp.ModifiedDate) {
								bp.IsIntegrationPending = false
								bp.IntegrationError = ""
								db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&bp)
								continue
							}
						}
					}
				}

				var (
					processBPs []models.BusinessPartner
				)
				processBPs = append(processBPs, bp)
				xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, processBPs)
				for _, res := range xeroResponses {
					if res.Status == 200 {
						bp.IsIntegrationPending = false
						bp.IntegrationError = ""
					} else {
						bp.IntegrationError = fmt.Sprintf("%v", res.Msg)
					}
					db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&bp)
					break
				}
			}
		}
	}()
}

// Initialize func
func Initialize(xeroConfig models.XeroConfig, accountKey int, lang string, requestHeader models.RequestHeader, timeFilterHeaderItem *time.Time, timeFilterHeaderCustomer *time.Time) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	errorsResponse := make([]models.ErrorResponse, 0)

	hasCheckInitRunning := false
	if timeFilterHeaderItem == nil && timeFilterHeaderCustomer == nil {
		hasCheckInitRunning = true
	}
	if hasCheckInitRunning {
		IsInitRunning = true
		finishedImportTax := ImportXeroTaxsFromXeroToDatabase(requestHeader, lang, accountKey)
		if finishedImportTax {
			rChannelErrors := make(chan []models.ErrorResponse, 2)
			go IntegrationInitialContacts(rChannelErrors, requestHeader, lang, accountKey, timeFilterHeaderCustomer)
			go IntegrationInitialItems(rChannelErrors, requestHeader, lang, accountKey, timeFilterHeaderItem)
			errItems := <-rChannelErrors
			for _, e := range errItems {
				errorsResponse = append(errorsResponse, e)
			}
			errContacts := <-rChannelErrors
			for _, e := range errContacts {
				errorsResponse = append(errorsResponse, e)
			}
		}
		IsInitRunning = false
	} else if !IsCronRunning {
		IsCronRunning = true
		rChannelErrors := make(chan []models.ErrorResponse, 2)
		IntegrationInitialContacts(rChannelErrors, requestHeader, lang, accountKey, timeFilterHeaderCustomer)
		IntegrationInitialItems(rChannelErrors, requestHeader, lang, accountKey, timeFilterHeaderItem)
		errItems := <-rChannelErrors
		for _, e := range errItems {
			errorsResponse = append(errorsResponse, e)
		}
		errContacts := <-rChannelErrors
		for _, e := range errContacts {
			errorsResponse = append(errorsResponse, e)
		}
		fmt.Println("UpdatePendingData")
		go UpdatePendingData(xeroConfig, accountKey, lang, requestHeader, timeFilterHeaderItem, timeFilterHeaderCustomer)

		var newConfig models.XeroConfig
		resultFindConfig := db.First(&newConfig)
		if resultFindConfig.RowsAffected > 0 {
			newConfig.LastTimeItem = xeroConfig.LastTimeItem
			newConfig.LastTimeCustomer = xeroConfig.LastTimeCustomer
			db.Save(&newConfig)
		}
		IsCronRunning = false
	}
}

// ImportXeroTaxsFromXeroToDatabase func
func ImportXeroTaxsFromXeroToDatabase(requestHeader models.RequestHeader, lang string, accountKey int) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		xeroTaxResponse models.XeroTaxResponse
	)
	representURL := "TaxRates"
	resStatus, _, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroTaxResponse)
		if len(xeroTaxResponse.TaxRates) > 0 {
			for _, xero := range xeroTaxResponse.TaxRates {
				var (
					taxModel models.Tax
				)
				resultFind := db.Where("TaxType = ?", xero.TaxType).First(&taxModel) // Override Tax
				taxModel.ConvertXeroToDatabaseModel(xero)
				if resultFind.RowsAffected > 0 {
					taxModel.ModifiedBy = accountKey
					taxModel.IsArchived = false
					taxModel.IsAudit = false
					taxModel.IsDeleted = false
					db.Save(&taxModel)
				} else {
					taxModel.CreatedBy = accountKey
					taxModel.ModifiedBy = accountKey
					db.Create(&taxModel)
				}
			}
		}
	}
	return true
}

// IntegrationInitialItems func
func IntegrationInitialItems(rChannelErrors chan []models.ErrorResponse, requestHeader models.RequestHeader, lang string, accountKey int, timeFilterHeaderItem *time.Time) {
	errorsResponse := make([]models.ErrorResponse, 0)
	errs2 := ImportXeroItemsFromXeroToDatabase(requestHeader, lang, accountKey, timeFilterHeaderItem)
	for _, e := range errs2 {
		errorsResponse = append(errorsResponse, e)
	}
	if timeFilterHeaderItem == nil {
		errs1 := ImportXeroItemsFromDatabaseToXero(requestHeader, lang, accountKey)
		for _, e := range errs1 {
			errorsResponse = append(errorsResponse, e)
		}
	}
	rChannelErrors <- errorsResponse
}

// ImportXeroItemsFromXeroToDatabase func
func ImportXeroItemsFromXeroToDatabase(requestHeader models.RequestHeader, lang string, accountKey int, timeFilterHeaderItem *time.Time) []models.ErrorResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		xeroItemResponse models.XeroItemResponse
	)
	//logger := logs.Logger
	errorsResponse := make([]models.ErrorResponse, 0)
	headers := make(map[string]interface{})
	if timeFilterHeaderItem != nil {
		lastRunTime := *timeFilterHeaderItem
		modifiedAfterUTC := libs.ConvertTimeToXeroHeaderFilterUTC(lastRunTime)
		headers["If-Modified-Since"] = modifiedAfterUTC
		//logger.Infoln(lastRunTime)
	}
	// @TODO items not paging
	representURL := "Items"

	//logger.Infoln("ImportXeroItemsFromXeroToDatabase...")
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, headers)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroItemResponse)
		if len(xeroItemResponse.Items) > 0 {
			//logger.Infoln(fmt.Sprintf("Total Items: %d", len(xeroItemResponse.Items)))
			for k, xero := range xeroItemResponse.Items {
				var (
					itemModel     models.Item
					itemCodeModel models.Item
					errProcess    error
					taxModel      models.Tax
				)

				//db.Where("TaxType = ? AND TaxName = ?", xero.TaxType, xero.Name).First(&taxModel)
				resultFindTax := db.Where("TaxType = ?", xero.SalesDetails.TaxType).First(&taxModel)
				if resultFindTax.RowsAffected <= 0 {
					taxModel = AddTaxRateFromXeroToDatabaseFilterByTaxType(requestHeader, lang, accountKey, xero.SalesDetails.TaxType)
				}
				resultFind := db.Where("ErpKey = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xero.ItemID).First(&itemModel)
				if resultFind.RowsAffected > 0 {
					// @TODO - Compare modified date
					xeroUpdatedTime, _ := libs.ConvertUpdatedDateUTCXeroToTime(xero.UpdatedDateUTC)
					fmt.Println(xeroUpdatedTime.Format("2006-01-02 15:04:05"))
					fmt.Println(itemModel.ModifiedDate.Format("2006-01-02 15:04:05"))
					if xeroUpdatedTime.Before(*itemModel.ModifiedDate) {
						continue
					}
					// ErpKey found
					// Find Code <> this item have ErpKey
					resultFindItemCode := db.Where("Code = ? AND ItemID <> ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xero.Code, itemModel.ItemID).First(&itemCodeModel)
					if resultFindItemCode.RowsAffected > 0 {
						errProcess = errors.New(services.GetMessage(lang, "api.itemcode_exist"))
					} else {
						itemModel.ConvertXeroToDatabaseModel(xero)
						itemModel.TaxID = taxModel.TaxID
						itemModel.ModifiedBy = &accountKey
						itemModel.IsArchived = false
						itemModel.IsAudit = false
						itemModel.IsDeleted = false
						itemModel.IsIntegrationPending = false
						itemModel.IntegrationError = ""
						errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&itemModel).Error
					}
				} else {
					// ErpKey not found
					resultFindItemCode := db.Where("Code = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xero.Code).First(&itemCodeModel)
					if resultFindItemCode.RowsAffected > 0 {
						// Code exist
						itemCodeModel.ConvertXeroToDatabaseModel(xero)
						itemCodeModel.TaxID = taxModel.TaxID
						itemCodeModel.ModifiedBy = &accountKey
						errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&itemCodeModel).Error
					} else {
						// Code not exist
						itemModel.ConvertXeroToDatabaseModel(xero)
						itemModel.TaxID = taxModel.TaxID
						itemModel.CreatedBy = &accountKey
						itemModel.ModifiedBy = &accountKey
						errProcess = db.Create(&itemModel).Error
					}
				}
				if errProcess != nil {
					errResponse := GetErrorResponseErrorMessage(k, errProcess.Error())
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	} else {
		if resMsg != nil {
			errResponse := GetErrorResponseErrorMessage(0, fmt.Sprintf("%v", resMsg))
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	return errorsResponse
}

// ImportXeroItemsFromDatabaseToXero func
func ImportXeroItemsFromDatabaseToXero(requestHeader models.RequestHeader, lang string, accountKey int) []models.ErrorResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		items []models.Item
	)
	errorsResponse := make([]models.ErrorResponse, 0)
	db.Preload(
		"RelatedItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Find(&items)
	xeroResponses := UpdateItemFromDatabaseToXero(requestHeader, lang, items)
	for k, res := range xeroResponses {
		if res.Status != 200 {
			errResponse := GetErrorResponseErrorMessage(k, fmt.Sprintf("%v", res.Msg))
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	return errorsResponse
}

// IntegrationInitialContacts func
func IntegrationInitialContacts(rChannelErrors chan []models.ErrorResponse, requestHeader models.RequestHeader, lang string, accountKey int, timeFilterHeaderCustomer *time.Time) {
	errorsResponse := make([]models.ErrorResponse, 0)
	errs2 := ImportXeroContactsFromXeroToDatabase(requestHeader, lang, accountKey, timeFilterHeaderCustomer)
	for _, e := range errs2 {
		errorsResponse = append(errorsResponse, e)
	}
	if timeFilterHeaderCustomer == nil {
		errs1 := ImportXeroContactsFromDatabaseToXero(requestHeader, lang, accountKey)
		for _, e := range errs1 {
			errorsResponse = append(errorsResponse, e)
		}
	}
	rChannelErrors <- errorsResponse
}

// ImportXeroContactsFromXeroToDatabase func
func ImportXeroContactsFromXeroToDatabase(requestHeader models.RequestHeader, lang string, accountKey int, timeFilterHeaderCustomer *time.Time) []models.ErrorResponse {
	var (
		xeroContactResponse models.XeroContactResponse
	)
	//logger := logs.Logger
	errorsResponse := make([]models.ErrorResponse, 0)
	headers := make(map[string]interface{})
	if timeFilterHeaderCustomer != nil {
		lastRunTime := *timeFilterHeaderCustomer
		modifiedAfterUTC := libs.ConvertTimeToXeroHeaderFilterUTC(lastRunTime)
		headers["If-Modified-Since"] = modifiedAfterUTC
	}
	representURL := "Contacts"
	// @TODO contact has paging
	page := 1
	for {
		params := make(map[string]interface{})
		params["page"] = strconv.Itoa(page)
		params["includeArchived"] = "true"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, params, headers)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
			if len(xeroContactResponse.Contacts) > 0 {
				for k, xero := range xeroContactResponse.Contacts {
					var (
						errProcess error
					)
					errProcess = ProcessXeroContactFromXeroToDatabase(requestHeader, xero, lang, accountKey)
					if errProcess != nil {
						errResponse := GetErrorResponseErrorMessage(k, errProcess.Error())
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				break
			}
		} else {
			if resMsg != nil {
				errResponse := GetErrorResponseErrorMessage(0, fmt.Sprintf("%v", resMsg))
				errorsResponse = append(errorsResponse, errResponse)
			}
			break
		}
		page++
	}

	return errorsResponse
}

// ProcessXeroContactFromXeroToDatabase func
func ProcessXeroContactFromXeroToDatabase(requestHeader models.RequestHeader, xero models.XeroContact, lang string, accountKey int) error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		businessPartnerModel models.BusinessPartner
		comapnyNameModel     models.BusinessPartner
		errProcess           error
	)
	resultFind := db.Where("ErpKey = ? AND IFNULL(IsDeleted, 0) <> 1", xero.ContactID).First(&businessPartnerModel)
	businessPartnerModel.ConvertXeroToDatabaseModel(db, accountKey, xero)

	var (
		pbLocations = make([]models.BusinessPartnerLocation, 0)
		pbLocation  models.BusinessPartnerLocation
		location    models.Location
	)
	var bpAddresses []models.Address
	db.Where("EntityID = ? AND Entity = ?", businessPartnerModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Find(&bpAddresses)
	if resultFind.RowsAffected > 0 {

		// @TODO - Compare modified date
		xeroUpdatedTime, _ := libs.ConvertUpdatedDateUTCXeroToTime(xero.UpdatedDateUTC)
		fmt.Println(xeroUpdatedTime.Format("2006-01-02 15:04:05"))
		fmt.Println(businessPartnerModel.ModifiedDate.Format("2006-01-02 15:04:05"))
		if xeroUpdatedTime.Before(*businessPartnerModel.ModifiedDate) {
			return nil
		}
		// ErpKey found
		// Find CompanyName <> this item have ErpKey
		resultFindItemCode := db.Where("CompanyName = ? AND BusinessPartnerID <> ? AND IFNULL(IsDeleted, 0) <> 1", xero.Name, businessPartnerModel.BusinessPartnerID).First(&comapnyNameModel)
		if resultFindItemCode.RowsAffected > 0 {
			errProcess = errors.New(services.GetMessage(lang, "api.comapnyname_exist"))
		} else {
			businessPartnerModel.ModifiedBy = accountKey

			// @TODO delete address/phone
			db.Where("EntityID = ? AND Entity = ?", businessPartnerModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Delete(&models.Address{})
			db.Where("EntityID = ? AND Entity = ?", businessPartnerModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Delete(&models.Phone{})
			if len(businessPartnerModel.Addresses) > 0 {
				validAddresses := make([]models.Address, 0)
				for _, address := range businessPartnerModel.Addresses {
					address.CreatedBy = accountKey
					address.ModifiedBy = accountKey
					for _, bpAddress := range bpAddresses {
						if bpAddress.AddressTypeID == address.AddressTypeID {
							address.NavigationAddress = bpAddress.NavigationAddress
							address.IsDepot = bpAddress.IsDepot
							address.IsBilling = bpAddress.IsBilling
							break
						}
					}
					validAddresses = append(validAddresses, address)
				}
				businessPartnerModel.Addresses = validAddresses
			}
			if len(businessPartnerModel.Phones) > 0 {
				validPhones := make([]models.Phone, 0)
				for _, phone := range businessPartnerModel.Phones {
					phone.CreatedBy = accountKey
					phone.ModifiedBy = accountKey
					validPhones = append(validPhones, phone)
				}
				businessPartnerModel.Phones = validPhones
			}

			if businessPartnerModel.BusinessPartnerCode == "" {
				for {
					businessPartnerModel.BusinessPartnerCode = libs.GenerateBusinessPartnerCode()
					resultFindCheckPartner := db.Where("BusinessPartnerCode = ?", businessPartnerModel.BusinessPartnerCode).First(&models.BusinessPartner{})
					if resultFindCheckPartner.RowsAffected == 0 {
						break
					}
				}
			}

			if xero.ContactStatus == "ARCHIVED" {
				businessPartnerModel.IsArchived = true
			} else {
				businessPartnerModel.IsArchived = false
			}
			businessPartnerModel.IsIntegrationPending = false
			businessPartnerModel.IntegrationError = ""
			errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&businessPartnerModel).Error
		}
	} else {
		if xero.ContactStatus != "ARCHIVED" {
			// ErpKey not found
			resultFindCompanyName := db.Where("CompanyName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xero.Name).First(&comapnyNameModel)
			if resultFindCompanyName.RowsAffected > 0 {
				// CompanyName exist
				comapnyNameModel.ConvertXeroToDatabaseModel(db, accountKey, xero)
				comapnyNameModel.ModifiedBy = accountKey
				// @TODO delete address/phone
				db.Where("EntityID = ? AND Entity = ?", comapnyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Delete(&models.Address{})
				db.Where("EntityID = ? AND Entity = ?", comapnyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Delete(&models.Phone{})

				if len(comapnyNameModel.Addresses) > 0 {
					validAddresses := make([]models.Address, 0)
					for _, address := range comapnyNameModel.Addresses {
						address.CreatedBy = accountKey
						address.ModifiedBy = accountKey
						for _, bpAddress := range bpAddresses {
							if bpAddress.AddressTypeID == address.AddressTypeID {
								address.NavigationAddress = bpAddress.NavigationAddress
								break
							}
						}
						validAddresses = append(validAddresses, address)
					}
					comapnyNameModel.Addresses = validAddresses
				}
				if len(comapnyNameModel.Phones) > 0 {
					validPhones := make([]models.Phone, 0)
					for _, phone := range comapnyNameModel.Phones {
						phone.CreatedBy = accountKey
						phone.ModifiedBy = accountKey
						validPhones = append(validPhones, phone)
					}
					comapnyNameModel.Phones = validPhones
				}

				if comapnyNameModel.BusinessPartnerCode == "" {
					for {
						comapnyNameModel.BusinessPartnerCode = libs.GenerateBusinessPartnerCode()
						resultFindCheckPartner := db.Where("BusinessPartnerCode = ?", comapnyNameModel.BusinessPartnerCode).First(&models.BusinessPartner{})
						if resultFindCheckPartner.RowsAffected == 0 {
							break
						}
					}
				}

				errProcess = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&comapnyNameModel).Error
			} else {
				// CompanyName not exist
				businessPartnerModel.ConvertXeroToDatabaseModel(db, accountKey, xero)
				businessPartnerModel.CreatedBy = accountKey
				businessPartnerModel.ModifiedBy = accountKey

				if len(businessPartnerModel.Addresses) > 0 {
					validAddresses := make([]models.Address, 0)
					for _, address := range businessPartnerModel.Addresses {
						address.CreatedBy = accountKey
						address.ModifiedBy = accountKey
						for _, bpAddress := range bpAddresses {
							if bpAddress.AddressTypeID == address.AddressTypeID {
								address.NavigationAddress = bpAddress.NavigationAddress
								break
							}
						}
						validAddresses = append(validAddresses, address)
					}
					businessPartnerModel.Addresses = validAddresses
				}
				if len(businessPartnerModel.Phones) > 0 {
					validPhones := make([]models.Phone, 0)
					for _, phone := range businessPartnerModel.Phones {
						phone.CreatedBy = accountKey
						phone.ModifiedBy = accountKey
						validPhones = append(validPhones, phone)
					}
					businessPartnerModel.Phones = validPhones
				}

				db.Where("IFNULL(IsMaster, 0) = 1 AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
				pbLocation.LocationID = location.LocationID
				pbLocation.LocationGroupID = location.LocationGroupID
				pbLocations = append(pbLocations, pbLocation)
				businessPartnerModel.Locations = pbLocations
				businessPartnerModel.LocationID = strconv.Itoa(location.LocationID)

				for {
					businessPartnerModel.BusinessPartnerCode = libs.GenerateBusinessPartnerCode()
					resultFindCheckPartner := db.Where("BusinessPartnerCode = ?", businessPartnerModel.BusinessPartnerCode).First(&models.BusinessPartner{})
					if resultFindCheckPartner.RowsAffected == 0 {
						break
					}
				}
				errProcess = db.Create(&businessPartnerModel).Error
			}
		}
	}
	return errProcess
}

// ImportXeroContactsFromDatabaseToXero func
func ImportXeroContactsFromDatabaseToXero(requestHeader models.RequestHeader, lang string, accountKey int) []models.ErrorResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		businessPartners []models.BusinessPartner
	)
	errorsResponse := make([]models.ErrorResponse, 0)
	db.Preload(
		"Addresses",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		models.BusinessPartner{}.TableName(),
	).Preload(
		"Phones",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		models.BusinessPartner{}.TableName(),
	).Preload("Locations").Find(&businessPartners)
	xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, businessPartners)
	for k, res := range xeroResponses {
		if res.Status != 200 {
			errResponse := GetErrorResponseErrorMessage(k, fmt.Sprintf("%v", res.Msg))
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	return errorsResponse
}

// AddTaxRateFromXeroToDatabaseFilterByTaxType func
func AddTaxRateFromXeroToDatabaseFilterByTaxType(requestHeader models.RequestHeader, lang string, accountKey int, taxType string) models.Tax {
	var (
		xeroTaxResponse models.XeroTaxResponse
		taxModel        models.Tax
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	params := make(map[string]interface{})
	params["where"] = `TaxType=="` + taxType + `"`
	representURL := "TaxRates"
	resStatus, _, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, params, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroTaxResponse)
		if len(xeroTaxResponse.TaxRates) > 0 {
			taxRate := xeroTaxResponse.TaxRates[0]
			resultFind := db.Where("TaxType = ? AND TaxName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", taxRate.TaxType, taxRate.Name).First(&taxModel)
			if resultFind.RowsAffected <= 0 {
				taxModel.ConvertXeroToDatabaseModel(taxRate)
				taxModel.CreatedBy = accountKey
				taxModel.ModifiedBy = accountKey
				db.Create(&taxModel)
			}
		}
	}
	return taxModel
}
