package controllers

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"os"
	"strconv"
	"text/template"
	"time"

	jpdatabase "jpapi/tig/v1/databases/jp"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

const LOGIN_MODE_WEB = "web"
const LOGIN_MODE_DEVICE = "device"

// CreateNewCompany func
func CreateNewCompany(c *gin.Context) {
	defer libs.RecoverError(c, "CreateNewCompany")
	var (
		status          = 200
		responseData    = gin.H{}
		responseMessage interface{}
		requestParams   models.ParamsCreateCompany
	)
	lang := services.GetLanguageKey(c)
	// check server username and password
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &requestParams)
	// check connection to db
	db := jpdatabase.ConnectDB(requestParams)
	sqlDB, err := db.DB()
	if err == nil {
		defer sqlDB.Close()
	}
	// create User for new db
	errCreateUser := jpdatabase.CreateUser(db, requestParams)
	if errCreateUser != nil {
		status = 400
		responseMessage = errCreateUser.Error
	} else {
		// create database
		errCreateDB := jpdatabase.CreateDatabase(db, requestParams.DatabaseID)
		if errCreateDB != nil {
			status = 400
			responseMessage = errCreateDB.Error
		} else {
			// choose database
			errChooseDB := jpdatabase.ChooseDatabase(db, requestParams.DatabaseID)
			if errChooseDB != nil {
				status = 400
				responseMessage = errChooseDB.Error
			} else {
				// permission user
				errPermissionUser := jpdatabase.PermissionUser(db, requestParams)
				if errPermissionUser != nil {
					status = 400
					responseMessage = errPermissionUser.Error
					jpdatabase.DropDatabase(db, requestParams.DatabaseID)
					jpdatabase.DropUserOfDatabase(db, requestParams.DBUsername)
				} else {
					// create all table in database
					errCreateTable := jpdatabase.CreateTableNewDB(db, requestParams.CompanyName, requestParams.CompanyID)
					if errCreateTable == nil {
						responseMessage = services.GetMessage(lang, "api.create_success")
						// @TODO Genereate data for searchfield table
						jpdatabase.GenerateDataWithAccountKey(db, requestParams.AccountKey)

						// @TODO Add master user
						CreateMasterUser(requestParams)
					} else {
						responseMessage = errCreateTable.Error
					}
				}
			}
		}
	}

	responseData = gin.H{
		"status": status,
		"msg":    responseMessage,
	}
	libs.ResponseData(responseData, c, status)
}

// CreateMasterUser func
func CreateMasterUser(requestParams models.ParamsCreateCompany) {
	var (
		postModel models.User
	)
	postModel.AccountKey = requestParams.AccountKey
	postModel.Email = requestParams.Email
	postModel.LocationID = requestParams.LocationID
	postModel.IsMaster = requestParams.IsMaster

	iSC, eSC := strconv.Atoi(os.Getenv("DEFAULT_SECURITY_GROUP"))
	if eSC == nil {
		postModel.SecurityGroupID = iSC
	}

	postModel.FirstName = requestParams.FirstName
	postModel.LastName = requestParams.LastName
	db := jpdatabase.CheckDBConnection(requestParams.DatabaseID, requestParams.DBUsername, requestParams.DBPassword, requestParams.Host, requestParams.DBPort)

	resultFindUser := db.Where("Email = ?", postModel.Email).First(&models.User{})
	if resultFindUser.RowsAffected == 0 {
		postModel.CreatedBy = requestParams.AccountKey
		postModel.ModifiedBy = requestParams.AccountKey
		validate, _ := services.GetValidatorTranslate()
		err := validate.Struct(postModel)
		if err == nil {
			err = db.Create(&postModel).Error
			if err == nil {
				// @TODO Add usermenu to master account
				var (
					menuModels     []models.DeviceMenu
					userMenuModels = make([]models.UserMenu, 0)
				)
				db.Select("MenuID").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&menuModels)
				if len(menuModels) > 0 {
					for _, menuModel := range menuModels {
						var userMenuModel models.UserMenu
						userMenuModel.UserID = postModel.UserID
						userMenuModel.MenuID = menuModel.MenuID
						userMenuModel.CreatedBy = requestParams.AccountKey
						userMenuModel.ModifiedBy = requestParams.AccountKey
						userMenuModels = append(userMenuModels, userMenuModel)
					}
					if len(userMenuModels) > 0 {
						db.Create(&userMenuModels)
					}
				}
			}
		}
	}
}

// CreateLoggedUser API
func CreateLoggedUser(c *gin.Context) {
	defer libs.RecoverError(c, "CreateLoggedUser")
	var (
		status       = 200
		responseData = gin.H{}
		paramsLogged models.ParamsLoggedUser
		loggedModel  models.DBLoggedUser
		msg          interface{}
		data         interface{}
	)
	lang := services.GetLanguageKey(c)
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &paramsLogged)
	if paramsLogged.DBName == "" || paramsLogged.DBUser == "" || paramsLogged.DBPassword == "" {
		status = 400
		msg = services.GetMessage(lang, "api.header_request_error")
		responseData = gin.H{
			"status": status,
			"msg":    msg,
		}
	} else {
		db := jpdatabase.CheckDBConnection(paramsLogged.DBName, paramsLogged.DBUser, paramsLogged.DBPassword, paramsLogged.Host, paramsLogged.DBPort)

		if paramsLogged.AccountKey == 0 {
			status = 400
			responseData = gin.H{
				"status": status,
				"msg":    services.GetMessage(lang, "api.field_not_empty", "AccountKey"),
			}
		} else if paramsLogged.Token == "" {
			status = 400
			responseData = gin.H{
				"status": status,
				"msg":    services.GetMessage(lang, "api.field_not_empty", "Token"),
			}
		} else if paramsLogged.ExpiredDate == "" {
			status = 400
			responseData = gin.H{
				"status": status,
				"msg":    services.GetMessage(lang, "api.field_not_empty", "ExpiredDate"),
			}
		} else {
			resultFind := db.Where("AccountKey = ?", paramsLogged.AccountKey).First(&loggedModel)
			vExpiredDate, sExpiredDate := time.Parse(libs.MYSQLDATE2, paramsLogged.ExpiredDate)
			if sExpiredDate == nil {
				loggedModel.ExpiredDate = &vExpiredDate
			}
			if resultFind.RowsAffected > 0 {
				if paramsLogged.Mode == LOGIN_MODE_DEVICE {
					loggedModel.DeviceToken = paramsLogged.Token
				} else {
					loggedModel.Token = paramsLogged.Token
				}
				resultSave := db.Save(&loggedModel)
				if resultSave.Error != nil {
					status = 500
					msg = resultSave.Error.Error()
				} else {
					data = loggedModel
					msg = services.GetMessage(lang, "api.update_success")

					// @TODO testing
					// @TODO Genereate data for searchfield table
					/* db1 := jpdatabase.CheckDBConnection(paramsLogged.DBName, paramsLogged.DBUser, paramsLogged.DBPassword, paramsLogged.Host, paramsLogged.DBPort)
					defer db1.Close()
					jpdatabase.GenerateDataWithAccountKey(db1, paramsLogged.AccountKey) */
				}
			} else {
				loggedModel.AccountKey = strconv.Itoa(paramsLogged.AccountKey)
				if paramsLogged.Mode == LOGIN_MODE_DEVICE {
					loggedModel.DeviceToken = paramsLogged.Token
				} else {
					loggedModel.Token = paramsLogged.Token
				}
				resultCreate := db.Create(&loggedModel)
				if resultCreate.Error != nil {
					status = 500
					msg = resultCreate.Error.Error()
				} else {
					data = paramsLogged
					msg = services.GetMessage(lang, "api.create_success")

				}
			}
			responseData = gin.H{
				"status": status,
				"data":   data,
				"msg":    msg,
			}
		}
	}
	libs.ResponseData(responseData, c, status)
}

// DeleteLoggedUser API
func DeleteLoggedUser(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteLoggedUser")
	var (
		status       = 200
		responseData = gin.H{}
		paramsLogged models.ParamsLoggedUser
		loggedModel  models.DBLoggedUser
		msg          interface{}
	)
	lang := services.GetLanguageKey(c)
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &paramsLogged)
	if paramsLogged.DBName == "" || paramsLogged.DBUser == "" || paramsLogged.DBPassword == "" {
		status = 400
		msg = services.GetMessage(lang, "api.header_request_error")
	} else {
		db := jpdatabase.CheckDBConnection(paramsLogged.DBName, paramsLogged.DBUser, paramsLogged.DBPassword, paramsLogged.Host, paramsLogged.DBPort)
		if paramsLogged.Mode == LOGIN_MODE_DEVICE {
			// @Find with token
			resultFind := db.Where("AccountKey = ? AND DeviceToken = ?", strconv.Itoa(paramsLogged.AccountKey), paramsLogged.Token).First(&loggedModel)
			if resultFind.RowsAffected > 0 {
				var resultDelete *gorm.DB
				if loggedModel.Token == "" {
					resultDelete = db.Delete(&loggedModel)
				} else {
					loggedModel.DeviceToken = ""
					resultDelete = db.Save(&loggedModel)
				}
				if resultDelete.Error == nil {
					msg = services.GetMessage(lang, "api.delete_success")
				} else {
					status = 500
					msg = resultDelete.Error.Error()
				}
			} else {
				msg = services.GetMessage(lang, "api.delete_success")
			}
		} else {
			// @Find with token
			resultFind := db.Where("AccountKey = ? AND Token = ?", strconv.Itoa(paramsLogged.AccountKey), paramsLogged.Token).First(&loggedModel)
			if resultFind.RowsAffected > 0 {
				var resultDelete *gorm.DB
				if loggedModel.DeviceToken == "" {
					resultDelete = db.Delete(&loggedModel)
				} else {
					loggedModel.Token = ""
					resultDelete = db.Save(&loggedModel)
				}
				if resultDelete.Error == nil {
					msg = services.GetMessage(lang, "api.delete_success")
				} else {
					status = 500
					msg = resultDelete.Error.Error()
				}
			} else {
				msg = services.GetMessage(lang, "api.delete_success")
			}
		}

	}
	responseData = gin.H{
		"status": status,
		"msg":    msg,
	}
	libs.ResponseData(responseData, c, status)
}

// UnlockScreen godoc
// @Summary Unlock Screen
// @Description Unlock Screen
// @Tags System
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Report body models.UnlockScreenPOST true "Unlock Screen"
// @Success 200 {object} models.APIResponseData
// @Router /unlockscreen [post]
func UnlockScreen(c *gin.Context) {
	defer libs.RecoverError(c, "UnlockScreen")
	var (
		status          = libs.GetStatusSuccess()
		response        models.APIResponseData
		msg, data       interface{}
		errorsResponse  []models.ErrorResponse
		unlockPOST      models.UnlockScreenPOST
		unlockPASS      models.UnlockScreenPASS
		bodyDataJSON    []byte
		errRes          models.ServerREEResponse
		resUnlockScreen models.UnlockScreenResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &unlockPOST)
	unlockPASS.AccountKey = accountKey
	unlockPASS.Password = unlockPOST.Password

	vBodyDataJSON, sBodyDataJSON := json.Marshal(unlockPASS)
	if sBodyDataJSON == nil {
		bodyDataJSON = vBodyDataJSON
	}
	URL := os.Getenv("SERVER_REE") + "/" + "unlockscreen"
	req, err := http.NewRequest("POST", URL, bytes.NewBuffer(bodyDataJSON))
	req.Close = true
	if err != nil {
		status = 500
		msg = err.Error()
	} else {
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			if resp != nil {
				status = resp.StatusCode
				body, _ := ioutil.ReadAll(resp.Body)
				json.Unmarshal([]byte(string(body)), &errRes)
				msg = errRes.Msg
			} else {
				status = 500
			}
			if err != nil {
				msg = err.Error()
			} else {
				if msg == nil {
					msg = services.GetMessage(lang, "api.request_api_error")
				}
			}
		}
		if resp != nil {
			defer resp.Body.Close()
		}
	}

	if status == 200 {
		resUnlockScreen.Unlock = true
	} else {
		resUnlockScreen.Unlock = false
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	data = resUnlockScreen

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ContactUs godoc
// @Summary ContactUs
// @Description ContactUs
// @Tags Account
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /contactus [post]
func ContactUs(c *gin.Context) {
	defer libs.RecoverError(c, "ContactUs")
	var (
		status     = libs.GetStatusSuccess()
		response   models.APIResponseData
		msg, data  interface{}
		contactUs  models.ContactUs
		emailFrom  = os.Getenv("EMAILSYSTEM")
		nameFrom   = os.Getenv("EMAILSENDERNAME")
		emailTitle = os.Getenv("CONTACT_US_EMAIL_TITLE")
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &contactUs)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	companyID := c.Request.Header.Get("companyid")
	URL := os.Getenv("SERVER_REE") + "/" + "getcontactusemail"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	headers["CompanyID"] = companyID
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data = reeResponse["data"]
		fileName := "contact_us.html"
		pathTemplate := "public/email/" + fileName

		arrayParams := make(map[string]string, 0)
		arrayParams["companyname"] = contactUs.CompanyName
		arrayParams["firstName"] = contactUs.FirstName
		arrayParams["lastName"] = contactUs.LastName
		arrayParams["message"] = contactUs.Message
		arrayParams["emailAddress"] = contactUs.EmailAddress

		t := template.New(fileName)
		t, err := t.ParseFiles(pathTemplate)
		if err == nil {
			var tpl bytes.Buffer
			if err := t.Execute(&tpl, arrayParams); err == nil {
				body := tpl.String()
				var convertObj map[string]interface{}
				dataJSON, _ := json.Marshal(data)
				json.Unmarshal([]byte(dataJSON), &convertObj)
				emails := convertObj["Email"]
				if emailTitle == "" {
					emailTitle = contactUs.Subject
				}
				statusSend, msgSend := libs.SendEmail(emailFrom, nameFrom, fmt.Sprintf("%v", emails), "Administrator", emailTitle, body)
				if statusSend != 200 {
					status = 500
					msg = msgSend
				}
			}
		}
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = nil
	libs.APIResponseData(response, c, status)
}
