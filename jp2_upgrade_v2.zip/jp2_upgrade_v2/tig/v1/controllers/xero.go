package controllers

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/jasonlvhit/gocron"
	"gopkg.in/go-playground/validator.v9"
)

// Callback API
func Callback(c *gin.Context) {
	funcLogName := "Callback"
	defer libs.RecoverError(c, funcLogName)
	var (
		response models.APIResponseData
		status   = libs.GetStatusSuccess()
		msg      interface{}
		data     interface{}
	)
	/* statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	} */
	/* db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//
	*/
	//lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	arr := c.Request.URL.Query()
	data = arr
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// Connections API
func Connections(c *gin.Context) {
	funcLogName := "Connections"
	defer libs.RecoverError(c, funcLogName)
	var (
		status         = libs.GetStatusSuccess()
		msg            interface{}
		data           interface{}
		connectionsRes []models.XeroConnectionResponse
		errRes         models.XeroErrorConnectionResponse
		response       models.APIResponseData
		isInvalidGrant = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	xeroConfig, isInvalidGrant := libs.GetXeroAccessToken(requestHeader)
	accessToken := xeroConfig.AccessToken
	if isInvalidGrant {
		status = 401
		msg = services.GetMessage(lang, "api.xero_invalid_grant", "")
	} else if accessToken == "" {
		status = 422
		msg = services.GetMessage(lang, "api.field_not_found", "access_token")
	}
	if status == 200 {
		URL := xeroConfig.BaseURL + "/connections"
		req, err := http.NewRequest("GET", URL, nil)
		req.Close = true
		if err == nil {
			token := "Bearer " + accessToken
			req.Header.Set("Authorization", token)
			req.Header.Set("Content-Type", "application/json")
			client := &http.Client{}
			resp, err := client.Do(req)
			if err == nil && resp.StatusCode == 200 {
				body, _ := ioutil.ReadAll(resp.Body)
				json.Unmarshal([]byte(string(body)), &connectionsRes)
				data = connectionsRes
				msg = services.GetMessage(lang, "api.success")
			} else {
				if resp != nil {
					status = resp.StatusCode
					body, _ := ioutil.ReadAll(resp.Body)
					json.Unmarshal([]byte(string(body)), &errRes)
					msg = errRes.Title
				} else {
					status = 500
					msg = services.GetMessage(lang, "api.request_api_error")
				}
			}
		} else {
			status = 500
			msg = err.Error()
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// GetXeroConfig godoc
// @Summary Get Xero Config
// @Description Get Xero Config
// @Tags XeroConfig
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/config [get]
func GetXeroConfig(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroConfig")
	var (
		status         = libs.GetStatusSuccess()
		resModel       models.XeroConfig
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		responsesData  gin.H
		connectionsRes []models.XeroTenantResponse
		isInvalidGrant = false
		xeroConfig     models.XeroConfig
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	resultRow := db.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := resModel
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	if resModel.IsActive {
		xeroConfig, isInvalidGrant = libs.GetXeroAccessToken(requestHeader)
		accessToken := xeroConfig.AccessToken
		if isInvalidGrant {
			status = 401
			msg = services.GetMessage(lang, "api.xero_invalid_grant", "")
		} else if accessToken != "" {
			connectionsRes, status, msg = GetTenant(xeroConfig, lang)
		}
	}

	data = ConvertXeroConfigToResponse(requestHeader, resModel, connectionsRes)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateXeroConfig godoc
// @Summary Update Xero Config
// @Description Update Xero Config
// @Tags XeroConfig
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param XeroConfig body models.XeroConfig true "Update Xero Config"
// @Success 200 {object} models.APIResponseData
// @Router /xero/config [put]
func UpdateXeroConfig(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateXeroConfig")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
		connectionsRes     []models.XeroTenantResponse
		changeTenant       = false
		isActive           = false
		xeroConfig         models.XeroConfig
		isInvalidGrant     = false
	)

	// Stop cron job
	gocron.Clear()
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel    models.XeroConfig
		curResModel models.XeroConfig
	)
	resModel.XeroConfigKey = 1
	resultFind := db.First(&resModel)
	curResModel = resModel
	resModel.PassBodyJSONToModel(bp)

	isRenew := false
	if curResModel.BaseURL != resModel.BaseURL {
		isRenew = true
	}
	if curResModel.IdentityURL != resModel.IdentityURL {
		isRenew = true
	}
	if curResModel.RedirectURI != resModel.RedirectURI {
		isRenew = true
	}
	if curResModel.AuthorizationCode != resModel.AuthorizationCode {
		isRenew = true
	}
	if curResModel.ClientID != resModel.ClientID {
		isRenew = true
	}
	if curResModel.ClientSecret != resModel.ClientSecret {
		isRenew = true
	}

	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		vIsActive, sIsActive := libs.GetQueryParam("isactive", c)
		if sIsActive {
			isActive, _ = strconv.ParseBool(vIsActive)
			resModel.IsActive = isActive
		}
		if resModel.IsActive {
			if isRenew {
				resModel.AccessToken = ""
				resModel.RefreshToken = ""
			}
		}

		var errProcess error
		if resultFind.RowsAffected > 0 {
			resModel.XeroConfigKey = 1
			errProcess = db.Save(&resModel).Error
		} else {
			resModel.XeroConfigKey = 1
			errProcess = db.Create(&resModel).Error
		}
		if errProcess != nil {
			errResponse := GetErrorResponseErrorMessage(0, errProcess.Error())
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			totalUpdatedRecord++
			data = resModel

		}
	}
	if resModel.IsActive {
		vChangeTenant, sChangeTenant := libs.GetQueryParam("changetenant", c)
		if sChangeTenant {
			changeTenant, _ = strconv.ParseBool(vChangeTenant)
		}
		// Generate Token
		xeroConfig, isInvalidGrant = libs.GetXeroAccessToken(requestHeader)
		accessToken := xeroConfig.AccessToken
		if isInvalidGrant {
			status = 401
			msg = services.GetMessage(lang, "api.xero_invalid_grant", "")
		} else if accessToken == "" {
			status = 422
			msg = services.GetMessage(lang, "api.field_not_found", "Access Token")
		}

		if status == 200 {
			connectionsRes, status, msg = GetTenant(xeroConfig, lang)
			if len(connectionsRes) > 0 {
				if !changeTenant {
					xeroConfig.TenantID = connectionsRes[0].TenantID
					db.Save(&xeroConfig)
				}
			}
		}
	}
	data = ConvertXeroConfigToResponse(requestHeader, resModel, connectionsRes)
	errors = errorsResponse
	if status == 200 {
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	}

	// @TODO update cronjob
	go func() {
		CronJob()
	}()
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetTenant func
func GetTenant(xeroConfig models.XeroConfig, lang string) ([]models.XeroTenantResponse, int, string) {
	var (
		errRes         models.XeroErrorConnectionResponse
		status         = libs.GetStatusSuccess()
		msg            string
		connectionsRes []models.XeroTenantResponse
	)
	URL := xeroConfig.BaseURL + "/connections"
	req, err := http.NewRequest("GET", URL, nil)
	req.Close = true
	if err == nil {
		// Get TenantId
		token := "Bearer " + xeroConfig.AccessToken
		req.Header.Set("Authorization", token)
		req.Header.Set("Content-Type", "application/json")
		client := &http.Client{}
		resp, err := client.Do(req)
		if err == nil && resp.StatusCode == 200 {
			body, _ := ioutil.ReadAll(resp.Body)
			json.Unmarshal([]byte(string(body)), &connectionsRes)
			msg = services.GetMessage(lang, "api.success")
		} else {
			if resp != nil {
				status = resp.StatusCode
				body, _ := ioutil.ReadAll(resp.Body)
				json.Unmarshal([]byte(string(body)), &errRes)
				msg = errRes.Title
			} else {
				status = 500
				msg = services.GetMessage(lang, "api.request_api_error")
			}
		}
	} else {
		status = 500
		msg = err.Error()
	}
	return connectionsRes, status, msg
}

// GetAccessToken func
func GetAccessToken(c *gin.Context) {
	funcLogName := "GetAccessToken"
	defer libs.RecoverError(c, funcLogName)
	var (
		status = libs.GetStatusSuccess()
		msg    interface{}
		data   interface{}
		//connectionsRes []models.XeroConnectionResponse
		//errRes         models.XeroErrorConnectionResponse
		response       models.APIResponseData
		xeroConfig     models.XeroConfig
		isInvalidGrant = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	xeroConfig, isInvalidGrant = libs.GetXeroAccessToken(requestHeader)
	accessToken := xeroConfig.AccessToken
	if isInvalidGrant {
		status = 401
		msg = services.GetMessage(lang, "api.xero_invalid_grant", "")
	} else if accessToken == "" {
		status = 422
		msg = services.GetMessage(lang, "api.field_not_found", "Access Token")
	} else {
		msg = services.GetMessage(lang, "api.success")
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// XeroEvents godoc
// @Summary Create Xero Events
// @Description Create Xero Events
// @Tags XeroConfig
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/xeroevents [put]
func XeroEvents(c *gin.Context) {
	defer libs.RecoverError(c, "XeroEvents")
	var (
		status     = libs.GetStatusSuccess()
		xeroEvents models.XeroEventResponse
	)
	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		hasWebHookKey := false
		databasesInfo := GetDatabasesInfo()
		for _, dbInfo := range databasesInfo {
			db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)

			var (
				xeroConfig models.XeroConfig
			)
			resultFindXeroConfig := db.First(&xeroConfig)
			if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
				webHookKey := xeroConfig.WebhookKey
				h := hmac.New(sha256.New, []byte(webHookKey))
				h.Write([]byte(string(body)))
				signature := base64.StdEncoding.EncodeToString(h.Sum(nil))
				headerSignature := c.Request.Header.Get("x-xero-signature")
				if signature == headerSignature {
					hasWebHookKey = true
				}
				json.Unmarshal([]byte(string(body)), &xeroEvents)
				if len(xeroEvents.Events) > 0 {
					for _, e := range xeroEvents.Events {
						if e.TenantID == xeroConfig.TenantID {
							if e.EventCategory == "CONTACT" {
								go func(dbInfo DatabaseInfo, e models.XeroEventItem) {
									db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)

									var (
										accountKey int
										lang       string
										userMaster models.User
									)
									lang = services.BundleObject.DefaultLanguage.String()
									resultFindUserMaster := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsMaster, 0) = 1").First(&userMaster)
									if resultFindUserMaster.RowsAffected > 0 {
										accountKey = userMaster.UserID
									}
									requestHeader := ConvertDBInfoToRequestHeader(dbInfo)
									UpdateXeroContactFromXeroToDatabase(requestHeader, lang, accountKey, e.ResourceID)
								}(dbInfo, e)
							}
						}
					}
				}
			}
		}
		if hasWebHookKey {
			status = 200
		} else {
			status = 401
		}
	} else {
		status = 500
	}
	c.Writer.WriteHeader(status)
}

// UpdateXeroContactFromXeroToDatabase func
func UpdateXeroContactFromXeroToDatabase(requestHeader models.RequestHeader, lang string, accountKey int, resourceID string) []models.ErrorResponse {
	var (
		xeroContactResponse models.XeroContactResponse
		errProcess          error
	)
	errorsResponse := make([]models.ErrorResponse, 0)
	representURL := "Contacts/" + resourceID
	// @TODO get one contact
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
		if len(xeroContactResponse.Contacts) > 0 {
			xero := xeroContactResponse.Contacts[0]
			errProcess = ProcessXeroContactFromXeroToDatabase(requestHeader, xero, lang, accountKey)
			if errProcess != nil {
				errResponse := GetErrorResponseErrorMessage(0, errProcess.Error())
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		if resMsg != nil {
			errResponse := GetErrorResponseErrorMessage(0, fmt.Sprintf("%v", resMsg))
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	return errorsResponse
}

// ConvertXeroConfigToResponse func
func ConvertXeroConfigToResponse(requestHeader models.RequestHeader, item models.XeroConfig, tenant []models.XeroTenantResponse) models.XeroConfigResponse {
	var (
		response       models.XeroConfigResponse
		tenantResponse []models.TenantResponse
	)
	response.XeroConfigKey = item.XeroConfigKey
	response.BaseURL = item.BaseURL
	response.IdentityURL = item.IdentityURL
	response.RedirectURI = item.RedirectURI
	response.AuthorizationCode = item.AuthorizationCode
	response.TenantID = item.TenantID
	response.ClientID = item.ClientID
	response.ClientSecret = item.ClientSecret
	response.IsActive = item.IsActive
	response.UseXeroPush = item.UseXeroPush
	response.IntervalInSeconds = item.IntervalInSeconds
	response.InventoryAssetAccountCode = item.InventoryAssetAccountCode
	response.InventoryPurchaseAccountCode = item.InventoryPurchaseAccountCode
	response.WebhookURL = item.WebhookURL
	response.WebhookKey = item.WebhookKey
	for _, t := range tenant {
		var (
			tn models.TenantResponse
		)
		tn.TenantID = t.TenantID
		tn.TenantName = t.TenantName
		tenantResponse = append(tenantResponse, tn)
	}
	if len(tenantResponse) > 0 {
		response.Tenant = tenantResponse
	} else {
		response.Tenant = []models.TenantResponse{}
	}
	response.IsInvoiceEnabled = item.IsInvoiceEnabled
	response.IsCreditNoteEnabled = item.IsCreditNoteEnabled
	response.IsPostAfterJobCompleted = item.IsPostAfterJobCompleted
	response.PostedInvoiceStatus = item.PostedInvoiceStatus
	response.Organisation = item.Organisation
	response.Branding = item.Branding
	response.InvoiceNumberGeneration = item.InvoiceNumberGeneration
	response.InvoiceDueDate = item.InvoiceDueDate
	response.CreditNoteNumberGeneration = item.CreditNoteNumberGeneration
	response.ItemSaleAccountCode = item.ItemSaleAccountCode
	return response
}

// GetOrganisation godoc
// @Summary Get Organisation
// @Description Get Organisation
// @Tags Organisation
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/organisation [get]
func GetOrganisation(c *gin.Context) {
	defer libs.RecoverError(c, "GetOrganisation")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//headers := map[string]interface{}{"If-Modified-Since": "2020-09-01T05:23:08"}
	headers := map[string]interface{}{}
	representURL := "Organisations"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, headers)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		var organisationsRes = make([]models.XeroOrganisation, 0)
		objectJSON, errJSON := json.Marshal(dataRes["Organisations"])
		if errJSON == nil {
			json.Unmarshal(objectJSON, &organisationsRes)
		}
		data = organisationsRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetBranding godoc
// @Summary GetBranding
// @Description GetBranding
// @Tags Branding
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/branding [get]
func GetBranding(c *gin.Context) {
	defer libs.RecoverError(c, "GetBranding")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//headers := map[string]interface{}{"If-Modified-Since": "2020-09-01T05:23:08"}
	headers := map[string]interface{}{}
	representURL := "BrandingThemes"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, headers)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		var brandingThemesRes = make([]models.XeroBranding, 0)
		objectJSON, errJSON := json.Marshal(dataRes["BrandingThemes"])
		if errJSON == nil {
			json.Unmarshal(objectJSON, &brandingThemesRes)
		}
		data = brandingThemesRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
