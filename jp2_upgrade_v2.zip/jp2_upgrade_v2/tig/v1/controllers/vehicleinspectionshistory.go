package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetVehicleInspectionHistory godoc
// @Summary Get VehicleInspectionHistory
// @Description Get VehicleInspectionHistory
// @Tags VehicleInspectionHistory
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param VehicleInspectionID query integer false "VehicleInspectionID"
// @Param ResourceID query integer false "ResourceID"
// @Param InspectionDateFrom query string false "InspectionDateFrom - yyyy-mm-dd"
// @Param InspectionDateTo query string false "InspectionDateTo - yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionhistory [get]
func GetVehicleInspectionHistory(c *gin.Context) {
	defer libs.RecoverError(c, "VehicleInspectionHistory")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.VehicleInspectionHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
	})
	bp = bp.Preload("Questions.Photos", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.VehicleInspectionQuestionHistory{}.TableName())
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"VehicleInspectionID", "ResourceID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{"InspectionDate"}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayVehicleInspectionHistoryToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetVehicleInspectionHistoryByID godoc
// @Summary Get VehicleInspectionHistory By ID
// @Description Get VehicleInspectionHistory By ID
// @Tags VehicleInspectionHistory
// @Accept  json
// @Produce  json
// @Param id path int true "VehicleInspectionHistory ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionhistory/{id} [get]
func GetVehicleInspectionHistoryByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetVehicleInspectionHistoryByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.VehicleInspectionHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Preload(
		"Questions.Photos",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.VehicleInspectionQuestionHistory{}.TableName())
		},
	).Where("VehicleInspectionHistoryID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertVehicleInspectionHistoryToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateVehicleInspectionHistory godoc
// @Summary Create VehicleInspectionHistory
// @Description Create VehicleInspectionHistory
// @Tags VehicleInspectionHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleInspectionHistory body models.VehicleInspectionHistoryResponse true "Create VehicleInspectionHistory"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionhistory [post]
func CreateVehicleInspectionHistory(c *gin.Context) {
	defer libs.RecoverError(c, "CreateVehicleInspectionHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.VehicleInspectionHistory
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		for i := range resModel.Questions {
			resModel.Questions[i].CreatedBy = accountKey
			if len(resModel.Questions[i].Photos) > 0 {
				for k := range resModel.Questions[i].Photos {
					resModel.Questions[i].Photos[k].CreatedBy = accountKey
					resModel.Questions[i].Photos[k].TableNameObj = models.VehicleInspectionHistory{}.TableName()
				}
			}
		}
		// @TODO validate for details
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				data = ConvertVehicleInspectionHistoryToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateVehicleInspectionHistory godoc
// @Summary Update VehicleInspectionHistory
// @Description Update VehicleInspectionHistory
// @Tags VehicleInspectionHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleInspectionHistory body models.VehicleInspectionHistoryResponse true "Update VehicleInspectionHistory"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionhistory/{id} [put]
func UpdateVehicleInspectionHistory(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateVehicleInspectionHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel              models.VehicleInspectionHistory
		arrPhotoIDBeforUpdate = make([]int, 0)
	)
	resultFind := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Preload(
		"Questions.Photos",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.VehicleInspectionHistory{}.TableName())
		},
	).Where("VehicleInspectionHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		for _, v := range resModel.Questions {
			for _, d := range v.Photos {
				arrPhotoIDBeforUpdate = append(arrPhotoIDBeforUpdate, d.PhotoID)
			}
		}

		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.VehicleInspectionHistoryID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			//timeNow := time.Now()
			for i := range resModel.Questions {
				resModel.Questions[i].ModifiedBy = accountKey
				for j := range resModel.Questions[i].Photos {
					if resModel.Questions[i].Photos[j].PhotoID <= 0 {
						resModel.Questions[i].Photos[j].CreatedBy = accountKey
					}
					resModel.Questions[i].Photos[j].ModifiedBy = accountKey
					resModel.Questions[i].Photos[j].TableNameObj = models.VehicleInspectionHistory{}.TableName()
				}
			}

			// @TODO validate for details
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					arrQuestionSkipID := make([]int, 0)
					arrPhotoIDAfterUpdate := make([]int, 0)
					for _, v := range resModel.Questions {
						arrQuestionSkipID = append(arrQuestionSkipID, v.VehicleInspectionQuestionHistoryID)
						for _, d := range v.Photos {
							arrPhotoIDAfterUpdate = append(arrPhotoIDAfterUpdate, d.PhotoID)
						}
					}
					if len(arrQuestionSkipID) > 0 {
						db.Where("VehicleInspectionHistoryID = ? AND VehicleInspectionQuestionHistoryID not in (?)", resModel.VehicleInspectionHistoryID, arrQuestionSkipID).Model(&models.VehicleInspectionQuestionHistory{}).Updates(models.VehicleInspectionQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("VehicleInspectionHistoryID = ?", resModel.VehicleInspectionHistoryID).Model(&models.VehicleInspectionQuestionHistory{}).Updates(models.VehicleInspectionQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					}
					// find photoid to delete
					arrPhotoIDToDelete := make([]int, 0)
					for _, i := range arrPhotoIDBeforUpdate {
						hasPhotoID := false
						for _, j := range arrPhotoIDAfterUpdate {
							if i == j {
								hasPhotoID = true
								break
							}
						}
						if !hasPhotoID {
							arrPhotoIDToDelete = append(arrPhotoIDToDelete, i)
						}
					}
					if len(arrPhotoIDToDelete) > 0 {
						db.Where("PhotoID in (?)", arrPhotoIDToDelete).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"Questions",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
						},
					).Preload(
						"Questions.Photos",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.VehicleInspectionHistory{}.TableName())
						},
					).Where("VehicleInspectionHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertVehicleInspectionHistoryToResponse(requestHeader, resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteVehicleInspectionHistory godoc
// @Summary Delete VehicleInspectionHistory
// @Description Delete VehicleInspectionHistory
// @Tags VehicleInspectionHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspectionhistory/{id} [delete]
func DeleteVehicleInspectionHistory(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteVehicleInspectionHistory")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.VehicleInspectionHistory
		)
		resultFind := db.Preload(
			"Questions",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
			},
		).Preload(
			"Questions.Photos",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.VehicleInspectionHistory{}.TableName())
			},
		).Where("VehicleInspectionHistoryID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				arrDeleteHistoryID := make([]int, 0)
				arrDeletePhotoID := make([]int, 0)
				for _, v := range resModel.Questions {
					arrDeleteHistoryID = append(arrDeleteHistoryID, v.VehicleInspectionQuestionHistoryID)
					for _, p := range v.Photos {
						arrDeletePhotoID = append(arrDeletePhotoID, p.PhotoID)
					}
				}
				if len(arrDeleteHistoryID) > 0 {
					db.Where("VehicleInspectionQuestionHistoryID in (?)", arrDeleteHistoryID).Model(&models.VehicleInspectionQuestionHistory{}).Updates(models.VehicleInspectionQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
				}
				if len(arrDeletePhotoID) > 0 {
					db.Where("PhotoID in (?)", arrDeletePhotoID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayVehicleInspectionHistoryToArrayResponse func
func ConvertArrayVehicleInspectionHistoryToArrayResponse(requestHeader models.RequestHeader, items []models.VehicleInspectionHistory) []models.VehicleInspectionHistoryResponse {
	responses := make([]models.VehicleInspectionHistoryResponse, 0)
	for _, item := range items {
		response := ConvertVehicleInspectionHistoryToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertVehicleInspectionHistoryToResponse func
func ConvertVehicleInspectionHistoryToResponse(requestHeader models.RequestHeader, item models.VehicleInspectionHistory) models.VehicleInspectionHistoryResponse {
	var (
		response        models.VehicleInspectionHistoryResponse
		inspectionModel models.VehicleInspection
		resource        models.Resource
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.VehicleInspectionHistoryID = item.VehicleInspectionHistoryID
	response.VehicleInspectionID = item.VehicleInspectionID
	resultFindInspection := db.Where("VehicleInspectionID = ?", item.VehicleInspectionID).First(&inspectionModel)
	if resultFindInspection.RowsAffected > 0 {
		response.VehicleInspectionName = inspectionModel.VehicleInspectionName
	}
	response.InspectionDate = item.InspectionDate
	response.Comment = item.Comment
	response.Rego = item.Rego
	response.Odometer = item.Odometer
	response.ResourceID = item.ResourceID
	resultFindResource := db.Where("ResourceID = ?", item.ResourceID).First(&resource)
	if resultFindResource.RowsAffected > 0 {
		response.ResourceCode = resource.ResourceCode
		response.ResourceName = resource.ResourceName
	}
	details := make([]models.VehicleInspectionQuestionHistoryResponse, 0)
	for _, v := range item.Questions {
		var detail models.VehicleInspectionQuestionHistoryResponse

		detail.VehicleInspectionQuestionHistoryID = v.VehicleInspectionQuestionHistoryID
		detail.VehicleInspectionHistoryID = v.VehicleInspectionHistoryID
		detail.GroupName = v.GroupName
		detail.Question = v.Question
		detail.Status = v.Status
		photos := make([]models.PhotoResponse, 0)

		for _, d := range v.Photos {
			var (
				photo       models.PhotoResponse
				reasonModel models.Reason
			)
			photo.PhotoID = d.PhotoID
			photo.TableNameObj = d.TableNameObj
			photo.ReasonID = d.ReasonID
			resultFindReason := db.Where("ReasonID = ?", d.ReasonID).First(&reasonModel)
			if resultFindReason.RowsAffected > 0 {
				photo.Reason = reasonModel.Reason
			}
			photo.ImageKey = d.ImageKey
			photo.ImageURL = d.ImageURL
			photo.ImageSize = d.ImageSize
			photo.ETag = d.ETag
			photo.Comment = d.Comment
			photo.PositionX = d.PositionX
			photo.PositionY = d.PositionY
			photos = append(photos, photo)
		}
		detail.Photos = photos
		details = append(details, detail)
	}
	response.Questions = details

	return response
}
