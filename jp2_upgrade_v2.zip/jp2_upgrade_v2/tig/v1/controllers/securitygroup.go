package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetSecurityGroup godoc
// @Summary Get SecurityGroup
// @Description Get SecurityGroup
// @Tags SecurityGroup
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /securitygroup [get]
func GetSecurityGroup(c *gin.Context) {
	defer libs.RecoverError(c, "GetSecurityGroup")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.SecurityGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	// Paging
	/* vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	} */

	//var bp = db.Limit(vLength).Offset(vStart)

	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"SecurityGroupName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySecurityGroupToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetSecurityGroupByID godoc
// @Summary Get SecurityGroup By ID
// @Description Get SecurityGroup  By ID
// @Tags SecurityGroup
// @Accept  json
// @Produce  json
// @Param id path int true "SecurityGroup ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /securitygroup/{id} [get]
func GetSecurityGroupByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetSecurityGroupByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.SecurityGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND SecurityGroupID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertSecurityGroupToResponse(resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateSecurityGroup godoc
// @Summary Create SecurityGroup
// @Description Create SecurityGroup
// @Tags SecurityGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SecurityGroup body []models.SecurityGroupResponse true "Create SecurityGroup"
// @Success 200 {object} models.APIResponseData
// @Router /securitygroup [post]
func CreateSecurityGroup(c *gin.Context) {
	defer libs.RecoverError(c, "CreateSecurityGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.SecurityGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.SecurityGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		isClone = false
	)
	vIsClone, sIsClone := libs.GetQueryParam("isclone", c)
	if sIsClone {
		bIsClone, eIsClone := strconv.ParseBool(vIsClone)
		if eIsClone == nil {
			isClone = bIsClone
		}
	}
	_, sSecurityGroupID := libs.GetQueryParam("securitygroupid", c)
	if isClone && !sSecurityGroupID {
		errResponse := GetErrorResponseValidate(lang, 0, "api.securitygroupid_required")
		errorsResponse = append(errorsResponse, errResponse)
		errors = errorsResponse
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
		data = dataResponse
		response.Status = status
		response.Message = msg
		response.Errors = errors
		response.Data = data
		libs.APIResponseData(response, c, status)
		return
	}

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.SecurityGroup
			)
			item.PassBodyJSONToModel(bp)

			resultFindSecurityGroup := db.Where("SecurityGroupName = ? AND IsDeleted = 0", item.SecurityGroupName).First(&models.SecurityGroup{})
			if resultFindSecurityGroup.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.securitygroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			item.CreatedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				resultCreate := db.Create(&item)
				if resultCreate.Error != nil {
					if itemMsgError == "" {
						itemMsgError = resultCreate.Error.Error()
					} else {
						itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
					}
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, item)

					// @TODO process permission
					ProcessClonePermission(requestHeader, c, item.SecurityGroupID, accountKey)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}

		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.SecurityGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.SecurityGroupID)
	}
	if len(arrID) > 0 {
		db.Where("SecurityGroupID in (?)", arrID).Find(&items)
		data = ConvertArraySecurityGroupToArrayResponse(items)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateSecurityGroup godoc
// @Summary Update SecurityGroup
// @Description Update SecurityGroup
// @Tags SecurityGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SecurityGroup body []models.SecurityGroupResponse true "Update SecurityGroup"
// @Success 200 {object} models.APIResponseData
// @Router /securitygroup [put]
func UpdateSecurityGroup(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSecurityGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.SecurityGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.SecurityGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.SecurityGroup
			)
			item.PassBodyJSONToModel(bp)

			resultFindSecurityGroup := db.Where("SecurityGroupName = ? AND SecurityGroupID <> ?  AND IsDeleted = 0", item.SecurityGroupName, item.SecurityGroupID).First(&models.SecurityGroup{})
			if resultFindSecurityGroup.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.securitygroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("SecurityGroupID = ?", item.SecurityGroupID).First(&item)
			if resultFind.RowsAffected > 0 {
				// @TODO not allow to delete admin
				if item.IsAdministrator {
					errResponse := GetErrorResponseValidate(lang, k, "api.securitygroup_isadmin")
					errorsResponse = append(errorsResponse, errResponse)
					continue
				}
			}

			item.PassBodyJSONToModel(bp)
			item.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var errProcess error
				if resultFind.RowsAffected > 0 {
					errProcess = db.Save(&item).Error
				} else {
					errProcess = db.Create(&item).Error
				}
				if errProcess == nil {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, item)
				} else {
					errResponse := GetErrorResponseErrorMessage(k, errProcess.Error())
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.SecurityGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.SecurityGroupID)
	}
	if len(arrID) > 0 {
		db.Where("SecurityGroupID in (?)", arrID).Find(&items)
		data = ConvertArraySecurityGroupToArrayResponse(items)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteSecurityGroup godoc
// @Summary Delete SecurityGroup
// @Description Delete SecurityGroup
// @Tags SecurityGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "SecurityGroup ID"
// @Success 200 {object} models.APIResponseData
// @Router /securitygroup/{id} [delete]
func DeleteSecurityGroup(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteSecurityGroup")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.SecurityGroup
		)
		resultFind := db.Where("SecurityGroupID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			// @TODO not allow to delete admin
			if uModel.IsAdministrator {
				errResponse := GetErrorResponseValidate(lang, k, "api.securitygroup_isadmin")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}
			// @TODO not allow to delete securitygroup assigned to user
			var (
				checkUserModel models.User
			)
			resultFindUser := db.Where("SecurityGroupID = ?", uModel.SecurityGroupID).First(&checkUserModel)
			if resultFindUser.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.securitygroup_assigned")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			statusDelete := uModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				uModel.IsDeleted = true
				deletedResult := db.Save(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++

					// @TODO After deleting the security group => delete permission
					db.Where("SecurityGroupID = ?", uModel.SecurityGroupID).Delete(&models.Permission{})
					//db.Model(models.Permission{}).Where("SecurityGroupID = ?", uModel.SecurityGroupID).Updates(models.Permission{IsDeleted: true})
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArraySecurityGroupToArrayResponse func
func ConvertArraySecurityGroupToArrayResponse(items []models.SecurityGroup) []models.SecurityGroupResponse {
	responses := make([]models.SecurityGroupResponse, 0)
	for _, item := range items {
		response := ConvertSecurityGroupToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertSecurityGroupToResponse func
func ConvertSecurityGroupToResponse(item models.SecurityGroup) models.SecurityGroupResponse {
	var (
		response models.SecurityGroupResponse
	)
	response.SecurityGroupID = item.SecurityGroupID
	response.SecurityGroupName = item.SecurityGroupName
	response.IsAdministrator = item.IsAdministrator

	return response
}

// ProcessClonePermission func
func ProcessClonePermission(requestHeader models.RequestHeader, c *gin.Context, newSecurityGroupID int, accountKey int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		isClone         = false
		securityGroupID = 0
	)
	arrSecurityGroup := make([]int, 0)
	vIsClone, sIsClone := libs.GetQueryParam("isclone", c)
	if sIsClone {
		bIsClone, eIsClone := strconv.ParseBool(vIsClone)
		if eIsClone == nil {
			isClone = bIsClone
		}
	}
	vSecurityGroupID, sSecurityGroupID := libs.GetQueryParam("securitygroupid", c)
	if sSecurityGroupID {
		iSecurityGroupID, eSecurityGroupID := strconv.Atoi(vSecurityGroupID)
		if eSecurityGroupID == nil {
			securityGroupID = iSecurityGroupID
		}
	}
	if isClone {
		// if isclone=true copy from securitygroupid
		if securityGroupID > 0 {
			arrSecurityGroup = append(arrSecurityGroup, securityGroupID)
		}
		if len(arrSecurityGroup) > 0 {
			var (
				permissionModels []models.Permission
			)
			db.Where("SecurityGroupID in (?)", arrSecurityGroup).Find(&permissionModels)
			for _, per := range permissionModels {
				per.PermissionID = 0
				per.SecurityGroupID = newSecurityGroupID
				per.CreatedBy = accountKey
				db.Create(&per)
			}
		}
	} else {
		// if isclone=false copy from administrator group and reset all permission to false
		var securityModels []models.SecurityGroup
		db.Where("IsAdministrator = 1").Find(&securityModels)
		for _, v := range securityModels {
			arrSecurityGroup = append(arrSecurityGroup, v.SecurityGroupID)
		}
		if len(arrSecurityGroup) > 0 {
			var (
				permissionModels            []models.Permission
				defaultNewValueOfPermission = false
			)
			db.Where("SecurityGroupID in (?)", arrSecurityGroup).Find(&permissionModels)
			for _, per := range permissionModels {
				per.PermissionID = 0
				per.SecurityGroupID = newSecurityGroupID
				per.CreatedBy = accountKey
				if per.CanAccess != nil {
					per.CanAccess = &defaultNewValueOfPermission
				}
				if per.CanCreate != nil {
					per.CanCreate = &defaultNewValueOfPermission
				}
				if per.CanDelete != nil {
					per.CanDelete = &defaultNewValueOfPermission
				}
				if per.CanArchive != nil {
					per.CanArchive = &defaultNewValueOfPermission
				}
				if per.CanEdit != nil {
					per.CanEdit = &defaultNewValueOfPermission
				}
				if per.CanExport != nil {
					per.CanExport = &defaultNewValueOfPermission
				}
				if per.CanPrint != nil {
					per.CanPrint = &defaultNewValueOfPermission
				}
				if per.CanView != nil {
					per.CanView = &defaultNewValueOfPermission
				}
				db.Create(&per)
			}
		}
	}
}
