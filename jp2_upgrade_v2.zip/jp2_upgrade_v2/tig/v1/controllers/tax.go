package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetTax godoc
// @Summary Get Tax
// @Description Get Tax
// @Tags Tax
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /tax [get]
func GetTax(c *gin.Context) {
	defer libs.RecoverError(c, "GetTax")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Tax
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"TaxName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	//arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Tax{}.TableName())
	//bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayTaxToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetTaxByID godoc
// @Summary Get Tax By ID
// @Description Get Tax By ID
// @Tags Tax
// @Accept  json
// @Produce  json
// @Param id path int true "Tax ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /tax/{id} [get]
func GetTaxByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetTaxByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Tax
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TaxID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertTaxToResponse(resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateTax godoc
// @Summary Create Tax
// @Description Create Tax
// @Tags Tax
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Tax body []models.TaxResponse true "Create Tax"
// @Success 200 {object} models.APIResponseData
// @Router /tax [post]
func CreateTax(c *gin.Context) {
	apiName := "CreateTax"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Tax
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Tax, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				obj models.Tax
			)
			obj.PassBodyJSONToModel(bp)
			resultCheck := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TaxType = ? AND TaxName = ?", obj.TaxType, obj.TaxName).First(&models.Tax{})
			if resultCheck.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.taxtype_taxname_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				obj.CreatedBy = accountKey
				obj.ModifiedBy = accountKey
				// @TODO validate
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(obj)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					// @TODO need to required > 0 for address, phone
					resultCreate := db.Create(&obj)
					if resultCreate.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultCreate.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, obj)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		objs []models.Tax
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.TaxID)
	}
	if len(arrID) > 0 {
		db.Where("TaxID in (?)", arrID).Find(&objs)
		dataResponses := ConvertArrayTaxToArrayResponse(objs)
		data = dataResponses
	} else {
		data = dataResponse
	}
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateTax godoc
// @Summary Update Tax
// @Description Update Tax
// @Tags Tax
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Tax body []models.TaxResponse true "Update Tax"
// @Success 200 {object} models.APIResponseData
// @Router /tax [put]
func UpdateTax(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateTax")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Tax
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Tax, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.Tax
			)
			putModel.PassBodyJSONToModel(bp)

			resultCheck := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TaxType = ? AND TaxName = ? AND TaxID <> ?", putModel.TaxType, putModel.TaxName, putModel.TaxID).First(&models.Tax{})
			if resultCheck.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.taxtype_taxname_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resultFind := db.Where("TaxID = ?", putModel.TaxID).First(&putModel)
				if resultFind.RowsAffected > 0 {
					putModel.PassBodyJSONToModel(bp)
					putModel.ModifiedBy = accountKey
					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(putModel)
					if err != nil {
						var (
							errValid interface{}
						)
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							errValid = e.Translate(trans)
						}
						errResponse := GetErrorResponseErrorMessage(k, errValid)
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						var (
							itemMsgError string
						)
						resultSave := db.Save(&putModel)
						if resultSave.Error != nil {
							if itemMsgError == "" {
								itemMsgError = resultSave.Error.Error()
							} else {
								itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
							}
						} else {
							totalUpdatedRecord++
							dataResponse = append(dataResponse, putModel)
						}
						if itemMsgError != "" {
							errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				} else {
					errResponse := GetErrorResponseNotFound(lang, k)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Tax
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.TaxID)
	}
	if len(arrID) > 0 {
		db.Where("TaxID in (?)", arrID).Find(&resModels)
		data = ConvertArrayTaxToArrayResponse(resModels)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteTax godoc
// @Summary Delete Tax
// @Description Delete Tax
// @Tags BusinessPartner
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Tax ID"
// @Success 200 {object} models.APIResponseData
// @Router /tax/{id} [delete]
func DeleteTax(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteTax")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.Tax
		)
		resultFind := db.Where("TaxID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := resModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayTaxToArrayResponse func
func ConvertArrayTaxToArrayResponse(items []models.Tax) []models.TaxResponse {
	responses := make([]models.TaxResponse, 0)
	for _, item := range items {
		response := ConvertTaxToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertTaxToResponse func
func ConvertTaxToResponse(item models.Tax) models.TaxResponse {
	var (
		response models.TaxResponse
	)
	response.TaxID = item.TaxID
	response.TaxName = item.TaxName
	response.TaxRate = item.TaxRate
	response.TaxType = item.TaxType
	return response
}
