package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetRescheduleJob godoc
// @Summary Get Reschedule Job
// @Description Get Reschedule Job
// @Tags Reschedule
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getreschedulejob [get]
func GetRescheduleJob(c *gin.Context) {
	defer libs.RecoverError(c, "GetRescheduleJob")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	var schedulesMapping = make([]models.ScheduleMappingResponse, 0)
	sql := `
	SELECT 
	IFNULL(s.JobID,0) AS JobID,
	IFNULL(j.JobNumber,'') AS JobNumber, 
	s.ScheduleStartDate, 
	s.ScheduleEndDate, 
	IFNULL(r.NavigationAddress,'') AS NavigationAddress,
	IFNULL(b.CompanyName,'') AS CompanyName 
	FROM schedules s 
	LEFT JOIN jobs j ON s.JobID = j.JobID 
	LEFT JOIN resources r ON s.ResourceID = r.ResourceID
	LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
	WHERE 
	IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1`
	rows, err := db.Raw(sql).Rows()
	if rows != nil {
		defer rows.Close()
	}
	if err == nil {
		for rows.Next() {
			var scheduleMapping models.ScheduleMappingResponse
			rows.Scan(
				&scheduleMapping.JobID, &scheduleMapping.JobNumber,
				&scheduleMapping.ScheduleStartDate, &scheduleMapping.ScheduleEndDate,
				&scheduleMapping.NavigationAddress, &scheduleMapping.CompanyName,
			)
			schedulesMapping = append(schedulesMapping, scheduleMapping)
		}
		data = schedulesMapping
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = 500
		msg = err.Error()
		data = make([]string, 0)
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
