package controllers

import (
	"encoding/json"
	"errors"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetDraftDynamicForm godoc
// @Summary Get DraftDynamicForm
// @Description Get DraftDynamicForm
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform [get]
func GetDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "GetDraftDynamicForm")
	var (
		status          = libs.GetStatusSuccess()
		resModels       []models.DraftDynamicForm
		requestHeader   models.RequestHeader
		response        models.APIResponseData
		msg             interface{}
		isArchived      = false
		excluded4DPrice = false
		excludedBreak   = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	vExcluded4DPrice, sExcluded4DPrice := libs.GetQueryParam("excluded4dprice", c)
	if sExcluded4DPrice {
		excluded4DPrice, _ = strconv.ParseBool(vExcluded4DPrice)
	}
	vExcludedBreak, sExcludedBreak := libs.GetQueryParam("excludedbreak", c)
	if sExcludedBreak {
		excludedBreak, _ = strconv.ParseBool(vExcludedBreak)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)
	if excluded4DPrice {
		bp = bp.Where("IFNULL(Is4DPriceForm, 0) = 0")
	}
	if excludedBreak {
		bp = bp.Where("IFNULL(IsBreakForm, 0) = 0")
	}
	// Filter

	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"FormName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDraftDynamicFormToArrayResponse(requestHeader, resModels)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetDraftDynamicFormByID godoc
// @Summary Get DraftDynamicForm By ID
// @Description Get DraftDynamicForm  By ID
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param id path int true "DraftDynamicForm ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform/{id} [get]
func GetDraftDynamicFormByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDraftDynamicFormByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DraftDynamicForm
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND DraftDynamicFormID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertDraftDynamicFormToResponse(requestHeader, resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CheckDynamicFormInFlow godoc
// @Summary Check Dynamic Form In Flow By ID
// @Description Check Dynamic Form In Flow By ID
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param id path int true "DraftDynamicForm ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkforminflow/{id} [get]
func CheckDynamicFormInFlow(c *gin.Context) {
	defer libs.RecoverError(c, "CheckDynamicFormInFlow")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DynamicFormFlow
		resFlowModel  models.DraftFormFlow
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
		isUsed        = false
		formFlowID    = 0
		formFlowName  = ""
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND DynamicFormID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		isUsed = true
		formFlowID = resModel.FormFlowID
		resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DraftFormFlowID = ?", formFlowID).First(&resFlowModel)
		if resultRow.RowsAffected > 0 {
			formFlowName = resFlowModel.DraftFormFlowName
		}
	}
	services.GetMessage(lang, "api.success")
	data = map[string]interface{}{"IsUsed": isUsed, "FormFlowID": formFlowID, "FormFlowName": formFlowName}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateDraftDynamicForm godoc
// @Summary Create DraftDynamicForm
// @Description Create DraftDynamicForm
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DraftDynamicForm body []models.DraftDynamicForm true "Create DraftDynamicForm"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform [post]
func CreateDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "CreateDraftDynamicForm")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.DraftDynamicForm
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// validate license
	var (
		isLicense = false
		msgData   string
	)
	companyID := c.Request.Header.Get("companyid")
	licenseType := "form"
	status, msg, isLicense, msgData, _, _ = libs.CheckLicenseFunc(requestHeader, lang, companyID, licenseType)
	if status == 200 {
		if !isLicense {
			status = 422
			msg = msgData
		}
	}
	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
		errors = errorsResponse
	}
	// validate license end

	if status == 200 {
		// Convert json body to object
		var objectsJSON map[string]interface{}
		json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
		var (
			obj models.DraftDynamicForm
		)
		obj.PassBodyJSONToModel(objectsJSON)
		resultFindForm := db.Where("FormName = ? AND IsDeleted = 0", obj.FormName).First(&models.DraftDynamicForm{})
		if resultFindForm.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.formname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			obj.CreatedBy = accountKey
			obj.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(obj)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				obj.Status = 0
				resultCreate := db.Create(&obj)
				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {
					// @TODO create/update to FormUDT
					errUDT := ProcessFormUDTAfterDraftDynamicForm(requestHeader, objectsJSON, lang, accountKey, obj)
					if errUDT != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, errUDT.Error())
						// delete draft
						db.Delete(&obj)
					} else {
						totalUpdatedRecord++
						dataResponse = obj
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
		errors = errorsResponse
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
		var (
			resModels models.DraftDynamicForm
		)
		if len(errorsResponse) == 0 {
			db.Where("DraftDynamicFormID in (?)", dataResponse.DraftDynamicFormID).First(&resModels)
			dataResponses := ConvertDraftDynamicFormToResponse(requestHeader, resModels)
			data = dataResponses
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateDraftDynamicForm godoc
// @Summary Update DraftDynamicForm
// @Description Update DraftDynamicForm
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DraftDynamicForm body []models.DraftDynamicForm true "Create DraftDynamicForm"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform [put]
func UpdateDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateDraftDynamicForm")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.DraftDynamicForm
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	var (
		obj models.DraftDynamicForm
	)
	obj.PassBodyJSONToModel(objectsJSON)

	resultFind := db.Where("DraftDynamicFormID = ?", obj.DraftDynamicFormID).First(&obj)
	if resultFind.RowsAffected > 0 {
		obj.PassBodyJSONToModel(objectsJSON)

		resultFindForm := db.Where("FormName = ? AND IsDeleted = 0 AND DraftDynamicFormID <> ?", obj.FormName, obj.DraftDynamicFormID).First(&models.DraftDynamicForm{})
		if resultFindForm.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.formname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {

			obj.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(obj)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				timeNow := time.Now()
				obj.ModifiedDate = &timeNow
				if obj.LastPublishedDate != nil {
					lastPublishedDate := *obj.LastPublishedDate
					if timeNow.After(lastPublishedDate) {
						obj.Status = 2
					}
				}
				resultSave := db.Save(&obj)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					dataResponse = obj
					// @TODO create/update to FormUDT
					// do not care error of this process
					ProcessFormUDTAfterDraftDynamicForm(requestHeader, objectsJSON, lang, accountKey, obj)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	var (
		resModels models.DraftDynamicForm
	)
	if len(errorsResponse) == 0 {
		db.Where("DraftDynamicFormID in (?)", dataResponse.DraftDynamicFormID).First(&resModels)
		dataResponses := ConvertDraftDynamicFormToResponse(requestHeader, resModels)
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteDraftDynamicForm godoc
// @Summary Delete DraftDynamicForm
// @Description Delete DraftDynamicForm
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "DraftDynamicForm ID"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform/{id} [delete]
func DeleteDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteDraftDynamicForm")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.DraftDynamicForm
		)
		resultFind := db.Where("DraftDynamicFormID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			resultFind := db.Where("DynamicFormID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&models.DynamicFormFlow{})
			if resultFind.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.dynamic_form_use_in_flow")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if CanDeleteDrafDynamicForm(requestHeader, uModel) {
					uModel.IsDeleted = true
					uModel.ModifiedBy = accountKey
					deletedResult := db.Save(&uModel)
					if deletedResult.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						totalUpdatedRecord++

						// Update Form UDT & UDF
						var (
							formUdt models.FormUDT
						)
						resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("DraftDynamicFormID = ?", id).First(&formUdt)
						if resultFind.RowsAffected > 0 {
							if formUdt.IsPublished {
								formUdt.ModifiedBy = accountKey
								formUdt.IsDeleted = true
								resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&formUdt)
								if resultSave.Error == nil {
									db.Where("IFNULL(IsDeleted, 0) <> 1 AND FormUDTID = ?", formUdt.FormUDTID).
										Model(&models.FormUDF{}).
										Updates(models.FormUDF{IsDeleted: true, ModifiedBy: accountKey})
								}
							} else {
								resultSave := db.Delete(&formUdt)
								if resultSave.Error == nil {
									db.Where("IFNULL(IsDeleted, 0) <> 1 AND FormUDTID = ?", formUdt.FormUDTID).
										Delete(&models.FormUDF{})
								}
							}
						}
					}
				} else {
					errResponse := GetErrorResponseValidate(lang, k, "api.confirm_delete_draftdynamicform")
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// PublishDraftDynamicForm godoc
// @Summary PublishDraftDynamicForm
// @Description PublishDraftDynamicForm
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform/publish/{DraftDynamicFormID} [put]
func PublishDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "PublishDraftDynamicForm")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
		draftForm         models.DraftDynamicForm
		dynamicForm       models.DynamicForm
		dynamicFormFlow   models.DynamicFormFlow
		itemMsgError      string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	draftID := c.Param("id")
	timeNow := time.Now()
	resultFindDraftForm := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DraftDynamicFormID = ?", draftID).First(&draftForm)
	if resultFindDraftForm.RowsAffected > 0 {
		if !draftForm.Is4DPriceForm && !draftForm.IsBreakForm {
			// Valid dynamic form in flow
			resultFindDynamicFormFlow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DynamicFormID = ?", draftID).First(&dynamicFormFlow)
			if resultFindDynamicFormFlow.RowsAffected > 0 {
				dynamicForm.ConvertDraftToDynamicFrom(draftForm)
				resultCreate := db.Save(&dynamicForm)
				if resultCreate.Error == nil {
					msg = services.GetMessage(lang, "api.success")
					data = ConvertDynamicFormToResponse(requestHeader, dynamicForm)
					draftForm.LastPublishedDate = &timeNow
					draftForm.Status = 1
					result := db.Save(&draftForm)
					if result.Error == nil {
						var (
							arrDynamicForm []int
						)
						arrDynamicForm = append(arrDynamicForm, draftForm.DraftDynamicFormID)
						UpdateUDTToDatabase(requestHeader, arrDynamicForm, accountKey)
					}
				} else {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				}
			} else {
				status = libs.GetStatusUnprocessableEntity()
				msg = services.GetMessage(lang, "api.dynamic_form_cannot_publish")
			}
		} else {
			dynamicForm.ConvertDraftToDynamicFrom(draftForm)
			resultCreate := db.Save(&dynamicForm)
			if resultCreate.Error == nil {
				msg = services.GetMessage(lang, "api.success")
				data = ConvertDynamicFormToResponse(requestHeader, dynamicForm)
				draftForm.LastPublishedDate = &timeNow
				draftForm.Status = 1
				result := db.Save(&draftForm)
				if result.Error == nil {
					var (
						arrDynamicForm []int
					)
					arrDynamicForm = append(arrDynamicForm, draftForm.DraftDynamicFormID)
					UpdateUDTToDatabase(requestHeader, arrDynamicForm, accountKey)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			}
		}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
	}

	if itemMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// RevertDraftDynamicForm godoc
// @Summary Revert Draft Dynamic Form
// @Description Revert Draft Dynamic Form
// @Tags DraftDynamicForm
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftdynamicform/revert/{DraftDynamicFormID} [put]
func RevertDraftDynamicForm(c *gin.Context) {
	defer libs.RecoverError(c, "RevertDraftDynamicForm")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
		draftForm         models.DraftDynamicForm
		dynamicForm       models.DynamicForm
		itemMsgError      string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	draftID := c.Param("id")
	resultFindDraftForm := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DraftDynamicFormID = ?", draftID).First(&draftForm)
	if resultFindDraftForm.RowsAffected > 0 {
		resultFindDynamicForm := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DynamicFormID = ?", draftID).First(&dynamicForm)
		if resultFindDynamicForm.RowsAffected > 0 {
			draftForm.RevertDraftFromDynamicForm(dynamicForm)
			resultCreate := db.Save(&draftForm)
			if resultCreate.Error == nil {
				msg = services.GetMessage(lang, "api.success")
				data = ConvertDraftDynamicFormToResponse(requestHeader, draftForm)
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			}
		} else {
			msg = services.GetMessage(lang, "api.success")
			data = ConvertDraftDynamicFormToResponse(requestHeader, draftForm)
		}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
	}

	if itemMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayDraftDynamicFormToArrayResponse func
func ConvertArrayDraftDynamicFormToArrayResponse(requestHeader models.RequestHeader, items []models.DraftDynamicForm) []models.DraftDynamicFormResponse {
	responses := make([]models.DraftDynamicFormResponse, 0)
	for _, item := range items {
		response := ConvertDraftDynamicFormToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDraftDynamicFormToResponse func
func ConvertDraftDynamicFormToResponse(requestHeader models.RequestHeader, item models.DraftDynamicForm) models.DraftDynamicFormResponse {
	var (
		response    models.DraftDynamicFormResponse
		udtResModel models.FormUDT
	)
	response.DraftDynamicFormID = item.DraftDynamicFormID
	response.FormName = item.FormName
	response.DesignP = item.DesignP
	response.DesignL = item.DesignL
	response.Is4DPriceForm = item.Is4DPriceForm
	response.IsBreakForm = item.IsBreakForm
	response.LastPublishedDate = item.LastPublishedDate
	response.Status = item.Status
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	// Get UDT
	resultRow := db.Preload(
		"FormUDFs",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND DraftDynamicFormID = ?", item.DraftDynamicFormID).First(&udtResModel)

	if resultRow.RowsAffected > 0 {
		details := make([]models.FormUDFResponse, 0)
		for _, de := range udtResModel.FormUDFs {
			var (
				detail models.FormUDFResponse
			)
			detail.DataField = de.DataField
			detail.DataType = de.DataType
			detail.Length = de.Length
			detail.ControlID = de.ControlID
			details = append(details, detail)
		}
		response.FormUDFs = details
	}
	return response
}

// ConvertArrayDynamicFormToArrayResponse func
func ConvertArrayDynamicFormToArrayResponse(requestHeader models.RequestHeader, items []models.DynamicForm) []models.DynamicFormResponse {
	responses := make([]models.DynamicFormResponse, 0)
	for _, item := range items {
		response := ConvertDynamicFormToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDynamicFormToResponse func
func ConvertDynamicFormToResponse(requestHeader models.RequestHeader, item models.DynamicForm) models.DynamicFormResponse {
	var (
		response models.DynamicFormResponse
	)
	response.DynamicFormID = item.DynamicFormID
	response.FormName = item.FormName
	response.DesignP = item.DesignP
	response.DesignL = item.DesignL
	response.FormStatus = item.FormStatus
	response.Is4DPriceForm = item.Is4DPriceForm
	response.IsBreakForm = item.IsBreakForm
	response.LastPublishedDate = item.LastPublishedDate
	return response
}

// CanDeleteDrafDynamicForm func
func CanDeleteDrafDynamicForm(requestHeader models.RequestHeader, draft models.DraftDynamicForm) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		dynamicFormModel models.DynamicForm
	)
	resultFind := db.Where("DynamicFormID = ? AND IFNULL(IsDeleted, 0) <> 1", draft.DraftDynamicFormID).First(&dynamicFormModel)
	if resultFind.RowsAffected <= 0 {
		return true
	}
	return false
}

// ProcessFormUDTAfterDraftDynamicForm func
func ProcessFormUDTAfterDraftDynamicForm(requestHeader models.RequestHeader, objectsJSON map[string]interface{}, lang string, accountKey int,
	draftDynamicForm models.DraftDynamicForm) error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		errRes         error
		res            interface{}
		formUDTMapData models.FormUDT
		resModel       models.FormUDT
		itemMsgError   string
		hasExistUDT    = false
	)
	db.Where("DraftDynamicFormID = ? AND IFNULL(IsDeleted, 0) <> 1", draftDynamicForm.DraftDynamicFormID).First(&formUDTMapData)
	formUDTMapData.DraftDynamicFormID = draftDynamicForm.DraftDynamicFormID
	formUDTMapData.TableNameObj = draftDynamicForm.FormName
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(formUDTMapData)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", errValid))
	} else {
		_, res = services.ConvertJSONValueToVariable("FormUDFs", objectsJSON)
		if res != nil {
			jsonFormUDF, errFormUDF := json.Marshal(objectsJSON["FormUDFs"])
			if errFormUDF == nil {
				var (
					arrSkipID             []int
					arrToDeleteID         []int
					detailsToDeleteModels []models.FormUDF
					formUDFs              []models.FormUDF
				)
				json.Unmarshal(jsonFormUDF, &formUDFs)
				// @TODO validate for details
				validateMap := make(map[string]interface{})
				for i, detail := range formUDFs {
					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(detail)
					if err != nil {
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
						}
					}

					if _, ok := validateMap[detail.DataField]; ok {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.datafield_exist"))
					} else {
						validateMap[detail.DataField] = true
					}

					// delete details
					var (
						detailModel models.FormUDF
					)
					resultFindDetails := db.Where("ControlID = ? AND FormUDTID = ?", detail.ControlID, formUDTMapData.FormUDTID).First(&detailModel)
					if resultFindDetails.RowsAffected > 0 {
						arrSkipID = append(arrSkipID, detailModel.FormUDFID)
						formUDFs[i].ModifiedBy = accountKey
						formUDFs[i].FormUDFID = detailModel.FormUDFID
					} else {
						formUDFs[i].ModifiedBy = accountKey
						formUDFs[i].CreatedBy = accountKey
					}
				}
				formUDTMapData.FormUDFs = formUDFs
				resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND TableName = ? AND FormUDTID <> ?",
					formUDTMapData.TableNameObj, formUDTMapData.FormUDTID).First(&models.FormUDT{})
				if resultCheckExist.RowsAffected > 0 {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.tablename_exist"))
				}

				if formUDTMapData.FormUDTID > 0 {
					resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND FormUDTID = ?", formUDTMapData.FormUDTID).First(&resModel)
					if resultFind.RowsAffected > 0 {
						hasExistUDT = true
					}
				}
				if len(arrSkipID) > 0 {
					// delete id not in arrSkipID
					db.Where("FormUDTID = ? AND FormUDFID not in (?)", formUDTMapData.FormUDTID, arrSkipID).Find(&detailsToDeleteModels)
				} else {
					// delete all
					db.Where("FormUDTID = ?", formUDTMapData.FormUDTID).Find(&detailsToDeleteModels)
				}
				for _, ad := range detailsToDeleteModels {
					arrToDeleteID = append(arrToDeleteID, ad.FormUDFID)
				}

				if hasExistUDT {
					formUDTMapData.ModifiedBy = accountKey
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&formUDTMapData)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							db.Where("FormUDFID in (?) AND IsPublished = 1", arrToDeleteID).Model(&models.FormUDF{}).
								Updates(models.FormUDF{IsDeleted: true, ModifiedBy: accountKey})
							db.Where("FormUDFID in (?) AND IsPublished = 0", arrToDeleteID).Delete(&models.FormUDF{})
						}
					}
				} else {
					formUDTMapData.CreatedBy = accountKey
					resultCreate := db.Create(&formUDTMapData)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							db.Where("FormUDFID in (?)", arrToDeleteID).Delete(&models.FormUDF{})
						}
					}
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, errFormUDF.Error())
			}
		}

		if itemMsgError != "" {
			errRes = errors.New(itemMsgError)
		}
	}
	return errRes
}
