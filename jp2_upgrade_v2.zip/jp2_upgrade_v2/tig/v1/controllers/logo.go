package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetLogoByID godoc
// @Summary GetLogoByID
// @Description GetLogoByID
// @Tags Logo
// @Accept  json
// @Produce  json
// @Param id path int true "Logo ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /logo/{id} [get]
func GetLogoByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetLogoByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Logo
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("LogoID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertLogoToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateLogo godoc
// @Summary UpdateLogo
// @Description UpdateLogo
// @Tags Logo
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Logo body models.LogoResponse true "Update Logo"
// @Success 200 {object} models.APIResponseData
// @Router /logo/{id} [put]
func UpdateLogo(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateLogo")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.Logo
	)
	resultFind := db.Where("LogoID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.LogoID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var itemMsgError string
			resultSave := db.Save(&resModel)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				totalUpdatedRecord++
				responses := ConvertLogoToResponse(requestHeader, resModel)
				data = responses
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertLogoToResponse func
func ConvertLogoToResponse(requestHeader models.RequestHeader, item models.Logo) models.LogoResponse {
	var (
		response models.LogoResponse
	)
	response.LogoID = item.LogoID
	response.LogoData = item.LogoData
	response.Width = item.Width
	response.Height = item.Height
	response.ResizableArea = item.ResizableArea
	return response
}
