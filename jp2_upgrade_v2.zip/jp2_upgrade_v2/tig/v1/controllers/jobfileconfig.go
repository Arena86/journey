package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetAllJobFileConfig godoc
// @Summary GetAllJobFileConfig
// @Description GetAllJobFileConfig
// @Tags JobFileConfig
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /jobfileconfig [get]
func GetAllJobFileConfig(c *gin.Context) {
	defer libs.RecoverError(c, "GetAllJobFileConfig")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.JobFileConfig
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	resultRow := db.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	responses := ConvertJobFileConfigToResponse(requestHeader, resModel, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	libs.ResponseData(responsesData, c, status)
}

// GetJobFileConfigByID godoc
// @Summary GetJobFileConfigByID
// @Description GetJobFileConfigByID
// @Tags JobFileConfig
// @Accept  json
// @Produce  json
// @Param id path int true "JobFileConfig ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /jobfileconfig/{id} [get]
func GetJobFileConfigByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobFileConfigByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.JobFileConfig
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("JobFileConfigKey = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertJobFileConfigToResponse(requestHeader, resModel, lang)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateJobFileConfig godoc
// @Summary UpdateJobFileConfig
// @Description UpdateJobFileConfig
// @Tags JobFileConfig
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param JobFileConfig body models.JobFileConfigResponse true "UpdateJobFileConfig"
// @Success 200 {object} models.APIResponseData
// @Router /jobfileconfig/{id} [put]
func UpdateJobFileConfig(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJobFileConfig")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.JobFileConfig
	)
	resModel.PassBodyJSONToModel(bp)
	resultFind := db.Where("JobFileConfigKey = ?", resModel.JobFileConfigKey).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		resModel.ModifiedBy = accountKey
		resModel.AccessToken = libs.GenerateToken()
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO need to required > 0 for details
			resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				totalUpdatedRecord++
				// @TODO delete details
				data = ConvertJobFileConfigToResponse(requestHeader, resModel, lang)
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		resModel.PassBodyJSONToModel(bp)
		resModel.JobFileConfigKey = 0
		resModel.CreatedBy = accountKey
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			// @TODO need to required > 0 for details
			resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Create(&resModel)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				totalUpdatedRecord++
				// @TODO delete details
				data = ConvertJobFileConfigToResponse(requestHeader, resModel, lang)
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	if resModel.IsActive {
		// @TODO - Create UDF for job file
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayJobFileConfigToArrayResponse func
func ConvertArrayJobFileConfigToArrayResponse(requestHeader models.RequestHeader, items []models.JobFileConfig, lang string) []models.JobFileConfigResponse {
	responses := make([]models.JobFileConfigResponse, 0)
	for _, item := range items {
		response := ConvertJobFileConfigToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJobFileConfigToResponse func
func ConvertJobFileConfigToResponse(requestHeader models.RequestHeader, item models.JobFileConfig, lang string) models.JobFileConfigResponse {
	var (
		response models.JobFileConfigResponse
	)
	response.JobFileConfigKey = item.JobFileConfigKey
	response.APIURL = item.APIURL
	response.UserName = item.UserName
	response.Password = item.Password
	response.IsActive = item.IsActive
	response.IntervalInSeconds = item.IntervalInSeconds
	return response
}
