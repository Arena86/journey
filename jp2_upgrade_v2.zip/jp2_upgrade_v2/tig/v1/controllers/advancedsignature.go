package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetAdvancedSignatureByJobTask godoc
// @Summary GetAdvancedSignatureByJobTask
// @Description GetAdvancedSignatureByJobTask
// @Tags AdvancedSignature
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getadvancedsignaturebyjobtask/{jobtaskid} [get]
func GetAdvancedSignatureByJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetAdvancedSignatureByJobTask")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.AdvancedSignature
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	jobTaskID := c.Param("jobtaskid")

	arrString := []string{"FormID", "ControlID"}
	db = libs.FilterString(arrString, db, c)
	arrInteger := []string{"ButtonID"}
	db = libs.FilterInteger(arrInteger, db, c)

	// Sort
	resultRow := db.Preload("Images", "TableName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.AdvancedSignature{}.TableName()).Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&resModels)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayAdvancedSignatureToArrayResponse(requestHeader, resModels)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = responses
	libs.APIResponseData(response, c, status)
}

// CreateAdvancedSignature godoc
// @Summary CreateAdvancedSignature
// @Description CreateAdvancedSignature
// @Tags AdvancedSignature
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AdvancedSignature body models.AdvancedSignatureResponse true "Create AdvancedSignature"
// @Success 200 {object} models.APIResponseData
// @Router /advancedsignature [post]
func CreateAdvancedSignature(c *gin.Context) {
	defer libs.RecoverError(c, "CreateAdvancedSignature")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.AdvancedSignature
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate
	resultFind := db.Where("AdvancedSignatureID = ?", resModel.AdvancedSignatureID).First(&resModel)
	resModel.PassBodyJSONToModel(bp)
	resModel.CreatedBy = accountKey
	for i := range resModel.Images {
		resModel.Images[i].CreatedBy = accountKey
		resModel.Images[i].ModifiedBy = accountKey
		resModel.Images[i].TableNameObj = models.AdvancedSignature{}.TableName()
	}
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		// @TODO validate for details
		if itemMsgError == "" {
			var resultCreate *gorm.DB
			if resultFind.RowsAffected > 0 {
				resultCreate = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
			} else {
				resultCreate = db.Create(&resModel)
			}
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				arrSkipID := make([]int, 0)
				for _, img := range resModel.Images {
					arrSkipID = append(arrSkipID, img.PhotoID)
				}
				if len(arrSkipID) > 0 {
					db.Where("TableName = ? AND RecordID = ? AND PhotoID not in (?)", models.AdvancedSignature{}.TableName(), resModel.AdvancedSignatureID, arrSkipID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				} else {
					db.Where("TableName = ? AND RecordID = ?", models.AdvancedSignature{}.TableName(), resModel.AdvancedSignatureID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				}
				data = ConvertAdvancedSignatureToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayAdvancedSignatureToArrayResponse func
func ConvertArrayAdvancedSignatureToArrayResponse(requestHeader models.RequestHeader, items []models.AdvancedSignature) []models.AdvancedSignatureResponse {
	responses := make([]models.AdvancedSignatureResponse, 0)
	for _, item := range items {
		response := ConvertAdvancedSignatureToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertAdvancedSignatureToResponse func
func ConvertAdvancedSignatureToResponse(requestHeader models.RequestHeader, item models.AdvancedSignature) models.AdvancedSignatureResponse {
	var (
		response models.AdvancedSignatureResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.AdvancedSignatureID = item.AdvancedSignatureID
	response.JobID = item.JobID
	response.JobTaskID = item.JobTaskID
	response.FormID = item.FormID
	response.ButtonID = item.ButtonID
	response.ControlID = item.ControlID
	images := make([]models.PhotoResponse, 0)
	for _, img := range item.Images {
		var (
			image       models.PhotoResponse
			reasonModel models.Reason
		)
		image.PhotoID = img.PhotoID
		image.TableNameObj = img.TableNameObj
		image.ImageKey = img.ImageKey
		image.ImageURL = img.ImageURL
		image.ImageSize = img.ImageSize
		image.ETag = img.ETag
		image.ReasonID = img.ReasonID
		resultFindReason := db.Where("ReasonID = ?", img.ReasonID).First(&reasonModel)
		if resultFindReason.RowsAffected > 0 {
			image.Reason = reasonModel.Reason
		}
		image.Comment = img.Comment
		image.PositionX = img.PositionX
		image.PositionY = img.PositionY
		images = append(images, image)
	}
	response.Images = images

	return response
}
