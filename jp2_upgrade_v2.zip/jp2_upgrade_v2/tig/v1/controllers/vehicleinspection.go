package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetVehicleInspection godoc
// @Summary Get VehicleInspection
// @Description Get VehicleInspection
// @Tags VehicleInspection
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspection [get]
func GetVehicleInspection(c *gin.Context) {
	defer libs.RecoverError(c, "GetVehicleInspection")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.VehicleInspection
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("QuestionGroups", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
	})
	bp = bp.Preload("QuestionGroups.Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Question ASC")
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"VehicleInspectionName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayVehicleInspectionToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetVehicleInspectionByID godoc
// @Summary Get VehicleInspection By ID
// @Description Get VehicleInspection By ID
// @Tags VehicleInspection
// @Accept  json
// @Produce  json
// @Param id path int true "VehicleInspection ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspection/{id} [get]
func GetVehicleInspectionByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetVehicleInspectionByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.VehicleInspection
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"QuestionGroups",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"QuestionGroups.Questions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND VehicleInspectionID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertVehicleInspectionToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateVehicleInspection godoc
// @Summary Create VehicleInspection
// @Description Create VehicleInspection
// @Tags VehicleInspection
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleInspection body models.VehicleInspectionResponse true "Create VehicleInspection"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspection [post]
func CreateVehicleInspection(c *gin.Context) {
	// @TODO if post exist vehicleinspectionquestiongroups => override old data
	defer libs.RecoverError(c, "CreateVehicleInspection")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.VehicleInspection
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		itemMsgError = InspectionValidation(requestHeader, lang, resModel, itemMsgError)
		if itemMsgError == "" {
			for i := range resModel.QuestionGroups {
				resModel.QuestionGroups[i].CreatedBy = accountKey
				if len(resModel.QuestionGroups[i].Questions) > 0 {
					for k := range resModel.QuestionGroups[i].Questions {
						resModel.QuestionGroups[i].Questions[k].CreatedBy = accountKey
					}
				}
			}
		}
		// @TODO validate for details
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				data = ConvertVehicleInspectionToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateVehicleInspection godoc
// @Summary Update VehicleInspection
// @Description Update VehicleInspection
// @Tags VehicleInspection
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleInspection body models.VehicleInspectionResponse true "Update VehicleInspection"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspection/{id} [put]
func UpdateVehicleInspection(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateVehicleInspection")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.VehicleInspection
	)
	resultFind := db.Where("VehicleInspectionID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.VehicleInspectionID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			itemMsgError = InspectionValidation(requestHeader, lang, resModel, itemMsgError)
			if itemMsgError == "" {
				timeNow := time.Now()
				for i := range resModel.QuestionGroups {
					if resModel.QuestionGroups[i].CreatedBy <= 0 {
						resModel.QuestionGroups[i].CreatedBy = accountKey
						resModel.QuestionGroups[i].CreatedDate = &timeNow
					}
					resModel.QuestionGroups[i].ModifiedBy = accountKey
					resModel.QuestionGroups[i].ModifiedDate = &timeNow
					if len(resModel.QuestionGroups[i].Questions) > 0 {
						for k := range resModel.QuestionGroups[i].Questions {
							if resModel.QuestionGroups[i].Questions[k].CreatedBy <= 0 {
								resModel.QuestionGroups[i].Questions[k].CreatedBy = accountKey
								resModel.QuestionGroups[i].Questions[k].CreatedDate = &timeNow
							}
							resModel.QuestionGroups[i].Questions[k].ModifiedBy = accountKey
							resModel.QuestionGroups[i].Questions[k].ModifiedDate = &timeNow
						}
					}
				}
			}
			// @TODO validate for details
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					var (
						arrSkipGroupID []string
					)
					for _, questionGroup := range resModel.QuestionGroups {
						var (
							arrSkipQuestionID []int
						)
						if len(questionGroup.Questions) > 0 {
							for _, question := range questionGroup.Questions {
								arrSkipQuestionID = append(arrSkipQuestionID, question.InspectionQuestionID)
							}
						}
						if len(arrSkipQuestionID) > 0 {
							db.Where("InspectionQuestionGroupID = ? AND InspectionQuestionID not in (?)", questionGroup.InspectionQuestionGroupID, arrSkipQuestionID).Model(&models.VehicleInspectionQuestion{}).Updates(models.VehicleInspectionQuestion{IsDeleted: true, ModifiedBy: accountKey})
						} else {
							db.Where("InspectionQuestionGroupID = ?", questionGroup.InspectionQuestionGroupID).Model(&models.VehicleInspectionQuestion{}).Updates(models.VehicleInspectionQuestion{IsDeleted: true, ModifiedBy: accountKey})
						}
						arrSkipGroupID = append(arrSkipGroupID, questionGroup.InspectionQuestionGroupID)
					}
					var (
						deleteGroupModels []models.VehicleInspectionQuestionGroup
						deleteGroupIDs    []string
					)
					if len(arrSkipGroupID) > 0 {
						db.Where("VehicleInspectionID = ? AND InspectionQuestionGroupID not in (?)", resModel.VehicleInspectionID, arrSkipGroupID).Find(&deleteGroupModels)
						// @TODO delete on groups
						db.Where("VehicleInspectionID = ? AND InspectionQuestionGroupID not in (?)", resModel.VehicleInspectionID, arrSkipGroupID).Model(&models.VehicleInspectionQuestionGroup{}).Updates(models.VehicleInspectionQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("VehicleInspectionID = ?", resModel.VehicleInspectionID).Find(&deleteGroupModels)
						// @TODO delete on groups
						db.Where("VehicleInspectionID = ?", resModel.VehicleInspectionID).Model(&models.VehicleInspectionQuestionGroup{}).Updates(models.VehicleInspectionQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})
					}
					// @TODO delete on questions
					for _, g := range deleteGroupModels {
						deleteGroupIDs = append(deleteGroupIDs, g.InspectionQuestionGroupID)
					}
					if len(deleteGroupIDs) > 0 {
						db.Where("InspectionQuestionGroupID in (?)", deleteGroupIDs).Model(&models.VehicleInspectionQuestion{}).Updates(models.VehicleInspectionQuestion{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"QuestionGroups",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Preload(
						"QuestionGroups.Questions",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("IFNULL(IsDeleted, 0) <> 1 AND VehicleInspectionID = ?", id).First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertVehicleInspectionToResponse(requestHeader, resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteVehicleInspection godoc
// @Summary Delete VehicleInspection
// @Description Delete VehicleInspection
// @Tags VehicleInspection
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /vehicleinspection/{id} [delete]
func DeleteVehicleInspection(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteVehicleInspection")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.VehicleInspection
		)
		resultFind := db.Preload(
			"QuestionGroups",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"QuestionGroups.Questions",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("VehicleInspectionID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				for _, questionGroup := range resModel.QuestionGroups {
					db.Where("InspectionQuestionGroupID = ?", questionGroup.InspectionQuestionGroupID).Model(&models.VehicleInspectionQuestion{}).Updates(models.VehicleInspectionQuestion{IsDeleted: true, ModifiedBy: accountKey})
				}
				db.Where("VehicleInspectionID = ?", resModel.VehicleInspectionID).Model(&models.VehicleInspectionQuestionGroup{}).Updates(models.VehicleInspectionQuestionGroup{IsDeleted: true, ModifiedBy: accountKey})

			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayVehicleInspectionToArrayResponse func
func ConvertArrayVehicleInspectionToArrayResponse(requestHeader models.RequestHeader, items []models.VehicleInspection) []models.VehicleInspectionResponse {
	responses := make([]models.VehicleInspectionResponse, 0)
	for _, item := range items {
		response := ConvertVehicleInspectionToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertVehicleInspectionToResponse func
func ConvertVehicleInspectionToResponse(requestHeader models.RequestHeader, item models.VehicleInspection) models.VehicleInspectionResponse {
	var (
		response models.VehicleInspectionResponse
	)
	response.VehicleInspectionID = item.VehicleInspectionID
	response.VehicleInspectionName = item.VehicleInspectionName
	response.IsOdometerVisible = item.IsOdometerVisible
	response.IsOdometerMandatory = item.IsOdometerMandatory
	response.IsRegoVisible = item.IsRegoVisible
	response.IsRegoMandatory = item.IsRegoMandatory
	response.IsCommentVisible = item.IsCommentVisible
	response.IsCommentMandatory = item.IsCommentMandatory

	details := make([]models.VehicleInspectionQuestionGroupResponse, 0)
	questionDetails := make([]models.VehicleInspectionQuestionResponse, 0)
	for _, v := range item.QuestionGroups {
		var detail models.VehicleInspectionQuestionGroupResponse
		detail.InspectionQuestionGroupID = v.InspectionQuestionGroupID
		detail.VehicleInspectionID = v.VehicleInspectionID
		detail.GroupName = v.GroupName
		detail.Sort = v.Sort
		for _, d := range v.Questions {
			var questionDetail models.VehicleInspectionQuestionResponse
			questionDetail.InspectionQuestionID = d.InspectionQuestionID
			questionDetail.InspectionQuestionGroupID = d.InspectionQuestionGroupID
			questionDetail.Question = d.Question
			questionDetail.IsPhotoEnable = d.IsPhotoEnable
			questionDetail.IsMandatory = d.IsMandatory
			questionDetail.RowID = d.InspectionQuestionID
			questionDetails = append(questionDetails, questionDetail)
		}
		details = append(details, detail)
	}
	response.QuestionGroups = details
	response.Questions = questionDetails
	response.VehicleInspectionID = item.VehicleInspectionID

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var historyCount int64
	historyCount = 0
	db.Where("VehicleInspectionID = ?", item.VehicleInspectionID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&[]models.VehicleInspectionHistory{}).Count(&historyCount)
	response.HistoryCount = int(historyCount)
	return response
}

// InspectionValidation func
func InspectionValidation(requestHeader models.RequestHeader, lang string, resModel models.VehicleInspection, itemMsgError string) string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	mappingGroupID := make(map[string]interface{})
	if len(resModel.QuestionGroups) <= 0 {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.vehicleinspection_need_least_one_group"))
	} else {
		for _, group := range resModel.QuestionGroups {
			if group.InspectionQuestionGroupID == "" {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.vehicleinspectionquestiongroupid_required"))
			} else {
				hasQuestion := false
				for _, question := range group.Questions {
					if group.InspectionQuestionGroupID == question.InspectionQuestionGroupID {
						hasQuestion = true
						break
					}
				}
				if !hasQuestion {
					//itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.vehicleinspection_need_least_one_question_for_group", group.InspectionQuestionGroupID))
				} else {
					// find group in db
					resultFindGroupID := db.Where("InspectionQuestionGroupID = ? AND VehicleInspectionID <> ? AND IFNULL(IsDeleted, 0) <> 1", group.InspectionQuestionGroupID, resModel.VehicleInspectionID).First(&models.VehicleInspectionQuestionGroup{})
					if resultFindGroupID.RowsAffected > 0 {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.vehicleinspectionquestiongroupid_exist_db", group.InspectionQuestionGroupID))
					} else {
						// find group in body params
						if _, ok := mappingGroupID[group.InspectionQuestionGroupID]; ok {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.vehicleinspectionquestiongroupid_exist_param", group.InspectionQuestionGroupID))
						} else {
							mappingGroupID[group.InspectionQuestionGroupID] = group.InspectionQuestionGroupID
						}
					}
				}
			}
		}
	}
	return itemMsgError
}
