package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetJobDynamicFormByID godoc
// @Summary GetJobDynamicFormByID
// @Description GetJobDynamicFormByID
// @Tags JobDynamicForm
// @Accept  json
// @Produce  json
// @Param id path int true "JobDynamicForm ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /jobdynamicform/{id} [get]
func GetJobDynamicFormByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobDynamicFormByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.JobDynamicForm
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobDynamicFormID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertJobDynamicFormToResponse(resModel)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertJobDynamicFormToResponse func
func ConvertJobDynamicFormToResponse(item models.JobDynamicForm) models.JobDynamicFormResponse {
	var (
		response models.JobDynamicFormResponse
	)
	response.JobDynamicFormID = item.JobDynamicFormID
	response.DynamicFormID = item.DynamicFormID
	response.FormName = item.FormName
	response.DesignP = item.DesignP
	response.DesignL = item.DesignL
	return response
}
