package controllers

import (
	"encoding/json"
	"fmt"
	redisdynamic "jpapi/tig/v1/databases/drivers/redisdynamic"
	libsredisgps "jpapi/tig/v1/databases/drivers/redisgps"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/aws/aws-sdk-go/service/dynamodb/expression"
	"github.com/gin-gonic/gin"
)

// GetGPS godoc
// @Summary GetGPS
// @Description GetGPS
// @Tags System
// @Accept  json
// @Produce  json
// @Param resourceid query string false "resourceid"
// @Param accountkey query string false "accountkey"
// @Param fromdate query string false "fromdate"
// @Param todate query string false "todate"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getgps [get]
func GetGPS(c *gin.Context) {
	defer libs.RecoverError(c, "GetGPS")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		errorsResponse   []models.ErrorResponse
		msg, data        interface{}
		validateMsgError string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))
		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
		}
		if status == 200 {
			// get dynamic connection
			if fromDate != nil && toDate == nil {
				toDate = &timeNow
			}
			if toDate != nil && fromDate == nil {
				fromDate = &timeNow
			}
			if fromDate != nil && toDate != nil {
				dynamoTable := dynamoConfig.DatabaseNameGPS
				sess, err := session.NewSession(&aws.Config{
					Region: aws.String(dynamoConfig.Region),
					Credentials: credentials.NewStaticCredentials(
						dynamoConfig.AccessKeyID,
						dynamoConfig.SecretAccessKey,
						"",
					),
				})

				if err == nil {
					svc := dynamodb.New(sess)
					hasFilter := false

					expressionNewBuilder := expression.NewBuilder()

					filterDataFormat := "20060102"
					prefixFromNumber := "000000000"
					prefixToNumber := "999999999"

					dFromDate := *fromDate
					sFromDate := dFromDate.Format(filterDataFormat)
					sFromDate = sFromDate + prefixFromNumber
					nFromDate, _ := strconv.Atoi(sFromDate)

					dToDate := *toDate
					sToDate := dToDate.Format(filterDataFormat)
					sToDate = sToDate + prefixToNumber
					nToDate, _ := strconv.Atoi(sToDate)

					filter := expression.And(
						expression.Name("dateTime").GreaterThanEqual(expression.Value(nFromDate)),
						expression.Name("dateTime").LessThanEqual(expression.Value(nToDate)),
					)
					vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
					if sJourneyCode {
						filter = filter.And(expression.Name("journeyCode").Equal(expression.Value(vJourneyCode)))
						hasFilter = true
					}
					vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
					if sAccountKey {
						iAccountKey, _ := strconv.Atoi(vAccountKey)
						filter = filter.And(expression.Name("accountKey").Equal(expression.Value(iAccountKey)))
						hasFilter = true
					}
					vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
					if sResourceID {
						iResourceID, _ := strconv.Atoi(vResourceID)
						filter = filter.And(expression.Name("resourceId").Equal(expression.Value(iResourceID)))
						hasFilter = true
					}
					expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
					hasFilter = true

					var params dynamodb.ScanInput
					if hasFilter {
						expr, err := expressionNewBuilder.Build()
						if err == nil {
							params = dynamodb.ScanInput{
								ExpressionAttributeNames:  expr.Names(),
								ExpressionAttributeValues: expr.Values(),
								FilterExpression:          expr.Filter(),
								ProjectionExpression:      expr.Projection(),
								TableName:                 aws.String(dynamoTable),
							}
						}
					} else {
						params = dynamodb.ScanInput{
							TableName: aws.String(dynamoTable),
						}
					}
					libs.PrintJSON(params)
					result, err := svc.Scan(&params)
					if err == nil {
						var gpsMessagesResponse = make([]models.GPSMessageResponse, 0)
						for _, i := range result.Items {
							var item models.GPSMessage
							errItem := dynamodbattribute.UnmarshalMap(i, &item)
							if errItem == nil {
								gpsMessage := ConvertGPSMessageRedisToJP(item)
								gpsMessagesResponse = append(gpsMessagesResponse, gpsMessage)
							}
						}

						if len(gpsMessagesResponse) > 1 {
							sort.Slice(gpsMessagesResponse, func(i, j int) bool {
								dTimeI := gpsMessagesResponse[i].DateTime
								dTimeJ := gpsMessagesResponse[j].DateTime
								if dTimeI == dTimeJ {
									return gpsMessagesResponse[i].AccountKey < gpsMessagesResponse[j].AccountKey
								}
								// min-max
								return dTimeI.Before(dTimeJ)
								// max-min
								//return dTimeI.After(dTimeJ)
							})
						}
						data = gpsMessagesResponse
					} else {
						status = 500
						validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
					}
				} else {
					status = 500
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
				}
			}
		}
	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetGPS_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetGPS")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		errorsResponse   []models.ErrorResponse
		msg, data        interface{}
		validateMsgError string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))

		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
		}
		var (
			hasFilterJourneyCode = false
			filterJourneyCode    string
		)
		vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
		if sJourneyCode {
			hasFilterJourneyCode = true
			filterJourneyCode = vJourneyCode
		}
		if status == 200 {
			// get dynamic connection
			conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseGPS)
			arrKeys := make([]string, 0)
			arrDateKey := make([]string, 0)
			arrPatternKey := make([]string, 0)
			pattern := "tb|gps*"

			vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
			if sAccountKey {
				pattern = pattern + "|ac|" + vAccountKey + "|*"
			}
			vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
			if sResourceID {
				pattern = pattern + "|rs|" + vResourceID + "|*"
			}

			/* vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
			if sResourceID {
				pattern = pattern + "|rs|" + vResourceID + "|*"
			}
			vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
			if sAccountKey && sResourceID {
				pattern = pattern + "ac|" + vAccountKey + "|*"
			} else if sAccountKey && !sResourceID {
				pattern = pattern + "|ac|" + vAccountKey + "|*"
			} */

			if fromDate != nil && toDate == nil {
				toDate = &timeNow
			}
			if toDate != nil && fromDate == nil {
				fromDate = &timeNow
			}

			if fromDate != nil && toDate != nil {
				dFromDate := *fromDate
				fromDateUnix := dFromDate.Unix()
				dToDate := *toDate
				toDateUnix := dToDate.Unix()
				if fromDateUnix > toDateUnix {
					temp := dFromDate
					dFromDate = dToDate
					dToDate = temp
				}
				dToDate, _ = libs.ConvertStringToDateTime(dToDate.Format("2006-01-02"))
				i := 0
				for {
					newDate := dFromDate.AddDate(0, 0, i)
					newDate, _ = libs.ConvertStringToDateTime(newDate.Format("2006-01-02"))
					if newDate.Unix() > dToDate.Unix() {
						break
					}
					arrDateKey = append(arrDateKey, newDate.Format("20060102"))
					i++
				}
			}
			if len(arrDateKey) > 0 {
				for _, k := range arrDateKey {
					newPatternKey := ``
					if sResourceID {
						newPatternKey = pattern + "dt|" + k + "*"
					} else {
						newPatternKey = pattern + "|dt|" + k + "*"
					}
					arrPatternKey = append(arrPatternKey, newPatternKey)
				}
			} else {
				newPatternKey := pattern
				arrPatternKey = append(arrPatternKey, newPatternKey)
			}

			for _, pattern := range arrPatternKey {
				resRedis := conn.Do(libsredisgps.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrKeys = append(arrKeys, key)
							}
						}
					}
				} else {
					status = 500
					msg = resRedis.Err().Error()
					break
				}
			}

			if status == 200 {
				if len(arrKeys) > 0 {
					var gpsMessagesResponse = make([]models.GPSMessageResponse, 0)
					for _, key := range arrKeys {
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.GPSMessage
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								gpsMessage := ConvertGPSMessageRedisToJP(redisObject)
								// @TODO filter journeyCode
								if hasFilterJourneyCode {
									if gpsMessage.JourneyCode == filterJourneyCode {
										gpsMessagesResponse = append(gpsMessagesResponse, gpsMessage)
									}
								} else {
									gpsMessagesResponse = append(gpsMessagesResponse, gpsMessage)
								}
							}
						} else {
							if statusSub == 500 {
								status = statusSub
								msg = errSub.Error()
								break
							}
						}
					}
					if status == 200 {
						sort.Slice(gpsMessagesResponse, func(i, j int) bool { return gpsMessagesResponse[i].DateTime.Before(gpsMessagesResponse[j].DateTime) })
						data = gpsMessagesResponse
					}
				}
			}
			if status == 200 {
				if msg == nil {
					msg = services.GetMessage(lang, "api.success")
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			if validateMsgError != "" {
				msg = validateMsgError
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetGPS_Backup_DynamoDB
func GetGPS_Backup_DynamoDB(c *gin.Context) {
	defer libs.RecoverError(c, "GetGPS")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	sess, err := session.NewSession(&aws.Config{
		Region: aws.String("ap-southeast-1"),
		Credentials: credentials.NewStaticCredentials(
			"AKIAVFJORX4RQPUAWOFA",
			"XUC3WYZuCPXtM9iiDUzHuqagh+NiR4qGjzFus1BQ",
			"",
		),
	})

	//fmt.Println(err)
	//fmt.Println(sess)

	svc := dynamodb.New(sess)

	// @TODO list tables
	/* input := &dynamodb.ListTablesInput{}
	result1, _ := svc.ListTables(input)
	fmt.Println(result1) */

	// get all items
	//filt := expression.Name("resourceId").Equal(expression.Value(3))
	//filt2 := expression.Name("accountKey").Equal(expression.Value(4))
	//proj := expression.NamesList(expression.Name("key"), expression.Name("accountKey"))
	//expr, err := expression.NewBuilder().WithFilter(filt).WithProjection(proj).Build()
	//expr, err := expression.NewBuilder().WithFilter(filt).WithFilter(filt2).Build()

	/* filter := expression.And(
		expression.Name("resourceId").Equal(expression.Value(3)),
		expression.Name("accountKey").Equal(expression.Value(4)),
	)

	expr, err := expression.NewBuilder().WithFilter(filter).Build() */

	filter := expression.Name("resourceId").Equal(expression.Value(3))
	filter = filter.And(expression.Name("accountKey").Equal(expression.Value(4)))
	filter = filter.And(expression.Name("locationId").Equal(expression.Value(4)))

	expr, err := expression.NewBuilder().WithFilter(filter).Build()

	//proj := expression.NamesList(expression.Name("key"), expression.Name("accountKey"))
	//expr, err := expression.NewBuilder().WithProjection(proj).Build()
	if err != nil {

	}
	// Build the query input parameters
	params := dynamodb.ScanInput{
		ExpressionAttributeNames:  expr.Names(),
		ExpressionAttributeValues: expr.Values(),
		FilterExpression:          expr.Filter(),
		ProjectionExpression:      expr.Projection(),
		TableName:                 aws.String("test_gps"),
	}

	libs.PrintJSON(params)

	var (
		hasFilterJourneyCode = false
		filterJourneyCode    string
	)
	// Make the DynamoDB Query API call
	result, err := svc.Scan(&params)
	//fmt.Println(result)
	var gpsMessagesResponse = make([]models.GPSMessageResponse, 0)
	for _, i := range result.Items {

		var item models.GPSMessage

		err = dynamodbattribute.UnmarshalMap(i, &item)

		if err != nil {
			log.Fatalf("Got error unmarshalling: %s", err)
		}

		// Which ones had a higher rating than minimum?

		gpsMessage := ConvertGPSMessageRedisToJP(item)

		// @TODO filter journeyCode
		if hasFilterJourneyCode {
			if gpsMessage.JourneyCode == filterJourneyCode {
				gpsMessagesResponse = append(gpsMessagesResponse, gpsMessage)
			}
		} else {
			gpsMessagesResponse = append(gpsMessagesResponse, gpsMessage)
		}

		//libs.PrintJSON(gpsMessage)

	}

	data = gpsMessagesResponse

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetGPSSource godoc
// @Summary GetGPS
// @Description GetGPS
// @Tags System
// @Accept  json
// @Produce  json
// @Param resourceid query string false "resourceid"
// @Param accountkey query string false "accountkey"
// @Param fromdate query string false "fromdate"
// @Param todate query string false "todate"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /gpssource [get]
func GetGPSSource(c *gin.Context) {
	defer libs.RecoverError(c, "GetGPS")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		errorsResponse   []models.ErrorResponse
		msg, data        interface{}
		validateMsgError string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, dynamoConfig := libs.GetDynamoConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))

		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
		}
		if status == 200 {
			// get dynamic connection
			if fromDate != nil && toDate == nil {
				toDate = &timeNow
			}
			if toDate != nil && fromDate == nil {
				fromDate = &timeNow
			}
			if fromDate != nil && toDate != nil {
				dynamoTable := dynamoConfig.DatabaseNameGPS
				sess, err := session.NewSession(&aws.Config{
					Region: aws.String(dynamoConfig.Region),
					Credentials: credentials.NewStaticCredentials(
						dynamoConfig.AccessKeyID,
						dynamoConfig.SecretAccessKey,
						"",
					),
				})

				if err == nil {
					svc := dynamodb.New(sess)
					hasFilter := false

					expressionNewBuilder := expression.NewBuilder()

					filterDataFormat := "20060102"
					prefixFromNumber := "000000000"
					prefixToNumber := "999999999"

					dFromDate := *fromDate
					sFromDate := dFromDate.Format(filterDataFormat)
					sFromDate = sFromDate + prefixFromNumber
					nFromDate, _ := strconv.Atoi(sFromDate)

					dToDate := *toDate
					sToDate := dToDate.Format(filterDataFormat)
					sToDate = sToDate + prefixToNumber
					nToDate, _ := strconv.Atoi(sToDate)

					filter := expression.And(
						expression.Name("dateTime").GreaterThanEqual(expression.Value(nFromDate)),
						expression.Name("dateTime").LessThanEqual(expression.Value(nToDate)),
					)
					vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
					if sJourneyCode {
						filter = filter.And(expression.Name("journeyCode").Equal(expression.Value(vJourneyCode)))
						hasFilter = true
					}
					vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
					if sAccountKey {
						iAccountKey, _ := strconv.Atoi(vAccountKey)
						filter = filter.And(expression.Name("accountKey").Equal(expression.Value(iAccountKey)))
						hasFilter = true
					}
					vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
					if sResourceID {
						iResourceID, _ := strconv.Atoi(vResourceID)
						filter = filter.And(expression.Name("resourceId").Equal(expression.Value(iResourceID)))
						hasFilter = true
					}

					vCompanyID, sCompanyID := libs.GetQueryParam("CompanyID", c)
					if sCompanyID {
						filter = filter.And(expression.Name("companyId").Equal(expression.Value(vCompanyID)))
						hasFilter = true
					}

					expressionNewBuilder = expressionNewBuilder.WithFilter(filter)
					hasFilter = true

					var params dynamodb.ScanInput
					if hasFilter {
						expr, err := expressionNewBuilder.Build()
						if err == nil {
							params = dynamodb.ScanInput{
								ExpressionAttributeNames:  expr.Names(),
								ExpressionAttributeValues: expr.Values(),
								FilterExpression:          expr.Filter(),
								ProjectionExpression:      expr.Projection(),
								TableName:                 aws.String(dynamoTable),
							}
						}
					} else {
						params = dynamodb.ScanInput{
							TableName: aws.String(dynamoTable),
						}
					}
					libs.PrintJSON(params)
					result, err := svc.Scan(&params)
					fmt.Println("err: ", err)
					if err == nil {
						var gpsResourcesResponse = make([]models.GPSResourceResponse, 0)
						for _, i := range result.Items {
							var item models.GPSResource
							errItem := dynamodbattribute.UnmarshalMap(i, &item)

							if errItem == nil {
								gpsResource := ConvertGPSResourceRedisToJP(item)
								// @TODO filter companyid
								libs.PrintJSON(gpsResource)
								//if gpsResource.CompanyID == companyID {
								gpsResourcesResponse = append(gpsResourcesResponse, gpsResource)
								//}
							}
						}
						var gpsResourcesGroupResponse = make([]models.GPSResourceResponse, 0)
						var mapResources = make(map[string]models.GPSResourceResponse)
						for _, res := range gpsResourcesResponse {
							// skip ResourceID = 0
							if res.ResourceID > 0 && res.JourneyCode != "" && res.CompanyID != "" {
								resourceKey := strconv.Itoa(res.ResourceID) + ":" + strconv.Itoa(res.AccountKey) + ":" + res.Date + ":" + res.JourneyCode
								_, ok := mapResources[resourceKey]
								if !ok {
									gpsResourcesGroupResponse = append(gpsResourcesGroupResponse, res)
									mapResources[resourceKey] = res
								}
							}
						}
						libs.PrintJSON(gpsResourcesGroupResponse)
						if len(gpsResourcesGroupResponse) > 1 {
							sort.Slice(gpsResourcesGroupResponse, func(i, j int) bool {
								if gpsResourcesGroupResponse[i].Date != "" && gpsResourcesGroupResponse[j].Date != "" {
									timeI := gpsResourcesGroupResponse[i].Date
									timeJ := gpsResourcesGroupResponse[j].Date

									dTimeI, _ := libs.ConvertStringToDateTime(timeI)
									dTimeJ, _ := libs.ConvertStringToDateTime(timeJ)

									if dTimeI == dTimeJ {
										return gpsResourcesGroupResponse[i].AccountKey < gpsResourcesGroupResponse[j].AccountKey
									}
									// min-max
									return dTimeI.Before(dTimeJ)
									// max-min
									//return dTimeI.After(dTimeJ)
								} else if gpsResourcesGroupResponse[i].Date != "" {
									return true
								}
								return false
							})
						}
						data = gpsResourcesGroupResponse
					} else {
						status = 500
						validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
					}
				} else {
					status = 500
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, err.Error())
				}
			}
		}
	} else {
		status = statusRee
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, fmt.Sprintf("%v", msgRee))
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if data == nil {
		data = make([]string, 0)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetGPSSource_Backup_Redis(c *gin.Context) {
	defer libs.RecoverError(c, "GetGPS")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		errorsResponse   []models.ErrorResponse
		msg, data        interface{}
		validateMsgError string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {

		var (
			fromDate, toDate *time.Time
		)
		timeNow, _ := libs.ConvertStringToDateTime(time.Now().Format("2006-01-02"))
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))

		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
		}

		if status == 200 {
			// get dynamic connection
			conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisConfig.RedisDatabaseGPS)
			arrKeys := make([]string, 0)
			arrDateKey := make([]string, 0)
			arrPatternKey := make([]string, 0)
			pattern := "tb|gps*"

			vAccountKey, sAccountKey := libs.GetQueryParam("AccountKey", c)
			if sAccountKey {
				pattern = pattern + "|ac|" + vAccountKey + "|*"
			}
			vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
			if sResourceID {
				pattern = pattern + "|rs|" + vResourceID + "|*"
			}

			if fromDate != nil && toDate == nil {
				toDate = &timeNow
			}
			if toDate != nil && fromDate == nil {
				fromDate = &timeNow
			}

			if fromDate != nil && toDate != nil {
				dFromDate := *fromDate
				fromDateUnix := dFromDate.Unix()
				dToDate := *toDate
				toDateUnix := dToDate.Unix()
				if fromDateUnix > toDateUnix {
					temp := dFromDate
					dFromDate = dToDate
					dToDate = temp
				}
				dToDate, _ = libs.ConvertStringToDateTime(dToDate.Format("2006-01-02"))
				i := 0
				for {
					newDate := dFromDate.AddDate(0, 0, i)
					newDate, _ = libs.ConvertStringToDateTime(newDate.Format("2006-01-02"))
					if newDate.Unix() > dToDate.Unix() {
						break
					}
					arrDateKey = append(arrDateKey, newDate.Format("20060102"))
					i++
				}
			}
			if len(arrDateKey) > 0 {
				for _, k := range arrDateKey {
					newPatternKey := ``
					if sResourceID {
						newPatternKey = pattern + "dt|" + k + "*"
					} else {
						newPatternKey = pattern + "|dt|" + k + "*"
					}
					arrPatternKey = append(arrPatternKey, newPatternKey)
				}
			} else {
				newPatternKey := pattern
				arrPatternKey = append(arrPatternKey, newPatternKey)
			}

			for _, pattern := range arrPatternKey {
				resRedis := conn.Do(libsredisgps.Ctx, "KEYS", pattern)
				if resRedis.Err() == nil {
					keyInterface := resRedis.Val()
					arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
					if sKeysInterface {
						for _, keyInterface := range arrKeysInterface {
							key := fmt.Sprintf("%v", keyInterface)
							key = strings.TrimSpace(key)
							if key != "" {
								arrKeys = append(arrKeys, key)
							}
						}
					}
				} else {
					status = 500
					msg = resRedis.Err().Error()
					break
				}
			}

			if status == 200 {
				if len(arrKeys) > 0 {
					var gpsResourcesResponse = make([]models.GPSResourceResponse, 0)
					for _, key := range arrKeys {
						dataSub, statusSub, errSub := GetRedisDataByKey(conn, key)
						if errSub == nil {
							var redisObject models.GPSResource
							dataJSON, errJSON := json.Marshal(dataSub)
							if errJSON == nil {
								json.Unmarshal(dataJSON, &redisObject)
								gpsResource := ConvertGPSResourceRedisToJP(redisObject)
								// @TODO filter companyid
								if gpsResource.CompanyID == companyID {
									gpsResourcesResponse = append(gpsResourcesResponse, gpsResource)
								}
							}
						} else {
							if statusSub == 500 {
								status = statusSub
								msg = errSub.Error()
								break
							}
						}
					}
					if status == 200 {
						var gpsResourcesGroupResponse = make([]models.GPSResourceResponse, 0)
						var mapResources = make(map[string]models.GPSResourceResponse)

						for _, res := range gpsResourcesResponse {
							// skip ResourceID = 0
							if res.ResourceID > 0 && res.JourneyCode != "" && res.CompanyID != "" {
								resourceKey := strconv.Itoa(res.ResourceID) + ":" + strconv.Itoa(res.AccountKey) + ":" + res.Date + ":" + res.JourneyCode
								_, ok := mapResources[resourceKey]
								if !ok {
									gpsResourcesGroupResponse = append(gpsResourcesGroupResponse, res)
									mapResources[resourceKey] = res
								}
							}
						}

						if len(gpsResourcesGroupResponse) > 1 {
							sort.Slice(gpsResourcesGroupResponse, func(i, j int) bool {
								if gpsResourcesGroupResponse[i].Date != "" && gpsResourcesGroupResponse[j].Date != "" {
									timeI := gpsResourcesGroupResponse[i].Date
									timeJ := gpsResourcesGroupResponse[j].Date

									dTimeI, _ := libs.ConvertStringToDateTime(timeI)
									dTimeJ, _ := libs.ConvertStringToDateTime(timeJ)

									if dTimeI == dTimeJ {
										return gpsResourcesGroupResponse[i].AccountKey < gpsResourcesGroupResponse[j].AccountKey
									}
									// min-max
									return dTimeI.Before(dTimeJ)
									// max-min
									//return dTimeI.After(dTimeJ)
								} else if gpsResourcesGroupResponse[i].Date != "" {
									return true
								}
								return false
							})
						}

						data = gpsResourcesGroupResponse
					}
				}
			}
			if status == 200 {
				if msg == nil {
					msg = services.GetMessage(lang, "api.success")
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			if validateMsgError != "" {
				msg = validateMsgError
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	if data == nil {
		data = make([]string, 0)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertGPSResourceRedisToJP func
func ConvertGPSResourceRedisToJP(redisResource models.GPSResource) models.GPSResourceResponse {
	var resource models.GPSResourceResponse
	resource.ResourceID, _ = strconv.Atoi(redisResource.ResourceID)
	resource.AccountKey, _ = strconv.Atoi(redisResource.AccountKey)
	timeResponse := ConvertRedisStringToDateTime(redisResource.DateTime)
	if timeResponse != nil {
		timeData := *timeResponse
		resource.Date = timeData.Format("2006-01-02")
	}
	resource.JourneyCode = redisResource.JourneyCode
	resource.CompanyID = redisResource.CompanyID
	return resource
}

// ConvertGPSMessageRedisToJP func
func ConvertGPSMessageRedisToJP(redis models.GPSMessage) models.GPSMessageResponse {
	var message models.GPSMessageResponse
	message.AccountKey, _ = strconv.Atoi(redis.AccountKey)
	message.Key = redis.Key
	message.Lat, _ = strconv.ParseFloat(redis.Lat, 64)
	message.Lng, _ = strconv.ParseFloat(redis.Lng, 64)
	message.LocationID, _ = strconv.Atoi(redis.LocationID)
	message.ResourceID, _ = strconv.Atoi(redis.ResourceID)
	message.GpsSignal, _ = strconv.Atoi(redis.GpsSignal)
	message.Street = redis.Street
	message.City = redis.City
	message.SpeedLimit, _ = strconv.Atoi(redis.SpeedLimit)
	message.Speeding, _ = strconv.Atoi(redis.Speeding)
	message.Eta, _ = strconv.Atoi(redis.Eta)
	message.LengthPassed, _ = strconv.Atoi(redis.LengthPassed)
	message.LengthTotal, _ = strconv.Atoi(redis.LengthTotal)
	message.TimeDelay, _ = strconv.Atoi(redis.TimeDelay)
	message.TimeRemaining, _ = strconv.Atoi(redis.TimeRemaining)
	message.Traffic, _ = strconv.Atoi(redis.Traffic)
	message.VehicleSpeed, _ = strconv.Atoi(redis.VehicleSpeed)
	message.Warning, _ = strconv.Atoi(redis.Warning)
	message.DateTime = *ConvertRedisStringToDateTime(redis.DateTime)
	message.JourneyCode = redis.JourneyCode
	message.CompanyID = redis.CompanyID
	return message
}

// ConvertRedisStringToDateTime func
func ConvertRedisStringToDateTime(redisDateTime string) *time.Time {
	var timeResponse *time.Time
	if redisDateTime != "" {
		if len(redisDateTime) >= 17 {
			redisDateTime, errRedisDateTime := time.Parse("20060102150405.000", redisDateTime[0:14]+"."+redisDateTime[len(redisDateTime)-3:])
			if errRedisDateTime == nil {
				timeResponse = &redisDateTime
			}
		} else {
			redisDateTime, errRedisDateTime := time.Parse("20060102150405", redisDateTime)
			if errRedisDateTime == nil {
				timeResponse = &redisDateTime
			}
		}
	}
	return timeResponse
}
