package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetPEDSerie godoc
// @Summary Get PEDSerie
// @Description Get PEDSerie
// @Tags PEDSerie
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /PEDSerie [get]
func GetPEDSerie(c *gin.Context) {
	defer libs.RecoverError(c, "GetPEDSerie")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.PEDSerie
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}

	var bp = db
	if sStart && sLength {
		vStartInt, _ := strconv.Atoi(vStart)
		vLengthInt, _ := strconv.Atoi(vLength)
		bp = bp.Limit(vLengthInt).Offset(vStartInt)
	}
	bp = bp.Preload("SerieDetails", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"Name"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPEDSerieToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPEDSerieByID godoc
// @Summary Get PEDSerie By ID
// @Description Get PEDSerie By ID
// @Tags PEDSerie
// @Accept  json
// @Produce  json
// @Param id path int true "PEDSerie ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /PEDSerie/{id} [get]
func GetPEDSerieByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPEDSerieByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.PEDSerie
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"SerieDetails",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
		},
	).Where("PEDSerieID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertPEDSerieToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePEDSerie godoc
// @Summary Create PEDSerie
// @Description Create PEDSerie
// @Tags PEDSerie
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PEDSerie body models.PEDSerieResponse true "Create PEDSerie"
// @Success 200 {object} models.APIResponseData
// @Router /PEDSerie [post]
func CreatePEDSerie(c *gin.Context) {
	defer libs.RecoverError(c, "CreatePEDSerie")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.PEDSerie
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		for i := range resModel.SerieDetails {
			resModel.SerieDetails[i].CreatedBy = accountKey
		}
		// @TODO validate for details
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				data = ConvertPEDSerieToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePEDSerie godoc
// @Summary Update PEDSerie
// @Description Update PEDSerie
// @Tags PEDSerie
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PEDSerie body models.PEDSerieResponse true "Update PEDSerie"
// @Success 200 {object} models.APIResponseData
// @Router /PEDSerie/{id} [put]
func UpdatePEDSerie(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePEDSerie")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.PEDSerie
	)
	resultFind := db.Preload(
		"SerieDetails",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
		},
	).Where("PEDSerieID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.PEDSerieID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			//timeNow := time.Now()
			for i := range resModel.SerieDetails {
				if resModel.SerieDetails[i].PEDSerieDetailID <= 0 {
					resModel.SerieDetails[i].CreatedBy = accountKey
				}
				resModel.SerieDetails[i].ModifiedBy = accountKey
			}

			// @TODO validate for details
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					arrQuestionSkipID := make([]int, 0)
					for _, v := range resModel.SerieDetails {
						arrQuestionSkipID = append(arrQuestionSkipID, v.PEDSerieDetailID)
					}
					if len(arrQuestionSkipID) > 0 {
						db.Where("PEDSerieID = ? AND PEDSerieDetailID not in (?)", resModel.PEDSerieID, arrQuestionSkipID).Model(&models.PEDSerieDetail{}).Updates(models.PEDSerieDetail{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("PEDSerieID = ?", resModel.PEDSerieID).Model(&models.PEDSerieDetail{}).Updates(models.PEDSerieDetail{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"SerieDetails",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
						},
					).Where("PEDSerieID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertPEDSerieToResponse(requestHeader, resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePEDSerie godoc
// @Summary Delete PEDSerie
// @Description Delete PEDSerie
// @Tags PEDSerie
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "PEDSerie ID"
// @Success 200 {object} models.APIResponseData
// @Router /PEDSerie/{id} [delete]
func DeletePEDSerie(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePEDSerie")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.PEDSerie
		)
		resultFind := db.Preload(
			"SerieDetails",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC")
			},
		).Where("PEDSerieID = ? AND IFNULL(IsDeleted, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				arrDeleteHistoryID := make([]int, 0)
				for _, v := range resModel.SerieDetails {
					arrDeleteHistoryID = append(arrDeleteHistoryID, v.PEDSerieDetailID)
				}
				if len(arrDeleteHistoryID) > 0 {
					db.Where("PEDSerieDetailID in (?)", arrDeleteHistoryID).Model(&models.PEDSerieDetail{}).Updates(models.PEDSerieDetail{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPEDSerieToArrayResponse func
func ConvertArrayPEDSerieToArrayResponse(requestHeader models.RequestHeader, items []models.PEDSerie) []models.PEDSerieResponse {
	responses := make([]models.PEDSerieResponse, 0)
	for _, item := range items {
		response := ConvertPEDSerieToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPEDSerieToResponse func
func ConvertPEDSerieToResponse(requestHeader models.RequestHeader, item models.PEDSerie) models.PEDSerieResponse {
	var (
		response models.PEDSerieResponse
	)
	response.PEDSerieID = item.PEDSerieID
	response.Name = item.Name
	details := make([]models.PEDSerieDetailResponse, 0)
	for _, v := range item.SerieDetails {
		var detail models.PEDSerieDetailResponse
		detail.PEDSerieDetailID = v.PEDSerieDetailID
		detail.PEDSerieID = v.PEDSerieID
		detail.Name = v.Name
		detail.Sort = v.Sort
		detail.ImageKey = v.ImageKey
		detail.ImageURL = v.ImageURL
		detail.ImageSize = v.ImageSize
		detail.ETag = v.ETag
		details = append(details, detail)
	}
	response.SerieDetails = details

	return response
}
