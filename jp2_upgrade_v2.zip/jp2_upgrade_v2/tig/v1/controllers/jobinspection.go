package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
)

const SurchargeParentItemKeySeparator = ";"

var DesktopMode = 2

func CreateInspectionJobFunc(requestHeader models.RequestHeader, lang string, accountKey int,
	job4DPriceModels []models.Job4DPrice, jobNumber string, inspectionJobForSkips []models.InspectionJobForSkip) []models.Job {
	var (
		inspectionJob4DPriceModels    = make([]models.Job4DPrice, 0)
		mapInspectionJob4DPriceModels = make(map[string]models.Job4DPrice)
		jobs                          = make([]models.Job, 0)
	)
	for _, job4DPriceModel := range job4DPriceModels {

		if job4DPriceModel.TriggerInspection {
			createInspection := true
			if job4DPriceModel.TriggerInspectionMode == nil {
				createInspection = true
			} else if *job4DPriceModel.TriggerInspectionMode == DesktopMode {
				createInspection = false
				fmt.Println(createInspection)
			}
			if createInspection {
				inspectionJob4DPriceModels = append(inspectionJob4DPriceModels, job4DPriceModel)
			}
		}
	}
	for _, inspectionJob4DPriceModel := range inspectionJob4DPriceModels {
		keyMap := strconv.Itoa(inspectionJob4DPriceModel.JobID) + "_" + strconv.Itoa(inspectionJob4DPriceModel.JobTaskID)
		_, hasPriceModel := mapInspectionJob4DPriceModels[keyMap]
		if !hasPriceModel {
			mapInspectionJob4DPriceModels[keyMap] = inspectionJob4DPriceModel
		}
	}
	for _, job4DPriceModel := range mapInspectionJob4DPriceModels {
		job := CreateInspectionJob(requestHeader, lang, accountKey, job4DPriceModel, jobNumber, inspectionJobForSkips)
		jobs = append(jobs, job)
	}
	return jobs
}

func CreateInspectionJob(requestHeader models.RequestHeader, lang string, accountKey int,
	job4DPriceModel models.Job4DPrice, jobNumber string, inspectionJobForSkips []models.InspectionJobForSkip) models.Job {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		parentJobModel          models.Job
		newJobModel             models.Job
		jobTypeTemplate         *int
		formFlowID              int
		settingInspectionItemID int
		settingJobTemplateID    int
		newJobTaskType          int
		isNewInspection         = false
	)
	var (
		arrJob4DPriceGroups []models.Job4DPrice
		parentItemKey       string
		arrItemKeys         = make([]string, 0)
	)
	db.Where("4DPriceID = ? AND JobID = ? AND JobTaskID = ?", job4DPriceModel.FourDPriceID, job4DPriceModel.JobID, job4DPriceModel.JobTaskID).
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&arrJob4DPriceGroups)
	for _, arrJob4DPriceGroup := range arrJob4DPriceGroups {
		if !hasCreatedInspectionJobByJob4DPrice(requestHeader, arrJob4DPriceGroup) {
			arrItemKeys = append(arrItemKeys, arrJob4DPriceGroup.Key)
		}
	}
	if len(arrItemKeys) > 0 {
		parentItemKey = strings.Join(arrItemKeys, SurchargeParentItemKeySeparator)
	}
	var (
		settingModel models.Setting
	)
	resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
	if resultFindSetting.RowsAffected > 0 {
		if settingModel.Value != nil {
			var (
				settingValue models.SettingValue
			)
			errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
			if errSettingValue == nil {
				settingInspectionItemID = settingValue.PriceLists.FDPricesInspectionServiceItem
				if settingValue.PriceLists.FDPricesInspectionJobTemplate != nil {
					settingJobTemplateID = *settingValue.PriceLists.FDPricesInspectionJobTemplate
				}
			}
		}
	}
	var jobTaskModel models.JobTask
	resultFindJobTask := db.Where("JobTaskID = ?", job4DPriceModel.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
	if resultFindJobTask.RowsAffected > 0 {
		newJobTaskType = jobTaskModel.JobType
	}
	var settingJobTemplateModel models.JobTemplate
	resultFindSettingJobTemplate := db.Where("JobTemplateID = ?", settingJobTemplateID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingJobTemplateModel)
	if resultFindSettingJobTemplate.RowsAffected > 0 {
		jobTypeTemplate = &settingJobTemplateModel.JobType
		formFlowID = settingJobTemplateModel.FormFlowID
		if jobTypeTemplate != nil {
			djobTypeTemplate := *jobTypeTemplate
			if djobTypeTemplate != models.JobTypePickupDelivery {
				// @TODo create InspectionJob
				parentJobID := job4DPriceModel.JobID
				resultFindParentJob := db.Preload(
					"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Preload(
					"JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where("JobID = ?", parentJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&parentJobModel)
				if resultFindParentJob.RowsAffected > 0 {
					parentJobType := parentJobModel.JobType
					newJobTaskTypeForDetail := GetJobTaskTypeForJobDetail(parentJobType, newJobTaskType)
					if len(inspectionJobForSkips) > 0 {
						for _, deletedJobNumber := range inspectionJobForSkips {
							if newJobTaskTypeForDetail == deletedJobNumber.InspectionJobType {
								jobNumber = deletedJobNumber.JobNumber
							}
						}
					}
					newJobModel = parentJobModel
					newJobModel.JobType = djobTypeTemplate
					newJobModel.IsRecurring = false
					newJobModel.JobID = 0
					newJobModel.RecurringJobID = 0
					newJobModel.IsInspection = true
					newJobModel.IsJob = true
					newJobModel.IsEstimate = false
					newJobModel.EstimateNumber = ""
					newJobModel.InspectionForJobID = parentJobModel.JobID
					newJobModel.SurchargeParentItemKeys = parentItemKey
					if jobNumber == "" {
						isNewInspection = true
						CheckDocumentSequencesBeforeCreate(requestHeader)
						var (
							sequencyModel models.DocumentSequency
							jobNumPrefix  models.Prefix
						)
						ResetDocumentSequencesIfGreaterLength(requestHeader)
						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
						db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
						jobNumberFirstConfig := jobNumPrefix.Prefix
						lenJobNumberConfig := jobNumPrefix.Length
						sqJobNumber := sequencyModel.JobNumber
						newJobModel.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)
					} else {
						newJobModel.JobNumber = jobNumber
					}
					var inspectionItemJobDetails = make([]models.JobDetail, 0)
					var settingInspectionItemModel models.Item
					resultFindSettingInspectionItem := db.Where("ItemID = ?", settingInspectionItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingInspectionItemModel)
					if resultFindSettingInspectionItem.RowsAffected > 0 {
						// @TODO need check
						var inspectionItemJobDetail models.JobDetail
						inspectionItemJobDetail.ItemID = settingInspectionItemModel.ItemID
						inspectionItemJobDetail.Code = settingInspectionItemModel.Code
						inspectionItemJobDetail.Description = settingInspectionItemModel.Description
						inspectionItemJobDetail.UnitPrice = settingInspectionItemModel.UnitPrice
						inspectionItemJobDetail.JobTaskType = &newJobTaskTypeForDetail
						inspectionItemJobDetail.Quantity = 1
						var taxModel models.Tax
						resultFindTax := db.Where("TaxID = ?", settingInspectionItemModel.TaxID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&taxModel)
						if resultFindTax.RowsAffected > 0 {
							inspectionItemJobDetail.TaxType = taxModel.TaxType
							inspectionItemJobDetail.TaxName = taxModel.TaxName
							inspectionItemJobDetail.TaxRate = taxModel.TaxRate
						}
						inspectionItemJobDetail.CreatedBy = accountKey
						inspectionItemJobDetail.ModifiedBy = accountKey
						inspectionItemJobDetails = append(inspectionItemJobDetails, inspectionItemJobDetail)
					}
					newJobModel.JobDetails = inspectionItemJobDetails
					var inspectionItemJobTasks = make([]models.JobTask, 0)
					for i := range parentJobModel.JobTasks {
						if parentJobModel.JobTasks[i].JobType == djobTypeTemplate {
							var inspectionItemJobTask models.JobTask
							inspectionItemJobTask = parentJobModel.JobTasks[i]
							inspectionItemJobTask.JobID = 0
							inspectionItemJobTask.JobTaskID = 0
							inspectionItemJobTask.CreatedBy = accountKey
							inspectionItemJobTask.ModifiedBy = accountKey
							inspectionItemJobTask.FormFlowID = formFlowID
							inspectionItemJobTasks = append(inspectionItemJobTasks, inspectionItemJobTask)
						}
					}
					if len(inspectionItemJobTasks) <= 0 {
						if len(parentJobModel.JobTasks) > 0 {
							var inspectionItemJobTask models.JobTask
							inspectionItemJobTask = parentJobModel.JobTasks[0]
							inspectionItemJobTask.JobID = 0
							inspectionItemJobTask.JobTaskID = 0
							inspectionItemJobTask.JobType = djobTypeTemplate
							inspectionItemJobTask.FormFlowID = formFlowID
							inspectionItemJobTask.CreatedBy = accountKey
							inspectionItemJobTask.ModifiedBy = accountKey
							inspectionItemJobTasks = append(inspectionItemJobTasks, inspectionItemJobTask)
						}
					}
					newJobModel.JobTasks = inspectionItemJobTasks

					if djobTypeTemplate == models.JobTypeOnSite {
						newJobModel.JobOnSite = nil
						var (
							jobOnSite models.JobOnSite
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobOnSite)
							jobOnSite.JobOnSiteID = 0
							jobOnSite.JobID = 0
							jobOnSite.JobTaskID = 0
							jobOnSite.CreatedBy = accountKey
							jobOnSite.ModifiedBy = accountKey
							newJobModel.JobOnSite = &jobOnSite
						}
					} else {
						newJobModel.JobOnSite = nil
					}

					if djobTypeTemplate == models.JobTypePickup {
						newJobModel.JobPickup = nil
						var (
							jobPickup models.JobPickup
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobPickup)
							jobPickup.JobPickupID = 0
							jobPickup.JobID = 0
							jobPickup.JobTaskID = 0
							jobPickup.CreatedBy = accountKey
							jobPickup.ModifiedBy = accountKey
							newJobModel.JobPickup = &jobPickup
						}
					} else {
						newJobModel.JobPickup = nil
					}

					if djobTypeTemplate == models.JobTypeDelivery {
						newJobModel.JobDelivery = nil
						var (
							jobDelivery models.JobDelivery
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobDelivery)
							jobDelivery.JobDeliveryID = 0
							jobDelivery.JobID = 0
							jobDelivery.JobTaskID = 0
							jobDelivery.CreatedBy = accountKey
							jobDelivery.ModifiedBy = accountKey
							newJobModel.JobDelivery = &jobDelivery
						}
					} else {
						newJobModel.JobDelivery = nil
					}

					if djobTypeTemplate == models.JobTypeInStore {
						newJobModel.JobInStore = nil
						var (
							jobInStore models.JobInStore
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobInStore)
							jobInStore.JobInStoreID = 0
							jobInStore.JobID = 0
							jobInStore.JobTaskID = 0
							jobInStore.CreatedBy = accountKey
							jobInStore.ModifiedBy = accountKey
							newJobModel.JobInStore = &jobInStore
						}
					} else {
						newJobModel.JobInStore = nil
					}

					if djobTypeTemplate == models.JobTypeResourcePickUp {
						newJobModel.JobResourcePickUp = nil
						var (
							jobResourcePickUp models.JobResourcePickup
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobResourcePickUp)
							jobResourcePickUp.JobResourcePickupID = 0
							jobResourcePickUp.JobID = 0
							jobResourcePickUp.JobTaskID = 0
							jobResourcePickUp.CreatedBy = accountKey
							jobResourcePickUp.ModifiedBy = accountKey
							newJobModel.JobResourcePickUp = &jobResourcePickUp
						}
					} else {
						newJobModel.JobResourcePickUp = nil
					}

					if djobTypeTemplate == models.JobTypeResourceDelivery {
						newJobModel.JobResourceDelivery = nil
						var (
							jobResourceDelivery models.JobResourceDelivery
						)
						hasCopy, dataRes := CopyDataInSpectionJob(newJobTaskType, parentJobModel)
						if hasCopy {
							json.Unmarshal(dataRes, &jobResourceDelivery)
							jobResourceDelivery.JobResourceDeliveryID = 0
							jobResourceDelivery.JobID = 0
							jobResourceDelivery.JobTaskID = 0
							jobResourceDelivery.CreatedBy = accountKey
							jobResourceDelivery.ModifiedBy = accountKey
							newJobModel.JobResourceDelivery = &jobResourceDelivery
						}
					} else {
						newJobModel.JobResourceDelivery = nil
					}

					if djobTypeTemplate == models.JobTypeCombinedJob {
						newJobModel.JobCombined = nil
					} else {
						newJobModel.JobCombined = nil
					}

					if djobTypeTemplate == models.JobTypeMultipleJob {
						newJobModel.JobMultiple = nil
					} else {
						newJobModel.JobMultiple = nil
					}

					if newJobModel.JobMap != nil {
						newJobModel.JobMap.JobID = 0
						newJobModel.JobMap.JobMapID = 0
						newJobModel.JobMap.CreatedBy = accountKey
						newJobModel.JobMap.ModifiedBy = accountKey
					}
					newJobModel.CreatedBy = accountKey
					newJobModel.ModifiedBy = accountKey
					// Calculate Job Amount
					newJobModel = CalculateJobAmount(newJobModel)
					err := db.Create(&newJobModel).Error
					if err == nil {
						UpdateJobTaskIDToSubJobAfterProcessJob(requestHeader, newJobModel)
						var (
							job          models.Job
							settingModel models.Setting
						)
						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)

						// Update JobPrecomputedRoute
						findJob := db.Preload(
							"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
						).Where("JobID = ?", newJobModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
						if findJob.RowsAffected > 0 {
							responseData, lengthInMeters, travelTimeInSeconds := CalcJobPrecomputeRoute(accountKey, lang, job, settingModel, db)
							newJobModel.TravelTime = float64(travelTimeInSeconds)
							newJobModel.Distance = float64(lengthInMeters)
							jobPrecomputedRouteByte, err := json.Marshal(responseData)
							if err == nil {
								jobPrecomputedRoute := string(jobPrecomputedRouteByte)
								newJobModel.JobPrecomputedRoute = &jobPrecomputedRoute
							}
							newJobModel = CalculatePrice(requestHeader, newJobModel)
							db.Save(&newJobModel)
						}
						if jobNumber == "" {
							IncreaseDocumentSequencesAfterCreateJob(true, false, false, false, requestHeader)
						}
						// Create new notification - Location
						settingValueModel, errSettingValue := GetSettingValue(requestHeader, lang)
						if errSettingValue == nil {
							sendNotificationOptional := settingValueModel.Notifications.IsJobInspectionCreationActive
							reasonID := settingValueModel.Notifications.JobInspectionCreation
							notificationComment := "Auto create inspection job. Job Number - " + newJobModel.JobNumber
							if !isNewInspection {
								notificationComment = "Inspection has been revised. Job Number - " + newJobModel.JobNumber
							}
							SendNotificationWithOptinalFromSetting(requestHeader, lang, accountKey, notificationComment,
								newJobModel.LocationID, reasonID, sendNotificationOptional, false)
						}
					}
				}
			}
		}
	}
	return newJobModel
}

func UpdateInspectionJobFunc(requestHeader models.RequestHeader, lang string, accountKey int, job4DPriceModels []models.Job4DPrice, parentJob models.Job) []models.Job {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		arrJob4DPriceIDSkip                    = make([]int, 0)
		newJob4DPriceModels                    = make([]models.Job4DPrice, 0)
		createdInspectionJobOfJob4DPriceModels = make([]models.Job4DPrice, 0)
		newCreateJob4DPriceModels              = make([]models.Job4DPrice, 0)
		inspectionJobForSkips                  = make([]models.InspectionJobForSkip, 0)
		jobs                                   = make([]models.Job, 0)
	)
	for _, job4DPriceModel := range job4DPriceModels {
		var (
			currentInspectionJobNumber string
			inspectionJobIDJob4DPrice  int
			inspectionJobForType       int
			job4DPrice                 models.Job4DPrice
		)
		resultFindJob4DPrice := db.Where("`Key` = ? AND `4DPriceID` = ? AND JobID = ? AND JobTaskID = ?", job4DPriceModel.Key, job4DPriceModel.FourDPriceID, job4DPriceModel.JobID, job4DPriceModel.JobTaskID).
			Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPrice)
		if resultFindJob4DPrice.RowsAffected > 0 {
			job4DPriceModel.Job4DPriceID = job4DPrice.Job4DPriceID
		}
		if job4DPriceModel.Job4DPriceID <= 0 {
			// create new all
			resultCreate := db.Create(&job4DPriceModel)
			if resultCreate.Error == nil {
				arrJob4DPriceIDSkip = append(arrJob4DPriceIDSkip, job4DPriceModel.Job4DPriceID)
				newJob4DPriceModels = append(newJob4DPriceModels, job4DPriceModel)
			}
		} else {
			var checkJob4DPriceModel models.Job4DPrice
			resultFindJob4DPrice := db.Where("Job4DPriceID = ?", job4DPriceModel.Job4DPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&checkJob4DPriceModel)
			if resultFindJob4DPrice.RowsAffected > 0 {
				arrJob4DPriceIDSkip = append(arrJob4DPriceIDSkip, job4DPriceModel.Job4DPriceID)
				// find inspection job of this parent job
				var (
					inspectionJobModels []models.Job
					hasJobProcess       = false
				)
				inspectionJobIDJob4DPrice = FindInspectionJobIDJob4DPriceIDFuncV2(requestHeader, job4DPriceModel.Job4DPriceID)
				_, currentInspectionJobNumber, inspectionJobForType = FindInspectionJobIDJob4DPriceIDFunc(requestHeader, job4DPriceModel.Job4DPriceID)
				db.Where("JobID = ?", inspectionJobIDJob4DPrice).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&inspectionJobModels)
				for _, inspectionJobModel := range inspectionJobModels {
					if inspectionJobModel.Status > 0 {
						hasJobProcess = true
						break
					}
				}
				if !hasJobProcess {
					if currentInspectionJobNumber != "" {
						var inspectionJobForSkip models.InspectionJobForSkip
						inspectionJobForSkip.JobID = inspectionJobIDJob4DPrice
						inspectionJobForSkip.JobNumber = currentInspectionJobNumber
						inspectionJobForSkip.InspectionJobType = inspectionJobForType
						inspectionJobForSkips = append(inspectionJobForSkips, inspectionJobForSkip)
					}
					DeleteInspectionJobByJob4DPriceIDFunc(requestHeader, job4DPriceModel.Job4DPriceID)
					db.Save(&job4DPriceModel)
					// create new
					newJob4DPriceModels = append(newJob4DPriceModels, job4DPriceModel)
				} else {
					createdInspectionJobOfJob4DPriceModels = append(createdInspectionJobOfJob4DPriceModels, job4DPriceModel)
				}
			} else {
				// not found
			}
		}
	}
	if len(arrJob4DPriceIDSkip) > 0 {
		db.Exec(`DELETE FROM `+models.Job4DPrice{}.TableName()+` WHERE JobID = ? AND Job4DPriceID not in (?)`, parentJob.JobID, arrJob4DPriceIDSkip)
	} else {
		db.Exec(`DELETE FROM `+models.Job4DPrice{}.TableName()+` WHERE JobID = ?`, parentJob.JobID)
	}
	if len(newJob4DPriceModels) > 0 {
		var mapInspectionJob4DPriceModels = make(map[string]models.Job4DPrice)
		for _, newJob4DPriceModel := range newJob4DPriceModels {
			keyMap := strconv.Itoa(newJob4DPriceModel.JobID) + "_" + strconv.Itoa(newJob4DPriceModel.JobTaskID)
			_, hasPriceModel := mapInspectionJob4DPriceModels[keyMap]
			if !hasPriceModel {
				newCreateJob4DPriceModels = append(newCreateJob4DPriceModels, newJob4DPriceModel)
				mapInspectionJob4DPriceModels[keyMap] = newJob4DPriceModel
			}
		}
	}
	if len(newCreateJob4DPriceModels) > 0 {
		jobs = CreateInspectionJobFunc(requestHeader, lang, accountKey, newCreateJob4DPriceModels, "", inspectionJobForSkips)
	}
	return jobs
}

func DeleteInspectionJobByInspectionForJobIDFunc(requestHeader models.RequestHeader, inspectionForJobID int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		jobModels      []models.Job
		arrJobIDDelete = make([]int, 0)
	)
	//db.Where("InspectionForJobID = ?", inspectionForJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
	db.Where("InspectionForJobID = ?", inspectionForJobID).Find(&jobModels)
	for i := range jobModels {
		if !libs.InArrayInteger(jobModels[i].JobID, arrJobIDDelete) {
			arrJobIDDelete = append(arrJobIDDelete, jobModels[i].JobID)
		}
	}
	if len(arrJobIDDelete) > 0 {
		db.Exec(`DELETE FROM `+models.Job{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobDetail{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobTask{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobPickup{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobDelivery{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobOnSite{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobInStore{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobMultiple{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobCombined{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobResourcePickup{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobResourceDelivery{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
		db.Exec(`DELETE FROM `+models.JobSelection{}.TableName()+` WHERE JobID in (?)`, arrJobIDDelete)
	}
}

func DeleteInspectionJobByJob4DPriceIDFunc(requestHeader models.RequestHeader, job4DPriceID int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		inspectionJobIDToDeleted int
	)
	inspectionJobIDToDeleted = FindInspectionJobIDJob4DPriceIDFuncV2(requestHeader, job4DPriceID)
	if inspectionJobIDToDeleted > 0 {
		db.Exec(`DELETE FROM `+models.Job{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobDetail{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobTask{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobPickup{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobDelivery{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobOnSite{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobInStore{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobMultiple{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobCombined{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobResourcePickup{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobResourceDelivery{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
		db.Exec(`DELETE FROM `+models.JobSelection{}.TableName()+` WHERE JobID = ?`, inspectionJobIDToDeleted)
	}
}

func CalculateJobAmount(job models.Job) models.Job {

	var (
		jobSubTotal         float64
		jobTotalTax         float64
		jobTotal            float64
		totalDiscount       float64
		totalBuffer         float64
		travelTimeTaxAmount float64
		distanceTaxAmount   float64
	)
	for k := range job.JobDetails {
		item := job.JobDetails[k]
		item.LineSubTotal = item.UnitPrice * item.Quantity
		item.DiscountAmount = item.LineSubTotal * (item.DiscountPercent / 100)
		item.BufferAmount = item.LineSubTotal * (item.BufferPercent / 100)
		item.LineTotalTaxExcluded = item.LineSubTotal - item.DiscountAmount + item.BufferAmount
		item.LineTotalTax = item.LineTotalTaxExcluded * (item.TaxRate / 100)
		item.LineTotal = item.LineTotalTaxExcluded + item.LineTotalTax
		jobSubTotal += item.LineTotalTaxExcluded
		jobTotalTax += item.LineTotalTax
		totalDiscount += item.DiscountAmount
		totalBuffer += item.BufferAmount
		job.JobDetails[k] = item
	}

	jobTotalTax += travelTimeTaxAmount + distanceTaxAmount
	jobTotal = jobSubTotal + jobTotalTax + job.TravelTimeCharge + job.DistanceCharge

	job.Subtotal = jobSubTotal
	job.TotalTax = jobTotalTax
	job.TotalJob = jobTotal
	job.TotalDiscountAmount = totalDiscount
	job.TotalBufferAmount = totalBuffer

	return job
}

func CalculatePrice(requestHeader models.RequestHeader, job models.Job) models.Job {
	/*{
		"BusinessPartnerID": 1,
		"TravelDistance": 18942,
		"ChargeTravelDistance": true,
		"TravelTime": 3767,
		"ChargeTravelTime": true,
		"Items": [
			{
				"LineNum": 1,
				"ItemID": 1,
				"Description": "Piano Relocation",
				"UnitPrice": 1440,
				"Quantity": 1,
				"TaxRate": 0,
				"DiscountPercent": 0,
				"BufferPercent": 0,
				"ParentItemID": 0,
				"IsUpdated": false,
				"SurchargeParentItemID": null
			}
		]
	}*/
	var (
		pricePOST models.GetPricePOST
		items     []models.GetPriceItem
	)
	pricePOST.BusinessPartnerID = job.BusinessPartnerID
	pricePOST.TravelDistance = job.Distance
	pricePOST.TravelTime = job.TravelTime
	if job.TravelChargeMode != 16 {
		if job.TravelCharge == 1 || job.TravelCharge == 3 {
			pricePOST.ChargeTravelDistance = true
		}
		if job.TravelCharge == 2 || job.TravelCharge == 3 {
			pricePOST.ChargeTravelTime = true
		}
	}
	for _, item := range job.JobDetails {
		var getPriceItem models.GetPriceItem
		getPriceItem.LineNum = item.LineNum
		getPriceItem.ItemID = item.ItemID
		getPriceItem.UnitPrice = item.UnitPrice
		getPriceItem.Quantity = item.Quantity
		getPriceItem.DiscountPercent = item.DiscountPercent
		getPriceItem.BufferPercent = item.BufferPercent
		getPriceItem.ParentItemID = item.ParentItemID
		getPriceItem.SurchargeParentItemID = item.SurchargeParentItemID

	}
	pricePOST.Items = items
	priceResponse := CalculateJobPrice(requestHeader, pricePOST, job)

	for _, priceItem := range priceResponse.Items {
		for i, _ := range job.JobDetails {
			if priceItem.LineNum == job.JobDetails[i].LineNum || priceItem.ItemID == job.JobDetails[i].ItemID {
				job.JobDetails[i].LineNum = priceItem.LineNum
				job.JobDetails[i].ItemID = priceItem.ItemID
				job.JobDetails[i].UnitPrice = priceItem.UnitPrice
				job.JobDetails[i].Quantity = priceItem.Quantity
				job.JobDetails[i].DiscountPercent = priceItem.DiscountPercent
				job.JobDetails[i].BufferPercent = priceItem.BufferPercent
				job.JobDetails[i].ParentItemID = priceItem.ParentItemID
				job.JobDetails[i].SurchargeParentItemID = priceItem.SurchargeParentItemID
			}
		}

	}
	return job
}

func CopyDataInSpectionJob(newJobTaskType int, parentJobModel models.Job) (bool, []byte) {
	var (
		dataRes []byte
		hasCopy = false
	)
	parentJobType := parentJobModel.JobType
	if parentJobType == models.JobTypeOnSite {
		if parentJobModel.JobOnSite != nil {
			parentJobModelObj := *parentJobModel.JobOnSite
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	} else if parentJobType == models.JobTypeInStore {
		if parentJobModel.JobInStore != nil {
			parentJobModelObj := *parentJobModel.JobInStore
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	} else if parentJobType == models.JobTypePickup {
		if parentJobModel.JobPickup != nil {
			parentJobModelObj := *parentJobModel.JobPickup
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	} else if parentJobType == models.JobTypeDelivery {
		if parentJobModel.JobDelivery != nil {
			parentJobModelObj := *parentJobModel.JobDelivery
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	} else if parentJobType == models.JobTypePickupDelivery {
		if newJobTaskType == models.JobTypePickup {
			if parentJobModel.JobPickup != nil {
				parentJobModelObj := *parentJobModel.JobPickup
				parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
				if errParentJobJSON == nil {
					dataRes = parentJobJSON
					hasCopy = true
				}
			}
		} else if newJobTaskType == models.JobTypeDelivery {
			if parentJobModel.JobDelivery != nil {
				parentJobModelObj := *parentJobModel.JobDelivery
				parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
				if errParentJobJSON == nil {
					dataRes = parentJobJSON
					hasCopy = true
				}
			}
		}
	} else if parentJobType == models.JobTypeResourcePickUp {
		if parentJobModel.JobResourcePickUp != nil {
			parentJobModelObj := *parentJobModel.JobResourcePickUp
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	} else if parentJobType == models.JobTypeResourceDelivery {
		if parentJobModel.JobResourceDelivery != nil {
			parentJobModelObj := *parentJobModel.JobResourceDelivery
			parentJobJSON, errParentJobJSON := json.Marshal(parentJobModelObj)
			if errParentJobJSON == nil {
				dataRes = parentJobJSON
				hasCopy = true
			}
		}
	}
	return hasCopy, dataRes
}

func GetJobTaskTypeForJobDetail(parentJobType int, newJobTaskType int) int {
	var jobTaskType int
	if parentJobType == models.JobTypePickupDelivery {
		if newJobTaskType == models.JobTypePickup {
			jobTaskType = newJobTaskType
		} else if newJobTaskType == models.JobTypeDelivery {
			jobTaskType = newJobTaskType
		} else {
			jobTaskType = parentJobType
		}
	} else {
		jobTaskType = parentJobType
	}
	return jobTaskType
}

func FindInspectionJobIDJob4DPriceIDFunc(requestHeader models.RequestHeader, job4DPriceID int) (int, string, int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		jobModels                    []models.Job
		inspectionJobIDToDeleted     int
		inspectionJobNumberToDeleted string
		jobTaskType                  int
	)
	var job4DPriceModel models.Job4DPrice
	resultFindJob4DPrice := db.Where("Job4DPriceID = ?", job4DPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPriceModel)
	if resultFindJob4DPrice.RowsAffected > 0 {
		var (
			parentJobModel models.Job
			jobTaskModel   models.JobTask
			newJobTaskType int
			parentJobType  int
			itemIDOnDetail int
		)
		parentJobID := job4DPriceModel.JobID
		var (
			settingModel            models.Setting
			settingInspectionItemID int
		)
		resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
		if resultFindSetting.RowsAffected > 0 {
			if settingModel.Value != nil {
				var (
					settingValue models.SettingValue
				)
				errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
				if errSettingValue == nil {
					settingInspectionItemID = settingValue.PriceLists.FDPricesInspectionServiceItem
				}
			}
		}
		var settingInspectionItemModel models.Item
		resultFindSettingInspectionItem := db.Where("ItemID = ?", settingInspectionItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingInspectionItemModel)
		if resultFindSettingInspectionItem.RowsAffected > 0 {
			itemIDOnDetail = settingInspectionItemModel.ItemID
		}
		resultFindParentJob := db.Where("JobID = ?", parentJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&parentJobModel)
		if resultFindParentJob.RowsAffected > 0 {
			parentJobType = parentJobModel.JobType
		}
		resultFindJobTask := db.Where("JobTaskID = ?", job4DPriceModel.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
		if resultFindJobTask.RowsAffected > 0 {
			newJobTaskType = jobTaskModel.JobType
		}
		db.Where("InspectionForJobID = ?", parentJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
		for _, jobModel := range jobModels {
			var jobDetailModel models.JobDetail
			jobDetailJobTaskType := GetJobTaskTypeForJobDetail(parentJobType, newJobTaskType)
			jobTaskType = jobDetailJobTaskType
			resultFindJobDetail := db.Where("JobID = ? AND ItemID = ? AND JobTaskType = ?", jobModel.JobID, itemIDOnDetail, jobDetailJobTaskType).
				Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobDetailModel)
			if resultFindJobDetail.RowsAffected > 0 {
				inspectionJobIDToDeleted = jobModel.JobID
				inspectionJobNumberToDeleted = jobModel.JobNumber
				break
			}
		}
	}
	return inspectionJobIDToDeleted, inspectionJobNumberToDeleted, jobTaskType
}

func FindInspectionJobIDJob4DPriceIDFuncV2(requestHeader models.RequestHeader, job4DPriceID int) int {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		inspectionJobID int
	)
	var job4DPriceModel models.Job4DPrice
	resultFindJob4DPrice := db.Where("Job4DPriceID = ?", job4DPriceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job4DPriceModel)
	if resultFindJob4DPrice.RowsAffected > 0 {
		var (
			jobModels []models.Job
		)
		var bp = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		bp.Where("InspectionForJobID = ?", job4DPriceModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
		for _, jobModel := range jobModels {
			var (
				arrInspectionJobItemKeys = make([]string, 0)
			)
			inspectionJobItemKey := jobModel.SurchargeParentItemKeys
			if inspectionJobItemKey != "" {
				arrInspectionJobItemKeys = strings.Split(inspectionJobItemKey, SurchargeParentItemKeySeparator)
				if len(arrInspectionJobItemKeys) > 0 {
					var jobTaskModel models.JobTask
					resultFindJobTask := db.Where("JobTaskID = ? AND JobType = ?", job4DPriceModel.JobTaskID, jobModel.JobDetails[0].JobTaskType).
						Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
					if resultFindJobTask.RowsAffected > 0 {
						for i := range arrInspectionJobItemKeys {
							if arrInspectionJobItemKeys[i] == job4DPriceModel.Key {
								return jobModel.JobID
							}
						}
					}
				}
			}
		}
	}
	return inspectionJobID
}

func AutoGenerateNewJobByJobEstimate(requestHeader models.RequestHeader, lang string, accountKey int, rootJobID int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		parentJobModel models.Job
		newJobModel    models.Job
	)
	resultFindParentJob := db.Preload(
		"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("JobID = ?", rootJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&parentJobModel)
	if resultFindParentJob.RowsAffected > 0 {

		newJobModel = parentJobModel
		newJobModel.IsEstimate = false
		newJobModel.EstimateNumber = ""
		newJobModel.IsJob = true
		//newJobModel.JobType =
		newJobModel.IsRecurring = false
		newJobModel.JobID = 0
		newJobModel.RecurringJobID = 0
		//newJobModel.IsInspection = true
		//newJobModel.InspectionForJobID = parentJobModel.JobID

		CheckDocumentSequencesBeforeCreate(requestHeader)
		var (
			sequencyModel models.DocumentSequency
			jobNumPrefix  models.Prefix
		)
		ResetDocumentSequencesIfGreaterLength(requestHeader)
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
		db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
		jobNumberFirstConfig := jobNumPrefix.Prefix
		lenJobNumberConfig := jobNumPrefix.Length
		sqJobNumber := sequencyModel.JobNumber
		newJobModel.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)

		for i := range newJobModel.JobDetails {
			newJobModel.JobDetails[i].JobDetailID = 0
			newJobModel.JobDetails[i].JobID = 0
			newJobModel.JobDetails[i].CreatedBy = accountKey
			newJobModel.JobDetails[i].ModifiedBy = accountKey
		}

		for i := range newJobModel.JobTasks {
			newJobModel.JobTasks[i].JobTaskID = 0
			newJobModel.JobTasks[i].JobID = 0
			newJobModel.JobTasks[i].CreatedBy = accountKey
			newJobModel.JobTasks[i].ModifiedBy = accountKey
		}

		newJobModel.JobOnSite = nil
		newJobModel.JobPickup = nil
		newJobModel.JobDelivery = nil
		newJobModel.JobInStore = nil
		newJobModel.JobResourcePickUp = nil
		newJobModel.JobResourceDelivery = nil
		newJobModel.JobCombined = nil
		newJobModel.JobMultiple = nil

		if newJobModel.JobMap != nil {
			newJobModel.JobMap.JobID = 0
			newJobModel.JobMap.JobMapID = 0
			newJobModel.JobMap.CreatedBy = accountKey
			newJobModel.JobMap.ModifiedBy = accountKey
		}
		newJobModel.CreatedBy = accountKey
		newJobModel.ModifiedBy = accountKey
		// Calculate Job Amount
		err := db.Create(&newJobModel).Error
		if err == nil {
			IncreaseDocumentSequencesAfterCreateJob(true, false, false, false, requestHeader)
		}
	}
}

func hasCreatedInspectionJobByJob4DPrice(requestHeader models.RequestHeader, job4DPriceModel models.Job4DPrice) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		jobModels []models.Job
	)
	var bp = db.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp.Where("InspectionForJobID = ?", job4DPriceModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
	for _, jobModel := range jobModels {
		var (
			arrInspectionJobItemKeys = make([]string, 0)
		)
		inspectionJobItemKey := jobModel.SurchargeParentItemKeys
		if inspectionJobItemKey != "" {
			arrInspectionJobItemKeys = strings.Split(inspectionJobItemKey, SurchargeParentItemKeySeparator)
			if len(arrInspectionJobItemKeys) > 0 {
				var jobTaskModel models.JobTask
				resultFindJobTask := db.Where("JobTaskID = ? AND JobType = ?", job4DPriceModel.JobTaskID, jobModel.JobDetails[0].JobTaskType).
					Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
				if resultFindJobTask.RowsAffected > 0 {
					for i := range arrInspectionJobItemKeys {
						if arrInspectionJobItemKeys[i] == job4DPriceModel.Key {
							return true
						}
					}
				}
			}
		}
	}
	return false
}

func SendNotificationWithOptinalFromSetting(requestHeader models.RequestHeader, lang string, accountKey int,
	comment string, locationID int, reasonID int, sendNotificationOptional bool, onlyManager bool) {
	// @TODO currently, do not have setting
	// get option from setting to send/not send
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if sendNotificationOptional {
		var (
			notiModel models.Notification
		)
		notiModel.Comment = comment
		notiModel.NotificationType = 1
		notiModel.Group = 2
		notiModel.ReasonID = reasonID // get from setting, if not send id = 0
		notiModel.CreatedBy = accountKey
		notiModel.ModifiedBy = accountKey
		resultCreate := db.Create(&notiModel)
		if resultCreate.Error == nil {
			// insert to notificationusers
			arrUserID := make([]int, 0)
			var (
				users []models.User
			)
			if onlyManager {
				db.Where("LocationID = ? AND IFNULL(IsManager, 0) = 1", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&users)
			} else {
				db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&users)
			}
			for _, u := range users {
				arrUserID = append(arrUserID, u.AccountKey)
			}
			if len(arrUserID) > 0 {
				for _, userID := range arrUserID {
					var notificationUser models.NotificationUser
					notificationUser.NotificationID = notiModel.NotificationID
					notificationUser.AccountKey = userID
					notificationUser.Status = 0
					notificationUser.ReadStatus = false
					notificationUser.CreatedBy = accountKey
					notificationUser.ModifiedBy = accountKey
					db.Create(&notificationUser)
				}
			}
		}
	}
}
