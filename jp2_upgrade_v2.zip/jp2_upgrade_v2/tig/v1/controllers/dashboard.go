package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strings"

	"github.com/gin-gonic/gin"
)

// GetDashboardByID godoc
// @Summary GetDashboardByID
// @Description GetDashboardByID
// @Tags Dashboard
// @Accept  json
// @Produce  json
// @Param id path int true "Dashboard ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /dashboard/{id} [get]
func GetDashboardByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDashboardByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Dashboard
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		arrayQueryMap = make([]map[string]interface{}, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("DashboardID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		sqlQuery := resModel.QueryString
		vFromDate, sFromDate := libs.GetQueryParam("fromdate", c)
		if sFromDate {
			_, sFromDateDateTime := services.ConvertStringToDateTime(vFromDate)
			if sFromDateDateTime == nil {
				sqlQuery = strings.Replace(sqlQuery, "%%fromdate%%", vFromDate, -1)
			}
		}
		vToDate, sToDate := libs.GetQueryParam("todate", c)
		if sToDate {
			_, sToDateDateTime := services.ConvertStringToDateTime(vToDate)
			if sToDateDateTime == nil {
				sqlQuery = strings.Replace(sqlQuery, "%%todate%%", vToDate, -1)
			}
		}
		vLocationID, sLocationID := libs.GetQueryParam("locationid", c)
		if sLocationID {
			sqlQuery = strings.Replace(sqlQuery, "%%locationid%%", vLocationID, -1)
		}
		vLocationGroupID, sLocationGroupID := libs.GetQueryParam("locationgroupid", c)
		if sLocationGroupID {
			sqlQuery = strings.Replace(sqlQuery, "%%locationgroupid%%", vLocationGroupID, -1)
		}
		rows, errQuery := db.Raw(sqlQuery).Rows()
		if errQuery == nil {
			defer rows.Close()
			mapColumsType := make(map[string]string)
			cols, _ := rows.Columns()
			colsType, _ := rows.ColumnTypes()
			for _, ty := range colsType {
				if ty != nil {
					sqlColumType := *ty
					mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
				}
			}
			for rows.Next() {
				data := make(map[string]interface{})
				columns := make([]*string, len(cols))
				columnPointers := make([]interface{}, len(cols))
				for i := range columns {
					columnPointers[i] = &columns[i]
				}
				rows.Scan(columnPointers...)
				for i, colName := range cols {
					if !libs.RemoveDefaultFieldsOnDynamicGenerateTable(colName) {
						vColumName, sColumName := mapColumsType[colName]
						if sColumName && columns[i] != nil {
							data[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
						} else {
							data[colName] = columns[i]
						}
					}
				}
				arrayQueryMap = append(arrayQueryMap, data)
			}
		} else {
			status = 500
			msg = errQuery.Error()
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "api.dashboardid_not_found")
	}
	if status == 200 && msg == nil {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	data = arrayQueryMap
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
