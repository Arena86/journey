package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetFormCheckListHistory godoc
// @Summary Get FormCheckListHistory
// @Description Get FormCheckListHistory
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param FormCheckListID query integer false "FormCheckListID"
// @Param FormCheckListDateFrom query string false "FormCheckListDateFrom - yyyy-mm-dd"
// @Param FormCheckListDateTo query string false "FormCheckListDateTo - yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistory [get]
func GetFormCheckListHistory(c *gin.Context) {
	defer libs.RecoverError(c, "FormCheckListHistory")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormCheckListHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
	})
	bp = bp.Preload("Questions.Photos", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"FormCheckListID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{"FormCheckListDate"}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayFormCheckListHistoryToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetFormCheckListHistoryByJobTask godoc
// @Summary Get FormCheckListHistory
// @Description Get FormCheckListHistory
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param FormCheckListID query integer false "FormCheckListID"
// @Param FormCheckListDateFrom query string false "FormCheckListDateFrom - yyyy-mm-dd"
// @Param FormCheckListDateTo query string false "FormCheckListDateTo - yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistorybyjobtask/{jobtaskid} [get]
func GetFormCheckListHistoryByJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormCheckListHistoryByJobTask")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormCheckListHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	jobTaskID := c.Param("jobtaskid")

	arrString := []string{"FormID", "ControlID"}
	db = libs.FilterString(arrString, db, c)
	arrInteger := []string{"ButtonID"}
	db = libs.FilterInteger(arrInteger, db, c)
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
	})
	bp = bp.Preload("Questions.Photos", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("JobTaskID = ?", jobTaskID)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayFormCheckListHistoryToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetFormCheckListHistoryByID godoc
// @Summary Get FormCheckListHistory By ID
// @Description Get FormCheckListHistory By ID
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param id path int true "FormCheckListHistory ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistory/{id} [get]
func GetFormCheckListHistoryByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormCheckListHistoryByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.FormCheckListHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Preload(
		"Questions.Photos",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
		},
	).Where("FormCheckListHistoryID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertFormCheckListHistoryToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateFormCheckListHistory godoc
// @Summary Create FormCheckListHistory
// @Description Create FormCheckListHistory
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormCheckListHistory body models.FormCheckListHistoryResponse true "Create FormCheckListHistory"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistory [post]
func CreateFormCheckListHistory(c *gin.Context) {
	defer libs.RecoverError(c, "CreateFormCheckListHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.FormCheckListHistory
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		for i := range resModel.Questions {
			resModel.Questions[i].CreatedBy = accountKey
			if len(resModel.Questions[i].Photos) > 0 {
				for k := range resModel.Questions[i].Photos {
					resModel.Questions[i].Photos[k].CreatedBy = accountKey
					resModel.Questions[i].Photos[k].TableNameObj = models.FormCheckListHistory{}.TableName()
				}
			}
		}
		// @TODO validate for details
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				resultRow := db.Preload(
					"Questions",
					func(db *gorm.DB) *gorm.DB {
						return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
					},
				).Preload(
					"Questions.Photos",
					func(db *gorm.DB) *gorm.DB {
						return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
					},
				).Where("FormCheckListHistoryID = ?", resModel.FormCheckListHistoryID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
				if resultRow.RowsAffected > 0 {
					responses := ConvertFormCheckListHistoryToResponse(requestHeader, resModel)
					data = responses
				} else {
					errResponse := GetErrorResponseNotFound(lang, 0)
					errorsResponse = append(errorsResponse, errResponse)
				}
				//data = ConvertFormCheckListHistoryToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateFormCheckListHistory godoc
// @Summary Update FormCheckListHistory
// @Description Update FormCheckListHistory
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormCheckListHistory body models.FormCheckListHistoryResponse true "Update FormCheckListHistory"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistory/{id} [put]
func UpdateFormCheckListHistory(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateFormCheckListHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel              models.FormCheckListHistory
		arrPhotoIDBeforUpdate = make([]int, 0)
	)
	resultFind := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Preload(
		"Questions.Photos",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
		},
	).Where("FormCheckListHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		for _, v := range resModel.Questions {
			for _, d := range v.Photos {
				arrPhotoIDBeforUpdate = append(arrPhotoIDBeforUpdate, d.PhotoID)
			}
		}

		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.FormCheckListHistoryID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			//timeNow := time.Now()
			for i := range resModel.Questions {
				resModel.Questions[i].ModifiedBy = accountKey
				for j := range resModel.Questions[i].Photos {
					if resModel.Questions[i].Photos[j].PhotoID <= 0 {
						resModel.Questions[i].Photos[j].CreatedBy = accountKey
					}
					resModel.Questions[i].Photos[j].ModifiedBy = accountKey
					resModel.Questions[i].Photos[j].TableNameObj = models.FormCheckListHistory{}.TableName()
				}
			}

			// @TODO validate for details
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					arrQuestionSkipID := make([]int, 0)
					arrPhotoIDAfterUpdate := make([]int, 0)
					for _, v := range resModel.Questions {
						arrQuestionSkipID = append(arrQuestionSkipID, v.FormCheckListQuestionHistoryID)
						for _, d := range v.Photos {
							arrPhotoIDAfterUpdate = append(arrPhotoIDAfterUpdate, d.PhotoID)
						}
					}
					if len(arrQuestionSkipID) > 0 {
						db.Where("FormCheckListHistoryID = ? AND FormCheckListQuestionHistoryID not in (?)", resModel.FormCheckListHistoryID, arrQuestionSkipID).Model(&models.FormCheckListQuestionHistory{}).Updates(models.FormCheckListQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("FormCheckListHistoryID = ?", resModel.FormCheckListHistoryID).Model(&models.FormCheckListQuestionHistory{}).Updates(models.FormCheckListQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					}
					// find photoid to delete
					arrPhotoIDToDelete := make([]int, 0)
					for _, i := range arrPhotoIDBeforUpdate {
						hasPhotoID := false
						for _, j := range arrPhotoIDAfterUpdate {
							if i == j {
								hasPhotoID = true
								break
							}
						}
						if !hasPhotoID {
							arrPhotoIDToDelete = append(arrPhotoIDToDelete, i)
						}
					}
					if len(arrPhotoIDToDelete) > 0 {
						db.Where("PhotoID in (?)", arrPhotoIDToDelete).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"Questions",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
						},
					).Preload(
						"Questions.Photos",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
						},
					).Where("FormCheckListHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertFormCheckListHistoryToResponse(requestHeader, resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteFormCheckListHistory godoc
// @Summary Delete FormCheckListHistory
// @Description Delete FormCheckListHistory
// @Tags FormCheckListHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /formchecklisthistory/{id} [delete]
func DeleteFormCheckListHistory(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteFormCheckListHistory")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.FormCheckListHistory
		)
		resultFind := db.Preload(
			"Questions",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
			},
		).Preload(
			"Questions.Photos",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("TableName = ?", models.FormCheckListHistory{}.TableName())
			},
		).Where("FormCheckListHistoryID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				arrDeleteHistoryID := make([]int, 0)
				arrDeletePhotoID := make([]int, 0)
				for _, v := range resModel.Questions {
					arrDeleteHistoryID = append(arrDeleteHistoryID, v.FormCheckListQuestionHistoryID)
					for _, p := range v.Photos {
						arrDeletePhotoID = append(arrDeletePhotoID, p.PhotoID)
					}
				}
				if len(arrDeleteHistoryID) > 0 {
					db.Where("FormCheckListQuestionHistoryID in (?)", arrDeleteHistoryID).Model(&models.FormCheckListQuestionHistory{}).Updates(models.FormCheckListQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
				}
				if len(arrDeletePhotoID) > 0 {
					db.Where("PhotoID in (?)", arrDeletePhotoID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayFormCheckListHistoryToArrayResponse func
func ConvertArrayFormCheckListHistoryToArrayResponse(requestHeader models.RequestHeader, items []models.FormCheckListHistory) []models.FormCheckListHistoryResponse {
	responses := make([]models.FormCheckListHistoryResponse, 0)
	for _, item := range items {
		response := ConvertFormCheckListHistoryToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertFormCheckListHistoryToResponse func
func ConvertFormCheckListHistoryToResponse(requestHeader models.RequestHeader, item models.FormCheckListHistory) models.FormCheckListHistoryResponse {
	var (
		response           models.FormCheckListHistoryResponse
		formCheckListModel models.FormCheckList
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.FormCheckListHistoryID = item.FormCheckListHistoryID
	response.FormCheckListID = item.FormCheckListID
	resultFindFormCheckList := db.Where("FormCheckListID = ?", item.FormCheckListID).First(&formCheckListModel)
	if resultFindFormCheckList.RowsAffected > 0 {
		response.FormCheckListName = formCheckListModel.FormCheckListName
		response.IsCommentVisible = formCheckListModel.IsCommentVisible
		response.IsCommentMandatory = formCheckListModel.IsCommentMandatory
	}

	response.FormCheckListDate = item.FormCheckListDate
	response.Comment = item.Comment
	response.JobID = item.JobID
	response.ButtonID = item.ButtonID
	response.JobTaskID = item.JobTaskID
	response.FormID = item.FormID
	details := make([]models.FormCheckListQuestionHistoryResponse, 0)
	for _, v := range item.Questions {
		var detail models.FormCheckListQuestionHistoryResponse
		detail.FormCheckListQuestionHistoryID = v.FormCheckListQuestionHistoryID
		detail.FormCheckListHistoryID = v.FormCheckListHistoryID
		detail.GroupName = v.GroupName
		detail.Question = v.Question
		detail.Status = v.Status
		detail.IsPhotoEnable = v.IsPhotoEnable
		detail.IsMandatory = v.IsMandatory
		photos := make([]models.PhotoResponse, 0)

		for _, d := range v.Photos {
			var (
				photo       models.PhotoResponse
				reasonModel models.Reason
			)
			photo.PhotoID = d.PhotoID
			photo.TableNameObj = d.TableNameObj
			photo.ReasonID = d.ReasonID
			resultFindReason := db.Where("ReasonID = ?", d.ReasonID).First(&reasonModel)
			if resultFindReason.RowsAffected > 0 {
				photo.Reason = reasonModel.Reason
			}
			photo.ImageKey = d.ImageKey
			photo.ImageURL = d.ImageURL
			photo.ImageSize = d.ImageSize
			photo.ETag = d.ETag
			photo.Comment = d.Comment
			photo.PositionX = d.PositionX
			photo.PositionY = d.PositionY
			photos = append(photos, photo)
		}
		detail.Photos = photos
		details = append(details, detail)
	}
	response.Questions = details

	return response
}
