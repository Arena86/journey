package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetCreditNote godoc
// @Summary Get CreditNote
// @Description CreditNote
// @Tags CreditNote
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/creditnote [get]
func GetCreditNote(c *gin.Context) {
	defer libs.RecoverError(c, "GetCreditNote")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//headers := map[string]interface{}{"If-Modified-Since": "2020-09-01T05:23:08"}
	headers := map[string]interface{}{}
	representURL := "CreditNotes"
	//arrQuery := libs.ParseParamsQuery(c)

	arrQuery := make(map[string]interface{})

	whereQuery := ""

	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := services.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			if whereQuery != "" {
				whereQuery = whereQuery + " AND "
			}
			whereQuery = whereQuery + "Date>=DateTime(" + strconv.Itoa(dFromDate.Year()) + "," + strconv.Itoa(int(dFromDate.Month())) + ", " + strconv.Itoa(dFromDate.Day()) + ")"
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := services.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			if whereQuery != "" {
				whereQuery = whereQuery + " AND "
			}
			whereQuery = whereQuery + "Date<=DateTime(" + strconv.Itoa(dToDate.Year()) + "," + strconv.Itoa(int(dToDate.Month())) + ", " + strconv.Itoa(dToDate.Day()) + ")"
		}
	}

	vType, sType := libs.GetQueryParam("Type", c)
	if sType {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Type==\"" + vType + "\""
	}

	vStatus, sStatus := libs.GetQueryParam("Status", c)
	if sStatus {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Status==\"" + vStatus + "\""
	}

	vContactID, sContactID := libs.GetQueryParam("ContactID", c)
	if sContactID {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.ContactID==guid(\"" + vContactID + "\")"
	}

	vContactName, sContactName := libs.GetQueryParam("ContactName", c)
	if sContactName {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.Name.Contains(\"" + vContactName + "\")"
	}

	vContactNumber, sContactNumber := libs.GetQueryParam("ContactNumber", c)
	if sContactNumber {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.ContactNumber==\"" + vContactNumber + "\""
	}

	if whereQuery != "" {
		arrQuery["where"] = whereQuery
	}

	vPage, sPage := libs.GetQueryParam("Page", c)
	if sPage {
		arrQuery["page"] = vPage
	} else {
		arrQuery["page"] = "1"
	}

	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, headers)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes["CreditNotes"]
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetCreditNoteByID godoc
// @Summary Get CreditNote By ID
// @Description Get CreditNote By ID
// @Tags CreditNote
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/creditnote/{id} [get]
func GetCreditNoteByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetCreditNoteByID")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//headers := map[string]interface{}{"If-Modified-Since": "2020-09-01T05:23:08"}
	headers := map[string]interface{}{}
	exportPDF := false
	vPDF, sPDF := libs.GetQueryParam("PDF", c)
	if sPDF {
		bPDF, ePDF := strconv.ParseBool(vPDF)
		if ePDF == nil {
			exportPDF = bPDF
		}
	}
	ID := c.Param("id")
	representURL := "CreditNotes/" + ID
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, headers, exportPDF)
	if resStatus == 200 {
		if !exportPDF {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			var creditNoteRes = make([]interface{}, 0)
			objectJSON, errJSON := json.Marshal(dataRes["CreditNotes"])
			if errJSON == nil {
				json.Unmarshal(objectJSON, &creditNoteRes)
				if len(creditNoteRes) > 0 {
					data = creditNoteRes[0]
				}
			}
		} else {
			data = resData
		}
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateCreditNote godoc
// @Summary CreateCreditNote
// @Description CreateCreditNote
// @Tags XeroCreditNote
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Credit Note"
// @Success 200 {object} models.APIResponseData
// @Router /xero/creditnote [post]
func CreateCreditNote(c *gin.Context) {
	defer libs.RecoverError(c, "CreateCreditNote")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg            interface{}
		data           interface{}
		dataRes        map[string]interface{}
		creditNotePOST map[string]interface{}
		//creditNotePOST models.XeroCreditNoteJPPOST
		msgError string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		json.Unmarshal([]byte(string(body)), &creditNotePOST)
		requestBody := creditNotePOST
		delete(requestBody, "Allocations")
		representURL := "CreditNotes"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			// @TODO create creditnote
			creditNoteID := ""
			//creditNoteStatus := ""
			invoiceID := ""
			processCreditNote := true
			json.Unmarshal([]byte(string(resData)), &dataRes)
			var creditNoteRes = make([]interface{}, 0)
			objectJSON, errJSON := json.Marshal(dataRes["CreditNotes"])
			if errJSON == nil {
				json.Unmarshal(objectJSON, &creditNoteRes)
				if len(creditNoteRes) > 0 {
					//data = creditNoteRes[0]
					var mapCreditNote map[string]interface{}
					mapCreditNoteJSON, errMapCreditNote := json.Marshal(creditNoteRes[0])
					if errMapCreditNote == nil {
						json.Unmarshal(mapCreditNoteJSON, &mapCreditNote)
						fCreditNoteKey, errCreditNoteKey := mapCreditNote["CreditNoteID"]
						if errCreditNoteKey {
							creditNoteID = fmt.Sprintf("%v", fCreditNoteKey)
						}
						/* fCreditNoteStatus, errCreditNoteStatus := mapCreditNote["Status"]
						if errCreditNoteStatus {
							creditNoteStatus = fmt.Sprintf("%v", fCreditNoteStatus)
						} */
					} else {
						msgError = errMapCreditNote.Error()
					}
				} else {
					processCreditNote = false
				}
			} else {
				msgError = errJSON.Error()
			}
			// assign Allocations
			if processCreditNote {
				if creditNoteID != "" {
					allocationURL := "CreditNotes/" + creditNoteID + "/Allocations"
					var (
						xeroCreditNoteJPPOST   models.XeroCreditNoteJPPOST
						xeroAllocationXeroPOST models.XeroAllocationXeroPOST
					)
					json.Unmarshal([]byte(string(body)), &xeroCreditNoteJPPOST)
					if xeroCreditNoteJPPOST.Allocations != nil {
						xeroAllocationXeroPOST.Amount = xeroCreditNoteJPPOST.Allocations.Amount
						if xeroCreditNoteJPPOST.Allocations.InvoiceID != nil {
							xeroAllocationXeroPOST.Invoice.InvoiceID = *xeroCreditNoteJPPOST.Allocations.InvoiceID
						} else {
							xeroAllocationXeroPOST.Invoice.InvoiceID = ""
						}
						invoiceID = xeroAllocationXeroPOST.Invoice.InvoiceID
					}
					resStatus, resMsg, _ := libs.RequestXero(requestHeader, lang, "PUT", allocationURL, xeroAllocationXeroPOST, nil, nil)
					if resStatus == 200 {
						getCreditNoteURL := "CreditNotes/" + creditNoteID
						resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", getCreditNoteURL, nil, nil, nil, false)
						if resStatus == 200 {
							json.Unmarshal([]byte(string(resData)), &dataRes)
							var creditNoteRes = make([]interface{}, 0)
							objectJSON, errJSON := json.Marshal(dataRes["CreditNotes"])
							if errJSON == nil {
								json.Unmarshal(objectJSON, &creditNoteRes)
								if len(creditNoteRes) > 0 {
									data = creditNoteRes[0]
									// update creditnote ID, status to job
									if invoiceID != "" {
										var jobModel models.Job
										resultFindJob := db.Where("ErpInvoiceKey = ?", invoiceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
										if resultFindJob.RowsAffected > 0 {
											jobModel.IsCreditNote = true
											jobModel.ErpCreditNoteKey = &creditNoteID
											db.Save(&jobModel)
										}
									}
								}
							} else {
								status = 500
								msgError = errJSON.Error()
							}
						} else {
							status = resStatus
							msgError = fmt.Sprintf("%v", resMsg)
						}
					} else {
						status = resStatus
						msgError = fmt.Sprintf("%v", resMsg)
					}
				} else {
					status = 422
					msgError = services.GetMessage(lang, "api.create_creditnote_error")
				}
			} else {
				status = 422
				msgError = services.GetMessage(lang, "api.create_creditnote_error")
			}
		} else {
			status = resStatus
			msgError = fmt.Sprintf("%v", resMsg)
		}
	} else {
		status = 500
		msgError = err.Error()
	}
	if msgError != "" {
		msg = msgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
