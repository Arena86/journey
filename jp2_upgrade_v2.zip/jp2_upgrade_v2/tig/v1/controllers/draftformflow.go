package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetDraftFormFlowOnlyMaster godoc
// @Summary Get DraftFormFlow
// @Description Get DraftFormFlow
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow [get]
func GetDraftFormFlowOnlyMaster(c *gin.Context) {
	defer libs.RecoverError(c, "GetDraftFormFlow")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.DraftFormFlow
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"DraftFormFlowName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDraftFormFlowToArrayResponseOnlyMaster(resModels)

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetDraftFormFlowByID godoc
// @Summary Get DraftFormFlow By ID
// @Description Get DraftFormFlow By ID
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param id path int true "Item Group ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow/{id} [get]
func GetDraftFormFlowByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDraftFormFlowByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DraftFormFlow
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"DraftFormConditions",
		"IFNULL(IsDeleted, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND DraftFormFlowID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertDraftFormFlowToResponse(requestHeader, resModel)

		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateDraftFormFlow godoc
// @Summary Create Item Group
// @Description Create Item Group
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DraftFormFlow body models.DraftFormFlowResponse true "Create Item Group"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow [post]
func CreateDraftFormFlow(c *gin.Context) {
	apiName := "CreateDraftFormFlow"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.DraftFormFlow
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.DraftFormFlow
	)
	obj.PassBodyJSONToModel(objectsJSON)
	if obj.DraftFormFlowName == "" {
		errResponse := GetErrorResponseValidate(lang, 0, "api.draftformflowname_required")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resultFindDraftFormFlow := db.Where("DraftFormFlowName = ? AND IsDeleted = 0", obj.DraftFormFlowName).First(&models.DraftFormFlow{})
		if resultFindDraftFormFlow.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.draftformflowname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			obj.CreatedBy = accountKey
			// @TODO validate
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(obj)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				for i := range obj.DraftFormConditions {
					obj.DraftFormConditions[i].CreatedBy = accountKey

				}
				obj.Status = 0
				resultCreate := db.Create(&obj)
				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {
					totalUpdatedRecord++
					dataResponse = obj

					var (
						objs models.DraftFormFlow
					)
					db.Preload(
						"DraftFormConditions",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("DraftFormFlowID in (?)", dataResponse.DraftFormFlowID).First(&objs)
					dataResponses := ConvertDraftFormFlowToResponse(requestHeader, objs)
					data = dataResponses

					// Update Form UDT & Flow table
					UpdateFormUDTFlow(requestHeader, obj)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateDraftFormFlow godoc
// @Summary Update DraftFormFlow
// @Description Update DraftFormFlow
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DraftFormFlow body []models.DraftFormFlow true "Update DraftFormFlow"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow [put]
func UpdateDraftFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateDraftFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.DraftFormFlow
	)
	resultFind := db.Preload(
		"DraftFormConditions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("DraftFormFlowID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		if resModel.DraftFormFlowName == "" {
			errResponse := GetErrorResponseValidate(lang, 0, "api.draftformflowname_required")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resultFindDraftFormFlow := db.Where("DraftFormFlowName = ? AND IsDeleted = 0 AND DraftFormFlowID <> ?", resModel.DraftFormFlowName, resModel.DraftFormFlowID).First(&models.DraftFormFlow{})
			if resultFindDraftFormFlow.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.draftformflowname_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(resModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(0, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					timeNow := time.Now()
					for i := range resModel.DraftFormConditions {
						if resModel.DraftFormConditions[i].CreatedBy <= 0 {
							resModel.DraftFormConditions[i].CreatedBy = accountKey
							resModel.DraftFormConditions[i].CreatedDate = &timeNow
						}
						resModel.DraftFormConditions[i].ModifiedBy = accountKey
						resModel.DraftFormConditions[i].ModifiedDate = &timeNow
					}
					resModel.ModifiedDate = &timeNow
					if resModel.LastPublishedDate != nil {
						lastPublishedDate := *resModel.LastPublishedDate
						if timeNow.After(lastPublishedDate) {
							resModel.Status = 2
						}
					}
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						var (
							arrSkipID []int
						)
						for _, flowCondition := range resModel.DraftFormConditions {
							arrSkipID = append(arrSkipID, flowCondition.DraftFormConditionID)
						}
						if len(arrSkipID) > 0 {
							db.Where("FormFlowID = ? AND DraftFormConditionID not in (?)", resModel.DraftFormFlowID, arrSkipID).Delete(&models.DraftFormCondition{})
							//db.Where("FormFlowID = ? AND DraftFormConditionID not in (?)", resModel.DraftFormFlowID, arrSkipID).Model(&models.DraftFormCondition{}).Updates(models.DraftFormCondition{IsDeleted: true, ModifiedBy: accountKey})
						} else {
							db.Where("FormFlowID = ?", resModel.DraftFormFlowID).Delete(&models.DraftFormCondition{})
							//db.Where("FormFlowID = ?", resModel.DraftFormFlowID).Model(&models.DraftFormCondition{}).Updates(models.DraftFormCondition{IsDeleted: true, ModifiedBy: accountKey})
						}

						// Update Form UDT & Flow table
						UpdateFormUDTFlow(requestHeader, resModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
					// reload data
					responses := ConvertDraftFormFlowToResponse(requestHeader, resModel)
					data = responses
				}
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// DeleteDraftFormFlow godoc
// @Summary Delete Item Group
// @Description Delete Item Group
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Item Group ID"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow/{id} [delete]
func DeleteDraftFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteDraftFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.DraftFormFlow
		)
		resultFind := db.Where("DraftFormFlowID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			var (
				jobTask     models.JobTask
				jobTemplate models.JobTemplate
				canDeleted  = true
			)
			resultFindJobTask := db.Where("IFNULL(IsDeleted, 0) <> 1 AND FormFlowID = ?", id).First(&jobTask)
			if resultFindJobTask.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.form_flow_in_use_jobtask")
				errorsResponse = append(errorsResponse, errResponse)
				canDeleted = false
			}

			resultFindJobTemplate := db.Where("IFNULL(IsDeleted, 0) <> 1 AND (FormFlowID = ? OR FormFlowSecondID = ?)", id, id).First(&jobTemplate)
			if resultFindJobTemplate.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.form_flow_in_use_jobtemplate")
				errorsResponse = append(errorsResponse, errResponse)
				canDeleted = false
			}

			if canDeleted {

				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// delete details
					db.Where("FormFlowID = ?", resModel.DraftFormFlowID).Model(&models.DraftFormCondition{}).
						Updates(models.DraftFormCondition{IsDeleted: true, ModifiedBy: accountKey})

					// Delete dynamic form flow
					db.Where("FormFlowID = ?", resModel.DraftFormFlowID).Delete(&models.DynamicFormFlow{})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// PublishDraftFormFlow godoc
// @Summary Publish DraftFormFlow
// @Description Publish DraftFormFlow
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow/{id}/publish [put]
func PublishDraftFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "PublishDraftFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	draftFormID := c.Param("id")
	errs := PublishDraftFormFlowFunc(requestHeader, lang, accountKey, draftFormID)
	for _, e := range errs {
		errResponse := GetErrorResponseErrorMessage(0, e.Error())
		errorsResponse = append(errorsResponse, errResponse)
	}
	if len(errs) <= 0 {
		totalUpdatedRecord++
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// RevertDraftFormFlow godoc
// @Summary Revert DraftFormFlow
// @Description Revert DraftFormFlow
// @Tags DraftFormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DraftFormFlow body []models.DraftFormFlow true "Revert DraftFormFlow"
// @Success 200 {object} models.APIResponseData
// @Router /draftformflow/{id}/revert [put]
func RevertDraftFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "RevertDraftFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
		itemMsgError       string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		draftFormFlow models.DraftFormFlow
		formFlow      models.FormFlow
	)
	resultFindDraftForm := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DraftFormFlowID = ?", id).First(&draftFormFlow)
	if resultFindDraftForm.RowsAffected > 0 {
		resultFindDynamicForm := db.Preload(
			"FormConditions",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("IFNULL(IsDeleted, 0) <> 1").Where("FormFlowID = ?", id).First(&formFlow)
		if resultFindDynamicForm.RowsAffected > 0 {
			draftFormFlow.RevertDraftFromFormFlow(formFlow)
			resultCreate := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&draftFormFlow)
			if resultCreate.Error == nil {
				totalUpdatedRecord++
				var skipArray []int
				for _, condition := range formFlow.FormConditions {
					var (
						formConditionModel models.DraftFormCondition
					)
					resultFindFormCondition := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("DraftFormConditionID = ?", condition.FormConditionID).First(&formConditionModel)
					if resultFindFormCondition.RowsAffected > 0 {
						formConditionModel.RevertDraftFromFormCondition(condition)
						err := db.Save(&formConditionModel)
						if err.Error == nil {
							skipArray = append(skipArray, condition.FormConditionID)
						}
					}
				}
				db.Where("DraftFormConditionID NOT IN (?)", skipArray).Delete(&models.DraftFormCondition{})
				// Update Form UDT & Flow table
				UpdateFormUDTFlow(requestHeader, draftFormFlow)
				msg = services.GetMessage(lang, "api.success")
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			}
		} else {
			msg = services.GetMessage(lang, "api.success")
		}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
	}

	if itemMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if status == 200 {
		db.Preload(
			"DraftFormConditions",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("IFNULL(IsDeleted, 0) <> 1").Where("DraftFormFlowID = ?", id).First(&draftFormFlow)
		data = ConvertDraftFormFlowToResponse(requestHeader, draftFormFlow)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// ConvertArrayDraftFormFlowToArrayResponseOnlyMaster func
func ConvertArrayDraftFormFlowToArrayResponseOnlyMaster(items []models.DraftFormFlow) []models.DraftFormFlowResponseMaster {
	responses := make([]models.DraftFormFlowResponseMaster, 0)
	for _, item := range items {
		response := ConvertDraftFormFlowToResponseOnlyMaster(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDraftFormFlowToResponseOnlyMaster func
func ConvertDraftFormFlowToResponseOnlyMaster(item models.DraftFormFlow) models.DraftFormFlowResponseMaster {
	var (
		response models.DraftFormFlowResponseMaster
	)
	response.DraftFormFlowID = item.DraftFormFlowID
	response.DraftFormFlowName = item.DraftFormFlowName
	response.LastPublishedDate = item.LastPublishedDate
	response.Status = item.Status
	return response
}

// ConvertArrayDraftFormFlowToArrayResponse func
func ConvertArrayDraftFormFlowToArrayResponse(requestHeader models.RequestHeader, items []models.DraftFormFlow) []models.DraftFormFlowResponse {
	responses := make([]models.DraftFormFlowResponse, 0)
	for _, item := range items {
		response := ConvertDraftFormFlowToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDraftFormFlowToResponse func
func ConvertDraftFormFlowToResponse(requestHeader models.RequestHeader, item models.DraftFormFlow) models.DraftFormFlowResponse {
	var (
		response models.DraftFormFlowResponse
	)
	response.DraftFormFlowID = item.DraftFormFlowID
	response.DraftFormFlowName = item.DraftFormFlowName
	response.DraftFormFlow = item.DraftFormFlow
	response.DraftNavigation = item.DraftNavigation
	response.AdvancedForms = item.AdvancedForms
	response.SubFormFlows = item.SubFormFlows
	response.LastPublishedDate = item.LastPublishedDate
	response.Status = item.Status
	response.DraftFormConditions = ConvertArrayDraftFormConditionsToResponse(item.DraftFormConditions)
	return response
}

// ConvertArrayDraftFormConditionsToResponse func
func ConvertArrayDraftFormConditionsToResponse(draftFormConditions []models.DraftFormCondition) []models.DraftFormConditionOnDraftFormFlowResponse {
	var (
		responses  = make([]models.DraftFormConditionOnDraftFormFlowResponse, 0)
		tempGroups = make([]models.DraftFormConditionGroupByConditionID, 0)
	)
	for _, draft := range draftFormConditions {
		hasGroupByID := false
		for i, groupByID := range tempGroups {
			if draft.ConditionID == groupByID.ConditionID {
				hasGroupByGroup := false
				for j, groupByGroup := range groupByID.Groups {
					if draft.ConditionGroup == groupByGroup.ConditionGroup {
						tempGroups[i].Groups[j].DraftFormConditions = append(tempGroups[i].Groups[j].DraftFormConditions, draft)
						hasGroupByGroup = true
					}
				}
				if !hasGroupByGroup {
					var groupByGroupObj models.DraftFormConditionGroupByConditionGroup
					groupByGroupObj.ConditionGroup = draft.ConditionGroup
					groupByGroupObj.DraftFormConditions = append(groupByGroupObj.DraftFormConditions, draft)
					tempGroups[i].Groups = append(tempGroups[i].Groups, groupByGroupObj)
				}
				hasGroupByID = true
			}
		}
		if !hasGroupByID {
			var (
				groupByIDObj    models.DraftFormConditionGroupByConditionID
				groupByGroupObj models.DraftFormConditionGroupByConditionGroup
			)
			groupByIDObj.ConditionID = draft.ConditionID
			groupByGroupObj.ConditionGroup = draft.ConditionGroup
			groupByGroupObj.DraftFormConditions = append(groupByGroupObj.DraftFormConditions, draft)
			groupByIDObj.Groups = append(groupByIDObj.Groups, groupByGroupObj)
			tempGroups = append(tempGroups, groupByIDObj)
		}
	}

	for _, group := range tempGroups {
		var item models.DraftFormConditionOnDraftFormFlowResponse
		item.ConditionID = group.ConditionID
		if len(group.Groups) > 0 {
			if len(group.Groups[0].DraftFormConditions) > 0 {
				item.DefaultToForm = group.Groups[0].DraftFormConditions[0].DefaultToForm
			}
		}
		for _, groupID := range group.Groups {
			var groupByGroupObj models.DraftFormConditionGroupOnDraftFormFlowResponse
			groupByGroupObj.ConditionGroup = groupID.ConditionGroup
			if len(groupID.DraftFormConditions) > 0 {
				groupByGroupObj.ToForm = groupID.DraftFormConditions[0].ToForm
				groupByGroupObj.Sort = groupID.DraftFormConditions[0].Sort
			}
			for _, draftCondition := range groupID.DraftFormConditions {
				var draft models.DraftFormConditionGroupConditionOnDraftFormFlowResponse
				draft.DraftFormConditionID = draftCondition.DraftFormConditionID
				draft.Operator = draftCondition.Operator
				draft.FormID = draftCondition.FormID
				draft.DataField = draftCondition.DataField
				draft.ControlID = draftCondition.ControlID
				draft.ConditionCode = draftCondition.ConditionCode
				draft.ConditionValue = draftCondition.ConditionValue
				groupByGroupObj.Conditions = append(groupByGroupObj.Conditions, draft)
			}
			item.ConditionGroups = append(item.ConditionGroups, groupByGroupObj)
		}
		responses = append(responses, item)
	}

	return responses
}

// PublishDraftFormFlowFunc func
func PublishDraftFormFlowFunc(requestHeader models.RequestHeader, lang string, accountKey int, draftFormFlowID string) []error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		draftFormFlowModel    models.DraftFormFlow
		formFlowModel         models.FormFlow
		dynamicFormFlows      []models.DynamicFormFlow
		arrDraftDynamicFormID []int
		errs                  []error
	)
	timeNow := time.Now()
	resultFindDraftFormFlow := db.Preload(
		"DraftFormConditions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1").Where("DraftFormFlowID = ?", draftFormFlowID).First(&draftFormFlowModel)
	if resultFindDraftFormFlow.RowsAffected > 0 {
		// parse DraftFormFlow field to get array draftdynamicformid
		if draftFormFlowModel.DraftFormFlow != nil {

			resultFindDynamicFormFlow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
				Where("FormFlowID = ?", draftFormFlowID).Find(&dynamicFormFlows)
			if resultFindDynamicFormFlow.RowsAffected > 0 {

				for _, draftForm := range dynamicFormFlows {
					if draftForm.DynamicFormID > 0 {
						var (
							draftDynamicFormModel models.DraftDynamicForm
							dynamicFormModel      models.DynamicForm
							processDynamicForm    *gorm.DB
						)
						// find draftdynamicform
						resultFindDraftDynamicForm := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("DraftDynamicFormID = ?", draftForm.DynamicFormID).First(&draftDynamicFormModel)
						if resultFindDraftDynamicForm.RowsAffected > 0 {
							arrDraftDynamicFormID = append(arrDraftDynamicFormID, draftForm.DynamicFormID)
							// find draftform in dynamic form
							resultFindDynamicForm := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("DynamicFormID = ?", draftForm.DynamicFormID).First(&dynamicFormModel)
							dynamicFormModel.ConvertDraftToDynamicFrom(draftDynamicFormModel)
							dynamicFormModel.CreatedBy = accountKey
							dynamicFormModel.ModifiedBy = accountKey
							dynamicFormModel.LastPublishedDate = &timeNow
							if resultFindDynamicForm.RowsAffected > 0 {
								processDynamicForm = db.Save(&dynamicFormModel)
							} else {
								processDynamicForm = db.Create(&dynamicFormModel)
							}
							if processDynamicForm.Error != nil {
								errs = append(errs, processDynamicForm.Error)
							} else {
								draftDynamicFormModel.LastPublishedDate = &timeNow
								draftDynamicFormModel.Status = 1
								db.Save(&draftDynamicFormModel)
							}
						}
					}
				}
			}
		}

		// copy data from DraftFormFlow > FormFlow
		resultFindFormFlow := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("FormFlowID = ?", draftFormFlowModel.DraftFormFlowID).First(&formFlowModel)
		formFlowModel.ConvertDraftToFormFlow(draftFormFlowModel)
		formFlowModel.CreatedBy = accountKey
		formFlowModel.ModifiedBy = accountKey
		formFlowModel.LastPublishedDate = &timeNow
		var processFormFlow *gorm.DB
		if resultFindFormFlow.RowsAffected > 0 {
			processFormFlow = db.Save(&formFlowModel)
		} else {
			processFormFlow = db.Create(&formFlowModel)
		}
		if processFormFlow.Error == nil {
			draftFormFlowModel.LastPublishedDate = &timeNow
			draftFormFlowModel.Status = 1
			db.Save(&draftFormFlowModel)
			// copy data from draftformconditions > formconditions
			for _, draft := range draftFormFlowModel.DraftFormConditions {
				var (
					formConditionModel   models.FormCondition
					processFormCondition *gorm.DB
				)
				resultFindFormCondition := db.Where("IFNULL(IsDeleted, 0) <> 1").Where("FormConditionID = ?", draft.DraftFormConditionID).First(&formConditionModel)
				formConditionModel.ConvertDraftToFormCondition(draft)
				formConditionModel.CreatedBy = accountKey
				formConditionModel.ModifiedBy = accountKey
				if resultFindFormCondition.RowsAffected > 0 {
					processFormCondition = db.Save(&formConditionModel)
				} else {
					processFormCondition = db.Create(&formConditionModel)
				}
				if processFormCondition.Error != nil {
					errs = append(errs, processFormCondition.Error)
				}
			}
		}
		// @TODO create/update table to database
		if len(arrDraftDynamicFormID) > 0 {
			errList := UpdateUDTToDatabase(requestHeader, arrDraftDynamicFormID, accountKey)
			temErrs := append(errs, errList...)
			errs = temErrs
		}

		// Always delete
		RemoveDeletedUDT(requestHeader)
	}
	return errs
}

// UpdateUDTToDatabase func
func UpdateUDTToDatabase(requestHeader models.RequestHeader, arrDraftDynamicFormID []int, accountKey int) []error {
	var (
		errs []error
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var formUDTModels []models.FormUDT
	db.Preload("FormUDFs", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DataType <> 'Advanced'").
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
		Where("DraftDynamicFormID in (?)", arrDraftDynamicFormID).Find(&formUDTModels)
	for _, udt := range formUDTModels {
		tableName := "u_form_" + strconv.Itoa(udt.DraftDynamicFormID)
		primaryFieldName := "U_Form_" + strconv.Itoa(udt.DraftDynamicFormID)
		if ExistTableNameInDatabase(requestHeader, tableName) {
			// update
			arrColumns := GetListColumnNameOfTable(requestHeader, tableName)
			arrDefaultColumns := libs.GetDefaultColumns(tableName, primaryFieldName)
			// @TODO remove fields database not in default & new udt data
			sqlDrop := ``
			for _, column := range arrColumns {
				if libs.InArrayString(column, arrDefaultColumns) {
					continue
				}
				hasDataField := false
				for _, udf := range udt.FormUDFs {
					fieldName := libs.ChangeValueToDatabaseFormat(udf.DataField)
					if column == fieldName {
						hasDataField = true
						break
					}
				}
				if !hasDataField {
					if sqlDrop != "" {
						sqlDrop = sqlDrop + `, `
					}
					sqlDrop = sqlDrop + `DROP COLUMN ` + column
				}
			}
			if sqlDrop != "" {
				errDropColumn := AlterTableFunc(requestHeader, tableName, sqlDrop)
				if errDropColumn != nil {
					errs = append(errs, errDropColumn)
				}
			}

			// @TODO alter fields
			var (
				publishedID []int
			)
			sqlAlter := ``
			for _, udf := range udt.FormUDFs {
				if sqlAlter != "" {
					sqlAlter = sqlAlter + `, `
				}
				fieldName := libs.ChangeValueToDatabaseFormat(udf.DataField)
				lowerCaseType := libs.ConvertToDBDataType(strings.ToLower(udf.DataType))
				if libs.InArrayString(fieldName, arrColumns) {
					sqlAlter = sqlAlter + `MODIFY ` + fieldName + ` ` + lowerCaseType
					sqlAlter = libs.MappingLengthToDataField(sqlAlter, lowerCaseType, udf.Length)
				} else {
					sqlAlter = sqlAlter + `ADD ` + fieldName + ` ` + lowerCaseType
					sqlAlter = libs.MappingLengthToDataField(sqlAlter, lowerCaseType, udf.Length)
					sqlAlter = sqlAlter + ` NULL`
				}

				publishedID = append(publishedID, udf.FormUDFID)
			}
			if sqlAlter != "" {
				errAlterColumn := AlterTableFunc(requestHeader, tableName, sqlAlter)
				if errAlterColumn != nil {
					errs = append(errs, errAlterColumn)
				} else {
					// Publish UDF
					PublishedUDF(requestHeader, publishedID, accountKey)
				}
			}
		} else {
			// create
			errCreate := CreateTableInDatabase(requestHeader, tableName, primaryFieldName, udt.FormUDFs)
			if errCreate != nil {
				errs = append(errs, errCreate)
			} else {
				// PublishedUDT UDF
				PublishedUDT(requestHeader, udt.FormUDTID, accountKey)
			}
		}
	}
	return errs
}

// AlterTableFunc func
func AlterTableFunc(requestHeader models.RequestHeader, tableName string, content string) error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	sqlAlter := `ALTER TABLE ` + tableName
	sqlAlter = sqlAlter + ` ` + content + `;`
	err := db.Exec(sqlAlter).Error
	return err
}

// GetListColumnNameOfTable func
func GetListColumnNameOfTable(requestHeader models.RequestHeader, tableName string) []string {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	arrColumns := make([]string, 0)
	sql := `SELECT * FROM ` + tableName
	rows, errQuery := db.Raw(sql).Rows()
	if errQuery == nil {
		cols, _ := rows.Columns()
		for _, colName := range cols {
			arrColumns = append(arrColumns, colName)
		}
	}
	if rows != nil {
		defer rows.Close()
	}
	return arrColumns
}

// CreateTableInDatabase func
func CreateTableInDatabase(requestHeader models.RequestHeader, tableName string, primaryFieldName string, fields []models.FormUDF) error {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	sql := `CREATE TABLE ` + tableName + ` (`
	sql = libs.GetDefaultFields(sql, primaryFieldName)
	for _, v := range fields {
		lowerCaseType := libs.ConvertToDBDataType(strings.ToLower(v.DataType))
		sql = sql + `, `
		sql = sql + ` ` + libs.ChangeValueToDatabaseFormat(v.DataField) + ` ` + lowerCaseType
		sql = libs.MappingLengthToDataField(sql, lowerCaseType, v.Length)
		sql = sql + ` NULL`
	}
	sql = sql + `)`
	fmt.Print(sql)
	err := db.Exec(sql).Error
	return err
}

// ExistTableNameInDatabase func
func ExistTableNameInDatabase(requestHeader models.RequestHeader, tableName string) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	_, err := db.Raw("select * from " + tableName + ";").Rows()
	if err == nil {
		return true
	}
	return false
}

// PublishedUDT func
func PublishedUDT(requestHeader models.RequestHeader, formUDTID int, accountKey int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		formUdt models.FormUDT
	)
	resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("FormUDTID = ?", formUDTID).First(&formUdt)
	if resultFind.RowsAffected > 0 {
		formUdt.IsPublished = true
		formUdt.ModifiedBy = accountKey
		db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&formUdt)
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormUDTID = ?", formUDTID).
			Model(&models.FormUDF{}).
			Updates(models.FormUDF{IsPublished: true, ModifiedBy: accountKey})
	}
}

// PublishedUDF func
func PublishedUDF(requestHeader models.RequestHeader, formUDFID []int, accountKey int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormUDFID IN (?)", formUDFID).
		Model(&models.FormUDF{}).
		Updates(models.FormUDF{IsPublished: true, ModifiedBy: accountKey})
}

// RemoveDeletedUDT func
func RemoveDeletedUDT(requestHeader models.RequestHeader) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Where("IFNULL(IsDeleted, 0) = 1").Delete(&models.FormUDT{})

	db.Where("IFNULL(IsDeleted, 0) = 1").Delete(&models.FormUDF{})
}

// UpdateFormUDTFlow func
func UpdateFormUDTFlow(requestHeader models.RequestHeader, draftFormFlow models.DraftFormFlow) {

	if draftFormFlow.DraftFormFlow != nil {
		var (
			draftFormFlowJSON models.DraftFormFlowJSON
		)
		db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		err := json.Unmarshal([]byte(*draftFormFlow.DraftFormFlow), &draftFormFlowJSON)
		if err == nil {
			db.Where("FormFlowID = ?", draftFormFlow.DraftFormFlowID).Delete(&models.DynamicFormFlow{})
			for _, shape := range draftFormFlowJSON.Data.Shapes {
				if val, err := strconv.Atoi(shape.ShapeType); err == nil {
					var (
						formUDTFlow models.DynamicFormFlow
					)
					formUDTFlow.FormFlowID = draftFormFlow.DraftFormFlowID
					formUDTFlow.DynamicFormID = val
					db.Create(&formUDTFlow)
				}
			}
		}
	}
}
