package controllers

import (
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/logs"
	"jpapi/tig/v1/models"
	"strconv"
	"strings"
	"time"

	"github.com/jasonlvhit/gocron"
	"gorm.io/gorm"
)

// RepeatDaily const
const RepeatDaily = "daily"

// RepeatWeekly const
const RepeatWeekly = "weekly"

// RepeatMonthly const
const RepeatMonthly = "monthly"

// RunTaskList var
var RunTaskList []models.ProcessingTask

// CronJobTaskScheduler func
func CronJobTaskScheduler() {
	gocron.Clear()
	go func() {
		/* for {
			second := time.Now().Second()
			if second%15 == 0 {
				break
			}
			time.Sleep(1 * time.Second)
		}
		s := gocron.NewScheduler()
		fmt.Printf("RescheduleJobsEndDay: [%s] \n", time.Now())
		s.Every(15).Seconds().Do(CronJobTaskScheduler)
		<-s.Start() */

		for {
			second := time.Now().Second()
			minute := time.Now().Minute()
			if minute%15 == 0 && second == 0 {
				break
			}
			time.Sleep(1 * time.Second)
		}
		s := gocron.NewScheduler()
		fmt.Printf("CronJob: [%s] \n", time.Now())
		s.Every(15).Minutes().Do(CronJobTaskSchedulerFunc)
		<-s.Start()
	}()
}

// CronJobTaskSchedulerFunc func
func CronJobTaskSchedulerFunc() {
	startTime := time.Now()
	layout := "2006-01-02 15:04"
	t, err := time.Parse(layout, startTime.Format(layout))
	logger := logs.Logger

	logger.Error("Run Time : " + t.Format(layout))
	fmt.Println(t)
	localOffsetStr, localOffset := time.Now().Zone()
	logger.Error("Local Time Offset: " + localOffsetStr + " - " + strconv.Itoa(localOffset))
	fmt.Println("Local Time Offset: " + localOffsetStr + " - " + strconv.Itoa(localOffset))
	if err == nil {
		databasesInfo := GetDatabasesInfo()
		for _, data := range databasesInfo {
			go CronJobForEveryDatabase(data, t, startTime)
		}
	}
}

// CronJobForEveryDatabase func
func CronJobForEveryDatabase(dbInfo DatabaseInfo, startTime time.Time, executedTime time.Time) {
	defer func() {
		if r := recover(); r != nil {
		}
	}()
	var (
		taskModels []models.TaskScheduler
		// @TODO ???
		objSetting models.Timezone
	)
	db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
	sqlDB, err := db.DB()
	if err == nil {
		defer sqlDB.Close()
	}
	// @TODO ???
	db.First(&objSetting)
	db.Where("Enabled = ? AND RunAfter = ? ", true, false).Find(&taskModels)
	for _, task := range taskModels {
		var (
			isRunning = false
		)
		for _, v := range RunTaskList {
			if err == nil {
				if v.TaskID == task.TaskID && dbInfo.DBName == v.DBName {
					isRunning = true
					break
				}
			}
		}
		if !isRunning {
			go CronJobForEveryTask(dbInfo, task, startTime, objSetting, executedTime)
		}
	}
}

// CronJobForEveryTask func
func CronJobForEveryTask(dbInfo DatabaseInfo, taskModel models.TaskScheduler, startTime time.Time, objSetting models.Timezone, executedTime time.Time) {
	var (
		task    models.TaskSchedulerData
		nextRun string
	)
	processThisTask := false
	task = ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
	if task.Enabled {
		t, err := time.Parse(models.TimeFormat, task.StartAtTime)
		if err == nil {
			// Calculate TimeZone Offset
			afterCalcTime := t.Add(time.Duration(-objSetting.Offset) * time.Hour)
			task.StartAtTime = afterCalcTime.Format(models.TimeFormat)
		}

		processInfiniteField := ProcessInfiniteField(task, startTime)
		//fmt.Printf("%v > CronJobForEveryTask > Task:#%v > processInfiniteField: %v \n", startTime, taskModel.TaskKey, processInfiniteField)
		if processInfiniteField {
			if task.IsRepeat {
				switch strings.ToLower(task.Repeat) {
				case RepeatDaily:
					{
						currentRun := task.NextRun
						if CheckDateFormatOfString(currentRun) {
							if CheckValidRunCronJobAtDateAndTime(startTime, currentRun, task.StartAtTime) {
								processThisTask = true
								repeatEvery := task.RepeatEvery
								if repeatEvery == 0 {
									repeatEvery = 1
								}
								nextRun = GetNextRunValueByDay(currentRun, repeatEvery)
							}
						}
						/* if !processThisTask {
							// update to nextrun valid
							FixNextRunValueByDay(startTime, dbInfo, taskModel)
						} */
						//fmt.Printf("CronJobForEveryTask > Task:#%v > processThisTask: %v \n", taskModel.TaskKey, processThisTask)

					}
				case RepeatWeekly:
					{
						currentRun := task.NextRun
						if CheckDateFormatOfString(currentRun) {
							if CheckValidRunCronJobAtDateAndTime(startTime, currentRun, task.StartAtTime) {
								weekDay := startTime.Weekday().String()
								shortWeekDay := GetShortWeekDay(weekDay)
								hasProcessWeekly := HasProcessWeekly(shortWeekDay, task.RepeatOn)
								if hasProcessWeekly {
									processThisTask = true
									repeatEvery := task.RepeatEvery
									if repeatEvery == 0 {
										repeatEvery = 1
									}
									nextRun = GetNextRunValueByWeek(currentRun, repeatEvery, task.RepeatOn)
								}
							}
						}
						/* if !processThisTask {
							// update to nextrun valid
							FixNextRunValueByWeek(startTime, dbInfo, taskModel)
						} */
					}
				case RepeatMonthly:
					{
						currentRun := task.NextRun
						if CheckDateFormatOfString(currentRun) {
							if CheckValidRunCronJobAtDateAndTime(startTime, currentRun, task.StartAtTime) {
								dayInMonth := startTime.Day()
								hasProcessMonthly := HasProcessMonthly(dayInMonth, task.RepeatOnDayMonth)
								if hasProcessMonthly {
									processThisTask = true
									repeatEvery := task.RepeatEvery
									if repeatEvery == 0 {
										repeatEvery = 1
									}
									nextRun = GetNextRunValueByMonth(currentRun, repeatEvery)
								}
							}
						}
						/* if !processThisTask {
							// update to nextrun valid
							FixNextRunValueByMonth(startTime, dbInfo, taskModel)
						} */
					}
				}
			} else {
				// run only 1 at: date: TaskStartDate, time: StartAtTime
				//currentRun := task.NextRun
				//if currentRun == "" {
				currentRun := task.TaskStartDate
				//}
				if CheckDateFormatOfString(currentRun) {
					nextRun = currentRun
					if CheckValidRunCronJobAtDateAndTime(startTime, currentRun, task.StartAtTime) {
						processThisTask = true
					}
				}
			}
		}
	}
	logger := logs.Logger
	logger.Info("CronJobForEveryTask > TaskKey : ", task.TaskID)
	logger.Info("CronJobForEveryTask > processThisTask : ", processThisTask)
	if processThisTask {
		vNextRunTime, sNextRunTime := time.Parse(models.DateFormat, nextRun)
		logger.Info("CronJobForEveryTask > sNextRunTime : ", sNextRunTime)
		logger.Info("CronJobForEveryTask > vNextRunTime : ", vNextRunTime)
		if sNextRunTime == nil {
			db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
			sqlDB, err := db.DB()
			if err == nil {
				defer sqlDB.Close()
			}
			//db.Where("TaskKey = ?", taskModel.TaskKey).Model(models.DBTaskScheduler{}).Updates(map[string]interface{}{"IsCompleted": false})
			resetStatus := ResetIsCompletedAndErrorMessageOfMainTaskAndAfterTask(dbInfo, taskModel.TaskID)
			if resetStatus {
				/* cResponse := make(chan CronJobResponse)
				go CronJobProcessTask(cResponse, dbInfo, taskModel, startTime, executedTime)
				<-cResponse */
				//fmt.Printf("CronJobForEveryTask > Task:#%v > vResponse: %v \n", taskModel.TaskKey, vResponse)
				// update NextRun for task executed
				//db.Where("TaskKey = ?", taskModel.TaskKey).Model(models.DBTaskScheduler{}).Updates(map[string]interface{}{"NextRun": &vNextRunTime})
				//UpdateNextRunOfMainTaskAndAfterTask(dbInfo, taskModel.TaskID, vNextRunTime)
			}
		}
	}
}

func ResetIsCompletedAndErrorMessageOfMainTaskAndAfterTask(dbInfo DatabaseInfo, mainTaskID int) bool {
	db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
	//db.LogMode(true)
	sqlDB, err := db.DB()
	if err == nil {
		defer sqlDB.Close()
	}
	mapProcessTaskID := make(map[int]int)
	arrRepeatTaskID := GetRepeatTaskByID(db, mainTaskID, mapProcessTaskID)
	arrRepeatTaskID = append(arrRepeatTaskID, mainTaskID)
	db.Where("TaskKey in (?)", arrRepeatTaskID).Model(models.TaskScheduler{}).Updates(map[string]interface{}{"IsCompleted": false, "TaskErrorMessage": ""})
	return true
}

func UpdateNextRunOfMainTaskAndAfterTask(dbInfo DatabaseInfo, mainTaskID int, vNextRunTime time.Time) {
	db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
	//db.LogMode(true)
	sqlDB, err := db.DB()
	if err == nil {
		defer sqlDB.Close()
	}
	mapProcessTaskID := make(map[int]int)
	arrRepeatTaskID := GetRepeatTaskByID(db, mainTaskID, mapProcessTaskID)
	arrRepeatTaskID = append(arrRepeatTaskID, mainTaskID)
	db.Where("TaskKey in (?)", arrRepeatTaskID).Model(models.TaskScheduler{}).Updates(map[string]interface{}{"NextRun": &vNextRunTime})
}

// GetRepeatTaskByID func
func GetRepeatTaskByID(db *gorm.DB, iTaskKey int, mapProcessTaskID map[int]int) []int {
	var (
		runAfterTaskRepeat []models.RunAfterTask
		arrRepeatTaskKey   = make([]int, 0)
	)
	_, hasTaskID := mapProcessTaskID[iTaskKey]
	if hasTaskID {
		return arrRepeatTaskKey
	}
	mapProcessTaskID[iTaskKey] = iTaskKey
	db.Where("TaskKey = ?", iTaskKey).Find(&runAfterTaskRepeat)
	if len(runAfterTaskRepeat) > 0 {
		for _, re := range runAfterTaskRepeat {
			arrRepeatTaskKey = append(arrRepeatTaskKey, re.MainTask)
			arrRepeatTaskKey = append(arrRepeatTaskKey, GetRepeatTaskByID(db, re.MainTask, mapProcessTaskID)...)
		}
	}
	return arrRepeatTaskKey
}
