package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetSMSTemplate godoc
// @Summary Get SMSTemplate
// @Description Get SMSTemplate
// @Tags SMSTemplate
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /smstemplate [get]
func GetSMSTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "GetSMSTemplate")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.SMSTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	arrString := []string{"Name"}
	bp = libs.FilterString(arrString, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySMSTemplateToArrayResponse(resModels, lang, requestHeader)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetSMSTemplateByID godoc
// @Summary Get SMSTemplate By ID
// @Description Get SMSTemplate  By ID
// @Tags SMSTemplate
// @Accept  json
// @Produce  json
// @Param id path int true "SMSTemplate ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /smstemplate/{id} [get]
func GetSMSTemplateByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetSMSTemplateByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.SMSTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IsDeleted = 0  AND SMSTemplateID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertSMSTemplateToResponse(resModel, lang, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)

	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateSMSTemplate godoc
// @Summary Create SMSTemplate
// @Description Create SMSTemplate
// @Tags SMSTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SMSTemplate body []models.SMSTemplateResponse true "Create SMSTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /smstemplate [post]
func CreateSMSTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "CreateSMSTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.SMSTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	var (
		resModel models.SMSTemplate
	)
	resModel.PassBodyJSONToModel(objectsJSON)

	resultFindItemGroupCode := db.Where("Name = ? AND IsDeleted = 0", resModel.Name).First(&models.SMSTemplate{})
	if resultFindItemGroupCode.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.smstemplatename_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resModel.CreatedBy = accountKey
		resModel.ModifiedBy = accountKey
		resultFind := db.Where("SMSTemplateID = ?", resModel.SMSTemplateID).First(&resModel)
		resModel.PassBodyJSONToModel(objectsJSON)
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			if resultFind.RowsAffected > 0 {
				db.Save(&resModel)
			} else {
				db.Create(&resModel)
			}
			totalUpdatedRecord++
			dataResponse = resModel
		}
		var (
			resModels models.SMSTemplate
		)

		db.Where("SMSTemplateID in (?)", dataResponse.SMSTemplateID).Find(&resModels)
		data = ConvertSMSTemplateToResponse(resModels, lang, requestHeader)
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateSMSTemplate godoc
// @Summary Update SMSTemplate
// @Description Update SMSTemplate
// @Tags SMSTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SMSTemplate body []models.SMSTemplateResponse true "Update SMSTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /smstemplate/{id} [put]
func UpdateSMSTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSMSTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.SMSTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		resModel models.SMSTemplate
	)
	resModel.PassBodyJSONToModel(objectsJSON)

	resultFindItemGroupCode := db.Where("Name = ? AND IsDeleted = 0  AND SMSTemplateID <> ?", resModel.Name, ID).First(&models.SMSTemplate{})
	if resultFindItemGroupCode.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.smstemplatename_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resultFind := db.Where("SMSTemplateID = ?", ID).First(&resModel)
		resModel.PassBodyJSONToModel(objectsJSON)
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			if resultFind.RowsAffected > 0 {
				db.Save(&resModel)
			} else {
				db.Create(&resModel)
			}
			totalUpdatedRecord++
			dataResponse = resModel

			var (
				resModels models.SMSTemplate
			)
			db.Where("SMSTemplateID in (?)", dataResponse.SMSTemplateID).Find(&resModels)
			data = ConvertSMSTemplateToResponse(resModels, lang, requestHeader)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteSMSTemplate godoc
// @Summary Delete SMSTemplate
// @Description Delete SMSTemplate
// @Tags SMSTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "SMSTemplate ID"
// @Success 200 {object} models.APIResponseData
// @Router /smstemplate/{id} [delete]
func DeleteSMSTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteSMSTemplate")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.SMSTemplate
		)
		resultFind := db.Where("SMSTemplateID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArraySMSTemplateToArrayResponse func
func ConvertArraySMSTemplateToArrayResponse(items []models.SMSTemplate, lang string, requestHeader models.RequestHeader) []models.SMSTemplateResponse {
	responses := make([]models.SMSTemplateResponse, 0)
	for _, item := range items {
		response := ConvertSMSTemplateToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertSMSTemplateToResponse func
func ConvertSMSTemplateToResponse(item models.SMSTemplate, lang string, requestHeader models.RequestHeader) models.SMSTemplateResponse {
	var (
		response models.SMSTemplateResponse
		enum     models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.SMSTemplateID = item.SMSTemplateID
	response.Name = item.Name
	response.Body = item.Body
	response.TemplateVariableKey = item.TemplateVariableKey
	db.Where("FieldName = ? AND Status = ?", "SMSTemplateVariableKey", item.TemplateVariableKey).First(&enum)
	if enum.TranslationKey != "" && enum.TranslationKey != services.GetMessage(lang, enum.TranslationKey) {
		response.TemplateVariableKeyName = services.GetMessage(lang, enum.TranslationKey)
	} else {
		response.TemplateVariableKeyName = enum.Caption
	}
	return response
}
