package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strings"
)

// ProcessTranslationForObject func
func ProcessTranslationForObject(requestHeader models.RequestHeader, objectTableName string, objectID int, accountKey int, objectInterface map[string]interface{}) {
	// @TODO add or update translation table
	var (
		transModel models.Translation
		transPOST  []models.TranslationResponse
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	resultFindTrans := db.Where("TypeID = ? AND TypeName = ?", objectID, objectTableName).First(&transModel)
	_, resTrans := services.ConvertJSONValueToVariable("Translations", objectInterface)
	if resTrans != nil {
		jsonTrans, errTrans := json.Marshal(resTrans)
		if errTrans == nil {
			json.Unmarshal(jsonTrans, &transPOST)
			for _, v := range transPOST {
				switch strings.ToLower(v.Language) {
				case models.LanguageEN:
					transModel.EN = v.Value
				case models.LanguageIT:
					transModel.IT = v.Value
				case models.LanguageNL:
					transModel.NL = v.Value
				}
			}

		}
	}
	if resultFindTrans.RowsAffected > 0 {
		transModel.TypeID = objectID
		transModel.TypeName = objectTableName
		transModel.ModifiedBy = accountKey
		db.Save(&transModel)
	} else {
		transModel.TypeID = objectID
		transModel.TypeName = objectTableName
		transModel.CreatedBy = accountKey
		db.Create(&transModel)
	}
}

// DeleteTranslationOnObject func
func DeleteTranslationOnObject(requestHeader models.RequestHeader, objectTableName string, objectID int) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	db.Where("TypeID = ? AND TypeName = ?", objectID, objectTableName).Delete(&models.Translation{})
}

// GetTranslationResponse func
func GetTranslationResponse(requestHeader models.RequestHeader, objectTableName string, objectID int) []models.TranslationResponse {
	var (
		translationResponses []models.TranslationResponse
		translationEN        models.TranslationResponse
		translationIT        models.TranslationResponse
		translationNL        models.TranslationResponse
	)
	translationResponses = make([]models.TranslationResponse, 0)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		transModel models.Translation
	)
	resultFindTrans := db.Where("TypeID = ? AND TypeName = ?", objectID, objectTableName).First(&transModel)
	if resultFindTrans.RowsAffected > 0 {
		translationEN.TranslationID = transModel.TranslationID
		translationEN.Language = models.LanguageEN
		translationEN.Value = transModel.EN
		translationResponses = append(translationResponses, translationEN)

		translationIT.TranslationID = transModel.TranslationID
		translationIT.Language = models.LanguageIT
		translationIT.Value = transModel.IT
		translationResponses = append(translationResponses, translationIT)

		translationNL.TranslationID = transModel.TranslationID
		translationNL.Language = models.LanguageNL
		translationNL.Value = transModel.NL
		translationResponses = append(translationResponses, translationNL)
	}
	return translationResponses
}
