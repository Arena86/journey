package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/tomasen/realip"
	"gopkg.in/go-playground/validator.v9"
)

// SendEstimate godoc
// @Summary Send Estimate
// @Description Send Estimate
// @Tags Estimate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Estimate body models.EstimatePOST true "Send Estimate"
// @Success 200 {object} models.APIResponseData
// @Router /sendestimate [post]
func SendEstimate(c *gin.Context) {
	apiName := "SendEstimate"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	tokenAPI := c.Request.Header.Get("token")
	security := c.Request.Header.Get("security")
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationgroupid, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	locationid, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var estimatePOST models.EstimatePOST
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &estimatePOST)
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(estimatePOST)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		// check job
		var (
			jobModel models.Job
			// template for test
			emailTemplateID = 1
			encryptObject   models.EstimateEncrypt
			emailTemplate   models.EmailTemplate
			//report          models.Report
			emailFrom      = os.Getenv("EMAILSYSTEM")
			nameFrom       = os.Getenv("EMAILSENDERNAME")
			emailTo        string
			nameTo         string
			subject        string
			content        string
			attachs        = make([]string, 0)
			attachDocument = false
			settingModel   models.Setting
		)
		resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
		if resultFindSetting.RowsAffected > 0 {
			if settingModel.Value != nil {
				var (
					settingValue models.SettingValue
				)
				err = json.Unmarshal([]byte(*settingModel.Value), &settingValue)
				if err == nil {
					emailTemplateID = settingValue.Estimate.Email.DefaultTemplate
					attachDocument = settingValue.Estimate.Email.AttachDocument
				} else {
					errResponse := GetErrorResponseValidate(lang, 0, err.Error())
					errorsResponse = append(errorsResponse, errResponse)
				}
			} else {
				errResponse := GetErrorResponseValidate(lang, 0, "api.setting_value_invalid")
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseValidate(lang, 0, "api.setting_not_found")
			errorsResponse = append(errorsResponse, errResponse)
		}
		if len(errorsResponse) <= 0 {
			if attachDocument {
				if estimatePOST.ReportID <= 0 {
					errResponse := GetErrorResponseValidate(lang, 0, "api.reportid_required")
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
		if len(errorsResponse) <= 0 {
			if emailTemplateID <= 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.setting_emailtemplate_required")
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
		if len(errorsResponse) <= 0 {
			emailTo = estimatePOST.EmailAddress
			nameTo = ""
			resultFindJob := db.Where("JobID = ?", estimatePOST.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
			if resultFindJob.RowsAffected > 0 {
				if jobModel.EstimateDueDate != nil {
					generateToken := libs.GenerateToken()
					for {
						resultFindToken := db.Where("JobID <> ? AND Token = ?", estimatePOST.JobID, generateToken).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Job{})
						if resultFindToken.RowsAffected <= 0 {
							break
						}
					}
					encryptObject.JobID = estimatePOST.JobID
					encryptObject.CompanyID = companyID
					encryptObject.Token = generateToken
					encryptObject.Language = estimatePOST.Language
					encryptToken, err := libs.EncryptEstimate(encryptObject)
					if err == nil {
						sendEstimateLink := os.Getenv("URL_WEB_SEND_ESTIMATE")
						sendEstimateLink = sendEstimateLink + "/" + encryptToken
						// find emailtemplate
						resultFindEmailTemplate := db.Where("EmailTemplateID = ?", emailTemplateID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&emailTemplate)
						if resultFindEmailTemplate.RowsAffected > 0 {
							subject = libs.RemoveHTMLTag(emailTemplate.Subject)
							bodyContent := emailTemplate.Body
							var (
								keyModels       []models.KeyTemplateVariable
								arrBodyKeys     = make([]string, 0)
								arrBodyContents = make([]string, 0)
								businessPartner models.BusinessPartner
							)
							db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
							//db.Where("TemplateVariableKey = ?", emailTemplate.TemplateVariableKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&keyModels)
							db.Where("TemplateVariableKey = ?", emailTemplate.TemplateVariableKey).Find(&keyModels)
							for _, keyVar := range keyModels {
								switch keyVar.DataField {
								case "FirstName":
									{
										arrBodyKeys = append(arrBodyKeys, "%%First Name%%")
										arrBodyContents = append(arrBodyContents, businessPartner.FirstName)
									}
								case "LastName":
									{
										arrBodyKeys = append(arrBodyKeys, "%%Last Name%%")
										arrBodyContents = append(arrBodyContents, businessPartner.LastName)
									}
								case "AdditionalComment":
									{
										arrBodyKeys = append(arrBodyKeys, "%%AdditionalComment%%")
										arrBodyContents = append(arrBodyContents, estimatePOST.AdditionalComment)
									}
								case "EstimateLink":
									{
										arrBodyKeys = append(arrBodyKeys, "%%EstimateLink%%")
										hyperLink := `<a href="` + sendEstimateLink + `">Estimate Link</a>`
										arrBodyContents = append(arrBodyContents, hyperLink)
									}
								case "Logo":
									{
										var (
											logoModel           models.Logo
											logoBase64          string
											pathLogoImageHTTP   string
											pathLogoImageFolder = "public/images/logos"
											// @TODO need load dynamic host
											//hostHTTP = "http://localhost:6040/"
											hostHTTP = libs.GetServerEndPointJPServer(requestHeader)
										)
										pathLogoImageFolderCompany := pathLogoImageFolder + "/" + companyID
										logoID := 4
										resultFindLogo := db.Where("LogoID = ?", logoID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&logoModel)
										if resultFindLogo.RowsAffected > 0 {
											if logoModel.LogoData != nil {
												logoBase64 = *logoModel.LogoData
											}
										}
										if logoBase64 != "" {
											// @TODO gmail can not show base64
											// I tested: jpg, png
											errFolder := os.MkdirAll(pathLogoImageFolderCompany, 0777)
											if errFolder == nil {
												imgName := "logo-" + strconv.Itoa(logoModel.LogoID) + ".jpg"
												pathLogoImage := pathLogoImageFolderCompany + "/" + imgName
												// @TODO check exist file and create/no
												errImg := libs.ExportToImageFileFromImageBase64(pathLogoImage, logoBase64)
												if errImg == nil {
													pathLogoImageHTTP = hostHTTP + "" + pathLogoImage
												}
											}
										}
										if pathLogoImageHTTP == "" {
											pathLogoImageHTTP = hostHTTP + "" + pathLogoImageFolder + "/logo.jpg"
										}
										if pathLogoImageHTTP != "" {
											hyperLink := `<img src="` + pathLogoImageHTTP + `" />`
											arrBodyKeys = append(arrBodyKeys, "%%Logo%%")
											arrBodyContents = append(arrBodyContents, hyperLink)
										}
									}
								}
							}
							bodyContent = libs.StrReplaceWithArray(bodyContent, arrBodyKeys, arrBodyContents)
							content = bodyContent

							//fmt.Println("content: ", content)

							// find report
							/* resultFindReport := db.Where("ReportID = ?", estimatePOST.ReportID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&report)
							if resultFindReport.RowsAffected > 0 {

							} */
							if attachDocument {
								var (
									reportServerResponse models.ReportServerResponse
								)
								URL := os.Getenv("SERVER_REPORT") + "/export/" + strconv.Itoa(estimatePOST.ReportID)
								headers := map[string]interface{}{
									"token":           tokenAPI,
									"security":        security,
									"accountKey":      strconv.Itoa(accountKey),
									"language":        lang,
									"locationgroupid": strconv.Itoa(locationgroupid),
									"locationid":      strconv.Itoa(locationid),
									"companyid":       companyID,
								}
								params := map[string]interface{}{}
								resStatus, resMsg, resData := libs.RequestAPI(lang, "GET", URL, nil, params, headers)
								json.Unmarshal(resData, &reportServerResponse)
								if resStatus == 200 {
									if reportServerResponse.Status == 200 {
										pathFile := reportServerResponse.Data
										//if libs.FileExists(pathFile) {
										attachs = append(attachs, pathFile)
										//}
									}
								}
								if len(attachs) <= 0 {
									if reportServerResponse.Status != 200 {
										errResponse := GetErrorResponseErrorMessage(0, reportServerResponse.Msg)
										errorsResponse = append(errorsResponse, errResponse)
									} else if resStatus != 200 {
										errResponse := GetErrorResponseErrorMessage(0, resMsg)
										errorsResponse = append(errorsResponse, errResponse)
									} else {
										errResponse := GetErrorResponseValidate(lang, 0, "api.attachfile_invalid")
										errorsResponse = append(errorsResponse, errResponse)
									}
								}
							}
							if len(errorsResponse) <= 0 {
								_, err = libs.SendEmailWithAttachs(emailFrom, nameFrom, emailTo, nameTo, subject, content, attachs)
								if err == nil {
									totalUpdatedRecord++
									// update to job and reset rejected
									jobModel.Token = &generateToken
									jobModel.ModifiedBy = accountKey
									jobModel.RejectedDate = nil
									jobModel.IsRejected = false
									jobModel.IsSent = true
									db.Save(&jobModel)
								} else {
									errResponse := GetErrorResponseErrorMessage(0, err.Error())
									errorsResponse = append(errorsResponse, errResponse)
								}
							}
						} else {
							errResponse := GetErrorResponseValidate(lang, 0, "api.emailtemplateid_not_found")
							errorsResponse = append(errorsResponse, errResponse)
						}
					} else {
						errResponse := GetErrorResponseErrorMessage(0, err.Error())
						errorsResponse = append(errorsResponse, errResponse)
					}
				} else {
					errResponse := GetErrorResponseValidate(lang, 0, "api.estimateduedate_required")
					errorsResponse = append(errorsResponse, errResponse)
				}
			} else {
				errResponse := GetErrorResponseValidate(lang, 0, "api.jobid_not_found")
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// EstimateApproval godoc
// @Summary Estimate Approval
// @Description Estimate Approval
// @Tags Estimate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Estimate body models.EstimateApprovalPOST true "Estimate Approval"
// @Success 200 {object} models.APIResponseData
// @Router /estimateapproval [post]
func EstimateApproval(c *gin.Context) {
	apiName := "EstimateApproval"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//tokenAPI := c.Request.Header.Get("token")
	//security := c.Request.Header.Get("security")
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationgroupid, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//locationid, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var estimateApprovalPOST models.EstimateApprovalPOST
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &estimateApprovalPOST)
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(estimateApprovalPOST)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			jobModel         models.Job
			processing       = true
			validateMsgError string
		)
		//fmt.Printf("estimateApprovalPOST: %+v\n", estimateApprovalPOST)
		// find jobid
		resultFindJob := db.Where("JobID = ?", estimateApprovalPOST.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected <= 0 {
			processing = false
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobid_not_found"))
		}
		if processing {
			if jobModel.Token != nil {
				if *jobModel.Token != estimateApprovalPOST.JobToken {
					processing = false
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_not_found"))
				} else {
					if jobModel.EstimateDueDate != nil {
						estimateDueDate := *jobModel.EstimateDueDate
						estimateDueDate = estimateDueDate.AddDate(0, 0, 1)
						if estimateDueDate.Before(time.Now()) {
							processing = false
							validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_expired"))
						}
					} else {
						processing = false
						validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_expired"))
					}
				}
			} else {
				processing = false
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_not_found"))
			}
		}
		if processing {
			clientIP := realip.FromRequest(c.Request)
			if estimateApprovalPOST.Approved {
				// approved
				jobModel.IsRejected = false
				jobModel.RejectedDate = nil
				timeNow := time.Now()
				jobModel.CustomerApprovalDate = &timeNow
				jobModel.IsCustomerApproved = true
				jobModel.Token = nil
				jobModel.Signature = &estimateApprovalPOST.Signature
				jobModel.SubmittedIP = &clientIP
				db.Save(&jobModel)
				// customer approval => send
				settingValueModel, errSettingValue := GetSettingValue(requestHeader, lang)
				if errSettingValue == nil {
					var bp models.BusinessPartner
					db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?", jobModel.BusinessPartnerID).First(&bp)
					sendNotificationOptional := settingValueModel.Notifications.IsCustomerEstimateApprovalActive
					reasonID := settingValueModel.Notifications.CustomerEstimateApproval
					//Estimate <EstimateNumber> <EstimateDate> has been approved by <COMPANYNAME>.Manager approval is required to proceed with the Job!
					//notificationComment := "Customer " + bp.CompanyName + " has approved this estimate [" + jobModel.EstimateNumber + "]. Time" + timeNow.Format("2006-01-02 15:04:05")
					notificationComment := "Estimate " + jobModel.EstimateNumber + " " + timeNow.Format("2006-01-02 15:04:05") + " has been approved by  " + bp.CompanyName + ".\nManager approval is required to proceed with the Job!"
					SendNotificationWithOptinalFromSetting(requestHeader, lang, accountKey, notificationComment, jobModel.LocationID, reasonID, sendNotificationOptional, true)
				}
			} else {
				// rejected
				if estimateApprovalPOST.Comment != "" {
					var rejectedDoc models.RejectedDocument
					rejectedDoc.CreatedBy = accountKey
					rejectedDoc.ModifiedBy = accountKey
					rejectedDoc.BusinessPartnerID = jobModel.BusinessPartnerID
					rejectedDoc.JobID = jobModel.JobID
					rejectedDoc.DocumentType = 2
					rejectedDoc.Entity = "c" // Customer
					timeNow := time.Now()
					rejectedDoc.RejectedDate = &timeNow
					rejectedDoc.TotalDocument = jobModel.TotalJob
					rejectedDoc.Comment = estimateApprovalPOST.Comment
					resultCreateRejected := db.Create(&rejectedDoc)
					if resultCreateRejected.Error == nil {
						jobModel.IsRejected = true
						jobModel.RejectedDate = &timeNow
						jobModel.CustomerApprovalDate = nil
						jobModel.IsCustomerApproved = false
						jobModel.Signature = nil
						jobModel.SubmittedIP = &clientIP
						jobModel.Token = nil
						db.Save(&jobModel)

						settingValueModel, errSettingValue := GetSettingValue(requestHeader, lang)
						if errSettingValue == nil {
							var bp models.BusinessPartner
							db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?", jobModel.BusinessPartnerID).First(&bp)
							sendNotificationOptional := settingValueModel.Notifications.IsCustomerEstimateRejectedActive
							reasonID := settingValueModel.Notifications.CustomerEstimateRejected
							notificationComment := "Estimate " + jobModel.EstimateNumber + " " + timeNow.Format("2006-01-02 15:04:05") + " has been rejected by  " + bp.CompanyName + ".\nManager is required to check this!"
							SendNotificationWithOptinalFromSetting(requestHeader, lang, accountKey, notificationComment, jobModel.LocationID, reasonID, sendNotificationOptional, true)
						}
					} else {
						processing = false
						validateMsgError = libs.GetStringWithWordBetween(validateMsgError, resultCreateRejected.Error.Error())
					}
				} else {
					processing = false
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.comment_required"))
				}
			}
		}
		if validateMsgError == "" {
			totalUpdatedRecord++
		} else {
			fmt.Println("validateMsgError: ", validateMsgError)
			errResponse := GetErrorResponseErrorMessage(0, validateMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// RejectEstimate godoc
// @Summary Reject Approval
// @Description Reject Approval
// @Tags Estimate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /rejectestimate [put]
func RejectEstimate(c *gin.Context) {
	apiName := "RejectEstimate"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var estimateRejectPOST models.EstimateRejectPOST
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &estimateRejectPOST)
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(estimateRejectPOST)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			jobModel         models.Job
			processing       = true
			validateMsgError string
		)
		// find jobid
		resultFindJob := db.Where("JobID = ?", estimateRejectPOST.JobID).Where("IFNULL(IsDeleted, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected <= 0 {
			processing = false
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobid_not_found"))
		}
		if processing {
			clientIP := realip.FromRequest(c.Request)
			// rejected
			if estimateRejectPOST.Comment != "" {
				var rejectedDoc models.RejectedDocument
				rejectedDoc.CreatedBy = accountKey
				rejectedDoc.ModifiedBy = accountKey
				rejectedDoc.BusinessPartnerID = jobModel.BusinessPartnerID
				rejectedDoc.JobID = jobModel.JobID
				rejectedDoc.DocumentType = 2
				rejectedDoc.Entity = "m" // Manager
				timeNow := time.Now()
				rejectedDoc.RejectedDate = &timeNow
				rejectedDoc.TotalDocument = jobModel.TotalJob
				rejectedDoc.Comment = estimateRejectPOST.Comment
				resultCreateRejected := db.Create(&rejectedDoc)
				if resultCreateRejected.Error == nil {
					jobModel.IsRejected = true
					jobModel.RejectedDate = &timeNow
					jobModel.CustomerApprovalDate = nil
					jobModel.IsCustomerApproved = false
					jobModel.Signature = nil
					jobModel.SubmittedIP = &clientIP
					jobModel.Token = nil
					db.Save(&jobModel)

					settingValueModel, errSettingValue := GetSettingValue(requestHeader, lang)
					if errSettingValue == nil {
						var bp models.BusinessPartner
						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?", jobModel.BusinessPartnerID).First(&bp)
						sendNotificationOptional := settingValueModel.Notifications.IsCustomerEstimateRejectedActive
						reasonID := settingValueModel.Notifications.CustomerEstimateRejected
						notificationComment := "Estimate " + jobModel.EstimateNumber + " " + timeNow.Format("2006-01-02 15:04:05") + " has been rejected by  " + bp.CompanyName + ".\nManager is required to check this!"
						SendNotificationWithOptinalFromSetting(requestHeader, lang, accountKey, notificationComment, jobModel.LocationID, reasonID, sendNotificationOptional, true)
					}
				} else {
					processing = false
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, resultCreateRejected.Error.Error())
				}
			} else {
				processing = false
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.comment_required"))
			}
		}
		if validateMsgError == "" {
			totalUpdatedRecord++
		} else {
			fmt.Println("validateMsgError: ", validateMsgError)
			errResponse := GetErrorResponseErrorMessage(0, validateMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	}
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetEstimateApproval godoc
// @Summary Get Estimate Approval
// @Description Get Estimate Approval
// @Tags Estimate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /approval [get]
func GetEstimateApproval(c *gin.Context) {
	apiName := "GetEstimateApproval"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//tokenAPI := c.Request.Header.Get("token")
	//security := c.Request.Header.Get("security")
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationgroupid, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//locationid, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var estimateApprovalPOST models.EstimateApprovalPOST
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &estimateApprovalPOST)
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(estimateApprovalPOST)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			jobModel         models.Job
			processing       = true
			validateMsgError string
		)
		//fmt.Printf("estimateApprovalPOST: %+v\n", estimateApprovalPOST)
		// find jobid
		resultFindJob := db.Preload(
			"JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Preload(
			"JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where(
			"JobID = ?", estimateApprovalPOST.JobID,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).First(&jobModel)
		if resultFindJob.RowsAffected <= 0 {
			processing = false
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobid_not_found"))
		}
		if processing {
			if jobModel.Token != nil {
				if *jobModel.Token != estimateApprovalPOST.JobToken {
					processing = false
					validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_not_found"))
				} else {
					if jobModel.EstimateDueDate != nil {
						estimateDueDate := *jobModel.EstimateDueDate
						estimateDueDate = estimateDueDate.AddDate(0, 0, 1)
						if estimateDueDate.Before(time.Now()) {
							processing = false
							validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_expired"))
						}
					} else {
						processing = false
						validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_expired"))
					}
				}
			} else {
				processing = false
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.jobtoken_not_found"))
			}
		}
		if processing {
			itemsResponse := ConvertJobToResponse(requestHeader, jobModel, lang, false)
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Job{}.TableName())

			udfParams := make([]string, 0)

			vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
			if sIsInvoice {
				bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
				if eIsInvoice == nil {
					if bIsInvoice {
						udfParams = append(udfParams, "invoices")
					}
				}
			}

			vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
			if sIsEstimate {
				bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
				if eIsEstimate == nil {
					if bIsEstimate {
						udfParams = append(udfParams, "estimates")
					}
				}
			}

			vIsCreditnote, sIsCreditnote := libs.GetQueryParam("iscreditnote", c)
			if sIsCreditnote {
				bIsCreditnote, eIsCreditnote := strconv.ParseBool(vIsCreditnote)
				if eIsCreditnote == nil {
					if bIsCreditnote {
						udfParams = append(udfParams, "creditnotes")
					}
				}
			}

			vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
			if sIsJob {
				bIsJob, eIsJob := strconv.ParseBool(vIsJob)
				if eIsJob == nil {
					if bIsJob {
						udfParams = append(udfParams, "jobs")
					}
				}
			}
			if len(udfParams) > 0 {
				dbu = dbu.Where("UDFKey in (?)", udfParams)
			}
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			itemsResponse.UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, itemsResponse.JobID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				itemsResponse.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			itemsResponse.UDFs = udfResponses
			data = itemsResponse
		}
		if validateMsgError == "" {
			totalUpdatedRecord++
		} else {
			fmt.Println("validateMsgError: ", validateMsgError)
			errResponse := GetErrorResponseErrorMessage(0, validateMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}
