package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// GetXeroItem godoc
// @Summary Get Xero Item
// @Description Xero Item
// @Tags XeroItem
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/item [get]
func GetXeroItem(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroItem")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	//headers := map[string]interface{}{"If-Modified-Since": "2020-09-01T05:23:08"}
	headers := map[string]interface{}{}
	representURL := "Items"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, headers)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetXeroItemByID godoc
// @Summary Get Xero Item By ID
// @Description Get Xero Item By ID
// @Tags XeroItem
// @Accept  json
// @Produce  json
// @Param id path int true "XeroItem ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/item/{id} [get]
func GetXeroItemByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroItemByID")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	ID := c.Param("id")
	representURL := "Items/" + ID
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateXeroItem godoc
// @Summary Create Xero Item
// @Description Create Xero Item
// @Tags XeroItem
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Xero Item"
// @Success 200 {object} models.APIResponseData
// @Router /xero/item [post]
func CreateXeroItem(c *gin.Context) {
	defer libs.RecoverError(c, "CreateXeroItem")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		dataPOST      map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		json.Unmarshal([]byte(string(body)), &dataPOST)
		requestBody := dataPOST
		representURL := "Items"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			data = dataRes
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateItemFromDatabaseToXero func
func UpdateItemFromDatabaseToXero(requestHeader models.RequestHeader, lang string, items []models.Item) []models.ProcessXeroResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	processXeroResponses := make([]models.ProcessXeroResponse, 0)
	for _, item := range items {
		var (
			xeroItem            models.XeroItem
			xeroItemResponse    models.XeroItemResponse
			requestBody         interface{}
			taxModel            models.Tax
			itemMsgError        string
			processXeroResponse models.ProcessXeroResponse
			status              = 200
			responseData        interface{}
		)
		db.Where("TaxID = ?", item.TaxID).First(&taxModel)
		xeroItem.ConvertDatabaseModelToXero(db, item, taxModel)
		ID := item.ErpKey
		if ID != "" {
			representURL := "Items/" + ID
			requestBody = models.RemoveEmptyValueWhenPostToXeroItem(xeroItem)
			resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			status = resStatus
			if resStatus == 200 {
				// update to database
				json.Unmarshal([]byte(string(resData)), &xeroItemResponse)
				if len(xeroItemResponse.Items) > 0 {
					xeroItem := xeroItemResponse.Items[0]
					item.ConvertXeroToDatabaseModel(xeroItem)
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
					if resultSave.Error != nil {
						status = 500
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						responseData = item
					}
				}
			} else {
				if resMsg != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", resMsg))
				}
			}
		} else {
			// @TODO add new
			var (
				requestBody interface{}
			)
			validXeroItems := make([]map[string]interface{}, 0)
			validXeroItem := models.RemoveEmptyValueWhenPostToXeroItem(xeroItem)
			validXeroItems = append(validXeroItems, validXeroItem)
			dataPOST := make(map[string]interface{})
			dataPOST["Items"] = validXeroItems
			representURL := "Items"
			requestBody = dataPOST
			resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			status = resStatus
			responseData = resData
			if resStatus == 200 {
				json.Unmarshal([]byte(string(resData)), &xeroItemResponse)
				if len(xeroItemResponse.Items) > 0 {
					// add/update to database
					var (
						itemCodeModel models.Item
					)
					xeroItem := xeroItemResponse.Items[0]
					resultFindItemCode := db.Where("Code = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xeroItem.Code).First(&itemCodeModel)
					if resultFindItemCode.RowsAffected > 0 {
						itemCodeModel.ConvertXeroToDatabaseModel(xeroItem)
						itemCodeModel.RelatedItems = item.RelatedItems
						itemCodeModel.CreatedBy = item.CreatedBy
						itemCodeModel.ModifiedBy = item.ModifiedBy
						resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&itemCodeModel)
						if resultSave.Error != nil {
							status = 500
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						} else {
							responseData = itemCodeModel
						}
					} else {
						itemCodeModel.ConvertXeroToDatabaseModel(xeroItem)
						itemCodeModel.RelatedItems = item.RelatedItems
						itemCodeModel.CreatedBy = item.CreatedBy
						itemCodeModel.ModifiedBy = item.ModifiedBy
						resultCreate := db.Create(&itemCodeModel)
						if resultCreate.Error != nil {
							status = 500
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
						} else {
							responseData = itemCodeModel
						}
					}
				}
			} else {
				if resMsg != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", resMsg))
				}
			}
		}
		processXeroResponse.Status = status
		processXeroResponse.Data = responseData
		processXeroResponse.Msg = itemMsgError
		processXeroResponses = append(processXeroResponses, processXeroResponse)
	}
	return processXeroResponses
}
