package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetAllMenus godoc
// @Summary GetAllMenus
// @Description GetAllMenus
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /menu [get]
func GetAllMenus(c *gin.Context) {
	defer libs.RecoverError(c, "GetAllMenus")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.DeviceMenu
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)

	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDeviceMenuToArrayResponse(resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetMenuByID godoc
// @Summary GetMenuByID
// @Description GetMenuByID
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param id path int true "Menu ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /menu/{id} [get]
func GetMenuByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetMenuByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DeviceMenu
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND MenuID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertDeviceMenuToResponse(resModel, lang)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetAllUserMenus godoc
// @Summary GetAllUserMenus
// @Description GetAllUserMenus
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /usermenu [get]
func GetAllUserMenus(c *gin.Context) {
	defer libs.RecoverError(c, "GetAllUserMenus")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.UserMenu
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)

	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayUserMenuToArrayResponse(resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUserMenuByID godoc
// @Summary GetUserMenuByID
// @Description GetUserMenuByID
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param id path int true "UserMenu ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /usermenu/{id} [get]
func GetUserMenuByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetUserMenuByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.UserMenu
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND UserMenuID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertUserMenuToResponse(resModel, lang)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateUserMenuByUserID godoc
// @Summary UpdateUserMenuByUserID
// @Description UpdateUserMenuByUserID
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param MenuID body []string true "Update usermenu"
// @Success 200 {object} models.APIResponseData
// @Router /usermenu/{userid} [put]
func UpdateUserMenuByUserID(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateUserMenuByUserID")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	userID, _ := strconv.Atoi(c.Param("userid"))
	var arrMenuID []int
	json.NewDecoder(c.Request.Body).Decode(&arrMenuID)
	if len(arrMenuID) >= 0 {
		var (
			userMenuModels    = make([]models.UserMenu, 0)
			arrSkipUserMenuID = make([]int, 0)
		)
		for k, menuID := range arrMenuID {
			var menuModel models.DeviceMenu
			resultFindMenu := db.Where("MenuID = ?", menuID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&menuModel)
			if resultFindMenu.RowsAffected > 0 {
				var userMenuModel models.UserMenu
				resultFindUserMenu := db.Where("UserID = ? AND MenuID = ?", userID, menuID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&userMenuModel)
				if resultFindUserMenu.RowsAffected > 0 {
					arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
					userMenuModels = append(userMenuModels, userMenuModel)
					totalUpdatedRecord++
				} else {
					userMenuModel.UserID = userID
					userMenuModel.MenuID = menuID
					userMenuModel.CreatedBy = accountKey
					userMenuModel.ModifiedBy = accountKey
					resultCreate := db.Create(&userMenuModel)
					if resultCreate.Error == nil {
						arrSkipUserMenuID = append(arrSkipUserMenuID, userMenuModel.UserMenuID)
						userMenuModels = append(userMenuModels, userMenuModel)
						totalUpdatedRecord++
					} else {
						errResponse := GetErrorResponseErrorMessage(k, resultCreate.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
		if len(arrSkipUserMenuID) > 0 {
			db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ? AND UserMenuID not in (?)`, userID, arrSkipUserMenuID)
		} else {
			db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ?`, userID)
		}
		data = ConvertArrayUserMenuToArrayResponse(userMenuModels, lang)
	} else {
		db.Exec(`DELETE FROM `+models.UserMenu{}.TableName()+` WHERE UserID = ?`, userID)
		data = make([]int, 0)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(arrMenuID), errorsResponse, false)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetUserMenuByAccount godoc
// @Summary GetUserMenuByAccount
// @Description GetUserMenuByAccount
// @Tags Menu
// @Accept  json
// @Produce  json
// @Param id path int true "UserMenu ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getdevicemenubyaccount/ [get]
func GetUserMenuByAccount(c *gin.Context) {
	defer libs.RecoverError(c, "GetUserMenuByAccount")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
		userModel     models.User
		menus         []models.DeviceMenu
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		userID := userModel.UserID
		resultRow := db.Joins(" JOIN userdevicemenus ON userdevicemenus.MenuID = devicemenus.MenuID").
			Where("IFNULL(devicemenus.IsDeleted, 0) <> 1 AND IFNULL(devicemenus.IsArchived, 0) <> 1 AND UserID = ?", userID).Find(&menus)
		if resultRow.RowsAffected > 0 {
			msg = services.GetMessage(lang, "api.success")
			itemsResponse := ConvertArrayDeviceMenuToArrayResponse(menus, lang)
			data = itemsResponse
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
			data = make([]models.DeviceMenu, 0)
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayDeviceMenuToArrayResponse func
func ConvertArrayDeviceMenuToArrayResponse(items []models.DeviceMenu, lang string) []models.DeviceMenuResponse {
	responses := make([]models.DeviceMenuResponse, 0)
	for _, item := range items {
		response := ConvertDeviceMenuToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDeviceMenuToResponse func
func ConvertDeviceMenuToResponse(item models.DeviceMenu, lang string) models.DeviceMenuResponse {
	var (
		response models.DeviceMenuResponse
	)
	response.MenuID = item.MenuID
	response.Code = item.Code
	if item.TranslationKey1 != "" && item.TranslationKey1 != services.GetMessage(lang, item.TranslationKey1) {
		response.Title = services.GetMessage(lang, item.TranslationKey1)
	} else {
		response.Title = item.Title
	}
	if item.TranslationKey2 != "" && item.TranslationKey2 != services.GetMessage(lang, item.TranslationKey2) {
		response.Description = services.GetMessage(lang, item.TranslationKey2)
	} else {
		response.Description = item.Description
	}
	response.Icon = item.Icon
	response.Color = item.Color
	response.Image = item.Image
	return response
}

// ConvertArrayUserMenuToArrayResponse func
func ConvertArrayUserMenuToArrayResponse(items []models.UserMenu, lang string) []models.UserMenuResponse {
	responses := make([]models.UserMenuResponse, 0)
	for _, item := range items {
		response := ConvertUserMenuToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertUserMenuToResponse func
func ConvertUserMenuToResponse(item models.UserMenu, lang string) models.UserMenuResponse {
	var (
		response models.UserMenuResponse
	)
	response.UserMenuID = item.UserMenuID
	response.UserID = item.UserID
	response.MenuID = item.MenuID
	return response
}
