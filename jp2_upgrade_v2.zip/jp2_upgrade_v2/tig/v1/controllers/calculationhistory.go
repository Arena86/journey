package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"time"

	"github.com/gin-gonic/gin"
)

// VehicleInspectionStocktakeCalculation godoc
// @Summary Vehicle Inspection Stocktake Calculation
// @Description Vehicle Inspection Stocktake Calculation
// @Tags APP
// @Accept  json
// @Produce  json
// @Param ScheduleDate query string false "ScheduleDate yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclecalculation/{resourceid} [get]
func VehicleInspectionStocktakeCalculation(c *gin.Context) {
	defer libs.RecoverError(c, "VehicleInspectionStocktakeCalculation")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		resourceModel     models.Resource
		inspectionHistory models.VehicleInspectionHistory
		stocktakeHistory  models.VehicleStocktakeHistory
		msg, data         interface{}
		needInspection    bool
		needStocktake     bool
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	resourceID := c.Param("resourceid")
	sDateTimeNeedCheck := time.Now().Format(libs.FORMATDATE)
	dateTimeNeedCheck, _ := libs.ConvertStringToDateTime(sDateTimeNeedCheck)
	vDate, sDate := libs.GetQueryParam("ScheduleDate", c)
	if sDate {
		dDate, eDate := libs.ConvertStringToDateTime(vDate)
		if eDate == nil {
			sDateTimeNeedCheck = dDate.Format(libs.FORMATDATE)
			dateTimeNeedCheck, _ = libs.ConvertStringToDateTime(sDateTimeNeedCheck)
		}
	}
	resultFindResource := db.Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
	if resultFindResource.RowsAffected > 0 {
		sVehicleInspectionDay := resourceModel.VehicleInspectionDay
		arrVehicleInspectionDay := libs.StringToArray(sVehicleInspectionDay)
		if len(arrVehicleInspectionDay) > 0 {
			var (
				inConfigDays = false
			)
			resultFindMaxInspectionDateInHistory := db.Select("Max(InspectionDate) as InspectionDate").Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&inspectionHistory)
			weekDayDateTimeNeedCheck := libs.ConvertDateTimeToWeekDay(dateTimeNeedCheck)
			if libs.InArrayInteger(weekDayDateTimeNeedCheck, arrVehicleInspectionDay) {
				inConfigDays = true
			}
			if resultFindMaxInspectionDateInHistory.RowsAffected > 0 {
				if inspectionHistory.InspectionDate != nil {
					maxInspectionDate := *inspectionHistory.InspectionDate
					resNeedInspection, resErrInspection := CalculationInspectionStocktakeFunc(maxInspectionDate, dateTimeNeedCheck, arrVehicleInspectionDay)
					if resErrInspection == nil {
						needInspection = resNeedInspection
					} else {
						status = 500
						msg = resErrInspection.Error()
					}
				} else {
					if inConfigDays {
						// no history => need inspection
						needInspection = true
					}
				}
			} else {
				if inConfigDays {
					// no history => need inspection
					needInspection = true
				}
			}
		} else {
			// not config => no need inspection
			needInspection = false
		}

		sVehicleStocktakeDay := resourceModel.VehicleStocktakeDay
		arrVehicleStocktakeDay := libs.StringToArray(sVehicleStocktakeDay)
		if len(arrVehicleStocktakeDay) > 0 {
			var (
				inConfigDays = false
			)
			resultFindMaxStocktakeDateInHistory := db.Select("Max(StocktakeDate) as StocktakeDate").Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&stocktakeHistory)
			weekDayDateTimeNeedCheck := libs.ConvertDateTimeToWeekDay(dateTimeNeedCheck)
			if libs.InArrayInteger(weekDayDateTimeNeedCheck, arrVehicleStocktakeDay) {
				inConfigDays = true
			}
			if resultFindMaxStocktakeDateInHistory.RowsAffected > 0 {
				if stocktakeHistory.StocktakeDate != nil {
					maxStocktakeDate := *stocktakeHistory.StocktakeDate
					resNeedStocktake, resErrStocktake := CalculationInspectionStocktakeFunc(maxStocktakeDate, dateTimeNeedCheck, arrVehicleStocktakeDay)
					if resErrStocktake == nil {
						needStocktake = resNeedStocktake
					} else {
						status = 500
						msg = resErrStocktake.Error()
					}
				} else {
					if inConfigDays {
						// no history => need inspection
						needStocktake = true
					}
				}
			} else {
				if inConfigDays {
					// no history => need stocktake
					needStocktake = true
				}
			}
		} else {
			// not config => no need stocktake
			needStocktake = false
		}
	} else {
		// not resource
		status = 422
		msg = services.GetMessage(lang, "api.inspectionday_not_found")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"VehicleInspectionRequired": needInspection, "VehicleStocktakeRequired": needStocktake}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// InspectionCalculation godoc
// @Summary InspectionCalculation
// @Description InspectionCalculation
// @Tags Calculation
// @Accept  json
// @Produce  json
// @Param ScheduleDate query string false "ScheduleDate yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /inspectioncalculation/{resourceid} [get]
func InspectionCalculation(c *gin.Context) {
	defer libs.RecoverError(c, "InspectionCalculation")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		resourceModel     models.Resource
		inspectionHistory models.VehicleInspectionHistory
		msg, data         interface{}
		needInspection    bool
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	resourceID := c.Param("resourceid")
	sDateTimeNeedCheck := time.Now().Format(libs.FORMATDATE)
	//sDateTimeNeedCheck = "2020-11-15"
	dateTimeNeedCheck, _ := libs.ConvertStringToDateTime(sDateTimeNeedCheck)
	vDate, sDate := libs.GetQueryParam("ScheduleDate", c)
	if sDate {
		dDate, eDate := libs.ConvertStringToDateTime(vDate)
		if eDate == nil {
			sDateTimeNeedCheck = dDate.Format(libs.FORMATDATE)
			dateTimeNeedCheck, _ = libs.ConvertStringToDateTime(sDateTimeNeedCheck)
		}
	}
	resultFindResource := db.Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
	if resultFindResource.RowsAffected > 0 {
		sVehicleInspectionDay := resourceModel.VehicleInspectionDay
		arrVehicleInspectionDay := libs.StringToArray(sVehicleInspectionDay)
		if len(arrVehicleInspectionDay) > 0 {
			var (
				inConfigDays = false
			)
			resultFindMaxInspectionDateInHistory := db.Select("Max(InspectionDate) as InspectionDate").Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&inspectionHistory)
			weekDayDateTimeNeedCheck := libs.ConvertDateTimeToWeekDay(dateTimeNeedCheck)
			if libs.InArrayInteger(weekDayDateTimeNeedCheck, arrVehicleInspectionDay) {
				inConfigDays = true
			}
			if resultFindMaxInspectionDateInHistory.RowsAffected > 0 {
				if inspectionHistory.InspectionDate != nil {
					maxInspectionDate := *inspectionHistory.InspectionDate
					resNeedInspection, resErrInspection := CalculationInspectionStocktakeFunc(maxInspectionDate, dateTimeNeedCheck, arrVehicleInspectionDay)
					if resErrInspection == nil {
						needInspection = resNeedInspection
					} else {
						status = 500
						msg = resErrInspection.Error()
					}
				} else {
					if inConfigDays {
						// no history => need inspection
						needInspection = true
					}
				}
			} else {
				if inConfigDays {
					// no history => need inspection
					needInspection = true
				}
			}
		} else {
			// not config => no need inspection
			needInspection = false
		}
	} else {
		// not resource
		status = 422
		msg = services.GetMessage(lang, "api.inspectionday_not_found")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"Inspection": needInspection}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// StocktakeCalculation godoc
// @Summary StocktakeCalculation
// @Description StocktakeCalculation
// @Tags Calculation
// @Accept  json
// @Produce  json
// @Param ScheduleDate query string false "ScheduleDate yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /stocktakecalculation/{resourceid} [get]
func StocktakeCalculation(c *gin.Context) {
	defer libs.RecoverError(c, "StocktakeCalculation")
	var (
		status           = libs.GetStatusSuccess()
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		resourceModel    models.Resource
		stocktakeHistory models.VehicleStocktakeHistory
		msg, data        interface{}
		needStocktake    bool
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	resourceID := c.Param("resourceid")
	sDateTimeNeedCheck := time.Now().Format(libs.FORMATDATE)
	//sDateTimeNeedCheck = "2020-11-02"
	dateTimeNeedCheck, _ := libs.ConvertStringToDateTime(sDateTimeNeedCheck)
	vDate, sDate := libs.GetQueryParam("ScheduleDate", c)
	if sDate {
		dDate, eDate := libs.ConvertStringToDateTime(vDate)
		if eDate == nil {
			sDateTimeNeedCheck = dDate.Format(libs.FORMATDATE)
			dateTimeNeedCheck, _ = libs.ConvertStringToDateTime(sDateTimeNeedCheck)
		}
	}
	resultFindResource := db.Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
	if resultFindResource.RowsAffected > 0 {
		sVehicleStocktakeDay := resourceModel.VehicleStocktakeDay
		arrVehicleStocktakeDay := libs.StringToArray(sVehicleStocktakeDay)
		if len(arrVehicleStocktakeDay) > 0 {
			var (
				inConfigDays = false
			)
			resultFindMaxStocktakeDateInHistory := db.Select("Max(StocktakeDate) as StocktakeDate").Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&stocktakeHistory)
			weekDayDateTimeNeedCheck := libs.ConvertDateTimeToWeekDay(dateTimeNeedCheck)
			if libs.InArrayInteger(weekDayDateTimeNeedCheck, arrVehicleStocktakeDay) {
				inConfigDays = true
			}
			if resultFindMaxStocktakeDateInHistory.RowsAffected > 0 {
				if stocktakeHistory.StocktakeDate != nil {
					maxStocktakeDate := *stocktakeHistory.StocktakeDate
					resNeedStocktake, resErrStocktake := CalculationInspectionStocktakeFunc(maxStocktakeDate, dateTimeNeedCheck, arrVehicleStocktakeDay)
					if resErrStocktake == nil {
						needStocktake = resNeedStocktake
					} else {
						status = 500
						msg = resErrStocktake.Error()
					}
				} else {
					if inConfigDays {
						// no history => need inspection
						needStocktake = true
					}
				}
			} else {
				if inConfigDays {
					// no history => need stocktake
					needStocktake = true
				}
			}
		} else {
			// not config => no need stocktake
			needStocktake = false
		}
	} else {
		// not resource
		status = 422
		msg = services.GetMessage(lang, "api.stocktakeday_not_found")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"Stocktake": needStocktake}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CalculationInspectionStocktakeFunc func
func CalculationInspectionStocktakeFunc(maxInspectionDate time.Time, dateTimeNeedCheck time.Time, arrConfigDay []int) (bool, error) {
	var (
		needWork bool
		err      error
	)
	// Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6
	// find weekday of max inspection
	//fmt.Println("arrConfigDay: ", arrConfigDay)
	maxInspectionDate, _ = libs.ConvertStringToDateTime(maxInspectionDate.Format(libs.FORMATDATE))
	//fmt.Println("maxInspectionDate: ", maxInspectionDate)
	//weekDayMaxInspection := libs.ConvertDateTimeToWeekDay(maxInspectionDate)
	//fmt.Println("weekDayMaxInspection: ", weekDayMaxInspection)

	// find weekday of day need check
	//fmt.Println("dateTimeNeedCheck: ", dateTimeNeedCheck)
	weekDayDateTimeNeedCheck := libs.ConvertDateTimeToWeekDay(dateTimeNeedCheck)
	//fmt.Println("weekDayDateTimeNeedCheck: ", weekDayDateTimeNeedCheck)

	// find number less than weekday of day need check
	hasLessThanConfig := false
	weekDayConfig := 0
	tempWeekDayDateTimeNeedCheck := weekDayDateTimeNeedCheck
	for {
		if tempWeekDayDateTimeNeedCheck < 0 {
			break
		}
		if libs.InArrayInteger(tempWeekDayDateTimeNeedCheck, arrConfigDay) {
			weekDayConfig = tempWeekDayDateTimeNeedCheck
			hasLessThanConfig = true
			break
		}
		tempWeekDayDateTimeNeedCheck--
	}
	//fmt.Println("weekDayConfig: ", weekDayConfig)
	betweenTwoDay := 0
	if hasLessThanConfig {
		betweenTwoDay = weekDayDateTimeNeedCheck - weekDayConfig
	} else {
		maxWeekDayConfig := libs.FindMaxInArray(arrConfigDay)
		//fmt.Println("maxWeekDayConfig: ", maxWeekDayConfig)
		betweenTwoDay = weekDayDateTimeNeedCheck - (maxWeekDayConfig - 7)
	}
	timeToCheck := dateTimeNeedCheck.AddDate(0, 0, -betweenTwoDay)
	//fmt.Println("timeToCheck: ", timeToCheck)
	if timeToCheck.Unix() > maxInspectionDate.Unix() {
		// inspection
		needWork = true
	} else {
		// no inspection
		needWork = false
	}
	return needWork, err
}
