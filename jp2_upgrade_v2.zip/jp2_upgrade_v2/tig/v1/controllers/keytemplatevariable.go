package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetTemplateVariableByKey godoc
// @Summary Get TemplateVariable By Key
// @Description Get TemplateVariable  By Key
// @Tags TemplateVariable
// @Accept  json
// @Produce  json
// @Param id path string true "TemplateVariable FieldName"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /templatevariable/{key} [get]
func GetTemplateVariableByKey(c *gin.Context) {
	defer libs.RecoverError(c, "GetTemplateVariableByKey")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.KeyTemplateVariable
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	key := c.Param("Key")

	vType, sType := libs.GetQueryParam("Type", c)
	if !sType {
		vType = ""
	}
	var totalCount int64
	totalCount = 0
	var bp = db
	bp = bp.Where("TemplateVariableKey = ? AND Type = ?", key, vType)
	bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	msg = services.GetMessage(lang, "api.success")
	responses := ConvertArrayTemplateVariableToArrayResponse(resModels, lang)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayTemplateVariableToArrayResponse func
func ConvertArrayTemplateVariableToArrayResponse(items []models.KeyTemplateVariable, lang string) []models.KeyTemplateVariableResponse {
	responses := make([]models.KeyTemplateVariableResponse, 0)
	for _, item := range items {
		response := ConvertTemplateVariableToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertTemplateVariableToResponse func
func ConvertTemplateVariableToResponse(item models.KeyTemplateVariable, lang string) models.KeyTemplateVariableResponse {
	var (
		response models.KeyTemplateVariableResponse
	)
	response.TemplateVariableID = item.TemplateVariableID
	response.TemplateVariableKey = item.TemplateVariableKey
	response.DataField = item.DataField
	if item.TranslationKey != "" && item.TranslationKey != services.GetMessage(lang, item.TranslationKey) {
		response.Caption = services.GetMessage(lang, item.TranslationKey)
	} else {
		response.Caption = item.DataField
	}
	return response
}
