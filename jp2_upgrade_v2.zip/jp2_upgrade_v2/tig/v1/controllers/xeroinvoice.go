package controllers

import (
	"encoding/json"
	"io/ioutil"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetXeroInvoice godoc
// @Summary Get Xero Invoice
// @Description Xero Invoice
// @Tags XeroInvoice
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/invoice [get]
func GetXeroInvoice(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroInvoice")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	representURL := "Invoices"
	//arrQuery := libs.ParseParamsQuery(c)
	arrQuery := make(map[string]interface{})

	whereQuery := ""

	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := services.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			if whereQuery != "" {
				whereQuery = whereQuery + " AND "
			}
			whereQuery = whereQuery + "Date>=DateTime(" + strconv.Itoa(dFromDate.Year()) + "," + strconv.Itoa(int(dFromDate.Month())) + ", " + strconv.Itoa(dFromDate.Day()) + ")"
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := services.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			if whereQuery != "" {
				whereQuery = whereQuery + " AND "
			}
			whereQuery = whereQuery + "Date<=DateTime(" + strconv.Itoa(dToDate.Year()) + "," + strconv.Itoa(int(dToDate.Month())) + ", " + strconv.Itoa(dToDate.Day()) + ")"
		}
	}

	vType, sType := libs.GetQueryParam("Type", c)
	if sType {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Type==\"" + vType + "\""
	}

	vStatus, sStatus := libs.GetQueryParam("Status", c)
	if sStatus {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Status==\"" + vStatus + "\""
	}

	vContactID, sContactID := libs.GetQueryParam("ContactID", c)
	if sContactID {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.ContactID==guid(\"" + vContactID + "\")"
	}

	vContactName, sContactName := libs.GetQueryParam("ContactName", c)
	if sContactName {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.Name.Contains(\"" + vContactName + "\")"
	}

	vContactNumber, sContactNumber := libs.GetQueryParam("ContactNumber", c)
	if sContactNumber {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Contact.ContactNumber==\"" + vContactNumber + "\""
	}

	if whereQuery != "" {
		arrQuery["where"] = whereQuery
	}

	vStatuses, sStatuses := libs.GetQueryParam("Statuses", c)
	if sStatuses {
		arrQuery["Statuses"] = vStatuses
	}

	vIDs, sIDs := libs.GetQueryParam("IDs", c)
	if sIDs {
		arrQuery["IDs"] = vIDs
	}

	vInvoiceNumbers, sInvoiceNumbers := libs.GetQueryParam("InvoiceNumbers", c)
	if sInvoiceNumbers {
		arrQuery["InvoiceNumbers"] = vInvoiceNumbers
	}

	vContactIDs, sContactIDs := libs.GetQueryParam("ContactIDs", c)
	if sContactIDs {
		arrQuery["ContactIDs"] = vContactIDs
	}

	vPage, sPage := libs.GetQueryParam("Page", c)
	if sPage {
		arrQuery["page"] = vPage
	} else {
		arrQuery["page"] = "1"
	}

	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes["Invoices"]
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetXeroInvoiceByID godoc
// @Summary Get Xero Invoice By ID
// @Description Get Xero Invoice By ID
// @Tags XeroInvoice
// @Accept  json
// @Produce  json
// @Param id path int true "XeroInvoice ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/invoice/{id} [get]
func GetXeroInvoiceByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroInvoiceByID")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	exportPDF := false
	vPDF, sPDF := libs.GetQueryParam("PDF", c)
	if sPDF {
		bPDF, ePDF := strconv.ParseBool(vPDF)
		if ePDF == nil {
			exportPDF = bPDF
		}
	}
	ID := c.Param("id")
	representURL := "Invoices/" + ID
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil, exportPDF)
	if resStatus == 200 {
		//json.Unmarshal([]byte(string(resData)), &dataRes)
		//data = dataRes
		if !exportPDF {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			var invoiceRes = make([]interface{}, 0)
			objectJSON, errJSON := json.Marshal(dataRes["Invoices"])
			if errJSON == nil {
				json.Unmarshal(objectJSON, &invoiceRes)
				if len(invoiceRes) > 0 {
					data = invoiceRes[0]
				}
			}
		} else {
			data = resData
		}
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateXeroInvoice godoc
// @Summary Create Xero Invoice
// @Description Create Xero Invoice
// @Tags XeroInvoice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Xero Invoice"
// @Success 200 {object} models.APIResponseData
// @Router /xero/invoice [post]
func CreateXeroInvoice(c *gin.Context) {
	defer libs.RecoverError(c, "CreateXeroInvoice")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		//dataPOST      map[string]interface{}
		invoicePOST models.XeroInvoiceJPPOST
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		//json.Unmarshal([]byte(string(body)), &dataPOST)
		json.Unmarshal([]byte(string(body)), &invoicePOST)
		//fmt.Printf("invoicePOST: %+v\n", invoicePOST)
		//requestBody := dataPOST
		requestBody := invoicePOST
		representURL := "Invoices"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			//json.Unmarshal([]byte(string(resData)), &dataRes)
			//data = dataRes
			json.Unmarshal([]byte(string(resData)), &dataRes)
			var invoiceRes = make([]interface{}, 0)
			objectJSON, errJSON := json.Marshal(dataRes["Invoices"])
			if errJSON == nil {
				json.Unmarshal(objectJSON, &invoiceRes)
				if len(invoiceRes) > 0 {
					data = invoiceRes[0]
				}
			}

			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ApproveXeroInvoice godoc
// @Summary Approve Xero Invoice
// @Description Approve Xero Invoice
// @Tags XeroInvoice
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param XeroInvoice body []models.XeroInvoiceJPPOST true "Approve Xero Invoice"
// @Success 200 {object} models.APIResponseData
// @Router /xero/invoice/approveinvoice/{invoiceid} [put]
func ApproveXeroInvoice(c *gin.Context) {
	defer libs.RecoverError(c, "ApproveXeroInvoice")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		//dataPOST      map[string]interface{}
		invoicePOST models.XeroInvoiceJPPOST
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	invoiceID := c.Param("invoiceid")
	invoicePOST.InvoiceID = &invoiceID
	approveInvoice := "AUTHORISED"
	invoicePOST.Status = &approveInvoice
	requestBody := invoicePOST
	representURL := "Invoices/" + invoiceID
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		var invoiceRes = make([]interface{}, 0)
		objectJSON, errJSON := json.Marshal(dataRes["Invoices"])
		if errJSON == nil {
			json.Unmarshal(objectJSON, &invoiceRes)
			if len(invoiceRes) > 0 {
				data = invoiceRes[0]
			}
		}
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
