package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// ResetDevice godoc
// @Summary Reset Device
// @Description Reset Device
// @Tags User
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /resetdevice [get]
func ResetDevice(c *gin.Context) {
	defer libs.RecoverError(c, "GetUserByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND AccountKey = ?", accountKey)
	resultRow := bp.First(&resModel)

	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"AllowPanicReset": resModel.AllowPanicReset}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetDevice godoc
// @Summary Get Device
// @Description Get Device
// @Tags Device
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param DeviceEntity query string false "Deviceentity=1,2,3"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /device [get]
func GetDevice(c *gin.Context) {
	defer libs.RecoverError(c, "GetDevice")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Device
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDeviceToArrayResponse(requestHeader, resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetDeviceByID godoc
// @Summary Get Device By ID
// @Description Get Device By ID
// @Tags Device
// @Accept  json
// @Produce  json
// @Param id path int true "Device ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /device/{id} [get]
func GetDeviceByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDeviceByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Device
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DeviceID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertDeviceToResponse(requestHeader, resModel, lang)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateDevice godoc
// @Summary Create Device
// @Description Create Device
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Device body []models.DeviceResponse true "Create Device"
// @Success 200 {object} models.APIResponseData
// @Router /device [post]
func CreateDevice(c *gin.Context) {
	apiName := "CreateDevice"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.Device
		totalUpdatedRecord = 0
		isNew              = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.Device
	)
	obj.PassBodyJSONToModel(objectsJSON)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
			resultCreate *gorm.DB
		)
		resultFind := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DeviceID = ?", obj.DeviceID).First(&obj)
		obj.PassBodyJSONToModel(objectsJSON)
		if resultFind.RowsAffected > 0 {
			resultCreate = db.Save(&obj)
			isNew = false
		} else {
			companyID := c.Request.Header.Get("companyid")
			hasLicense, license, errLicense := libs.FindLicenseInfo(companyID)
			if hasLicense && errLicense == nil {
				var totalDevices int64
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&models.Device{}).Count(&totalDevices)
				if float64(totalDevices) >= license.PhysicalDeviceQuantity {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.reached_maximum_device"))
				}
			}
			if itemMsgError == "" {
				obj.Status = 0
				resultCreate = db.Create(&obj)
			}
		}
		if itemMsgError == "" {
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				totalUpdatedRecord++

				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DeviceID = ?", obj.DeviceID).First(&obj)
				dataResponse = obj

				dataResponses := ConvertDeviceToResponse(requestHeader, dataResponse, lang)
				data = dataResponses
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	if isNew {
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	} else {
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	}
	errors = errorsResponse
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteDevice godoc
// @Summary Delete Device
// @Description Delete Device
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Device ID"
// @Success 200 {object} models.APIResponseData
// @Router /device/{id} [delete]
func DeleteDevice(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteDevice")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.Device
		)
		resultFind := db.Where("DeviceID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayDeviceToArrayResponse func
func ConvertArrayDeviceToArrayResponse(requestHeader models.RequestHeader, items []models.Device, lang string) []models.DeviceResponse {
	responses := make([]models.DeviceResponse, 0)
	for _, item := range items {
		response := ConvertDeviceToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDeviceToResponse func
func ConvertDeviceToResponse(requestHeader models.RequestHeader, item models.Device, lang string) models.DeviceResponse {
	var (
		response                models.DeviceResponse
		deviceLicenseStatusEnum models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.DeviceID = item.DeviceID
	response.DeviceName = item.DeviceName
	response.DeviceModel = item.DeviceModel
	response.Status = item.Status
	response.OSVersion = item.OSVersion
	response.PseudoUniqueID = item.PseudoUniqueID
	response.WLANMACAddress = item.WLANMACAddress
	response.AppVersion = item.AppVersion
	response.Status = item.Status
	response.ActivatedDate = item.ActivatedDate
	response.DeactivatedDate = item.DeactivatedDate
	response.Message = item.Message
	db.Where("FieldName = ? AND Status = ?", "DeviceLicenseStatus", item.Status).First(&deviceLicenseStatusEnum)
	if deviceLicenseStatusEnum.TranslationKey != "" && deviceLicenseStatusEnum.TranslationKey != services.GetMessage(lang, deviceLicenseStatusEnum.TranslationKey) {
		response.StatusName = services.GetMessage(lang, deviceLicenseStatusEnum.TranslationKey)
	} else {
		response.StatusName = deviceLicenseStatusEnum.Caption
	}

	return response
}

// UpdateDeviceLicense godoc
// @Summary UpdateDeviceLicense
// @Description UpdateDeviceLicense
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Device body []models.DeviceLicenseJSON true "Update Device"
// @Success 200 {object} models.APIResponseData
// @Router /updatedevicelicense [put]
func UpdateDeviceLicense(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateDeviceLicense")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data          interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Device
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Device, 0)

	var (
		sygicProductID      string
		sygicPurchasePeriod string
		sygicURLROOT        string
		sygicAPIKey         string
		locationCountryCode string
	)

	// @TODO hardcode to testing
	//locationCountryCode = "aus"
	locationCountryCode = GetSygicCountryCode(requestHeader, locationID)

	sygicLicenseConfig := libs.GetSygicLicense()

	if sygicLicenseConfig.SygicLicenseKey > 0 {
		sygicURLROOT = sygicLicenseConfig.APIURL
		sygicAPIKey = sygicLicenseConfig.APIKey
		for _, sygicDetail := range sygicLicenseConfig.SygicLicenseDetails {
			if strings.ToLower(sygicDetail.CountryCode) == locationCountryCode {
				sygicProductID = sygicDetail.ProductID
				sygicPurchasePeriod = sygicDetail.PurchasePeriod
			}
		}
	}

	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel     models.Device
				itemMsgError string
			)
			var oldDeviceModel models.Device
			resultFindOldDevice := db.Where("Status = 2").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&oldDeviceModel)
			if resultFindOldDevice.RowsAffected > 0 {
				// replace sygic license
				resModel.PassBodyJSONToModelDeviceLicense(bp)
				newStatus := resModel.Status
				resultFind := db.Where("DeviceID = ?", resModel.DeviceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
				if resultFind.RowsAffected > 0 {
					if resModel.Status == 1 {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, resModel)
					} else {
						resModel.PassBodyJSONToModelDeviceLicense(bp)
						if newStatus == 1 {
							newDeviceID := resModel.DeviceID
							bodyData := make(map[string]interface{})
							bodyDataLicense := make(map[string]interface{})
							bodyDataLicense["sourceIdentifier"] = oldDeviceModel.DeviceID
							bodyDataLicense["destinationIdentifier"] = newDeviceID
							bodyDataLicenseSygic := []interface{}{bodyDataLicense}
							bodyData["licenses"] = bodyDataLicenseSygic

							bodyData["note"] = "reactivate"
							bodySygic := bodyData

							headers := make(map[string]interface{})
							headers["X-api_key"] = sygicAPIKey
							headers["Content-Type"] = "application/json"
							params := make(map[string]interface{})
							params["productId"] = sygicProductID
							params["purchasePeriod"] = sygicPurchasePeriod
							sygicURL := libs.GetSygicRootURL(sygicURLROOT)
							sygicURL = sygicURL + "/licenseservices/reactivate"
							statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
							var sygicAPIRespone models.SygicAPIRespone
							json.Unmarshal(dataRes, &sygicAPIRespone)
							if statusRes == 200 {
								if sygicAPIRespone.SuccessfulCount == 1 {
									resModel.Status = 1
									// delete old
									oldDeviceModel.IsDeleted = true
									oldDeviceModel.ModifiedBy = accountKey
									deletedResult := db.Save(&oldDeviceModel)
									if deletedResult.Error != nil {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, deletedResult.Error.Error())
									}
								} else {
									status = 422
									if len(sygicAPIRespone.Errors.NotFound) > 0 {
										for _, notFound := range sygicAPIRespone.Errors.NotFound {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, notFound+": "+services.GetMessage(lang, "api.sygic_not_found"))
										}
									}
									if len(sygicAPIRespone.Errors.InvalidLicenseAction) > 0 {
										for _, invalid := range sygicAPIRespone.Errors.InvalidLicenseAction {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_license"))
										}
									}
									if len(sygicAPIRespone.Errors.MaxRepairCountReached) > 0 {
										for _, invalid := range sygicAPIRespone.Errors.MaxRepairCountReached {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_max_repair_count_reached"))
										}
									}
									if itemMsgError == "" {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_error"))
									}
								}
							} else {
								status = statusRes
								if sygicAPIRespone.Message != "" {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", msgRes))
								}
							}
						}
						if itemMsgError != "" {
							resModel.Message = itemMsgError
						}
						resModel.ModifiedBy = accountKey
						resultSave := db.Save(&resModel)
						if resultSave.Error != nil {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						} else {
							totalUpdatedRecord++
							dataResponse = append(dataResponse, resModel)
						}
					}
				} else {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.deviceid_not_found"))
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			} else {
				// create new sygic license
				resModel.PassBodyJSONToModelDeviceLicense(bp)
				resultFind := db.Where("DeviceID = ?", resModel.DeviceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
				if resultFind.RowsAffected > 0 {
					if resModel.Status == 1 {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, resModel)
						// actived
						//itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_activated"))
					} else {
						oldStatus := resModel.Status
						resModel.PassBodyJSONToModelDeviceLicense(bp)
						resModel.ModifiedBy = accountKey
						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(resModel)
						if err != nil {
							var (
								errValid interface{}
							)
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								errValid = e.Translate(trans)
							}
							errResponse := GetErrorResponseErrorMessage(k, errValid)
							errorsResponse = append(errorsResponse, errResponse)
						} else {
							// @TODO call to Sygic if status = 1
							sygicURL := libs.GetSygicRootURL(sygicURLROOT)
							sygicURL = sygicURL + "/activate"
							if resModel.Status == 1 {
								if sygicURL == "" {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygicurl_not_found"))
								}
								if sygicAPIKey == "" {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygicapikey_not_found"))
								}
								if sygicProductID == "" {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygicproductid_not_found"))
								}
								if sygicPurchasePeriod == "" {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygicpurchaseperiod_not_found"))
								}
								if itemMsgError == "" {
									// reset old status
									resModel.Status = oldStatus
									//bodySygic := make([]interface{}, 0)
									bodyData := make(map[string]interface{})
									bodyData["licenseIdentifierType"] = "device"
									bodyData["identifier"] = resModel.DeviceID
									bodyData["note"] = "activationnote"
									bodySygic := []interface{}{bodyData}

									/* sygicURL := "https://api.bls.sygic.com/api/v1/activate"
									   sygicProductID = "4206"
									   sygicPurchasePeriod = "3" */
									headers := make(map[string]interface{})
									//headers["X-api_key"] = "edricewduydfrfrpobradriofdurdrcp"
									headers["X-api_key"] = sygicAPIKey
									headers["Content-Type"] = "application/json"
									params := make(map[string]interface{})
									params["productId"] = sygicProductID
									params["purchasePeriod"] = sygicPurchasePeriod
									statusRes, _, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
									var sygicAPIRespone models.SygicAPIRespone
									json.Unmarshal(dataRes, &sygicAPIRespone)
									if statusRes == 200 {
										if sygicAPIRespone.SuccessfulCount == 1 {
											resModel.Status = 1
											resModel.Message = services.GetMessage(lang, "api.success")
										} else {
											if len(sygicAPIRespone.Errors.AlreadyActivated) > 0 {
												resModel.Status = 1
												itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_activated")+": "+sygicAPIRespone.Errors.AlreadyActivated[0])
											} else if len(sygicAPIRespone.Errors.InvalidProduct) > 0 {
												itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_invalid_product")+": "+sygicAPIRespone.Errors.InvalidProduct[0])
											}

											if len(sygicAPIRespone.Errors.NotFound) > 0 {
												for _, notFound := range sygicAPIRespone.Errors.NotFound {
													itemMsgError = libs.GetStringWithWordBetween(itemMsgError, notFound+": "+services.GetMessage(lang, "api.sygic_not_found"))
												}
											}
											if len(sygicAPIRespone.Errors.InvalidLicenseAction) > 0 {
												for _, invalid := range sygicAPIRespone.Errors.InvalidLicenseAction {
													itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_license"))
												}
											}
											if len(sygicAPIRespone.Errors.MaxRepairCountReached) > 0 {
												for _, invalid := range sygicAPIRespone.Errors.MaxRepairCountReached {
													itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_max_repair_count_reached"))
												}
											}
											if len(sygicAPIRespone.Errors.AlreadyDeactivated) > 0 {
												for _, invalid := range sygicAPIRespone.Errors.AlreadyDeactivated {
													itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_already_deactivated"))
												}
											}
											if len(sygicAPIRespone.Errors.NotEnoughLicenses) > 0 {
												for _, invalid := range sygicAPIRespone.Errors.NotEnoughLicenses {
													itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_not_enough_licenses"))
												}
											}
											if itemMsgError == "" {
												itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_error"))
											}
										}
									} else {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
									}
								} else {
									resModel.Status = oldStatus
								}
							}
							if itemMsgError != "" {
								resModel.Message = itemMsgError
							}
							resultSave := db.Save(&resModel)
							if resultSave.Error == nil {
								// @TODO add or update translation table
								if itemMsgError == "" {
									totalUpdatedRecord++
									dataResponse = append(dataResponse, resModel)
								}
							} else {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
							}
						}
					}
				} else {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.deviceid_not_found"))
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Device
	)
	arrID := make([]string, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.DeviceID)
	}
	if len(arrID) > 0 {
		db.Where("DeviceID in (?)", arrID).Find(&resModels)
		data = ConvertArrayDeviceToArrayResponse(requestHeader, resModels, lang)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetSygicDownloadURL godoc
// @Summary GetSygicDownloadURL
// @Description GetSygicDownloadURL
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getsygicdownloadurl [get]
func GetSygicDownloadURL(c *gin.Context) {
	defer libs.RecoverError(c, "GetSygicDownloadURL")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)

	var (
		sygicProductID      string
		sygicPurchasePeriod string
		sygicURL            string
		sygicAPIKey         string
		locationCountryCode string
		downloadURL         string
	)

	// @TODO hardcode to testing
	//locationCountryCode = "aus"
	locationCountryCode = GetSygicCountryCode(requestHeader, locationID)

	sygicLicenseConfig := libs.GetSygicLicense()
	if sygicLicenseConfig.SygicLicenseKey > 0 {
		sygicURL = sygicLicenseConfig.APIURL
		sygicAPIKey = sygicLicenseConfig.APIKey
		downloadURL = sygicLicenseConfig.DownloadURL
		for _, sygicDetail := range sygicLicenseConfig.SygicLicenseDetails {
			if strings.ToLower(sygicDetail.CountryCode) == locationCountryCode {
				sygicProductID = sygicDetail.ProductID
				sygicPurchasePeriod = sygicDetail.PurchasePeriod
			}
		}
		var resData = make(map[string]interface{})
		resData["APIURL"] = sygicURL
		resData["DownloadURL"] = downloadURL
		resData["APIKey"] = sygicAPIKey
		resData["ProductID"] = sygicProductID
		resData["PurchasePeriod"] = sygicPurchasePeriod
		resData["CountryCode"] = locationCountryCode
		msg = services.GetMessage(lang, "api.success")
		data = resData
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetSygicCountryCode func
func GetSygicCountryCode(requestHeader models.RequestHeader, locationID int) string {
	var (
		locationModel       models.Location
		timezoneModel       models.Timezone
		locationCountryCode string
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFindLocation := db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&locationModel)
	if resultFindLocation.RowsAffected > 0 {
		resultFindTimezone := db.Where("TimeZoneID = ?", locationModel.TimeZoneID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&timezoneModel)
		if resultFindTimezone.RowsAffected > 0 {
			locationCountryCode = strings.ToLower(timezoneModel.CountryCode)
		}
	}
	return locationCountryCode
}

// SygicDeactivateDevice
// @Summary SygicDeactivateDevice
// @Description SygicDeactivateDevice
// @Tags Sygic
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Device body []models.DeviceResponse true "Sygic Deactivate Device"
// @Success 200 {object} models.APIResponseData
// @Router /sygicdeactivatedevice/{deviceid} [post]
func SygicDeactivateDevice(c *gin.Context) {
	defer libs.RecoverError(c, "SygicDeactivateDevice")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, errors    interface{}
		errorsResponse []models.ErrorResponse
		itemMsgError   string
		dataResponses  = make([]models.JourneyResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	deviceID := c.Param("deviceid")

	var (
		sygicProductID      string
		sygicPurchasePeriod string
		sygicURL            string
		sygicAPIKey         string
		locationCountryCode string
	)

	locationCountryCode = GetSygicCountryCode(requestHeader, locationID)
	// @TODO hardcode to testing
	//locationCountryCode = "aus"

	sygicLicenseConfig := libs.GetSygicLicense()

	if sygicLicenseConfig.SygicLicenseKey > 0 {
		sygicURL = sygicLicenseConfig.APIURL
		sygicAPIKey = sygicLicenseConfig.APIKey
		for _, sygicDetail := range sygicLicenseConfig.SygicLicenseDetails {
			if strings.ToLower(sygicDetail.CountryCode) == locationCountryCode {
				sygicProductID = sygicDetail.ProductID
				sygicPurchasePeriod = sygicDetail.PurchasePeriod
			}
		}
	}

	bodyData := make(map[string]interface{})
	bodyData["licenseIdentifierType"] = "device"
	bodyData["identifier"] = deviceID
	bodyData["note"] = "deactivatenote"
	bodySygic := []interface{}{bodyData}

	headers := make(map[string]interface{})
	headers["X-api_key"] = sygicAPIKey
	headers["Content-Type"] = "application/json"
	params := make(map[string]interface{})
	params["productId"] = sygicProductID
	params["purchasePeriod"] = sygicPurchasePeriod
	sygicURL = libs.GetSygicRootURL(sygicURL)
	sygicURL = sygicURL + "/licenseservices/deactivate"
	statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
	var sygicAPIRespone models.SygicAPIRespone
	json.Unmarshal(dataRes, &sygicAPIRespone)
	if statusRes == 200 {
		if sygicAPIRespone.SuccessfulCount == 1 {
			// delete old
			var oldDeviceModel models.Device
			resultFindDevice := db.Where("DeviceID = ?", deviceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&oldDeviceModel)
			if resultFindDevice.RowsAffected > 0 {
				oldDeviceModel.IsDeleted = true
				oldDeviceModel.ModifiedBy = accountKey
				deletedResult := db.Save(&oldDeviceModel)
				if deletedResult.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, deletedResult.Error.Error())
				}
			}
		} else {
			status = 422
			if len(sygicAPIRespone.Errors.NotFound) > 0 {
				for _, notFound := range sygicAPIRespone.Errors.NotFound {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, notFound+": "+services.GetMessage(lang, "api.sygic_not_found"))
				}
			}
			if len(sygicAPIRespone.Errors.InvalidLicenseAction) > 0 {
				for _, invalid := range sygicAPIRespone.Errors.InvalidLicenseAction {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_license"))
				}
			}
			if len(sygicAPIRespone.Errors.MaxRepairCountReached) > 0 {
				for _, invalid := range sygicAPIRespone.Errors.MaxRepairCountReached {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_max_repair_count_reached"))
				}
			}
			if len(sygicAPIRespone.Errors.AlreadyDeactivated) > 0 {
				for _, invalid := range sygicAPIRespone.Errors.AlreadyDeactivated {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_already_deactivated"))
				}
			}
			if len(sygicAPIRespone.Errors.NotEnoughLicenses) > 0 {
				for _, invalid := range sygicAPIRespone.Errors.NotEnoughLicenses {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_not_enough_licenses"))
				}
			}
			if itemMsgError == "" {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_error"))
			}
		}
	} else {
		status = statusRes
		if sygicAPIRespone.Message != "" {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
		} else {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", msgRes))
		}
	}

	if itemMsgError != "" {
		if status == 200 {
			status = 500
		}
		msg = itemMsgError
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	errors = errorsResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = dataResponses
	libs.APIResponseData(response, c, status)
}

// SygicReplaceDevice
// @Summary Sygic Replace Device
// @Description Sygic Replace Device
// @Tags Sygic
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Device body []models.DeviceResponse true "Sygic Replace Device"
// @Success 200 {object} models.APIResponseData
// @Router /sygicreplacedevice/{deviceid} [post]
func SygicReplaceDevice(c *gin.Context) {
	defer libs.RecoverError(c, "SygicReplaceDevice")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, errors    interface{}
		errorsResponse []models.ErrorResponse
		itemMsgError   string
		dataResponses  = make([]models.JourneyResponse, 0)
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	var oldDeviceModel models.Device
	resultFindOldDevice := db.Where("Status = 2").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&oldDeviceModel)
	if resultFindOldDevice.RowsAffected > 0 {
		var (
			sygicProductID      string
			sygicPurchasePeriod string
			sygicURL            string
			sygicAPIKey         string
			locationCountryCode string
		)

		newDeviceID := c.Param("newdeviceid")

		locationCountryCode = GetSygicCountryCode(requestHeader, locationID)
		// @TODO hardcode to testing
		//locationCountryCode = "aus"

		sygicLicenseConfig := libs.GetSygicLicense()

		if sygicLicenseConfig.SygicLicenseKey > 0 {
			sygicURL = sygicLicenseConfig.APIURL
			sygicAPIKey = sygicLicenseConfig.APIKey
			for _, sygicDetail := range sygicLicenseConfig.SygicLicenseDetails {
				if strings.ToLower(sygicDetail.CountryCode) == locationCountryCode {
					sygicProductID = sygicDetail.ProductID
					sygicPurchasePeriod = sygicDetail.PurchasePeriod
				}
			}
		}

		bodyData := make(map[string]interface{})

		bodyDataLicense := make(map[string]interface{})
		bodyDataLicense["sourceIdentifier"] = oldDeviceModel.DeviceID
		bodyDataLicense["destinationIdentifier"] = newDeviceID
		bodyDataLicenseSygic := []interface{}{bodyDataLicense}
		bodyData["licenses"] = bodyDataLicenseSygic

		bodyData["note"] = "reactivate"
		bodySygic := bodyData

		headers := make(map[string]interface{})
		headers["X-api_key"] = sygicAPIKey
		headers["Content-Type"] = "application/json"
		params := make(map[string]interface{})
		params["productId"] = sygicProductID
		params["purchasePeriod"] = sygicPurchasePeriod
		sygicURL = libs.GetSygicRootURL(sygicURL)
		sygicURL = sygicURL + "/licenseservices/reactivate"
		statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
		var sygicAPIRespone models.SygicAPIRespone
		json.Unmarshal(dataRes, &sygicAPIRespone)
		if statusRes == 200 {
			if sygicAPIRespone.SuccessfulCount == 1 {
				// delete old
				oldDeviceModel.IsDeleted = true
				oldDeviceModel.ModifiedBy = accountKey
				deletedResult := db.Save(&oldDeviceModel)
				if deletedResult.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, deletedResult.Error.Error())
				}
				if itemMsgError == "" {
					// create new
					var objectsJSON map[string]interface{}
					body, _ := ioutil.ReadAll(c.Request.Body)
					json.Unmarshal([]byte(string(body)), &objectsJSON)
					var (
						obj models.Device
					)
					obj.PassBodyJSONToModel(objectsJSON)
					obj.DeviceID = newDeviceID
					obj.Status = 1
					obj.CreatedBy = accountKey
					obj.ModifiedBy = accountKey
					resultCreate := db.Save(&obj)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					}
				}
			} else {
				status = 422
				if len(sygicAPIRespone.Errors.NotFound) > 0 {
					for _, notFound := range sygicAPIRespone.Errors.NotFound {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, notFound+": "+services.GetMessage(lang, "api.sygic_not_found"))
					}
				}
				if len(sygicAPIRespone.Errors.InvalidLicenseAction) > 0 {
					for _, invalid := range sygicAPIRespone.Errors.InvalidLicenseAction {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_license"))
					}
				}
				if len(sygicAPIRespone.Errors.MaxRepairCountReached) > 0 {
					for _, invalid := range sygicAPIRespone.Errors.MaxRepairCountReached {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_max_repair_count_reached"))
					}
				}
				if itemMsgError == "" {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_error"))
				}
			}
		} else {
			status = statusRes
			if sygicAPIRespone.Message != "" {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", msgRes))
			}
		}
	} else {
		status = 404
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_replace_not_found"))
	}

	if itemMsgError != "" {
		if status == 200 {
			status = 500
		}
		msg = itemMsgError
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	errors = errorsResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = dataResponses
	libs.APIResponseData(response, c, status)
}

// RegisterDeviceLicense godoc
// @Summary RegisterDeviceLicense
// @Description RegisterDeviceLicense
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Device body []models.DeviceLicenseJSON true "Update Device"
// @Success 200 {object} models.APIResponseData
// @Router /registerdevicelicense [put]
func RegisterDeviceLicense(c *gin.Context) {
	defer libs.RecoverError(c, "RegisterDeviceLicense")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data          interface{}
		errorsResponse     []models.ErrorResponse
		msgError           string
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse = make([]models.ErrorResponse, 0)
	var (
		bp          map[string]interface{}
		deviceModel models.Device
	)
	json.NewDecoder(c.Request.Body).Decode(&bp)
	deviceModel.PassBodyJSONToModelDeviceLicense(bp)

	if deviceModel.DeviceID == "" {
		status = 422
		msgError = libs.GetStringWithWordBetween(msgError, services.GetMessage(lang, "api.deviceid_required"))
	}
	if status == 200 {
		var (
			sygicProductID      string
			sygicPurchasePeriod string
			sygicURLROOT        string
			sygicAPIKey         string
			locationCountryCode string
		)
		locationCountryCode = GetSygicCountryCode(requestHeader, locationID)
		// @TODO hardcode to testing
		//locationCountryCode = "aus"
		sygicLicenseConfig := libs.GetSygicLicense()
		if sygicLicenseConfig.SygicLicenseKey > 0 {
			sygicURLROOT = sygicLicenseConfig.APIURL
			sygicAPIKey = sygicLicenseConfig.APIKey
			for _, sygicDetail := range sygicLicenseConfig.SygicLicenseDetails {
				if strings.ToLower(sygicDetail.CountryCode) == locationCountryCode {
					sygicProductID = sygicDetail.ProductID
					sygicPurchasePeriod = sygicDetail.PurchasePeriod
				}
			}
		}
		oldDeviceStatus := 1
		resultFindDevice := db.Where("DeviceID = ?", deviceModel.DeviceID).First(&deviceModel)
		if resultFindDevice.RowsAffected > 0 {
			// exist
			oldDeviceStatus = deviceModel.Status
			if oldDeviceStatus != 1 {
				// licensed
				deviceModel.PassBodyJSONToModelDeviceLicense(bp)
				deviceModel.Status = oldDeviceStatus
				resultSave := db.Save(&deviceModel)
				if resultSave.Error == nil {
					totalUpdatedRecord++
					data = ConvertDeviceToResponse(requestHeader, deviceModel, lang)
				} else {
					status = 500
					msgError = libs.GetStringWithWordBetween(msgError, resultSave.Error.Error())
				}
			} else {
				// not licensed
				deviceModel.PassBodyJSONToModelDeviceLicense(bp)
				deviceModel.Status = oldDeviceStatus
				deviceModel.ModifiedBy = accountKey
				var (
					replaceDeviceModel models.Device
				)
				//resultFindReplaceDevice := db.Where("Status = 2").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&replaceDeviceModel)
				resultFindReplaceDevice := db.Where("Status = 3").First(&replaceDeviceModel)
				if resultFindReplaceDevice.RowsAffected > 0 {
					// replace sygic license
					newDeviceID := deviceModel.DeviceID
					bodyData := make(map[string]interface{})
					bodyDataLicense := make(map[string]interface{})
					bodyDataLicense["sourceIdentifier"] = replaceDeviceModel.DeviceID
					bodyDataLicense["destinationIdentifier"] = newDeviceID
					bodyDataLicenseSygic := []interface{}{bodyDataLicense}
					bodyData["licenses"] = bodyDataLicenseSygic
					bodyData["note"] = "reactivate"
					bodySygic := bodyData
					headers := make(map[string]interface{})
					headers["X-api_key"] = sygicAPIKey
					headers["Content-Type"] = "application/json"
					params := make(map[string]interface{})
					params["productId"] = sygicProductID
					params["purchasePeriod"] = sygicPurchasePeriod
					sygicURL := libs.GetSygicRootURL(sygicURLROOT)
					sygicURL = sygicURL + "/licenseservices/reactivate"
					statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
					var sygicAPIRespone models.SygicAPIRespone
					json.Unmarshal(dataRes, &sygicAPIRespone)
					if statusRes == 200 {
						var (
							successLicense    = false
							sygicLicenseError string
						)
						if sygicAPIRespone.SuccessfulCount == 1 {
							successLicense = true
							deviceModel.Status = 2
							deviceModel.Message = services.GetMessage(lang, "api.success")
						} else {
							if len(sygicAPIRespone.Errors.AlreadyActivated) > 0 {
								successLicense = true
								deviceModel.Status = 2
								deviceModel.Message = services.GetMessage(lang, "api.sygic_activated")
							}
							sygicLicenseError = GetSygicLicenseErrorMessage(lang, sygicAPIRespone)
							if sygicLicenseError != "" {
								deviceModel.Message = sygicLicenseError
							}
						}
						resultSave := db.Save(&deviceModel)
						if resultSave.Error == nil {
							if successLicense {
								totalUpdatedRecord++
								data = ConvertDeviceToResponse(requestHeader, deviceModel, lang)
								// delete old
								db.Exec(`DELETE FROM `+models.Device{}.TableName()+` WHERE DeviceID = ?`, replaceDeviceModel.DeviceID)
							} else {
								status = 422
								msgError = libs.GetStringWithWordBetween(msgError, sygicLicenseError)
							}
						} else {
							status = 500
							msgError = libs.GetStringWithWordBetween(msgError, resultSave.Error.Error())
						}
					} else {
						status = statusRes
						msgError = libs.GetStringWithWordBetween(msgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
						if msgError == "" {
							msgError = fmt.Sprintf("%v", msgRes)
						}
					}
				} else {
					// create new sygic license
					bodyData := make(map[string]interface{})
					bodyData["licenseIdentifierType"] = "device"
					bodyData["identifier"] = deviceModel.DeviceID
					bodyData["note"] = "activationnote"
					bodySygic := []interface{}{bodyData}
					headers := make(map[string]interface{})
					headers["X-api_key"] = sygicAPIKey
					headers["Content-Type"] = "application/json"
					params := make(map[string]interface{})
					params["productId"] = sygicProductID
					params["purchasePeriod"] = sygicPurchasePeriod
					sygicURL := libs.GetSygicRootURL(sygicURLROOT)
					sygicURL = sygicURL + "/activate"
					statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
					var sygicAPIRespone models.SygicAPIRespone
					json.Unmarshal(dataRes, &sygicAPIRespone)
					if statusRes == 200 {
						var (
							successLicense    = false
							sygicLicenseError string
						)
						if sygicAPIRespone.SuccessfulCount == 1 {
							successLicense = true
							deviceModel.Status = 2
							deviceModel.Message = services.GetMessage(lang, "api.success")
						} else {
							if len(sygicAPIRespone.Errors.AlreadyActivated) > 0 {
								successLicense = true
								deviceModel.Status = 2
								deviceModel.Message = services.GetMessage(lang, "api.sygic_activated")
							}
							sygicLicenseError = GetSygicLicenseErrorMessage(lang, sygicAPIRespone)
							if sygicLicenseError != "" {
								deviceModel.Message = sygicLicenseError
							}
						}
						resultSave := db.Save(&deviceModel)
						if resultSave.Error == nil {
							if successLicense {
								totalUpdatedRecord++
								data = ConvertDeviceToResponse(requestHeader, deviceModel, lang)
							} else {
								status = 422
								msgError = libs.GetStringWithWordBetween(msgError, sygicLicenseError)
							}
						} else {
							status = 500
							msgError = libs.GetStringWithWordBetween(msgError, resultSave.Error.Error())
						}
					} else {
						status = statusRes
						msgError = libs.GetStringWithWordBetween(msgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
						if msgError == "" {
							msgError = fmt.Sprintf("%v", msgRes)
						}
					}
				}
			}
		} else {
			// not found
			deviceModel.PassBodyJSONToModelDeviceLicense(bp)
			deviceModel.Status = 1
			deviceModel.CreatedBy = accountKey
			deviceModel.ModifiedBy = accountKey
			var (
				replaceDeviceModel models.Device
			)
			resultFindReplaceDevice := db.Where("Status = 3").First(&replaceDeviceModel)
			if resultFindReplaceDevice.RowsAffected > 0 {
				// replace sygic license
				newDeviceID := deviceModel.DeviceID
				bodyData := make(map[string]interface{})
				bodyDataLicense := make(map[string]interface{})
				bodyDataLicense["sourceIdentifier"] = replaceDeviceModel.DeviceID
				bodyDataLicense["destinationIdentifier"] = newDeviceID
				bodyDataLicenseSygic := []interface{}{bodyDataLicense}
				bodyData["licenses"] = bodyDataLicenseSygic
				bodyData["note"] = "reactivate"
				bodySygic := bodyData
				headers := make(map[string]interface{})
				headers["X-api_key"] = sygicAPIKey
				headers["Content-Type"] = "application/json"
				params := make(map[string]interface{})
				params["productId"] = sygicProductID
				params["purchasePeriod"] = sygicPurchasePeriod
				sygicURL := libs.GetSygicRootURL(sygicURLROOT)
				sygicURL = sygicURL + "/licenseservices/reactivate"
				statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
				var sygicAPIRespone models.SygicAPIRespone
				json.Unmarshal(dataRes, &sygicAPIRespone)
				if statusRes == 200 {
					var (
						successLicense    = false
						sygicLicenseError string
					)
					if sygicAPIRespone.SuccessfulCount == 1 {
						time := time.Now()
						successLicense = true
						deviceModel.Status = 2
						deviceModel.ActivatedDate = &time
						deviceModel.Message = services.GetMessage(lang, "api.success")
					} else {
						if len(sygicAPIRespone.Errors.AlreadyActivated) > 0 {
							successLicense = true
							deviceModel.Status = 2
							deviceModel.Message = services.GetMessage(lang, "api.sygic_activated")
						}
						sygicLicenseError = GetSygicLicenseErrorMessage(lang, sygicAPIRespone)
						if sygicLicenseError != "" {
							deviceModel.Message = sygicLicenseError
						}
					}
					deviceModel.IsDeleted = false
					resultSave := db.Save(&deviceModel)
					if resultSave.Error == nil {
						if successLicense {
							totalUpdatedRecord++
							data = ConvertDeviceToResponse(requestHeader, deviceModel, lang)
							// delete old
							db.Exec(`DELETE FROM `+models.Device{}.TableName()+` WHERE DeviceID = ?`, replaceDeviceModel.DeviceID)
						} else {
							status = 422
							msgError = libs.GetStringWithWordBetween(msgError, sygicLicenseError)
						}
					} else {
						status = 500
						msgError = libs.GetStringWithWordBetween(msgError, resultSave.Error.Error())
					}
				} else {
					status = statusRes
					msgError = libs.GetStringWithWordBetween(msgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
					if msgError == "" {
						msgError = fmt.Sprintf("%v", msgRes)
					}
				}
			} else {
				// create new sygic license
				bodyData := make(map[string]interface{})
				bodyData["licenseIdentifierType"] = "device"
				bodyData["identifier"] = deviceModel.DeviceID
				bodyData["note"] = "activationnote"
				bodySygic := []interface{}{bodyData}
				headers := make(map[string]interface{})
				headers["X-api_key"] = sygicAPIKey
				headers["Content-Type"] = "application/json"
				params := make(map[string]interface{})
				params["productId"] = sygicProductID
				params["purchasePeriod"] = sygicPurchasePeriod
				sygicURL := libs.GetSygicRootURL(sygicURLROOT)
				sygicURL = sygicURL + "/activate"
				statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", sygicURL, bodySygic, params, headers)
				var sygicAPIRespone models.SygicAPIRespone
				json.Unmarshal(dataRes, &sygicAPIRespone)
				if statusRes == 200 {
					var (
						successLicense    = false
						sygicLicenseError string
					)
					if sygicAPIRespone.SuccessfulCount == 1 {
						successLicense = true
						deviceModel.Status = 2
						deviceModel.Message = services.GetMessage(lang, "api.success")
					} else {
						if len(sygicAPIRespone.Errors.AlreadyActivated) > 0 {
							time := time.Now()
							successLicense = true
							deviceModel.Status = 2
							deviceModel.ActivatedDate = &time
							deviceModel.Message = services.GetMessage(lang, "api.sygic_activated")
						}
						sygicLicenseError = GetSygicLicenseErrorMessage(lang, sygicAPIRespone)
						if sygicLicenseError != "" {
							deviceModel.Message = sygicLicenseError
						}
					}
					resultCreate := db.Create(&deviceModel)
					if resultCreate.Error == nil {
						if successLicense {
							totalUpdatedRecord++
							data = ConvertDeviceToResponse(requestHeader, deviceModel, lang)
						} else {
							status = 422
							msgError = libs.GetStringWithWordBetween(msgError, sygicLicenseError)
						}
					} else {
						status = 500
						msgError = libs.GetStringWithWordBetween(msgError, resultCreate.Error.Error())
					}
				} else {
					status = statusRes
					msgError = libs.GetStringWithWordBetween(msgError, sygicAPIRespone.Message+" - "+fmt.Sprintf("%v", headers["X-api_key"]))
					if msgError == "" {
						msgError = fmt.Sprintf("%v", msgRes)
					}
				}
			}
		}
	}

	if msgError != "" {
		msg = msgError
		errResponse := GetErrorResponseErrorMessage(0, msgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetSygicLicenseErrorMessage(lang string, sygicAPIRespone models.SygicAPIRespone) string {
	var (
		itemMsgError string
	)
	/* for _, invalid := range sygicAPIRespone.Errors.AlreadyActivated {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_activated"))
	} */
	for _, invalid := range sygicAPIRespone.Errors.InvalidProduct {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_product"))
	}
	for _, invalid := range sygicAPIRespone.Errors.NotFound {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_not_found"))
	}
	for _, invalid := range sygicAPIRespone.Errors.InvalidLicenseAction {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_invalid_license"))
	}
	for _, invalid := range sygicAPIRespone.Errors.MaxRepairCountReached {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_max_repair_count_reached"))
	}
	for _, invalid := range sygicAPIRespone.Errors.AlreadyDeactivated {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_already_deactivated"))
	}
	for _, invalid := range sygicAPIRespone.Errors.NotEnoughLicenses {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_not_enough_licenses"))
	}
	for _, invalid := range sygicAPIRespone.Errors.ProductServerError {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, invalid+": "+services.GetMessage(lang, "api.sygic_product_server_error"))
	}
	/* if itemMsgError == "" {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.sygic_error"))
	} */
	return itemMsgError
}

// DeleteDevice godoc
// @Summary Replace Device
// @Description Replace Device
// @Tags Device
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Device ID"
// @Success 200 {object} models.APIResponseData
// @Router /replacedevice/{deviceid} [put]
func ReplaceDevice(c *gin.Context) {
	defer libs.RecoverError(c, "ReplaceDevice")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("deviceid")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.Device
		)
		resultFind := db.Where("DeviceID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.Status = 3 // Ready for Replacement
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}
