package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetSchedule godoc
// @Summary Get Schedule
// @Description Get Schedule
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param FromDate query string false "FromDate: yyyy-mm-dd"
// @Param ToDate query string false "ToDate: yyyy-mm-dd"
// @Param JourneyCode query string false "JourneyCode"
// @Param ResourceID query int false "ResourceID"
// @Param UserID query int false "UserID"
// @Param JobID query int false "JobID"
// @Param JobTaskID query int false "JobTaskID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /schedule [get]
func GetSchedule(c *gin.Context) {
	defer libs.RecoverError(c, "GetSchedule")
	var (
		status        = libs.GetStatusSuccess()
		schedules     []models.Schedule
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	usePaging := false
	errorsResponse := make([]models.ErrorResponse, 0)
	vUsePaging, sUsePaging := libs.GetQueryParam("usepaging", c)
	if sUsePaging {
		bUsePaging, eUsePaging := strconv.ParseBool(vUsePaging)
		if eUsePaging == nil {
			usePaging = bUsePaging
		}
	}
	var bp = db
	if usePaging {
		// Paging
		vStart, sStart := libs.GetQueryParam("Start", c)
		vLength, sLength := libs.GetQueryParam("Length", c)
		if !sStart {
			vStart = os.Getenv("PAGE_DEFAULT")
		} else {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
		}
		if !sLength {
			vLength = os.Getenv("PAGE_SIZE")
		}
		vStartInt, _ := strconv.Atoi(vStart)
		vLengthInt, _ := strconv.Atoi(vLength)
		bp = bp.Limit(vLengthInt).Offset(vStartInt)
	}

	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}

	// Filter
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"JourneyCode"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"ResourceID", "UserID", "JobID", "JobTaskID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	format := libs.MYSQLDATE
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			vFromDate = dFromDate.Format(format)
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			vToDate = dToDate.Format(format)
		}
	}
	if sFromDate && sToDate {
		bp = bp.Where("ScheduleEndDate > ? AND ScheduleStartDate < ? ", vFromDate, vToDate)
	} else if sFromDate {
		bp = bp.Where("ScheduleStartDate >= ?", vFromDate)
	} else if sToDate {
		bp = bp.Where("ScheduleStartDate <= ?", vToDate)
	}

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	// Additional
	additionalScheulesID := make([]int, 0)
	var resources []models.Resource
	var re = db
	re = re.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	if locationID > 0 {
		re = re.Where("LocationID = ?", locationID)
	}
	arrBoolAdditional := []string{"ShowInScheduler"}
	re = libs.FilterBool(arrBoolAdditional, re, c)
	re.Find(&resources)
	if len(resources) > 0 {
		arrResourcesID := make([]int, 0)
		for _, re := range resources {
			arrResourcesID = append(arrResourcesID, re.ResourceID)
		}
		var additionalScheules []models.Schedule
		var se = db
		se = se.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		se = se.Where("LocationID <> ?", locationID)
		se = se.Where("ResourceID in (?)", arrResourcesID)
		if sFromDate && sToDate {
			se = se.Where("ScheduleEndDate > ? AND ScheduleStartDate < ? ", vFromDate, vToDate)
		} else if sFromDate {
			se = se.Where("ScheduleStartDate >= ?", vFromDate)
		} else if sToDate {
			se = se.Where("ScheduleStartDate <= ?", vToDate)
		}
		se.Find(&additionalScheules)
		for _, as := range additionalScheules {
			additionalScheulesID = append(additionalScheulesID, as.ScheduleID)
		}
	}
	if len(additionalScheulesID) > 0 {
		bp = bp.Or("ScheduleID in (?)", additionalScheulesID)
	}
	resultRow := bp.Find(&schedules).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(schedules) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySchedulesToArrayResponse(requestHeader, schedules, lang)
	if status == 200 {
		countCreateNew := 0
		arrScheduleFromRecurringJob := GetListScheduleFromRecurringJob(requestHeader, lang, c, accountKey)
		if len(arrScheduleFromRecurringJob) > 0 {
			for _, recurringJobObj := range arrScheduleFromRecurringJob {
				var (
					schedulesCompare []models.Schedule
					canCreated       = true
				)
				db.Joins(
					"JOIN jobs ON jobs.JobID = schedules.JobID",
				).Where(
					"IFNULL(schedules.IsDeleted, 0) <> 1 AND IFNULL(schedules.IsArchived, 0) <> 1 AND jobs.RecurringJobID = ?",
					recurringJobObj.JobID,
				).Find(&schedulesCompare)
				for _, scheduleObj := range schedulesCompare {
					var jobTaskModel models.JobTask
					resultFindJobTask := db.Where("JobTaskID = ?", scheduleObj.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
					if resultFindJobTask.RowsAffected > 0 {
						if jobTaskModel.JobType == recurringJobObj.JobSummary.JobTask.JobType {
							dResponseObjScheduleStartDateOnlyDate, _ := libs.ConvertStringToDateTime(scheduleObj.ScheduleStartDate.Format(libs.FORMATDATE))
							dRecurringJobObjScheduleStartDateOnlyDate, _ := libs.ConvertStringToDateTime(recurringJobObj.ScheduleStartDate.Format(libs.FORMATDATE))
							if dResponseObjScheduleStartDateOnlyDate.Unix() == dRecurringJobObjScheduleStartDateOnlyDate.Unix() {
								canCreated = false
								break
							}
						}
					}
				}
				if canCreated {
					// Create Job & Schedule
					response := CreateRecurringSchedule(requestHeader, lang, accountKey, recurringJobObj, c)
					responses = append(responses, response)
					countCreateNew++
				}

			}
		}
		totalCount = totalCount + int64(countCreateNew)
		if totalCount > 0 {
			if status == 200 {
				msg = services.GetMessage(lang, "api.success")
			}
		}
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}
func CreateRecurringSchedule(requestHeader models.RequestHeader, lang string, accountKey int, recurringJobObj models.ScheduleResponse, c *gin.Context) models.ScheduleResponse {
	var (
		scheduleObjPOST models.JourneyBodyJSON
	)
	scheduleObjPOST.ScheduleID = recurringJobObj.ScheduleID
	scheduleObjPOST.ResourceID = recurringJobObj.ResourceID
	scheduleObjPOST.ScheduleStartDate = &recurringJobObj.ScheduleStartDate
	scheduleObjPOST.ScheduleEndDate = &recurringJobObj.ScheduleEndDate
	scheduleObjPOST.LocationID = recurringJobObj.LocationID
	scheduleObjPOST.UserID = recurringJobObj.UserID
	scheduleObjPOST.FirstName = recurringJobObj.FirstName
	scheduleObjPOST.LastName = recurringJobObj.LastName
	scheduleObjPOST.JobID = recurringJobObj.JobID
	scheduleObjPOST.JobTaskID = recurringJobObj.JobTaskID
	scheduleObjPOST.JourneyCode = recurringJobObj.JourneyCode
	scheduleObjPOST.JobStatus = recurringJobObj.JobStatus
	scheduleObjPOST.JobStatusName = recurringJobObj.JobStatusName
	scheduleObjPOST.JobStatusIcon = recurringJobObj.JobStatusIcon
	scheduleObjPOST.JobSummary = recurringJobObj.JobSummary
	scheduleObjPOST.ScheduleStartDateTimeZone = recurringJobObj.ScheduleStartDateTimeZone
	scheduleObjPOST.ScheduleEndDateTimeZone = recurringJobObj.ScheduleEndDateTimeZone

	scheduleObj := CreateRecurringJob(accountKey, scheduleObjPOST.JobID, scheduleObjPOST.JobTaskID, requestHeader, scheduleObjPOST, c)
	response := ConvertScheduleToResponse(requestHeader, scheduleObj, lang)
	return response
}

// GetScheduleByID godoc
// @Summary Get Schedule By ID
// @Description Get Schedule  By ID
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param id path int true "Schedule ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /schedule/{id} [get]
func GetScheduleByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetScheduleByID")
	var (
		status        = libs.GetStatusSuccess()
		schedules     models.Schedule
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ScheduleID = ?", ID).First(&schedules)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertScheduleToResponse(requestHeader, schedules, lang)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CheckReschedule godoc
// @Summary Get Schedule By ID
// @Description Get Schedule  By ID
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param id path int true "Schedule ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkreschedule/{id} [get]
func CheckReschedule(c *gin.Context) {
	defer libs.RecoverError(c, "CheckReschedule")
	var (
		status        = libs.GetStatusSuccess()
		schedules     models.Schedule
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsArchived, 0) <> 1 AND ScheduleID = ?", ID).First(&schedules)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"IsReschedule": schedules.IsReschedule, "RescheduleComment": schedules.RescheduleComment,
			"RescheduleDateTime": schedules.RescheduleDateTime, "RescheduleUserID": schedules.RescheduleUserID}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CheckReschedule godoc
// @Summary Get Schedule By ID
// @Description Get Schedule  By ID
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param id path int true "Schedule ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkreschedulejob/{jobid} [get]
func CheckRescheduleJob(c *gin.Context) {
	defer libs.RecoverError(c, "CheckRescheduleJob")
	var (
		status        = libs.GetStatusSuccess()
		schedules     models.Schedule
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("jobid")
	resultRow := db.Where("IFNULL(IsArchived, 0) <> 1 AND IsReschedule = 0 AND IFNULL(IsArchived, 0) <> 1  AND JobID = ?", ID).First(&schedules)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"IsReschedule": false}
	} else {
		msg = services.GetMessage(lang, "api.success")
		data = map[string]interface{}{"IsReschedule": true}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateSchedule godoc
// @Summary Create Schedule
// @Description Create Schedule
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Schedule body models.ScheduleResponse true "Create Schedule"
// @Success 200 {object} models.APIResponseData
// @Router /schedule [post]
func CreateSchedule(c *gin.Context) {
	defer libs.RecoverError(c, "CreateSchedule")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.ScheduleResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	var (
		schedule models.Schedule

		itemMsgError string
	)
	schedule.PassBodyJSONToModel(objectsJSON)
	schedule.CreatedBy = accountKey
	schedule.ModifiedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(schedule)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {

		resultCreate := db.Create(&schedule)
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {

			totalUpdatedRecord++
			var (
				job     models.Job
				jobTask models.JobTask
			)
			// update job status = 1=Scheduled by jobid on schedules table
			resultFindJob := db.Where("JobID = ?", schedule.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
			if resultFindJob.RowsAffected > 0 {
				UpdateJobStatus(requestHeader, schedule.JobID, 1, accountKey, c)
				// update job status for master job combined
				UpdateJobStatusForMasterJobCombined(requestHeader, schedule.JobID, accountKey)
			}

			// update schedule start date & end date
			resultFindJobTask := db.Where("JobTaskID = ?", schedule.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
			if resultFindJobTask.RowsAffected > 0 {
				jobTask.ModifiedBy = accountKey
				jobTask.ScheduleStartDateTime = &schedule.ScheduleStartDate
				jobTask.ScheduleEndDateTime = &schedule.ScheduleEndDate

				val, res := services.ConvertJSONValueToVariable("ArrivalTime", objectsJSON)
				if res != nil {
					vEstimatedArrivalDateTime, sEstimatedArrivalDateTime := services.ConvertStringToDateTime(val)
					if sEstimatedArrivalDateTime == nil {
						jobTask.EstimatedArrivalDateTime = &vEstimatedArrivalDateTime
					}
				}
				db.Save(&jobTask)
			}

			// Update additional users
			UpdateAdditionalUser(accountKey, schedule, requestHeader, objectsJSON)

			dataResponse = ConvertScheduleToResponse(requestHeader, schedule, lang)
			data = dataResponse
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateSchedule godoc
// @Summary Update Schedule
// @Description Update Schedule
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Schedule body models.ScheduleResponse true "Create Schedule"
// @Success 200 {object} models.APIResponseData
// @Router /schedule [put]
func UpdateSchedule(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSchedule")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.ScheduleResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		schedule     models.Schedule
		itemMsgError string
	)
	schedule.PassBodyJSONToModel(objectsJSON)
	resultFind := db.Where("ScheduleID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", schedule.ScheduleID).First(&schedule)
	if resultFind.RowsAffected > 0 {
		schedule.PassBodyJSONToModel(objectsJSON)
		schedule.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(schedule)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resultSave := db.Save(&schedule)
			if resultSave.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
			} else {
				// Update EstimatedArrivalDateTime
				var (
					jobTask models.JobTask
				)
				jobTaskFind := db.Where("JobTaskID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", schedule.JobTaskID).First(&jobTask)

				if jobTaskFind.RowsAffected > 0 {
					val, res := services.ConvertJSONValueToVariable("ArrivalTime", objectsJSON)
					if res != nil {
						vEstimatedArrivalDateTime, sEstimatedArrivalDateTime := services.ConvertStringToDateTime(val)
						if sEstimatedArrivalDateTime == nil {
							jobTask.EstimatedArrivalDateTime = &vEstimatedArrivalDateTime
							db.Save(&jobTask)
						}
					}
				}
				totalUpdatedRecord++

				// Update additional users
				UpdateAdditionalUser(accountKey, schedule, requestHeader, objectsJSON)
				dataResponse = ConvertScheduleToResponse(requestHeader, schedule, lang)
				data = dataResponse
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteSchedule godoc
// @Summary Delete Schedule
// @Description Delete Schedule
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Schedule ID"
// @Success 200 {object} models.APIResponseData
// @Router /schedule/{id} [delete]
func DeleteSchedule(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteSchedule")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
		fullCombined       = false
		permanentDelete    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)

	vFullCombined, sFullCombined := libs.GetQueryParam("fullcombined", c)
	if sFullCombined {
		bFullCombined, eFullCombined := strconv.ParseBool(vFullCombined)
		if eFullCombined == nil {
			fullCombined = bFullCombined
		}
	}
	vPermanentDelete, sPermanentDelete := libs.GetQueryParam("permanent", c)
	if sPermanentDelete {
		permanentDelete, _ = strconv.ParseBool(vPermanentDelete)
	}
	for k, id := range arrID {
		var (
			uModel    models.Schedule
			job       models.Job
			canDelete = true
		)

		resultFind := db.Where("ScheduleID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", id).First(&uModel)
		if resultFind.RowsAffected > 0 {

			if !fullCombined {
				resultFindJob := db.Select("JobID, IsCombinedChild").Where("JobID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsCombinedChild, 0) = ?", uModel.JobID, true).First(&job)
				if resultFindJob.RowsAffected > 0 {
					if job.IsCombinedChild {
						sql := `SELECT COUNT(RelatedJobID) AS Count FROM jobsselection js JOIN ( 
					SELECT JobID FROM jobsselection 
					WHERE IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND RelatedJobID = ?) AS jo ON js.JobID = jo.JobID
					WHERE  IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1`
						rows, err := db.Raw(sql, job.JobID).Rows()
						if rows != nil {
							defer rows.Close()
						}
						if err == nil {
							for rows.Next() {
								var (
									count = 0
								)
								rows.Scan(&count)
								if count <= 2 {
									canDelete = false
								}
							}
						}
					}
				}
			}

			if canDelete {
				var deletedResult *gorm.DB
				if !permanentDelete {
					uModel.IsDeleted = true
					deletedResult = db.Save(&uModel)
				} else {
					sqlDeleteSchedule := `DELETE FROM ` + models.Schedule{}.TableName() + ` WHERE ScheduleID = ?`
					deletedResult = db.Exec(sqlDeleteSchedule, id)
				}
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// update job status = 0
					sqlResetJob := `UPDATE ` + models.Job{}.TableName() + ` SET Status = 0, ModifiedBy = ?  WHERE JobID = ?`
					db.Exec(sqlResetJob, accountKey, uModel.JobID)

					// update jobtask
					sqlResetJobTask := `UPDATE ` + models.JobTask{}.TableName() + ` SET ScheduleStartDateTime = NULL, ScheduleEndDateTime = NULL, ModifiedBy = ?  WHERE JobID = ?`
					db.Exec(sqlResetJobTask, accountKey, uModel.JobID)

					// update additionalusers
					sqlResetAddUser := `DELETE FROM ` + models.AdditionalUser{}.TableName() + ` WHERE ScheduleID = ?`
					db.Exec(sqlResetAddUser, id)

					// update precomputedroutes
					sqlResetprecomputedroutes := `DELETE FROM ` + models.PrecomputedRoute{}.TableName() + ` WHERE TaskID = ?`
					db.Exec(sqlResetprecomputedroutes, uModel.JobTaskID)

					// @TODO - Delete Combined Job schedule
					if fullCombined {
						sql := `SELECT sc.ScheduleID, sc.JobID FROM schedules sc JOIN (SELECT jt.JobID, jt.JobTaskID FROM jobtasks jt WHERE JobID IN (
						SELECT RelatedJobID FROM jobsselection js JOIN (
						SELECT js.JobID FROM jobsselection js 
						JOIN (
						SELECT JobID FROM schedules sc 
						WHERE IFNULL(sc.IsReschedule, 0) <> 1 AND sc.ScheduleID = ?) as sjob 
						ON js.RelatedJobID = sjob.JobID) AS rj ON js.JobID = rj.JobID)) AS sj
						ON sc.JobID = sj.JobID AND sc.JobTaskID = sj.JobTaskID
						WHERE IFNULL(sc.IsReschedule, 0) <> 1 AND IFNULL(sc.IsDeleted, 0) <> 1 AND IFNULL(sc.IsArchived, 0) <> 1`

						rows, err := db.Raw(sql, id).Rows()
						if rows != nil {
							defer rows.Close()
						}
						if err == nil {
							for rows.Next() {
								var (
									scheduleID = 0
									jobID      = 0
								)
								rows.Scan(&scheduleID, &jobID)

								db.Where("ScheduleID = ? ", scheduleID).
									Model(&models.Schedule{}).Updates(models.Schedule{IsDeleted: true, ModifiedBy: accountKey})

								// update job status = 0
								sqlResetJob := `UPDATE ` + models.Job{}.TableName() + ` SET Status = 0, ModifiedBy = ?  WHERE JobID = ?`
								db.Exec(sqlResetJob, accountKey, jobID)

								// update jobtask
								sqlResetJobTask := `UPDATE ` + models.JobTask{}.TableName() + ` SET ScheduleStartDateTime = NULL, ScheduleEndDateTime = NULL, ModifiedBy = ?  WHERE JobID = ?`
								db.Exec(sqlResetJobTask, accountKey, jobID)

								// update additionalusers
								sqlResetAddUser := `DELETE FROM ` + models.AdditionalUser{}.TableName() + ` WHERE ScheduleID = ?`
								db.Exec(sqlResetAddUser, scheduleID)

								// find job combine master
								var jobSelection models.JobSelection
								resultFindJobSelection := db.Where("RelatedJobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
								if resultFindJobSelection.RowsAffected > 0 {
									// update job status = 0
									sqlResetJob := `UPDATE ` + models.Job{}.TableName() + ` SET Status = 0, ModifiedBy = ?  WHERE JobID = ?`
									db.Exec(sqlResetJob, accountKey, jobSelection.JobID)
								}
							}
						}
					}
					// @TODO - Delete job selection & reset IsCombinedChild = 0
					if job.IsCombinedChild {
						// update job IsCombinedChild = 0
						sqlResetJob := `UPDATE ` + models.Job{}.TableName() + ` SET IsCombinedChild = 0, ModifiedBy = ?  WHERE JobID = ?`
						db.Exec(sqlResetJob, accountKey, uModel.JobID)

						// delete job selections - find master job
						sql := `SELECT JobID FROM jobsselection 
							WHERE IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND RelatedJobID = ?`
						rows, err := db.Raw(sql, job.JobID).Rows()
						if rows != nil {
							defer rows.Close()
						}
						if err == nil {
							for rows.Next() {
								var (
									jobID = 0
								)
								rows.Scan(&jobID)
								sqlDeleteJobSelection := `UPDATE ` + models.JobSelection{}.TableName() + ` SET IsDeleted = 1, ModifiedBy = ?  
									WHERE IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ? AND RelatedJobID = ?`
								db.Exec(sqlDeleteJobSelection, accountKey, jobID, uModel.JobID)

								sqlResetSequence := `UPDATE ` + models.JobSelection{}.TableName() + ` 
								INNER JOIN (SELECT COUNT(*) AS CNT, JobSelectionID FROM jobsselection WHERE HasSequence = 1 
								AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?) AS C
								ON C.CNT <= 1  AND jobsselection.JobSelectionID = C.JobSelectionID
								SET HasSequence = 0 
								WHERE IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobID = ?`
								db.Exec(sqlResetSequence, jobID, jobID)
							}
						}
					}
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, services.GetMessage(lang, "api.cannotdeletejobselection"))
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// CheckAssignResource godoc
// @Summary CheckAssignResource
// @Description CheckAssignResource
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkassignresource [get]
// App
func CheckAssignResource(c *gin.Context) {
	defer libs.RecoverError(c, "CheckAssignResource")
	var (
		status                   = libs.GetStatusSuccess()
		scheduleModels           []models.Schedule
		userModel                models.User
		resourceModels           []models.Resource
		requestHeader            models.RequestHeader
		response                 models.APIResponseData
		msg, data                interface{}
		unAssignedScheduleModels []models.Schedule
		itemMsgError             string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}
	if status == 200 {
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
		if resultFindUser.RowsAffected > 0 {
			userID := userModel.UserID
			db.Where("IFNULL(schedules.IsDeleted, 0) <> 1 AND IFNULL(schedules.IsArchived, 0) <> 1").Where("schedules.UserID = ?", userID).
				Joins(" JOIN jobs ON (jobs.JobID = schedules.JobID AND jobs.Status = 2)").
				Where("schedules.LocationID = ?", locationID).
				Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')", fromDate, toDate).Find(&scheduleModels)
			arrResourceID := make([]int, 0)
			for _, schedule := range scheduleModels {
				var (
					job models.Job
				)

				// Check if job completed
				resultFindJob := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("JobID = ? AND Status = 7", schedule.JobID).Find(&job)
				if resultFindJob.RowsAffected <= 0 {
					arrResourceID = append(arrResourceID, schedule.ResourceID)
				}
			}

			// if  len(arrResourceID) > 0 => Assigned
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("ResourceID in (?)", arrResourceID).Find(&resourceModels)
			responses := ConvertArrayResourcesToArrayAppResponse(requestHeader, resourceModels)

			// Get unassign resource
			db.Where("IFNULL(schedules.IsDeleted, 0) <> 1 AND IFNULL(schedules.IsArchived, 0) <> 1").
				Joins(" JOIN jobs ON (jobs.JobID = schedules.JobID AND jobs.Status = 2)").
				Where("UserID <= 0").Where("schedules.LocationID = ?", locationID).Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')", fromDate, toDate).Find(&unAssignedScheduleModels)
			responses.UnAssignedResource = len(unAssignedScheduleModels)
			data = responses
			msg = services.GetMessage(lang, "api.success")

		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			data = make([]int, 0)
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		if msg == nil {
			msg = itemMsgError
		}
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// GetUnassignResource godoc
// @Summary GetUnassignResource
// @Description GetUnassignResource
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getunassignresource [get]
// App
func GetUnassignResource(c *gin.Context) {
	defer libs.RecoverError(c, "GetUnassignResource")
	var (
		status         = libs.GetStatusSuccess()
		scheduleModels []models.Schedule
		resourceModels []models.Resource
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		itemMsgError   string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}
	if status == 200 {
		db.Debug().Where("IFNULL(schedules.IsDeleted, 0) <> 1 AND IFNULL(schedules.IsArchived, 0) <> 1").Where("schedules.UserID <= 0 AND schedules.LocationID = ?", locationID).
			Joins(" JOIN jobs ON (jobs.JobID = schedules.JobID AND jobs.Status = 2)").
			Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')", fromDate, toDate).Find(&scheduleModels)
		arrResourceID := make([]int, 0)
		for _, schedule := range scheduleModels {
			arrResourceID = append(arrResourceID, schedule.ResourceID)
		}
		if len(arrResourceID) > 0 {
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("ResourceID in (?)", arrResourceID).Find(&resourceModels)
			responses := ConvertArrayResourcesToArrayResponse(requestHeader, resourceModels)
			if len(responses) > 0 {
				data = responses
				msg = services.GetMessage(lang, "api.success")
			} else {
				data = make([]int, 0)
				msg = services.GetMessage(lang, "api.no_record_found")
				status = libs.GetStatusNotFound()
				errResponse := GetErrorResponseNotFound(lang, 0)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			data = make([]int, 0)
			msg = services.GetMessage(lang, "api.no_record_found")
			status = libs.GetStatusNotFound()
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	if itemMsgError != "" {
		data = make([]int, 0)
		if msg == nil {
			msg = itemMsgError
		}
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// GetJobByUser godoc
// @Summary GetJobByUser
// @Description GetJobByUser
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjobbyuserandresource [get]
// App
func GetJobByUser(c *gin.Context) {

	defer libs.RecoverError(c, "GetJobByUser")
	var (
		status        = libs.GetStatusSuccess()
		userModel     models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		itemMsgError  string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}

	vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
	if !sJourneyCode {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.param_required", "Journey Code"))
		status = 422
	}
	if status == 200 {
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
		if resultFindUser.RowsAffected > 0 {
			userID := userModel.UserID
			schedulesJobs := make([]models.ScheduleJobResponse, 0)

			// Only Job Status = 2  - Allocated
			sql := `SELECT 
					IFNULL(s.JobID,0) AS JobID,
					IFNULL(j.JobNumber,'') AS JobNumber, 
					IFNULL(j.Status,0) AS Status, 
					IFNULL(r.NavigationAddress,'') AS NavigationAddress,
					IFNULL(b.CompanyName,'') AS CompanyName,
					j.InspectionForJobID,
					j.IsInspection,
					j.IsCombinedChild,
					j.IsMultipleChild, 
					IFNULL(jm.PrimaryJobID,0) AS PrimaryJobID
					FROM schedules s
					LEFT JOIN jobs j ON s.JobID = j.JobID
					LEFT JOIN resources r ON s.ResourceID = r.ResourceID 
					LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
					LEFT JOIN jobmultiples jm ON (jm.PrimaryJobID = j.JobID AND IFNULL(jm.IsDeleted, 0) <> 1 AND IFNULL(jm.IsArchived, 0) <> 1)
					WHERE j.Status IN (2,3,8)  AND IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
					AND s.UserID = ? AND (DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s'))
					AND s.JourneyCode = ? AND s.LocationID = ?
					GROUP BY j.InspectionForJobID, j.IsInspection,s.ScheduleStartDate, s.JobID, j.JobNumber, j.Status, r.NavigationAddress, b.CompanyName
					ORDER BY s.ScheduleStartDate ASC
			`
			rows, err := db.Debug().Raw(sql, userID, fromDate, toDate, vJourneyCode, locationID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var (
						scheduleJob  models.ScheduleJobResponse
						primaryJobID int
					)

					rows.Scan(
						&scheduleJob.JobID, &scheduleJob.JobNumber,
						&scheduleJob.Status,
						&scheduleJob.NavigationAddress, &scheduleJob.CompanyName,
						&scheduleJob.InspectionForJobID, &scheduleJob.IsInspection,
						&scheduleJob.IsCombinedChild,
						&scheduleJob.IsMultipleChild,
						&primaryJobID,
					)
					if primaryJobID > 0 {
						scheduleJob.IsPrimaryJob = true
					}
					schedulesJobs = append(schedulesJobs, scheduleJob)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
			}
			if len(schedulesJobs) > 0 {
				data = schedulesJobs
				msg = services.GetMessage(lang, "api.success")
			} else {
				status = libs.GetStatusNotFound()
				msg = services.GetMessage(lang, "api.no_record_found")
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
			}
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// GetJourneyByUser godoc
// @Summary GetJourneyByUser
// @Description GetJourneyByUser
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjourneybyuser [get]
// App
func GetJourneyByUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetJourneyByUser")
	var (
		status        = libs.GetStatusSuccess()
		userModel     models.User
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		itemMsgError  string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}
	resourceID := ""
	vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
	if sResourceID {
		resourceID = vResourceID
	}
	if status == 200 {
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
		if resultFindUser.RowsAffected > 0 {
			userID := userModel.UserID
			journeys := make([]models.JourneyListResponse, 0)

			sql := `SELECT 
				r.ResourceID,
				r.ResourceName,
				jn.JourneyCode,
				jn.StartJourneyDateTime,
				jn.EndJourneyDateTime,
				jn.Status,
				'' AS StatusName
				FROM schedules s
				LEFT JOIN jobs j ON s.JobID = j.JobID
				LEFT JOIN resources r ON s.ResourceID = r.ResourceID 
				LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
				JOIN journeys jn ON jn.JourneyCode = s.JourneyCode
				WHERE IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
				AND s.UserID = ? AND (DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s'))
				AND (DATE_FORMAT(jn.StartJourneyDateTime,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(jn.StartJourneyDateTime,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s'))
				AND jn.Status < 2`
			if resourceID != "" {
				sql = sql + ` AND s.ResourceID = ` + resourceID
			}
			sql = sql + ` GROUP BY r.ResourceID,
				r.ResourceName,
				jn.JourneyCode,
				jn.StartJourneyDateTime,
				jn.EndJourneyDateTime,
				jn.Status
				ORDER BY jn.StartJourneyDateTime ASC
			`
			rows, err := db.Raw(sql, userID, fromDate, toDate, fromDate, toDate).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var journey models.JourneyListResponse
					rows.Scan(
						&journey.ResourceID, &journey.ResourceName,
						&journey.JourneyCode,
						&journey.StartJourneyDateTime, &journey.EndJourneyDateTime,
						&journey.Status, &journey.StatusName,
					)
					journey.StatusName, _ = libs.GetEnum(requestHeader, journey.Status, "JourneyStatus", lang)
					journeys = append(journeys, journey)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
			}
			data = journeys
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// AssignUserToResource godoc
// @Summary AssignUserToResource
// @Description AssignUserToResource
// @Tags APP
// @Accept  json
// @Produce  json
// @Param scheduledate query string false "Schedule Date"
// @Param ResourceID body []int true "ResourceID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /assignusertoresource [post]
// App
func AssignUserToResource(c *gin.Context) {
	defer libs.RecoverError(c, "AssignUserToResource")
	var (
		status         = libs.GetStatusSuccess()
		userModel      models.User
		resourceModels []models.Resource
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		itemMsgError   string
		tempData       = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	errorsResponse := make([]models.ErrorResponse, 0)
	todayDate := time.Now().Format(libs.FORMATDATE)
	startDate, statusStartDate := libs.GetQueryParam("ScheduleDate", c)
	if statusStartDate {
		vStartDate, eStartDate := libs.ConvertStringToDateTime(startDate)
		if eStartDate == nil {
			todayDate = vStartDate.Format(libs.FORMATDATE)
		} else {
			// query has been error => to change format
			todayDate = startDate
		}
		tempData = true
	}
	var fromDate, toDate time.Time
	if !tempData {
		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
			if errFromDate != nil {
				status = 422
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			} else {
				fromDate = dFromDate
			}
		} else {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
		}

		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
			if errToDate != nil {
				status = 422
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
			} else {
				toDate = dToDate
			}
		} else {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
		}
	}

	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		userID := userModel.UserID
		type ResourcePOST struct {
			ResourceID []int `json:"ResourceID"`
		}
		var (
			resource    ResourcePOST
			resourceObj models.Resource
		)
		body, _ := ioutil.ReadAll(c.Request.Body)
		json.Unmarshal([]byte(string(body)), &resource)
		if len(resource.ResourceID) > 0 {
			resultFindResource := db.Where("ResourceID in (?)", resource.ResourceID).Find(&resourceObj)
			if resultFindResource.RowsAffected > 0 {
				var resultUpdate *gorm.DB
				if !tempData {
					resultUpdate = db.Where("ResourceID in (?)", resource.ResourceID).Where("UserID <= 0").
						Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')", fromDate, toDate).
						Model(&models.Schedule{}).Updates(models.Schedule{UserID: userID})
				} else {
					resultUpdate = db.Where("ResourceID in (?)", resource.ResourceID).Where("UserID <= 0").
						Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", todayDate).Model(&models.Schedule{}).Updates(models.Schedule{UserID: userID}).
						Model(&models.Schedule{}).Updates(models.Schedule{UserID: userID})
				}
				if resultUpdate.Error != nil {
					status = libs.GetStatusServerError()
					msg = services.GetMessage(lang, resultUpdate.Error.Error())
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
				} else {

					if resultUpdate.RowsAffected > 0 {
						msg = services.GetMessage(lang, "api.success")
						// Get resource
						db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("ResourceID in (?)", resource.ResourceID).Find(&resourceModels)
						responses := ConvertArrayResourcesToArrayResponse(requestHeader, resourceModels)
						if len(responses) > 0 {
							data = responses
						} else {
							data = make([]int, 0)
						}
					} else {
						status = libs.GetStatusUnprocessableEntity()
						msg = services.GetMessage(lang, "api.schedule_assign_resource")
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
					}
				}
			} else {
				status = libs.GetStatusNotFound()
				msg = services.GetMessage(lang, "api.resourceid_required")
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
			}
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.resourceid_required")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	} else {
		status = libs.GetStatusNotFound()
		msg = services.GetMessage(lang, "api.accountkey_not_found")
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
	}
	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetJobsByResource godoc
// @Summary Get Jobs By Resource
// @Description Get Jobs By Resource
// @Tags APP
// @Accept  json
// @Produce  json
// @Param id path int true "Resource ID"
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjobsbyresource/{id} [get]
func GetJobsByResource(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobsByResource")
	var (
		status         = libs.GetStatusSuccess()
		jobs           []models.Job
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		scheduleModels []models.Schedule
		itemMsgError   string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}
	if status == 200 {
		resourceID := c.Param("resourceid")
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("ResourceID = ?", resourceID).Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')", fromDate, toDate).Find(&scheduleModels)
		arrJobID := make([]int, 0)
		for _, schedule := range scheduleModels {
			arrJobID = append(arrJobID, schedule.JobID)
		}
		if len(arrJobID) > 0 {
			resultRow := db.Preload(
				"JobDetails",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("JobID in (?)", arrJobID).Find(&jobs)
			if resultRow.Error != nil {
				status = 500
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultRow.Error.Error())
			} else {
				responses := ConvertArrayJobsToArrayResponse(requestHeader, jobs, lang, false, true)
				for i, b := range responses {
					var (
						udfModels []models.UDF
					)
					dbu := db
					dbu = dbu.Where("TableName = ?", models.Job{}.TableName())

					udfParams := make([]string, 0)

					vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
					if sIsInvoice {
						bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
						if eIsInvoice == nil {
							if bIsInvoice {
								udfParams = append(udfParams, "invoices")
							}
						}
					}

					vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
					if sIsEstimate {
						bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
						if eIsEstimate == nil {
							if bIsEstimate {
								udfParams = append(udfParams, "estimates")
							}
						}
					}

					vIsCreditnote, sIsCreditnote := libs.GetQueryParam("iscreditnote", c)
					if sIsCreditnote {
						bIsCreditnote, eIsCreditnote := strconv.ParseBool(vIsCreditnote)
						if eIsCreditnote == nil {
							if bIsCreditnote {
								udfParams = append(udfParams, "creditnotes")
							}
						}
					}

					vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
					if sIsJob {
						bIsJob, eIsJob := strconv.ParseBool(vIsJob)
						if eIsJob == nil {
							if bIsJob {
								udfParams = append(udfParams, "jobs")
							}
						}
					}
					if len(udfParams) > 0 {
						dbu = dbu.Where("UDFKey in (?)", udfParams)
					}
					dbu = dbu.Order("Sort ASC")
					dbu = dbu.Find(&udfModels)
					udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
					responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
					for k, v := range udfResponses {
						val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, b.JobID)
						udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
						responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
					}
					responses[i].UDFs = udfResponses
				}
				data = responses
			}
		} else {
			data = make([]int, 0)
		}
	}
	if status == libs.GetStatusSuccess() {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// OptimizeRoute godoc
// @Summary OptimizeRoute
// @Description OptimizeRoute
// @Tags Routexl
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Tour body models.RoutexlTourPOST true "Tour body"
// @Success 200 {object} models.APIResponseData
// @Router /optimizeroute [post]
func OptimizeRoute(c *gin.Context) {
	defer libs.RecoverError(c, "OptimizeRoute")
	var (
		status = libs.GetStatusSuccess()
		//requestHeader models.RequestHeader
		response     models.APIResponseData
		msg, data    interface{}
		toursPOST    models.RoutexlTourPOST
		bodyDataJSON []byte
		routeXL      models.RouteXL
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	errorsResponse := make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	body, _ := ioutil.ReadAll(c.Request.Body)
	var mappingTourPOST map[string]interface{}
	json.Unmarshal([]byte(string(body)), &mappingTourPOST)
	jsonMapping, errMapping := json.Marshal(mappingTourPOST)
	if errMapping == nil {
		json.Unmarshal(jsonMapping, &toursPOST)
	}
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	bodyData := url.Values{}
	_, res := services.ConvertJSONValueToVariable("locations", mappingTourPOST)
	if res != nil {
		if len(toursPOST.Locations) > 0 {
			vBodyDataJSON, sBodyDataJSON := json.Marshal(toursPOST.Locations)
			if sBodyDataJSON == nil {
				bodyDataJSON = vBodyDataJSON
			}
			bodyData.Set("locations", string(bodyDataJSON))
		} else {
			bodyData.Set("locations", "[]")
		}
	}
	bodyData.Set("type", toursPOST.Type)
	/* skipOptimisation := "0"
	if toursPOST.SkipOptimization {
		skipOptimisation = "1"
	} */
	routeXL = GetRouteXL(accountKey)
	if routeXL.RouteXLUrl == "" {
		status = 404
		msg = services.GetMessage(lang, "api.routexl_not_found")
	}

	if status == 200 {
		//bodyData.Set("skipOptimisation", skipOptimisation)
		req, err := http.NewRequest("POST", routeXL.RouteXLUrl, strings.NewReader(bodyData.Encode()))
		req.Close = true
		if err != nil {
			status = 500
			msg = err.Error()
		} else {
			req.SetBasicAuth(routeXL.UserName, routeXL.Password)
			client := &http.Client{}
			resp, err := client.Do(req)
			fmt.Println("req: ", req)
			fmt.Println("resp: ", resp)
			if err == nil && resp.StatusCode == 200 {
				body, _ := ioutil.ReadAll(resp.Body)
				var routexlResponse map[string]interface{}
				json.Unmarshal(body, &routexlResponse)
				feasible := false
				val, res := services.ConvertJSONValueToVariable("feasible", routexlResponse)
				if res != nil {
					feasible, _ = strconv.ParseBool(val)
				}
				if !feasible {
					msg = services.GetMessage(lang, "api.routexl_not_feasible")
					//data = nil
					data = routexlResponse
				} else {
					data = routexlResponse
				}
			} else {
				if resp != nil {
					status = resp.StatusCode
					body, _ := ioutil.ReadAll(resp.Body)
					msg = string(body)
				} else {
					status = 500
				}
				if err != nil {
					msg = err.Error()
				} else {
					if msg == nil {
						msg = services.GetMessage(lang, "api.request_api_error")
					}
				}
			}
		}
	}
	if status == libs.GetStatusSuccess() {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetJobTasksByUser godoc
// @Summary Get Job Tasks By Resource
// @Description Get Job Tasks By Resource
// @Tags APP
// @Accept  json
// @Produce  json
// @Param id path int true "Resource ID"
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjobtasksbyuser [get]
func GetJobTasksByUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobTasksByUser")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		userModel     models.User
		itemMsgError  string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}

	vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
	if !sJourneyCode {
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.param_required", "Journey Code"))
		status = 422
	}
	if status == 200 {
		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		userModel = libs.GetCurrentUser(requestHeader, accountKey)
		if userModel.UserID > 0 {
			userID := userModel.UserID
			schedulesJobs := make([]models.ScheduleJobTaskResponse, 0)
			sql := `
			SELECT 
			IFNULL(s.ScheduleID,0) AS ScheduleID, 
			IFNULL(s.JobID,0) AS JobID,
			IFNULL(j.JobNumber,'') AS JobNumber, 
			IFNULL(jt.Status,0) AS Status, 
			IFNULL(s.JobTaskID,0) AS JobTaskID,
			IFNULL(jt.FormFlowID,0) AS FormFlowID,
			IFNULL(jt.JobType,0) AS JobType,
			'' AS JobTypeName,
			s.ScheduleStartDate,
			s.ScheduleEndDate,
			IFNULL(jt.NavigationAddress,'') AS NavigationAddress,
			IFNULL(b.CompanyName,'') AS CompanyName,
			j.InspectionForJobID,
			j.IsInspection,
			j.IsCombinedChild,
			j.IsMultipleChild, 
			IFNULL(jm.PrimaryJobID,0) AS PrimaryJobID
			FROM schedules s
			LEFT JOIN jobs j ON s.JobID = j.JobID
			LEFT JOIN jobtasks jt on (s.JobID = jt.JobID AND s.JobTaskID = jt.JobTaskID)
			LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
			LEFT JOIN jobmultiples jm ON (jm.PrimaryJobID = j.JobID AND IFNULL(jm.IsDeleted, 0) <> 1 AND IFNULL(jm.IsArchived, 0) <> 1)
			WHERE IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
			AND s.UserID = ? AND (DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s'))
			AND s.JourneyCode = ?
			ORDER BY s.ScheduleStartDate ASC
			`
			rows, err := db.Raw(sql, userID, fromDate, toDate, vJourneyCode).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var (
						scheduleJob  models.ScheduleJobTaskResponse
						primaryJobID int
					)
					rows.Scan(
						&scheduleJob.ScheduleID, &scheduleJob.JobID, &scheduleJob.JobNumber,
						&scheduleJob.Status, &scheduleJob.JobTaskID, &scheduleJob.FormFlowID,
						&scheduleJob.JobType, &scheduleJob.JobTypeName,
						&scheduleJob.ScheduleStartDate, &scheduleJob.ScheduleEndDate,
						&scheduleJob.NavigationAddress, &scheduleJob.CompanyName,
						&scheduleJob.InspectionForJobID, &scheduleJob.IsInspection,
						&scheduleJob.IsCombinedChild, &scheduleJob.IsMultipleChild,
						&primaryJobID,
					)
					if primaryJobID > 0 {
						scheduleJob.IsPrimaryJob = true
					}
					scheduleJob.JobTypeName, _ = libs.GetEnum(requestHeader, scheduleJob.JobType, "JobType", lang)
					schedulesJobs = append(schedulesJobs, scheduleJob)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
			}
			if len(schedulesJobs) > 0 {
				data = schedulesJobs
				msg = services.GetMessage(lang, "api.success")
			} else {
				status = libs.GetStatusNotFound()
				msg = services.GetMessage(lang, "api.no_record_found")
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
			}
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// GetSelectionJobTask godoc
// @Summary GetSelectionJobTask
// @Description GetSelectionJobTask
// @Tags APP
// @Accept  json
// @Produce  json
// @Param id path int true "Resource ID"
// @Param scheduledate query string false "Schedule Date"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getselectionjobtask [get]
func GetSelectionJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetSelectionJobTask")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		userModel     models.User
		itemMsgError  string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	primaryJobID, _ := libs.GetQueryParam("PrimaryJobID", c)
	if status == 200 {
		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		userModel = libs.GetCurrentUser(requestHeader, accountKey)
		if userModel.UserID > 0 {
			schedulesJobs := make([]models.ScheduleJobTaskResponse, 0)
			sqlJobID := `SELECT js.RelatedJobID FROM jobsselection js JOIN ( 
				SELECT js.JobID FROM jobsselection js JOIN jobmultiples jm ON js.JobID = jm.JobID
				WHERE  IFNULL(js.IsDeleted, 0) <> 1 AND IFNULL(js.IsArchived, 0) <> 1 AND js.RelatedJobID = 498)  AS jo ON js.JobID = jo.JobID`
			var arrJobID []int
			rows, err := db.Raw(sqlJobID, primaryJobID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var (
						primaryJobID int
					)
					rows.Scan(
						&primaryJobID,
					)
					arrJobID = append(arrJobID, primaryJobID)
				}
			}
			sql := `
			SELECT 
			IFNULL(s.ScheduleID,0) AS ScheduleID, 
			IFNULL(s.JobID,0) AS JobID,
			IFNULL(j.JobNumber,'') AS JobNumber, 
			IFNULL(jt.Status,0) AS Status, 
			IFNULL(s.JobTaskID,0) AS JobTaskID,
			IFNULL(jt.FormFlowID,0) AS FormFlowID,
			IFNULL(jt.JobType,0) AS JobType,
			'' AS JobTypeName,
			s.ScheduleStartDate,
			s.ScheduleEndDate,
			IFNULL(jt.NavigationAddress,'') AS NavigationAddress,
			IFNULL(b.CompanyName,'') AS CompanyName,
			j.InspectionForJobID,
			j.IsInspection,
			j.IsCombinedChild,
			j.IsMultipleChild, 
			IFNULL(jm.PrimaryJobID,0) AS PrimaryJobID
			FROM schedules s
			LEFT JOIN jobs j ON s.JobID = j.JobID
			LEFT JOIN jobtasks jt on (s.JobID = jt.JobID AND s.JobTaskID = jt.JobTaskID)
			LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
			LEFT JOIN jobmultiples jm ON (jm.PrimaryJobID = j.JobID AND IFNULL(jm.IsDeleted, 0) <> 1 AND IFNULL(jm.IsArchived, 0) <> 1)
			WHERE IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
			AND j.JobID IN (?)
			ORDER BY s.ScheduleStartDate ASC
			`
			rows, err = db.Raw(sql, arrJobID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					var (
						scheduleJob  models.ScheduleJobTaskResponse
						primaryJobID int
					)
					rows.Scan(
						&scheduleJob.ScheduleID, &scheduleJob.JobID, &scheduleJob.JobNumber,
						&scheduleJob.Status, &scheduleJob.JobTaskID, &scheduleJob.FormFlowID,
						&scheduleJob.JobType, &scheduleJob.JobTypeName,
						&scheduleJob.ScheduleStartDate, &scheduleJob.ScheduleEndDate,
						&scheduleJob.NavigationAddress, &scheduleJob.CompanyName,
						&scheduleJob.InspectionForJobID, &scheduleJob.IsInspection,
						&scheduleJob.IsCombinedChild, &scheduleJob.IsMultipleChild,
						&primaryJobID,
					)
					if primaryJobID > 0 {
						scheduleJob.IsPrimaryJob = true
					}
					scheduleJob.JobTypeName, _ = libs.GetEnum(requestHeader, scheduleJob.JobType, "JobType", lang)
					schedulesJobs = append(schedulesJobs, scheduleJob)
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
			}
			if len(schedulesJobs) > 0 {
				data = schedulesJobs
				msg = services.GetMessage(lang, "api.success")
			} else {
				status = libs.GetStatusNotFound()
				msg = services.GetMessage(lang, "api.no_record_found")
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
			}
		} else {
			status = libs.GetStatusNotFound()
			msg = services.GetMessage(lang, "api.accountkey_not_found")
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", msg))
		}
	}

	if itemMsgError != "" {
		data = make([]int, 0)
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// CreateSchedulerUser godoc
// @Summary Create Scheduler User
// @Description Create Scheduler User
// @Tags Schedule
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SchedulerUser body models.SchedulerUserResponse true "Create Scheduler User"
// @Success 200 {object} models.APIResponseData
// @Router /scheduleruser [post]
func CreateSchedulerUser(c *gin.Context) {
	defer libs.RecoverError(c, "CreateSchedulerUser")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.SchedulerUserResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	var (
		schedulerUser models.SchedulerUser
		itemMsgError  string
	)
	schedulerUser.PassBodyJSONToModel(objectsJSON)
	schedulerUser.CreatedBy = accountKey
	schedulerUser.ModifiedBy = accountKey
	schedulerUser.LocationID = locationID
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(schedulerUser)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {

		if schedulerUser.IsDeleted {
			sqlDelete := `DELETE FROM ` + models.SchedulerUser{}.TableName() + ` WHERE UserID = ? AND ResourceID = ? AND LocationID = ? AND DATE_FORMAT(SchedulerDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')`
			err = db.Exec(sqlDelete, schedulerUser.UserID, schedulerUser.ResourceID, schedulerUser.LocationID, *schedulerUser.SchedulerDate).Error
		} else {
			if schedulerUser.SchedulerDate != nil {
				sqlDelete := `DELETE FROM ` + models.SchedulerUser{}.TableName() + ` WHERE ResourceID = ? AND LocationID = ? AND DATE_FORMAT(SchedulerDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')`
				err = db.Exec(sqlDelete, schedulerUser.ResourceID, schedulerUser.LocationID, *schedulerUser.SchedulerDate).Error
			} else {
				sqlDelete := `DELETE FROM ` + models.SchedulerUser{}.TableName() + ` WHERE ResourceID = ? AND LocationID = ? AND SchedulerDate IS NULL`
				err = db.Exec(sqlDelete, schedulerUser.ResourceID, schedulerUser.LocationID).Error
			}
		}
		if err == nil {
			if !schedulerUser.IsDeleted {
				resultCreate := db.Create(&schedulerUser)
				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {
					totalUpdatedRecord++
					dataResponse = ConvertSchedulerUserToResponse(schedulerUser)
					data = dataResponse
				}
			} else {
				totalUpdatedRecord++
			}
		} else {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, err.Error())
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse

	if schedulerUser.IsDeleted {
		status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, 1, errorsResponse, false)
	} else {
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArraySchedulesToArrayResponse func
func ConvertArraySchedulesToArrayResponse(requestHeader models.RequestHeader, items []models.Schedule, lang string) []models.ScheduleResponse {
	responses := make([]models.ScheduleResponse, 0)
	for _, item := range items {
		response := ConvertScheduleToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertScheduleToResponse func
func ConvertScheduleToResponse(requestHeader models.RequestHeader, item models.Schedule, lang string) models.ScheduleResponse {
	var (
		response       models.ScheduleResponse
		jobTaskSummary models.JobTaskSummary
		jobSummary     models.JobSummary
	)
	response.ScheduleID = item.ScheduleID
	response.ScheduleStartDate = item.ScheduleStartDate
	response.ScheduleEndDate = item.ScheduleEndDate
	response.LocationID = item.LocationID
	response.ResourceID = item.ResourceID
	response.PrimaryResourceID = item.PrimaryResourceID
	response.UserID = item.UserID
	response.JobID = item.JobID
	response.JobTaskID = item.JobTaskID
	response.JourneyCode = item.JourneyCode
	response.ScheduleStartDateTimeZone = item.ScheduleStartDateTimeZone
	response.ScheduleEndDateTimeZone = item.ScheduleEndDateTimeZone

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var job models.Job
	resultFindJob := db.Where("JobID = ?", item.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFindJob.RowsAffected > 0 {
		response.JobStatus = job.Status
		response.JobStatusName, response.JobStatusIcon = libs.GetEnum(requestHeader, job.Status, "JobStatus", lang)
		jobSummary.JobNumber = job.JobNumber
		jobSummary.JobID = job.JobID
		jobSummary.JobType = job.JobType
		jobSummary.JobTypeName, jobSummary.JobTypeIcon = libs.GetEnum(requestHeader, job.JobType, "JobType", lang)
		jobSummary.JobDate = job.JobDate
		jobSummary.ContactDetails = job.ContactDetails
		jobSummary.ContactPhoneNumber = job.ContactPhoneNumber
		jobSummary.Comment = job.Comment
		jobSummary.Priority = job.Priority
		jobSummary.PriorityName, jobSummary.PriorityIcon = libs.GetEnum(requestHeader, job.Priority, "Priority", lang)
		jobSummary.IsCombinedChild = job.IsCombinedChild
		jobSummary.IsRecurring = job.IsRecurring
		jobSummary.RecurringJobID = job.RecurringJobID
		jobSummary.OptimizeJob = job.OptimizeJob
		var bp models.BusinessPartner
		resultFindBP := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&bp)
		if resultFindBP.RowsAffected > 0 {
			jobSummary.CompanyName = bp.CompanyName
			jobSummary.FirstName = bp.FirstName
			jobSummary.LastName = bp.LastName
		}
	}
	var user models.User
	resultFindUser := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&user)
	if resultFindUser.RowsAffected > 0 {
		response.FirstName = user.FirstName
		response.LastName = user.LastName
	}

	var jobTask models.JobTask
	resultFindJobTask := db.Where("JobTaskID = ?", item.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
	if resultFindJobTask.RowsAffected > 0 {
		jobTaskSummary.Status = jobTask.Status
		jobTaskSummary.StatusName, jobTaskSummary.StatusIcon = libs.GetEnum(requestHeader, jobTask.Status, "JobTaskStatus", lang)
		jobTaskSummary.NavigationAddress = jobTask.NavigationAddress
		jobTaskSummary.JobType = jobTask.JobType
		jobTaskSummary.JobTypeName, jobTaskSummary.JobTypeIcon = libs.GetEnum(requestHeader, jobTask.JobType, "JobType", lang)
		jobTaskSummary.AdditionalInformation = jobTask.AdditionalInformation
		jobTaskSummary.ServiceTimeInMinutes = jobTask.ServiceTimeInMinutes
		jobTaskSummary.ContactDetails, jobTaskSummary.ContactPhoneNumber = GetJobContactDetail(jobTask, db)

		var precomputes models.PrecomputedRoute
		resultFindPreComputes := db.Where("TaskID = ?", item.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&precomputes)
		if resultFindPreComputes.RowsAffected > 0 {
			jobTaskSummary.PrecomputedRoute = precomputes.PrecomputedRoute
			jobTaskSummary.PrecomputedRouteWeb = precomputes.PrecomputedRouteWeb
		}
	}
	jobSummary.JobTask = jobTaskSummary
	response.JobSummary = jobSummary

	sql := `SELECT au.UserID, u.FirstName, u.LastName, l.LocationName, u.Email, u.PhoneNumber FROM additionalusers au JOIN users u ON au.UserID = u.UserID
				JOIN locations l ON l.LocationID = u.LocationID 
				WHERE au.ScheduleID = ?`
	rows, err := db.Raw(sql, item.ScheduleID).Rows()
	if rows != nil {
		defer rows.Close()
	}
	if err == nil {
		var additionalUsers []models.AdditionalUserResponse
		additionalUsers = make([]models.AdditionalUserResponse, 0)
		for rows.Next() {
			var (
				additionalUser models.AdditionalUserResponse
			)
			rows.Scan(
				&additionalUser.UserID, &additionalUser.FirstName, &additionalUser.LastName,
				&additionalUser.LocationName, &additionalUser.Email, &additionalUser.PhoneNumber,
			)
			additionalUsers = append(additionalUsers, additionalUser)
		}
		response.AdditionalUsers = additionalUsers

	}

	return response
}

// ConvertArrayResourcesToArrayAppResponse func
func ConvertArrayResourcesToArrayAppResponse(requestHeader models.RequestHeader, items []models.Resource) models.ResourceAppResponse {
	var (
		response models.ResourceAppResponse
	)
	resources := make([]models.AppResourceResponse, 0)
	for _, item := range items {
		resource := ConvertResourceToAppResponse(requestHeader, item)
		resources = append(resources, resource)
	}
	response.Resources = resources
	return response
}

// ConvertResourceToAppResponse func
func ConvertResourceToAppResponse(requestHeader models.RequestHeader, item models.Resource) models.AppResourceResponse {
	var (
		resourceModeEnum models.Enumerator
		resourceTypeEnum models.Enumerator
		response         models.AppResourceResponse
	)

	response.ResourceID = item.ResourceID
	response.ResourceCode = item.ResourceCode
	response.ResourceName = item.ResourceName
	response.ResourceMode = item.ResourceMode
	response.ResourceColor = item.ResourceColor
	response.UserID = item.UserID
	response.ResourceType = item.ResourceType
	response.RegistrationNumber = item.RegistrationNumber
	response.CubicMeter = item.CubicMeter
	response.MaxLoadingWeight = item.MaxLoadingWeight
	response.SquareMeter = item.SquareMeter
	response.Level = item.Level
	response.NavigationAddress = item.NavigationAddress
	response.CurrentLatitude = item.CurrentLatitude
	response.CurrentLongitude = item.CurrentLongitude
	response.ShowInScheduler = item.ShowInScheduler
	response.VehicleInspectionID = item.VehicleInspectionID
	response.VehicleInspectionDay = libs.StringToArray(item.VehicleInspectionDay)
	response.VehicleStocktakeID = item.VehicleStocktakeID
	response.VehicleStocktakeDay = libs.StringToArray(item.VehicleStocktakeDay)
	response.BuyPriceByHour = item.BuyPriceByHour
	response.SellPriceByHour = item.SellPriceByHour
	response.LocationID = item.LocationID
	response.Note = item.Note

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultEnum := db.Where("FieldName = ? AND Status = ?", "ResourceMode", item.ResourceMode).First(&resourceModeEnum)
	if resultEnum.RowsAffected > 0 {
		response.ResourceModeName = resourceModeEnum.Caption
	}
	resultEnum = db.Where("FieldName = ? AND Status = ?", "ResourceType", item.ResourceType).First(&resourceTypeEnum)
	if resultEnum.RowsAffected > 0 {
		response.ResourceTypeName = resourceTypeEnum.Caption
	}

	var userModel models.User
	resultFindUser := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		response.Email = userModel.Email
		response.FirstName = userModel.FirstName
		response.LastName = userModel.LastName
		response.PhoneNumber = userModel.PhoneNumber
	}
	return response
}

// ConvertSchedulerUserToResponse func
func ConvertSchedulerUserToResponse(item models.SchedulerUser) models.SchedulerUserResponse {
	var (
		response models.SchedulerUserResponse
	)
	response.SchedulerUserID = item.SchedulerUserID
	response.UserID = item.UserID
	response.ResourceID = item.ResourceID
	response.LocationID = item.LocationID
	response.SchedulerDate = item.SchedulerDate

	return response
}

// UpdateAdditionalUser func
func UpdateAdditionalUser(accoutkey int, schedule models.Schedule, requestHeader models.RequestHeader, objectsJSON map[string]interface{}) {

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		additionalUserOld []models.AdditionalUser
	)
	findResultRow := db.Where("ScheduleID = ?", schedule.ScheduleID).Find(&additionalUserOld)
	// Delete All Additional Users
	db.Where("ScheduleID = ?", schedule.ScheduleID).Delete(&models.AdditionalUser{})
	if findResultRow.RowsAffected > 0 {
		for _, bp := range additionalUserOld {
			// Delete Scheduler Users
			db.Where("UserID = ? AND ResourceID = ? AND LocationID = ? AND DATE_FORMAT(SchedulerDate, '%Y-%m-%d') = DATE_FORMAT(?, '%Y-%m-%d')",
				bp.UserID, schedule.ResourceID, schedule.LocationID, schedule.ScheduleStartDate).
				Delete(&models.SchedulerUser{})
		}
	}
	_, res := services.ConvertJSONValueToVariable("AdditionalUsers", objectsJSON)
	if res != nil {
		var (
			objectsAddUsersJSON []map[string]interface{}
		)
		addUserJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(addUserJSON, &objectsAddUsersJSON)
			arrUserID := make([]int, 0)
			for _, bp := range objectsAddUsersJSON {
				var (
					additionalUser models.AdditionalUser
					scheduleUser   models.SchedulerUser
				)
				additionalUser.ModifiedBy = accoutkey
				additionalUser.CreatedBy = accoutkey
				additionalUser.PassBodyJSONToModel(bp)
				additionalUser.ScheduleID = schedule.ScheduleID
				db.Create(&additionalUser)

				arrUserID = append(arrUserID, additionalUser.UserID)

				findResultRow := db.Where("UserID = ? AND ResourceID = ? AND LocationID = ? AND DATE_FORMAT(SchedulerDate, '%Y-%m-%d') = DATE_FORMAT(?, '%Y-%m-%d')",
					additionalUser.UserID, schedule.ResourceID, schedule.LocationID, schedule.ScheduleStartDate).First(&models.SchedulerUser{})
				if findResultRow.RowsAffected <= 0 {
					scheduleUser.ModifiedBy = accoutkey
					scheduleUser.CreatedBy = accoutkey
					scheduleUser.UserID = additionalUser.UserID
					scheduleUser.ResourceID = schedule.ResourceID
					scheduleUser.LocationID = schedule.LocationID
					scheduleUser.SchedulerDate = &schedule.ScheduleStartDate
					db.Create(&scheduleUser)
				}
			}
		}
	}
}

// GetJobContactDetail func
func GetJobContactDetail(jobTask models.JobTask, db *gorm.DB) (string, string) {
	var (
		contactDetails     = ""
		contactPhoneNumber = ""
	)
	switch jobTask.JobType {
	case 1:
		var job models.JobOnSite
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	case 2:
		var job models.JobPickup
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	case 3:
		var job models.JobDelivery
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	case 5:
		var job models.JobInStore
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	case 7:
		var job models.JobResourcePickup
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	case 8:
		var job models.JobResourceDelivery
		resultFindJob := db.Where("JobTaskID = ?", jobTask.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
		if resultFindJob.RowsAffected > 0 {
			contactDetails = job.ContactDetails
			contactPhoneNumber = job.ContactPhoneNumber
		}
	}
	return contactDetails, contactPhoneNumber
}

func CreateRecurringJob(accountKey int, parentJobID int, parentJobTaskID int, requestHeader models.RequestHeader, scheduleObjPOST models.JourneyBodyJSON, c *gin.Context) models.Schedule {
	//create job
	var (
		parentJobModel models.Job
		newJobModel    models.Job
		scheduleObj    models.Schedule
		err            error
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	parentJobTaskType := 0
	newJobTaskID := 0
	resultFindParentJob := db.Preload(
		"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobMap", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where(
		"JobID = ?", parentJobID,
	).Where(
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).First(&parentJobModel)
	if resultFindParentJob.RowsAffected > 0 {
		// need to job Task
		if len(parentJobModel.JobTasks) > 0 {
			newJobModel = parentJobModel
			newJobModel.IsRecurring = false
			newJobModel.JobID = 0
			newJobModel.RecurringJobID = parentJobModel.JobID

			CheckDocumentSequencesBeforeCreate(requestHeader)
			var (
				sequencyModel models.DocumentSequency
				jobNumPrefix  models.Prefix
			)
			ResetDocumentSequencesIfGreaterLength(requestHeader)
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
			db.Where("DocumentSequence = ?", "JobNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
			jobNumberFirstConfig := jobNumPrefix.Prefix
			lenJobNumberConfig := jobNumPrefix.Length
			sqJobNumber := sequencyModel.JobNumber
			newJobModel.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)

			for i := range newJobModel.JobTasks {
				if newJobModel.JobTasks[i].JobTaskID == parentJobTaskID {
					parentJobTaskType = newJobModel.JobTasks[i].JobType
				}
				newJobModel.JobTasks[i].JobID = 0
				newJobModel.JobTasks[i].JobTaskID = 0
				newJobModel.JobTasks[i].CreatedBy = accountKey
				newJobModel.JobTasks[i].ModifiedBy = accountKey
			}
			for i := range newJobModel.JobDetails {
				newJobModel.JobDetails[i].JobID = 0
				newJobModel.JobDetails[i].JobDetailID = 0
				newJobModel.JobDetails[i].CreatedBy = accountKey
				newJobModel.JobDetails[i].ModifiedBy = accountKey
			}
			if newJobModel.JobPickup != nil {
				newJobModel.JobPickup.JobID = 0
				newJobModel.JobPickup.CreatedBy = accountKey
				newJobModel.JobPickup.ModifiedBy = accountKey
			}
			if newJobModel.JobDelivery != nil {
				newJobModel.JobDelivery.JobID = 0
				newJobModel.JobDelivery.JobDeliveryID = 0
				newJobModel.JobDelivery.CreatedBy = accountKey
				newJobModel.JobDelivery.ModifiedBy = accountKey
			}
			if newJobModel.JobOnSite != nil {
				newJobModel.JobOnSite.JobID = 0
				newJobModel.JobOnSite.JobOnSiteID = 0
				newJobModel.JobOnSite.CreatedBy = accountKey
				newJobModel.JobOnSite.ModifiedBy = accountKey
			}
			if newJobModel.JobInStore != nil {
				newJobModel.JobInStore.JobID = 0
				newJobModel.JobInStore.CreatedBy = accountKey
				newJobModel.JobInStore.ModifiedBy = accountKey
			}
			if newJobModel.JobMultiple != nil {
				newJobModel.JobMultiple.JobID = 0
				newJobModel.JobMultiple.JobMultipleID = 0
				newJobModel.JobMultiple.CreatedBy = accountKey
				newJobModel.JobMultiple.ModifiedBy = accountKey
			}
			if newJobModel.JobCombined != nil {
				newJobModel.JobCombined.JobID = 0
				newJobModel.JobCombined.JobCombinedID = 0
				newJobModel.JobCombined.CreatedBy = accountKey
				newJobModel.JobCombined.ModifiedBy = accountKey
			}
			if newJobModel.JobResourcePickUp != nil {
				newJobModel.JobResourcePickUp.JobID = 0
				newJobModel.JobResourcePickUp.JobResourcePickupID = 0
				newJobModel.JobResourcePickUp.CreatedBy = accountKey
				newJobModel.JobResourcePickUp.ModifiedBy = accountKey
			}
			if newJobModel.JobResourceDelivery != nil {
				newJobModel.JobResourceDelivery.JobID = 0
				newJobModel.JobResourceDelivery.JobResourceDeliveryID = 0
				newJobModel.JobResourceDelivery.CreatedBy = accountKey
				newJobModel.JobResourceDelivery.ModifiedBy = accountKey
			}
			if newJobModel.JobMap != nil {
				newJobModel.JobMap.JobID = 0
				newJobModel.JobMap.JobMapID = 0
				newJobModel.JobMap.CreatedBy = accountKey
				newJobModel.JobMap.ModifiedBy = accountKey
			}
			newJobModel.CreatedBy = accountKey
			newJobModel.ModifiedBy = accountKey
			err = db.Create(&newJobModel).Error
			if err == nil {
				IncreaseDocumentSequencesAfterCreateJob(true, false, false, false, requestHeader)
				for i := range newJobModel.JobTasks {
					if newJobModel.JobTasks[i].JobType == parentJobTaskType {
						newJobTaskID = newJobModel.JobTasks[i].JobTaskID
					}
				}
				//create schedule
				if newJobTaskID > 0 {
					if scheduleObjPOST.ScheduleStartDate != nil {
						scheduleObj.ScheduleStartDate = *scheduleObjPOST.ScheduleStartDate
					}
					if scheduleObjPOST.ScheduleEndDate != nil {
						scheduleObj.ScheduleEndDate = *scheduleObjPOST.ScheduleEndDate
					}
					scheduleObj.LocationID = scheduleObjPOST.LocationID
					scheduleObj.ResourceID = scheduleObjPOST.ResourceID
					scheduleObj.UserID = scheduleObjPOST.UserID
					scheduleObj.JobID = newJobModel.JobID
					scheduleObj.JobTaskID = newJobTaskID
					scheduleObj.ScheduleStartDateTimeZone = scheduleObjPOST.ScheduleStartDateTimeZone
					scheduleObj.ScheduleEndDateTimeZone = scheduleObjPOST.ScheduleEndDateTimeZone
					scheduleObj.CreatedBy = accountKey
					scheduleObj.ModifiedBy = accountKey
					err = db.Create(&scheduleObj).Error
					if err == nil {
						// update job status = 1=Scheduled by jobid on schedules table
						UpdateJobStatus(requestHeader, scheduleObj.JobID, 1, accountKey, c)
						// update job status for master job combined
						UpdateJobStatusForMasterJobCombined(requestHeader, scheduleObj.JobID, accountKey)

						// update schedule start date & end date
						var (
							jobTask models.JobTask
						)
						resultFindJobTask := db.Where("JobTaskID = ?", scheduleObj.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
						if resultFindJobTask.RowsAffected > 0 {
							jobTask.ModifiedBy = accountKey
							jobTask.ScheduleStartDateTime = &scheduleObj.ScheduleStartDate
							jobTask.ScheduleEndDateTime = &scheduleObj.ScheduleEndDate
							db.Save(&jobTask)
						}
					}
				}
			}
		}
	}
	return scheduleObj
}
