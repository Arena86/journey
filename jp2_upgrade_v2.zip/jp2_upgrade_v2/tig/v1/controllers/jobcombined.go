package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
)

// UpdateJobStatusForMasterJobCombined func
func UpdateJobStatusForMasterJobCombined(requestHeader models.RequestHeader, jobIDChild int, accountKey int) error {
	var err error
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {
		// check jobchild status
		var (
			currentJobChild            models.Job
			newMasterJobStatus         int
			hasAllChildCompleted       = true
			hasAllChildPicked          = true
			hasUpdateMasterJobCombined = true
			masterJobID                int
			onlyOneJobCombined         = true
		)
		resultFindCurrentJobChild := db.Where("JobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&currentJobChild)
		if resultFindCurrentJobChild.RowsAffected > 0 {
			if currentJobChild.IsCombinedChild {
				// find job combine master
				var jobSelection models.JobSelection
				resultFindJobSelection := db.Where("RelatedJobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
				if resultFindJobSelection.RowsAffected > 0 {
					masterJobID = jobSelection.JobID
				}
				if masterJobID > 0 {
					// check another jobchild status
					var jobSelections []models.JobSelection
					db.Where("JobID = ? AND RelatedJobID <> ?", masterJobID, jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobSelections)
					if len(jobSelections) > 0 {
						onlyOneJobCombined = false
					}
					if onlyOneJobCombined {
						newMasterJobStatus = currentJobChild.Status
					} else {
						if currentJobChild.Status == libs.JobStatusPicked {
							var maxJobStatus = currentJobChild.Status
							// find another jobchild
							for _, jobSelectionChild := range jobSelections {
								var jobChild models.Job
								resultFindJobChild := db.Where("JobID = ?", jobSelectionChild.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobChild)
								if resultFindJobChild.RowsAffected > 0 {
									if libs.GetPositionJobStatus(maxJobStatus) < libs.GetPositionJobStatus(jobChild.Status) {
										maxJobStatus = jobChild.Status
									}
									// find position job status < pickup then not change
									if hasAllChildPicked {
										if libs.GetPositionJobStatus(jobChild.Status) < libs.GetPositionJobStatus(libs.JobStatusPicked) {
											hasAllChildPicked = false
										}
									}
								}
							}
							if !hasAllChildPicked {
								hasUpdateMasterJobCombined = false
							} else {
								newMasterJobStatus = maxJobStatus
							}
						} else if currentJobChild.Status == libs.JobStatusCompleted {
							// check another jobchild status
							// find another jobchild
							for _, jobSelectionChild := range jobSelections {
								var jobChild models.Job
								resultFindJobChild := db.Where("JobID = ?", jobSelectionChild.RelatedJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobChild)
								if resultFindJobChild.RowsAffected > 0 {
									if jobChild.Status != libs.JobStatusCompleted {
										hasAllChildCompleted = false
										break
									}
								}
							}
							if !hasAllChildCompleted {
								hasUpdateMasterJobCombined = false
							} else {
								newMasterJobStatus = currentJobChild.Status
							}
						} else {
							newMasterJobStatus = currentJobChild.Status
						}
					}
					if hasUpdateMasterJobCombined {
						var masterJob models.Job
						resultFindMasterJob := db.Where("JobID = ?", masterJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&masterJob)
						if resultFindMasterJob.RowsAffected > 0 {
							if onlyOneJobCombined {
								masterJob.Status = newMasterJobStatus
								masterJob.ModifiedBy = accountKey
								err = db.Save(&masterJob).Error
							} else {
								if masterJob.Status != 8 {
									if libs.GetPositionJobStatus(newMasterJobStatus) > libs.GetPositionJobStatus(masterJob.Status) {
										masterJob.Status = newMasterJobStatus
										masterJob.ModifiedBy = accountKey
										err = db.Save(&masterJob).Error
									}
								} else {
									masterJob.Status = newMasterJobStatus
									masterJob.ModifiedBy = accountKey
									err = db.Save(&masterJob).Error
								}
							}
						}
					}
				}
			}
		}
	}
	return err
}

// if combined
// if jobselection > 2 then delete current jobselection => reset IsCombinedChild = false
// else delete all jobselection => reset IsCombinedChild = false, => master combined IsDeleted = true
// UpdateJobStatusForMasterJobCombinedAfterResetJob func
func UpdateJobStatusForMasterJobCombinedAfterResetJob(requestHeader models.RequestHeader, jobIDChild int, accountKey int) error {
	var err error
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {
		var (
			currentJobChild models.Job
			masterJobID     int
		)
		resultFindCurrentJobChild := db.Where("JobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&currentJobChild)
		if resultFindCurrentJobChild.RowsAffected > 0 {
			if currentJobChild.IsCombinedChild {
				// find job combine master
				var jobSelection models.JobSelection
				resultFindJobSelection := db.Where("RelatedJobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
				if resultFindJobSelection.RowsAffected > 0 {
					masterJobID = jobSelection.JobID
				}
				if masterJobID > 0 {
					// check another jobchild status
					var jobSelections []models.JobSelection
					db.Where("JobID = ?", masterJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobSelections)
					if len(jobSelections) > 2 {
						jobSelection.IsDeleted = true
						jobSelection.ModifiedBy = accountKey
						err = db.Save(&jobSelection).Error
						if err == nil {
							currentJobChild.IsCombinedChild = false
							currentJobChild.ModifiedBy = accountKey
							err = db.Save(&currentJobChild).Error
						}
					} else {
						var arrJobIDOfJobCombinedChild = make([]int, 0)
						for _, jobSelectionVar := range jobSelections {
							arrJobIDOfJobCombinedChild = append(arrJobIDOfJobCombinedChild, jobSelectionVar.RelatedJobID)
						}
						// delete all jobselection
						err = db.Model(&models.JobSelection{}).Where("JobID = ?", masterJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Updates(map[string]interface{}{"IsDeleted": true, "ModifiedBy": accountKey}).Error
						if err == nil {
							// reset job combined child > IsCombinedChild = false
							if len(arrJobIDOfJobCombinedChild) > 0 {
								err = db.Model(&models.Job{}).Where("JobID in (?)", arrJobIDOfJobCombinedChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Updates(map[string]interface{}{"IsCombinedChild": false, "ModifiedBy": accountKey}).Error
							}
							//  master combined IsDeleted = true
							if err == nil {
								err = db.Model(&models.Job{}).Where("JobID = ?", masterJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Updates(map[string]interface{}{"IsDeleted": true, "ModifiedBy": accountKey}).Error
							}
						}
					}
				}
			}
		}
	}
	return err
}

// update master combined job = current job
// UpdateJobStatusForMasterJobCombinedAfterTakeJob func
func UpdateJobStatusForMasterJobCombinedAfterTakeJob(requestHeader models.RequestHeader, jobIDChild int, accountKey int) error {
	var err error
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {
		var (
			currentJobChild models.Job
			masterJobID     int
		)
		resultFindCurrentJobChild := db.Where("JobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&currentJobChild)
		if resultFindCurrentJobChild.RowsAffected > 0 {
			if currentJobChild.IsCombinedChild {
				// find job combine master
				var jobSelection models.JobSelection
				resultFindJobSelection := db.Where("RelatedJobID = ?", jobIDChild).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobSelection)
				if resultFindJobSelection.RowsAffected > 0 {
					masterJobID = jobSelection.JobID
				}
				if masterJobID > 0 {
					var masterJob models.Job
					resultFindMasterJob := db.Where("JobID = ?", masterJobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&masterJob)
					if resultFindMasterJob.RowsAffected > 0 {
						masterJob.Status = currentJobChild.Status
						masterJob.ModifiedBy = accountKey
						err = db.Save(&masterJob).Error
					}
				}
			}
		}
	}
	return err
}
