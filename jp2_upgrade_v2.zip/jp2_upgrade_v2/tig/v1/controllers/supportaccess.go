package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// CreateSupportAccess godoc
// @Summary CreateSupportAccess
// @Description CreateSupportAccess
// @Tags SupportAccess
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SupportAccess body []models.SupportAccessResponse true "CreateSupportAccess"
// @Success 200 {object} models.APIResponseData
// @Router /supportaccess [post]
func CreateSupportAccess(c *gin.Context) {
	apiName := "CreateSupportAccess"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.SupportAccess
		totalUpdatedRecord = 0
		isNew              = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.SupportAccess
	)
	obj.PassBodyJSONToModel(objectsJSON)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
			resultCreate *gorm.DB
		)
		resultFind := db.Where("SupportAccessID = ?", obj.SupportAccessID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&obj)
		obj.PassBodyJSONToModel(objectsJSON)
		if resultFind.RowsAffected > 0 {
			resultCreate = db.Save(&obj)
			isNew = false
		} else {
			resultCreate = db.Create(&obj)
		}
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {
			totalUpdatedRecord++
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND SupportAccessID = ?", obj.SupportAccessID).First(&obj)
	dataResponse = obj
	errors = errorsResponse
	if isNew {
		status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	} else {
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	}
	dataResponses := ConvertSupportAccessToResponse(requestHeader, dataResponse, lang)
	data = dataResponses
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertSupportAccessToResponse func
func ConvertSupportAccessToResponse(requestHeader models.RequestHeader, item models.SupportAccess, lang string) models.SupportAccessResponse {
	var (
		response models.SupportAccessResponse
	)
	response.SupportAccessID = item.SupportAccessID
	response.FirstName = item.FirstName
	response.LastName = item.LastName
	response.DateTime = item.DateTime
	response.Type = item.Type
	response.ClientOffSet = item.ClientOffSet
	return response
}
