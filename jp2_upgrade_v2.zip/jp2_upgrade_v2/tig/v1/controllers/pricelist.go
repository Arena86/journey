package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetPriceListOnlyMaster godoc
// @Summary Get Price List
// @Description Get Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist [get]
func GetPriceListOnlyMaster(c *gin.Context) {
	defer libs.RecoverError(c, "GetPriceListOnlyMaster")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.PriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{"IsSpecial"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"PriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.PriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPriceListToArrayResponseOnlyMaster(requestHeader, resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPriceListWithDetails godoc
// @Summary Get Price List
// @Description Get Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist/details [get]
func GetPriceListWithDetails(c *gin.Context) {
	defer libs.RecoverError(c, "GetPriceListWithDetails")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.PriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("PriceListDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{"IsSpecial"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"PriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.PriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPriceListToArrayResponse(requestHeader, resModels, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPriceListByID godoc
// @Summary Get Price List By ID
// @Description Get Price List By ID
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param id path int true " Price List ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist/id/{id} [get]
func GetPriceListByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPriceListByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.PriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"PriceListDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertPriceListToResponse(requestHeader, resModel, lang)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePriceList godoc
// @Summary Create Price List
// @Description Create Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PriceList body models.PriceListResponse true "Create Price List"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist [post]
func CreatePriceList(c *gin.Context) {
	apiName := "CreatePriceList"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var bp map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &bp)
	var (
		obj models.PriceList
	)
	obj.PassBodyJSONToModel(bp)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListName = ?", obj.PriceListName).First(&models.PriceList{})
	if resultCheckExist.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.pricelistname_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(obj)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError   string
				itemMsgWarning string
			)
			// @TODO validate for details
			if len(obj.PriceListDetails) > 0 {
				detailsValid := make([]models.PriceListDetail, 0)
				for _, detail := range obj.PriceListDetails {
					validate, trans := services.GetValidatorTranslate()
					err := validate.Struct(detail)
					if err != nil {
						errs := err.(validator.ValidationErrors)
						for _, e := range errs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
						}
					} else {
						// @ vaidate data in details
						validateDetail := ValidatePriceListDetails(lang, detail)
						itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
						if validateDetail != "" {
							continue
						}
						// @ end vaidate data in details
						detail.CreatedBy = accountKey
						detailsValid = append(detailsValid, detail)
					}
				}
				obj.PriceListDetails = detailsValid
			} else {
				errResponse := GetErrorResponseValidate(lang, 0, "api.pricelistdetail_required")
				errorsResponse = append(errorsResponse, errResponse)
			}
			if len(errorsResponse) <= 0 {
				if itemMsgWarning != "" {
					errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
					errorsResponse = append(errorsResponse, errResponse)
				}
				if itemMsgError == "" {
					resultCreate := db.Create(&obj)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						totalUpdatedRecord++
						data = ConvertPriceListToResponse(requestHeader, obj, lang)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePriceList godoc
// @Summary Update Price List
// @Description Update Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PriceList body []models.PriceListResponse true "Update Price List"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist/{id} [put]
func UpdatePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePriceList")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.PriceList
	)
	resultFind := db.Where("PriceListID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListName = ? AND PriceListID <> ?", resModel.PriceListName, resModel.PriceListID).First(&models.PriceList{})
		if resultCheckExist.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.pricelistname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resModel.PriceListID = id
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError   string
					res            interface{}
					itemMsgWarning string
				)

				// @TODO validate for details
				// set details empty
				resModel.PriceListDetails = make([]models.PriceListDetail, 0)
				var (
					objectsDetails        []map[string]interface{}
					details               []models.PriceListDetail
					arrSkipID             []int
					arrToDeleteID         []int
					detailsToDeleteModels []models.PriceListDetail
				)
				details = make([]models.PriceListDetail, 0)
				_, res = services.ConvertJSONValueToVariable("PriceListDetails", bp)
				if res != nil {
					objectsJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(objectsJSON, &objectsDetails)
						if len(objectsDetails) > 0 {
							for _, obj := range objectsDetails {
								var (
									detailModel models.PriceListDetail
								)
								detailModel.PassBodyJSONToModel(obj)
								resultFindDetails := db.Where("PriceListDetailID = ? AND PriceListID = ?", detailModel.PriceListDetailID, resModel.PriceListID).First(&detailModel)
								if resultFindDetails.RowsAffected > 0 {
									arrSkipID = append(arrSkipID, detailModel.PriceListDetailID)
									detailModel.PassBodyJSONToModel(obj)
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											if itemMsgError == "" {
												itemMsgError = itemMsgError + e.Translate(trans)
											} else {
												itemMsgError = itemMsgError + "\n" + e.Translate(trans)
											}
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidatePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								} else {
									detailModel.PassBodyJSONToModel(obj)
									detailModel.CreatedBy = accountKey
									detailModel.PriceListDetailID = 0
									detailModel.PriceListID = 0
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											if itemMsgError == "" {
												itemMsgError = itemMsgError + e.Translate(trans)
											} else {
												itemMsgError = itemMsgError + "\n" + e.Translate(trans)
											}
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidatePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								}
							}
						}
					}
				}
				resModel.PriceListDetails = details

				if len(details) > 0 {
					if itemMsgWarning != "" {
						errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
						errorsResponse = append(errorsResponse, errResponse)
					}

					if len(arrSkipID) > 0 {
						// delete id not in arrSkipID
						db.Where("PriceListID = ? AND PriceListDetailID not in (?)", resModel.PriceListID, arrSkipID).Find(&detailsToDeleteModels)
					} else {
						// delete all
						db.Where("PriceListID = ?", resModel.PriceListID).Find(&detailsToDeleteModels)
					}
					for _, ad := range detailsToDeleteModels {
						arrToDeleteID = append(arrToDeleteID, ad.PriceListDetailID)
					}

					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultSave.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							db.Where("PriceListDetailID in (?)", arrToDeleteID).Delete(&models.PriceListDetail{})
							//db.Where("PriceListDetailID in (?)", arrToDeleteID).Model(&models.PriceListDetail{}).Updates(models.PriceListDetail{IsDeleted: true})
						}
						//data = ConvertPriceListToResponse(requestHeader, resModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				} else {
					errResponse := GetErrorResponseValidate(lang, 0, "api.pricelistdetail_required")
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
		// reload data
		resultRow := db.Preload(
			"PriceListDetails",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListID = ?", id).First(&resModel)
		if resultRow.RowsAffected > 0 {
			responses := ConvertPriceListToResponse(requestHeader, resModel, lang)
			data = responses
		} else {
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePriceList godoc
// @Summary Delete Price List
// @Description Delete Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /pricelist/{id} [delete]
func DeletePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePriceList")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.PriceList
		)
		resultFind := db.Where("PriceListID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			// @TODO DELETE - If the pricelist is assigned to a customergroup or customer cannot be deleted.
			var totalCountCustomerGroup int64
			totalCountCustomerGroup = 0
			db.Model(&models.CustomerGroup{}).Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListID = ?", resModel.PriceListID).Count(&totalCountCustomerGroup)
			var totalCountCustomer int64
			totalCountCustomer = 0
			db.Model(&models.BusinessPartner{}).Where("IFNULL(IsDeleted, 0) <> 1 AND PriceListID = ?", resModel.PriceListID).Count(&totalCountCustomer)
			if totalCountCustomer > 0 || totalCountCustomerGroup > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.confirm_delete_pricelist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPriceListToArrayResponseOnlyMaster func
func ConvertArrayPriceListToArrayResponseOnlyMaster(requestHeader models.RequestHeader, items []models.PriceList, lang string) []models.PriceListResponseMaster {
	responses := make([]models.PriceListResponseMaster, 0)
	for _, item := range items {
		response := ConvertPriceListToResponseOnlyMaster(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPriceListToResponseOnlyMaster func
func ConvertPriceListToResponseOnlyMaster(requestHeader models.RequestHeader, item models.PriceList, lang string) models.PriceListResponseMaster {
	var (
		response         models.PriceListResponseMaster
		resourceModeEnum models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.PriceListID = item.PriceListID
	response.PriceListName = item.PriceListName
	response.IsSpecial = item.IsSpecial
	response.FromDate = item.FromDate
	response.ToDate = item.ToDate
	response.SpecialToPricelistID = item.SpecialToPricelistID
	response.TravelCalculationMode = item.TravelCalculationMode
	response.TravelCalculationMode = item.TravelCalculationMode
	response.IsIncludeTax = item.IsIncludeTax
	db.Where("FieldName = ? AND Status = ?", "TravelCalculationMode", item.TravelCalculationMode).First(&resourceModeEnum)
	if resourceModeEnum.TranslationKey != "" && resourceModeEnum.TranslationKey != services.GetMessage(lang, resourceModeEnum.TranslationKey) {
		response.TravelCalculationModeName = services.GetMessage(lang, resourceModeEnum.TranslationKey)
	} else {
		response.TravelCalculationModeName = resourceModeEnum.Caption
	}
	return response
}

// ConvertArrayPriceListToArrayResponse func
func ConvertArrayPriceListToArrayResponse(requestHeader models.RequestHeader, items []models.PriceList, lang string) []models.PriceListResponse {
	responses := make([]models.PriceListResponse, 0)
	for _, item := range items {
		response := ConvertPriceListToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPriceListToResponse func
func ConvertPriceListToResponse(requestHeader models.RequestHeader, item models.PriceList, lang string) models.PriceListResponse {
	var (
		response         models.PriceListResponse
		resourceModeEnum models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.PriceListID = item.PriceListID
	response.PriceListName = item.PriceListName
	response.IsSpecial = item.IsSpecial
	response.FromDate = item.FromDate
	response.ToDate = item.ToDate
	response.SpecialToPricelistID = item.SpecialToPricelistID
	response.TravelCalculationMode = item.TravelCalculationMode
	db.Where("FieldName = ? AND Status = ?", "TravelCalculationMode", item.TravelCalculationMode).First(&resourceModeEnum)
	if resourceModeEnum.TranslationKey != "" && resourceModeEnum.TranslationKey != services.GetMessage(lang, resourceModeEnum.TranslationKey) {
		response.TravelCalculationModeName = services.GetMessage(lang, resourceModeEnum.TranslationKey)
	} else {
		response.TravelCalculationModeName = resourceModeEnum.Caption
	}

	details := make([]models.PriceListDetailResponse, 0)

	for _, v := range item.PriceListDetails {
		var (
			item models.Item
		)
		var detail models.PriceListDetailResponse
		db.Where("ItemID = ?", v.ItemID).First(&item)
		if item.ItemID != 0 {
			detail.ItemCode = item.Code
			detail.ItemName = item.Name
			detail.Description = item.Description
		}

		detail.PriceListDetailID = v.PriceListDetailID
		detail.PriceListID = v.PriceListID
		detail.ItemID = v.ItemID
		detail.ServicePriceListID = v.ServicePriceListID
		detail.DistancePriceListID = v.DistancePriceListID
		detail.Unit = v.Unit
		detail.DefaultQuantity = v.DefaultQuantity
		detail.Price = v.Price
		detail.DiscountPercent = v.DiscountPercent
		detail.BufferPercent = v.BufferPercent
		detail.TravelTimeChargeMatrixID = v.TravelTimeChargeMatrixID
		details = append(details, detail)
	}
	response.PriceListDetails = details
	return response
}

// ValidatePriceListDetails func
func ValidatePriceListDetails(lang string, detail models.PriceListDetail) string {
	var itemMsgWarning string
	if detail.DefaultQuantity < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.defaultquantity_greater_zero"))
	}
	if detail.Price < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.price_greater_zero"))
	}
	if detail.DiscountPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.discountpercent_greater_zero"))
	}
	if detail.BufferPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.bufferpercent_greater_zero"))
	}
	return itemMsgWarning
}
