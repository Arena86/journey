package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetNotification godoc
// @Summary Get Notification
// @Description Get Notification
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /notification [get]
func GetNotification(c *gin.Context) {
	defer libs.RecoverError(c, "GetNotification")
	var (
		status            = libs.GetStatusSuccess()
		resModels         []models.Notification
		notificationsUser []models.NotificationUser
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg               interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	arrNotificationsID := make([]int, 0)
	if accountKey > 0 {
		db.Where("AccountKey = ?", accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&notificationsUser)
		for _, notificationUser := range notificationsUser {
			arrNotificationsID = append(arrNotificationsID, notificationUser.NotificationID)
		}
		if len(arrNotificationsID) <= 0 {
			arrNotificationsID = append(arrNotificationsID, -1)
		}
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	if len(arrNotificationsID) > 0 {
		bp = bp.Where("NotificationID in (?)", arrNotificationsID)
	}
	bp = bp.Order("CreatedDate DESC")
	// Sort
	//bp = libs.SortDataOnParam(bp, c, "ReasonName")
	reasonSort := libs.GetSortValueFromKey(c, "ReasonName")
	if reasonSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//

		var reasons []models.Reason
		arrReasonIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Reason " + reasonSort).Find(&reasons)
		for _, reason := range reasons {
			arrReasonIDSort = append(arrReasonIDSort, reason.ReasonID)
		}
		if len(arrReasonIDSort) > 0 {
			strJoin := libs.IntJoin(arrReasonIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(ReasonID," + strJoin + ")")
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayNotificationToArrayResponse(resModels, lang, requestHeader, accountKey)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetUnreadNotificationCount godoc
// @Summary Get Notification
// @Description Get Notification
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getunreadcount [get]
func GetUnreadNotificationCount(c *gin.Context) {
	defer libs.RecoverError(c, "GetNotification")
	var (
		status                  = libs.GetStatusSuccess()
		resModels               []models.NotificationUser
		requestHeader           models.RequestHeader
		response                models.APIResponseData
		msg                     interface{}
		unreadNotificationCount models.UnReadNotificationResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(ReadStatus, 0) <> 1 AND AccountKey = ?", accountKey)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	unreadNotificationCount.Count = int(totalCount)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = unreadNotificationCount
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetNotificationByAccountKey godoc
// @Summary Get Notification By AccountKey
// @Description Get Notification By AccountKey
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getunreadcount/{accountkey} [get]
func GetNotificationByAccountKey(c *gin.Context) {
	defer libs.RecoverError(c, "GetNotificationByAccountKey")
	var (
		status            = libs.GetStatusSuccess()
		resModels         []models.Notification
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg               interface{}
		notificationUsers []models.NotificationUser
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	arrNotificationID := make([]int, 0)
	// Paging
	accountKey := c.Param("accountkey")
	headerAccountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	db.Where("AccountKey = ?", accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&notificationUsers)
	for _, u := range notificationUsers {
		arrNotificationID = append(arrNotificationID, u.NotificationID)
	}
	if len(arrNotificationID) <= 0 {
		arrNotificationID = append(arrNotificationID, -1)
	}

	var bp = db
	bp = bp.Where("NotificationID in (?)", arrNotificationID)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Order("CreatedDate DESC")
	// Sort
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Find(&[]models.Notification{}).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayNotificationToArrayResponse(resModels, lang, requestHeader, headerAccountKey)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = responses
	libs.APIResponseData(response, c, status)
}

// GetNotificationByID godoc
// @Summary Get Notification By ID
// @Description Get Notification  By ID
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param id path int true "Notification ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /notification/{id} [get]
/* func GetNotificationByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetNotificationByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Notification
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("NotificationID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertNotificationToResponse(resModel, lang, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
} */

// CreateNotification godoc
// @Summary Create Notification
// @Description Create Notification
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param Group query string false "Group:company|locationgroup|location"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Notification body models.NotificationResponse true "Create Notification"
// @Success 200 {object} models.APIResponseData
// @Router /notification [post]
func CreateNotification(c *gin.Context) {
	defer libs.RecoverError(c, "CreateNotification")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Notification
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	group := ""
	vGroup, sGroup := libs.GetQueryParam("Group", c)
	if sGroup {
		group = vGroup
	}

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	dataResponse = make([]models.Notification, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.Notification
			)
			resModel.PassBodyJSONToModel(bp)
			resModel.CreatedBy = accountKey
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resultCreate := db.Create(&resModel)
				if resultCreate.Error == nil {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, resModel)
					// insert to notificationusers
					arrUserID := make([]int, 0)
					switch group {
					case "company":
						{
							var users []models.User
							db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&users)
							for _, u := range users {
								arrUserID = append(arrUserID, u.AccountKey)
							}
						}
					case "locationgroup":
						{
							var (
								location  models.Location
								locations []models.Location
								users     []models.User
							)
							arrLocationID := make([]int, 0)
							resultFindLocation := db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
							if resultFindLocation.RowsAffected > 0 {
								db.Where("LocationGroupID = ?", location.LocationGroupID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&locations)
								for _, l := range locations {
									arrLocationID = append(arrLocationID, l.LocationID)
								}
							}
							if len(arrLocationID) > 0 {
								db.Where("LocationID in (?)", arrLocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&users)
								for _, u := range users {
									arrUserID = append(arrUserID, u.AccountKey)
								}
							}
						}
					case "location":
						{
							var (
								users []models.User
							)
							db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&users)
							for _, u := range users {
								arrUserID = append(arrUserID, u.AccountKey)
							}
						}
					}
					/* if !libs.InArrayInteger(accountKey, arrUserID) {

					} */

					if len(arrUserID) > 0 {
						for _, userID := range arrUserID {
							var notificationUser models.NotificationUser
							notificationUser.NotificationID = resModel.NotificationID
							notificationUser.AccountKey = userID
							if userID == accountKey {
								notificationUser.Status = 1
								notificationUser.ReadStatus = true
							} else {
								notificationUser.Status = 0
								notificationUser.ReadStatus = false
							}
							notificationUser.CreatedBy = accountKey
							notificationUser.ModifiedBy = accountKey
							db.Create(&notificationUser)
						}
					}
				} else {
					errResponse := GetErrorResponseErrorMessage(k, resultCreate.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.Notification
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.NotificationID)
	}
	if len(arrID) > 0 {
		db.Where("NotificationID in (?)", arrID).Find(&resModels)
		data = ConvertArrayNotificationToArrayResponse(resModels, lang, requestHeader, accountKey)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateNotification godoc
// @Summary Update Notification
// @Description Update Notification
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param AccountKey header int true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param NotificationID path int true "NotificationID ID"
// @Success 200 {object} models.APIResponseData
// @Router /notification [put]
func UpdateNotification(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateNotification")
	var (
		status                 = libs.GetStatusSuccess()
		requestHeader          models.RequestHeader
		response               models.APIResponseData
		msg, data, errors      interface{}
		errorsResponse         []models.ErrorResponse
		totalUpdatedRecord     = 0
		notificationUserModels []models.NotificationUser
		notificationPOST       models.NotificationPOST
		responses              []models.NotificationResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	json.NewDecoder(c.Request.Body).Decode(&notificationPOST)
	if len(notificationPOST.NotificationIDs) > 0 {
		for k, v := range notificationPOST.NotificationIDs {
			var (
				resModel models.Notification
			)
			notificationID := v
			resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND NotificationID = ?", notificationID).First(&resModel)
			if resultRow.RowsAffected > 0 {
				db.Where("NotificationID = ? AND AccountKey = ?", notificationID, accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&notificationUserModels)
				for _, notificationUser := range notificationUserModels {
					notificationUser.ReadStatus = true
					db.Save(&notificationUser)
				}
				totalUpdatedRecord++
				response := ConvertNotificationToResponse(resModel, lang, requestHeader, accountKey)
				responses = append(responses, response)

			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
		status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(notificationPOST.NotificationIDs), errorsResponse, true)
	} else {
		db.Where("AccountKey = ?", accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&notificationUserModels)
		for _, notificationUser := range notificationUserModels {
			var (
				resModel models.Notification
			)
			if !notificationUser.ReadStatus {
				notificationUser.ReadStatus = true
				db.Save(&notificationUser)
			}
			resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND NotificationID = ?", notificationUser.NotificationID).First(&resModel)
			if resultRow.RowsAffected > 0 {
				response := ConvertNotificationToResponse(resModel, lang, requestHeader, accountKey)
				responses = append(responses, response)
			}
		}

		status, msg = GetStatusState("PUT", lang, 1, 1, errorsResponse, true)
	}
	data = responses
	errors = errorsResponse

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteNotification godoc
// @Summary Delete Notification
// @Description Delete Notification
// @Tags Notification
// @Accept  json
// @Produce  json
// @Param AccountKey header int true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param NotificationID path int true "NotificationID ID"
// @Success 200 {object} models.APIResponseData
// @Router /deletenotification [put]
func DeleteNotification(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteNotification")
	var (
		status                 = libs.GetStatusSuccess()
		requestHeader          models.RequestHeader
		response               models.APIResponseData
		msg, data, errors      interface{}
		errorsResponse         []models.ErrorResponse
		totalUpdatedRecord     = 0
		notificationUserModels []models.NotificationUser
		notificationPOST       models.NotificationPOST
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	json.NewDecoder(c.Request.Body).Decode(&notificationPOST)
	for k, v := range notificationPOST.NotificationIDs {
		var (
			resModel models.Notification
		)
		notificationID := v
		resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND NotificationID = ?", notificationID).First(&resModel)
		if resultRow.RowsAffected > 0 {
			resModel.IsDeleted = true
			db.Save(&resModel)
			db.Where("NotificationID = ? AND AccountKey = ?", notificationID, accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&notificationUserModels)
			for _, notificationUser := range notificationUserModels {
				notificationUser.IsDeleted = true
				db.Save(&notificationUser)
			}
			totalUpdatedRecord++
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(notificationPOST.NotificationIDs), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayNotificationToArrayResponse func
func ConvertArrayNotificationToArrayResponse(items []models.Notification, lang string, requestHeader models.RequestHeader, accountKey int) []models.NotificationResponse {
	responses := make([]models.NotificationResponse, 0)
	for _, item := range items {
		response := ConvertNotificationToResponse(item, lang, requestHeader, accountKey)
		responses = append(responses, response)
	}
	return responses
}

// ConvertNotificationToResponse func
func ConvertNotificationToResponse(item models.Notification, lang string, requestHeader models.RequestHeader, accountKey int) models.NotificationResponse {
	var (
		response          models.NotificationResponse
		reason            models.Reason
		notificationUsers models.NotificationUser
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.NotificationID = item.NotificationID
	response.ReasonID = item.ReasonID
	rowResult := db.Where("ReasonID = ?", item.ReasonID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&reason)
	if rowResult.RowsAffected > 0 {
		response.ReasonName = reason.Reason
	}
	response.Comment = item.Comment
	response.NotificationType = item.NotificationType
	response.NotificationTypeName, _ = libs.GetEnum(requestHeader, item.NotificationType, "NotificationType", lang)
	response.CreatedDate = item.CreatedDate
	response.Group = item.Group
	response.GroupName, _ = libs.GetEnum(requestHeader, item.NotificationType, "NotificationGroup", lang)

	rowResult = db.Where("NotificationID = ? AND AccountKey = ?", item.NotificationID, accountKey).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&notificationUsers)
	if rowResult.RowsAffected > 0 {
		response.ReadStatus = notificationUsers.ReadStatus
	}
	return response
}
