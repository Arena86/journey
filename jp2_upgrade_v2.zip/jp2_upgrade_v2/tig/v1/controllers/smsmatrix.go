package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetSMSMatrix godoc
// @Summary GetSMSMatrix
// @Description GetSMSMatrix
// @Tags SMSMatrix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /smsmatrix [get]
func GetSMSMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "GetSMSMatrix")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.SMSMatrix
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter
	// Sort
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArraySMSMatrixToArrayResponse(requestHeader, lang, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// UpdateSMSMatrix godoc
// @Summary UpdateSMSMatrix
// @Description UpdateSMSMatrix
// @Tags SMSMatrix
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SMSMatrix body []models.SMSMatrixResponse true "Update SMSMatrix"
// @Success 200 {object} models.APIResponseData
// @Router /smsmatrix [put]
func UpdateSMSMatrix(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSMSMatrix")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.SMSMatrix
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.SMSMatrix, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resModel models.SMSMatrix
			)
			resModel.PassBodyJSONToModel(bp)
			resultFind := db.Where("SMSMatrixID = ?", resModel.SMSMatrixID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
			resModel.PassBodyJSONToModel(bp)
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resModel)
				} else {
					db.Create(&resModel)
				}
				// @TODO add or update translation table
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resModel)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.SMSMatrix
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.SMSMatrixID)
	}
	if len(arrID) > 0 {
		db.Where("SMSMatrixID in (?)", arrID).Find(&resModels)
		data = ConvertArraySMSMatrixToArrayResponse(requestHeader, lang, resModels)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArraySMSMatrixToArrayResponse func
func ConvertArraySMSMatrixToArrayResponse(requestHeader models.RequestHeader, lang string, items []models.SMSMatrix) []models.SMSMatrixResponse {
	responses := make([]models.SMSMatrixResponse, 0)
	for _, item := range items {
		response := ConvertSMSMatrixToResponse(requestHeader, lang, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertSMSMatrixToResponse func
func ConvertSMSMatrixToResponse(requestHeader models.RequestHeader, lang string, item models.SMSMatrix) models.SMSMatrixResponse {
	var (
		response models.SMSMatrixResponse
	)
	response.SMSMatrixID = item.SMSMatrixID
	if item.TranslationKey != "" && item.TranslationKey != services.GetMessage(lang, item.TranslationKey) {
		response.Caption = services.GetMessage(lang, item.TranslationKey)
	} else {
		response.Caption = item.Caption
	}
	response.Enabled = item.Enabled
	response.SMSTemplate = item.SMSTemplate
	response.Managers = item.Managers
	response.AssignedUser = item.AssignedUser
	response.Customer = item.Customer
	response.Task = item.Task
	response.Task2 = item.Task2
	response.TranslationKey = item.TranslationKey
	return response
}
