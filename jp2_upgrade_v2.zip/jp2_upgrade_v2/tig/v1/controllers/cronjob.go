package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"net/url"
	"os"
	"time"

	"github.com/jasonlvhit/gocron"
)

// DatabaseInfo data
type DatabaseInfo struct {
	DBAccountKey int    `json:"DBAccountKey"`
	DBName       string `json:"DBName"`
	DBUsername   string `json:"DBUsername"`
	DBPassword   string `json:"DBPassword"`
	DBHost       string `json:"DBHost"`
	DBPort       string `json:"DBPort"`
}

// CronJobResponse data
type CronJobResponse struct {
	Status int
	Msg    interface{}
	Data   interface{}
}

// DatabaseInfoResponse data
type DatabaseInfoResponse struct {
	Data []DatabaseInfo `json:"data"`
}

// ConvertDBInfoToRequestHeader func
func ConvertDBInfoToRequestHeader(dbInfo DatabaseInfo) models.RequestHeader {
	var requestHeader models.RequestHeader
	requestHeader.DBName = dbInfo.DBName
	requestHeader.DBUser = dbInfo.DBUsername
	requestHeader.DBPassword = dbInfo.DBPassword
	requestHeader.DBServer = dbInfo.DBHost
	requestHeader.DBPort = dbInfo.DBPort
	return requestHeader
}

// GetDatabasesInfo func
func GetDatabasesInfo() []DatabaseInfo {
	var (
		resDatabaseInfo DatabaseInfoResponse
	)
	databasesInfo := make([]DatabaseInfo, 0)
	serverIP := os.Getenv("CRONJOB_SERVER_IP")
	req, errRequest := http.NewRequest("GET", os.Getenv("SERVER_REE")+"/getdatabasesforcronjob", nil)
	req.Close = true
	if errRequest == nil {
		query := url.Values{}
		query.Add("ip", serverIP)
		req.URL.RawQuery = query.Encode()
		client := &http.Client{Timeout: time.Duration(libs.GetTimeOutAmountWhenCallAPI()) * time.Second}
		resp, err := client.Do(req)
		if err == nil {
			body, _ := ioutil.ReadAll(resp.Body)
			json.Unmarshal([]byte(string(body)), &resDatabaseInfo)
			databasesInfo = resDatabaseInfo.Data
		}
	}
	return databasesInfo
}

// CronJob func
func CronJob() {
	gocron.Clear()
	go func() {
		databasesInfo := GetDatabasesInfo()
		for _, dbInfo := range databasesInfo {
			go func(dbInfo DatabaseInfo) {
				defer func() {
					if r := recover(); r != nil {
					}
				}()
				db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)

				var (
					xeroConfig models.XeroConfig
				)
				resultFindXeroConfig := db.First(&xeroConfig)
				if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive && xeroConfig.UseXeroPush &&
					xeroConfig.IntervalInSeconds > 0 && xeroConfig.AccessToken != "" {
					go func(dbInfo DatabaseInfo) {
						s := gocron.NewScheduler()
						fmt.Printf("CronJobImportsFromXeroForEveryDatabase: [%s] [%s] \n", dbInfo.DBName, time.Now())
						s.Every(uint64(xeroConfig.IntervalInSeconds)).Seconds().Do(CronJobImportsFromXeroForEveryDatabase, dbInfo, time.Now().UTC())
						<-s.Start()
					}(dbInfo)
				}

				// jobFileConfig
				/*var (
					jobFileConfig models.JobFileConfig
				)
				resultFindJobFileConfig := db.First(&jobFileConfig)
				//libs.PrintJSON(jobFileConfig)
				if resultFindJobFileConfig.RowsAffected > 0 && jobFileConfig.IsActive &&
					jobFileConfig.IntervalInSeconds > 0 && jobFileConfig.AccessToken != "" {
					go func(dbInfo DatabaseInfo, jobFileConfig models.JobFileConfig) {
						s := gocron.NewScheduler()
						fmt.Printf("CronJobImportsFromJobFileConfigForEveryDatabase: [%s] [%s] \n", dbInfo.DBName, time.Now())
						s.Every(uint64(jobFileConfig.IntervalInSeconds)).Seconds().Do(CronJobImportsFromJobFileConfigForEveryDatabase, dbInfo, jobFileConfig)
						<-s.Start()
					}(dbInfo, jobFileConfig)
				}*/
			}(dbInfo)
		}
	}()
}

// CronJobImportsFromXeroForEveryDatabase func
func CronJobImportsFromXeroForEveryDatabase(dbInfo DatabaseInfo, firstTimeRun time.Time) {
	currentTime := time.Now().UTC()
	db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)

	var (
		xeroConfig               models.XeroConfig
		timeFilterHeaderItem     time.Time
		timeFilterHeaderCustomer time.Time
		accountKey               int
		lang                     string
		userMaster               models.User
	)
	resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.AccessToken != "" {
		if xeroConfig.LastTimeItem != nil {
			lastTimeItem := *xeroConfig.LastTimeItem
			timeFilterHeaderItem = lastTimeItem.UTC()
			xeroConfig.LastTimeItem = &currentTime
		} else {
			xeroConfig.LastTimeItem = &firstTimeRun
			timeFilterHeaderItem = firstTimeRun.UTC()
		}
		if xeroConfig.LastTimeCustomer != nil {
			lastTimeCustomer := *xeroConfig.LastTimeCustomer
			timeFilterHeaderCustomer = lastTimeCustomer.UTC()
			xeroConfig.LastTimeCustomer = &currentTime
		} else {
			xeroConfig.LastTimeCustomer = &firstTimeRun
			timeFilterHeaderCustomer = firstTimeRun.UTC()
		}
		lang = services.BundleObject.DefaultLanguage.String()
		resultFindUserMaster := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsMaster, 0) = 1").First(&userMaster)
		if resultFindUserMaster.RowsAffected > 0 {
			accountKey = userMaster.UserID
		}
		requestHeader := ConvertDBInfoToRequestHeader(dbInfo)
		go Initialize(xeroConfig, accountKey, lang, requestHeader, &timeFilterHeaderItem, &timeFilterHeaderCustomer)
	}
}
