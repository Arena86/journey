package controllers

import (
	"encoding/json"
	"fmt"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
)

func CronJobImportsFromJobFileConfigForEveryDatabase(dbInfo DatabaseInfo, jobFileConfig models.JobFileConfig) {
	exportQueueURL := jobFileConfig.APIURL + "/exportqueues/" + strconv.Itoa(jobFileConfig.ExportQueueID)
	lang := services.BundleObject.DefaultLanguage.String()
	headers := make(map[string]interface{})
	headers["token"] = jobFileConfig.AccessToken

	var (
		requestHeader models.RequestHeader
		security      string
	)
	requestHeader.DBName = dbInfo.DBName
	requestHeader.DBUser = dbInfo.DBUsername
	requestHeader.DBPassword = dbInfo.DBPassword
	requestHeader.DBServer = dbInfo.DBHost
	requestHeader.DBPort = dbInfo.DBPort
	securityJSON, _ := json.Marshal(requestHeader)
	key := []byte(os.Getenv("SERCURITY_KEY"))
	encryptSecurityData, errEncrypt := libs.EncryptJSON(securityJSON, key)
	if errEncrypt == nil {
		security = libs.EncodeBase64(encryptSecurityData)
	}
	headers["security"] = security
	params := make(map[string]interface{})
	statusRes, msgRes, dataRes := libs.RequestAPI(lang, "GET", exportQueueURL, nil, params, headers)
	if statusRes == 200 {
		var jpResponse map[string]interface{}
		json.Unmarshal(dataRes, &jpResponse)
		libs.PrintJSON(jpResponse)
	} else {
		fmt.Println("msgRes: ", msgRes)
	}

}
