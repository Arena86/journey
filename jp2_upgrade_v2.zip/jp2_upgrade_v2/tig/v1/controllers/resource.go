package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetResource func
func GetResource(c *gin.Context) {
	defer libs.RecoverError(c, "GetResource")
	var (
		status        = libs.GetStatusSuccess()
		resources     []models.Resource
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, _ := libs.GetQueryParam("Start", c)
	vLength, _ := libs.GetQueryParam("Length", c)

	var bp = db

	if vStart != "" && vLength != "" {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
		vStartInt, _ := strconv.Atoi(vStart)
		vLengthInt, _ := strconv.Atoi(vLength)
		bp = bp.Limit(vLengthInt).Offset(vStartInt)
	}
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}
	arrBool := []string{"ShowInScheduler"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"ResourceCode", "RegistrationNumber", "Level", "ResourceName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{
		"ResourceMode", "UserID", "ResourceType",
		"CubicMeter", "MaxLoadingWeight", "SquareMeter",
	}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Resource{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c, "ResourceModeName", "ResourceTypeName")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resources).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resources) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayResourcesToArrayResponse(requestHeader, resources)
	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, b.ResourceID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetSchedulerResource godoc
// @Summary Get Scheduler Resource
// @Description Get Scheduler Resource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param ShowInscheduler query bool false "ShowInscheduler"
// @Param FromDate query string false "FromDate: yyyy-mm-dd"
// @Param ToDate query string false "ToDate: yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /schedulerresource [get]
func GetSchedulerResource(c *gin.Context) {
	defer libs.RecoverError(c, "GetSchedulerResource")
	var (
		status              = libs.GetStatusSuccess()
		resources           []models.Resource
		requestHeader       models.RequestHeader
		response            models.APIResponseData
		msg                 interface{}
		locationResources   []models.Resource
		arrResourceID       = make([]int, 0)
		schedules           []models.Schedule
		additionalResources []models.AdditionalResource
		isSmartScheduling   = false
		includeExternal     = true
		fromDate            time.Time
		toDate              time.Time
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	format := libs.FORMATDATE
	formatDateTime := libs.FORMATDATETIME
	scheduleFormat := libs.MYSQLDATE
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	vScheduleFromDate := ""
	vFromDateTime := ""
	vToDateTime := ""
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		fromDate = dFromDate
		if errFromDate == nil {
			vFromDate = dFromDate.Format(format)
			vFromDateTime = dFromDate.Format(formatDateTime)
			vScheduleFromDate = dFromDate.Format(scheduleFormat)
		}
	}
	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	vScheduleToDate := ""
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		toDate = dToDate
		if errToDate == nil {
			vToDate = dToDate.Format(format)
			vToDateTime = dToDate.Format(formatDateTime)
			vScheduleToDate = dToDate.Format(scheduleFormat)
		}
	}
	vSmartScheduling, sSmartScheduling := libs.GetQueryParam("issmartscheduling", c)
	if sSmartScheduling {
		isSmartScheduling, _ = strconv.ParseBool(vSmartScheduling)
	}
	var rdb = db

	if isSmartScheduling {
		delta := toDate.Sub(fromDate)
		if delta.Hours() > 24 {
			includeExternal = false
		}
	}

	rdb = rdb.Select("ResourceID")
	rdb = rdb.Where("LocationID = ?", locationID)
	rdb = rdb.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	arrBool := []string{"ShowInScheduler"}
	rdb = libs.FilterBool(arrBool, rdb, c)
	rdb.Find(&locationResources)
	for _, locationResource := range locationResources {
		arrResourceID = append(arrResourceID, locationResource.ResourceID)
	}
	if sFromDate && sToDate {
		// find in schedules
		db.Select("ResourceID").Where("ScheduleEndDate > ? AND ScheduleStartDate < ? ",
			vScheduleFromDate, vScheduleToDate).
			Where(
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND LocationID = ?", locationID,
			).Find(&schedules)
		if len(schedules) > 0 {
			for _, schedule := range schedules {
				if !libs.InArrayInteger(schedule.ResourceID, arrResourceID) {
					arrResourceID = append(arrResourceID, schedule.ResourceID)
				}
			}
		}

		// find in additionalresources
		db.Debug().Select("ResourceID").Where(
			"DATE_FORMAT(FromDate, '%Y-%m-%d %H:%i') >= ? AND DATE_FORMAT(ToDate, '%Y-%m-%d %H:%i') <= ?",
			vFromDateTime, vToDateTime,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1  AND LocationID = ?", locationID,
		).Find(&additionalResources)
		if len(additionalResources) > 0 {
			for _, additionalResource := range additionalResources {
				if !libs.InArrayInteger(additionalResource.ResourceID, arrResourceID) {
					arrResourceID = append(arrResourceID, additionalResource.ResourceID)
				}
			}
		}
	}

	// Paging
	vStart, _ := libs.GetQueryParam("Start", c)
	vLength, _ := libs.GetQueryParam("Length", c)

	// Filter ShowInScheduler
	if len(arrResourceID) > 0 {
		var bp = db

		if vStart != "" && vLength != "" {
			iStart, eStart := strconv.Atoi(vStart)
			if eStart == nil {
				iStart = iStart - 1
				if iStart < 0 {
					iStart = 0
				}
			}
			vStart = strconv.Itoa(iStart)
			vStartInt, _ := strconv.Atoi(vStart)
			vLengthInt, _ := strconv.Atoi(vLength)
			bp = bp.Limit(vLengthInt).Offset(vStartInt)
		}

		bp = bp.Where("ResourceID in (?)", arrResourceID)
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
		arrBool := []string{"ShowInScheduler"}
		bp = libs.FilterBool(arrBool, bp, c)
		bp.Find(&resources)
	}
	var responsesFinal []models.ResourceResponse
	responsesFinal = make([]models.ResourceResponse, 0)
	responses := ConvertArrayResourcesToArrayResponse(requestHeader, resources)
	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, b.ResourceID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
		responses[i].SchedulerUsers = GetSchedulerUserResource(requestHeader, b, locationID, vFromDate, vToDate)
		responses[i].SchedulerResources = GetSchedulerResourceByDate(requestHeader, b, locationID, vFromDate, vToDate)

		// IsReserved - a resource is allocated to another Location.
		var (
			ars []models.AdditionalResource
		)
		db.Where(
			"ResourceID = ?", b.ResourceID,
		).Where(
			"DATE_FORMAT(FromDate, '%Y-%m-%d %H:%i:%s') >= ? AND DATE_FORMAT(FromDate, '%Y-%m-%d %H:%i:%s') <= ?",
			vFromDateTime, vToDateTime,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where(
			"LocationID <> ?", locationID,
		).Find(&ars)

		if len(ars) > 0 {
			responses[i].SchedulerUsers = GetSchedulerUserResource(requestHeader, b, ars[0].LocationID, vFromDate, vToDate)
		}

		if !isSmartScheduling {
			responsesFinal = append(responsesFinal, responses[i])
		} else {
			forSmartScheduling := true
			for _, v := range responses[i].SchedulerResources {
				if v.IsReserved {
					forSmartScheduling = false
					break
				}
				if !includeExternal {
					if v.IsExternal {
						forSmartScheduling = false
						break
					}
				}
			}

			if forSmartScheduling {
				var schedules []models.Schedule
				db.Debug().Select("ResourceID").Where("ScheduleEndDate > ? AND ScheduleStartDate < ? ",
					vScheduleFromDate, vScheduleToDate).
					Where(
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ResourceID = ?", b.ResourceID,
					).Find(&schedules)
				if len(schedules) > 0 {
					forSmartScheduling = false
				}
			}
			if forSmartScheduling {
				responsesFinal = append(responsesFinal, responses[i])
			}
		}
	}
	msg = services.GetMessage(lang, "api.success")
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = responsesFinal
	libs.APIResponseData(response, c, status)
}

// GetResourceByID godoc
// @Summary Get Resource By ID
// @Description Get Resource  By ID
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param id path int true "Resource ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /resource/{id} [get]
func GetResourceByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetResourceByID")
	var (
		status         = libs.GetStatusSuccess()
		resources      models.Resource
		requestHeader  models.RequestHeader
		errorsResponse []models.ErrorResponse
		response       models.APIResponseData
		msg, data      interface{}
		responsesData  gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND ResourceID = ?", ID).First(&resources)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertResourceToResponse(requestHeader, resources)
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses.UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, responses.ResourceID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses.UDFs = udfResponses
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetResourceByUser godoc
// @Summary Get Resource By User
// @Description Get Resource  By User
// @Tags API
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getresourcebyuser [get]
func GetResourceByUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetResourceByUser")
	var (
		status         = libs.GetStatusSuccess()
		resources      models.Resource
		requestHeader  models.RequestHeader
		errorsResponse []models.ErrorResponse
		response       models.APIResponseData
		msg, data      interface{}
		responsesData  gin.H
		userModel      models.User
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
	if resultFindUser.RowsAffected > 0 {
		resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND UserID = ?", userModel.UserID).First(&resources)
		if resultRow.RowsAffected > 0 {
			msg = services.GetMessage(lang, "api.success")
			responses := ConvertResourceToResponse(requestHeader, resources)
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			responses.UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, responses.ResourceID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				responses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			responses.UDFs = udfResponses
			data = responses
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
			status = libs.GetStatusNotFound()
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateResource godoc
// @Summary Create Resource
// @Description Create Resource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Resource body []models.ResourceResponse true "Create Resource"
// @Success 200 {object} models.APIResponseData
// @Router /resource [post]
func CreateResource(c *gin.Context) {
	defer libs.RecoverError(c, "CreateResource")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Resource
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.Resource, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			// validate license
			var (
				resource models.Resource
			)
			resource.PassBodyJSONToModel(bp)
			resultFind := db.Where("ResourceID = ?", resource.ResourceID).First(&resource)
			resource.PassBodyJSONToModel(bp)
			//resource.UserID = accountKey

			CheckDocumentSequencesBeforeCreate(requestHeader)
			var (
				sequencyModel  models.DocumentSequency
				resourcePrefix models.Prefix
			)
			db.First(&sequencyModel)
			db.Where("DocumentSequence = ?", "ResourceCode").First(&resourcePrefix)
			resource.GenerateDefaultValue(sequencyModel, resourcePrefix)

			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resource)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&resource)
				} else {
					db.Create(&resource)
					IncreaseDocumentSequencesAfterCreateResource(requestHeader)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resource)

				var (
					itemMsgError string
				)
				// @TODO process for UDFs
				arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
				// @TODO update data for UDFs
				errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ResourceID", resource.ResourceID)
				if len(errUDFs) > 0 {
					for _, e := range errUDFs {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resources []models.Resource
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ResourceID)
	}
	if len(arrID) > 0 {
		db.Where("ResourceID in (?)", arrID).Find(&resources)
		dataResponses := ConvertArrayResourcesToArrayResponse(requestHeader, resources)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string

			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, b.ResourceID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses

	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateResource godoc
// @Summary Update Resource
// @Description Update Resource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Resource body []models.ResourceResponse true "Create Resource"
// @Success 200 {object} models.APIResponseData
// @Router /resource [put]
func UpdateResource(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateResource")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Resource
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Resource, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				resource models.Resource
			)
			resource.PassBodyJSONToModel(bp)
			resultFind := db.Where("ResourceID = ?", resource.ResourceID).First(&resource)
			resource.PassBodyJSONToModel(bp)
			//resource.UserID = accountKey
			resource.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resource)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				if resultFind.RowsAffected > 0 {
					db.Save(&resource)
				} else {
					db.Create(&resource)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, resource)

				// @TODO process for UDFs
				arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
				// @TODO update data for UDFs
				errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ResourceID", resource.ResourceID)
				if len(errUDFs) > 0 {
					for _, e := range errUDFs {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resources []models.Resource
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ResourceID)
	}
	if len(arrID) > 0 {
		db.Where("ResourceID in (?)", arrID).Find(&resources)
		dataResponses := ConvertArrayResourcesToArrayResponse(requestHeader, resources)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Resource{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ResourceID", v.DataType, b.ResourceID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateResourceGPSLocation godoc
// @Summary Update Resource
// @Description Update Resource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Resource body []models.ResourceResponse true "Create Resource"
// @Success 200 {object} models.APIResponseData
// @Router /updateresourcegpslocation/{resourceid} [put]
func UpdateResourceGPSLocation(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateResourceGPSLocation")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.Resource
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	var (
		resource models.Resource
	)
	resourceID := c.Param("resourceid")
	resultFind := db.Where("ResourceID = ?", resourceID).First(&resource)
	if resultFind.RowsAffected > 0 {
		val, res := services.ConvertJSONValueToVariable("CurrentLatitude", objectsJSON)
		if res != nil {
			resource.CurrentLatitude = val
		}
		val, res = services.ConvertJSONValueToVariable("CurrentLongitude", objectsJSON)
		if res != nil {
			resource.CurrentLongitude = val
		}
		resource.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resource)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			db.Save(&resource)
			totalUpdatedRecord++
			dataResponse = resource
		}
	} else {
		status = libs.GetStatusNotFound()
		msg = services.GetMessage(lang, "api.no_record_found")
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	var (
		resources models.Resource
	)
	if dataResponse.ResourceID > 0 {
		db.Where("ResourceID = ?", dataResponse.ResourceID).Find(&resources)
		data = ConvertResourceToResponse(requestHeader, resources)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// DeleteResource godoc
// @Summary Delete Resource
// @Description Delete Resource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Resource ID"
// @Success 200 {object} models.APIResponseData
// @Router /resource/{id} [delete]
func DeleteResource(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteResource")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)

	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Resource
		)
		resultFind := db.Where("ResourceID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := uModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				uModel.IsDeleted = true
				deletedResult := db.Save(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayResourcesToArrayResponse func
func ConvertArrayResourcesToArrayResponse(requestHeader models.RequestHeader, items []models.Resource) []models.ResourceResponse {
	responses := make([]models.ResourceResponse, 0)
	for _, item := range items {
		response := ConvertResourceToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertResourceToResponse func
func ConvertResourceToResponse(requestHeader models.RequestHeader, item models.Resource) models.ResourceResponse {
	var (
		response         models.ResourceResponse
		resourceModeEnum models.Enumerator
		resourceTypeEnum models.Enumerator
	)

	response.ResourceID = item.ResourceID
	response.ResourceCode = item.ResourceCode
	response.ResourceName = item.ResourceName
	response.ResourceMode = item.ResourceMode
	response.ResourceColor = item.ResourceColor
	//response.UserID = item.UserID
	response.ResourceType = item.ResourceType
	response.RegistrationNumber = item.RegistrationNumber
	response.CubicMeter = item.CubicMeter
	response.MaxLoadingWeight = item.MaxLoadingWeight
	response.SquareMeter = item.SquareMeter
	response.Level = item.Level
	response.NavigationAddress = item.NavigationAddress
	response.CurrentLatitude = item.CurrentLatitude
	response.CurrentLongitude = item.CurrentLongitude
	response.ShowInScheduler = item.ShowInScheduler
	response.VehicleInspectionID = item.VehicleInspectionID
	response.VehicleInspectionDay = libs.StringToArray(item.VehicleInspectionDay)
	response.VehicleStocktakeID = item.VehicleStocktakeID
	response.VehicleStocktakeDay = libs.StringToArray(item.VehicleStocktakeDay)
	response.BuyPriceByHour = item.BuyPriceByHour
	response.SellPriceByHour = item.SellPriceByHour
	response.LocationID = item.LocationID
	response.Note = item.Note

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultEnum := db.Where("FieldName = ? AND Status = ?", "ResourceMode", item.ResourceMode).First(&resourceModeEnum)
	if resultEnum.RowsAffected > 0 {
		response.ResourceModeName = resourceModeEnum.Caption
	}
	resultEnum = db.Where("FieldName = ? AND Status = ?", "ResourceType", item.ResourceType).First(&resourceTypeEnum)
	if resultEnum.RowsAffected > 0 {
		response.ResourceTypeName = resourceTypeEnum.Caption
		response.Icon = resourceTypeEnum.Icon
	}
	var inspectionHistoryCount int64
	inspectionHistoryCount = 0
	db.Where("VehicleInspectionID = ?", item.VehicleInspectionID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&[]models.VehicleInspectionHistory{}).Count(&inspectionHistoryCount)
	response.InspectionHistoryCount = int(inspectionHistoryCount)
	var stocktakeHistoryCount int64
	stocktakeHistoryCount = 0
	db.Where("VehicleStocktakeID = ?", item.VehicleStocktakeID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&[]models.VehicleStocktakeHistory{}).Count(&stocktakeHistoryCount)
	response.StocktakeHistoryCount = int(stocktakeHistoryCount)

	response.MaxDistance = item.MaxDistance
	response.MaxDrivingTime = item.MaxDrivingTime
	response.MaxJobs = item.MaxJobs
	response.MinJobs = item.MinJobs
	response.UseMaxDrivingTime = item.UseMaxDrivingTime
	response.BreakDuration = item.BreakDuration
	response.TotalMaxDrivingTime = item.TotalMaxDrivingTime
	response.InitialDrivingTime = item.InitialDrivingTime
	response.VehicleLength = item.VehicleLength

	return response
}

// IncreaseDocumentSequencesAfterCreateResource func
func IncreaseDocumentSequencesAfterCreateResource(requestHeader models.RequestHeader) {
	var (
		resModel models.DocumentSequency
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	resultFind := db.First(&resModel)
	resModel.ResourceCode = resModel.ResourceCode + 1
	if resultFind.RowsAffected > 0 {
		db.Save(&resModel)
	} else {
		db.Create(&resModel)
	}
}

// GetSchedulerUserResource func
func GetSchedulerUserResource(requestHeader models.RequestHeader, resource models.ResourceResponse, locationID int, fromDate string, toDate string) []models.SchedulerUserResourceResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		scheduleUsers = make([]models.SchedulerUserResourceResponse, 0)
	)
	format := libs.FORMATDATE
	dFromDate, errFromDate := libs.ConvertStringToDateTime(fromDate)
	dToDate, errToDate := libs.ConvertStringToDateTime(toDate)
	if errFromDate == nil && errToDate == nil {
		days := int(dToDate.Sub(dFromDate).Hours()) / 24
		if days >= 0 {
			for i := 0; i <= days; i++ {
				nextFromDate := dFromDate
				nextFromDate = nextFromDate.AddDate(0, 0, i)
				sNextFromDate := nextFromDate.Format(format)
				var scheduleUser models.SchedulerUserResourceResponse
				scheduleUser.ResourceID = resource.ResourceID
				scheduleUser.LocationID = locationID
				scheduleUser.SchedulerDate = sNextFromDate
				scheduleUsers = append(scheduleUsers, scheduleUser)
			}
		}
	}
	for k, scheduleUser := range scheduleUsers {
		var (
			schedule      models.Schedule
			schedulerUser models.SchedulerUser
			user          models.User
		)
		// find in schedule first if not found then find in schedulerusers
		resultFindSchedule := db.Where(
			"DATE_FORMAT(ScheduleStartDate, '%Y-%m-%d') = ? AND ResourceID = ? AND LocationID = ?",
			scheduleUser.SchedulerDate,
			scheduleUser.ResourceID,
			scheduleUser.LocationID,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).First(&schedule)
		if resultFindSchedule.RowsAffected > 0 {
			scheduleUsers[k].UserID = schedule.UserID
		} else {
			// find in schedulerusers
			resultFindSchedulerUser := db.Where(
				"DATE_FORMAT(SchedulerDate, '%Y-%m-%d') = ? AND ResourceID = ? AND LocationID = ?",
				scheduleUser.SchedulerDate,
				scheduleUser.ResourceID,
				scheduleUser.LocationID,
			).Where(
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).First(&schedulerUser)
			if resultFindSchedulerUser.RowsAffected > 0 {
				scheduleUsers[k].SchedulerUserID = schedulerUser.SchedulerUserID
				scheduleUsers[k].UserID = schedulerUser.UserID
			}
		}
		if scheduleUsers[k].UserID > 0 {
			resultFindUser := db.Where(
				"UserID = ?",
				scheduleUsers[k].UserID,
			).Where(
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).First(&user)
			if resultFindUser.RowsAffected > 0 {
				scheduleUsers[k].FirstName = user.FirstName
				scheduleUsers[k].LastName = user.LastName
				scheduleUsers[k].Email = user.Email
				scheduleUsers[k].PhoneNumber = user.PhoneNumber
			}
		}
	}

	return scheduleUsers
}

// GetSchedulerResourceByDate func
func GetSchedulerResourceByDate(requestHeader models.RequestHeader, resource models.ResourceResponse, locationID int, fromDate string, toDate string) []models.SchedulerResourceResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		scheduleResources = make([]models.SchedulerResourceResponse, 0)
	)
	format := libs.FORMATDATE
	dFromDate, errFromDate := libs.ConvertStringToDateTime(fromDate)
	dToDate, errToDate := libs.ConvertStringToDateTime(toDate)
	if errFromDate == nil && errToDate == nil {
		days := int(dToDate.Sub(dFromDate).Hours()) / 24
		if days >= 0 {
			for i := 0; i <= days; i++ {
				nextFromDate := dFromDate
				nextFromDate = nextFromDate.AddDate(0, 0, i)
				sNextFromDate := nextFromDate.Format(format)
				var scheduleResource models.SchedulerResourceResponse
				scheduleResource.LocationID = locationID
				scheduleResource.SchedulerDate = sNextFromDate
				scheduleResources = append(scheduleResources, scheduleResource)
			}
		}
	}
	for k, scheduleResource := range scheduleResources {
		var (
			ars []models.AdditionalResource
		)
		db.Where(
			"ResourceID = ?", resource.ResourceID,
		).Where(
			"DATE_FORMAT(FromDate, '%Y-%m-%d') >= ? AND DATE_FORMAT(FromDate, '%Y-%m-%d') <= ?",
			scheduleResource.SchedulerDate, scheduleResource.SchedulerDate,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Find(&ars)
		if len(ars) > 0 {
			scheduleResources[k].ResourceID = resource.ResourceID
			for _, additionalResource := range ars {
				if additionalResource.LocationID != locationID {
					scheduleResources[k].IsReserved = true
				}
				if additionalResource.LocationID == locationID {
					scheduleResources[k].IsExternal = true
				}
			}
		}
	}

	return scheduleResources
}
