package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
)

// SendSMSAfterProcessJob func
func SendSMSAfterProcessJob(requestHeader models.RequestHeader, accountKey int, lang string, smsMatrixID int, jobID int) (int, string, []models.SendSMSResponse) {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		statusSendSMS    = libs.GetStatusSuccess()
		msgSendSMS       string
		smsMatrixModel   models.SMSMatrix
		smsTemplateModel models.SMSTemplate
		jobModel         models.Job
		sendSMSResponses = make([]models.SendSMSResponse, 0)
		smsServiceConfig models.SMSServiceConfig
	)
	resultFindSMSMatrix := db.Where("SMSMatrixID = ?", smsMatrixID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&smsMatrixModel)
	if resultFindSMSMatrix.RowsAffected > 0 {
		if !smsMatrixModel.Enabled {
			statusSendSMS = 422
			msgSendSMS = services.GetMessage(lang, "api.smsmatrixid_not_enable")
		}
		if statusSendSMS == libs.GetStatusSuccess() {
			if smsMatrixModel.SMSTemplate <= 0 {
				statusSendSMS = 422
				msgSendSMS = services.GetMessage(lang, "api.smstemplate_not_found")
			} else {
				resultFindSMSTemplate := db.Where("SMSTemplateID = ?", smsMatrixModel.SMSTemplate).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&smsTemplateModel)
				if resultFindSMSTemplate.RowsAffected <= 0 {
					statusSendSMS = 422
					msgSendSMS = services.GetMessage(lang, "api.smstemplate_not_found")
				} else {
					// body empty
					if smsTemplateModel.Body == "" {
						statusSendSMS = 422
						msgSendSMS = services.GetMessage(lang, "api.smstemplate_content_required")
					}
				}
			}
		}
	} else {
		statusSendSMS = 404
		msgSendSMS = services.GetMessage(lang, "api.smsmatrixid_not_found")
	}
	if statusSendSMS == libs.GetStatusSuccess() {
		resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected <= 0 {
			statusSendSMS = 404
			msgSendSMS = services.GetMessage(lang, "api.jobid_not_found")
		}
		smsServiceConfig = libs.GetSMSService(accountKey)
		if smsServiceConfig.SMSKey == "" {
			statusSendSMS = 422
			msgSendSMS = libs.GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_key_required"))
		}
		if smsServiceConfig.SMSPassword == "" {
			statusSendSMS = 422
			msgSendSMS = libs.GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_password_required"))
		}
		if smsServiceConfig.SMSURL == "" {
			statusSendSMS = 422
			msgSendSMS = libs.GetStringWithWordBetween(msgSendSMS, services.GetMessage(lang, "api.smsservice_url_required"))
		}
	}
	if statusSendSMS == libs.GetStatusSuccess() {
		switch smsMatrixID {
		case 1, 2, 3, 6:
			{
				// 1. After Schedule Committed, 2. Job Reminder, 3. Start From Depot, 6. Reschedule
				// send to Customer
				if smsMatrixModel.Customer {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfJob(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				// send to Task
				if smsMatrixModel.Task {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfTask(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel, jobModel.JobType)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				// send to Task2
				if smsMatrixModel.Task2 {
					if jobModel.JobType == 4 {
						var sendSMSResponse models.SendSMSResponse
						sendSMSResponse = libs.SendSMSOfTask2(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
						sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
					}
				}
				break
			}
		case 4:
			{
				// 4. Start Driving to Task1
				// send to Customer
				if smsMatrixModel.Customer {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfCustomer(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				// send to Task
				if smsMatrixModel.Task {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfTask(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel, jobModel.JobType)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				break
			}
		case 5:
			{
				// 5. Start Driving to Task2
				// send to Customer
				if smsMatrixModel.Customer {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfCustomer(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				// send to Task2
				if smsMatrixModel.Task2 {
					if jobModel.JobType == 4 {
						var sendSMSResponse models.SendSMSResponse
						sendSMSResponse = libs.SendSMSOfTask2(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
						sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
					}
				}
				break
			}
		case 7, 8:
			{
				// 7. Job Completed, 8. Job Collection
				// send to Managers
				if smsMatrixModel.Managers {
					var sendSMSResponseManagers = make([]models.SendSMSResponse, 0)
					sendSMSResponseManagers = libs.SendSMSOfManagers(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponseManagers...)
				}
				// send to Customer
				if smsMatrixModel.Customer {
					var sendSMSResponse models.SendSMSResponse
					sendSMSResponse = libs.SendSMSOfCustomer(requestHeader, smsServiceConfig, accountKey, lang, smsTemplateModel, jobModel)
					sendSMSResponses = append(sendSMSResponses, sendSMSResponse)
				}
				break
			}
		default:
			{
				statusSendSMS = 422
				msgSendSMS = services.GetMessage(lang, "api.smsmatrixid_invalid")
			}
		}
	}
	if statusSendSMS == 200 {
		msgSendSMS = services.GetMessage(lang, "api.success")
	}
	return statusSendSMS, msgSendSMS, sendSMSResponses
}
