package controllers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	redisdynamic "jpapi/tig/v1/databases/drivers/redisdynamic"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
)

// GetRedisDataByKey func
func GetRedisDataByKey(conn *redis.Client, key string) (interface{}, int, error) {
	var (
		err    error
		status = 200
		data   interface{}
	)

	existKey, errSub := conn.Exists(context.Background(), key).Result()
	if errSub == nil {
		if existKey == 1 {
			resRedis := conn.Type(context.Background(), key)
			if resRedis.Err() == nil {
				keyType := resRedis.Val()
				switch keyType {
				case "string":
					{
						dataSub, errSub := conn.Get(context.Background(), key).Result()
						if errSub == nil {
							var (
								objectData interface{}
							)
							json.Unmarshal([]byte(dataSub), &objectData)
							data = objectData
						}
					}
				case "hash":
					{
						dataSub, errSub := conn.HGetAll(context.Background(), key).Result()
						if errSub == nil {
							data = dataSub
						}
					}
				case "list":
					{
						lenKey, errSub := conn.LLen(context.Background(), key).Result()
						if errSub == nil {
							if lenKey > 0 {
								dataSub, errSub := conn.LRange(context.Background(), key, 0, lenKey-1).Result()
								if errSub == nil {
									data = dataSub
								}
							}
						}
					}
				default:
					{
						status = 404
						err = errors.New("Type is not found")
					}
				}
			} else {
				status = 500
				err = resRedis.Err()
			}
		} else {
			status = 404
			err = errors.New("Key is not found")
		}
	} else {
		status = 500
		err = errSub
	}
	return data, status, err
}

// DeleteRedisData godoc
// @Summary DeleteRedisData
// @Description DeleteRedisData
// @Tags Redis
// @Accept  json
// @Produce  json
// @Param Socket query string false "Socket"
// @Param FromDate query string false "FromDate"
// @Param ToDate query string false "ToDate"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /deleteredisdata [delete]
func DeleteRedisData(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteRedisData")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
	)
	const SocketNameGPS = "gps"
	const SocketNameChat = "cha"
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	fmt.Println("time.Now:               start: ", time.Now().Format("2006-01-02 15:04:05.999"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	token := c.Request.Header.Get("token")
	companyID := c.Request.Header.Get("companyid")
	errorsResponse = make([]models.ErrorResponse, 0)

	statusRee, msgRee, redisConfig := libs.GetRedisConfigByCompanyID(lang, accountKey, token, companyID)
	if statusRee == 200 {
		var (
			socketName       string
			validateMsgError string
			fromDate, toDate *time.Time
		)
		vSocket, sSocket := libs.GetQueryParam("socket", c)
		if sSocket {
			socketName = vSocket
			if socketName != "" {
				socketName = strings.ToLower(socketName)
			}
			switch socketName {
			case SocketNameChat, SocketNameGPS:
			default:
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.socket_name_invalid"))

			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.socket_name_required"))
		}

		vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
		if sFromDate {
			dFromDate, eFromDate := libs.ConvertStringToDateTime(vFromDate)
			if eFromDate == nil {
				fromDate = &dFromDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))

		}
		vToDate, sToDate := libs.GetQueryParam("ToDate", c)
		if sToDate {
			dToDate, eToDate := libs.ConvertStringToDateTime(vToDate)
			if eToDate == nil {
				toDate = &dToDate
			} else {
				status = 422
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
			}
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
		}
		if status == 200 {
			// get dynamic connection
			arrKeys := make([]string, 0)
			arrDateKey := make([]string, 0)
			arrPatternKey := make([]string, 0)
			redisDatabase := -1
			pattern := "--------------------"
			switch socketName {
			case SocketNameGPS:
				redisDatabase = redisConfig.RedisDatabaseGPS
				pattern = "tb|gps*"
			case SocketNameChat:
				redisDatabase = redisConfig.RedisDatabaseChat
				pattern = "tb|cha*"
			}

			fmt.Println("redisConfig: ", redisConfig)
			conn := redisdynamic.GetRedisConnectionDynamic(redisConfig.RedisServer, redisConfig.RedisPort, redisConfig.RedisPassword, redisDatabase)

			if fromDate != nil && toDate != nil {
				dFromDate := *fromDate
				fromDateUnix := dFromDate.Unix()
				dToDate := *toDate
				toDateUnix := dToDate.Unix()
				if fromDateUnix > toDateUnix {
					temp := dFromDate
					dFromDate = dToDate
					dToDate = temp
				}
				dToDate, _ = libs.ConvertStringToDateTime(dToDate.Format("2006-01-02"))
				i := 0
				for {
					newDate := dFromDate.AddDate(0, 0, i)
					newDate, _ = libs.ConvertStringToDateTime(newDate.Format("2006-01-02"))
					if newDate.Unix() > dToDate.Unix() {
						break
					}
					arrDateKey = append(arrDateKey, newDate.Format("20060102"))
					i++
				}
			}
			if len(arrDateKey) > 0 {
				for _, k := range arrDateKey {
					newPatternKey := ``
					newPatternKey = pattern + "|dt|" + k + "*"
					arrPatternKey = append(arrPatternKey, newPatternKey)
				}
			} else {
				newPatternKey := pattern
				arrPatternKey = append(arrPatternKey, newPatternKey)
			}

			fmt.Println("arrPatternKey: ", arrPatternKey)
			fmt.Println("time.Now:     find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
			lenArrayPattern := len(arrPatternKey)
			cResponseGetRedisKey := make(chan models.CronJobResponseRedisKey, lenArrayPattern)
			for _, pattern := range arrPatternKey {
				go func(cResponseGetRedisKey chan models.CronJobResponseRedisKey, connn *redis.Client, pattern string) {
					var responseGetRedisKey models.CronJobResponseRedisKey
					resRedis := connn.Do(redisdynamic.Ctx, "KEYS", pattern)
					if resRedis.Err() == nil {
						keyInterface := resRedis.Val()
						arrKeysInterface, sKeysInterface := keyInterface.([]interface{})
						if sKeysInterface {
							var arrSearchKeys = make([]string, 0)
							for _, keyInterface := range arrKeysInterface {
								key := fmt.Sprintf("%v", keyInterface)
								key = strings.TrimSpace(key)
								if key != "" {
									arrSearchKeys = append(arrSearchKeys, key)
								}
							}
							responseGetRedisKey.Keys = arrSearchKeys
							responseGetRedisKey.Status = 200
						}
					} else {
						responseGetRedisKey.Status = 500
						responseGetRedisKey.Message = resRedis.Err().Error()
					}
					cResponseGetRedisKey <- responseGetRedisKey
				}(cResponseGetRedisKey, conn, pattern)
			}
			for range arrPatternKey {
				objectKey := <-cResponseGetRedisKey
				if objectKey.Status == 200 {
					if len(objectKey.Keys) > 0 {
						arrKeys = append(arrKeys, objectKey.Keys...)
					}
				} else if objectKey.Status == 500 {
					status = objectKey.Status
					msg = objectKey.Message
				}
			}
			fmt.Println("time.Now: End find search key: ", time.Now().Format("2006-01-02 15:04:05.999"))
			fmt.Println("time.Now     find data by key: ", time.Now().Format("2006-01-02 15:04:05.999"))
			//fmt.Println("arrKeys: ", arrKeys)
			if status == 200 {
				if len(arrKeys) > 0 {
					for _, key := range arrKeys {
						go func(conn *redis.Client, key string) {
							DeleteRedisDataByKey(conn, key)
						}(conn, key)
					}
				}
			}
		} else {
			if validateMsgError != "" {
				msg = validateMsgError
				errResponse := GetErrorResponseErrorMessage(0, msg)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteRedisDataByKey func
func DeleteRedisDataByKey(conn *redis.Client, key string) (int, error) {
	var (
		err    error
		status = 200
	)
	_, errDelKey := conn.Del(context.Background(), key).Result()
	if errDelKey != nil {
		status = 500
		err = errDelKey
	}
	return status, err
}
