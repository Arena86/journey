package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetLocations godoc
// @Summary Get Location
// @Description Get Location
// @Tags Location
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /location [get]
func GetLocations(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocations")
	var (
		status        = libs.GetStatusSuccess()
		locations     []models.Location
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.Location{}.TableName())
	bp = bp.Preload("Phones", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.Location{}.TableName())
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)
	// Filter
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"LocationName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Location{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&locations).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(locations) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayLocationToArrayResponse(requestHeader, locations)

	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Location{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "LocationID", v.DataType, b.LocationID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetLocationByID godoc
// @Summary Get Location By ID
// @Description Get Location  By ID
// @Tags Location
// @Accept  json
// @Produce  json
// @Param id path int true "Location ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /location/{id} [get]
func GetLocationByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocationByID")
	var (
		status        = libs.GetStatusSuccess()
		locations     models.Location
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Addresses",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
		models.Location{}.TableName(),
	).Preload(
		"Phones",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
		models.Location{}.TableName(),
	).Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", ID).First(&locations)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertLocationToResponse(requestHeader, locations)

		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Location{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses.UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "LocationID", v.DataType, responses.LocationID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses.UDFs = udfResponses

		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GetDepotLocationByID godoc
// @Summary Get Location By ID
// @Description Get Location  By ID
// @Tags Location
// @Accept  json
// @Produce  json
// @Param id path int true "Location ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /location/{id} [get]
func GetDepotLocationByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDepotLocationByID")
	var (
		status        = libs.GetStatusSuccess()
		locations     models.Location
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Addresses",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
		models.Location{}.TableName(),
	).Preload(
		"Phones",
		"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
		models.Location{}.TableName(),
	).Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", ID).First(&locations)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertDepotLocationToResponse(requestHeader, locations)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateLocation godoc
// @Summary Create Location
// @Description Create Location
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Location body []models.LocationResponse true "Create Location"
// @Success 200 {object} models.APIResponseData
// @Router /location [post]
func CreateLocation(c *gin.Context) {
	defer libs.RecoverError(c, "CreateLocation")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Location
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.Location, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, obj := range objectsJSON {
			var (
				location models.Location
			)
			location.PassBodyJSONToModel(obj)
			resultFindLocation := db.Where("LocationName = ? AND IsDeleted = 0", location.LocationName).First(&models.Location{})
			if resultFindLocation.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.locationname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}
			resultFind := db.Where("LocationID = ?", location.LocationID).First(&location)
			location.PassBodyJSONToModel(obj)
			// @TODO validate IsMaster
			if location.LocationID > 0 {
				if !location.IsMaster {
					resultFindLocationMaster := db.Where("IFNULL(IsMaster, 0) = 1 AND LocationID <> ? AND IFNULL(IsDeleted, 0) <> 1", location.LocationID).First(&models.Location{})
					if resultFindLocationMaster.RowsAffected <= 0 {
						errResponse := GetErrorResponseValidate(lang, k, "api.location_need_master")
						errorsResponse = append(errorsResponse, errResponse)
						continue
					}
				}
			}

			location.CreatedBy = accountKey
			location.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(location)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)

				// @TODO validate for address
				if len(location.Addresses) > 0 {
					addressValid := make([]models.Address, 0)
					for _, address := range location.Addresses {
						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(address)
						if err != nil {
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								itemMsgError = itemMsgError + e.Translate(trans) + "\n"
							}
						} else {
							address.Entity = models.Location{}.TableName()
							address.CreatedBy = accountKey
							addressValid = append(addressValid, address)
						}
					}
					location.Addresses = addressValid
				}
				// @TODO validate for phone
				if len(location.Phones) > 0 {
					phonesValid := make([]models.Phone, 0)
					for _, phone := range location.Phones {

						validate, trans := services.GetValidatorTranslate()
						err := validate.Struct(phone)
						if err != nil {
							errs := err.(validator.ValidationErrors)
							for _, e := range errs {
								itemMsgError = itemMsgError + e.Translate(trans) + "\n"
							}
						} else {
							phone.Entity = models.Location{}.TableName()
							phone.CreatedBy = accountKey
							phonesValid = append(phonesValid, phone)
						}
					}
					location.Phones = phonesValid
				}

				if resultFind.RowsAffected > 0 {
					db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&location)
				} else {
					db.Create(&location)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, location)

				// @TODO process for UDFs
				arrUDFs := libs.GetArrayUDFResponseFromJSON(obj)
				// @TODO update data for UDFs
				errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "LocationID", location.LocationID)
				if len(errUDFs) > 0 {
					for _, e := range errUDFs {
						if itemMsgError == "" {
							itemMsgError = e.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + e.Error()
						}
					}
				}
				// @TOO reset location master on another row if this row is master
				if location.IsMaster {
					sqlReset := `UPDATE ` + models.Location{}.TableName() + ` SET IsMaster = 0, ModifiedBy = ?  WHERE LocationID <> ?`
					db.Exec(sqlReset, accountKey, location.LocationID)
				}

				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Location
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.LocationID)
	}
	if len(arrID) > 0 {
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
			models.Location{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
			models.Location{}.TableName(),
		).Where("LocationID in (?)", arrID).Find(&items)
		dataResponses := ConvertArrayLocationToArrayResponse(requestHeader, items)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Location{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string

			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "LocationID", v.DataType, b.LocationID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateLocation godoc
// @Summary Update Location
// @Description Update Location
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Location body models.LocationResponse true "Update Location"
// @Success 200 {object} models.APIResponseData
// @Router /location [put]
func UpdateLocation(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateLocation")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Location
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Location, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, object := range objectsJSON {
			var (
				location models.Location
			)
			location.PassBodyJSONToModel(object)

			resultFindLocation := db.Where("LocationName = ? AND IsDeleted = 0 AND LocationID  <> ?", location.LocationName, location.LocationID).First(&models.Location{})
			if resultFindLocation.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.locationname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("LocationID = ?", location.LocationID).First(&location)
			location.PassBodyJSONToModel(object)

			// @TODO validate IsMaster
			if location.LocationID > 0 {
				if !location.IsMaster {
					resultFindLocationMaster := db.Where("IFNULL(IsMaster, 0) = 1 AND LocationID <> ? AND IFNULL(IsDeleted, 0) <> 1", location.LocationID).First(&models.Location{})
					if resultFindLocationMaster.RowsAffected <= 0 {
						errResponse := GetErrorResponseValidate(lang, k, "api.location_need_master")
						errorsResponse = append(errorsResponse, errResponse)
						continue
					}
				}
			}

			location.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(location)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
					res          interface{}
				)

				// @TODO validate for address
				// set address empty
				location.Addresses = make([]models.Address, 0)
				var (
					objectsAddress        []map[string]interface{}
					addresses             []models.Address
					arrAddressSkipID      []int
					arrAddressToDeleteID  []int
					addressToDeleteModels []models.Address
				)
				addresses = make([]models.Address, 0)
				_, res = services.ConvertJSONValueToVariable("Addresses", object)
				if res != nil {
					addressJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(addressJSON, &objectsAddress)
						if len(objectsAddress) > 0 {
							for _, objAddress := range objectsAddress {
								var (
									address models.Address
								)
								address.PassBodyJSONToModel(objAddress)
								resultFindAddress := db.Where("AddressID = ?", address.AddressID).First(&address)
								if resultFindAddress.RowsAffected > 0 {
									arrAddressSkipID = append(arrAddressSkipID, address.AddressID)
									address.PassBodyJSONToModel(objAddress)
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(address)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = itemMsgError + e.Translate(trans) + "\n"
										}
									} else {
										address.Entity = models.Location{}.TableName()
										address.ModifiedBy = accountKey
										addresses = append(addresses, address)
									}
								} else {
									address.PassBodyJSONToModel(objAddress)
									address.Entity = models.Location{}.TableName()
									address.CreatedBy = accountKey
									addresses = append(addresses, address)
								}
							}
						}
					}
				}
				location.Addresses = addresses
				if len(arrAddressSkipID) > 0 {
					db.Where("EntityID = ? AND Entity = ? AND AddressID not in (?)", location.LocationID, models.Location{}.TableName(), arrAddressSkipID).Find(&addressToDeleteModels)
				} else {
					// delete all
					db.Where("EntityID = ? AND Entity = ? ", location.LocationID, models.Location{}.TableName()).Find(&addressToDeleteModels)
				}
				for _, ad := range addressToDeleteModels {
					arrAddressToDeleteID = append(arrAddressToDeleteID, ad.AddressID)
				}

				// @TODO validate for phone
				// set phone empty
				location.Phones = make([]models.Phone, 0)
				var (
					objectsPhone        []map[string]interface{}
					phones              []models.Phone
					arrPhoneSkipID      []int
					arrPhoneToDeleteID  []int
					phoneToDeleteModels []models.Phone
				)
				phones = make([]models.Phone, 0)
				_, res = services.ConvertJSONValueToVariable("Phones", object)
				if res != nil {
					phoneJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(phoneJSON, &objectsPhone)
						if len(objectsPhone) > 0 {
							for _, objPhone := range objectsPhone {
								var (
									phone models.Phone
								)
								phone.PassBodyJSONToModel(objPhone)
								resultFindPhone := db.Where("PhoneID = ?", phone.PhoneID).First(&phone)
								if resultFindPhone.RowsAffected > 0 {
									arrPhoneSkipID = append(arrPhoneSkipID, phone.PhoneID)
									phone.PassBodyJSONToModel(objPhone)
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(phone)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = itemMsgError + e.Translate(trans) + "\n"
										}
									} else {
										phone.Entity = models.Location{}.TableName()
										phone.ModifiedBy = accountKey
										phones = append(phones, phone)
									}
								} else {
									phone.PassBodyJSONToModel(objPhone)
									phone.Entity = models.Location{}.TableName()
									phone.CreatedBy = accountKey
									phones = append(phones, phone)
								}
							}
						}
					}
				}
				location.Phones = phones
				if len(arrPhoneSkipID) > 0 {
					// delete id not in arrPhoneSkipID
					db.Where("EntityID = ? AND Entity = ? AND PhoneID not in (?)", location.LocationID, models.Location{}.TableName(), arrPhoneSkipID).Find(&phoneToDeleteModels)
				} else {
					// delete all
					db.Where("EntityID = ? AND Entity = ?", location.LocationID, models.Location{}.TableName()).Find(&phoneToDeleteModels)
				}
				for _, pd := range phoneToDeleteModels {
					arrPhoneToDeleteID = append(arrPhoneToDeleteID, pd.PhoneID)
				}

				if resultFind.RowsAffected > 0 {
					db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&location)
				} else {
					db.Create(&location)
				}
				dataResponse = append(dataResponse, location)
				totalUpdatedRecord++

				// @TODO process for UDFs
				arrUDFs := libs.GetArrayUDFResponseFromJSON(object)
				// @TODO update data for UDFs
				errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "LocationID", location.LocationID)

				if len(errUDFs) > 0 {
					for _, e := range errUDFs {
						if itemMsgError == "" {
							itemMsgError = e.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + e.Error()
						}
					}
				}

				// @TOO reset location master on another row if this row is master
				if location.IsMaster {
					sqlReset := `UPDATE ` + models.Location{}.TableName() + ` SET IsMaster = 0, ModifiedBy = ?  WHERE LocationID <> ?`
					db.Exec(sqlReset, accountKey, location.LocationID)
				}

				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Location
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.LocationID)
	}
	if len(arrID) > 0 {
		db.Preload(
			"Addresses",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
			models.Location{}.TableName(),
		).Preload(
			"Phones",
			"Entity = ? AND IFNULL(IsDeleted, 0) <> 1",
			models.Location{}.TableName(),
		).Where("LocationID in (?)", arrID).Find(&items)
		dataResponses := ConvertArrayLocationToArrayResponse(requestHeader, items)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Location{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "LocationID", v.DataType, b.LocationID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// DeleteLocation godoc
// @Summary Delete Location
// @Description Delete Location
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Location ID"
// @Success 200 {object} models.APIResponseData
// @Router /location/{id} [delete]
func DeleteLocation(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteLocation")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Location
		)
		resultFind := db.Where("LocationID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := uModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				arrLocation := []int{uModel.LocationID}
				if HasUseLocationIDInAnotherTables(requestHeader, arrLocation) {
					errResponse := GetErrorResponseValidate(lang, k, "api.location_used")
					errorsResponse = append(errorsResponse, errResponse)
				} else if uModel.IsMaster {
					errResponse := GetErrorResponseValidate(lang, k, "api.location_need_master")
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					uModel.IsDeleted = true
					uModel.ModifiedBy = accountKey
					deletedResult := db.Save(&uModel)
					if deletedResult.Error != nil {
						errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						totalUpdatedRecord++
					}
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// GetLocationByID godoc
// @Summary Get Location By ID
// @Description Get Location  By ID
// @Tags Location
// @Accept  json
// @Produce  json
// @Param id path int true "Location ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /location/validate/{id} [get]
func ValidateLocation(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocationByID")
	var (
		status               = libs.GetStatusSuccess()
		requestHeader        models.RequestHeader
		response             models.APIResponseData
		msg, data            interface{}
		responsesData        gin.H
		uModel               models.Location
		businessPartnerModel []models.BusinessPartner
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	//lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	locationID, _ := strconv.Atoi(ID)
	arrLocation := []int{locationID}
	resultFind := db.Where("LocationID = ?", locationID).First(&uModel)
	var responseData = make(map[string]interface{})
	responseData["IsUsedInJob"] = false
	responseData["IsUsedInUser"] = false
	responseData["IsMaster"] = false
	responseData["IsUsedInBP"] = false
	if resultFind.RowsAffected > 0 {
		if HasUseLocationIDInAnotherTables(requestHeader, arrLocation) {
			responseData["IsUsedInJob"] = true
		}
		if uModel.IsMaster {
			responseData["IsMaster"] = true
		}
		if HasUseLocationIDInUserTables(requestHeader, arrLocation) {
			responseData["IsUsedInUser"] = true
		}
		resultFindBusinessPartner := db.Select("BusinessPartnerID").Where("FIND_IN_SET(?, LocationID) AND CHAR_LENGTH(LocationID) = 1", locationID).Find(&businessPartnerModel)
		if resultFindBusinessPartner.RowsAffected > 0 {
			responseData["IsUsedInBP"] = true
		}
	}
	data = responseData
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// SetMasterLocation godoc
// @Summary Set Master Location
// @Description Set Master Location
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Location ID"
// @Success 200 {object} models.APIResponseData
// @Router /location/setmaster/{id} [put]
func SetMasterLocation(c *gin.Context) {
	defer libs.RecoverError(c, "SetMasterLocation")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var (
		uModel models.Location
	)
	resultFind := db.Where("LocationID = ?", ID).First(&uModel)
	if resultFind.RowsAffected > 0 {
		sql := `UPDATE ` + models.Location{}.TableName() + " SET IsMaster = 0"
		deletedResult := db.Exec(sql)
		if deletedResult.Error == nil {
			uModel.IsMaster = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(0, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseErrorMessage(0, deletedResult.Error.Error())
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// AssignLocationToCustomer godoc
// @Summary Assign Location To Customer
// @Description Assign Location To Customer
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Location body []models.LocationResponse true "Assign Location To Customer"
// @Success 200 {object} models.APIResponseData
// @Router /location/assign [post]
func AssignLocationToCustomer(c *gin.Context) {
	defer libs.RecoverError(c, "AssignLocationToCustomer")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.BusinessPartnerLocation
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.BusinessPartnerLocation, 0)
	// Convert json body to object
	var objectsJSON []models.LocationAssignPOST
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, obj := range objectsJSON {
			if len(obj.Locations) > 0 {
				for _, locationID := range obj.Locations {
					var (
						locationModel           models.Location
						businessPartnerModel    models.BusinessPartner
						businessPartnerLocation models.BusinessPartnerLocation
						resultProcess           *gorm.DB
					)
					// @TODO check businesspartnerID, LocationID
					db.Where("BusinessPartnerID = ? AND LocationID = ?", obj.BusinessPartnerID, locationID).First(&businessPartnerLocation)
					resultFindLocation := db.Where("LocationID = ?", locationID).First(&locationModel)
					resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", obj.BusinessPartnerID).First(&businessPartnerModel)
					if resultFindLocation.RowsAffected > 0 && resultFindBusinessPartner.RowsAffected > 0 {
						businessPartnerLocation.BusinessPartnerID = obj.BusinessPartnerID
						businessPartnerLocation.LocationGroupID = locationModel.LocationGroupID
						businessPartnerLocation.LocationID = locationModel.LocationID
						if businessPartnerLocation.BusinessPartnerLocationID > 0 {
							businessPartnerLocation.ModifiedBy = accountKey
							resultProcess = db.Save(&businessPartnerLocation)
						} else {
							businessPartnerLocation.CreatedBy = accountKey
							resultProcess = db.Create(&businessPartnerLocation)
						}
						if resultProcess.RowsAffected <= 0 {
							if resultProcess.Error != nil {
								var (
									errResponse models.ErrorResponse
								)
								status = 500
								errResponse.Index = k
								errResponse.Message = resultProcess.Error.Error()
								errResponse.Type = models.ErrorResponseTypeError
								errorsResponse = append(errorsResponse, errResponse)
							}
						} else {
							dataResponse = append(dataResponse, businessPartnerLocation)
						}
					} else {
						var (
							errResponse models.ErrorResponse
						)
						status = 201
						errResponse.Index = k
						if resultFindLocation.RowsAffected <= 0 {
							errResponse.Message = services.GetMessage(lang, "api.field_not_found", "LocationID")
						} else if resultFindBusinessPartner.RowsAffected <= 0 {
							errResponse.Message = services.GetMessage(lang, "api.field_not_found", "BusinessPartnerID")
						} else {
							errResponse.Message = services.GetMessage(lang, "api.no_record_found")
						}
						errResponse.Type = models.ErrorResponseTypeError
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
				totalUpdatedRecord++
			} else {
				var (
					errResponse models.ErrorResponse
				)
				status = 500
				errResponse.Index = k
				errResponse.Message = services.GetMessage(lang, "api.field_invalid", "Locations")
				errResponse.Type = models.ErrorResponseTypeError
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}

	errors = errorsResponse

	if totalUpdatedRecord == 0 {
		status = libs.GetStatusError()
		msg = services.GetMessage(lang, "api.full_failed")
	} else if totalUpdatedRecord < len(objectsJSON) {
		status = libs.GetStatusPartial()
		msg = services.GetMessage(lang, "api.partial_success")
	} else {
		msg = services.GetMessage(lang, "api.success")
		if len(errorsResponse) > 0 {
			msg = services.GetMessage(lang, "api.partial_success")
		}
	}

	resItems := make([]models.BusinessPartnerLocationResponse, 0)
	for _, v := range dataResponse {
		var item models.BusinessPartnerLocation
		db.Where("BusinessPartnerID = ? AND LocationID = ?", v.BusinessPartnerID, v.LocationID).First(&item)
		resItem := ConvertBusinessPartnerLocationToResponse(item, requestHeader)
		resItems = append(resItems, resItem)
	}
	data = resItems

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ChangeLocationCustomer godoc
// @Summary Change Location Customer
// @Description Change Location Customer
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Location body []models.LocationResponse true "Assign Location To Customer"
// @Success 200 {object} models.APIResponseData
// @Router /location/changecustomerlocation [post]
func ChangeLocationCustomer(c *gin.Context) {
	defer libs.RecoverError(c, "ChangeLocationCustomer")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
		dataResponse      []models.BusinessPartnerLocation
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.BusinessPartnerLocation, 0)
	// Convert json body to object
	var objectsJSON models.LocationChangeLocationPOST
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON.Locations) > 0 {
		var (
			businessPartnerModel []models.BusinessPartner
			locationModels       []models.Location
		)
		resultFindBusinessPartner := db.Select("BusinessPartnerID").Where("FIND_IN_SET(?, LocationID) AND CHAR_LENGTH(LocationID) = 1", objectsJSON.LocationID).Find(&businessPartnerModel)
		resultFindLocation := db.Where("LocationID IN (?)", objectsJSON.Locations).Find(&locationModels)
		for _, bp := range businessPartnerModel {
			var strLocations []string
			for _, locationID := range objectsJSON.Locations {
				var (
					businessPartnerLocation models.BusinessPartnerLocation
					resultProcess           *gorm.DB
				)
				if resultFindLocation.RowsAffected > 0 && resultFindBusinessPartner.RowsAffected > 0 {
					businessPartnerLocation.BusinessPartnerID = bp.BusinessPartnerID
					for _, location := range locationModels {
						if location.LocationID == locationID {
							businessPartnerLocation.LocationGroupID = location.LocationGroupID
							businessPartnerLocation.LocationID = location.LocationID
							break
						}
					}
					if businessPartnerLocation.BusinessPartnerLocationID > 0 {
						businessPartnerLocation.ModifiedBy = accountKey
						resultProcess = db.Save(&businessPartnerLocation)
					} else {
						businessPartnerLocation.CreatedBy = accountKey
						resultProcess = db.Create(&businessPartnerLocation)
					}
					if resultProcess.RowsAffected <= 0 {
						if resultProcess.Error != nil {
							var (
								errResponse models.ErrorResponse
							)
							status = 500
							errResponse.Index = 0
							errResponse.Message = resultProcess.Error.Error()
							errResponse.Type = models.ErrorResponseTypeError
							errorsResponse = append(errorsResponse, errResponse)
						}
					} else {
						dataResponse = append(dataResponse, businessPartnerLocation)
						strLocations = append(strLocations, strconv.Itoa(businessPartnerLocation.LocationID))
					}
				}
			}
			sql := `UPDATE ` + models.BusinessPartner{}.TableName() + " SET LocationID = ? WHERE BusinessPartnerID = ?"
			db.Exec(sql, strings.Join(strLocations, ","), bp.BusinessPartnerID)
		}
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = 400
		var (
			errResponse models.ErrorResponse
		)
		errResponse.Message = services.GetMessage(lang, "api.field_invalid", "Locations")
		errResponse.Type = models.ErrorResponseTypeError
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ChangeUserCustomer godoc
// @Summary Change User User
// @Description Change Location CustomerCustomer
// @Tags Location
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Location body []models.LocationResponse true "Assign Location To Location"
// @Success 200 {object} models.APIResponseData
// @Router /location/changeuserlocation [post]
func ChangeLocationUser(c *gin.Context) {
	defer libs.RecoverError(c, "ChangeLocationUser")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	// Convert json body to object
	var objectsJSON models.LocationChangeUserLocationPOST
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if objectsJSON.UserLocationID > 0 {
		var (
			users []models.User
		)
		resultFindUser := db.Where("LocationID = ?", objectsJSON.LocationID).Find(&users)
		if resultFindUser.RowsAffected > 0 {
			time := time.Now()
			for _, user := range users {
				user.LocationID = objectsJSON.UserLocationID
				user.ModifiedBy = accountKey
				user.ModifiedDate = &time

				resultSave := db.Save(&user)
				if resultSave.Error == nil {
					additionalNewUser := make(map[string]interface{})
					additionalNewUser["FirstName"] = user.FirstName
					additionalNewUser["LastName"] = user.LastName
					additionalNewUser["PhoneNumber"] = user.PhoneNumber
					additionalNewUser["LocationID"] = user.LocationID
					if user.Language == "" {
						user.Language = lang
					}
					additionalNewUser["Language"] = user.Language
					additionalNewUser["CountryCode"] = user.CountryCode

					var locationModel models.Location
					resultFindLocation := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", user.LocationID).First(&locationModel)
					if resultFindLocation.RowsAffected > 0 {
						additionalNewUser["LocationGroupID"] = locationModel.LocationGroupID
					}
					additionalNewUser["IsManager"] = user.IsManager
					companies := make([]map[string]interface{}, 0)
					company := map[string]interface{}{"companyid": companyID}
					companies = append(companies, company)
					additionalNewUser["Companies"] = companies

					URL := os.Getenv("SERVER_REE") + "/" + "accounts/" + strconv.Itoa(user.AccountKey)
					libs.RequestAPIRee(lang, "PUT", URL, additionalNewUser, nil, nil)
				} else {
					var (
						errResponse models.ErrorResponse
					)
					status = 500
					errResponse.Index = 0
					errResponse.Message = resultSave.Error.Error()
					errResponse.Type = models.ErrorResponseTypeError
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
		if status == 200 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.full_failed")
		}
	} else {
		status = 400
		var (
			errResponse models.ErrorResponse
		)
		errResponse.Message = services.GetMessage(lang, "api.field_invalid", "User Location")
		errResponse.Type = models.ErrorResponseTypeError
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayLocationToArrayResponse func
func ConvertArrayLocationToArrayResponse(requestHeader models.RequestHeader, items []models.Location) []models.LocationResponse {
	responses := make([]models.LocationResponse, 0)
	for _, item := range items {
		response := ConvertLocationToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertLocationToResponse func
func ConvertLocationToResponse(requestHeader models.RequestHeader, item models.Location) models.LocationResponse {
	var (
		response    models.LocationResponse
		locationGrp models.LocationGroup
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.LocationID = item.LocationID
	response.LocationName = item.LocationName
	response.IsDeleted = item.IsDeleted
	response.LocationGroupID = item.LocationGroupID
	response.IsArchived = item.IsArchived
	response.IsMaster = item.IsMaster
	response.Note = item.Note
	response.LocationMap = item.LocationMap
	response.StartDayHour = item.StartDayHour
	response.EndDayHour = item.EndDayHour
	response.Timezone = item.Timezone
	response.DefaultView = item.DefaultView
	response.FirstDayOfWeek = item.FirstDayOfWeek
	response.Latitude = item.Latitude
	response.Longitude = item.Longitude
	response.UsePicking = item.UsePicking
	response.BackToDepot = item.BackToDepot
	response.BreakInIntransitFormID = item.BreakInIntransitFormID
	response.BreakInJobFormID = item.BreakInJobFormID
	response.AdditionalResourceLocationGroupOnly = item.AdditionalResourceLocationGroupOnly
	resultFindLocationGrp := db.Where("LocationGroupID = ? ", item.LocationGroupID).First(&locationGrp)
	if resultFindLocationGrp.RowsAffected > 0 {
		response.LocationGroupName = locationGrp.LocationGroupName
	}

	addresses := make([]models.AddressResponse, 0)
	for _, ad := range item.Addresses {
		var (
			address     models.AddressResponse
			addressType models.AddressType
		)
		address.AddressID = ad.AddressID
		address.AddressTypeID = ad.AddressTypeID
		db.Where("AddressTypeID = ?", ad.AddressTypeID).First(&addressType)
		address.AddressTypeName = addressType.AddressTypeName
		address.IsDepot = addressType.IsDepot
		address.IsLocation = addressType.IsLocation
		address.IsDefault = addressType.IsDefault
		address.AddressLine1 = ad.AddressLine1
		address.AddressLine2 = ad.AddressLine2
		address.AddressLine3 = ad.AddressLine3
		address.AddressLine4 = ad.AddressLine4
		address.City = ad.City
		address.PostalCode = ad.PostalCode
		address.State = ad.State
		address.Country = ad.Country
		address.AttentionTo = ad.AttentionTo
		address.IsDeleted = ad.IsDeleted
		address.IsArchived = ad.IsArchived
		address.EntityID = ad.EntityID
		address.Entity = ad.Entity
		address.NavigationAddress = ad.NavigationAddress
		addresses = append(addresses, address)
	}
	response.Addresses = addresses
	phones := make([]models.PhoneResponse, 0)
	for _, ph := range item.Phones {
		var (
			phone     models.PhoneResponse
			phoneType models.PhoneType
		)
		phone.PhoneID = ph.PhoneID
		phone.PhoneTypeID = ph.PhoneTypeID
		db.Where("PhoneTypeID = ?", ph.PhoneTypeID).First(&phoneType)
		phone.PhoneTypeName = phoneType.PhoneTypeName
		phone.IsDepot = phoneType.IsDepot
		phone.IsLocation = phoneType.IsLocation
		phone.IsDefault = phoneType.IsDefault
		phone.CountryCode = ph.CountryCode
		phone.PhoneNumber = ph.PhoneNumber
		phone.Extension = ph.Extension
		phone.EntityID = ph.EntityID
		phone.Entity = ph.Entity
		phone.IsDeleted = ph.IsDeleted
		phone.IsArchived = ph.IsArchived
		phones = append(phones, phone)
	}
	response.Phones = phones

	schedulerViews := make([]string, 0)
	if item.SchedulerViews != "" {
		schedulerViews = strings.Split(item.SchedulerViews, ",")
	}
	response.SchedulerViews = schedulerViews

	resourceModes := make([]string, 0)
	if item.ResourceModes != "" {
		resourceModes = strings.Split(item.ResourceModes, ",")
	}
	arrResourceModes, _ := libs.ConvertArrayStringToInt(resourceModes)
	response.ResourceModes = arrResourceModes

	resourceTypes := make([]string, 0)
	if item.ResourceTypes != "" {
		resourceTypes = strings.Split(item.ResourceTypes, ",")
	}
	arrResourceTypes, _ := libs.ConvertArrayStringToInt(resourceTypes)
	response.ResourceTypes = arrResourceTypes
	response.TimeZoneID = item.TimeZoneID
	var timezoneModel models.Timezone
	resultFindTimezone := db.Where("TimeZoneID = ?", item.TimeZoneID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&timezoneModel)
	if resultFindTimezone.RowsAffected > 0 {
		// override timezone by timezone name on timezone table
		response.Timezone = timezoneModel.Name
		response.Offset = timezoneModel.Offset
		response.CountryCode = timezoneModel.CountryCode
	}
	return response
}

// ConvertDepotLocationToResponse func
func ConvertDepotLocationToResponse(requestHeader models.RequestHeader, item models.Location) models.LocationInformResponse {
	var (
		response models.LocationInformResponse
		timeZone models.Timezone
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.LocationID = item.LocationID
	response.LocationName = item.LocationName
	response.Note = item.Note
	response.StartDayHour = item.StartDayHour
	response.EndDayHour = item.EndDayHour
	response.Timezone = item.Timezone
	response.DefaultView = item.DefaultView
	response.FirstDayOfWeek = item.FirstDayOfWeek
	response.Latitude = item.Latitude
	response.Longitude = item.Longitude
	response.UsePicking = item.UsePicking
	response.BackToDepot = item.BackToDepot
	response.BreakInIntransitFormID = item.BreakInIntransitFormID
	response.BreakInJobFormID = item.BreakInJobFormID
	addresses := make([]models.AddressResponse, 0)
	for _, ad := range item.Addresses {
		var (
			address     models.AddressResponse
			addressType models.AddressType
		)
		address.AddressID = ad.AddressID
		address.AddressTypeID = ad.AddressTypeID
		db.Where("AddressTypeID = ?", ad.AddressTypeID).First(&addressType)
		address.AddressTypeName = addressType.AddressTypeName
		if addressType.IsDepot {
			address.IsDepot = addressType.IsDepot
			address.IsLocation = addressType.IsLocation
			address.IsDefault = addressType.IsDefault
			address.AddressLine1 = ad.AddressLine1
			address.AddressLine2 = ad.AddressLine2
			address.AddressLine3 = ad.AddressLine3
			address.AddressLine4 = ad.AddressLine4
			address.City = ad.City
			address.PostalCode = ad.PostalCode
			address.State = ad.State
			address.Country = ad.Country
			address.AttentionTo = ad.AttentionTo
			address.IsDeleted = ad.IsDeleted
			address.IsArchived = ad.IsArchived
			address.EntityID = ad.EntityID
			address.Entity = ad.Entity
			address.NavigationAddress = ad.NavigationAddress
			addresses = append(addresses, address)
		}
	}
	response.Addresses = addresses
	phones := make([]models.PhoneResponse, 0)
	for _, ph := range item.Phones {
		var (
			phone     models.PhoneResponse
			phoneType models.PhoneType
		)
		phone.PhoneID = ph.PhoneID
		phone.PhoneTypeID = ph.PhoneTypeID
		db.Where("PhoneTypeID = ?", ph.PhoneTypeID).First(&phoneType)
		phone.PhoneTypeName = phoneType.PhoneTypeName
		if phoneType.IsDepot {
			phone.IsDepot = phoneType.IsDepot
			phone.IsLocation = phoneType.IsLocation
			phone.IsDefault = phoneType.IsDefault
			phone.CountryCode = ph.CountryCode
			phone.PhoneNumber = ph.PhoneNumber
			phone.Extension = ph.Extension
			phone.EntityID = ph.EntityID
			phone.Entity = ph.Entity
			phone.IsDeleted = ph.IsDeleted
			phone.IsArchived = ph.IsArchived
			phones = append(phones, phone)
		}
	}
	response.Phones = phones

	schedulerViews := make([]string, 0)
	if item.SchedulerViews != "" {
		schedulerViews = strings.Split(item.SchedulerViews, ",")
	}
	response.SchedulerViews = schedulerViews

	resourceModes := make([]string, 0)
	if item.ResourceModes != "" {
		resourceModes = strings.Split(item.ResourceModes, ",")
	}
	arrResourceModes, _ := libs.ConvertArrayStringToInt(resourceModes)
	response.ResourceModes = arrResourceModes

	resourceTypes := make([]string, 0)
	if item.ResourceTypes != "" {
		resourceTypes = strings.Split(item.ResourceTypes, ",")
	}
	arrResourceTypes, _ := libs.ConvertArrayStringToInt(resourceTypes)
	response.ResourceTypes = arrResourceTypes

	db.Where("TimeZoneID = ?", item.TimeZoneID).First(&timeZone)
	if timeZone.TimeZoneID > 0 {
		response.DateFormat = timeZone.DateFormat
		response.TimeFormat = timeZone.TimeFormat
	}
	return response
}
