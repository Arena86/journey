package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"math"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// CheckFirstTaskInJourney func
func CheckFirstTaskInJourney(requestHeader models.RequestHeader, lang string, journeyCode string, userID int) bool {
	var (
		status = false
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	sql := `SELECT IFNULL(s.ScheduleID,0) AS ScheduleID, 
			IFNULL(s.JobID,0) AS JobID,
			IFNULL(j.JobNumber,'') AS JobNumber, 
			IFNULL(jt.Status,0) AS Status, 
			IFNULL(s.JobTaskID,0) AS JobTaskID,
			IFNULL(jt.FormFlowID,0) AS FormFlowID,
			IFNULL(jt.JobType,0) AS JobType,
			'' AS JobTypeName,
			s.ScheduleStartDate,
			s.ScheduleEndDate,
			IFNULL(jt.NavigationAddress,'') AS NavigationAddress,
			IFNULL(b.CompanyName,'') AS CompanyName
			FROM schedules s
			LEFT JOIN jobs j ON s.JobID = j.JobID
			LEFT JOIN jobtasks jt on (s.JobID = jt.JobID AND s.JobTaskID = jt.JobTaskID)
			LEFT JOIN businesspartners b on j.BusinessPartnerID = b.BusinessPartnerID
			WHERE IFNULL(s.IsDeleted, 0) <> 1 AND IFNULL(s.IsArchived, 0) <> 1
			AND s.UserID = ? 
			AND s.JourneyCode = ?
			ORDER BY s.ScheduleStartDate ASC LIMIT 1`
	rows, err := db.Raw(sql, journeyCode, userID).Rows()
	if rows != nil {
		defer rows.Close()
	}
	if err == nil {
		for rows.Next() {
			var (
				scheduleJob models.ScheduleJobTaskResponse
			)
			rows.Scan(
				&scheduleJob.ScheduleID, &scheduleJob.JobID, &scheduleJob.JobNumber,
				&scheduleJob.Status, &scheduleJob.JobTaskID, &scheduleJob.FormFlowID,
				&scheduleJob.JobType, &scheduleJob.JobTypeName,
				&scheduleJob.ScheduleStartDate, &scheduleJob.ScheduleEndDate,
				&scheduleJob.NavigationAddress, &scheduleJob.CompanyName,
			)
			if scheduleJob.Status == 0 {
				status = true
				break
			}
		}
	}
	return status
}

// CheckJobTaskFormFlowFunc func
func CheckJobTaskFormFlowFunc(requestHeader models.RequestHeader, lang string, jobTaskID int) (bool, string) {
	var (
		status       = true
		msg          string
		jobTaskModel models.JobTask
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	resultFindJobTask := db.Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
	if resultFindJobTask.RowsAffected > 0 {
		resultFindDraftFormFlow := db.Where("DraftFormFlowID = ?", jobTaskModel.FormFlowID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.DraftFormFlow{})
		if resultFindDraftFormFlow.RowsAffected > 0 {
			resultFindFormFlowPublish := db.Where("FormFlowID = ?", jobTaskModel.FormFlowID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.FormFlow{})
			if resultFindFormFlowPublish.RowsAffected <= 0 {
				status = false
				msg = services.GetMessage(lang, "api.formflowid_not_publish")
			}
		} else {
			status = false
			msg = services.GetMessage(lang, "api.formflowid_not_found")
		}
	} else {
		status = false
		msg = services.GetMessage(lang, "api.jobtaskid_not_found")
	}
	return status, msg
}

// CheckJobTask godoc
// @Summary CheckJobTask
// @Description CheckJobTask
// @Tags JobTask
// @Accept  json
// @Produce  json
// @Param JobTaskID query string true "JobTaskID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkjobtaskformflow [get]
func CheckJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "CheckJobTask")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var (
		jobTasks       []int
		valid          = true
		isFirstJobTask = true
		errorsValid    = make([]interface{}, 0)
		userModel      models.User
	)

	vJobTask, sJobTask := libs.GetQueryParam("JobTaskID", c)
	if sJobTask {
		jobTasks = libs.StringToArray(vJobTask)
	}
	vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
	if !sJourneyCode {
		msg = services.GetMessage(lang, "api.param_required", "Journey Code")
		status = 422
	}
	if len(jobTasks) <= 0 {
		status = 422
		msg = services.GetMessage(lang, "api.jobtaskid_required")
	}

	if status == 200 {
		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		userModel = libs.GetCurrentUser(requestHeader, accountKey)
		if userModel.UserID > 0 {

			for _, jobTaskID := range jobTasks {
				hasPublish, msgPublish := CheckJobTaskFormFlowFunc(requestHeader, lang, jobTaskID)
				if !hasPublish {
					valid = false
					errorValid := map[string]interface{}{
						"JobTask": jobTaskID,
						"Error":   msgPublish,
					}
					errorsValid = append(errorsValid, errorValid)
				}
			}

			// Check First Task in Journey
			isFirstJobTask = CheckFirstTaskInJourney(requestHeader, lang, vJourneyCode, userModel.UserID)

			data = map[string]interface{}{
				"Valid":       valid,
				"JobTask":     errorsValid,
				"IsFirstTask": isFirstJobTask,
			}
		}
	}
	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJobTask godoc
// @Summary Update JobTask
// @Description Update JobTask
// @Tags JobTask
// @Accept json
// @Produce json
// @Param Form query string false "Form"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Type path int true "Item Movement Type"
// @Param JobTask body models.JobTask true "Update JobTask"
// @Success 200 {object} models.APIResponseData
// @Router /jobtask/{id} [put]
func UpdateJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJobTask")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.JobTaskResponse
		totalUpdatedRecord = 0
		jobTaskStatus      = ""
		jobStatus          = 0
		createInvoice      = false
		isBreakIn          = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	id := c.Param("id")

	vJourneyCode := ""

	formStopID := ""
	vFormStopID, sFormStopID := libs.GetQueryParam("Form", c)
	if sFormStopID {
		formStopID = vFormStopID
	}

	vIsBreakIn, sIsBreakIn := libs.GetQueryParam("isbreakin", c)
	if sIsBreakIn {
		isBreakIn, _ = strconv.ParseBool(vIsBreakIn)
	}
	// Find Journey Code by Job Task
	var (
		schedule models.Schedule
	)

	resultFind := db.Where("JobTaskID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&schedule)
	if resultFind.RowsAffected > 0 {
		if schedule.JourneyCode != nil {
			vJourneyCode = *schedule.JourneyCode
		}
	}

	if vJourneyCode != "" {

		// Convert json body to object
		var objectsJSON map[string]interface{}
		json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
		var (
			jobTask       models.JobTask
			startDateTime *time.Time
		)
		jobTask.PassBodyJSONToModel(objectsJSON)
		resultFind := db.Where("JobTaskID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
		if resultFind.RowsAffected > 0 {
			if jobTask.Status != 4 {
				jobTask.ModifiedBy = accountKey
				startDateTime = jobTask.StartDateTime
				jobTask.PassBodyJSONToModel(objectsJSON)
				if jobTask.Status > 3 { // Not In Progress
					jobTask.StartDateTime = startDateTime
				}
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(jobTask)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(0, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					if jobTask.JobType == 2 {
						jobTaskStatus = "Pickup"
					}
					if jobTask.JobType == 3 {
						jobTaskStatus = "Delivery"
					}
					if jobTask.Status == 1 { //1=InTransit
						jobStatus = libs.JobMappingStatus(jobTask.Status)
					}
					if jobTask.Status == 2 { //2=Arrived
						jobStatus = libs.JobMappingStatus(jobTask.Status)
					}
					if jobTask.Status == 3 { //3=In Progress
						jobStatus = libs.JobMappingStatus(jobTask.Status)
					}
					if jobTask.Status == 4 { //4 = Completed
						jobStatus = libs.JobMappingStatus(jobTask.Status)
					}

					isFirstJobTask := CheckFirstTaskInJourney(requestHeader, lang, vJourneyCode, schedule.UserID)

					resultSave := db.Save(&jobTask) // Update Job Task
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						// Update job status
						var (
							job      models.Job
							jobTasks []models.JobTask
							res      interface{}
							val      string
						)
						resultFindJob := db.Where("JobID = ?", jobTask.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
						if resultFindJob.RowsAffected > 0 {
							// SEND SMS
							if jobTask.Status == 1 { //1=InTransit
								if isFirstJobTask {
									smsMatrixID := 3 // Start From Depot
									go SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobTask.JobID)
								}
								if job.JobType == jobTask.JobType {
									smsMatrixID := 4 // Start Driving to Task1
									go SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobTask.JobID)
								} else {
									if jobTask.JobType == 2 {
										smsMatrixID := 4 // Start Driving to Task1
										go SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobTask.JobID)
									} else {
										smsMatrixID := 5 // Start Driving to Task2
										go SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobTask.JobID)
									}
								}
							}

							job.ModifiedBy = accountKey
							resultFindJobTask := db.Where("JobID = ? AND Status <> 4", jobTask.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTasks)
							if resultFindJobTask.RowsAffected <= 0 {
								jobStatus = 7 // 7=Completed
								jobTaskStatus = "Completed"
								createInvoice = true
								// status = 7 & inspectionjob => send notification
								if job.IsInspection {
									settingValueModel, errSettingValue := GetSettingValue(requestHeader, lang)
									if errSettingValue == nil {
										sendNotificationOptional := settingValueModel.Notifications.IsJobInspectionCompletedActive
										reasonID := settingValueModel.Notifications.JobInspectionCompleted
										notificationComment := "Inspection job has completed. Job Number - " + job.JobNumber
										SendNotificationWithOptinalFromSetting(requestHeader, lang, accountKey, notificationComment,
											job.LocationID, reasonID, sendNotificationOptional, true)
									}
								}
							} else {
								if jobTask.Status == 4 {
									for _, jobTask := range jobTasks {
										if jobTask.Status == 0 {
											if jobTask.JobType == 2 {
												jobTaskStatus = "Pickup"
											}
											if jobTask.JobType == 3 {
												jobTaskStatus = "Delivery"
											}
										}
									}
								}
							}
							if jobTask.Status == 4 {
								UpdateJobTimeInSecondOnJobTask(requestHeader, &jobTask)
							}
							UpdateJobStatus(requestHeader, jobTask.JobID, jobStatus, accountKey, c)
							// update job status for master job combined
							UpdateJobStatusForMasterJobCombined(requestHeader, jobTask.JobID, accountKey)
							resultFindJob := db.Where("JobID = ?", jobTask.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
							if resultFindJob.RowsAffected > 0 {
								val, res = services.ConvertJSONValueToVariable("InProgressStatus", objectsJSON)
								if res != nil {
									job.InProgressStatus = val
								}
								job.JobTaskStatus = jobTaskStatus
								if jobStatus == 7 {
									job.InProgressStatus = jobTaskStatus
								}
								if !isBreakIn {
									if formStopID != "" {
										// @TODO update JobFormsNavigation
										var (
											jobFormsNavigation = make([]models.JobFormNavigation, 0)
										)
										if job.JobFormsNavigation != nil {
											strJobFormsNavigation := *job.JobFormsNavigation
											json.Unmarshal([]byte(strJobFormsNavigation), &jobFormsNavigation)
										}
										jobTaskNavigation := ConvertDynamicFormNavigationToJobFormsNavigation(requestHeader, lang, jobTask.JobID, jobTask.JobTaskID, formStopID)
										// compare and update
										jobTaskNavigation.Forms = CompareAndUpdateWithJobDynamicForm(requestHeader, lang, accountKey, jobTaskNavigation.Forms)
										existNavigation := false
										for i, navigation := range jobFormsNavigation {
											if navigation.Task.TaskID == jobTaskNavigation.Task.TaskID {
												existNavigation = true
												jobTaskNavigation.BreakForms = navigation.BreakForms
												if jobTaskNavigation.BreakForms == nil || len(jobTaskNavigation.BreakForms) == 0 {
													jobTaskNavigation.BreakForms = make([]models.BreakFormsNavigationForm, 0)
												}
												jobFormsNavigation[i] = jobTaskNavigation
												break
											}
										}
										if !existNavigation {
											if jobTaskNavigation.BreakForms == nil || len(jobTaskNavigation.BreakForms) == 0 {
												jobTaskNavigation.BreakForms = make([]models.BreakFormsNavigationForm, 0)
											}
											jobFormsNavigation = append(jobFormsNavigation, jobTaskNavigation)
										}
										jsonValFormsNavigation, errValFormsNavigation := json.Marshal(jobFormsNavigation)
										if errValFormsNavigation == nil {
											valFormsNavigationJSON := string(jsonValFormsNavigation)
											job.JobFormsNavigation = &valFormsNavigationJSON
										}
										// @TODO update JobFormsNavigation end
									}
								} else {
									// @TODO update JobFormsNavigation
									var (
										jobFormsNavigations = make([]models.JobFormNavigation, 0)

										breakForm    models.BreakFormsNavigationForm
										location     models.Location
										jobTaskModel models.JobTask
									)
									if job.JobFormsNavigation != nil {
										strJobFormsNavigation := *job.JobFormsNavigation
										json.Unmarshal([]byte(strJobFormsNavigation), &jobFormsNavigations)
									}

									// Create Break Forms
									breakForm.Form = formStopID
									breakForm.Sort = 1
									formID, _ := strconv.Atoi(formStopID)
									resultFind := db.Where("LocationID = ?", job.LocationID).Where("IFNULL(IsDeleted, 0) <> 1").First(&location)
									if resultFind.RowsAffected > 0 {
										if location.BreakInIntransitFormID == formID {
											breakForm.Type = "api.break_in_intransit_form"
										} else if location.BreakInJobFormID == formID {
											breakForm.Type = "api.break_in_job_form"
										}
									}
									var (
										dynamicForm models.DynamicForm
									)
									resultFindDynamicForm := db.Where("DynamicFormID = ?", formID).Where("IFNULL(IsDeleted, 0) <> 1").First(&dynamicForm)
									if resultFindDynamicForm.RowsAffected > 0 {
										breakForm.Form = strconv.Itoa(dynamicForm.DynamicFormID)
										breakForm.FormTitle = dynamicForm.FormStatus
									}
									breakForm = CompareAndUpdateWithJobBreakInDynamicForm(requestHeader, lang, accountKey, breakForm)

									existNavigation := false
									jobTaskID, _ := strconv.Atoi(id)
									navIndex := 0
									for i, navigation := range jobFormsNavigations {
										if navigation.Task.TaskID == jobTaskID {
											existNavigation = true
											navIndex = i
											break
										}
									}
									if !existNavigation {
										var jobFormsNavigation models.JobFormNavigation
										resultFindJobTask := db.Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1").First(&jobTaskModel)
										if resultFindJobTask.RowsAffected > 0 {
											jobFormsNavigation.Task.TaskID = jobTaskModel.JobTaskID
											jobFormsNavigation.Task.JobType = jobTaskModel.JobType
											jobFormsNavigation.Task.JobTypeName, _ = libs.GetEnum(requestHeader, jobTaskModel.JobType, "JobType", lang)
										}
										if jobFormsNavigation.Forms == nil || len(jobFormsNavigation.Forms) == 0 {
											jobFormsNavigation.Forms = make([]models.JobFormNavigationForm, 0)
										}
										jobFormsNavigation.BreakForms = append(jobFormsNavigation.BreakForms, breakForm)
										jobFormsNavigations = append(jobFormsNavigations, jobFormsNavigation)
									} else {
										if jobFormsNavigations[navIndex].Forms == nil || len(jobFormsNavigations[navIndex].Forms) == 0 {
											jobFormsNavigations[navIndex].Forms = make([]models.JobFormNavigationForm, 0)
										}
										existBreakForms := false
										for i, bf := range jobFormsNavigations[navIndex].BreakForms {
											if bf.OriginalForm == formID {
												existBreakForms = true
												jobFormsNavigations[navIndex].BreakForms[i] = breakForm
												break
											}
										}
										if !existBreakForms {
											jobFormsNavigations[navIndex].BreakForms = append(jobFormsNavigations[navIndex].BreakForms, breakForm)
										}
									}

									jsonValFormsNavigation, errValFormsNavigation := json.Marshal(jobFormsNavigations)
									if errValFormsNavigation == nil {
										valFormsNavigationJSON := string(jsonValFormsNavigation)
										job.JobFormsNavigation = &valFormsNavigationJSON
									} else {
										fmt.Println(errValFormsNavigation)
									}
									// @TODO update JobFormsNavigation end
								}
								db.Save(&job)
							}
						}
						totalUpdatedRecord++

						// Update journey status
						var (
							result models.Job
						)

						resultFind := db.Table("jobs").Select("jobs.JobID, jobs.Status").
							Joins("JOIN schedules ON jobs.JobID = schedules.JobID").
							Where("schedules.JourneyCode = ? AND jobs.Status <> 7", vJourneyCode).Group("jobs.JobID, jobs.Status").Scan(&result)

						journeyStatus := 0 // Status = 0 Open
						if resultFind.RowsAffected <= 0 {
							journeyStatus = 2 // Status = 2 Completed
						} else {
							if result.Status > 2 {
								journeyStatus = 1 // Status = 1 In Progress
							}
						}
						db.Table(models.Journey{}.TableName()).Where("JourneyCode = ?", vJourneyCode).Updates(map[string]interface{}{"Status": journeyStatus})
					}
				}
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, 0)
			errorsResponse = append(errorsResponse, errResponse)
		}

		var (
			resModels models.JobTask
		)

		db.Where("JobTaskID in (?)", id).Find(&resModels)
		dataResponse = ConvertJobTaskToResponse(resModels)
		data = dataResponse
		// @TODO generate invoice
		if createInvoice {
			GenerateXeroInvoice(requestHeader, lang, jobTask.JobID, accountKey)
			//if statusInvoice != 200 {

			//}

		}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.param_required", "Journey Code"))
		errorsResponse = append(errorsResponse, errResponse)
		status = 422
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJobTask godoc
// @Summary Update JobTask
// @Description Update JobTask
// @Tags JobTask
// @Accept json
// @Produce json
// @Param Form query string false "Form"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Type path int true "Item Movement Type"
// @Param JobTask body models.JobTask true "Update JobTask"
// @Success 200 {object} models.APIResponseData
// @Router /checkpaymentcompleted/{id} [get]
func CheckCompletedPayment(c *gin.Context) {
	defer libs.RecoverError(c, "CheckCompletedPayment")
	var (
		status               = libs.GetStatusSuccess()
		requestHeader        models.RequestHeader
		response             models.APIResponseData
		msg, data, errors    interface{}
		errorsResponse       []models.ErrorResponse
		jobModel             models.Job
		jobTaskModel         models.JobTask
		paymentModel         models.Payment
		paymentDetails       []models.PaymentDetail
		totalPaidMoney       float64 = 0
		nextProcessingStatus bool    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	jobTaskID := c.Param("jobtaskid")
	resultFindJobTask := db.Select("JobID").Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
	if resultFindJobTask.RowsAffected > 0 {
		jobID := jobTaskModel.JobID
		resultFindJob := db.Select("TotalJob").Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected > 0 {
			if jobModel.TotalJob > 0 {
				totalMoney := jobModel.TotalJob
				resultFindPayment := db.Select("PaymentID").Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&paymentModel)
				if resultFindPayment.RowsAffected > 0 {
					db.Select("Amount").Where("PaymentID = ?", paymentModel.PaymentID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&paymentDetails)
					for _, de := range paymentDetails {
						totalPaidMoney = totalPaidMoney + de.Amount
					}
				}
				if totalMoney <= totalPaidMoney {
					nextProcessingStatus = true
				} else {
					var totalJobTaskNotFinished int64
					db.Model(&models.JobTask{}).Where("JobID = ? AND Status <> 4", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Count(&totalJobTaskNotFinished)
					if totalJobTaskNotFinished > 1 {
						nextProcessingStatus = true
					}
				}
			} else {
				nextProcessingStatus = true
			}
		} else {
			status = 404
			msg = services.GetMessage(lang, "api.jobid_not_found")
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "api.jobtaskid_not_found")
	}
	if status == 200 {
		data = map[string]interface{}{"status": nextProcessingStatus}
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJobTimeInSecondOnJobTask func
func UpdateJobTimeInSecondOnJobTask(requestHeader models.RequestHeader, jobTask *models.JobTask) {
	if jobTask.StartDateTime != nil && jobTask.EndDateTime != nil {
		db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//

		var (
			jobTaskModel models.JobTask
			breaks       []models.Break
			totalBreaks  float64
		)
		startTime := *jobTask.StartDateTime
		endTime := *jobTask.EndDateTime
		totalTimeOnJobTask := endTime.Sub(startTime).Seconds()
		db.Where(
			"JobTaskID = ?",
			jobTask.JobTaskID,
		).Where(
			"DATE_FORMAT(FromDateTime,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(ToDateTime,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')",
			startTime, endTime,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Find(&breaks)
		if len(breaks) > 0 {
			for _, bre := range breaks {
				totalBreaks = totalBreaks + float64(bre.TotalBreakInSeconds)
			}
		}
		totalTimeInSeconds := totalTimeOnJobTask - totalBreaks
		totalTimeInSecondsInt := int(math.Round(totalTimeInSeconds))
		// return > need to override update
		jobTask.JobTimeInSeconds = totalTimeInSecondsInt
		// save
		resultFindJobTask := db.Where("JobTaskID = ?", jobTask.JobTaskID).First(&jobTaskModel)
		if resultFindJobTask.RowsAffected > 0 {
			jobTaskModel.JobTimeInSeconds = totalTimeInSecondsInt
			db.Save(&jobTaskModel)
		}
	}
}

// ConvertArrayJobTasksToArrayResponse func
func ConvertArrayJobTasksToArrayResponse(items []models.JobTask) []models.JobTaskResponse {
	responses := make([]models.JobTaskResponse, 0)
	for _, item := range items {
		response := ConvertJobTaskToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJobTaskToResponse func
func ConvertJobTaskToResponse(item models.JobTask) models.JobTaskResponse {
	var (
		response models.JobTaskResponse
	)
	response.JobTaskID = item.JobTaskID
	response.JobID = item.JobID
	response.JobType = item.JobType
	response.Status = item.Status
	response.FormFlowID = item.FormFlowID
	response.JobTaskID = item.JobTaskID
	response.ScheduleStartDateTime = item.ScheduleStartDateTime
	response.ScheduleEndDateTime = item.ScheduleEndDateTime
	response.DepartureDateTime = item.DepartureDateTime
	response.EstimatedArrivalDateTime = item.EstimatedArrivalDateTime
	response.JobTimeInSeconds = item.JobTimeInSeconds
	response.ArrivalDateTime = item.ArrivalDateTime
	response.StartDateTime = item.StartDateTime
	response.EndDateTime = item.EndDateTime
	response.NavigationAddress = item.NavigationAddress
	response.AdditionalInformation = item.AdditionalInformation
	response.ServiceTimeInMinutes = item.ServiceTimeInMinutes
	response.Longitude = item.Longitude
	response.Latitude = item.Latitude
	return response
}

// ConvertDynamicFormNavigationToJobFormsNavigation func
func ConvertDynamicFormNavigationToJobFormsNavigation(requestHeader models.RequestHeader, lang string, jobID int, jobTaskID int, paramFormStop string) models.JobFormNavigation {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	const START = "start"
	const END = "end"
	const CONDITION = "condition"
	var (
		jobTaskModel           models.JobTask
		formFlowModel          models.FormFlow
		strNavigation          string
		formFlowNavigations    []models.FormFlowNavigation
		jobFormNavigation      models.JobFormNavigation
		jobFormNavigationForms = make([]models.JobFormNavigationForm, 0)
	)

	dynamicFormIDToStop := paramFormStop
	arrConditionStop := strings.Split(paramFormStop, "_")
	if arrConditionStop[0] == CONDITION {
		dynamicFormIDToStop, _, _ = CheckFormConditionFunc(requestHeader, lang, paramFormStop, jobID, jobTaskID)
		// @TODO test
		//dynamicFormIDToStop = "ped_76617205-3cc7-f747-7abf-d0e83f6f7293"
		fmt.Println("conditionStopID: ", paramFormStop)
		fmt.Println("conditionStopID > dynamicFormIDToStop: ", dynamicFormIDToStop)
	}

	resultFindJobTask := db.Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskModel)
	if resultFindJobTask.RowsAffected > 0 {
		jobFormNavigation.Task.TaskID = jobTaskModel.JobTaskID
		jobFormNavigation.Task.JobType = jobTaskModel.JobType
		jobFormNavigation.Task.JobTypeName, _ = libs.GetEnum(requestHeader, jobTaskModel.JobType, "JobType", lang)
		resultFindFormFlow := db.Where("FormFlowID = ?", jobTaskModel.FormFlowID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&formFlowModel)
		if resultFindFormFlow.RowsAffected > 0 {
			if formFlowModel.Navigation != nil {
				strNavigation = *formFlowModel.Navigation
			}
		}
	}
	if strNavigation != "" {
		json.Unmarshal([]byte(strNavigation), &formFlowNavigations)
		//fmt.Printf("formFlowNavigations: %+v\n", formFlowNavigations)
		var (
			hasFormStart      = false
			hasFormEnd        = false
			nextForm          models.FormFlowNavigation
			mapFormNavigation = make(map[string]string)
		)
		i := 0
		lenStop := len(formFlowNavigations)
		for {
			for j, form := range formFlowNavigations {
				//fmt.Printf("form: %+v\n\n", form)
				if !hasFormStart {
					if form.FromForm == START {
						hasFormStart = true
						nextForm = form
						formFlowNavigations = SliceFormFlowNavigations(formFlowNavigations, j)
						break
					}
				} else {
					//fmt.Printf("nextForm: %+v\n\n", nextForm)
					if form.FromForm == nextForm.ToForm {
						arrConditions := strings.Split(form.ToForm, "_")
						fmt.Println("arrConditions: ", arrConditions)
						if arrConditions[0] == CONDITION {
							conditionID := form.ToForm
							formID, _, _ := CheckFormConditionFunc(requestHeader, lang, conditionID, jobID, jobTaskID)
							fmt.Println("conditionID: ", conditionID)
							fmt.Println("conditionID > formID: ", formID)
							// @TODO test
							//formID = "ped_76617205-3cc7-f747-7abf-d0e83f6f7293"
							nextForm = models.FormFlowNavigation{
								ToForm:   formID,
								FromForm: nextForm.ToForm,
							}
							break
						} else {
							nextForm = form
							formFlowNavigations = SliceFormFlowNavigations(formFlowNavigations, j)
							break
						}
					}
				}
			}
			fmt.Printf("nextForm: %+v\n\n", nextForm)
			var (
				jobFormNavigationForm models.JobFormNavigationForm
			)
			if nextForm.FromForm != "" {
				if nextForm.FromForm != START {
					// check duplicate data
					_, ok := mapFormNavigation[nextForm.FromForm]
					if !ok {
						mapFormNavigation[nextForm.FromForm] = nextForm.FromForm
						iFormID, sFormID := strconv.Atoi(nextForm.FromForm)
						if sFormID == nil {
							// find Form by FormID
							var (
								dynamicForm models.DynamicForm
							)
							resultFindDynamicForm := db.Where("DynamicFormID = ?", iFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&dynamicForm)
							if resultFindDynamicForm.RowsAffected > 0 {
								jobFormNavigationForm.Form = strconv.Itoa(dynamicForm.DynamicFormID)
								jobFormNavigationForm.FormTitle = dynamicForm.FormStatus
							} else {
								// @TODO need to accept
								jobFormNavigationForm.Form = nextForm.FromForm
								jobFormNavigationForm.FormTitle = nextForm.FromForm
							}
						} else {
							arrFormTitle := strings.Split(nextForm.FromForm, "_")
							if arrFormTitle[0] != CONDITION {
								jobFormNavigationForm.Form = nextForm.FromForm
								jobFormNavigationForm.FormTitle = arrFormTitle[0]
							}
						}
						jobFormNavigationForm.Sort = i
						jobFormNavigationForms = append(jobFormNavigationForms, jobFormNavigationForm)
					}
				}
			}
			if nextForm.ToForm == END {
				hasFormEnd = true
			}
			if hasFormEnd || len(formFlowNavigations) <= 0 || i > lenStop || nextForm.FromForm == dynamicFormIDToStop {
				break
			}
			i++
		}
	}
	jobFormNavigation.Forms = jobFormNavigationForms
	//fmt.Printf("jobFormNavigation: %+v\n", jobFormNavigation)
	return jobFormNavigation
}

// SliceFormFlowNavigations func
func SliceFormFlowNavigations(arr []models.FormFlowNavigation, index int) []models.FormFlowNavigation {
	if index == 0 {
		return arr[1:]
	} else if index >= len(arr) {
		return arr
	}
	return append(arr[:index], arr[index+1:]...)
}

// CompareAndUpdateWithJobDynamicForm func
func CompareAndUpdateWithJobDynamicForm(requestHeader models.RequestHeader, lang string, accountKey int, jobFormNavigationForm []models.JobFormNavigationForm) []models.JobFormNavigationForm {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	for i, form := range jobFormNavigationForm {
		iDynamicFormID, sDynamicFormID := strconv.Atoi(form.Form)
		if sDynamicFormID == nil {
			var (
				dynamicFormModel       models.DynamicForm
				jobDynamicFormModel    models.JobDynamicForm
				newJobDynamicFormModel models.JobDynamicForm
				newInsert              = false
				dynamicDesignP         string
				dynamicDesignL         string
				jobDynamicDesignP      string
				jobDynamicDesignL      string
			)
			// find dynamicforms table
			resultFindDynamicForm := db.Where("DynamicFormID = ?", iDynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&dynamicFormModel)
			if resultFindDynamicForm.RowsAffected > 0 {
				// find jobdynamicforms table => find newest row
				resultFindJobDynamicForm := db.Where("DynamicFormID = ?", iDynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Last(&jobDynamicFormModel)
				if resultFindJobDynamicForm.RowsAffected > 0 {
					// exist => compare
					if dynamicFormModel.DesignP != nil {
						dynamicDesignP = *dynamicFormModel.DesignP
					}
					if dynamicFormModel.DesignL != nil {
						dynamicDesignL = *dynamicFormModel.DesignL
					}
					if jobDynamicFormModel.DesignP != nil {
						jobDynamicDesignP = *jobDynamicFormModel.DesignP
					}
					if jobDynamicFormModel.DesignL != nil {
						jobDynamicDesignL = *jobDynamicFormModel.DesignL
					}
					if dynamicDesignP != jobDynamicDesignP || dynamicDesignL != jobDynamicDesignL {
						// exist & changed
						newInsert = true
					} else {
						// exist & not changed
						jobFormNavigationForm[i].Form = strconv.Itoa(jobDynamicFormModel.JobDynamicFormID)
						jobFormNavigationForm[i].OriginalForm = iDynamicFormID
					}
				} else {
					// not exist in JobDynamicForm
					newInsert = true
				}
			}
			if newInsert {
				newJobDynamicFormModel.DynamicFormID = iDynamicFormID
				newJobDynamicFormModel.FormName = dynamicFormModel.FormName
				newJobDynamicFormModel.DesignP = dynamicFormModel.DesignP
				newJobDynamicFormModel.DesignL = dynamicFormModel.DesignL
				newJobDynamicFormModel.CreatedBy = accountKey
				newJobDynamicFormModel.ModifiedBy = accountKey
				reusltCreate := db.Create(&newJobDynamicFormModel)
				if reusltCreate.Error == nil {
					jobFormNavigationForm[i].Form = strconv.Itoa(newJobDynamicFormModel.JobDynamicFormID)
					jobFormNavigationForm[i].OriginalForm = iDynamicFormID
				}
			}
		}
	}

	return jobFormNavigationForm
}

// CompareAndUpdateWithJobDynamicForm func
func CompareAndUpdateWithJobBreakInDynamicForm(requestHeader models.RequestHeader, lang string,
	accountKey int, jobFormNavigationForm models.BreakFormsNavigationForm) models.BreakFormsNavigationForm {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	iDynamicFormID, sDynamicFormID := strconv.Atoi(jobFormNavigationForm.Form)
	if sDynamicFormID == nil {
		var (
			dynamicFormModel       models.DynamicForm
			jobDynamicFormModel    models.JobDynamicForm
			newJobDynamicFormModel models.JobDynamicForm
			newInsert              = false
			dynamicDesignP         string
			dynamicDesignL         string
			jobDynamicDesignP      string
			jobDynamicDesignL      string
		)
		// find dynamicforms table
		resultFindDynamicForm := db.Where("DynamicFormID = ?", iDynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&dynamicFormModel)
		if resultFindDynamicForm.RowsAffected > 0 {
			// find jobdynamicforms table => find newest row
			resultFindJobDynamicForm := db.Where("DynamicFormID = ?", iDynamicFormID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Last(&jobDynamicFormModel)
			if resultFindJobDynamicForm.RowsAffected > 0 {
				// exist => compare
				if dynamicFormModel.DesignP != nil {
					dynamicDesignP = *dynamicFormModel.DesignP
				}
				if dynamicFormModel.DesignL != nil {
					dynamicDesignL = *dynamicFormModel.DesignL
				}
				if jobDynamicFormModel.DesignP != nil {
					jobDynamicDesignP = *jobDynamicFormModel.DesignP
				}
				if jobDynamicFormModel.DesignL != nil {
					jobDynamicDesignL = *jobDynamicFormModel.DesignL
				}
				if dynamicDesignP != jobDynamicDesignP || dynamicDesignL != jobDynamicDesignL {
					// exist & changed
					newInsert = true
				} else {
					// exist & not changed
					jobFormNavigationForm.Form = strconv.Itoa(jobDynamicFormModel.JobDynamicFormID)
					jobFormNavigationForm.OriginalForm = iDynamicFormID
				}
			} else {
				// not exist in JobDynamicForm
				newInsert = true
			}
		}
		if newInsert {
			newJobDynamicFormModel.DynamicFormID = iDynamicFormID
			newJobDynamicFormModel.FormName = dynamicFormModel.FormName
			newJobDynamicFormModel.DesignP = dynamicFormModel.DesignP
			newJobDynamicFormModel.DesignL = dynamicFormModel.DesignL
			newJobDynamicFormModel.CreatedBy = accountKey
			newJobDynamicFormModel.ModifiedBy = accountKey
			reusltCreate := db.Create(&newJobDynamicFormModel)
			if reusltCreate.Error == nil {
				jobFormNavigationForm.Form = strconv.Itoa(newJobDynamicFormModel.JobDynamicFormID)
				jobFormNavigationForm.OriginalForm = iDynamicFormID
			}
		}
	}

	return jobFormNavigationForm
}

// GetJobTaskByID godoc
// @Summary Get JobTask By ID
// @Description Get JobTask By ID
// @Tags JobTask
// @Accept json
// @Produce json
// @Param Form query string false "Form"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Type path int true "Item Movement Type"
// @Param JobTask body models.JobTask true "Get JobTask By ID"
// @Success 200 {object} models.APIResponseData
// @Router /jobtask/{id} [get]
func GetJobTaskByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobTaskByID")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
		jobTask           models.JobTask
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	id := c.Param("id")

	resultFind := db.Where("JobTaskID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
	if resultFind.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		dataResponse := ConvertJobTaskForSmartScheduleToResponse(jobTask)
		data = dataResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertJobTaskForSmartScheduleToResponse func
func ConvertJobTaskForSmartScheduleToResponse(item models.JobTask) models.JobTaskForSmartSchedulingResponse {
	var (
		response models.JobTaskForSmartSchedulingResponse
	)
	response.JobID = item.JobID
	response.NavigationAddress = item.NavigationAddress
	return response
}
