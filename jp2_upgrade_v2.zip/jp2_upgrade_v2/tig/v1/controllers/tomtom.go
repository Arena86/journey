package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func IntArrayContains(s []int, e int) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}
func CalcJobPrecomputeRouteTest(c *gin.Context) {
	defer libs.RecoverError(c, "CalcJobPrecomputeRouteTest")
	var (
		job          models.Job
		response     models.APIResponseData
		settingModel models.Setting
		responseData interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	jobID := 197
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
	resultFindParentJob := db.Preload(
		"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFindParentJob.RowsAffected > 0 {
		lang := services.GetLanguageKey(c)
		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		CalcJobPrecomputeRoute(accountKey, lang, job, settingModel, db)
	}
	response.Status = 200
	response.Message = nil
	response.Errors = nil
	response.Data = responseData
	libs.APIResponseData(response, c, 200)

}
func CalcJobPrecomputeRoute(accountKey int, lang string, job models.Job, settings models.Setting, db *gorm.DB) (interface{}, int, int) {

	var (
		tomTomResponsePoints    []models.TomTomResponsePoint
		responses               models.PrecomputedRouteTomTomResponse
		routeParts              = make([]models.TomTomRouteParts, 0)
		settingJobTemplateModel models.JobTemplate
		travelChargeMode        int
		location                models.Location
		lengthInMeters          int
		travelTimeInSeconds     int
	)
	fromDepotTravelChargeModes := []int{1, 3, 4, 6, 7, 9, 10, 11, 12, 17, 16}
	toDepotTravelChargeModes := []int{2, 3, 5, 6, 8, 9, 12, 14, 15}

	var (
		settingValue models.SettingValue
	)
	json.Unmarshal([]byte(*settings.Value), &settingValue)

	// Get Job Template
	settingJobTemplateID := *settingValue.PriceLists.FDPricesInspectionJobTemplate
	resultFindSettingJobTemplate := db.Where("JobTemplateID = ?", settingJobTemplateID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingJobTemplateModel)
	if resultFindSettingJobTemplate.RowsAffected > 0 {
		travelChargeMode = settingJobTemplateModel.TravelChargeMode
	}
	isFromDepot := IntArrayContains(fromDepotTravelChargeModes, travelChargeMode)
	isToDepot := IntArrayContains(toDepotTravelChargeModes, travelChargeMode)
	// Get location
	db.Where("LocationID = ?", job.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)

	// Depot Location
	var depot models.TomTomResponsePoint
	if location.Latitude != nil && location.Longitude != nil {
		depot.Latitude = *location.Latitude
		depot.Longitude = *location.Longitude
	} else {
		var (
			location models.Location
		)
		var bp = db.Preload("Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IsDepot = 1", models.Location{}.TableName())
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID = ?", job.LocationID).First(&location)
		if len(location.Addresses) > 0 {
			address := location.Addresses[0].NavigationAddress
			address = strings.Replace(address, "/", "", -1)
			apiURL := "/search/2/geocode/" + address + ".json"
			urlParameter := ""
			urlParameter = urlParameter + "?limit=1"
			apiURL = apiURL + urlParameter
			statusRes, _, dataRes := CallTomTomAPI(apiURL, accountKey, lang, settings)
			if statusRes == 200 {
				var geoCodeResponse models.GeocodeResponse
				json.Unmarshal(dataRes, &geoCodeResponse)
				if len(geoCodeResponse.Results) > 0 {
					// Convert Address to Location
					depot.Latitude = geoCodeResponse.Results[0].Position.Lat
					depot.Longitude = geoCodeResponse.Results[0].Position.Lon
				}
			}
		}
	}
	if isFromDepot {
		tomTomResponsePoints = append(tomTomResponsePoints, depot)
	}
	var jobTaskPoint models.TomTomResponsePoint

	for _, task := range job.JobTasks {
		address := task.NavigationAddress
		address = strings.Replace(address, "/", "", -1)
		apiURL := "/search/2/geocode/" + address + ".json"
		urlParameter := ""
		urlParameter = urlParameter + "?limit=1"
		apiURL = apiURL + urlParameter
		statusRes, _, dataRes := CallTomTomAPI(apiURL, accountKey, lang, settings)
		if statusRes == 200 {
			var geoCodeResponse models.GeocodeResponse
			json.Unmarshal(dataRes, &geoCodeResponse)
			if len(geoCodeResponse.Results) > 0 {
				// Convert Address to Location
				jobTaskPoint.Latitude = geoCodeResponse.Results[0].Position.Lat
				jobTaskPoint.Longitude = geoCodeResponse.Results[0].Position.Lon
				tomTomResponsePoints = append(tomTomResponsePoints, jobTaskPoint)
			}
		}
	}
	if isToDepot {
		tomTomResponsePoints = append(tomTomResponsePoints, depot)
	}

	avoid := settingValue.Estimate.Map.DefaultAvoid
	traffic := settingValue.Estimate.Map.Traffic
	if job.IsJob {
		avoid = settingValue.Job.Map.DefaultAvoid
		traffic = settingValue.Job.Map.Traffic
	}

	travelMode := GetTravelModes(job.ResourceType)
	calcPoint := ""
	for _, point := range tomTomResponsePoints {
		calcPoint = calcPoint + fmt.Sprintf("%f", point.Latitude) + "," + fmt.Sprintf("%f", point.Longitude) + ":"
	}
	calcPoint = strings.TrimSuffix(calcPoint, ":")
	urlParameter := ""
	apiURL := "/routing/1/calculateRoute/" + calcPoint + "/json"
	//params := make(map[string]interface{})
	urlParameter = urlParameter + "?computeBestOrder=" + strconv.FormatBool(false)
	//params["computeBestOrder"] = strconv.FormatBool(false)
	arrAvoid := make([]string, len(avoid))
	for i, v := range avoid {
		arrAvoid[i] = v.(string)
	}
	for _, i := range arrAvoid {
		//params["avoid"] = i
		urlParameter = urlParameter + "&avoid=" + i
	}
	//params["traffic"] = strconv.FormatBool(traffic)
	urlParameter = urlParameter + "&traffic=" + strconv.FormatBool(traffic)

	//params["travelMode"] = travelMode // Job ResourceType
	urlParameter = urlParameter + "&travelMode=" + travelMode

	apiURL = apiURL + urlParameter

	statusRes, _, dataRes := CallTomTomAPI(apiURL, accountKey, lang, settings)
	if statusRes == 200 {
		var resObj models.TomTomResponse
		json.Unmarshal(dataRes, &resObj)

		responses.Name = "Job #" + job.JobNumber
		responses.Version = "Job Date " + job.JobDate.Format("01-02-2006")

		var (
			road      models.TomTomRoad
			routePart models.TomTomRouteParts
		)
		if len(resObj.Routes) > 0 {
			for _, route := range resObj.Routes {
				lengthInMeters = route.Summary.LengthInMeters
				travelTimeInSeconds = route.Summary.TravelTimeInSeconds
				legs := route.Legs
				if len(legs) > 0 {

					twoWays := false
					index := 0
					if len(legs) > 1 {
						twoWays = true
					}
					for _, leg := range legs {
						var (
							roads  []models.TomTomRoad
							points []models.TomTomMapPoint
						)
						if len(leg.Points) > 0 {
							var (
								waypointFrom models.TomTomWaypoint
								waypointTo   models.TomTomWaypoint
							)
							startLat := int(leg.Points[0].Latitude * 100000)
							startLon := int(leg.Points[0].Longitude * 100000)
							finishLat := int(leg.Points[len(leg.Points)-1].Latitude * 100000)
							finishLon := int(leg.Points[len(leg.Points)-1].Longitude * 100000)
							if twoWays {
								if index == 0 {
									waypointFrom = models.TomTomWaypoint{Lat: startLat, Lon: startLon, Type: "start"}
									waypointTo = models.TomTomWaypoint{Lat: finishLat, Lon: finishLon, Type: "waypoint"}
								} else if index < len(legs)-1 {
									waypointFrom = models.TomTomWaypoint{Lat: startLat, Lon: startLon, Type: "waypoint"}
									waypointTo = models.TomTomWaypoint{Lat: finishLat, Lon: finishLon, Type: "waypoint"}
								} else {
									waypointFrom = models.TomTomWaypoint{Lat: startLat, Lon: startLon, Type: "waypoint"}
									waypointTo = models.TomTomWaypoint{Lat: finishLat, Lon: finishLon, Type: "finish"}
								}
							} else {
								waypointFrom = models.TomTomWaypoint{Lat: startLat, Lon: startLon, Type: "start"}
								waypointTo = models.TomTomWaypoint{Lat: finishLat, Lon: finishLon, Type: "finish"}
							}
							for _, ttPoint := range leg.Points {
								var (
									point models.TomTomMapPoint
								)
								point.Lat = ttPoint.Latitude
								point.Lng = ttPoint.Longitude
								points = append(points, point)
							}

							routePart.WaypointFrom = &waypointFrom
							routePart.WaypointTo = waypointTo

							road.ID = 1
							road.Points = points
							roads = append(roads, road)
							index++
						}
						routePart.Roads = roads
						routeParts = append(routeParts, routePart)
					}
				}
			}
		}

		responses.RouteParts = routeParts

	} /*else {
		var resObj models.TomTomResponseError
		json.Unmarshal(dataRes, &resObj)
		fmt.Println(resObj)
		return resObj
	}*/
	return responses, lengthInMeters, travelTimeInSeconds
}

func CallTomTomAPI(apiURL string, accountKey int, lang string, settings models.Setting) (int, interface{}, []byte) {
	var (
		statusRes = 200
		msg       interface{}
		dataRes   []byte
	)
	tomTomConfig := libs.GetTomTom(accountKey)

	if tomTomConfig.TomTomKey > 0 {
		apiKey := tomTomConfig.APIKey
		baseURL := tomTomConfig.APIBaseURL
		url := baseURL + apiURL
		//params["key"] = apiKey
		url = url + "&key=" + apiKey
		headers := make(map[string]interface{})
		headers["Content-Type"] = "application/json"
		statusRes, msg, dataRes = libs.RequestAPI(lang, "GET", url, nil, nil, headers)
	} else {
		statusRes = 500
		msg = "TomTom API is invalid"
		dataRes = nil
	}
	return statusRes, msg, dataRes
}

func GetTravelModes(resourceType int) string {
	switch resourceType {
	case 1:
		return "truck"
	case 2:
		return "car"
	case 3:
		return "motorcycle"
	case 4:
		return "pedestrian"
	case 7:
		return "van"
	case 8:
		return "bicycle"
	case 10:
		return "taxi"
	case 11:
		return "bus"
	case 12:
		return "truck"

	}
	return "car"
}
