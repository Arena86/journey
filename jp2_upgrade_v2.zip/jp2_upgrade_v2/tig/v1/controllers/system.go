package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Archive godoc
// @Summary Archive
// @Description Archive
// @Tags System
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /archive [put]
func Archive(c *gin.Context) {
	defer libs.RecoverError(c, "Archive")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		archiveRequests    models.ArchiveRequest
		totalUpdatedRecord = 0
		itemMsgError       string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &archiveRequests)
	table, _ := libs.GetQueryParam("table", c)
	sql := ""
	ID := ""
	if table == "" {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.table_required"))
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}
	if status == 200 {
		switch table {
		case models.User{}.TableName():
			ID = "UserID"
		case models.BusinessPartner{}.TableName():
			ID = "BusinessPartnerID"
		case models.Item{}.TableName():
			ID = "ItemID"
		case models.ItemGroup{}.TableName():
			ID = "ItemGroupID"
		case models.Resource{}.TableName():
			ID = "ResourceID"
		case models.Location{}.TableName():
			ID = "LocationID"
		case models.LocationGroup{}.TableName():
			ID = "LocationGroupID"
		case models.CustomerGroup{}.TableName():
			ID = "CustomerGroupID"
		case models.SecurityGroup{}.TableName():
			ID = "SecurityGroupID"
		case models.PriceList{}.TableName():
			ID = "PriceListID"
		case models.DistancePriceList{}.TableName():
			ID = "DistancePriceListID"
		case models.ServicePriceList{}.TableName():
			ID = "ServicePriceListID"
		case models.FourDPrice{}.TableName():
			ID = "4DPriceID"
		case models.DraftDynamicForm{}.TableName():
			ID = "DraftDynamicFormID"
		case models.DraftFormFlow{}.TableName():
			ID = "DraftFormFlowID"
		case models.JobTemplate{}.TableName():
			ID = "JobTemplateID"
		case models.EmailTemplate{}.TableName():
			ID = "EmailTemplateID"
		case models.SMSTemplate{}.TableName():
			ID = "SMSTemplateID"
		case models.Reason{}.TableName():
			ID = "ReasonID"
		case models.PEDSerie{}.TableName():
			ID = "PEDSerieID"
		case models.FormCheckList{}.TableName():
			ID = "FormCheckListID"
		case models.VehicleInspection{}.TableName():
			ID = "VehicleInspectionID"
		case models.VehicleStocktake{}.TableName():
			ID = "VehicleStocktakeID"
		case models.TravelTimeChargeMatrix{}.TableName():
			ID = "TravelTimeChargeMatrixID"
		case models.LegalDocument{}.TableName():
			ID = "LegalDocumentID"
		}
		if ID != "" {
			if table != "locations" {
				sql = `Update ` + table + ` SET IsArchived = not IsArchived, ModifiedBy = ?, ModifiedDate = NOW() WHERE ` + ID + ` IN (?)`
			} else {
				sql = `Update ` + table + ` SET IsArchived = not IsArchived, ModifiedBy = ?, ModifiedDate = NOW() WHERE IsMaster = 0 AND ` + ID + ` IN (?)`
			}
			rowsQuery, errQuery := db.Debug().Raw(sql, accountKey, archiveRequests.IDs).Rows()
			if errQuery == nil {
				defer rowsQuery.Close()
				totalUpdatedRecord = len(archiveRequests.IDs)

				//@TODO update to xero
				var (
					xeroConfig models.XeroConfig
				)
				resultFindXeroConfig := db.First(&xeroConfig)
				if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
					businessPartnerTable := models.BusinessPartner{}.TableName()
					if table == businessPartnerTable {
						for _, businessPartnerID := range archiveRequests.IDs {
							var (
								partner models.BusinessPartner
							)
							resultFind := db.Where("BusinessPartnerID = ?", businessPartnerID).First(&partner)
							if resultFind.RowsAffected > 0 {
								if partner.ErpKey != "" {
									var contact = make(map[string]interface{})
									contactStatus := "ACTIVE"
									if partner.IsArchived == true {
										contactStatus = "ARCHIVED"
									}
									contact["ContactID"] = partner.ErpKey
									contact["ContactStatus"] = contactStatus
									representURL := "Contacts/" + partner.ErpKey
									resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, contact, nil, nil)
									fmt.Println("resStatus: ", resStatus)
									fmt.Println("resMsg: ", resMsg)
									fmt.Println("resData: ", string(resData))
								}
							}
						}
					}
				}
			} else {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, errQuery.Error())
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		} else {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.table_invalid"))
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(archiveRequests.IDs), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJobFullAddress godoc
// @Summary UpdateJobFullAddress
// @Description UpdateJobFullAddress
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /updatejobfulladdress [put]
func UpdateJobFullAddress(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJobFullAddress")
	var (
		status                = libs.GetStatusSuccess()
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		msg, data, errors     interface{}
		jobFullAddressRequest models.JobFullAddressRequest
		job                   models.Job
		totalUpdatedRecord    = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &jobFullAddressRequest)
	resultFind := db.Preload(
		"JobDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobTasks",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND JobTaskID = ?", jobFullAddressRequest.JobTaskID,
	).Preload(
		"JobPickup",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobDelivery",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobOnSite",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobInStore",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourcePickUp",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"JobResourceDelivery",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"RecurringJob",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Preload(
		"RecurringJob.RecurringSkips",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("JobID = ?", jobFullAddressRequest.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFind.RowsAffected > 0 {
		var (
			itemMsgError string
		)
		if job.JobPickup != nil {
			job.JobPickup.ModifiedBy = accountKey
			job.JobPickup.Address = jobFullAddressRequest.Address
			job.JobPickup.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobPickup.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		if job.JobDelivery != nil {
			job.JobDelivery.ModifiedBy = accountKey
			job.JobDelivery.Address = jobFullAddressRequest.Address
			job.JobDelivery.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobDelivery.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		if job.JobOnSite != nil {
			job.JobOnSite.ModifiedBy = accountKey
			job.JobOnSite.Address = jobFullAddressRequest.Address
			job.JobOnSite.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobOnSite.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		if job.JobInStore != nil {
			job.JobInStore.ModifiedBy = accountKey
			job.JobInStore.Address = jobFullAddressRequest.Address
			job.JobInStore.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobInStore.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		if job.JobResourcePickUp != nil {
			job.JobResourcePickUp.ModifiedBy = accountKey
			job.JobResourcePickUp.Address = jobFullAddressRequest.Address
			job.JobResourcePickUp.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobResourcePickUp.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		if job.JobResourceDelivery != nil {
			job.JobResourceDelivery.ModifiedBy = accountKey
			job.JobResourceDelivery.Address = jobFullAddressRequest.Address
			job.JobResourceDelivery.ContactDetails = jobFullAddressRequest.ContactDetails
			job.JobResourceDelivery.ContactPhoneNumber = jobFullAddressRequest.ContactPhoneNumber
		}
		var resultSave *gorm.DB
		if len(job.JobTasks) > 0 {
			for i := range job.JobTasks {
				if job.JobTasks[i].JobTaskID == jobFullAddressRequest.JobTaskID {
					job.JobTasks[i].ModifiedBy = accountKey
					job.JobTasks[i].NavigationAddress = jobFullAddressRequest.Address
					job.JobTasks[i].IsFullAddress = true
					resultSave = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&job)
					break
				}
			}
		}
		if resultSave.Error != nil {
			status = 400
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
		} else {
			var (
				updatedJob   models.Job
				settingModel models.Setting
			)
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)

			// Update JobPrecomputedRoute
			findJob := db.Preload(
				"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("JobID = ?", job.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&updatedJob)
			if findJob.RowsAffected > 0 {
				responseData, lengthInMeters, travelTimeInSeconds := CalcJobPrecomputeRoute(accountKey, lang, job, settingModel, db)
				updatedJob.TravelTime = float64(travelTimeInSeconds)
				updatedJob.Distance = float64(lengthInMeters)
				jobPrecomputedRouteByte, err := json.Marshal(responseData)
				if err == nil {
					jobPrecomputedRoute := string(jobPrecomputedRouteByte)
					updatedJob.JobPrecomputedRoute = &jobPrecomputedRoute
				}
				updatedJob = CalculatePrice(requestHeader, updatedJob)
				resultSave := db.Save(&updatedJob)
				if resultSave.Error != nil {
					status = 400
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
				}
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
		data = jobFullAddressRequest
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetPrice godoc
// @Summary Get Price List
// @Description Get Price List
// @Tags PriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getprice [put]
func GetPrice(c *gin.Context) {
	defer libs.RecoverError(c, "GetPrice")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		pricePOST     models.GetPricePOST
		priceResponse models.GetPriceResponse
		taxes         []models.Tax

		job models.Job
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	jobid, _ := libs.GetQueryParam("jobid", c)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	// Get job
	var bp = db.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp.Where("JobID = ?", jobid).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &pricePOST)

	var (
		res          interface{}
		postMapData  map[string]interface{}
		itemsMapData []map[string]interface{}
	)
	json.Unmarshal([]byte(string(body)), &postMapData)
	_, res = services.ConvertJSONValueToVariable("Items", postMapData)
	if res != nil {
		jsonItems, err := json.Marshal(postMapData["Items"])
		if err == nil {

			db.Find(&taxes)

			json.Unmarshal([]byte(string(jsonItems)), &itemsMapData)
			for k, itemMap := range itemsMapData {
				var (
					validate     = false
					itemMsgError string
				)
				_, resUnitPrice := services.ConvertJSONValueToVariable("UnitPrice", itemMap)
				_, resQuantity := services.ConvertJSONValueToVariable("Quantity", itemMap)
				_, resDiscount := services.ConvertJSONValueToVariable("DiscountPercent", itemMap)
				_, resBuffer := services.ConvertJSONValueToVariable("BufferPercent", itemMap)
				if resUnitPrice != nil || resQuantity != nil || resDiscount != nil || resBuffer != nil {
					validate = true
				}
				if validate {
					if resUnitPrice == nil {
						if itemMsgError == "" {
							itemMsgError = itemMsgError + services.GetMessage(lang, "api.unitpriceisrequired")
						} else {
							itemMsgError = itemMsgError + "\n" + services.GetMessage(lang, "api.unitpriceisrequired")
						}
					}
					if resQuantity == nil {
						if itemMsgError == "" {
							itemMsgError = itemMsgError + services.GetMessage(lang, "api.quantityisrequired")
						} else {
							itemMsgError = itemMsgError + "\n" + services.GetMessage(lang, "api.quantityisrequired")
						}
					}
					if resDiscount == nil {
						if itemMsgError == "" {
							itemMsgError = itemMsgError + services.GetMessage(lang, "api.discountisrequired")
						} else {
							itemMsgError = itemMsgError + "\n" + services.GetMessage(lang, "api.discountisrequired")
						}
					}
					if resBuffer == nil {
						if itemMsgError == "" {
							itemMsgError = itemMsgError + services.GetMessage(lang, "api.bufferisrequired")
						} else {
							itemMsgError = itemMsgError + "\n" + services.GetMessage(lang, "api.bufferisrequired")
						}
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}

	if len(errorsResponse) > 0 {
		status, msg = GetStatusState("PUT", lang, 0, 1, errorsResponse, true)
	} else {

		priceResponse = CalculateJobPrice(requestHeader, pricePOST, job)
		data = priceResponse
		if status == 200 {
			if msg == nil {
				msg = services.GetMessage(lang, "api.success")
			}
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GenerateCode godoc
// @Summary Generate Code
// @Description Generate Code
// @Tags System
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /generatecode [get]
func GenerateCode(c *gin.Context) {
	defer libs.RecoverError(c, "GenerateCode")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		errorsResponse []models.ErrorResponse
		msg, data      interface{}
		responsesData  gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)

	businessPartner := "bp" // businesspartners
	item := "it"            // items
	resource := "re"        // resources
	jobtemplate := "jt"     // jobtemplates
	itemgroup := "ig"       // itemgroups
	relateditem := "ri"     // relateditems
	jobdetails1 := "jo"     // jobdetails1

	pType := ""
	vType, sType := libs.GetQueryParam("type", c)
	if sType {
		pType = strings.ToLower(vType)
	}
	for {
		var resultFindCheck *gorm.DB
		data = libs.GenerateBusinessPartnerCode()
		switch pType {
		case businessPartner:
			resultFindCheck = db.Where("BusinessPartnerCode = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.BusinessPartner{})
		case item:
			resultFindCheck = db.Where("Code = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Item{})
		case resource:
			resultFindCheck = db.Where("ResourceCode = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.Resource{})
		case jobtemplate:
			resultFindCheck = db.Where("JobTemplateCode = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.JobTemplate{})
		case itemgroup:
			resultFindCheck = db.Where("ItemGroupCode = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.ItemGroup{})
		case relateditem:
			resultFindCheck = db.Where("Code = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.RelatedItem{})
		case jobdetails1:
			resultFindCheck = db.Where("Code = ?", data).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&models.JobDetail{})
		}
		if resultFindCheck != nil {
			// error then == 0
			if resultFindCheck.RowsAffected == 0 {
				break
			}
		} else {
			break
		}
	}
	msg = services.GetMessage(lang, "api.success")
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// GenerateSequenceNumber godoc
// @Summary Generate Sequence Number
// @Description Generate Sequence Number
// @Tags System
// @Accept  json
// @Produce  json
// @Param documentsequence query string false "Document Sequence-JobNumber|EstimateNumber|InvoiceNumber|CreditNoteNumber"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /generatesequencenumber [get]
func GenerateSequenceNumber(c *gin.Context) {
	defer libs.RecoverError(c, "GenerateSequenceNumber")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		sequenceData  = make(map[string]interface{})
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	vdocumentsequence, sdocumentsequence := libs.GetQueryParam("documentsequence", c)
	if sdocumentsequence {
		vdocumentsequence = strings.ToLower(vdocumentsequence)
		if libs.InArrayString(vdocumentsequence, []string{strings.ToLower(models.JobNumber), strings.ToLower(models.EstimateNumber), strings.ToLower(models.InvoiceNumber), strings.ToLower(models.CreditNoteNumber)}) {
			var (
				sequencyModel     models.DocumentSequency
				jobNumPrefix      models.Prefix
				estimateNumPrefix models.Prefix
				invoiceNumPrefix  models.Prefix
				creditNotePrefix  models.Prefix
			)
			CheckDocumentSequencesBeforeCreate(requestHeader)
			db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
			switch vdocumentsequence {
			case strings.ToLower(models.JobNumber):
				{
					db.Where("DocumentSequence = ?", models.JobNumber).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobNumPrefix)
					if jobNumPrefix.DocumentSequence != "" {
						jobNumberFirstConfig := jobNumPrefix.Prefix
						lenJobNumberConfig := jobNumPrefix.Length
						sqJobNumber := sequencyModel.JobNumber
						sequenceData["SequenceNumber"] = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)
					} else {
						status = 404
						msg = services.GetMessage(lang, "api.field_not_found", "JobNumber Prefix")
					}
				}
			case strings.ToLower(models.EstimateNumber):
				{
					db.Where("DocumentSequence = ?", models.EstimateNumber).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&estimateNumPrefix)
					if estimateNumPrefix.DocumentSequence != "" {
						estimateNumberFirstConfig := estimateNumPrefix.Prefix
						lenEstimateNumberConfig := estimateNumPrefix.Length
						sqEstimateNumber := sequencyModel.EstimateNumber
						sequenceData["SequenceNumber"] = services.GenerateDefaultValueWithConfigLength(estimateNumberFirstConfig, lenEstimateNumberConfig, sqEstimateNumber)
					} else {
						status = 404
						msg = services.GetMessage(lang, "api.field_not_found", "EstimateNumber Prefix")
					}
				}
			case strings.ToLower(models.InvoiceNumber):
				{
					db.Where("DocumentSequence = ?", models.InvoiceNumber).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&invoiceNumPrefix)
					if invoiceNumPrefix.DocumentSequence != "" {
						invoiceNumberFirstConfig := invoiceNumPrefix.Prefix
						lenInvoiceNumberConfig := invoiceNumPrefix.Length
						sqInvoiceNumber := sequencyModel.InvoiceNumber
						sequenceData["SequenceNumber"] = services.GenerateDefaultValueWithConfigLength(invoiceNumberFirstConfig, lenInvoiceNumberConfig, sqInvoiceNumber)
					} else {
						status = 404
						msg = services.GetMessage(lang, "api.field_not_found", "InvoiceNumber Prefix")
					}
				}
			case strings.ToLower(models.CreditNoteNumber):
				{
					db.Where("DocumentSequence = ?", models.CreditNoteNumber).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&creditNotePrefix)
					if creditNotePrefix.DocumentSequence != "" {
						creditNoteFirstConfig := creditNotePrefix.Prefix
						lenCreditNoteConfig := creditNotePrefix.Length
						sqCreditNote := sequencyModel.CreditNoteNumber
						sequenceData["SequenceNumber"] = services.GenerateDefaultValueWithConfigLength(creditNoteFirstConfig, lenCreditNoteConfig, sqCreditNote)
					} else {
						status = 404
						msg = services.GetMessage(lang, "api.field_not_found", "CreditNoteNumber Prefix")
					}
				}
			}

		} else {
			status = 422
			msg = services.GetMessage(lang, "api.documentsequence_invalid")
		}
	} else {
		status = 422
		msg = services.GetMessage(lang, "api.documentsequence_required")
	}

	if status == 200 {
		data = sequenceData
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetUserByAccount func
func GetUserByAccount(accountKey int, requestHeader models.RequestHeader) models.User {
	var (
		userModel models.User
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)

	return userModel
}

// XeroIntegrationStatus func
func XeroIntegrationStatus(c *gin.Context) {
	defer libs.RecoverError(c, "XeroIntegrationStatus")
	var (
		status                = libs.GetStatusSuccess()
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		errorsResponse        []models.ErrorResponse
		msg                   interface{}
		responsesData         gin.H
		xeroConfig            models.XeroConfig
		xeroIntegrationStatus models.XeroIntegrationStatus
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	resultFindCheck := db.First(&xeroConfig)
	if resultFindCheck.RowsAffected > 0 {
		xeroIntegrationStatus.IsActive = xeroConfig.IsActive
		xeroIntegrationStatus.IsCreditNoteEnabled = xeroConfig.IsCreditNoteEnabled
		xeroIntegrationStatus.IsInvoiceEnabled = xeroConfig.IsInvoiceEnabled
		xeroIntegrationStatus.UseXeroPush = xeroConfig.UseXeroPush
		xeroIntegrationStatus.IntervalInSeconds = xeroConfig.IntervalInSeconds
		xeroIntegrationStatus.IsPostAfterJobCompleted = xeroConfig.IsPostAfterJobCompleted
		xeroIntegrationStatus.PostedInvoiceStatus = xeroConfig.PostedInvoiceStatus
		xeroIntegrationStatus.InvoiceNumberGeneration = xeroConfig.InvoiceNumberGeneration
		xeroIntegrationStatus.InvoiceDueDate = xeroConfig.InvoiceDueDate
		xeroIntegrationStatus.CreditNoteNumberGeneration = xeroConfig.CreditNoteNumberGeneration
	}
	msg = services.GetMessage(lang, "api.success")
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = xeroIntegrationStatus
	libs.ResponseData(responsesData, c, status)
}
