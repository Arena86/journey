package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"math"
	"os"
	"strconv"
	"time"

	"github.com/chargebee/chargebee-go"
	cardAction "github.com/chargebee/chargebee-go/actions/card"
	couponAction "github.com/chargebee/chargebee-go/actions/coupon"
	couponCodeAction "github.com/chargebee/chargebee-go/actions/couponcode"
	creditNoteAction "github.com/chargebee/chargebee-go/actions/creditnote"
	customerAction "github.com/chargebee/chargebee-go/actions/customer"
	invoiceAction "github.com/chargebee/chargebee-go/actions/invoice"
	paymentSourceAction "github.com/chargebee/chargebee-go/actions/paymentsource"
	"github.com/chargebee/chargebee-go/enum"
	"github.com/chargebee/chargebee-go/filter"
	"github.com/chargebee/chargebee-go/models/card"
	"github.com/chargebee/chargebee-go/models/creditnote"
	"github.com/chargebee/chargebee-go/models/customer"
	"github.com/chargebee/chargebee-go/models/invoice"
	"github.com/chargebee/chargebee-go/models/paymentsource"
	"github.com/gin-gonic/gin"
)

func GetCBCustomerID(companyID string, accountKey int, lang string) string {
	URL := os.Getenv("SERVER_REE") + "/" + "getsubscriptionbycompany"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	headers["CompanyID"] = companyID
	statusRee, _, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee == 200 {
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data := reeResponse["data"]
		var objectsJobHeader map[string]interface{}
		jobHeaderJSON, _ := json.Marshal(data)
		json.Unmarshal(jobHeaderJSON, &objectsJobHeader)
		val, res := services.ConvertJSONValueToVariable("CBCustomerID", objectsJobHeader)
		if res != nil {
			return val
		}
	}
	return ""
}

// GetChargeBeeCustomers godoc
// @Summary GetChargeBeeCustomers
// @Description GetChargeBeeCustomers
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customers [get]
func GetChargeBeeCustomers(c *gin.Context) {
	defer libs.RecoverError(c, "GetChargeBeeCustomers")
	var (
		status    = libs.GetStatusSuccess()
		response  models.APIResponseData
		msg       interface{}
		data      interface{}
		resModels = make([]interface{}, 0)
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	res, err := customerAction.List(&customer.ListRequestParams{}).ListRequest()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		for _, sub := range res.List {
			var resModel interface{}
			if sub != nil {
				subResult := *sub
				resModel = subResult.Customer
			}
			resModels = append(resModels, resModel)
		}
		data = resModels
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetChargeBeeCustomerByCustomerID godoc
// @Summary GetChargeBeeCustomerByCustomerID
// @Description GetChargeBeeCustomerByCustomerID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customer [get]
func GetChargeBeeCustomerByCustomerID(c *gin.Context) {
	defer libs.RecoverError(c, "GetChargeBeeCustomerByCustomerID")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)

	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)

	res, err := customerAction.Retrieve(customerID).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res.Customer
		}
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetPaymentSourcesByCustomerID godoc
// @Summary Get Payment Sources By Customer ID
// @Description Get Payment Sources By Customer ID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/paymentsources [get]
func GetPaymentSourcesByCustomerID(c *gin.Context) {
	// http://localhost:6040/jpapi/api/1.0/chargebee/customers
	// "primary_payment_source_id": "pm_169mBRSTmnK5qEWi" => primary
	defer libs.RecoverError(c, "GetPaymentSourcesByCustomerID")
	var (
		status           = libs.GetStatusSuccess()
		response         models.APIResponseData
		msg              interface{}
		data             interface{}
		resModels        = make([]interface{}, 0)
		paymentResources []models.CBPaymentMethodResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	if customerID != "" {
		chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
		chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
		res, err := paymentSourceAction.List(&paymentsource.ListRequestParams{
			CustomerId: &filter.StringFilter{
				Is: customerID,
			},
		}).ListRequest()
		if err != nil {
			var chargeBeeError models.ChargeBeeError
			json.Unmarshal([]byte(err.Error()), &chargeBeeError)
			if chargeBeeError.Message != "" {
				status = chargeBeeError.HTTPStatusCode
				msg = chargeBeeError.Message
			} else {
				status = 500
				msg = err.Error()
			}
		} else {
			primaryPaymentSourceID := ""
			resCus, errCus := customerAction.Retrieve(customerID).Request()
			if errCus == nil {
				if resCus != nil {
					primaryPaymentSourceID = resCus.Customer.PrimaryPaymentSourceId
				}
			}
			for _, sub := range res.List {
				var (
					paymentResource models.CBPaymentMethodResponse
					card            models.CBCardResponse
				)
				if sub != nil {
					subResult := *sub
					resModel := subResult.PaymentSource

					card.FirstName = resModel.Card.FirstName
					card.LastName = resModel.Card.LastName
					card.Number = resModel.Card.MaskedNumber
					card.ExpiryMonth = resModel.Card.ExpiryMonth
					card.ExpiryYear = resModel.Card.ExpiryYear
					card.Brand = string(resModel.Card.Brand)
					paymentResource.Card = card
					paymentResource.PaymentMethodID = resModel.Id
					paymentResource.CreatedAt = time.Unix(resModel.CreatedAt, 0)
					paymentResource.CustomerID = resModel.CustomerId
					paymentResource.Deleted = resModel.Deleted
					paymentResource.IssuingCountry = resModel.IssuingCountry
					paymentResource.Status = string(resModel.Status)
					paymentResource.ObjectType = resModel.Object

					if resModel.Id == primaryPaymentSourceID {
						paymentResource.IsPrimary = true
					}
					paymentResources = append(paymentResources, paymentResource)
					//data = resModel
				}
			}
			data = paymentResources
		}
	} else {
		data = resModels
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetInvoiceByCustomerID godoc
// @Summary Get Invoice By Customer ID
// @Description Get Invoice By Customer ID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/getinvoicecustomer [get]
func GetInvoiceByCustomerID(c *gin.Context) {
	defer libs.RecoverError(c, "GetInvoiceByCustomerID")
	var (
		status     = libs.GetStatusSuccess()
		response   models.APIResponseData
		msg        interface{}
		data       interface{}
		cbInvoices []models.CBInvoiceResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	if customerID != "" {
		chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)

		chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
		res, err := invoiceAction.List(&invoice.ListRequestParams{
			CustomerId: &filter.StringFilter{
				Is: customerID,
			},
		}).ListRequest()
		if err != nil {
			var chargeBeeError models.ChargeBeeError
			json.Unmarshal([]byte(err.Error()), &chargeBeeError)
			if chargeBeeError.Message != "" {
				status = chargeBeeError.HTTPStatusCode
				msg = chargeBeeError.Message
			} else {
				status = 500
				msg = err.Error()
			}
		} else {
			if res != nil {
				for _, inv := range res.List {
					var cbInvoice models.CBInvoiceResponse
					cbInvoice.InvoiceNumber = inv.Invoice.Id
					cbInvoice.FirstName = inv.Invoice.BillingAddress.FirstName
					cbInvoice.LastName = inv.Invoice.BillingAddress.LastName
					cbInvoice.Date = time.Unix(inv.Invoice.Date, 0)
					cbInvoice.DueDate = time.Unix(inv.Invoice.DueDate, 0)
					cbInvoice.PaidAt = time.Unix(inv.Invoice.PaidAt, 0)
					cbInvoice.CurrencyCode = inv.Invoice.CurrencyCode
					cbInvoice.PONumber = inv.Invoice.PoNumber

					if string(inv.Invoice.PriceType) == "tax_exclusive" {
						cbInvoice.PriceType = "Tax Exclusive"
					}
					if string(inv.Invoice.PriceType) == "tax_inclusive" {
						cbInvoice.PriceType = "Tax Inclusive"
					}

					cbInvoice.Recurring = inv.Invoice.Recurring
					cbInvoice.Deleted = inv.Invoice.Deleted
					cbInvoice.FirstInvoice = inv.Invoice.FirstInvoice
					cbInvoice.IsGifted = inv.Invoice.IsGifted
					cbInvoice.Invoicetype = inv.Invoice.Object
					cbInvoice.Status = string(inv.Invoice.Status)
					cbInvoice.SubTotal = CalcCBAmount(inv.Invoice.SubTotal)
					cbInvoice.Tax = CalcCBAmount(inv.Invoice.Tax)
					cbInvoice.Total = CalcCBAmount(inv.Invoice.Total)
					cbInvoice.SubTotalInLocalCurrency = CalcCBAmount(inv.Invoice.SubTotalInLocalCurrency)
					cbInvoice.TotalInLocalCurrency = CalcCBAmount(inv.Invoice.TotalInLocalCurrency)
					cbInvoice.AmountAdjusted = CalcCBAmount(inv.Invoice.AmountAdjusted)
					cbInvoice.AmountDue = CalcCBAmount(inv.Invoice.AmountDue)
					cbInvoice.AmountPaid = CalcCBAmount(inv.Invoice.AmountPaid)
					cbInvoice.AmountToCollect = CalcCBAmount(inv.Invoice.AmountToCollect)
					cbInvoice.CreditsApplied = CalcCBAmount(inv.Invoice.CreditsApplied)
					cbInvoices = append(cbInvoices, cbInvoice)
				}
				data = cbInvoices //res.List
			}
		}
	} else {
		cbInvoices = make([]models.CBInvoiceResponse, 0)
		data = cbInvoices
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func CalcCBAmount(amount int32) float64 {
	var caclAmount float64
	caclAmount = float64(amount) / 100
	caclAmount = math.Round(caclAmount*100) / 100
	return caclAmount
}

// GetCreditNoteByCustomerID godoc
// @Summary Get Credit Note By Customer ID
// @Description Get Credit Note By Customer ID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/getcreditnotecustomer [get]
func GetCreditNoteByCustomerID(c *gin.Context) {
	defer libs.RecoverError(c, "GetCreditNoteByCustomerID")
	var (
		status        = libs.GetStatusSuccess()
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		cbCreditNotes []models.CBCreditNoteResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	if customerID != "" {
		chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
		chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
		res, err := creditNoteAction.List(&creditnote.ListRequestParams{
			CustomerId: &filter.StringFilter{
				Is: customerID,
			},
		}).ListRequest()
		if err != nil {
			var chargeBeeError models.ChargeBeeError
			json.Unmarshal([]byte(err.Error()), &chargeBeeError)
			if chargeBeeError.Message != "" {
				status = chargeBeeError.HTTPStatusCode
				msg = chargeBeeError.Message
			} else {
				status = 500
				msg = err.Error()
			}
		} else {
			if res != nil {
				for _, cr := range res.List {
					var cbCreditNote models.CBCreditNoteResponse
					cbCreditNote.CreditNoteNumber = cr.CreditNote.Id
					cbCreditNote.ReferenceInvoiceNumber = cr.CreditNote.ReferenceInvoiceId
					cbCreditNote.CreditNoteType = string(cr.CreditNote.Type)
					cbCreditNote.Date = time.Unix(cr.CreditNote.Date, 0)
					cbCreditNote.CurrencyCode = cr.CreditNote.CurrencyCode
					if string(cr.CreditNote.PriceType) == "tax_exclusive" {
						cbCreditNote.PriceType = "Tax Exclusive"
					}
					if string(cr.CreditNote.PriceType) == "tax_inclusive" {
						cbCreditNote.PriceType = "Tax Inclusive"
					}
					cbCreditNote.Deleted = cr.CreditNote.Deleted
					cbCreditNote.CreditNoteObject = cr.CreditNote.Object
					cbCreditNote.Status = string(cr.CreditNote.Status)
					cbCreditNote.SubTotal = CalcCBAmount(cr.CreditNote.SubTotal)
					cbCreditNote.Total = CalcCBAmount(cr.CreditNote.Total)
					cbCreditNote.SubTotalInLocalCurrency = CalcCBAmount(cr.CreditNote.SubTotalInLocalCurrency)
					cbCreditNote.TotalInLocalCurrency = CalcCBAmount(cr.CreditNote.TotalInLocalCurrency)
					cbCreditNote.AmountAllocated = CalcCBAmount(cr.CreditNote.AmountAllocated)
					cbCreditNote.AmountRefunded = CalcCBAmount(cr.CreditNote.AmountRefunded)
					cbCreditNote.AmountAvailable = CalcCBAmount(cr.CreditNote.AmountAvailable)
					cbCreditNote.RefundedAt = time.Unix(cr.CreditNote.RefundedAt, 0)
					cbCreditNote.LocalCurrencyCode = cr.CreditNote.LocalCurrencyCode
					cbCreditNotes = append(cbCreditNotes, cbCreditNote)
				}
				data = cbCreditNotes //res.List
			}
		}
	} else {
		cbCreditNotes = make([]models.CBCreditNoteResponse, 0)
		data = cbCreditNotes
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// AssignPaymentRoleByCustomerID godoc
// @Summary AssignPaymentRoleByCustomerID
// @Description AssignPaymentRoleByCustomerID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/assignpaymentrole [post]
func AssignPaymentRoleByCustomerID(c *gin.Context) {
	defer libs.RecoverError(c, "AssignPaymentRoleByCustomerID")
	var (
		status          = libs.GetStatusSuccess()
		response        models.APIResponseData
		msg             interface{}
		data            interface{}
		paymentSourceID string
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	body, _ := ioutil.ReadAll(c.Request.Body)
	var assignPaymentRolePOST map[string]interface{}
	json.Unmarshal([]byte(string(body)), &assignPaymentRolePOST)
	fPaymentSourceID, bPaymentSourceID := assignPaymentRolePOST["PaymentSourceID"]
	if bPaymentSourceID {
		paymentSourceID = fmt.Sprintf("%v", fPaymentSourceID)
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	res, err := customerAction.AssignPaymentRole(customerID, &customer.AssignPaymentRoleRequestParams{
		PaymentSourceId: paymentSourceID,
		Role:            enum.RolePrimary,
	}).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res.Customer
		}
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateChargeBeeCustomerCard godoc
// @Summary UpdateChargeBeeCustomerCard
// @Description UpdateChargeBeeCustomerCard
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customers/update/card [put]
func UpdateChargeBeeCustomerCard(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateChargeBeeCustomerCard")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	body, _ := ioutil.ReadAll(c.Request.Body)
	var chargebeeCardPOST models.ChargeBeeCardInfo
	json.Unmarshal([]byte(string(body)), &chargebeeCardPOST)
	expiryMonth := int32(chargebeeCardPOST.ExpiryMonth)
	expiryYear := int32(chargebeeCardPOST.ExpiryYear)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	res, err := cardAction.UpdateCardForCustomer(customerID, &card.UpdateCardForCustomerRequestParams{
		FirstName:   chargebeeCardPOST.FirstName,
		LastName:    chargebeeCardPOST.LastName,
		Number:      chargebeeCardPOST.Number,
		ExpiryMonth: chargebee.Int32(expiryMonth),
		ExpiryYear:  chargebee.Int32(expiryYear),
		Cvv:         chargebeeCardPOST.Cvv,
	}).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res.Customer
		}
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteChargeBeeCustomerCard godoc
// @Summary DeleteChargeBeeCustomerCard
// @Description DeleteChargeBeeCustomerCard
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customers/delete/card [delete]
func DeleteChargeBeeCustomerCard(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteChargeBeeCustomerCard")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	res, err := cardAction.DeleteCardForCustomer(customerID).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res.Customer
		}
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteChargeBeeCustomerCard godoc
// @Summary DeleteChargeBeeCustomerCard
// @Description DeleteChargeBeeCustomerCard
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customer/card/{id} [delete]
func DeleteChargeBeeCustomerPaymentSource(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteChargeBeeCustomerCard")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	paymentSourceID := c.Param("id")
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	res, err := paymentSourceAction.Delete(paymentSourceID).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res
		}
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteChargeBeeCustomerCard godoc
// @Summary DeleteChargeBeeCustomerCard
// @Description DeleteChargeBeeCustomerCard
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/customer/card [post]
func CreateChargeBeeCustomerPaymentSource(c *gin.Context) {
	defer libs.RecoverError(c, "CreateChargeBeeCustomerPaymentSource")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	body, _ := ioutil.ReadAll(c.Request.Body)
	var chargebeeCardPOST models.ChargeBeeCardInfo
	json.Unmarshal([]byte(string(body)), &chargebeeCardPOST)
	expiryMonth := int32(chargebeeCardPOST.ExpiryMonth)
	expiryYear := int32(chargebeeCardPOST.ExpiryYear)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	companyID := c.Request.Header.Get("companyid")
	customerID := GetCBCustomerID(companyID, accountKey, lang)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	param := &paymentsource.CreateCardRequestParams{
		CustomerId: customerID,
		Card: &paymentsource.CreateCardCardParams{
			FirstName:   chargebeeCardPOST.FirstName,
			LastName:    chargebeeCardPOST.LastName,
			Number:      chargebeeCardPOST.Number,
			Cvv:         chargebeeCardPOST.Cvv,
			ExpiryYear:  chargebee.Int32(expiryYear),
			ExpiryMonth: chargebee.Int32(expiryMonth),
		},
	}
	res, err := paymentSourceAction.CreateCard(param).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			data = res
		}
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetChargeBeeCustomerByCustomerID godoc
// @Summary GetChargeBeeCustomerByCustomerID
// @Description GetChargeBeeCustomerByCustomerID
// @Tags ChargeBee
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /chargebee/getcoupon/:couponcode [get]
func GetCouponByCode(c *gin.Context) {
	defer libs.RecoverError(c, "GetChargeBeeCustomerByCustomerID")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	couponCode := c.Param("couponcode")
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)

	res, err := couponCodeAction.Retrieve(couponCode).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			msg = services.GetMessage(lang, "api.coupon.not_found")
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil {
			couponObj := *res.CouponCode
			res, err := couponAction.Retrieve(couponObj.CouponId).Request()
			if err != nil {
				var chargeBeeError models.ChargeBeeError
				json.Unmarshal([]byte(err.Error()), &chargeBeeError)
				if chargeBeeError.Message != "" {
					status = chargeBeeError.HTTPStatusCode
					msg = chargeBeeError.Message
				} else {
					status = 500
					msg = err.Error()
				}
			} else {
				var response map[string]interface{}
				dataJSON, _ := json.Marshal(res.Coupon)
				json.Unmarshal([]byte(dataJSON), &response)
				response["coupon_code_status"] = couponObj.Status
				data = response
			}
		}
	}

	if status == 200 {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		} else {
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetChargeBeeInvoiceAsPDFByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetChargeBeeInvoiceAsPDFByID")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	invoiceID := c.Param("id")
	res, err := invoiceAction.Pdf(invoiceID, nil).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil && res.Download != nil {
			data = res.Download
		}
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetChargeBeeCreditNoteAsPDFByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetChargeBeeCreditNoteAsPDFByID")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	chargeBeeConfig := libs.GetChargeBeeConfig(lang, accountKey)
	chargebee.Configure(chargeBeeConfig.ConfigKey, chargeBeeConfig.ConfigSiteName)
	creditNoteID := c.Param("id")
	res, err := creditNoteAction.Pdf(creditNoteID, nil).Request()
	if err != nil {
		var chargeBeeError models.ChargeBeeError
		json.Unmarshal([]byte(err.Error()), &chargeBeeError)
		if chargeBeeError.Message != "" {
			status = chargeBeeError.HTTPStatusCode
			msg = chargeBeeError.Message
		} else {
			status = 500
			msg = err.Error()
		}
	} else {
		if res != nil && res.Download != nil {
			data = res.Download
		}
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
