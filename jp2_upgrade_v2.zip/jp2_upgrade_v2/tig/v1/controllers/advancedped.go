package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetAdvancedPEDByJobTask godoc
// @Summary GetAdvancedPEDByJobTask
// @Description GetAdvancedPEDByJobTask
// @Tags AdvancedPED
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getadvancedpedbyjobtask/{jobtaskid} [get]
func GetAdvancedPEDByJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetAdvancedPEDByJobTask")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.AdvancedPED
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	jobTaskID := c.Param("jobtaskid")

	arrString := []string{"FormID", "ControlID"}
	db = libs.FilterString(arrString, db, c)
	arrInteger := []string{"ButtonID"}
	db = libs.FilterInteger(arrInteger, db, c)

	// Sort
	resultRow := db.Preload("Images", "TableName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.AdvancedPED{}.TableName()).Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&resModels)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayAdvancedPEDToArrayResponse(requestHeader, resModels)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = responses
	libs.APIResponseData(response, c, status)
}

// CreateAdvancedPED godoc
// @Summary CreateAdvancedPED
// @Description CreateAdvancedPED
// @Tags AdvancedPED
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AdvancedPED body models.AdvancedPEDResponse true "Create AdvancedPED"
// @Success 200 {object} models.APIResponseData
// @Router /advancedped [post]
func CreateAdvancedPED(c *gin.Context) {
	defer libs.RecoverError(c, "CreateAdvancedPED")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.AdvancedPED
	)
	resModel.PassBodyJSONToModel(bp)
	resultFind := db.Where("AdvancedPEDID = ?", resModel.AdvancedPEDID).First(&resModel)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate
	resModel.CreatedBy = accountKey
	for i := range resModel.Images {
		resModel.Images[i].CreatedBy = accountKey
		resModel.Images[i].ModifiedBy = accountKey
		resModel.Images[i].TableNameObj = models.AdvancedPED{}.TableName()
	}
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		// @TODO validate for details
		if itemMsgError == "" {
			var resultCreate *gorm.DB
			if resultFind.RowsAffected > 0 {
				resultCreate = db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
			} else {
				resultCreate = db.Create(&resModel)
			}
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				arrSkipID := make([]int, 0)
				for _, img := range resModel.Images {
					arrSkipID = append(arrSkipID, img.PhotoID)
				}
				if len(arrSkipID) > 0 {
					db.Where("TableName = ? AND RecordID = ? AND PhotoID not in (?)", models.AdvancedPED{}.TableName(), resModel.AdvancedPEDID, arrSkipID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				} else {
					db.Where("TableName = ? AND RecordID = ?", models.AdvancedPED{}.TableName(), resModel.AdvancedPEDID).Model(&models.Photo{}).Updates(models.Photo{IsDeleted: true, ModifiedBy: accountKey})
				}
				data = ConvertAdvancedPEDToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayAdvancedPEDToArrayResponse func
func ConvertArrayAdvancedPEDToArrayResponse(requestHeader models.RequestHeader, items []models.AdvancedPED) []models.AdvancedPEDResponse {
	responses := make([]models.AdvancedPEDResponse, 0)
	for _, item := range items {
		response := ConvertAdvancedPEDToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertAdvancedPEDToResponse func
func ConvertAdvancedPEDToResponse(requestHeader models.RequestHeader, item models.AdvancedPED) models.AdvancedPEDResponse {
	var (
		response       models.AdvancedPEDResponse
		pedSerieDetail models.PEDSerieDetail
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.AdvancedPEDID = item.AdvancedPEDID
	response.JobID = item.JobID
	response.JobTaskID = item.JobTaskID
	response.PEDSerieDetailID = item.PEDSerieDetailID

	resultFind := db.Where("PEDSerieDetailID = ?", item.PEDSerieDetailID).First(&pedSerieDetail)

	if resultFind.RowsAffected > 0 {
		response.PEDSerieDetailName = pedSerieDetail.Name
		response.PEDSerieDetailImageURL = pedSerieDetail.ImageURL
	}

	response.FormID = item.FormID
	response.ButtonID = item.ButtonID
	response.ControlID = item.ControlID
	images := make([]models.PhotoResponse, 0)
	for _, img := range item.Images {
		var (
			image       models.PhotoResponse
			reasonModel models.Reason
		)
		image.PhotoID = img.PhotoID
		image.TableNameObj = img.TableNameObj
		image.ImageKey = img.ImageKey
		image.ImageURL = img.ImageURL
		image.ImageSize = img.ImageSize
		image.ETag = img.ETag
		image.ReasonID = img.ReasonID
		resultFindReason := db.Where("ReasonID = ?", img.ReasonID).First(&reasonModel)
		if resultFindReason.RowsAffected > 0 {
			image.Reason = reasonModel.Reason
		}
		image.Comment = img.Comment
		image.PositionX = img.PositionX
		image.PositionY = img.PositionY
		images = append(images, image)
	}
	response.Images = images

	return response
}
