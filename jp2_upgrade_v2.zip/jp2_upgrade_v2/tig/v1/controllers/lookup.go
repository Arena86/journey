package controllers

import (
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	jpdatabase "jpapi/tig/v1/databases/jp"

	"github.com/gin-gonic/gin"
)

// Lookup godoc
// @Summary Lookup
// @Description Lookup
// @Tags System
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /lookup [get]
func Lookup(c *gin.Context) {
	defer libs.RecoverError(c, "Lookup")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		responses     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	db2 := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}

	responses = make([]interface{}, 0)
	var totalCount int64
	totalCount = 0

	vTableName, sTableName := libs.GetQueryParam("tablename", c)
	vLookupValue, sLookupValue := libs.GetQueryParam("lookupvalue", c)
	if sTableName && sLookupValue {
		vStartInt, _ := strconv.Atoi(vStart)
		vLengthInt, _ := strconv.Atoi(vLength)
		var bp = db.Limit(vLengthInt).Offset(vStartInt)
		arrBusiness := []string{"vendors", "customers", "contractors"}
		arrItem := []string{"items"}
		arrJob := []string{"estimates", "jobs", "invoices", "creditnotes"}

		// Filter
		tableName := strings.ToLower(vTableName)
		arrTableName := libs.StringToArrayString(tableName)
		if len(arrTableName) > 0 {
			arrBusinessTableName := libs.GetArrayOnBothArray(arrTableName, arrBusiness)
			arrItemTableName := libs.GetArrayOnBothArray(arrTableName, arrItem)
			arrJobTableName := libs.GetArrayOnBothArray(arrTableName, arrJob)
			if len(arrBusinessTableName) > 0 {
				// @TODO BusinessPartner
				var (
					resModels    []models.BusinessPartner
					lookupModels []models.LookupField
				)
				sqlQuery := ``
				sqlWhere := ``
				db.Where("TableName in (?)", arrBusinessTableName).Find(&lookupModels)
				for _, v := range lookupModels {
					refix := `bp`
					switch v.RelatedTableName {
					case models.Address{}.TableName():
						refix = `ar`
					case models.Phone{}.TableName():
						refix = `ph`
					}
					if sqlWhere == "" {
						sqlWhere = refix + `.` + v.FieldName + ` like '%` + vLookupValue + `%'`
					} else {
						sqlWhere = sqlWhere + ` OR ` + refix + `.` + v.FieldName + ` like '%` + vLookupValue + `%'`
					}
				}
				sqlWhere = strings.TrimSpace(sqlWhere)
				if sqlWhere != "" {
					sqlWhere = ` where (` + sqlWhere + `) `
				}
				sqlQuery = `select bp.BusinessPartnerID from ` + models.BusinessPartner{}.TableName() + ` bp
						left join ` + models.Address{}.TableName() + ` ar on bp.BusinessPartnerID = ar.EntityID AND '` + models.BusinessPartner{}.TableName() + `' = ar.Entity
						left join ` + models.Phone{}.TableName() + ` ph on bp.BusinessPartnerID = ph.EntityID AND '` + models.BusinessPartner{}.TableName() + `' = ph.Entity ` + sqlWhere + ` group by  bp.BusinessPartnerID`

				arrID := make([]int, 0)

				rows, err := db2.Raw(sqlQuery).Rows()
				if err == nil {
					defer rows.Close()
					for rows.Next() {
						var ID int
						rows.Scan(&ID)
						if ID > 0 {
							arrID = append(arrID, ID)
						}
					}
				}

				// @TODO not find businesspartner
				if len(arrID) <= 0 {
					arrID = append(arrID, -1)
				}
				bp = bp.Where("BusinessPartnerID in (?)", arrID)
				bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

				whereConditionTrue := ``
				for _, k := range arrBusinessTableName {
					if k == "vendors" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsVendor = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsVendor = 1`
						}
					} else if k == "customers" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsCustomer = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsCustomer = 1`
						}
					} else if k == "contractors" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsContractor = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsContractor = 1`
						}
					}
				}
				if whereConditionTrue != "" {
					bp = bp.Where(whereConditionTrue)
				}

				// Sort
				vSort, sSort := libs.GetQueryParam("sort", c)
				if sSort {
					arrSorts := libs.GetSortParamsFromURL(vSort)
					for fieldSortObj, vSortObj := range arrSorts {
						strSort := fieldSortObj + " " + vSortObj
						bp = bp.Order(strSort)
					}
				}

				bp = bp.Preload("Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
				bp = bp.Preload("Phones", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
				bp = bp.Preload("Locations", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("CustomerGroups", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
				businessPartnersResponse := ConvertArrayBusinessPartnerToArrayResponse(requestHeader, resModels)
				for i, b := range businessPartnersResponse {
					var (
						udfModels []models.UDF
					)
					dbu := db
					dbu = dbu.Where("TableName = ?", models.BusinessPartner{}.TableName())
					dbu = dbu.Order("Sort ASC")
					dbu = dbu.Find(&udfModels)
					udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
					businessPartnersResponse[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
					for k, v := range udfResponses {
						val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "BusinessPartnerID", v.DataType, b.BusinessPartnerID)
						udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
						businessPartnersResponse[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
					}
					businessPartnersResponse[i].UDFs = udfResponses
				}
				responses = businessPartnersResponse
			} else if len(arrItemTableName) > 0 {
				// @TODO Item
				onlyServiceItem := false
				vServiceItem, sServiceItem := libs.GetQueryParam("ServiceItem", c)

				if sServiceItem {
					bServiceItem, eServiceItem := strconv.ParseBool(vServiceItem)
					if eServiceItem == nil {
						onlyServiceItem = bServiceItem
					}
				}
				var (
					resModels    []models.Item
					lookupModels []models.LookupField
				)
				sqlQuery := ``
				sqlWhere := ``
				db.Where("TableName in (?)", arrItemTableName).Find(&lookupModels)
				if len(lookupModels) > 0 {
					for _, v := range lookupModels {
						if sqlWhere == "" {
							sqlWhere = v.FieldName + ` like '%` + vLookupValue + `%'`
						} else {
							sqlWhere = sqlWhere + ` OR ` + v.FieldName + ` like '%` + vLookupValue + `%'`
						}
					}
				}
				sqlWhere = strings.TrimSpace(sqlWhere)
				if sqlWhere != "" {
					sqlWhere = ` where (` + sqlWhere + `) `
				}
				if onlyServiceItem {
					sqlWhere = sqlWhere + " AND ItemType = 2"
				}
				sqlQuery = `SELECT ItemID FROM ` + models.Item{}.TableName() + sqlWhere + ` group by  ItemID`

				arrID := make([]int, 0)

				rows, err := db2.Raw(sqlQuery).Rows()
				if err == nil {
					defer rows.Close()
					for rows.Next() {
						var ID int
						rows.Scan(&ID)
						if ID > 0 {
							arrID = append(arrID, ID)
						}
					}
				}

				// @TODO not find businesspartner
				if len(arrID) <= 0 {
					arrID = append(arrID, -1)
				}
				bp = bp.Preload("RelatedItems", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Where("ItemID in (?)", arrID)
				bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

				// Sort
				vSort, sSort := libs.GetQueryParam("sort", c)
				if sSort {
					arrSorts := libs.GetSortParamsFromURL(vSort)
					for fieldSortObj, vSortObj := range arrSorts {
						strSort := fieldSortObj + " " + vSortObj
						bp = bp.Order(strSort)
					}
				}
				bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
				responses = ConvertArrayItemsToArrayResponse(requestHeader, resModels, lang)
			} else if len(arrJobTableName) > 0 {

				// @TODO Job
				var (
					resModels    []models.Job
					lookupModels []models.LookupField
				)
				sqlQuery := ``
				sqlWhere := ``
				db.Where("TableName in (?)", arrJobTableName).Find(&lookupModels)
				if len(lookupModels) > 0 {
					for _, v := range lookupModels {
						refix := `jb`
						switch v.RelatedTableName {
						case models.JobDetail{}.TableName():
							refix = `jd`
						}
						if sqlWhere == "" {
							sqlWhere = refix + `.` + v.FieldName + ` like '%` + vLookupValue + `%'`
						} else {
							sqlWhere = sqlWhere + ` OR ` + refix + `.` + v.FieldName + ` like '%` + vLookupValue + `%'`
						}
					}
				}
				sqlWhere = strings.TrimSpace(sqlWhere)
				if sqlWhere != "" {
					sqlWhere = ` where (` + sqlWhere + `) `
				}
				sqlQuery = `SELECT jb.JobID FROM ` + models.Job{}.TableName() + ` jb 
				left join ` + models.JobDetail{}.TableName() + ` jd on jb.JobID = jd.JobID  ` + sqlWhere + `  GROUP BY jb.JobID`

				arrID := make([]int, 0)

				rows, err := db2.Raw(sqlQuery).Rows()
				if err == nil {
					defer rows.Close()
					for rows.Next() {
						var ID int
						rows.Scan(&ID)
						if ID > 0 {
							arrID = append(arrID, ID)
						}
					}
				}

				// @TODO not find businesspartner
				if len(arrID) <= 0 {
					arrID = append(arrID, -1)
				}
				bp = bp.Where("JobID in (?)", arrID)
				bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

				whereConditionTrue := ``
				for _, k := range arrJobTableName {
					if k == "estimates" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsEstimate = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsEstimate = 1`
						}
					} else if k == "jobs" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsJob = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsJob = 1`
						}
					} else if k == "invoices" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsInvoice = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsInvoice = 1`
						}
					} else if k == "creditnotes" {
						if whereConditionTrue == "" {
							whereConditionTrue = `IsCreditNote = 1`
						} else {
							whereConditionTrue = whereConditionTrue + ` OR IsCreditNote = 1`
						}
					}
				}
				if whereConditionTrue != "" {
					bp = bp.Where(whereConditionTrue)
				}

				// Sort
				bp = libs.SortDataOnParam(bp, c)
				bp = bp.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Preload("JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
				bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
				responses = ConvertArrayJobsToArrayResponse(requestHeader, resModels, lang, false, true)
			}
		}
	} else {
		if !sTableName {
			errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.field_required", "TableName"))
			errorsResponse = append(errorsResponse, errResponse)
		}
		if !sLookupValue {
			errResponse := GetErrorResponseErrorMessage(0, services.GetMessage(lang, "api.field_required", "LookupValue"))
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}
