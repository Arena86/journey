package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetCountryCode godoc
// @Summary Get CountryCode
// @Description Get CountryCode
// @Tags CountryCode
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param IsLocation query boolean false "IsLocation"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /countrycodes [get]
func GetCountryCode(c *gin.Context) {
	defer libs.RecoverError(c, "GetCountryCode")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.CountryCode
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var bp = db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayCountryCodeToArrayResponse(resModels, lang)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// CreateCountryCode godoc
// @Summary Get CreateCountryCode
// @Description Get CreateCountryCode
// @Tags CountryCode
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /countrycodes [post]
func CreateCountryCode(c *gin.Context) {
	defer libs.RecoverError(c, "CreateCountryCode")
	var (
		status             = libs.GetStatusSuccess()
		resModel           models.CountryCode
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data          interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	var (
		itemMsgError string
	)
	var objectsJSON map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	resModel.PassBodyJSONToModel(objectsJSON)

	findCountryCode := db.Debug().Where("CountryCode = ?", resModel.CountryCode).Find(&models.CountryCode{})
	if findCountryCode.RowsAffected <= 0 {
		resModel.CreatedBy = accountKey
		resModel.ModifiedBy = accountKey
		resultCreate := db.Create(&resModel)
		if resultCreate.Error == nil {
			totalUpdatedRecord++
		} else {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(1, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		errResponse := GetErrorResponseValidate(lang, 1, "api.countrycode_exist")
		errorsResponse = append(errorsResponse, errResponse)
	}

	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, false)
	if status == 200 {
		data = ConvertCountryCodeToResponse(resModel, lang)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// DeleteCountryCode godoc
// @Summary Get DeleteCountryCode
// @Description Get DeleteCountryCode
// @Tags CountryCode
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /countrycodes/{id} [delete]
func DeleteCountryCode(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteCountryCode")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArrayString(strID)
	for k, id := range arrID {
		var (
			uModel models.CountryCode
		)
		resultFind := db.Where("CountryCodeID  = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			sqlDelete := "DELETE FROM " + models.CountryCode{}.TableName() + " WHERE CountryCodeID = ?"
			err := db.Exec(sqlDelete, uModel.CountryCodeID).Error
			if err == nil {
				totalUpdatedRecord++
			} else {
				errResponse := GetErrorResponseErrorMessage(k, err.Error())
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayCountryCodeToArrayResponse func
func ConvertArrayCountryCodeToArrayResponse(items []models.CountryCode, lang string) []models.CountryCodeResponse {
	responses := make([]models.CountryCodeResponse, 0)
	for _, item := range items {
		response := ConvertCountryCodeToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertCountryCodeToResponse func
func ConvertCountryCodeToResponse(item models.CountryCode, lang string) models.CountryCodeResponse {
	var (
		response models.CountryCodeResponse
	)
	response.CountryCodeID = item.CountryCodeID
	response.Country = item.Country
	response.CountryCode = item.CountryCode
	response.CountryName = item.CountryName
	response.PhoneDigitsMin = item.PhoneDigitsMin
	response.PhoneDigitsMax = item.PhoneDigitsMax
	return response
}
