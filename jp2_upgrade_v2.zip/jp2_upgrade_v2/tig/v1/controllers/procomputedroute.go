package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetPrecomputedRoutesByResourceID godoc
// @Summary GetPrecomputedRoutesByResourceID
// @Description GetPrecomputedRoutesByResourceID
// @Tags PrecomputedRoute
// @Accept  json
// @Produce  json
// @Param ResourceID query int true "ResourceID"
// @Param FromDate query string true "FromDate: yyyy-mm-dd HH:mm:ss"
// @Param ToDate query string true "ToDate: yyyy-mm-dd HH:mm:ss"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /precomputedroutes [get]
func GetPrecomputedRoutesByResourceID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPrecomputedRouteByTaskID")
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		scheduleModels []models.Schedule
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	var (
		validateMsgError string
		resourceID       int
		responses        = make([]models.PrecomputedRouteResourceResponse, 0)
		arrObj           = make([]models.PrecomputedRouteResourceObject, 0)
	)
	journeyCode := ""
	format := libs.MYSQLDATE
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate == nil {
			fmt.Println("dFromDate: ", dFromDate)
			vFromDate = dFromDate.Format(format)
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		}
	} else {
		status = 422
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate == nil {
			vToDate = dToDate.Format(format)
		} else {
			status = 422
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_invalid"))
		}
	} else {
		status = 422
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.todate_required"))
	}

	vResourceID, sResourceID := libs.GetQueryParam("ResourceID", c)
	if sResourceID {
		resourceID, _ = strconv.Atoi(vResourceID)
	} else {
		status = 422
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.resourceid_required"))
	}
	vJourneyCode, sJourneyCode := libs.GetQueryParam("JourneyCode", c)
	if sJourneyCode {
		journeyCode = vJourneyCode
	}
	if status == 200 {
		var pc = db.Where(
			"ResourceID = ?", resourceID,
		)
		if journeyCode != "" {
			pc = pc.Where(
				"JourneyCode = ?", journeyCode,
			)
		}
		pc.Where(
			"ScheduleStartDate >= ? AND ScheduleStartDate <= ?", vFromDate, vToDate,
		).Where(
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Order("ScheduleStartDate ASC, LocationID ASC").Find(&scheduleModels)
		for _, schedule := range scheduleModels {
			existObj := false
			for j, obj := range arrObj {
				if schedule.ResourceID == obj.ResourceID && schedule.LocationID == obj.LocationID {
					existObj = true
					existScheduleID := false
					for _, scheduleObj := range obj.Schedules {
						if schedule.ScheduleID == scheduleObj.ScheduleID {
							existScheduleID = true
						}
					}
					if !existScheduleID {
						arrObj[j].Schedules = append(arrObj[j].Schedules, schedule)
					}
				}
			}
			if !existObj {
				var objNext models.PrecomputedRouteResourceObject
				objNext.ResourceID = schedule.ResourceID
				objNext.LocationID = schedule.LocationID
				objNext.Schedules = []models.Schedule{schedule}
				arrObj = append(arrObj, objNext)
			}
		}
		//fmt.Printf("arrObj: %+v\n", arrObj)
		for _, obj := range arrObj {
			var (
				locationModel models.Location
				resourceModel models.Resource
				precomputes   = make([]models.ResourcePrecomputeResponse, 0)
				response      models.PrecomputedRouteResourceResponse
			)
			// location
			resultFindLocation := db.Preload(
				"Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.Location{}.TableName(),
			).Joins(" JOIN addresses ON addresses.EntityID = locations.LocationID").
				Joins(" JOIN addresstypes  ON addresses.AddressTypeID = addresstypes.AddressTypeID").
				Where("addresstypes.IsLocation = 1 AND addresstypes.IsDepot = 1").
				Where(
					"LocationID = ?", obj.LocationID,
				).Where(
				"IFNULL(locations.IsDeleted, 0) <> 1 AND IFNULL(locations.IsArchived, 0) <> 1",
			).First(&locationModel)
			if resultFindLocation.RowsAffected > 0 {
				response.Depot.LocationName = locationModel.LocationName
				for _, address := range locationModel.Addresses {
					response.Depot.Address = address.NavigationAddress
				}
			}
			// resource
			response.Resource.ResourceID = obj.ResourceID
			resultFindResource := db.Where("ResourceID = ?", obj.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
			if resultFindResource.RowsAffected > 0 {
				response.Resource.ResourceName = resourceModel.ResourceName
				response.Resource.ResourceColor = resourceModel.ResourceColor
			}
			// precomputes
			for _, schedule := range obj.Schedules {
				var (
					jobModel models.Job
				)

				// job
				resultFindJob := db.Preload(
					"JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).Where(
					"JobID = ?", schedule.JobID,
				).Where(
					"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
				).First(&jobModel)
				if resultFindJob.RowsAffected > 0 {
					// businesspartner
					var (
						businessPartnerModel models.BusinessPartner
					)
					resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartnerModel)
					// @TODO precomputes response > if exist jobtask > add to array
					for _, task := range jobModel.JobTasks {

						if task.JobTaskID == schedule.JobTaskID {
							var precompute models.ResourcePrecomputeResponse
							precompute.JobNumber = jobModel.JobNumber
							if resultFindBusinessPartner.RowsAffected > 0 {
								precompute.CompanyName = businessPartnerModel.CompanyName
							}
							// jobtask type name
							var jobTaskEnum models.Enumerator
							resultFindJobTaskType := db.Where("FieldName = ? AND Status = ?", "JobType", task.JobType).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTaskEnum)
							if resultFindJobTaskType.RowsAffected > 0 {
								precompute.JobTaskJobTypeName = jobTaskEnum.Caption
							}
							// precompute
							var (
								precomputedModel models.PrecomputedRoute
							)
							resultFindPrecomputed := db.Where("TaskID = ?", task.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&precomputedModel)
							if resultFindPrecomputed.RowsAffected > 0 {
								precompute.Precompute = precomputedModel.PrecomputedRouteWeb
							}
							precompute.NavigationAddress = task.NavigationAddress
							precompute.TaskID = schedule.JobTaskID
							precomputes = append(precomputes, precompute)
						}
					}
				}
			}
			response.Precomputes = precomputes
			// map all
			responses = append(responses, response)
		}
	}
	if status != 200 {
		if validateMsgError != "" {
			msg = validateMsgError
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}
	data = responses
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetPrecomputedRouteByTaskID godoc
// @Summary Get PrecomputedRoute By Task D
// @Description Get PrecomputedRoute By Task ID
// @Tags PrecomputedRoute
// @Accept  json
// @Produce  json
// @Param id path int true "PrecomputedRoute ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /precomputedroute/{taskid} [get]
func GetPrecomputedRouteByTaskID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPrecomputedRouteByTaskID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.PrecomputedRoute
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("taskid")

	_, sSygic := libs.GetQueryParam("ForSygic", c)
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TaskID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		if !sSygic {
			responses := ConvertPrecomputedRouteToResponse(requestHeader, resModel)
			data = responses
		} else {
			// Convert PrecomputedRoute to Sygic format
			// testing data
			var (
				responses  models.PrecomputedRouteSygicResponse
				routeParts = make([]models.RouteParts, 0)
			)
			responses.Name = "Route-" + ID
			responses.Version = "1.1"

			var tomTomPoints []models.TomTomPoint
			json.Unmarshal([]byte(resModel.PrecomputedRoute), &tomTomPoints)
			var (
				roads  []models.Road
				points []models.Point
				road   models.Road
			)

			if len(tomTomPoints) > 1 {
				startLat := int(tomTomPoints[0].Latitude * 100000)
				startLon := int(tomTomPoints[0].Longitude * 100000)
				waypointFrom := &models.Waypoint{Lat: startLat, Lon: startLon, Type: "start"}
				finishLat := int(tomTomPoints[len(tomTomPoints)-1].Latitude * 100000)
				finishLon := int(tomTomPoints[len(tomTomPoints)-1].Longitude * 100000)
				waypointTo := &models.Waypoint{Lat: finishLat, Lon: finishLon, Type: "finish"}

				for _, ttpoint := range tomTomPoints {
					var (
						point models.Point
					)
					point.Lat = int(ttpoint.Latitude * 100000)
					point.Lon = int(ttpoint.Longitude * 100000)
					points = append(points, point)
				}
				var routePart models.RouteParts

				routePart.WaypointFrom = waypointFrom
				routePart.WaypointTo = *waypointTo

				road.ID = 1
				road.Points = points
				roads = append(roads, road)
				routePart.Roads = roads
				routeParts = append(routeParts, routePart)
			}

			responses.RouteParts = routeParts
			str, err := json.Marshal(responses)
			if err == nil {
				resModel.PrecomputedRoute = string(str)
				responses := ConvertPrecomputedRouteToResponse(requestHeader, resModel)
				data = responses
			}
		}

	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePrecomputedRoute godoc
// @Summary Create PrecomputedRoute
// @Description Create PrecomputedRoute
// @Tags PrecomputedRoute
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param PrecomputedRoute body models.PrecomputedRouteResponse true "Create PrecomputedRoute"
// @Success 200 {object} models.APIResponseData
// @Router /precomputedroute [post]
func CreatePrecomputedRoute(c *gin.Context) {
	apiName := "CreatePrecomputedRoute"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.PrecomputedRoute
	)
	obj.PassBodyJSONToModel(objectsJSON)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(obj)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		db.Where("TaskID = ?", obj.TaskID).Delete(&models.PrecomputedRoute{})
		resultCreate := db.Create(&obj)
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {
			totalUpdatedRecord++
			dataResponses := ConvertPrecomputedRouteToResponse(requestHeader, obj)
			data = dataResponses
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPrecomputedRouteToArrayResponse func
func ConvertArrayPrecomputedRouteToArrayResponse(requestHeader models.RequestHeader, items []models.PrecomputedRoute) []models.PrecomputedRouteResponse {
	responses := make([]models.PrecomputedRouteResponse, 0)
	for _, item := range items {
		response := ConvertPrecomputedRouteToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPrecomputedRouteToResponse func
func ConvertPrecomputedRouteToResponse(requestHeader models.RequestHeader, item models.PrecomputedRoute) models.PrecomputedRouteResponse {
	var (
		response models.PrecomputedRouteResponse
	)
	response.PrecomputedRouteID = item.PrecomputedRouteID
	response.TaskID = item.TaskID
	response.PrecomputedRoute = item.PrecomputedRoute
	response.PrecomputedRouteWeb = item.PrecomputedRouteWeb
	return response
}
