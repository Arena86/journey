package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/url"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetLocationPaymentMethodByLocationID godoc
// @Summary GetLocationPaymentMethodByLocationID
// @Description GetLocationPaymentMethodByLocationID
// @Tags PaymentMethod
// @Accept  json
// @Produce  json
// @Param locationid path int true "LocationID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /locationpaymentmethod/{locationid} [get]
func GetLocationPaymentMethodByLocationID(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocationPaymentMethodByLocationID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.LocationPaymentMethod
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	locationID, _ := strconv.Atoi(c.Param("locationid"))
	resultRow := db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&resModels)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayLocationPaymentMethodToArrayResponse(requestHeader, lang, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = responses
	libs.APIResponseData(response, c, status)
}

// CreateLocationPaymentMethodByLocationID godoc
// @Summary CreateLocationPaymentMethodByLocationID
// @Description CreateLocationPaymentMethodByLocationID
// @Tags PaymentMethod
// @Accept  json
// @Produce  json
// @Param locationid path int true "LocationID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param LocationPaymentMethod body []models.LocationPaymentMethodResponse true "Create LocationPaymentMethod"
// @Success 200 {object} models.APIResponseData
// @Router /locationpaymentmethod/{locationid} [post]
func CreateLocationPaymentMethodByLocationID(c *gin.Context) {
	defer libs.RecoverError(c, "CreateLocationPaymentMethodByLocationID")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.LocationPaymentMethod
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.LocationPaymentMethod, 0)
	locationID, _ := strconv.Atoi(c.Param("locationid"))
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	db.Where("LocationID = ?", locationID).Delete(&models.LocationPaymentMethod{})
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.LocationPaymentMethod
			)
			item.PassBodyJSONToModel(bp)
			item.LocationID = locationID
			item.CreatedBy = accountKey
			item.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
					isValid      = true
				)

				if item.HasURL {
					_, err := url.ParseRequestURI(item.URL)
					if err != nil {
						isValid = false
						errResponse := GetErrorResponseErrorMessage(k, err.Error())
						errorsResponse = append(errorsResponse, errResponse)
					} else {
						validStatus := libs.RequestURL(item.URL)
						if validStatus != 200 {
							isValid = false
							errResponse := GetErrorResponseValidate(lang, k, "api.page_not_found")
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
				if isValid {
					resultCreate := db.Create(&item)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, item)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.LocationPaymentMethod
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.LocationPaymentMethodID)
	}
	if len(arrID) > 0 {
		db.Where("LocationPaymentMethodID in (?)", arrID).Find(&items)
		data = ConvertArrayLocationPaymentMethodToArrayResponse(requestHeader, lang, items)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertArrayLocationPaymentMethodToArrayResponse func
func ConvertArrayLocationPaymentMethodToArrayResponse(requestHeader models.RequestHeader, lang string, items []models.LocationPaymentMethod) []models.LocationPaymentMethodResponse {
	responses := make([]models.LocationPaymentMethodResponse, 0)
	for _, item := range items {
		response := ConvertLocationPaymentMethodToResponse(requestHeader, lang, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertLocationPaymentMethodToResponse func
func ConvertLocationPaymentMethodToResponse(requestHeader models.RequestHeader, lang string, item models.LocationPaymentMethod) models.LocationPaymentMethodResponse {
	var (
		response models.LocationPaymentMethodResponse
	)
	response.LocationPaymentMethodID = item.LocationPaymentMethodID
	response.LocationID = item.LocationID
	response.PaymentMethod = item.PaymentMethod
	response.HasURL = item.HasURL
	response.URL = item.URL
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var enumPaymentMethod models.Enumerator
	resultFindEnumeratorPayment := db.Where("FieldName = ? AND Status = ?", "PaymentMethod", item.PaymentMethod).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&enumPaymentMethod)
	if resultFindEnumeratorPayment.RowsAffected > 0 {
		if enumPaymentMethod.TranslationKey != "" && enumPaymentMethod.TranslationKey != services.GetMessage(lang, enumPaymentMethod.TranslationKey) {
			response.PaymentMethodName = services.GetMessage(lang, enumPaymentMethod.TranslationKey)
		} else {
			response.PaymentMethodName = enumPaymentMethod.Caption
		}
	}
	return response
}
