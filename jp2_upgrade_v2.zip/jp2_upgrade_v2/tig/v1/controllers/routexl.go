package controllers

import (
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
)

// GetRouteXL func
func GetRouteXL(accountKey int) models.RouteXL {
	return libs.GetRouteXL(accountKey)
}
