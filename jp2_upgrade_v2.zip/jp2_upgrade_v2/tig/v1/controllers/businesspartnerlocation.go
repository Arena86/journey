package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	"jpapi/tig/v1/models"
)

// ConvertArrayBusinessPartnerLocationToArrayResponse func
func ConvertArrayBusinessPartnerLocationToArrayResponse(items []models.BusinessPartnerLocation, requestHeader models.RequestHeader) []models.BusinessPartnerLocationResponse {
	responses := make([]models.BusinessPartnerLocationResponse, 0)
	for _, item := range items {
		response := ConvertBusinessPartnerLocationToResponse(item, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertBusinessPartnerLocationToResponse func
func ConvertBusinessPartnerLocationToResponse(item models.BusinessPartnerLocation, requestHeader models.RequestHeader) models.BusinessPartnerLocationResponse {
	var (
		response      models.BusinessPartnerLocationResponse
		locationGroup models.LocationGroup
		locationName  models.Location
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.BusinessPartnerLocationID = item.BusinessPartnerLocationID
	response.BusinessPartnerID = item.BusinessPartnerID
	response.LocationGroupID = item.LocationGroupID
	db.Where("LocationGroupID = ?", item.LocationGroupID).First(&locationGroup)
	response.LocationGroupName = locationGroup.LocationGroupName
	response.LocationID = item.LocationID
	db.Where("LocationID = ?", item.LocationID).First(&locationName)
	response.LocationName = locationName.LocationName
	return response
}
