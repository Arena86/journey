package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetPermission godoc
// @Summary Get Permission
// @Description Get Permission
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /permission [get]
func GetPermission(c *gin.Context) {
	defer libs.RecoverError(c, "GetPermission")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Permission
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPermissionToArrayResponse(resModels, lang, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPermissionByUser godoc
// @Summary Get Permission By User
// @Description Get Permission By User
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /permission/getbyuser [get]
func GetPermissionByUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetPermissionByUser")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Permission
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	// Paging
	var bp = db
	var userModel models.User

	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	db.Where("AccountKey = ?", accountKey).First(&userModel)
	bp = bp.Where("SecurityGroupID = ?", userModel.SecurityGroupID)

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPermissionToArrayResponse(resModels, lang, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPermissionBySecurityGroupID godoc
// @Summary Get Permission By SecurityGroupID
// @Description Get Permission By SecurityGroupID
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /permission/securitygroupid/{id} [get]
func GetPermissionBySecurityGroupID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPermissionBySecurityGroupID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Permission
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	securityGroupID := c.Param("id")
	// Paging
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("SecurityGroupID = ?", securityGroupID)

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPermissionToArrayResponse(resModels, lang, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPermissionByUserID godoc
// @Summary Get Permission By UserID
// @Description Get Permission By UserID
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /permission/userid/{id} [get]
func GetPermissionByUserID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPermissionByUserID")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Permission
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	userID := c.Param("id")
	// Paging
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	var userModel models.User
	db.Where("UserID = ?", userID).First(&userModel)
	bp = bp.Where("SecurityGroupID = ?", userModel.SecurityGroupID)

	// Filter

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayPermissionToArrayResponse(resModels, lang, requestHeader)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetPermissionByID godoc
// @Summary Get Permission By ID
// @Description Get Permission  By ID
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param id path int true "Permission ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /permission/getbyid/{id} [get]
func GetPermissionByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetPermissionByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.Permission
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND PermissionID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertPermissionToResponse(resModel, lang, requestHeader)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreatePermission godoc
// @Summary Create Permission
// @Description Create Permission
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Permission body []models.PermissionResponse true "Create Permission"
// @Success 200 {object} models.APIResponseData
// @Router /permission [post]
func CreatePermission(c *gin.Context) {
	defer libs.RecoverError(c, "CreatePermission")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Permission
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Permission, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.Permission
			)
			item.PassBodyJSONToModel(bp)
			item.CreatedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				resultCreate := db.Create(&item)
				if resultCreate.Error != nil {
					if itemMsgError == "" {
						itemMsgError = resultCreate.Error.Error()
					} else {
						itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
					}
				} else {
					// @TODO add or update translation table
					ProcessTranslationForObject(requestHeader, models.Permission{}.TableName(), item.TranslationTypeID, accountKey, bp)
					totalUpdatedRecord++
					dataResponse = append(dataResponse, item)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Permission
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.PermissionID)
	}
	if len(arrID) > 0 {
		db.Where("PermissionID in (?)", arrID).Find(&items)
		data = ConvertArrayPermissionToArrayResponse(items, lang, requestHeader)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdatePermission godoc
// @Summary Update Permission
// @Description Update Permission
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Permission body []models.PermissionResponse true "Update Permission"
// @Success 200 {object} models.APIResponseData
// @Router /permission [put]
func UpdatePermission(c *gin.Context) {
	defer libs.RecoverError(c, "UpdatePermission")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Permission
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Permission, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.Permission
			)
			item.PassBodyJSONToModel(bp)
			resultFind := db.Where("PermissionID = ?", item.PermissionID).First(&item)

			// @TODO Not allow to edit permission of Administrator
			if resultFind.RowsAffected > 0 {
				var securityGroupAdminModel models.SecurityGroup
				db.Where("IsAdministrator = 1").First(&securityGroupAdminModel)
				if item.SecurityGroupID == securityGroupAdminModel.SecurityGroupID {
					errResponse := GetErrorResponseValidate(lang, k, "api.securitygroup_isadmin")
					errorsResponse = append(errorsResponse, errResponse)
					continue
				}
			}

			item.PassBodyJSONToModel(bp)
			item.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&item)
				} else {
					db.Create(&item)
				}
				// @TODO add or update translation table
				ProcessTranslationForObject(requestHeader, models.Permission{}.TableName(), item.TranslationTypeID, accountKey, bp)
				totalUpdatedRecord++
				dataResponse = append(dataResponse, item)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Permission
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.PermissionID)
	}
	if len(arrID) > 0 {
		db.Where("PermissionID in (?)", arrID).Find(&items)
		data = ConvertArrayPermissionToArrayResponse(items, lang, requestHeader)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeletePermission godoc
// @Summary Delete Permission
// @Description Delete Permission
// @Tags Permission
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Permission ID"
// @Success 200 {object} models.APIResponseData
// @Router /permission/{id} [delete]
func DeletePermission(c *gin.Context) {
	defer libs.RecoverError(c, "DeletePermission")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.Permission
		)
		resultFind := db.Where("PermissionID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				//@TODO delete translation table
				DeleteTranslationOnObject(requestHeader, models.Permission{}.TableName(), uModel.TranslationTypeID)
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayPermissionToArrayResponse func
func ConvertArrayPermissionToArrayResponse(items []models.Permission, lang string, requestHeader models.RequestHeader) []models.PermissionResponse {
	responses := make([]models.PermissionResponse, 0)
	for _, item := range items {
		response := ConvertPermissionToResponse(item, lang, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertPermissionToResponse func
func ConvertPermissionToResponse(item models.Permission, lang string, requestHeader models.RequestHeader) models.PermissionResponse {
	var (
		response models.PermissionResponse
	)
	response.PermissionID = item.PermissionID
	response.SecurityGroupID = item.SecurityGroupID
	if item.PermissionGroupTranslationKey != nil {
		perTranslationKey := *item.PermissionGroupTranslationKey
		if perTranslationKey != services.GetMessage(lang, perTranslationKey) {
			perTranslationKey = services.GetMessage(lang, perTranslationKey)
		} else {
			perTranslationKey = item.PermissionGroup
		}
		response.PermissionGroup = perTranslationKey
	} else {
		response.PermissionGroup = item.PermissionGroup
	}
	response.ReportID = item.ReportID
	response.PermissionGroupSort = item.PermissionGroupSort
	response.Area = item.Area
	response.CanAccess = item.CanAccess
	response.CanView = item.CanView
	response.CanCreate = item.CanCreate
	response.CanEdit = item.CanEdit
	response.CanDelete = item.CanDelete
	response.CanArchive = item.CanArchive
	response.CanPrint = item.CanPrint
	response.CanExport = item.CanExport
	response.TranslationTypeID = item.TranslationTypeID

	var (
		translationResponses []models.TranslationResponse
	)
	translationResponses = make([]models.TranslationResponse, 0)
	reportID := 0
	if item.ReportID != nil {
		reportID = *item.ReportID
	}

	if reportID > 0 {
		translationResponses = GetTranslationResponse(requestHeader, models.Report{}.TableName(), reportID)
		for _, v := range translationResponses {
			if v.Language == lang && v.Value != "" {
				response.AreaLabel = v.Value
			}
		}
	} else {
		translationResponses = GetTranslationResponse(requestHeader, models.Permission{}.TableName(), item.TranslationTypeID)
		for _, v := range translationResponses {
			if v.Language == lang && v.Value != "" {
				response.AreaLabel = v.Value
			}
		}
	}

	return response
}
