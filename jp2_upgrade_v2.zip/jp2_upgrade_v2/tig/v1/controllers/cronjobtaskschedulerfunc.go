package controllers

import (
	"sort"
	"strings"

	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"time"
)

// GetArrayConfigDays func
func GetArrayConfigDays() map[int]string {
	return map[int]string{
		0: "mon",
		1: "tue",
		2: "wed",
		3: "thu",
		4: "fri",
		5: "sat",
		6: "sun",
	}
}

// GetNextRunValueOnTaskScheduler func
func GetNextRunValueOnTaskScheduler(responseHeader models.RequestHeader, taskModel models.TaskScheduler) {
	var (
		dbInfo DatabaseInfo
	)
	dbInfo.DBName = responseHeader.DBName
	dbInfo.DBUsername = responseHeader.DBUser
	dbInfo.DBPassword = responseHeader.DBPassword
	dbInfo.DBHost = responseHeader.DBServer
	dbInfo.DBPort = responseHeader.DBPort
	task := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
	if task.Enabled {
		startTime := time.Now()
		processInfiniteField := ProcessInfiniteField(task, startTime)
		if processInfiniteField {
			if task.IsRepeat {
				switch strings.ToLower(task.Repeat) {
				case RepeatDaily:
					{
						FixNextRunValueByDay(startTime, dbInfo, taskModel)
					}
				case RepeatWeekly:
					{
						FixNextRunValueByWeek(startTime, dbInfo, taskModel)
					}
				case RepeatMonthly:
					{
						FixNextRunValueByMonth(startTime, dbInfo, taskModel)
					}
				}
			}
		}
	}
}

// FixNextRunValueByDay func
func FixNextRunValueByDay(startTime time.Time, dbInfo DatabaseInfo, taskModel models.TaskScheduler) {
	var (
		needFixed = false
		nextRun   time.Time
	)
	if taskModel.NextRun == nil {
		if taskModel.TaskStartDate != nil {
			nextRun = *taskModel.TaskStartDate
			needFixed = true
		}
	} else {
		nextRun = *taskModel.NextRun
		needFixed = true
	}
	if needFixed {
		needFixed = false
		sStartTime := startTime.Format(models.DateFormat) + " " + startTime.Format(models.TimeFormat)
		startTime, _ = time.Parse(models.DateTimeFormat, sStartTime)
		sNextRun := nextRun.Format(models.DateFormat)
		if taskModel.StartAtTime != nil {
			sNextRun = sNextRun + " " + string(*taskModel.StartAtTime)
			vNextRunTime, sNextRunTime := time.Parse(models.DateTimeFormat, sNextRun)
			if sNextRunTime == nil {
				//if vNextRunTime.Unix() < startTime.Unix() {
				nextRun, _ = time.Parse(models.DateFormat, vNextRunTime.Format(models.DateFormat))
				needFixed = true
				//}
			}
		}
	}
	if needFixed {
		repeatDay := 1
		if taskModel.RepeatEvery > 0 {
			repeatDay = taskModel.RepeatEvery
		}
		nextRunTime, _ := time.Parse(models.DateTimeFormat, nextRun.Format(models.DateFormat)+" "+string(*taskModel.StartAtTime))
		i := 0
		for {
			if nextRunTime.Unix() > startTime.Unix() {
				nextRun, _ = time.Parse(models.DateFormat, nextRunTime.Format(models.DateFormat))
				break
			}
			nextRunTime = nextRunTime.AddDate(0, 0, repeatDay)
			if i >= 31 {
				break
			}
			i++
		}
		db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
		sqlDB, err := db.DB()
		if err == nil {
			defer sqlDB.Close()
		}
		nextRun, _ = time.Parse(models.DateFormat, nextRun.Format(models.DateFormat))
		taskModel.NextRun = &nextRun
		db.Save(&taskModel)
	}
}

// FixNextRunValueByWeek func
func FixNextRunValueByWeek(startTime time.Time, dbInfo DatabaseInfo, taskModel models.TaskScheduler) {
	var (
		needFixed = false
		nextRun   time.Time
	)
	if taskModel.NextRun == nil {
		if taskModel.TaskStartDate != nil {
			nextRun = *taskModel.TaskStartDate
			needFixed = true
		}
	} else {
		nextRun = *taskModel.NextRun
		needFixed = true
	}
	repeatOn := ""
	if taskModel.RepeatOn != nil {
		repeatOn = *taskModel.RepeatOn
	}
	// change to not get timezone
	sStartTime := startTime.Format(models.DateFormat) + " " + startTime.Format(models.TimeFormat)
	startTime, _ = time.Parse(models.DateTimeFormat, sStartTime)
	if needFixed {
		needFixed = false
		sNextRun := nextRun.Format(models.DateFormat)
		if taskModel.StartAtTime != nil {
			sNextRun = sNextRun + " " + string(*taskModel.StartAtTime)
			vNextRunTime, sNextRunTime := time.Parse(models.DateTimeFormat, sNextRun)
			if sNextRunTime == nil {
				//if vNextRunTime.Unix() < startTime.Unix() {
				nextRun, _ = time.Parse(models.DateFormat, vNextRunTime.Format(models.DateFormat))
				needFixed = true
				//}
			}
		}
	}
	if needFixed {
		needFixed = false
		weekDayRepeatOn := strings.ToLower(repeatOn)
		arrDayRepeat := ConvertStringToArrayString(weekDayRepeatOn)
		arrDayRepeat = UniqueDayRepeatInArray(arrDayRepeat)
		arrDayRepeat = SortArrayDayRepeat(arrDayRepeat)
		if len(arrDayRepeat) > 0 {
			needFixed = true
			repeatOn = strings.Join(arrDayRepeat, ",")
		}
	}
	if needFixed {
		nextRunTime, _ := time.Parse(models.DateTimeFormat, nextRun.Format(models.DateFormat)+" "+string(*taskModel.StartAtTime))
		i := 0
		for {
			if nextRunTime.Unix() >= startTime.Unix() {
				weekDay := nextRunTime.Weekday().String()
				shortWeekDay := GetShortWeekDay(weekDay)
				hasProcessWeekly := HasProcessWeekly(shortWeekDay, repeatOn)
				if hasProcessWeekly {
					nextRun, _ = time.Parse(models.DateFormat, nextRunTime.Format(models.DateFormat))
					break
				}
			}
			nextRunTime = nextRunTime.AddDate(0, 0, 1)
			if i >= 31 {
				break
			}
			i++
		}
		db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
		sqlDB, err := db.DB()
		if err == nil {
			defer sqlDB.Close()
		}
		nextRun, _ = time.Parse(models.DateFormat, nextRun.Format(models.DateFormat))
		taskModel.NextRun = &nextRun
		db.Save(&taskModel)
	}
}

// FixNextRunValueByMonth func
func FixNextRunValueByMonth(startTime time.Time, dbInfo DatabaseInfo, taskModel models.TaskScheduler) {
	var (
		needFixed = false
		nextRun   time.Time
	)
	if taskModel.NextRun == nil {
		if taskModel.TaskStartDate != nil {
			nextRun = *taskModel.TaskStartDate
			needFixed = true
		}
	} else {
		nextRun = *taskModel.NextRun
		needFixed = true
	}
	if needFixed {
		needFixed = false
		// change to not get timezone
		sStartTime := startTime.Format(models.DateFormat) + " " + startTime.Format(models.TimeFormat)
		startTime, _ = time.Parse(models.DateTimeFormat, sStartTime)
		sNextRun := nextRun.Format(models.DateFormat)
		if taskModel.StartAtTime != nil {
			sNextRun = sNextRun + " " + string(*taskModel.StartAtTime)
			vNextRunTime, sNextRunTime := time.Parse(models.DateTimeFormat, sNextRun)
			if sNextRunTime == nil {
				//if vNextRunTime.Unix() < startTime.Unix() {
				nextRun, _ = time.Parse(models.DateFormat, vNextRunTime.Format(models.DateFormat))
				needFixed = true
				//}
			}
		}
	}
	if needFixed {
		nextRunTime, _ := time.Parse(models.DateTimeFormat, nextRun.Format(models.DateFormat)+" "+string(*taskModel.StartAtTime))
		i := 0
		for {
			if nextRunTime.Unix() >= startTime.Unix() {
				dayInMonth := nextRunTime.Day()
				hasProcessMonthly := HasProcessMonthly(dayInMonth, taskModel.RepeatOnDayMonth)
				if hasProcessMonthly {
					nextRun, _ = time.Parse(models.DateFormat, nextRunTime.Format(models.DateFormat))
					break
				}
			}
			nextRunTime = nextRunTime.AddDate(0, 0, 1)
			if i >= 365 {
				break
			}
			i++
		}
		db := jpdatabase.CheckDBConnection(dbInfo.DBName, dbInfo.DBUsername, dbInfo.DBPassword, dbInfo.DBHost, dbInfo.DBPort)
		sqlDB, err := db.DB()
		if err == nil {
			defer sqlDB.Close()
		}
		nextRun, _ = time.Parse(models.DateFormat, nextRun.Format(models.DateFormat))
		taskModel.NextRun = &nextRun
		db.Save(&taskModel)
	}
}

// CheckValidRunCronJobForWeekly func
func CheckValidRunCronJobForWeekly(currentRun string, startTime time.Time, startAtTime string, repeatOn string) bool {
	if CheckDateFormatOfString(currentRun) {
		if CheckValidRunCronJobAtDateAndTime(startTime, currentRun, startAtTime) {
			weekDay := startTime.Weekday().String()
			shortWeekDay := GetShortWeekDay(weekDay)
			hasProcessWeekly := HasProcessWeekly(shortWeekDay, repeatOn)
			if hasProcessWeekly {
				return true
			}
		}
	}
	return false
}

// GetNextWeekDay func
func GetNextWeekDay(key string, arr []string) string {
	var (
		nextWeekDay     string
		currentPosition int
	)
	currentPosition = -1
	for i, v := range arr {
		if v == key {
			currentPosition = i
		}
	}
	if currentPosition >= 0 {
		currentPosition = currentPosition + 1
	}
	if currentPosition <= len(arr)-1 {
		nextWeekDay = arr[currentPosition]
	}
	return nextWeekDay
}

// GetPositionDay func
func GetPositionDay(day string) int {
	arrConfigDays := GetArrayConfigDays()
	for k, v := range arrConfigDays {
		if v == day {
			return k
		}
	}
	return 0
}

// GetShortWeekDay func
func GetShortWeekDay(weekDay string) string {
	return strings.ToLower(weekDay[0:3])
}

// HasProcessMonthly func
func HasProcessMonthly(currentMonth int, monthInTask int) bool {
	return currentMonth == monthInTask
}

// HasProcessWeekly func
func HasProcessWeekly(shortWeekDay, weekDayRepeatOn string) bool {
	weekDayRepeatOn = strings.ToLower(weekDayRepeatOn)
	arrDayRepeat := ConvertStringToArrayString(weekDayRepeatOn)
	return libs.InArrayString(strings.ToLower(shortWeekDay), arrDayRepeat)
}

// ConvertStringToArrayString func
func ConvertStringToArrayString(str string) []string {
	arr := make([]string, 0)
	str = strings.TrimSpace(str)
	listStr := strings.Split(str, ",")
	for i := range listStr {
		key := (strings.TrimSpace(listStr[i]))
		arr = append(arr, key)
	}
	return arr
}

// ProcessInfiniteField func
func ProcessInfiniteField(task models.TaskSchedulerData, startTime time.Time) bool {
	resState := false
	if task.Infinite {
		resState = true
	} else {
		// @TODO no check hours
		startTime, _ = time.Parse(models.DateFormat, startTime.Format(models.DateFormat))
		vTaskStartDate, sTaskStartDate := time.Parse(models.DateFormat, task.TaskStartDate)
		vTaskEndDate, sTaskEndDate := time.Parse(models.DateFormat, task.TaskEndDate)
		if sTaskStartDate == nil && sTaskEndDate == nil {
			if (startTime.Unix() >= vTaskStartDate.Unix()) && (startTime.Unix() <= vTaskEndDate.Unix()) {
				resState = true
			}
		}
	}
	return resState
}

// CheckDateFormatOfString func
func CheckDateFormatOfString(str string) bool {
	if str == "" {
		return false
	}
	_, sStr := time.Parse(models.DateFormat, str)
	if sStr == nil {
		return true
	}
	return false
}

// CheckValidRunCronJobAtDateAndTime func
func CheckValidRunCronJobAtDateAndTime(startTime time.Time, dateRun string, timeRun string) bool {
	if dateRun == startTime.Format(models.DateFormat) {
		if timeRun == startTime.Format(models.TimeFormat) {
			return true
		}
	}
	return false
}

// GetNextRunValueByDay func
func GetNextRunValueByDay(currentRun string, repeatDay int) string {
	var (
		nextRun string
	)
	if CheckDateFormatOfString(currentRun) {
		vCurrentRunTime, sCurrentRunTime := time.Parse(models.DateFormat, currentRun)
		if sCurrentRunTime == nil {
			nextRunTime := vCurrentRunTime.AddDate(0, 0, repeatDay)
			nextRun = nextRunTime.Format(models.DateFormat)
		}
	}
	return nextRun
}

// GetNextRunValueByWeek func
func GetNextRunValueByWeek(currentRun string, repeatEvery int, repeatOn string) string {
	var (
		nextRun string
	)
	weekDayRepeatOn := strings.ToLower(repeatOn)
	arrDayRepeat := ConvertStringToArrayString(weekDayRepeatOn)
	arrDayRepeat = UniqueDayRepeatInArray(arrDayRepeat)
	arrDayRepeat = SortArrayDayRepeat(arrDayRepeat)
	vCurrentRunTime, sCurrentRunTime := time.Parse(models.DateFormat, currentRun)
	if sCurrentRunTime == nil {
		weekDay := vCurrentRunTime.Weekday().String()
		shortWeekDay := GetShortWeekDay(weekDay)
		if libs.InArrayString(shortWeekDay, arrDayRepeat) {
			isLast := CheckLastItemInArray(shortWeekDay, arrDayRepeat)
			if !isLast {
				nextWeekDay := GetNextWeekDay(shortWeekDay, arrDayRepeat)
				positionCurrentWeekDay := GetPositionDay(shortWeekDay)
				positionNextWeekDay := GetPositionDay(nextWeekDay)
				countDayToNext := positionNextWeekDay - positionCurrentWeekDay
				nextRun = vCurrentRunTime.AddDate(0, 0, countDayToNext).Format(models.DateFormat)
			} else {
				nextWeekDay := arrDayRepeat[0]
				positionCurrentWeekDay := GetPositionDay(shortWeekDay)
				positionNextWeekDay := GetPositionDay(nextWeekDay)
				countDayToNext := (6 - positionCurrentWeekDay) + (positionNextWeekDay + 1)
				vCurrentRunTime = vCurrentRunTime.AddDate(0, 0, countDayToNext)
				if repeatEvery > 0 {
					vCurrentRunTime = vCurrentRunTime.AddDate(0, 0, ((repeatEvery - 1) * 7))
				}
				nextRun = vCurrentRunTime.Format(models.DateFormat)
			}
		}
	}
	return nextRun
}

// GetNextRunValueByMonth func
func GetNextRunValueByMonth(currentRun string, repeatMonth int) string {
	var (
		nextRun string
	)
	if CheckDateFormatOfString(currentRun) {
		vCurrentRunTime, sCurrentRunTime := time.Parse(models.DateFormat, currentRun)
		if sCurrentRunTime == nil {
			nextRunTime := vCurrentRunTime.AddDate(0, repeatMonth, 0)
			nextRun = nextRunTime.Format(models.DateFormat)
		}
	}
	return nextRun
}

// CheckValidDay func
func CheckValidDay(key string, arrDays map[int]string) bool {
	hasDay := false
	if arrDays != nil {
		for _, v := range arrDays {
			if strings.ToLower(strings.TrimSpace(v)) == strings.ToLower(strings.TrimSpace(key)) {
				hasDay = true
				break
			}
		}
	}
	return hasDay
}

// UniqueDayRepeatInArray func
func UniqueDayRepeatInArray(arrDay []string) []string {
	keys := make(map[string]bool)
	list := []string{}
	for _, entry := range arrDay {
		if _, value := keys[entry]; !value {
			keys[entry] = true
			list = append(list, entry)
		}
	}
	return list
}

// SortArrayDayRepeat func
func SortArrayDayRepeat(arr []string) []string {
	arrConfigDays := GetArrayConfigDays()
	resArr := make([]string, 0)
	var keys []int
	for _, shortWeekDay := range arr {
		if CheckValidDay(shortWeekDay, arrConfigDays) {
			positionDay := GetPositionDay(shortWeekDay)
			keys = append(keys, positionDay)
		}
	}
	sort.Ints(keys)
	for _, k := range keys {
		val, ok := arrConfigDays[k]
		if ok {
			resArr = append(resArr, val)
		}
	}
	return resArr
}

// CheckLastItemInArray func
func CheckLastItemInArray(key string, arr []string) bool {
	if key == arr[len(arr)-1] {
		return true
	}
	return false
}

// ConvertDBTaskSchedulerToTaskSchedulerData func
func ConvertDBTaskSchedulerToTaskSchedulerData(dBModel models.TaskScheduler) models.TaskSchedulerData {
	var (
		resModel models.TaskSchedulerData
	)
	resModel.TaskID = dBModel.TaskID
	if dBModel.Name != nil {
		resModel.Name = *dBModel.Name
	}
	if dBModel.Description != nil {
		resModel.Description = *dBModel.Description
	}
	if dBModel.TaskStartDate != nil {
		taskStartDate := *dBModel.TaskStartDate
		resModel.TaskStartDate = taskStartDate.Format(models.DateFormat)
	}
	if dBModel.TaskEndDate != nil {
		taskEndDate := *dBModel.TaskEndDate
		resModel.TaskEndDate = taskEndDate.Format(models.DateFormat)
	}
	resModel.Infinite = dBModel.Infinite
	if dBModel.Type != nil {
		resModel.Type = *dBModel.Type
	}
	if dBModel.Operation != nil {
		resModel.Operation = *dBModel.Operation
	}
	resModel.IsRepeat = dBModel.IsRepeat
	resModel.RunAfter = dBModel.RunAfter
	resModel.Enabled = dBModel.Enabled
	if dBModel.NextRun != nil {
		nextRun := *dBModel.NextRun
		resModel.NextRun = nextRun.Format(models.DateFormat)
	}
	if dBModel.FromDate != nil {
		fromDate := *dBModel.FromDate
		resModel.FromDate = fromDate.Format(models.DateFormat)
	}
	if dBModel.ToDate != nil {
		toDate := *dBModel.ToDate
		resModel.ToDate = toDate.Format(models.DateFormat)
	}
	if dBModel.StartAtTime != nil {
		startAtTime := *dBModel.StartAtTime
		resModel.StartAtTime = string(startAtTime)
	}
	if dBModel.Repeat != nil {
		resModel.Repeat = *dBModel.Repeat
	}
	resModel.RepeatEvery = dBModel.RepeatEvery
	resModel.PreviousDay = dBModel.PreviousDay
	if dBModel.RepeatOn != nil {
		resModel.RepeatOn = *dBModel.RepeatOn
	}
	resModel.RepeatOnDayMonth = dBModel.RepeatOnDayMonth
	if dBModel.TaskExecuted != nil {
		taskExecuted := *dBModel.TaskExecuted
		resModel.TaskExecuted = taskExecuted.Format(models.FullTimeFormat)
	}
	if dBModel.TaskEnded != nil {
		taskEnded := *dBModel.TaskEnded
		resModel.TaskEnded = taskEnded.Format(models.FullTimeFormat)
	}
	resModel.IsCompleted = dBModel.IsCompleted
	if dBModel.TaskErrorMessage != nil {
		resModel.TaskErrorMessage = *dBModel.TaskErrorMessage
	}
	return resModel
}

// GetFromDateToDateFromTaskScheduler func
func GetFromDateToDateFromTaskScheduler(taskModel models.TaskScheduler) (string, string) {
	var (
		fromDate, toDate string
	)
	if taskModel.IsRepeat {
		if taskModel.NextRun != nil {
			vFromDate := *taskModel.NextRun
			vFromDate = vFromDate.AddDate(0, 0, (-taskModel.PreviousDay))
			// Batche from =(next run - previous day)
			vFromDate = vFromDate.UTC()
			fromDate = vFromDate.Format(models.FullTimeFormat)
			if taskModel.PreviousDay == 0 {
				vToDate := *taskModel.NextRun
				vToDate = vToDate.UTC()
				toDate = vToDate.Format(models.FullTimeFormat)
			} else {
				vToDate := *taskModel.NextRun
				vToDate = vToDate.AddDate(0, 0, (-1))
				// Batch to= (next run - previous day)  + previous days
				vToDate = vToDate.UTC()
				toDate = vToDate.Format(models.FullTimeFormat)
			}
		}
	} else {
		if taskModel.FromDate != nil {
			vFromDate := *taskModel.FromDate
			vFromDate = vFromDate.UTC()
			fromDate = vFromDate.Format(models.FullTimeFormat)
		}
		if taskModel.ToDate != nil {
			vToDate := *taskModel.ToDate
			vToDate = vToDate.UTC()
			toDate = vToDate.Format(models.FullTimeFormat)
		}
	}
	return fromDate, toDate
}
