package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetFormFlowOnlyMaster godoc
// @Summary Get FormFlow
// @Description Get FormFlow
// @Tags FormFlow
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formflow [get]
func GetFormFlowOnlyMaster(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormFlow")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.FormFlow
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"FormFlowName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayFormFlowToArrayResponseOnlyMaster(resModels)

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetFormFlowByID godoc
// @Summary Get FormFlow By ID
// @Description Get FormFlow By ID
// @Tags FormFlow
// @Accept  json
// @Produce  json
// @Param id path int true "Item Group ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formflow/{id} [get]
func GetFormFlowByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormFlowByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.FormFlow
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"FormConditions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FormFlowID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertFormFlowToResponse(requestHeader, resModel)

		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateFormFlow godoc
// @Summary Create Item Group
// @Description Create Item Group
// @Tags FormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormFlow body models.FormFlowResponse true "Create Item Group"
// @Success 200 {object} models.APIResponseData
// @Router /formflow [post]
func CreateFormFlow(c *gin.Context) {
	apiName := "CreateFormFlow"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       models.FormFlow
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	var (
		obj models.FormFlow
	)
	obj.PassBodyJSONToModel(objectsJSON)
	if obj.FormFlowName == "" {
		errResponse := GetErrorResponseValidate(lang, 0, "api.formflowname_required")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		resultFindFormFlow := db.Where("FormFlowName = ? AND IsDeleted = 0", obj.FormFlowName).First(&models.FormFlow{})
		if resultFindFormFlow.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.formflowname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			obj.CreatedBy = accountKey
			// @TODO validate
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(obj)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				for i := range obj.FormConditions {
					obj.FormConditions[i].CreatedBy = accountKey
				}
				resultCreate := db.Create(&obj)
				if resultCreate.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
				} else {
					totalUpdatedRecord++
					dataResponse = obj

					var (
						objs models.FormFlow
					)
					db.Preload(
						"FormConditions",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("FormFlowID in (?)", dataResponse.FormFlowID).First(&objs)
					dataResponses := ConvertFormFlowToResponse(requestHeader, objs)
					data = dataResponses
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateFormFlow godoc
// @Summary Update FormFlow
// @Description Update FormFlow
// @Tags FormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param FormFlow body []models.FormFlow true "Update FormFlow"
// @Success 200 {object} models.APIResponseData
// @Router /formflow [put]
func UpdateFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.FormFlow
	)
	resultFind := db.Preload(
		"FormConditions",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("FormFlowID = ?", id).First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		if resModel.FormFlowName == "" {
			errResponse := GetErrorResponseValidate(lang, 0, "api.formflowname_required")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resultFindFormFlow := db.Where("FormFlowName = ? AND IsDeleted = 0 AND FormFlowID <> ?", resModel.FormFlowName, resModel.FormFlowID).First(&models.FormFlow{})
			if resultFindFormFlow.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.formflowname_exist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(resModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(0, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					timeNow := time.Now()
					for i := range resModel.FormConditions {
						if resModel.FormConditions[i].CreatedBy <= 0 {
							resModel.FormConditions[i].CreatedBy = accountKey
							resModel.FormConditions[i].CreatedDate = &timeNow
						}
						resModel.FormConditions[i].ModifiedBy = accountKey
						resModel.FormConditions[i].ModifiedDate = &timeNow
					}
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						var (
							arrSkipID []int
						)
						for _, flowCondition := range resModel.FormConditions {
							arrSkipID = append(arrSkipID, flowCondition.FormConditionID)
						}
						if len(arrSkipID) > 0 {
							//db.Where("FlowID = ? AND FormConditionID not in (?)", resModel.FormFlowID, arrSkipID).Delete(&models.FlowCondition{})
							db.Where("FlowID = ? AND FormConditionID not in (?)", resModel.FormFlowID, arrSkipID).Model(&models.FormCondition{}).Updates(models.FormCondition{IsDeleted: true, ModifiedBy: accountKey})
						} else {
							//db.Where("FlowID = ?", resModel.FormFlowID).Delete(&models.FlowCondition{})
							db.Where("FlowID = ?", resModel.FormFlowID).Model(&models.FormCondition{}).Updates(models.FormCondition{IsDeleted: true, ModifiedBy: accountKey})
						}
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
					// reload data
					responses := ConvertFormFlowToResponse(requestHeader, resModel)
					data = responses
				}
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)

}

// DeleteFormFlow godoc
// @Summary Delete Item Group
// @Description Delete Item Group
// @Tags FormFlow
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Item Group ID"
// @Success 200 {object} models.APIResponseData
// @Router /formflow/{id} [delete]
func DeleteFormFlow(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteFormFlow")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.FormFlow
		)
		resultFind := db.Where("FormFlowID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// delete details
				db.Where("FlowID = ?", resModel.FormFlowID).Model(&models.DraftFormCondition{}).Updates(models.DraftFormCondition{IsDeleted: true, ModifiedBy: accountKey})
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayFormFlowToArrayResponseOnlyMaster func
func ConvertArrayFormFlowToArrayResponseOnlyMaster(items []models.FormFlow) []models.FormFlowResponseMaster {
	responses := make([]models.FormFlowResponseMaster, 0)
	for _, item := range items {
		response := ConvertFormFlowToResponseOnlyMaster(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertFormFlowToResponseOnlyMaster func
func ConvertFormFlowToResponseOnlyMaster(item models.FormFlow) models.FormFlowResponseMaster {
	var (
		response models.FormFlowResponseMaster
	)
	response.FormFlowID = item.FormFlowID
	response.FormFlowName = item.FormFlowName
	return response
}

// ConvertArrayFormFlowToArrayResponse func
func ConvertArrayFormFlowToArrayResponse(requestHeader models.RequestHeader, items []models.FormFlow) []models.FormFlowResponse {
	responses := make([]models.FormFlowResponse, 0)
	for _, item := range items {
		response := ConvertFormFlowToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertFormFlowToResponse func
func ConvertFormFlowToResponse(requestHeader models.RequestHeader, item models.FormFlow) models.FormFlowResponse {
	var (
		response models.FormFlowResponse
		//dataField models.DataFieldResponse
		//resModel  models.FormUDT
	)
	response.FormFlowID = item.FormFlowID
	response.FormFlowName = item.FormFlowName
	response.FormFlow = item.FormFlow
	response.Navigation = item.Navigation
	response.AdvancedForms = item.AdvancedForms
	response.SubFormFlows = item.SubFormFlows
	response.LastPublishedDate = item.LastPublishedDate
	drafs := make([]models.FormConditionResponse, 0)
	for _, d := range item.FormConditions {
		var draft models.FormConditionResponse
		draft.FormConditionID = d.FormConditionID
		draft.ConditionID = d.ConditionID
		draft.FormID = d.FormID
		draft.FormFlowID = d.FormFlowID
		draft.Operator = d.Operator
		draft.DataField = d.DataField
		draft.ConditionCode = d.ConditionCode
		draft.ConditionValue = d.ConditionValue
		draft.ConditionGroup = d.ConditionGroup
		drafs = append(drafs, draft)
	}
	response.FormConditions = drafs
	return response
}
