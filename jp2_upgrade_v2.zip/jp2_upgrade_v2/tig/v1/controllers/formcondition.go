package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetFormConditionByConditionID godoc
// @Summary Get Get Form Condition By Condition ID
// @Description Get Get Form Condition By Condition ID
// @Tags FormCondition
// @Accept  json
// @Produce  json
// @Param id path int true "Condition ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /formcondition/{conditionid} [get]
func GetFormConditionByConditionID(c *gin.Context) {
	defer libs.RecoverError(c, "GetFormConditionByConditionID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      []models.FormCondition
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("conditionid")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ConditionID = ?", ID).Find(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertFormConditionToArrayResponse(requestHeader, resModel)

		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CheckControlInFormCondition godoc
// @Summary Check Control in Form Condition
// @Description Check Control in Form Condition
// @Tags FormCondition
// @Accept  json
// @Produce  json
// @Param id path int true "Condition ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /checkcontrolinformcondition/{controlid} [get]
func CheckControlInFormCondition(c *gin.Context) {
	defer libs.RecoverError(c, "CheckControlInFormCondition")
	var (
		status           = libs.GetStatusSuccess()
		resModel         models.DraftFormCondition
		resFormFlowModel models.DraftFormFlow
		requestHeader    models.RequestHeader
		response         models.APIResponseData
		msg, data        interface{}
		responsesData    gin.H
		inFlow           = false
		formConditionID  = 0
		formFlowName     = ""
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("controlid")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ControlID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		inFlow = true
		formConditionID = resModel.DraftFormConditionID
		resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DraftFormFlowID = ?", resModel.FormFlowID).First(&resFormFlowModel)
		if resultRow.RowsAffected > 0 {
			formFlowName = resFormFlowModel.DraftFormFlowName
		}
	}
	msg = services.GetMessage(lang, "api.success")
	resData := map[string]interface{}{"InFormCondition": inFlow, "FormCondition": formConditionID, "FormFlowName": formFlowName}
	data = resData

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// ConvertFormConditionToArrayResponse func
func ConvertFormConditionToArrayResponse(requestHeader models.RequestHeader, item []models.FormCondition) []models.FormConditionResponse {
	var (
		response []models.FormConditionResponse
		//dataField models.DataFieldResponse
		//resModel  models.FormUDT
	)
	for _, d := range item {
		var form models.FormConditionResponse
		form.FormConditionID = d.FormConditionID
		form.ConditionID = d.ConditionID
		form.FormID = d.FormID
		form.FormFlowID = d.FormFlowID
		form.Operator = d.Operator

		/* resultRow := db.Preload("FormUDFs", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DataField = '"+d.DataField+"'").
			Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DraftDynamicFormID = ?", d.FormID).First(&resModel)
		if resultRow.RowsAffected > 0 {
			dataField.DataType = resModel.FormUDFs[0].DataType
		}
		dataField.Name = d.DataField
		dataField.Value = ""
		form.DataField = dataField */

		form.DataField = d.DataField
		form.ConditionCode = d.ConditionCode
		form.ConditionValue = d.ConditionValue
		form.ConditionGroup = d.ConditionGroup
		response = append(response, form)
	}
	return response
}
