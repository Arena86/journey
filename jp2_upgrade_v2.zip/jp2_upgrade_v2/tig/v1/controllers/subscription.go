package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
)

// GetSubscription godoc
// @Summary GetSubscription
// @Description GetSubscription
// @Tags Subscription
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /subscriptions [get]
func GetSubscription(c *gin.Context) {
	defer libs.RecoverError(c, "GetSubscription")
	var (
		status    = libs.GetStatusSuccess()
		response  models.APIResponseData
		msg, data interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	URL := os.Getenv("SERVER_REE") + "/" + "subscription"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data = reeResponse["data"]
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateSubscription godoc
// @Summary UpdateSubscription
// @Description UpdateSubscription
// @Tags Subscription
// @Accept json
// @Produce json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param SubscriptionJSON body models.SubscriptionJSON true "Update Subscription"
// @Success 200 {object} models.APIResponseData
// @Router /subscriptions [post]
func UpdateSubscription(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateSubscription")
	var (
		status         = libs.GetStatusSuccess()
		response       models.APIResponseData
		msg, data      interface{}
		errorsResponse []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// @TODO need to get from config
	chargebeeInvoiceImmediately := false
	var subscriptionJSON = make(map[string]interface{})
	json.NewDecoder(c.Request.Body).Decode(&subscriptionJSON)
	companyID := c.Request.Header.Get("companyid")
	//subscriptionJSON.CompanyID = companyID
	subscriptionJSON["InvoiceImmediately"] = chargebeeInvoiceImmediately
	URL := os.Getenv("SERVER_REE") + "/" + "updatesubscription"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	headers["CompanyID"] = companyID
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "POST", URL, subscriptionJSON, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
	} else {
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		vReeResponse, sReeResponse := reeResponse["data"]
		if sReeResponse {
			reeResponseDataJSON, errReeResponseDataJSON := json.Marshal(vReeResponse)
			if errReeResponseDataJSON == nil {
				msg = services.GetMessage(lang, "api.success")
				var response map[string]interface{}
				json.Unmarshal(reeResponseDataJSON, &response)
				data = response
				var license models.LicenseProduct
				json.Unmarshal(reeResponseDataJSON, &license)
				fmt.Printf("license: %+v\n", license)
				// update license to memory, file
				libs.UpdateLicenseInfo(license)

				if response["IsXeroIntegration"].(bool) { // @TODO - Nedd to test & map Integration Name
					var (
						requestHeader models.RequestHeader
					)
					statusCheckHeader, _, requestHeader := libs.CheckHeaderInAPI(c)
					if statusCheckHeader == 200 {
						db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
						db.Where("Name = ?", "Xero").Model(&models.Integration{}).Updates(models.Integration{IsLicensed: true, ModifiedBy: accountKey})
					}
				}
			} else {
				status = 500
				msg = errReeResponseDataJSON.Error()
			}
		} else {
			status = 500
			msg = services.GetMessage(lang, "api.license_data_invalid")
		}
	}

	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetSubscriptionByCompany godoc
// @Summary GetSubscriptionByCompany
// @Description GetSubscriptionByCompany
// @Tags Subscription
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /subscription [get]
func GetSubscriptionByCompany(c *gin.Context) {
	defer libs.RecoverError(c, "GetSubscriptionByCompany")
	var (
		status    = libs.GetStatusSuccess()
		response  models.APIResponseData
		msg, data interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	companyID := c.Request.Header.Get("companyid")
	URL := os.Getenv("SERVER_REE") + "/" + "getsubscriptionbycompany"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	headers["CompanyID"] = companyID
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data = reeResponse["data"]
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// LicenseVerification godoc
// @Summary LicenseVerification
// @Description LicenseVerification
// @Tags Subscription
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /licenseverification [get]
func LicenseVerification(c *gin.Context) {
	defer libs.RecoverError(c, "LicenseVerification")
	var (
		status       = libs.GetStatusSuccess()
		response     models.APIResponseData
		msg, data    interface{}
		responseData models.LicenseVerificationJSON
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	companyID := c.Request.Header.Get("companyid")
	URL := os.Getenv("SERVER_REE") + "/" + "getsubscriptionbycompany"
	headers := make(map[string]interface{})
	headers["AccountKey"] = strconv.Itoa(accountKey)
	headers["CompanyID"] = companyID
	statusRee, msgRee, resRee := libs.RequestAPIRee(lang, "GET", URL, nil, nil, headers)
	if statusRee != 200 {
		status = statusRee
		msg = msgRee
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		msg = services.GetMessage(lang, "api.success")
		var reeResponse map[string]interface{}
		json.Unmarshal(resRee, &reeResponse)
		data = reeResponse["data"]
		byteData, _ := json.Marshal(data)
		json.Unmarshal(byteData, &responseData)
		data = responseData
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
