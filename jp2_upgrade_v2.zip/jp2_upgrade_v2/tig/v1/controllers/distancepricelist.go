package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetDistancePriceListOnlyMaster godoc
// @Summary Get Distance Price List
// @Description Get Distance Price List
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist [get]
func GetDistancePriceListOnlyMaster(c *gin.Context) {
	defer libs.RecoverError(c, "GetDistancePriceListOnlyMaster")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.DistancePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("DistancePriceListDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"DistancePriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.DistancePriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDistancePriceListToArrayResponseOnlyMaster(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetDistancePriceListWithDetails godoc
// @Summary Get Distance Price List
// @Description Get Distance Price List
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist/details [get]
func GetDistancePriceListWithDetails(c *gin.Context) {
	defer libs.RecoverError(c, "GetDistancePriceListWithDetails")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.DistancePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("DistancePriceListDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1  AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"DistancePriceListName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.DistancePriceList{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayDistancePriceListToArrayResponse(resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetDistancePriceListByID godoc
// @Summary Get Distance Price List By ID
// @Description Get Distance Price List By ID
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param id path int true "Distance Price List ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist/id/{id} [get]
func GetDistancePriceListByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetDistancePriceListByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.DistancePriceList
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"DistancePriceListDetails",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND DistancePriceListID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertDistancePriceListToResponse(resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateDistancePriceList godoc
// @Summary Create Distance Price List
// @Description Create Distance Price List
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DistancePriceList body models.DistancePriceListResponse true "Create Distance Price List"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist [post]
func CreateDistancePriceList(c *gin.Context) {
	apiName := "CreateDistancePriceList"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var bp map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &bp)
	var (
		obj models.DistancePriceList
	)
	obj.PassBodyJSONToModel(bp)
	obj.CreatedBy = accountKey
	obj.ModifiedBy = accountKey
	// @TODO validate
	resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DistancePriceListName = ?", obj.DistancePriceListName).First(&models.DistancePriceList{})
	if resultCheckExist.RowsAffected > 0 {
		errResponse := GetErrorResponseValidate(lang, 0, "api.distancepricelistname_exist")
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(obj)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError   string
				itemMsgWarning string
			)
			// @TODO validate for Detail
			objDetailsValid := make([]models.DistancePriceListDetail, 0)
			for _, objDetail := range obj.DistancePriceListDetails {
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(objDetail)
				if err != nil {
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
					}
				} else {
					// @ vaidate data in details
					validateDetail := ValidateDistancePriceListDetails(lang, objDetail)
					itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
					if validateDetail != "" {
						continue
					}
					objDetail.CreatedBy = accountKey
					objDetailsValid = append(objDetailsValid, objDetail)
				}
			}
			obj.DistancePriceListDetails = objDetailsValid

			if len(obj.DistancePriceListDetails) <= 0 {
				errResponse := GetErrorResponseValidate(lang, 0, "api.distancepricelistdetails_required")
				errorsResponse = append(errorsResponse, errResponse)
			}
			if len(errorsResponse) <= 0 {
				if itemMsgWarning != "" {
					errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
					errorsResponse = append(errorsResponse, errResponse)
				}
				var (
					res          interface{}
					itemsMapData []map[string]interface{}
				)
				_, res = services.ConvertJSONValueToVariable("DistancePriceListDetails", bp)
				if res != nil {
					jsonItems, err := json.Marshal(bp["DistancePriceListDetails"])
					if err == nil {
						var (
							itemMsgErrorDetail string
						)
						json.Unmarshal([]byte(string(jsonItems)), &itemsMapData)
						for _, itemMap := range itemsMapData {
							var (
								validate = false
							)
							_, resFromUnit := services.ConvertJSONValueToVariable("FromUnit", itemMap)
							_, resToUnit := services.ConvertJSONValueToVariable("ToUnit", itemMap)
							if resFromUnit != nil || resToUnit != nil {
								validate = true
							}
							if validate {
								if resFromUnit == nil {
									itemMsgErrorDetail = libs.GetStringWithWordBetween(itemMsgErrorDetail, services.GetMessage(lang, "api.fromunit_required"))
								}
								if resToUnit == nil {
									itemMsgErrorDetail = libs.GetStringWithWordBetween(itemMsgErrorDetail, services.GetMessage(lang, "api.tounit_required"))
								}
							}
						}
						if itemMsgErrorDetail != "" {
							errResponse := GetErrorResponseErrorMessage(0, itemMsgErrorDetail)
							errorsResponse = append(errorsResponse, errResponse)
						}
					}
				}
				if itemMsgError == "" {
					// @TODO need to required > 0 for address, phone
					resultCreate := db.Create(&obj)
					if resultCreate.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					} else {
						totalUpdatedRecord++
						data = ConvertDistancePriceListToResponse(obj)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateDistancePriceList godoc
// @Summary Update Distance Price List
// @Description Update Distance Price List
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param DistancePriceList body models.DistancePriceListResponse true "Update Distance Price List"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist/{id} [put]
func UpdateDistancePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateDistancePriceList")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.DistancePriceList
	)
	resultFind := db.Where("DistancePriceListID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resultCheckExist := db.Where("IFNULL(IsDeleted, 0) <> 1 AND DistancePriceListName = ? AND DistancePriceListID <> ?", resModel.DistancePriceListName, resModel.DistancePriceListID).First(&models.DistancePriceList{})
		if resultCheckExist.RowsAffected > 0 {
			errResponse := GetErrorResponseValidate(lang, 0, "api.distancepricelistname_exist")
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			resModel.DistancePriceListID = id
			resModel.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(resModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(0, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError   string
					res            interface{}
					itemMsgWarning string
				)
				// @TODO validate for details
				// set details empty
				resModel.DistancePriceListDetails = make([]models.DistancePriceListDetail, 0)
				var (
					objectsDetails        []map[string]interface{}
					details               []models.DistancePriceListDetail
					arrSkipID             []int
					arrToDeleteID         []int
					detailsToDeleteModels []models.DistancePriceListDetail
				)
				details = make([]models.DistancePriceListDetail, 0)
				_, res = services.ConvertJSONValueToVariable("DistancePriceListDetails", bp)
				if res != nil {
					objectsJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(objectsJSON, &objectsDetails)
						if len(objectsDetails) > 0 {
							for _, obj := range objectsDetails {
								var (
									detailModel models.DistancePriceListDetail
								)
								detailModel.PassBodyJSONToModel(obj)
								resultFindDetails := db.Where("DistancePriceListDetailID = ? AND DistancePriceListID = ?", detailModel.DistancePriceListDetailID, resModel.DistancePriceListID).First(&detailModel)
								if resultFindDetails.RowsAffected > 0 {
									arrSkipID = append(arrSkipID, detailModel.DistancePriceListDetailID)
									detailModel.PassBodyJSONToModel(obj)
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidateDistancePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								} else {
									detailModel.PassBodyJSONToModel(obj)
									detailModel.CreatedBy = accountKey
									detailModel.DistancePriceListDetailID = 0
									detailModel.DistancePriceListID = 0
									validate, trans := services.GetValidatorTranslate()
									err := validate.Struct(detailModel)
									if err != nil {
										errs := err.(validator.ValidationErrors)
										for _, e := range errs {
											if itemMsgError == "" {
												itemMsgError = itemMsgError + e.Translate(trans)
											} else {
												itemMsgError = itemMsgError + "\n" + e.Translate(trans)
											}
										}
									} else {
										// @ vaidate data in details
										validateDetail := ValidateDistancePriceListDetails(lang, detailModel)
										itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, validateDetail)
										if validateDetail != "" {
											continue
										}
										detailModel.IsDeleted = false
										detailModel.ModifiedBy = accountKey
										details = append(details, detailModel)
									}
								}
							}
						}
					}
				}
				resModel.DistancePriceListDetails = details

				if itemMsgWarning != "" {
					errResponse := GetErrorResponseWarningMessage(0, itemMsgWarning)
					errorsResponse = append(errorsResponse, errResponse)
				}

				if len(resModel.DistancePriceListDetails) <= 0 {
					errResponse := GetErrorResponseValidate(lang, 0, "api.distancepricelistdetails_required")
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					if len(arrSkipID) > 0 {
						// delete id not in arrSkipID
						db.Where("DistancePriceListID = ? AND DistancePriceListDetailID not in (?)", resModel.DistancePriceListID, arrSkipID).Find(&detailsToDeleteModels)
					} else {
						// delete all
						db.Where("DistancePriceListID = ?", resModel.DistancePriceListID).Find(&detailsToDeleteModels)
					}
					for _, ad := range detailsToDeleteModels {
						arrToDeleteID = append(arrToDeleteID, ad.DistancePriceListDetailID)
					}
					// @TODO need to required > 0 for details
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
					if resultSave.Error != nil {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						totalUpdatedRecord++
						// @TODO delete details
						if len(arrToDeleteID) > 0 {
							db.Where("DistancePriceListDetailID in (?)", arrToDeleteID).Delete(&models.DistancePriceListDetail{})
							//db.Where("DistancePriceListDetailID in (?)", arrToDeleteID).Model(&models.DistancePriceListDetail{}).Updates(models.DistancePriceListDetail{IsDeleted: true})
						}
						//data = ConvertDistancePriceListToResponse(resModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			resultRow := db.Preload(
				"DistancePriceListDetails",
				"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
			).Where("IFNULL(IsDeleted, 0) <> 1 AND DistancePriceListID = ?", id).First(&resModel)
			if resultRow.RowsAffected > 0 {
				responses := ConvertDistancePriceListToResponse(resModel)
				data = responses
			} else {
				errResponse := GetErrorResponseNotFound(lang, 0)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteDistancePriceList godoc
// @Summary Delete Distance Price List
// @Description Delete Distance Price List
// @Tags DistancePriceList
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Distance Price List ID"
// @Success 200 {object} models.APIResponseData
// @Router /distancepricelist/{id} [delete]
func DeleteDistancePriceList(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteDistancePriceList")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.DistancePriceList
		)
		resultFind := db.Where("DistancePriceListID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			// @TODO DELETE - If the pricelist is assigned to a pricematrix cannot be deleted
			var totalCountAssigned int64
			totalCountAssigned = 0
			db.Model(&models.PriceListDetail{}).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DistancePriceListID = ?", resModel.DistancePriceListID).Count(&totalCountAssigned)
			if totalCountAssigned > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.confirm_delete_distancepricelist")
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// @TODO delete detail
					//db.Where("DistancePriceListID = ?", id).Delete(&models.DistancePriceListDetail{})
					db.Where("DistancePriceListID = ?", id).Model(&models.DistancePriceListDetail{}).Updates(models.DistancePriceListDetail{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayDistancePriceListToArrayResponseOnlyMaster func
func ConvertArrayDistancePriceListToArrayResponseOnlyMaster(items []models.DistancePriceList) []models.DistancePriceListResponseMaster {
	responses := make([]models.DistancePriceListResponseMaster, 0)
	for _, item := range items {
		response := ConvertDistancePriceListToResponseOnlyMaster(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDistancePriceListToResponseOnlyMaster func
func ConvertDistancePriceListToResponseOnlyMaster(item models.DistancePriceList) models.DistancePriceListResponseMaster {
	var (
		response models.DistancePriceListResponseMaster
	)
	response.DistancePriceListID = item.DistancePriceListID
	response.DistancePriceListName = item.DistancePriceListName
	return response
}

// ConvertArrayDistancePriceListToArrayResponse func
func ConvertArrayDistancePriceListToArrayResponse(items []models.DistancePriceList) []models.DistancePriceListResponse {
	responses := make([]models.DistancePriceListResponse, 0)
	for _, item := range items {
		response := ConvertDistancePriceListToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertDistancePriceListToResponse func
func ConvertDistancePriceListToResponse(item models.DistancePriceList) models.DistancePriceListResponse {
	var (
		response models.DistancePriceListResponse
	)
	response.DistancePriceListID = item.DistancePriceListID
	response.DistancePriceListName = item.DistancePriceListName
	response.IsIncludeTax = item.IsIncludeTax
	response.TaxID = item.TaxID
	details := make([]models.DistancePriceListDetailResponse, 0)
	for _, de := range item.DistancePriceListDetails {
		var (
			detail models.DistancePriceListDetailResponse
		)
		detail.DistancePriceListDetailID = de.DistancePriceListDetailID
		detail.DistancePriceListID = de.DistancePriceListID
		detail.Description = de.Description
		detail.FromUnit = de.FromUnit
		detail.ToUnit = de.ToUnit
		detail.Rate = de.Rate
		detail.IsRateByRange = de.IsRateByRange
		detail.DiscountPercent = de.DiscountPercent
		detail.BufferPercent = de.BufferPercent
		details = append(details, detail)
	}
	response.DistancePriceListDetails = details
	return response
}

// ValidateDistancePriceListDetails func
func ValidateDistancePriceListDetails(lang string, detail models.DistancePriceListDetail) string {
	var itemMsgWarning string
	if detail.FromUnit < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.fromunit_greater_zero"))
	}
	if detail.ToUnit < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.tounit_greater_zero"))
	}
	if detail.Rate < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.rate_greater_zero"))
	}
	if detail.DiscountPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.discountpercent_greater_zero"))
	}
	if detail.BufferPercent < 0 {
		itemMsgWarning = libs.GetStringWithWordBetween(itemMsgWarning, services.GetMessage(lang, "api.bufferpercent_greater_zero"))
	}
	return itemMsgWarning
}
