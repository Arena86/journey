package controllers

import (
	"encoding/json"
	"io/ioutil"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strings"

	"github.com/gin-gonic/gin"
)

// GetXeroAccount godoc
// @Summary Get Xero Account
// @Description Xero Account
// @Tags XeroAccount
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/account [get]
func GetXeroAccount(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroAccount")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	arrQuery := make(map[string]interface{})
	whereQuery := ""
	vType, sType := libs.GetQueryParam("Type", c)
	if sType {
		if whereQuery != "" {
			whereQuery = whereQuery + " AND "
		}
		whereQuery = whereQuery + "Type==\"" + strings.ToUpper(vType) + "\""
	}
	if whereQuery != "" {
		arrQuery["where"] = whereQuery
	}
	representURL := "Accounts"
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateXeroAccount godoc
// @Summary Create Xero Account
// @Description Create Xero Account
// @Tags XeroAccount
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Xero Account"
// @Success 200 {object} models.APIResponseData
// @Router /xero/account [post]
func CreateXeroAccount(c *gin.Context) {
	defer libs.RecoverError(c, "CreateXeroAccount")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		dataPOST      map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		json.Unmarshal([]byte(string(body)), &dataPOST)
		requestBody := dataPOST
		representURL := "Accounts"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "PUT", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			data = dataRes
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
