package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	smslogs "jpapi/tig/v1/logs/sms"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"math"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/printfhome/goutils"
	"gorm.io/gorm"
)

// GetInProgressUser godoc
// @Summary GetInProgressUser
// @Description GetInProgressUser
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getinprogressuser [get]
func GetInProgressUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetInProgressUser")
	var (
		status = libs.GetStatusSuccess()

		requestHeader           models.RequestHeader
		response                models.APIResponseData
		msg                     interface{}
		inProgressUserResponses []models.InProgressUserResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	todayDate := time.Now().Format(libs.FORMATDATE)
	startDate, statusStartDate := libs.GetQueryParam("ScheduleDate", c)
	if statusStartDate {
		vStartDate, eStartDate := libs.ConvertStringToDateTime(startDate)
		if eStartDate == nil {
			todayDate = vStartDate.Format(libs.FORMATDATE)
		} else {
			todayDate = startDate
		}
	}
	sql := `
	SELECT s.UserID, u.AccountKey, u.FirstName, u.LastName, u.CountryCode, u.PhoneNumber, l.LocationName, 
	s.ResourceID, r.ResourceCode, r.ResourceName, r.ResourceColor, r.ResourceType
	FROM jobs j
	JOIN schedules s ON j.JobID = s.JobID
	LEFT JOIN users u ON s.UserID = u.UserID
	LEFT JOIN locations l ON u.LocationID = l.LocationID
	LEFT JOIN resources r  ON s.ResourceID = r.ResourceID
	JOIN journeys jn ON (s.JourneyCode = jn.JourneyCode AND jn.Status <>2)
	WHERE j.status  = 6 AND DATE_FORMAT(s.ScheduleStartDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')
	AND s.IsDeleted = 0 AND j.IsDeleted = 0 AND s.IsReschedule = 0
	GROUP BY s.UserID, u.AccountKey, u.FirstName, u.LastName, u.CountryCode, u.PhoneNumber, l.LocationName, 
	s.ResourceID, r.ResourceCode, r.ResourceName, r.ResourceColor`
	rows, err := db.Raw(sql, todayDate).Rows()
	if rows != nil {
		defer rows.Close()
	}
	if err == nil {
		for rows.Next() {
			var (
				inProgressUserResponse models.InProgressUserResponse
				jobs                   []models.Job
				inProgressJobs         []models.InProgressJob
			)
			rows.Scan(&inProgressUserResponse.UserID,
				&inProgressUserResponse.AccountKey,
				&inProgressUserResponse.FirstName,
				&inProgressUserResponse.LastName,
				&inProgressUserResponse.CountryCode,
				&inProgressUserResponse.PhoneNumber,
				&inProgressUserResponse.LocationName,
				&inProgressUserResponse.ResourceID,
				&inProgressUserResponse.ResourceCode,
				&inProgressUserResponse.ResourceName,
				&inProgressUserResponse.ResourceColor,
				&inProgressUserResponse.ResourceType)

			inProgressUserResponse.ResourceTypeName, _ = libs.GetEnum(requestHeader, inProgressUserResponse.ResourceType, "ResourceType", lang)

			resultFindJob := db.Select("jobs.JobID,jobs.JobNumber,jobs.JobType,jobs.LocationID,jobs.Status,jobs.InProgressStatus,jobs.JobTaskStatus").Joins("JOIN schedules on schedules.JobID = jobs.JobID").
				Joins("JOIN journeys ON (schedules.JourneyCode = journeys.JourneyCode AND journeys.Status <>2)").
				Where("IFNULL(schedules.IsDeleted, 0) <> 1 AND IFNULL(schedules.IsReschedule, 0) <> 1").
				Where("IFNULL(schedules.IsArchived, 0) <> 1 AND IFNULL(jobs.IsDeleted, 0) <> 1 ").
				Where("schedules.UserID = ? AND schedules.ResourceID = ?", inProgressUserResponse.UserID, inProgressUserResponse.ResourceID).
				Where("jobs.Status = 6 AND DATE_FORMAT(schedules.ScheduleStartDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", todayDate).Group("jobs.JobID,jobs.JobNumber,jobs.JobType,jobs.LocationID,jobs.Status,jobs.InProgressStatus,jobs.JobTaskStatus").
				Find(&jobs)

			if resultFindJob.RowsAffected > 0 {
				for _, job := range jobs {
					var (
						jobTasks      []models.JobTask
						inProgressJob models.InProgressJob
					)
					inProgressJob.JobID = job.JobID
					inProgressJob.JobNumber = job.JobNumber
					inProgressJob.JobType = job.JobType
					inProgressJob.JobTypeName, inProgressJob.JobTypeIcon = libs.GetEnum(requestHeader, job.JobType, "JobType", lang)
					inProgressJob.LocationID = job.LocationID
					inProgressJob.Status = job.Status
					inProgressJob.StatusName, inProgressJob.StatusIcon = libs.GetEnum(requestHeader, job.Status, "JobStatus", lang)
					inProgressJob.InProgressStatus = job.InProgressStatus
					inProgressJob.JobTaskStatus = job.JobTaskStatus

					resultFindJobTask := db.Where("JobID", job.JobID).Find(&jobTasks)
					if resultFindJobTask.RowsAffected > 0 {
						var (
							inProgressJobTasks []models.InProgressJobTask
						)
						if len(jobTasks) > 0 {
							for _, jobTask := range jobTasks {
								var (
									inProgressJobTask models.InProgressJobTask
								)
								inProgressJobTask.JobTaskID = jobTask.JobTaskID
								inProgressJobTask.NavigationAddress = jobTask.NavigationAddress
								inProgressJobTask.TaskJobType = jobTask.JobType
								inProgressJobTask.TaskJobTypeName, inProgressJobTask.TaskJobTypeIcon = libs.GetEnum(requestHeader, jobTask.JobType, "JobType", lang)
								inProgressJobTask.TaskStatus = jobTask.Status
								inProgressJobTask.TaskStatusName, inProgressJobTask.TaskStatusIcon = libs.GetEnum(requestHeader, jobTask.Status, "JobTaskStatus", lang)
								inProgressJobTasks = append(inProgressJobTasks, inProgressJobTask)
							}
						} else {
							inProgressJobTasks = make([]models.InProgressJobTask, 0)
						}
						inProgressJob.InProgressJobTasks = inProgressJobTasks
					}
					inProgressJobs = append(inProgressJobs, inProgressJob)
				}
			} else {
				inProgressJobs = make([]models.InProgressJob, 0)
			}
			inProgressUserResponse.InProgressJobs = inProgressJobs
			inProgressUserResponses = append(inProgressUserResponses, inProgressUserResponse)
		}
	}

	responses := inProgressUserResponses

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = len(inProgressUserResponses)
	libs.ResponseData(responsesData, c, status)
}

// GetJobList godoc
// @Summary Get Job List
// @Description Get Job List
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjoblist [get]
func GetJobList(c *gin.Context) {
	defer libs.RecoverError(c, "GetJob")
	var (
		status          = libs.GetStatusSuccess()
		jobs            []models.Job
		requestHeader   models.RequestHeader
		response        models.APIResponseData
		msg             interface{}
		isSearch        = false
		includeCombined = true
		includeMultiple = true
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	errorsResponse := make([]models.ErrorResponse, 0)
	vSearch, sSearch := libs.GetQueryParam("Search", c)
	if sSearch {
		isSearch = true
	}
	vIncludeCombined, sIncludeCombined := libs.GetQueryParam("includecombined", c)
	if sIncludeCombined {
		includeCombined, _ = strconv.ParseBool(vIncludeCombined)
	}
	vIncludeMultiple, sIncludeMultiple := libs.GetQueryParam("includemultiple", c)
	if sIncludeMultiple {
		includeMultiple, _ = strconv.ParseBool(vIncludeMultiple)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	if !includeCombined {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsCombinedChild, 0) = 0")
	}

	if !includeMultiple {
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1  AND IFNULL(IsMultipleChild, 0) = 0")
	}
	// Filter
	if locationID > 0 {
		bp = bp.Where("LocationID = ?", locationID)
	}
	if isSearch {
		var (
			jobDateSearchs []models.JobSearchField
		)
		dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//dbP.LogMode(true)
		dbP.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND IFNULL(IsSelected, 0) <> 0").Find(&jobDateSearchs)
		sqlQuery := ""
		sqlWhere := ""
		concatString := "CONCAT("
		for _, p := range jobDateSearchs {
			if p.FieldName == "JobTypeName" {
				p.FieldName = "Caption"
			}
			concatString += p.FieldName
			concatString += ","
			concatString += "' '"
			concatString += ","
		}
		concatString = strings.TrimSuffix(concatString, ",")
		concatString += ")"
		sqlQuery = `SELECT jo.JobID FROM jobs jo 
		LEFT JOIN businesspartners bp ON jo.BusinessPartnerID = bp.BusinessPartnerID
		LEFT JOIN jobtasks jt ON jo.JobID = jt.JobTaskID
		LEFT JOIN phones ph ON  (ph.EntityID = bp.BusinessPartnerID AND ph.Entity = 'businesspartners')
		LEFT JOIN enums en ON (jo.JobType = en.Status AND en.FieldName = 'JobType')
		`
		sqlWhere += "WHERE " + concatString + ` LIKE '%` + vSearch + `%'`
		arrID := make([]int, 0)
		sqlQuery += sqlWhere + `  GROUP BY jo.JobID`
		rows, err := dbP.Raw(sqlQuery).Rows()
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var ID int
				rows.Scan(&ID)
				if ID > 0 {
					arrID = append(arrID, ID)
				}
			}
		}

		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		bp = bp.Where("JobID IN (?)", arrID)
	} else {
		arrBool := []string{
			"IsJob", "IsInvoice", "IsEstimate", "IsCreditNote",
		}
		bp = libs.FilterBool(arrBool, bp, c)
		arrString := []string{
			"EstimateNumber", "JobNumber", "InvoiceNumber", "CreditNoteNumber", "AdditionalResources",
		}
		bp = libs.FilterString(arrString, bp, c)
		arrInteger := []string{
			"JobType", "LocationID", "BusinessPartnerID", "Status", "InProgressStatus",
			"PrimaryResource", "EstimatedTravelTime", "EstimatedDistance",
		}
		bp = libs.FilterInteger(arrInteger, bp, c)
		arrDateTime := []string{
			"PreferredDateTime", "JobDate", "ScheduleStartDateTime",
			"ScheduleEndDateTime", "DepartureDateTime", "EstimatedArrivalDateTime",
			"EstimatedArrivalDateTimeAfterDeparture", "ArrivalDateTime",
			"JobStartDateTime", "JobEndDateTime",
		}
		bp = libs.FilterDateTime(arrDateTime, bp, c)

		jobDateSearch := "JobDate"
		jobPeriod, statusPeriod := libs.GetQueryParam("Period", c)
		if statusPeriod {
			timeNow := time.Now()
			if jobPeriod == models.TW {
				// this week from get all jobs
				beginningOfTWeek := goutils.TimeBeginningOfWeek(timeNow, false).Format("2006-01-02")
				endOfTWeek := goutils.TimeEndOfWeek(timeNow, false).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfTWeek, endOfTWeek)
			} else if jobPeriod == models.NW {
				// next week from get all jobs
				beginningOfNextWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				endOfNextWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, 7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfNextWeek, endOfNextWeek)
			} else if jobPeriod == models.FT {
				// Future from get all jobs
				toDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') > DATE_FORMAT(?,'%Y-%m-%d')", toDay)
			} else if jobPeriod == models.LW {
				// last week
				beginningOfLastWeek := goutils.TimeBeginningOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				endOfLastWeek := goutils.TimeEndOfWeek(timeNow, false).AddDate(0, 0, -7).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d') and DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", beginningOfLastWeek, endOfLastWeek)
			} else if jobPeriod == models.TM {
				// tomorrow - only tomorrow
				tomorrowDay := timeNow.AddDate(0, 0, 1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", tomorrowDay)
			} else if jobPeriod == models.YD {
				// only yester day
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.PV {
				// previous from yesterday and before -> yesterday -> past
				yesterdayDay := timeNow.AddDate(0, 0, -1).Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", yesterdayDay)
			} else if jobPeriod == models.TD {
				todayDay := timeNow.Format("2006-01-02")
				bp = bp.Where("DATE_FORMAT("+jobDateSearch+",'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", todayDay)
			}
		}

		vCompanyName, sCompanyName := libs.GetQueryParam("CompanyName", c)
		if sCompanyName {
			dbP := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			var (
				partners []models.BusinessPartner
			)
			arrID := make([]int, 0)
			dbP.Where("CompanyName like ?", "%"+vCompanyName+"%").Find(&partners)
			for _, p := range partners {
				arrID = append(arrID, p.BusinessPartnerID)
			}
			if len(arrID) <= 0 {
				arrID = append(arrID, -1)
			}
			bp = bp.Where("BusinessPartnerID in (?)", arrID)
		}

		// UDFs
		arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Job{}.TableName())
		bp = libs.FilterUDFs(arrQueries, bp)
		// Sort
		bp = libs.SortDataOnParam(bp, c, "CompanyName")
		companySort := libs.GetSortValueFromKey(c, "CompanyName")
		if companySort != "" {
			dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			//

			var partners []models.BusinessPartner
			arrBusinessPartnerIDSort := make([]int, 0)
			dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("CompanyName " + companySort).Find(&partners)
			for _, partner := range partners {
				arrBusinessPartnerIDSort = append(arrBusinessPartnerIDSort, partner.BusinessPartnerID)
			}
			if len(arrBusinessPartnerIDSort) > 0 {
				strJoin := libs.IntJoin(arrBusinessPartnerIDSort)
				if strJoin != "" {
					bp = bp.Order("FIELD(BusinessPartnerID," + strJoin + ")")
				}
			}
		}
	}
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobs).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(jobs) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayJobListToArrayResponse(requestHeader, jobs, lang, false)
	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Job{}.TableName())

		udfParams := make([]string, 0)

		vIsInvoice, sIsInvoice := libs.GetQueryParam("isinvoice", c)
		if sIsInvoice {
			bIsInvoice, eIsInvoice := strconv.ParseBool(vIsInvoice)
			if eIsInvoice == nil {
				if bIsInvoice {
					udfParams = append(udfParams, "invoices")
				}
			}
		}

		vIsEstimate, sIsEstimate := libs.GetQueryParam("isestimate", c)
		if sIsEstimate {
			bIsEstimate, eIsEstimate := strconv.ParseBool(vIsEstimate)
			if eIsEstimate == nil {
				if bIsEstimate {
					udfParams = append(udfParams, "estimates")
				}
			}
		}

		vIsCreditnote, sIsCreditnote := libs.GetQueryParam("iscreditnote", c)
		if sIsCreditnote {
			bIsCreditnote, eIsCreditnote := strconv.ParseBool(vIsCreditnote)
			if eIsCreditnote == nil {
				if bIsCreditnote {
					udfParams = append(udfParams, "creditnotes")
				}
			}
		}

		vIsJob, sIsJob := libs.GetQueryParam("isjob", c)
		if sIsJob {
			bIsJob, eIsJob := strconv.ParseBool(vIsJob)
			if eIsJob == nil {
				if bIsJob {
					udfParams = append(udfParams, "jobs")
				}
			}
		}

		if len(udfParams) > 0 {
			dbu = dbu.Where("UDFKey in (?)", udfParams)
		}

		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		// @TOTO Move UDF to outsite
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "JobID", v.DataType, b.JobID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetInProgressJobTask godoc
// @Summary GetInProgressJobTask
// @Description GetInProgressJobTask
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getinprogressjobtask [get]
func GetInProgressJobTask(c *gin.Context) {
	defer libs.RecoverError(c, "GetInProgressJobTask")
	var (
		status = libs.GetStatusSuccess()
		//jobs               []models.Job
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data          interface{}
		userModel          models.User
		currentProgressJob models.JobInProgress
		itemMsgError       string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	var fromDate, toDate time.Time
	vFromDate, sFromDate := libs.GetQueryParam("FromDate", c)
	if sFromDate {
		dFromDate, errFromDate := libs.ConvertStringToDateTime(vFromDate)
		if errFromDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_invalid"))
		} else {
			fromDate = dFromDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.fromdate_required"))
	}

	vToDate, sToDate := libs.GetQueryParam("ToDate", c)
	if sToDate {
		dToDate, errToDate := libs.ConvertStringToDateTime(vToDate)
		if errToDate != nil {
			status = 422
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_invalid"))
		} else {
			toDate = dToDate
		}
	} else {
		status = 422
		itemMsgError = libs.GetStringWithWordBetween(itemMsgError, services.GetMessage(lang, "api.todate_required"))
	}
	if status == 200 {
		sql := `SELECT IFNULL(jo.JobFormsNavigation,'') AS JobFormsNavigation, sc.ResourceID,  sc.JourneyCode, jo.JobNumber, sc.ScheduleID, sc.ScheduleStartDate,jo.JobID, jt.JobTaskID, 
		jo.InProgressStatus, jo.JobTaskStatus, jo.Status AS JobStatus, jt.Status AS TaskStatus, sc.UserID, jt.FormFlowID, jo.InspectionForJobID, jo.IsInspection
		FROM jobs jo JOIN jobtasks jt ON jo.JobID = jt.JobID
		JOIN schedules sc ON (jo.JobID = sc.JobID AND jt.JobTaskID = sc.JobTaskID)
		WHERE (jo.Status IN (3,4,5,6,8) OR jt.Status IN (1,2,3))
		AND (DATE_FORMAT(sc.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') >= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(sc.ScheduleStartDate,'%Y-%m-%d %H:%i:%s') <= DATE_FORMAT(?,'%Y-%m-%d %H:%i:%s')) AND sc.UserID = ? 
		AND IFNULL(sc.IsDeleted,0) = 0 AND IFNULL(sc.IsReschedule,0) = 0 
		`
		if locationID > 0 {
			sql = sql + " AND sc.LocationID = " + strconv.Itoa(locationID)
		}
		sql = sql + ` HAVING jt.Status <> 4`
		sql = sql + ` ORDER BY sc.ScheduleStartDate ASC LIMIT 1`
		resultFindUser := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Where("AccountKey = ?", accountKey).First(&userModel)
		if resultFindUser.RowsAffected > 0 {
			userID := userModel.UserID
			var (
				jobFormNavigation  []models.JobFormNavigation
				jobCurrentForm     models.JobCurrentForm
				jobFormsNavigation = ""
			)
			rows, err := db.Raw(sql, fromDate, toDate, userID).Rows()
			if rows != nil {
				defer rows.Close()
			}
			if err == nil {
				for rows.Next() {
					rows.Scan(&jobFormsNavigation, &currentProgressJob.ResourceID, &currentProgressJob.JourneyCode, &currentProgressJob.JobNumber,
						&currentProgressJob.ScheduleID, &currentProgressJob.ScheduleStartDate,
						&currentProgressJob.JobID, &currentProgressJob.JobTaskID,
						&currentProgressJob.InProgressStatus, &currentProgressJob.JobTaskStatus,
						&currentProgressJob.JobStatus, &currentProgressJob.TaskStatus,
						&currentProgressJob.UserID, &currentProgressJob.FormFlowID, &currentProgressJob.InspectionForJobID, &currentProgressJob.IsInspection,
					)
					currentProgressJob.JobStatusName, _ = libs.GetEnum(requestHeader, currentProgressJob.JobStatus, "JobStatus", lang)
					currentProgressJob.TaskStatusName, _ = libs.GetEnum(requestHeader, currentProgressJob.TaskStatus, "JobStatus", lang)
				}
				if jobFormsNavigation != "" {
					json.Unmarshal([]byte(jobFormsNavigation), &jobFormNavigation)
					if len(jobFormNavigation) > 0 {

						for _, n := range jobFormNavigation {
							if n.Task.TaskID == currentProgressJob.JobTaskID {
								if len(n.Forms) > 0 {
									item := n.Forms[len(n.Forms)-1]
									jobCurrentForm.FormTitle = item.FormTitle
									if item.OriginalForm == 0 {
										jobCurrentForm.Form = item.Form
									} else {
										jobCurrentForm.Form = strconv.Itoa(item.OriginalForm)
									}
								}
								break
							}
						}
					}
					currentProgressJob.JobCurrentForm = jobCurrentForm
				}
				if currentProgressJob.JobID == 0 {
					data = nil
				} else {
					data = currentProgressJob
				}
			}

			msg = services.GetMessage(lang, "api.success")
		}
	}

	if itemMsgError != "" {
		errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)

}

// TakeJob godoc
// @Summary TakeJob
// @Description TakeJob
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /takejob [put]
func TakeJob(c *gin.Context) {
	defer libs.RecoverError(c, "TakeJob")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 1
		arrJobID           models.JobIDList
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	json.NewDecoder(c.Request.Body).Decode(&arrJobID)
	isTaken := false
	vTaken, sTaken := libs.GetQueryParam("taken", c)
	if sTaken {
		bIsTaken, eIsTaken := strconv.ParseBool(vTaken)
		if eIsTaken == nil {
			isTaken = bIsTaken
		}
	}

	if len(arrJobID.JobID) > 0 {
		if isTaken {
			db.Where("JobID IN (?) AND Status = 2", arrJobID.JobID).Model(&models.Job{}).Updates(map[string]interface{}{"Status": 8})
		} else {
			db.Where("JobID IN (?) AND Status = 8", arrJobID.JobID).Model(&models.Job{}).Updates(map[string]interface{}{"Status": 2})
		}
		// @TODO update master combined job
		for _, jobIDVar := range arrJobID.JobID {
			UpdateJobStatusForMasterJobCombinedAfterTakeJob(requestHeader, jobIDVar, accountKey)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, false)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetJobsInProgress godoc
// @Summary GetJobsInProgress
// @Description GetJobsInProgress
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /getjobsinprogress [get]
func GetJobsInProgress(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobsInProgress")
	var (
		status        = libs.GetStatusSuccess()
		jobs          []models.Job
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("JobDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobPickup", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobOnSite", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobInStore", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobMultiple", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobCombined", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobResourcePickUp", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Preload("JobResourceDelivery", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	if locationID > 0 {
		bp = bp.Where("jobs.LocationID = ?", locationID)
	}
	bp = bp.Where("Status not in (?)", []int{0, 7})

	var (
		settingModel           models.Setting
		showTodayJobInProgress = false
	)
	resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
	if resultFindSetting.RowsAffected > 0 {
		if settingModel.Value != nil {
			var (
				settingValue models.SettingValue
			)
			errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
			if errSettingValue == nil {
				showTodayJobInProgress = settingValue.Job.ShowTodayJobInProgress
			}
		}
	}

	vJobDate, sJobDate := libs.GetQueryParam("JobDate", c)
	if sJobDate {
		dJobDate, errJobDate := services.ConvertStringToDateTime(vJobDate)
		if errJobDate == nil {
			// get 2 day old datetime
			if showTodayJobInProgress {
				vJobDate = dJobDate.AddDate(0, 0, 0).Format("2006-01-02")
			} else {
				vJobDate = dJobDate.AddDate(0, 0, -1).Format("2006-01-02")
			}
		}
	}
	if vJobDate == "" {
		// get 2 day old datetime
		if showTodayJobInProgress {
			yesterdayDay := time.Now().AddDate(0, 0, 0).Format("2006-01-02")
			vJobDate = yesterdayDay
		} else {
			yesterdayDay := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
			vJobDate = yesterdayDay
		}
	}
	bp = bp.Joins("JOIN schedules ON schedules.JobID = jobs.JobID").Where("DATE_FORMAT(ScheduleStartDate,'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", vJobDate).Group("jobs.JobID")
	//bp = bp.Where("DATE_FORMAT(JobDate,'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')", vJobDate)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&jobs).Limit(-1).Offset(-1).Count(&totalCount)

	if resultRow.Error == nil {
		msg = services.GetMessage(lang, "api.success")
		data = ConvertArrayJobsToArrayResponse(requestHeader, jobs, lang, false, true)
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// PostJobsInProgress godoc
// @Summary PostJobsInProgress
// @Description PostJobsInProgress
// @Tags Job
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Job body []models.JSONInProgressJob true "PostJobsInProgress"
// @Success 200 {object} models.APIResponseData
// @Router /postjobsinprogress [post]
func PostJobsInProgress(c *gin.Context) {
	defer libs.RecoverError(c, "PostJobsInProgress")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data          interface{}
		errorsResponse     []models.ErrorResponse
		postJobsJSON       []models.JSONInProgressJob
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &postJobsJSON)

	if len(postJobsJSON) > 0 {
		for i, postJob := range postJobsJSON {
			var (
				msgErrorPostJobsInProgress string
				jobModel                   models.Job
			)
			resultFindJob := db.Where("JobID = ?", postJob.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
			if resultFindJob.RowsAffected > 0 {
				smsMatrixID := 0
				if postJob.Complete {
					var (
						hasComplete = false
					)
					if postJob.CompleteJob { // complete all jobtask > complete job
						// Status = 7, ForceCompletedDate = CompleteDate, JobTaskStatus = 4
						sqlJobTask := `UPDATE ` + models.JobTask{}.TableName() + ` SET Status = 4 Where JobID = ?`
						resultUpdateCompleteJobTask := db.Exec(sqlJobTask, postJob.JobID)
						if resultUpdateCompleteJobTask.Error != nil {
							msgErrorPostJobsInProgress = libs.GetStringWithWordBetween(msgErrorPostJobsInProgress, resultUpdateCompleteJobTask.Error.Error())
						} else {
							sql := `UPDATE ` + models.Job{}.TableName() + ` SET Status = 7 Where JobID = ?`
							resultUpdateComplete := db.Exec(sql, postJob.JobID)
							if resultUpdateComplete.Error != nil {
								msgErrorPostJobsInProgress = libs.GetStringWithWordBetween(msgErrorPostJobsInProgress, resultUpdateComplete.Error.Error())
							} else {
								hasComplete = true
							}
						}
					} else { // complete jobtask
						sqlJobTask := `UPDATE ` + models.JobTask{}.TableName() + ` SET Status = 4 Where JobTaskID = ?`
						resultUpdateCompleteJobTask := db.Exec(sqlJobTask, postJob.JobTaskID)
						if resultUpdateCompleteJobTask.Error != nil {
							msgErrorPostJobsInProgress = libs.GetStringWithWordBetween(msgErrorPostJobsInProgress, resultUpdateCompleteJobTask.Error.Error())
						} else {
							hasComplete = true
						}
					}

					if postJob.Invoice {
						// Create Invoice
						if hasComplete {
							statusXeroInvoice, msgXeroInvoice, _ := GenerateXeroInvoice(requestHeader, lang, postJob.JobID, accountKey)
							if statusXeroInvoice != 200 {
								msgErrorPostJobsInProgress = libs.GetStringWithWordBetween(msgErrorPostJobsInProgress, msgXeroInvoice)
							}
						}
					}
					if hasComplete {
						smsMatrixID = 8
					}
				}
				if postJob.Reschedule {
					// Reschedule Job
					var (
						itemMsgError string
					)
					itemMsgError = ResetJob(postJob.JobID, postJob.ReasonID, postJob.Comment, accountKey, requestHeader, itemMsgError, c)
					if itemMsgError != "" {
						smsMatrixID = 6
						// job combined master
						UpdateJobStatusForMasterJobCombinedAfterResetJob(requestHeader, postJob.JobID, accountKey)
					} else {
						msgErrorPostJobsInProgress = libs.GetStringWithWordBetween(msgErrorPostJobsInProgress, itemMsgError)
					}
				}

				if postJob.SendSMS && smsMatrixID > 0 {
					// Send SMS
					jobID := postJob.JobID
					resStatus, resMsg, resSendSMS := SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobID)
					// logger
					var smsLogger = smslogs.SMSLogger
					smsLogger.Println("jobID: ", jobID)
					smsLogger.Println("smsMatrixID: ", smsMatrixID)
					smsLogger.Println("resStatus: ", resStatus)
					smsLogger.Println("resMsg: ", resMsg)
					smsLogger.Printf("resSendSMS: %+v", resSendSMS)
				}
			} else {
				msgErrorPostJobsInProgress = services.GetMessage(lang, "api.jobid_not_found")
			}

			if msgErrorPostJobsInProgress != "" {
				errResponse := GetErrorResponseErrorMessage(i, msgErrorPostJobsInProgress)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		}
	}
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(postJobsJSON), errorsResponse, false)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GenerateXeroInvoice func
func GenerateXeroInvoice(requestHeader models.RequestHeader, lang string, jobID int, accountKey int) (int, string, interface{}) {
	var (
		status               = 200
		msg                  string
		xeroConfig           models.XeroConfig
		invoicePOST          models.XeroInvoiceJPPOST
		dataRes              map[string]interface{}
		jobModel             models.Job
		jobDetails           []models.JobDetail
		businessPartnerModel models.BusinessPartner
		data                 interface{}
		createXeroInvoice    = true
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 {
		if xeroConfig.IsActive {
			if xeroConfig.IsInvoiceEnabled {
				resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
				if resultFindJob.RowsAffected > 0 {
					// check job IsInvoice
					if !jobModel.IsInvoice {
						increaseInvoiceSequence := false
						jobModel.IsInvoice = true
						if strings.ToLower(xeroConfig.InvoiceNumberGeneration) == "journey pro" {
							if jobModel.InvoiceNumber == "" {
								CheckDocumentSequencesBeforeCreate(requestHeader)
								var (
									sequencyModel    models.DocumentSequency
									invoiceNumPrefix models.Prefix
								)
								ResetDocumentSequencesIfGreaterLength(requestHeader)
								db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
								db.Where("DocumentSequence = ?", "InvoiceNumber").Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&invoiceNumPrefix)
								invoiceNumberFirstConfig := invoiceNumPrefix.Prefix
								lenInvoiceNumberConfig := invoiceNumPrefix.Length
								sqInvoiceNumber := sequencyModel.InvoiceNumber
								jobModel.InvoiceNumber = services.GenerateDefaultValueWithConfigLength(invoiceNumberFirstConfig, lenInvoiceNumberConfig, sqInvoiceNumber)
								increaseInvoiceSequence = true
							}
						}
						jobModel.ModifiedBy = accountKey
						resultSaveJob := db.Save(&jobModel)
						if resultSaveJob.Error != nil {
							status = 500
							msg = resultSaveJob.Error.Error()
						} else {
							if increaseInvoiceSequence {
								IncreaseDocumentSequencesAfterCreateJob(false, false, true, false, requestHeader)
							}
						}
					} else {
						createXeroInvoice = false
					}
				} else {
					status = 404
					msg = services.GetMessage(lang, "api.jobid_not_found")
				}
				if status == 200 && createXeroInvoice {
					// @TODO hardcode AccountCode = 200
					accountCode := xeroConfig.ItemSaleAccountCode
					// @TODO mapping job data to invoice json
					xeroInvoiceType := os.Getenv("XERO_INVOICE_TYPE")
					invoicePOST.Type = &xeroInvoiceType
					if strings.ToLower(xeroConfig.InvoiceNumberGeneration) == "journey pro" {
						if jobModel.InvoiceNumber != "" {
							invoicePOST.InvoiceNumber = &jobModel.InvoiceNumber
						}
					}
					invoicePOST.Reference = &jobModel.JobNumber
					invoicePOST.BrandingThemeID = &xeroConfig.Branding
					resultFindBusinessPartner := db.Preload(
						"Addresses",
						"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
						models.BusinessPartner{}.TableName(),
					).Preload(
						"Phones",
						"Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
						models.BusinessPartner{}.TableName(),
					).Preload(
						"Locations",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartnerModel)
					if resultFindBusinessPartner.RowsAffected > 0 {
						if businessPartnerModel.ErpKey != "" {
							// @TODO need to check ErpKey exist on xero > currently - no need
							invoicePOST.Contact.ContactID = &businessPartnerModel.ErpKey
						} else {
							// @TODO need insert new contact from jp to xero
							contacts := make([]models.BusinessPartner, 0)
							contacts = append(contacts, businessPartnerModel)
							xeroResponses := UpdateContactFromDatabaseToXero(requestHeader, lang, contacts)
							if len(xeroResponses) > 0 {
								contactResponse := xeroResponses[0]
								if contactResponse.Status == 200 {
									var xeroContactResponse models.BusinessPartner
									dataContact, errContact := json.Marshal(contactResponse.Data)
									if errContact == nil {
										json.Unmarshal(dataContact, &xeroContactResponse)
										if xeroContactResponse.ErpKey != "" {
											invoicePOST.Contact.ContactID = &xeroContactResponse.ErpKey
										}
									}
								}
							}
						}
					} else {
						// @TODO need create new contact on xero > currently - no need
					}
					/* if jobModel.JobDate != nil {
						dJobDate := *jobModel.JobDate
						sJobDate := dJobDate.Format("2006-01-02T15:04:05")
						invoicePOST.DateString = &sJobDate
						dDueDate := dJobDate.AddDate(0, 0, xeroConfig.InvoiceDueDate)
						sDueDate := dDueDate.Format("2006-01-02T15:04:05")
						invoicePOST.DueDateString = &sDueDate
					} */

					dCurrentDate := time.Now()
					sJobDate := dCurrentDate.Format("2006-01-02T15:04:05")
					invoicePOST.DateString = &sJobDate
					dDueDate := dCurrentDate.AddDate(0, 0, xeroConfig.InvoiceDueDate)
					sDueDate := dDueDate.Format("2006-01-02T15:04:05")
					invoicePOST.DueDateString = &sDueDate

					var settingModel models.Setting
					resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
					if resultFindSetting.RowsAffected > 0 {
						if settingModel.Value != nil {
							var (
								settingValue models.SettingValue
							)
							errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
							if errSettingValue == nil {
								invoicePOST.CurrencyCode = &settingValue.Localization.Currency
							}
						}
					}
					invoicePOST.Status = &xeroConfig.PostedInvoiceStatus

					db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobDetails)
					var lineItems = make([]models.XeroInvoiceItem, 0)
					for _, jobDetail := range jobDetails {
						var (
							lineItem  models.XeroInvoiceItem
							itemModel models.Item
						)
						resultFindItem := db.Where("ItemID = ?", jobDetail.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&itemModel)
						if resultFindItem.RowsAffected > 0 {
							if itemModel.ErpKey != "" && itemModel.Code != "" {
								lineItem.ItemCode = &itemModel.Code
							}
						}
						description := jobDetail.Description
						lineItem.AccountCode = &accountCode
						lineItem.Description = &description
						sQuantity := fmt.Sprintf("%f", jobDetail.Quantity)
						lineItem.Quantity = &sQuantity
						sUnitAmount := fmt.Sprintf("%f", jobDetail.UnitPrice)
						lineItem.UnitAmount = &sUnitAmount
						sDiscountAmount := fmt.Sprintf("%f", jobDetail.DiscountAmount)
						lineItem.DiscountAmount = &sDiscountAmount
						lineItems = append(lineItems, lineItem)
					}

					distanceCharge := jobModel.DistanceCharge
					if distanceCharge > 0 {
						var lineItem models.XeroInvoiceItem
						//if strings.ToLower(xeroConfig.PostedInvoiceStatus) != strings.ToLower("DRAFT") {
						lineItem.AccountCode = &accountCode
						//}
						description := "Distance Charge" + " " + fmt.Sprintf("%.2f", math.Round(jobModel.Distance/1000))
						lineItem.Description = &description
						sQuantity := "1"
						lineItem.Quantity = &sQuantity
						sUnitAmount := fmt.Sprintf("%f", distanceCharge)
						lineItem.UnitAmount = &sUnitAmount
						sDiscountAmount := "0"
						lineItem.DiscountAmount = &sDiscountAmount
						//sLineAmount := fmt.Sprintf("%f", distanceCharge)
						//lineItem.LineAmount = &sLineAmount
						lineItems = append(lineItems, lineItem)
					}

					travelTimeCharge := jobModel.TravelTimeCharge
					if travelTimeCharge > 0 {
						var lineItem models.XeroInvoiceItem
						//if strings.ToLower(xeroConfig.PostedInvoiceStatus) != strings.ToLower("DRAFT") {
						lineItem.AccountCode = &accountCode
						//}
						description := "Travel Time Charge" + " " + fmt.Sprintf("%.2f", math.Round(jobModel.TravelTime/1000))
						lineItem.Description = &description
						sQuantity := "1"
						lineItem.Quantity = &sQuantity
						sUnitAmount := fmt.Sprintf("%f", travelTimeCharge)
						lineItem.UnitAmount = &sUnitAmount
						sDiscountAmount := "0"
						lineItem.DiscountAmount = &sDiscountAmount
						//sLineAmount := fmt.Sprintf("%f", travelTimeCharge)
						//lineItem.LineAmount = &sLineAmount
						lineItems = append(lineItems, lineItem)
					}

					invoicePOST.LineItems = lineItems
					requestBody := invoicePOST
					representURL := "Invoices"
					resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
					if resStatus == 200 {
						json.Unmarshal([]byte(string(resData)), &dataRes)
						var invoiceRes = make([]interface{}, 0)
						objectJSON, errJSON := json.Marshal(dataRes["Invoices"])
						if errJSON == nil {
							json.Unmarshal(objectJSON, &invoiceRes)
							if len(invoiceRes) > 0 {
								data = invoiceRes[0]
								// @TODO update InvoiceID to jobs
								var mapInvoice map[string]interface{}
								mapInvoiceJSON, errMapInvoice := json.Marshal(invoiceRes[0])
								if errMapInvoice == nil {
									json.Unmarshal(mapInvoiceJSON, &mapInvoice)
									fInvoiceKey, errInvoiceKey := mapInvoice["InvoiceID"]
									if errInvoiceKey {

										if strings.ToLower(xeroConfig.InvoiceNumberGeneration) == "xero" {
											if jobModel.InvoiceNumber == "" {
												fInvoiceNumber, errInvoiceNumber := mapInvoice["InvoiceNumber"]
												if errInvoiceNumber {
													vInvoiceNumber := fmt.Sprintf("%v", fInvoiceNumber)
													jobModel.InvoiceNumber = vInvoiceNumber
												}
											}
										}

										vInvoiceKey := fmt.Sprintf("%v", fInvoiceKey)
										jobModel.ErpInvoiceKey = &vInvoiceKey

										fInvoiceStatus, errInvoiceStatus := mapInvoice["Status"]
										if errInvoiceStatus {
											vInvoiceStatus := fmt.Sprintf("%v", fInvoiceStatus)
											jobModel.ErpInvoiceStatus = &vInvoiceStatus
										}
										db.Save(&jobModel)
										//@TODO - Do Payment
										AddXeroPayment(requestHeader, db, jobModel, vInvoiceKey, lang, accountKey)
									}
								}
							}
						} else {
							status = 500
							msg = errJSON.Error()
						}
					} else {
						// @TOTO  - Reset Invoice Number\
						jobModel.InvoiceNumber = ""
						jobModel.IsInvoice = false
						db.Save(&jobModel)
						status = resStatus
						msg = fmt.Sprintf("%v", resMsg)
					}
				} else { //@TODO - Do Payment
					if *jobModel.ErpInvoiceKey != "" {
						AddXeroPayment(requestHeader, db, jobModel, *jobModel.ErpInvoiceKey, lang, accountKey)
					}
				}
			}
		}
	}
	return status, msg, data
}

// AddXeroPayment func
func AddXeroPayment(requestHeader models.RequestHeader, db *gorm.DB, jobModel models.Job, vInvoiceKey string, lang string, accountKey int) {
	//@TODO - Do Payment
	var (
		payment models.Payment
	)
	resultRow := db.Preload("PaymentDetails", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND  IFNULL(AssignedInvoice, 0) <> 1").
		Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
		Where("JobID = ?", jobModel.JobID).Find(&payment)
	if resultRow.Error == nil {
		var isAuthorised = false
		if len(payment.PaymentDetails) > 0 {
			var invoicePOST models.XeroInvoiceJPPOST
			invoicePOST.InvoiceID = &vInvoiceKey
			approveInvoice := "AUTHORISED"
			invoicePOST.Status = &approveInvoice
			requestBody := invoicePOST
			representURL := "Invoices/" + vInvoiceKey
			resStatus, _, _ := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			if resStatus == 200 {
				isAuthorised = true
				jobModel.ErpInvoiceStatus = &approveInvoice
				db.Save(&jobModel)
			}
		}
		if isAuthorised {
			for _, paymentDetail := range payment.PaymentDetails {
				// Create Payment on Xero
				var xeroPayment models.XeroPaymentPOST
				xeroPayment.Invoice.InvoiceID = vInvoiceKey
				// @TODO hardcode to testing and need add to config
				accountCode := "880"
				xeroPayment.Account.Code = &accountCode
				xeroPayment.Date = time.Now().Format(libs.FORMATDATE)
				xeroPayment.Amount = paymentDetail.Amount
				xeroPayment.Reference = &paymentDetail.OnlinePaymentID
				representURL := "Payments"
				resStatus, _, resData := libs.RequestXero(requestHeader, lang, "PUT", representURL, xeroPayment, nil, nil)
				//fmt.Println(resMsg)
				if resStatus == 200 {
					var xeroPaymentRes models.XeroPaymentResponse
					json.Unmarshal([]byte(string(resData)), &xeroPaymentRes)
					if len(xeroPaymentRes.Payments) > 0 {
						paymentObj := xeroPaymentRes.Payments[0]
						jobModel.ErpInvoiceStatus = &paymentObj.Invoice.Status
						db.Save(&jobModel)
						db.Where("PaymentDetailID = ?", paymentDetail.PaymentDetailID).
							Model(&models.PaymentDetail{}).Updates(models.PaymentDetail{AssignedInvoice: true, ModifiedBy: accountKey})
					}
				}
			}
		}
	}
}

// GenerateXeroCreditNote func
func GenerateXeroCreditNote(requestHeader models.RequestHeader, lang string, jobID int) (int, string, interface{}) {
	var (
		status               = 200
		msg                  string
		xeroConfig           models.XeroConfig
		creditNotePOST       models.XeroCreditNoteJPPOST
		dataRes              map[string]interface{}
		jobModel             models.Job
		jobDetails           []models.JobDetail
		businessPartnerModel models.BusinessPartner
		data                 interface{}
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	resultFindXeroConfig := db.First(&xeroConfig)
	if resultFindXeroConfig.RowsAffected > 0 {
		if xeroConfig.IsActive {
			if !xeroConfig.IsCreditNoteEnabled {
				status = 422
				msg = services.GetMessage(lang, "api.xeroconfig_iscreditnote_not_enabled")
			}
		} else {
			status = 422
			msg = services.GetMessage(lang, "api.xeroconfig_not_active")
		}
	} else {
		status = 422
		msg = services.GetMessage(lang, "api.xeroconfig_not_found")
	}

	if status == 200 {
		// @TODO hardcode AccountCode = 200
		//accountCode := "200"
		// @TODO mapping job data to creditnote json
		resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected > 0 {
			xeroCreditNoteType := os.Getenv("XERO_CREDITNOTE_TYPE")
			creditNotePOST.Type = &xeroCreditNoteType
			if xeroConfig.CreditNoteNumberGeneration != "" {
				creditNotePOST.CreditNoteNumber = &xeroConfig.CreditNoteNumberGeneration
			}
			//creditNotePOST.Reference =
			creditNotePOST.BrandingThemeID = &xeroConfig.Branding
			resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartnerModel)
			if resultFindBusinessPartner.RowsAffected > 0 {
				creditNotePOST.Contact.ContactID = &businessPartnerModel.ErpKey
			}
			if jobModel.JobDate != nil {
				dJobDate := *jobModel.JobDate
				sJobDate := dJobDate.Format("2006-01-02T15:04:05")
				creditNotePOST.DateString = &sJobDate
			}
			var settingModel models.Setting
			resultFindSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
			if resultFindSetting.RowsAffected > 0 {
				if settingModel.Value != nil {
					var (
						settingValue models.SettingValue
					)
					errSettingValue := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
					if errSettingValue == nil {
						//creditNotePOST.CurrencyCode =
					}
				}
			}
			//creditNotePOST.Status =

			db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobDetails)
			var lineItems = make([]models.XeroCreditNoteItem, 0)
			for _, jobDetail := range jobDetails {
				var lineItem models.XeroCreditNoteItem
				var itemModel models.Item
				resultFindItem := db.Where("ItemID = ?", jobDetail.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&itemModel)
				if resultFindItem.RowsAffected > 0 {
					if itemModel.ErpKey != "" && itemModel.Code != "" {
						lineItem.ItemCode = &itemModel.Code
					}
				}
				/* if strings.ToLower(xeroConfig.PostedInvoiceStatus) != strings.ToLower("DRAFT") {
					lineItem.AccountCode = &accountCode
				} */
				lineItem.Description = &jobDetail.Description
				lineItem.Quantity = &jobDetail.Quantity
				lineItem.UnitAmount = &jobDetail.UnitPrice
				sDiscountAmount := fmt.Sprintf("%f", jobDetail.DiscountAmount)
				lineItem.DiscountAmount = &sDiscountAmount
				sLineAmount := fmt.Sprintf("%f", jobDetail.LineTotal)
				lineItem.LineAmount = &sLineAmount
				lineItems = append(lineItems, lineItem)
			}
			creditNotePOST.LineItems = lineItems
			requestBody := creditNotePOST
			representURL := "CreditNotes"
			resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			if resStatus == 200 {
				json.Unmarshal([]byte(string(resData)), &dataRes)
				var creditNotesRes = make([]interface{}, 0)
				objectJSON, errJSON := json.Marshal(dataRes["CreditNotes"])
				if errJSON == nil {
					json.Unmarshal(objectJSON, &creditNotesRes)
					if len(creditNotesRes) > 0 {
						data = creditNotesRes[0]
						// @TODO update CreditNoteID to jobs
						var mapCreditNote map[string]interface{}
						mapCreditNoteJSON, errMapCreditNote := json.Marshal(creditNotesRes[0])
						if errMapCreditNote == nil {
							json.Unmarshal(mapCreditNoteJSON, &mapCreditNote)
							fCreditNoteKey, errCreditNoteKey := mapCreditNote["CreditNoteID"]
							if errCreditNoteKey {
								vCreditNoteKey := fmt.Sprintf("%v", fCreditNoteKey)
								jobModel.ErpCreditNoteKey = &vCreditNoteKey
								db.Save(&jobModel)
							}
						}
					}
				} else {
					status = 500
					msg = errJSON.Error()
				}
			} else {
				status = resStatus
				msg = fmt.Sprintf("%v", resMsg)
			}
		} else {
			status = 404
			msg = services.GetMessage(lang, "api.jobid_not_found")
		}
	}
	return status, msg, data
}

// ConvertArrayInProgressJobsToArrayResponse func
func ConvertArrayInProgressJobsToArrayResponse(requestHeader models.RequestHeader, items []models.Job, lang string) []models.InProgressJobResponse {
	responses := make([]models.InProgressJobResponse, 0)
	for _, item := range items {
		response := ConvertInProgressToResponse(requestHeader, item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertInProgressToResponse func
func ConvertInProgressToResponse(requestHeader models.RequestHeader, item models.Job, lang string) models.InProgressJobResponse {
	var (
		response        models.InProgressJobResponse
		businessPartner models.BusinessPartner
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.JobID = item.JobID
	response.JobNumber = item.JobNumber
	response.Status = item.Status
	response.StatusName, response.StatusIcon = libs.GetEnum(requestHeader, item.Status, "JobStatus", lang)
	response.JobType = item.JobType
	response.JobTypeName, response.JobTypeIcon = libs.GetEnum(requestHeader, item.JobType, "JobType", lang)
	response.JobDate = item.JobDate
	response.LocationID = item.LocationID
	resultFindBP := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
	if resultFindBP.RowsAffected > 0 {
		response.CompanyName = businessPartner.CompanyName
		response.FirstName = businessPartner.FirstName
		response.LastName = businessPartner.LastName
	}
	jobTasks := make([]models.JobTaskForJobListResponse, 0)
	for _, jt := range item.JobTasks {
		var (
			jobTask models.JobTaskForJobListResponse
		)
		if jt.Status != 4 {
			jobTask.JobTaskID = jt.JobTaskID
			jobTask.JobType = jt.JobType
			jobTask.JobTypeName, jobTask.JobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
			jobTask.Status = jt.Status
			jobTask.StatusName, jobTask.StatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
			jobTask.NavigationAddress = jt.NavigationAddress
			jobTask.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
			jobTask.FormFlowID = jt.FormFlowID

			jobTask.ScheduleStartDateTime = jt.ScheduleStartDateTime
			jobTask.ScheduleEndDateTime = jt.ScheduleEndDateTime
			jobTask.DepartureDateTime = jt.DepartureDateTime
			jobTask.EstimatedArrivalDateTime = jt.EstimatedArrivalDateTime
			jobTask.ArrivalDateTime = jt.ArrivalDateTime
			jobTask.StartDateTime = jt.StartDateTime
			jobTask.EndDateTime = jt.EndDateTime
			jobTask.AdditionalInformation = jt.AdditionalInformation
			jobTasks = append(jobTasks, jobTask)
		}
	}
	response.JobTasks = &jobTasks

	var jobTotalResponse models.JobTotalResponse
	jobTotalResponse.Subtotal = item.Subtotal
	jobTotalResponse.TotalTax = item.TotalTax
	jobTotalResponse.TotalTravelAmount = item.TravelTimeCharge + item.DistanceCharge
	jobTotalResponse.TravelTimeTaxAmount = item.TravelTimeChargeTaxRate / 100 * (item.TravelTimeCharge)
	jobTotalResponse.TravelTimeChargeTaxRate = item.TravelTimeChargeTaxRate
	jobTotalResponse.DistanceTaxAmount = item.DistanceChargeTaxRate / 100 * (item.DistanceCharge)
	jobTotalResponse.DistanceChargeTaxRate = item.DistanceChargeTaxRate
	jobTotalResponse.TotalDiscountAmount = item.TotalDiscountAmount
	jobTotalResponse.TotalBufferAmount = item.TotalBufferAmount
	jobTotalResponse.TotalJob = item.TotalJob
	response.JobTotal = jobTotalResponse

	return response
}

// ConvertArrayJobListToArrayResponse func
func ConvertArrayJobListToArrayResponse(requestHeader models.RequestHeader, items []models.Job, lang string, isUpdate bool) []models.JobListResponse {
	responses := make([]models.JobListResponse, 0)
	for _, item := range items {
		response := ConvertJobListToResponse(requestHeader, item, lang, isUpdate)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJobListToResponse func
func ConvertJobListToResponse(requestHeader models.RequestHeader, item models.Job, lang string, isUpdate bool) models.JobListResponse {
	var (
		response models.JobListResponse
	)
	// TravelCalculation
	response.JobID = item.JobID
	response.JobType = item.JobType
	response.JobTypeName, response.JobTypeIcon = libs.GetEnum(requestHeader, item.JobType, "JobType", lang)
	response.LocationID = item.LocationID
	response.Status = item.Status
	response.StatusName, response.StatusIcon = libs.GetEnum(requestHeader, item.Status, "JobStatus", lang)
	response.InProgressStatus = item.InProgressStatus
	response.JobTaskStatus = item.JobTaskStatus
	response.EstimateDate = item.EstimateDate
	response.InvoiceDate = item.InvoiceDate
	response.CreditNoteDate = item.CreditNoteDate
	response.EstimateDueDate = item.EstimateDueDate
	response.InvoiceDueDate = item.InvoiceDueDate
	response.CustomerApprovalDate = item.CustomerApprovalDate
	response.ManagerApprovalDate = item.ManagerApprovalDate
	response.RejectedDate = item.RejectedDate
	response.EstimatedDistance = item.EstimatedDistance
	response.EstimatedTravelTime = item.EstimatedTravelTime

	if len(item.JobTasks) > 0 && item.JobType != 4 {
		jt := item.JobTasks[0]
		response.JobTaskID = jt.JobTaskID
		response.NavigationAddress = jt.NavigationAddress
		response.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
		response.FormFlowID = jt.FormFlowID
		response.ScheduleStartDateTime = jt.ScheduleStartDateTime
		response.ScheduleEndDateTime = jt.ScheduleEndDateTime
		response.DepartureDateTime = jt.DepartureDateTime
		response.EstimatedArrivalDateTime = jt.EstimatedArrivalDateTime
		response.ArrivalDateTime = jt.ArrivalDateTime
		response.StartDateTime = jt.StartDateTime
		response.EndDateTime = jt.EndDateTime
		response.AdditionalInformation = jt.AdditionalInformation
		response.JobTimeInSeconds = jt.JobTimeInSeconds
		response.TaskJobType = jt.JobType
		response.TaskJobTypeName, response.TaskJobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
		response.TaskStatus = jt.Status
		response.TaskStatusName, response.TaskStatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
	} else if len(item.JobTasks) > 1 && item.JobType == 4 {

		for _, jt := range item.JobTasks {
			if jt.JobType == 2 {
				response.JobTaskID = jt.JobTaskID
				response.Status = jt.Status
				response.NavigationAddress = jt.NavigationAddress
				response.ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				response.FormFlowID = jt.FormFlowID
				response.ScheduleStartDateTime = jt.ScheduleStartDateTime
				response.ScheduleEndDateTime = jt.ScheduleEndDateTime
				response.DepartureDateTime = jt.DepartureDateTime
				response.EstimatedArrivalDateTime = jt.EstimatedArrivalDateTime
				response.ArrivalDateTime = jt.ArrivalDateTime
				response.StartDateTime = jt.StartDateTime
				response.EndDateTime = jt.EndDateTime
				response.AdditionalInformation = jt.AdditionalInformation
				response.JobTimeInSeconds = jt.JobTimeInSeconds
				response.TaskJobType = jt.JobType
				response.TaskJobTypeName, response.TaskJobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
				response.TaskStatus = jt.Status
				response.TaskStatusName, response.TaskStatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
			} else if jt.JobType == 3 {
				response.Task2JobTaskID = jt.JobTaskID
				response.Task2Status = jt.Status
				response.Task2NavigationAddress = jt.NavigationAddress
				response.Task2ServiceTimeInMinutes = jt.ServiceTimeInMinutes
				response.Task2FormFlowID = jt.FormFlowID
				response.Task2ScheduleStartDateTime = jt.ScheduleStartDateTime
				response.Task2ScheduleEndDateTime = jt.ScheduleEndDateTime
				response.Task2DepartureDateTime = jt.DepartureDateTime
				response.Task2EstimatedArrivalDateTime = jt.EstimatedArrivalDateTime
				response.Task2ArrivalDateTime = jt.ArrivalDateTime
				response.Task2StartDateTime = jt.StartDateTime
				response.Task2EndDateTime = jt.EndDateTime
				response.Task2AdditionalInformation = jt.AdditionalInformation
				response.Task2JobTimeInSeconds = jt.JobTimeInSeconds
				response.Task2JobType = jt.JobType
				response.Task2JobTypeName, response.Task2JobTypeIcon = libs.GetEnum(requestHeader, jt.JobType, "JobType", lang)
				response.Task2Status = jt.Status
				response.Task2StatusName, response.Task2StatusIcon = libs.GetEnum(requestHeader, jt.Status, "JobStatus", lang)
			}
		}
	}

	return response
}

func CalculateJobPrice(requestHeader models.RequestHeader, pricePOST models.GetPricePOST, job models.Job) models.GetPriceResponse {
	var (
		priceResponse           models.GetPriceResponse
		priceListTravelMatrix   models.PriceListTravelMatrix
		taxes                   []models.Tax
		jobSubTotal             float64
		jobTotalTax             float64
		jobTotal                float64
		totalDiscount           float64
		totalBuffer             float64
		distanceChargeTaxRate   float64
		travelTimeChargeTaxRate float64
		distanceTaxInclude      bool
		travelTimeTaxInclude    bool
		serviceTaxInclude       bool
		priceListTaxInclude     bool
		totalTravelAmount       float64
		travelTimeTaxAmount     float64
		distanceTaxAmount       float64
		isSuburb                bool
		isInspection            bool
		isJob                   bool
	)
	if job.JobID > 0 {
		isJob = job.IsJob
		isInspection = job.IsInspection
		if len(job.JobTasks) > 0 {
			isSuburb = job.JobTasks[0].IsSuburb
		}
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	priceListTravelMatrix.TravelCalculationDetail = []models.TravelCalculationDetail{}
	if len(pricePOST.Items) > 0 {
		priceListID := 0
		var (
			customerModel         models.BusinessPartner
			customerGroupModel    models.CustomerGroup
			travelDistanceAmounts []float64
			travelTimeAmounts     []float64
			priceList             models.PriceList
		)
		travelTimeAmounts = make([]float64, 0)
		travelDistanceAmounts = make([]float64, 0)
		// Get Price List ID from Customer
		resultFindCustomer := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND BusinessPartnerID = ?", pricePOST.BusinessPartnerID).First(&customerModel)
		if resultFindCustomer.RowsAffected > 0 {
			if customerModel.PriceListID != nil && *customerModel.PriceListID > 0 {
				priceListID = *customerModel.PriceListID
			} else {
				// Get Price List ID from Customer Group
				resultFindCustomerGroup := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND CustomerGroupID = ?", customerModel.CustomerGroupID).
					First(&customerGroupModel)
				if resultFindCustomerGroup.RowsAffected > 0 {
					if customerGroupModel.PriceListID != nil && *customerGroupModel.PriceListID > 0 {
						priceListID = *customerGroupModel.PriceListID
					}
				}
			}
		}

		//totalDistancePrice := 0.0
		if priceListID > 0 {
			for k, item := range pricePOST.Items {
				var (
					priceList                    models.PriceList
					applyPriceList               models.PriceListDetail
					servicePriceListDetail       models.ServicePriceListDetail
					distancePriceListDetail      models.DistancePriceListDetail
					travelTimeChargeMatrixDetail models.TravelCalculationDetail
					travelTimeChargeMatrix       models.TravelTimeChargeMatrix
					servicePriceList             models.ServicePriceList
					distancePriceList            models.DistancePriceList
					hasPriceList                 = false
					itemDB                       models.Item
				)

				if item.SurchargeParentItemID == 0 {
					today := time.Now()
					// Check if Price List has special Price List
					resultFindSpecial := db.Joins("JOIN pricelists on pricelists.PriceListID = pricelistdetails.PriceListID").
						Where("IFNULL(pricelists.IsDeleted, 0) <> 1 AND IFNULL(pricelists.IsArchived, 0) <> 1 AND IFNULL(pricelists.IsSpecial, 0) = 1 AND pricelists.SpecialToPricelistID = ? AND pricelistdetails.ItemID = ?", priceListID, item.ItemID).
						Where("DATE_FORMAT(FromDate,'%Y-%m-%d') <= DATE_FORMAT(?,'%Y-%m-%d')  AND DATE_FORMAT(ToDate,'%Y-%m-%d') >= DATE_FORMAT(?,'%Y-%m-%d')", today, today).First(&applyPriceList)
					if resultFindSpecial.RowsAffected <= 0 {
						// Get Price List
						resultFindSpecialTo := db.Joins("JOIN pricelists on pricelists.PriceListID = pricelistdetails.PriceListID").
							Where("IFNULL(pricelists.IsDeleted, 0) <> 1 AND IFNULL(pricelists.IsArchived, 0) <> 1 AND pricelists.PriceListID = ? AND pricelistdetails.ItemID = ?", priceListID, item.ItemID).First(&applyPriceList)
						if resultFindSpecialTo.RowsAffected > 0 {
							hasPriceList = true
						}
					} else {
						hasPriceList = true
					}

					// Get price list detail
					db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND PriceListID = ?",
						priceListID).First(&priceList)
					priceListTaxInclude = priceList.IsIncludeTax

					resultFindItem := db.Where("ItemID = ?", item.ItemID).First(&itemDB)
					if resultFindItem.RowsAffected > 0 {
						for i := range taxes {
							if taxes[i].TaxID == itemDB.TaxID {
								pricePOST.Items[k].TaxRate = taxes[i].TaxRate
								break
							}
						}
					}

					// servicepricelist => Update for service item ONLY
					if item.ParentItemID > 0 {
						if !item.IsUpdated {
							var (
								applyServicePriceList models.PriceListDetail
							)
							resultFindSpecial := db.Joins("JOIN pricelists on pricelists.PriceListID = pricelistdetails.PriceListID").
								Where("IFNULL(pricelists.IsDeleted, 0) <> 1 AND IFNULL(pricelists.IsArchived, 0) <> 1 AND IFNULL(pricelists.IsSpecial, 0) = 1 AND pricelists.SpecialToPricelistID = ?", priceListID).First(&applyServicePriceList)
							if resultFindSpecial.RowsAffected <= 0 {
								db.Joins("JOIN pricelists on pricelists.PriceListID = pricelistdetails.PriceListID").
									Where("IFNULL(pricelists.IsDeleted, 0) <> 1 AND IFNULL(pricelists.IsArchived, 0) <> 1 AND pricelists.PriceListID = ?", priceListID).First(&applyServicePriceList)
							}
							resultFindServicePriceDetail := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ServicePriceListID = ? AND ItemID = ?",
								applyServicePriceList.ServicePriceListID, item.ItemID).First(&servicePriceListDetail)
							if resultFindServicePriceDetail.RowsAffected > 0 {

								// Get service price list
								db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ServicePriceListID = ?",
									applyServicePriceList.ServicePriceListID).First(&servicePriceList)
								serviceTaxInclude = servicePriceList.IsIncludeTax

								hasPriceList = true
								price := servicePriceListDetail.Price // @TODO - Calculate TAX
								pricePOST.Items[k].UnitPrice = price

								pricePOST.Items[k].Quantity = servicePriceListDetail.DefaultQuantity
								pricePOST.Items[k].DiscountPercent = servicePriceListDetail.DiscountPercent
								pricePOST.Items[k].BufferPercent = servicePriceListDetail.BufferPercent
								// Calculate discount & buffer
								discountAmount := servicePriceListDetail.Price * (pricePOST.Items[k].DiscountPercent / 100)
								bufferAmount := servicePriceListDetail.Price * (pricePOST.Items[k].BufferPercent / 100)
								pricePOST.Items[k].UnitPrice = pricePOST.Items[k].UnitPrice - discountAmount + bufferAmount
							}
						}
					} else {
						if hasPriceList {
							// distancepricelist
							distanceAmount := 0.0
							if pricePOST.ChargeTravelDistance {
								travelDistance := pricePOST.TravelDistance / 1000
								resultFindDistacePriceDetail := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DistancePriceListID = ? AND FromUnit <= ? AND ? <= ToUnit",
									applyPriceList.DistancePriceListID, math.Round(travelDistance), math.Round(travelDistance)).First(&distancePriceListDetail)
								if resultFindDistacePriceDetail.RowsAffected > 0 {

									// Get Distance Price List
									db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND DistancePriceListID = ?",
										applyPriceList.DistancePriceListID).First(&distancePriceList)
									distanceTaxInclude = distancePriceList.IsIncludeTax
									for i := range taxes {
										if taxes[i].TaxID == distancePriceList.TaxID {
											distanceChargeTaxRate = taxes[i].TaxRate
											break
										}
									}
									rate := distancePriceListDetail.Rate // @TODO - Calculate TAX
									taxAmount := ((rate * distanceChargeTaxRate) / 100)
									rate = rate + taxAmount

									if distancePriceListDetail.IsRateByRange {
										distanceAmount = rate
									} else {
										distanceAmount = rate * travelDistance
									}

									discountAmt := ((distanceAmount * distancePriceListDetail.DiscountPercent) / 100)
									bufferAmt := ((distanceAmount * distancePriceListDetail.BufferPercent) / 100)
									distanceAmount = distanceAmount - discountAmt + bufferAmt
									travelDistanceAmounts = append(travelDistanceAmounts, distanceAmount)
								}
							}

							// travel time charge matrix
							travelTimeAmount := 0.0
							if pricePOST.ChargeTravelTime {
								resultFindTravelTimeMatrix := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND TravelTimeChargeMatrixID = ?",
									applyPriceList.TravelTimeChargeMatrixID).First(&travelTimeChargeMatrix)
								if resultFindTravelTimeMatrix.RowsAffected > 0 {
									travelTimeTaxInclude = travelTimeChargeMatrix.IsIncludeTax
									for i := range taxes {
										if taxes[i].TaxID == travelTimeChargeMatrix.TaxID {
											travelTimeChargeTaxRate = taxes[i].TaxRate
											break
										}
									}
									var travelTime float64
									if travelTimeChargeMatrix.Unit == 1 { // Hour
										travelTime = pricePOST.TravelTime / 3600
									} else if travelTimeChargeMatrix.Unit == 2 { // Minute
										travelTime = pricePOST.TravelTime / 60
									} else if travelTimeChargeMatrix.Unit == 3 { // Second
										travelTime = pricePOST.TravelTime
									}
									price := travelTimeChargeMatrix.Price // @TODO - Calculate TAX
									taxAmount := ((price * travelTimeChargeTaxRate) / 100)
									price = price + taxAmount
									travelTimeAmount = travelTime * price
									discountAmt := ((travelTimeAmount * travelTimeChargeMatrix.DiscountPercent) / 100)
									bufferAmt := ((travelTimeAmount * travelTimeChargeMatrix.BufferPercent) / 100)
									travelTimeAmount = travelTimeAmount - discountAmt + bufferAmt

									travelTimeAmounts = append(travelTimeAmounts, travelTimeAmount)
									// Update amount for Suburb
								}
							}
							if resultFindItem.RowsAffected > 0 {
								travelTimeChargeMatrixDetail.Description = itemDB.Description
								travelTimeChargeMatrixDetail.ItemCode = itemDB.Code
								travelTimeChargeMatrixDetail.ItemName = itemDB.Name
							}
							travelTimeChargeMatrixDetail.ItemID = item.ItemID
							travelTimeChargeMatrixDetail.TravelDistanceAmount = distanceAmount
							travelTimeChargeMatrixDetail.TravelTimeAmount = travelTimeAmount

							priceListTravelMatrix.TravelCalculationDetail = append(priceListTravelMatrix.TravelCalculationDetail, travelTimeChargeMatrixDetail)

							// Get Item Price from Price List level
							if !pricePOST.Items[k].IsUpdated {

								price := applyPriceList.Price // @TODO - Calculate TAX
								pricePOST.Items[k].UnitPrice = price

								pricePOST.Items[k].Quantity = applyPriceList.DefaultQuantity
								pricePOST.Items[k].DiscountPercent = applyPriceList.DiscountPercent
								pricePOST.Items[k].BufferPercent = applyPriceList.BufferPercent

								// Calculate discount & buffer
								discountAmount := applyPriceList.Price * (pricePOST.Items[k].DiscountPercent / 100)
								bufferAmount := applyPriceList.Price * (pricePOST.Items[k].BufferPercent / 100)
								pricePOST.Items[k].UnitPrice = pricePOST.Items[k].UnitPrice - discountAmount + bufferAmount
							}
						}
					}
					//Get Item Price from Item level
					if !hasPriceList {
						if !pricePOST.Items[k].IsUpdated {
							var (
								itemModel models.Item
							)
							resultFindItem := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ItemID = ? AND Code = ?", item.ItemID, item.ItemCode).
								First(&itemModel)
							if resultFindItem.RowsAffected > 0 {
								pricePOST.Items[k].UnitPrice = itemModel.UnitPrice
								pricePOST.Items[k].Quantity = itemModel.QuantityOnHand
								pricePOST.Items[k].DiscountPercent = 0
								pricePOST.Items[k].BufferPercent = 0
							}
						}
					}
				}
			}
		} else {
			for k, item := range pricePOST.Items {
				if item.SurchargeParentItemID == 0 {
					var (
						itemModel models.Item
					)
					resultFindItem := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ItemID = ?", item.ItemID).First(&itemModel)
					if resultFindItem.RowsAffected > 0 {
						for i := range taxes {
							if taxes[i].TaxID == itemModel.TaxID {
								pricePOST.Items[k].TaxRate = taxes[i].TaxRate
								break
							}
						}
					}
				}
			}
		}
		if priceListID > 0 { // Check Combined Mode
			// Get Price List By ID
			resultFindPriceList := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND PriceListID = ?", priceListID).
				First(&priceList)
			if resultFindPriceList.RowsAffected > 0 {
				if travelDistanceAmounts != nil && travelTimeAmounts != nil {
					if len(travelDistanceAmounts) > 1 {
						if priceList.TravelCalculationMode == 1 { // higher
							_, priceResponse.TravelDistanceAmount = libs.MinMax(travelDistanceAmounts)
							priceListTravelMatrix.TravelCalculationMode = "Higher"
						} else if priceList.TravelCalculationMode == 2 { // sum
							priceResponse.TravelDistanceAmount = libs.SUM(travelDistanceAmounts)
							priceListTravelMatrix.TravelCalculationMode = "SUM"

						} else if priceList.TravelCalculationMode == 3 { // average
							priceResponse.TravelDistanceAmount = libs.Average(travelDistanceAmounts)
							priceListTravelMatrix.TravelCalculationMode = "Average"
						}
					} else {
						if len(travelDistanceAmounts) > 0 {
							priceResponse.TravelDistanceAmount = travelDistanceAmounts[0]
						}
					}
					if len(travelTimeAmounts) > 1 {
						if priceList.TravelCalculationMode == 1 { // higher
							_, priceResponse.TravelTimeAmount = libs.MinMax(travelTimeAmounts)
							priceListTravelMatrix.TravelCalculationMode = "Higher"
						} else if priceList.TravelCalculationMode == 2 { // sum
							priceResponse.TravelTimeAmount = libs.SUM(travelTimeAmounts)
							priceListTravelMatrix.TravelCalculationMode = "SUM"

						} else if priceList.TravelCalculationMode == 3 { // average
							priceResponse.TravelTimeAmount = libs.Average(travelTimeAmounts)
							priceListTravelMatrix.TravelCalculationMode = "Average"
						}
					} else {

						if len(travelTimeAmounts) > 0 {
							priceResponse.TravelTimeAmount = travelTimeAmounts[0]
						}
					}
				}
			}
		}

		// Update amount for Suburb
		if job.JobID > 0 {
			if isJob {
				if isSuburb {
					if !isInspection {
						priceResponse.TravelDistanceAmount = job.DistanceCharge
						priceResponse.TravelTimeAmount = job.TravelTimeCharge
					}
				}
			}
		}

		for k := range pricePOST.Items {
			item := pricePOST.Items[k]
			if !item.IsUpdated {
				item.DiscountPercent = 0
				item.BufferPercent = 0
				item.DiscountAmount = 0
				item.BufferAmount = 0
			}
			item.LineSubTotal = item.UnitPrice * item.Quantity
			item.DiscountAmount = item.LineSubTotal * (item.DiscountPercent / 100)
			item.BufferAmount = item.LineSubTotal * (item.BufferPercent / 100)
			item.LineTotalTaxExcluded = item.LineSubTotal - item.DiscountAmount + item.BufferAmount
			item.LineTotalTax = item.LineTotalTaxExcluded * (item.TaxRate / 100)
			item.LineTotal = item.LineTotalTaxExcluded + item.LineTotalTax
			jobSubTotal += item.LineTotalTaxExcluded
			jobTotalTax += item.LineTotalTax
			totalDiscount += item.DiscountAmount
			totalBuffer += item.BufferAmount
			pricePOST.Items[k] = item
		}
	}
	travelDistanceAmount := libs.ToFixedPlaces(priceResponse.TravelDistanceAmount, 2)
	travelTimeAmount := libs.ToFixedPlaces(priceResponse.TravelTimeAmount, 2)

	travelTimeTaxAmount = travelTimeAmount * (travelTimeChargeTaxRate / 100)
	distanceTaxAmount = travelDistanceAmount * (distanceChargeTaxRate / 100)
	jobTotalTax += travelTimeTaxAmount + distanceTaxAmount
	jobTotal = jobSubTotal + jobTotalTax + travelDistanceAmount + travelTimeAmount // @TODO - Include Total Travel

	priceResponse.BusinessPartnerID = pricePOST.BusinessPartnerID
	priceResponse.Items = pricePOST.Items
	priceResponse.TravelDistance = pricePOST.TravelDistance
	priceResponse.TravelTime = pricePOST.TravelTime
	priceResponse.TravelCalculation = priceListTravelMatrix
	priceResponse.SubTotal = jobSubTotal
	priceResponse.TotalTax = jobTotalTax
	priceResponse.TotalJob = jobTotal
	priceResponse.TotalDiscountAmount = totalDiscount
	priceResponse.TotalBufferAmount = totalBuffer

	priceResponse.TravelDistanceAmount = travelDistanceAmount
	priceResponse.TravelTimeAmount = travelTimeAmount

	totalTravelAmount = priceResponse.TravelDistanceAmount + priceResponse.TravelTimeAmount
	priceResponse.TotalTravelAmount = totalTravelAmount
	priceResponse.DistanceChargeTaxRate = distanceChargeTaxRate
	priceResponse.TravelTimeChargeTaxRate = travelTimeChargeTaxRate
	priceResponse.TravelTimeTaxAmount = travelTimeTaxAmount
	priceResponse.DistanceTaxAmount = distanceTaxAmount

	priceResponse.DistanceChargeIncludeTax = distanceTaxInclude
	priceResponse.TravelTimeIncludeTax = travelTimeTaxInclude
	priceResponse.PriceListIncludeTax = serviceTaxInclude
	priceResponse.ServiceIncludeTax = priceListTaxInclude
	return priceResponse
}
