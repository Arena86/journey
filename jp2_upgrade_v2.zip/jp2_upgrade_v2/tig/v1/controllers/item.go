package controllers

import (
	"encoding/json"
	"fmt"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetItem godoc
// @Summary Get Item
// @Description Get Item
// @Tags Item
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /item [get]
func GetItem(c *gin.Context) {
	defer libs.RecoverError(c, "GetItem")
	var (
		status        = libs.GetStatusSuccess()
		items         []models.Item
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	getAll := false
	// Paging
	vShowAll, sShowAll := libs.GetQueryParam("ShowAll", c)

	if sShowAll {
		bShowAll, eShowAll := strconv.ParseBool(vShowAll)
		if eShowAll == nil {
			getAll = bShowAll
		}
	}
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	onlyServiceItem := false
	vServiceItem, sServiceItem := libs.GetQueryParam("ServiceItem", c)

	if sServiceItem {
		bServiceItem, eServiceItem := strconv.ParseBool(vServiceItem)
		if eServiceItem == nil {
			onlyServiceItem = bServiceItem
		}
	}
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	var bp = db
	if !getAll {
		bp = bp.Where("IFNULL(IsHidden, 0) = 0")
	}

	if onlyServiceItem {
		bp = bp.Where("ItemType = 2")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	bp = bp.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("RelatedItems", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter
	arrBool := []string{"IsTrackedAsInventory"}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"Code", "Name", "Description", "TaxType", "TaxName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrFloat := []string{"UnitPrice", "TaxRate", "QuantityOnHand"}
	bp = libs.FilterFloat(arrFloat, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.Item{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c, "TaxRate")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&items).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(items) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayItemsToArrayResponse(requestHeader, items, lang)

	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Item{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemID", v.DataType, b.ItemID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetItemByID godoc
// @Summary Get Item By ID
// @Description Get Item  By ID
// @Tags Item
// @Accept  json
// @Produce  json
// @Param id path int true "Item ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /item/{id} [get]
func GetItemByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetItemByID")
	var (
		status        = libs.GetStatusSuccess()
		items         models.Item
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"RelatedItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND ItemID = ?", ID).First(&items)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertItemToResponse(requestHeader, items, lang)
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Item{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		itemsResponse.UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemID", v.DataType, itemsResponse.ItemID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			itemsResponse.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		itemsResponse.UDFs = udfResponses
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateItem godoc
// @Summary Create Item
// @Description Create Item
// @Tags Item
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Item body []models.Item true "Create Item"
// @Success 200 {object} models.APIResponseData
// @Router /item [post]
func CreateItem(c *gin.Context) {
	defer libs.RecoverError(c, "CreateItem")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Item
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Item, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.Item
			)
			item.PassBodyJSONToModel(bp)
			resultFindItem := db.Where("Code = ? AND IsDeleted = 0", item.Code).First(&models.Item{})
			if resultFindItem.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemcode_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}
			item.PassBodyJSONToModel(bp)
			item.CreatedBy = &accountKey
			item.ModifiedBy = &accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError      string
					createItemSuccess = false
				)
				item.RelatedItems = make([]models.RelatedItem, 0)
				var objects []map[string]interface{}
				_, res := services.ConvertJSONValueToVariable("RelatedItems", bp)
				if res != nil {
					objsJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(objsJSON, &objects)
						if len(objects) > 0 {
							objsValid := make([]models.RelatedItem, 0)
							for _, mObj := range objects {
								var obj models.RelatedItem
								obj.PassBodyJSONToModel(mObj)
								validate, trans := services.GetValidatorTranslate()
								err := validate.Struct(obj)
								if err != nil {
									errs := err.(validator.ValidationErrors)
									for _, e := range errs {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
									}
								} else {
									obj.CreatedBy = accountKey
									objsValid = append(objsValid, obj)
								}
							}
							item.RelatedItems = objsValid
						}
					}
				}

				// @TODO Update to xero
				var xeroConfig models.XeroConfig
				resultFindXeroConfig := db.First(&xeroConfig)
				if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
					items := make([]models.Item, 0)
					items = append(items, item)
					resultCreate := db.Create(&item)
					if resultCreate.Error == nil {
						xeroResponses := UpdateItemFromDatabaseToXero(requestHeader, lang, items)
						if len(xeroResponses) > 0 {
							itemResponse := xeroResponses[0]
							if itemResponse.Status == 200 {
								createItemSuccess = true
								var xeroItemResponse models.Item
								dataItem, errItem := json.Marshal(itemResponse.Data)
								if errItem == nil {
									json.Unmarshal(dataItem, &xeroItemResponse)
									item = xeroItemResponse
								}
							} else {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", itemResponse.Msg))
								item.IsIntegrationPending = true
								item.IntegrationError = fmt.Sprintf("%v", itemResponse.Msg)
								resultCreate := db.Save(&item)
								if resultCreate.Error == nil {
									createItemSuccess = true
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
								}
							}
						} else {
							// add error message
						}
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					}
				} else {
					resultCreate := db.Create(&item)
					if resultCreate.Error == nil {
						createItemSuccess = true
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
					}
				}
				// end
				if createItemSuccess {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, item)
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ItemID", item.ItemID)
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
						}
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Item
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ItemID)
	}
	if len(arrID) > 0 {
		db.Preload(
			"RelatedItems",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("ItemID in (?)", arrID).Find(&items)
		dataResponses := ConvertArrayItemsToArrayResponse(requestHeader, items, lang)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Item{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemID", v.DataType, b.ItemID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses

	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateItem godoc
// @Summary Update Item
// @Description Update Item
// @Tags Item
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Item body []models.Item true "Create Item"
// @Success 200 {object} models.APIResponseData
// @Router /item [put]
func UpdateItem(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateItem")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Item
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.Item, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				item models.Item
			)
			item.PassBodyJSONToModel(bp)
			resultFindItem := db.Where("Code = ? AND IsDeleted = 0 AND ItemID <> ?", item.Code, item.ItemID).First(&models.Item{})
			if resultFindItem.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemcode_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}
			resultFind := db.Where("ItemID = ?", item.ItemID).First(&item)
			item.PassBodyJSONToModel(bp)
			item.ModifiedBy = &accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(item)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError      string
					createItemSuccess = false
				)
				// @TODO validate for RelatedItems
				var (
					relatedItemToDeleteModels []models.RelatedItem
				)
				arrSkipID := make([]int, 0)
				arrToDeleteID := make([]int, 0)
				item.RelatedItems = make([]models.RelatedItem, 0)
				var objects []map[string]interface{}
				_, res := services.ConvertJSONValueToVariable("RelatedItems", bp)
				if res != nil {
					objsJSON, err := json.Marshal(res)
					if err == nil {
						json.Unmarshal(objsJSON, &objects)
						if len(objects) > 0 {
							objsValid := make([]models.RelatedItem, 0)
							for _, mObj := range objects {
								var obj models.RelatedItem
								obj.PassBodyJSONToModel(mObj)
								validate, trans := services.GetValidatorTranslate()
								err := validate.Struct(obj)
								if err != nil {
									errs := err.(validator.ValidationErrors)
									for _, e := range errs {
										itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Translate(trans))
									}
								} else {
									if resultFind.RowsAffected > 0 {
										db.Where("ItemID = ? AND RelatedItemID = ?", item.ItemID, obj.RelatedItemID).First(&obj)
										obj.PassBodyJSONToModel(mObj)
										obj.ModifiedBy = accountKey
										objsValid = append(objsValid, obj)
									} else {
										obj.CreatedBy = accountKey
										objsValid = append(objsValid, obj)
									}
								}
								if obj.RelatedItemID > 0 {
									arrSkipID = append(arrSkipID, obj.RelatedItemID)
								}
							}
							item.RelatedItems = objsValid
						}
					}
				}

				if item.ItemID > 0 {
					if len(arrSkipID) > 0 {
						// delete id not in arrSkipID
						db.Where("ItemID = ? AND RelatedItemID not in (?)", item.ItemID, arrSkipID).Find(&relatedItemToDeleteModels)
					} else {
						// delete all
						db.Where("ItemID = ?", item.ItemID).Find(&relatedItemToDeleteModels)
					}
				}

				for _, ad := range relatedItemToDeleteModels {
					arrToDeleteID = append(arrToDeleteID, ad.RelatedItemID)
				}

				// @TODO Update to xero
				var xeroConfig models.XeroConfig
				resultFindXeroConfig := db.First(&xeroConfig)
				if resultFindXeroConfig.RowsAffected > 0 && xeroConfig.IsActive {
					items := make([]models.Item, 0)
					items = append(items, item)
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
					if resultSave.Error == nil {
						xeroResponses := UpdateItemFromDatabaseToXero(requestHeader, lang, items)
						if len(xeroResponses) > 0 {
							itemResponse := xeroResponses[0]
							if itemResponse.Status == 200 {
								createItemSuccess = true
								var xeroItemResponse models.Item
								dataItem, errItem := json.Marshal(itemResponse.Data)
								if errItem == nil {
									json.Unmarshal(dataItem, &xeroItemResponse)
									item = xeroItemResponse
								}
							} else {
								itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", itemResponse.Msg))
								item.IsIntegrationPending = true
								item.IntegrationError = fmt.Sprintf("%v", itemResponse.Msg)
								resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
								if resultSave.Error == nil {
									createItemSuccess = true
								} else {
									itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
								}
							}
						} else {
							// add error message
						}
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}
				} else {
					resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&item)
					if resultSave.Error == nil {
						createItemSuccess = true
					} else {
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					}
				}
				// end
				if createItemSuccess {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, item)
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ItemID", item.ItemID)
					// @TODO delete address/phone
					if len(arrToDeleteID) > 0 {
						db.Where("RelatedItemID in (?)", arrToDeleteID).Delete(&models.RelatedItem{})
						//db.Where("RelatedItemID in (?)", arrToDeleteID).Model(&models.RelatedItem{}).Updates(models.RelatedItem{IsDeleted: true})
					}
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, e.Error())
						}
					}
				}

				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.Item
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ItemID)
	}
	if len(arrID) > 0 {
		db.Preload(
			"RelatedItems",
			"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
		).Where("ItemID in (?)", arrID).Find(&items)
		dataResponses := ConvertArrayItemsToArrayResponse(requestHeader, items, lang)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.Item{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)

			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemID", v.DataType, b.ItemID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateHiddenItems godoc
// @Summary Update Item
// @Description Update Item
// @Tags Item
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Item body []models.Item true "Create Item"
// @Success 200 {object} models.APIResponseData
// @Router /updatehiddenitems [put]
func UpdateHiddenItems(c *gin.Context) {
	defer libs.RecoverError(c, "updatehiddenitems")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)

	var objectsJSON models.HiddenItemPOST
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON.ItemIDs) > 0 {
		sql := `UPDATE ` + models.Item{}.TableName() + " SET IsHidden = 0, ModifiedBy = ? WHERE ItemID NOT IN  (?)"
		db.Exec(sql, accountKey, objectsJSON.ItemIDs)
		db.Where("ItemID IN (?)", objectsJSON.ItemIDs).Model(&models.Item{}).Updates(models.Item{IsHidden: true, ModifiedBy: &accountKey})
	} else {
		sql := `UPDATE ` + models.Item{}.TableName() + " SET IsHidden = 0, ModifiedBy = ?"
		db.Exec(sql, accountKey)
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, 1, 1, errorsResponse, false)
	var (
		items []models.Item
	)

	db.Preload(
		"RelatedItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Find(&items)
	dataResponses := ConvertArrayItemsToArrayResponse(requestHeader, items, lang)
	for i, b := range dataResponses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.Item{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)

		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemID", v.DataType, b.ItemID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		dataResponses[i].UDFs = udfResponses
	}
	data = dataResponses

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// DeleteItem godoc
// @Summary Delete Item
// @Description Delete Item
// @Tags Item
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Item ID"
// @Success 200 {object} models.APIResponseData
// @Router /item/{id} [delete]
func DeleteItem(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteItem")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArrayString(strID)
	for k, id := range arrID {
		var (
			uModel models.Item
		)
		resultFind := db.Where("ItemID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := uModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				uModel.IsDeleted = true
				uModel.ModifiedBy = &accountKey
				deletedResult := db.Save(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayItemsToArrayResponse func
func ConvertArrayItemsToArrayResponse(requestHeader models.RequestHeader, items []models.Item, lang string) []models.ItemResponse {
	itemResponses := make([]models.ItemResponse, 0)
	for _, item := range items {
		response := ConvertItemToResponse(requestHeader, item, lang)
		itemResponses = append(itemResponses, response)
	}
	return itemResponses
}

// ConvertItemToResponse func
func ConvertItemToResponse(requestHeader models.RequestHeader, item models.Item, lang string) models.ItemResponse {
	var (
		itemResponse models.ItemResponse
		tax          models.Tax
		itemTypeEnum models.Enumerator
		itemGroup    models.ItemGroup
	)

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	itemResponse.ItemID = item.ItemID
	itemResponse.ItemGroupID = item.ItemGroupID
	resultRow := db.Where("ItemGroupID = ?", item.ItemGroupID).First(&itemGroup)
	if resultRow.RowsAffected > 0 {
		itemResponse.ItemGroupName = itemGroup.ItemGroupName
		itemResponse.ItemGroupCode = itemGroup.ItemGroupCode
	}
	itemResponse.Code = item.Code
	itemResponse.Name = item.Name
	itemResponse.Description = item.Description
	itemResponse.UnitPrice = item.UnitPrice
	if item.TaxID > 0 {
		itemResponse.TaxID = &item.TaxID
	} else {
		itemResponse.TaxID = nil
	}
	itemResponse.IsTrackedAsInventory = item.IsTrackedAsInventory
	itemResponse.QuantityOnHand = item.QuantityOnHand
	itemResponse.ErpKey = item.ErpKey
	itemResponse.Cost = item.Cost
	itemResponse.ItemType = item.ItemType
	itemResponse.IsHidden = item.IsHidden
	itemResponse.ServiceTimeInMinutes = item.ServiceTimeInMinutes
	db.Where("FieldName = ? AND Status = ?", "ItemType", item.ItemType).First(&itemTypeEnum)
	if itemTypeEnum.TranslationKey != "" && itemTypeEnum.TranslationKey != services.GetMessage(lang, itemTypeEnum.TranslationKey) {
		itemResponse.ItemTypeName = services.GetMessage(lang, itemTypeEnum.TranslationKey)
	} else {
		itemResponse.ItemTypeName = itemTypeEnum.Caption
	}
	itemResponse.AutomaticallyIncludeInNewDocument = item.AutomaticallyIncludeInNewDocument
	resultFindTax := db.Where("TaxID = ? ", item.TaxID).First(&tax)
	if resultFindTax.RowsAffected > 0 {
		itemResponse.TaxType = tax.TaxType
		itemResponse.TaxName = tax.TaxName
		itemResponse.TaxRate = tax.TaxRate
	}
	storeItemID := make(map[int]int)
	itemResponse.RelatedItems = GetRelatedItemByItemID(requestHeader, lang, item.ItemID, storeItemID)
	itemResponse.ItemPurchaseAccountCode = item.ItemPurchaseAccountCode
	itemResponse.ItemSaleAccountCode = item.ItemSaleAccountCode
	itemResponse.InventoryAssetAccountCode = item.InventoryAssetAccountCode
	itemResponse.FourDPriceDynamicFormID = item.FourDPriceDynamicFormID
	return itemResponse
}

// GetRelatedItemByItemID func
func GetRelatedItemByItemID(requestHeader models.RequestHeader, lang string, itemID int, storeItemID map[int]int) []models.RelatedItemResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	var (
		item models.Item
	)
	relatedItems := make([]models.RelatedItemResponse, 0)

	// @TODO check repeat
	_, existItemID := storeItemID[itemID]
	if existItemID {
		return relatedItems
	}
	storeItemID[itemID] = itemID

	resultRow := db.Preload(
		"RelatedItems",
		"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
	).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ItemID = ?", itemID).First(&item)
	if resultRow.RowsAffected > 0 {
		if len(item.RelatedItems) <= 0 {
			return relatedItems
		}
		for _, v := range item.RelatedItems {
			var (
				relatedItem  models.RelatedItemResponse
				itemGroup    models.ItemGroup
				itemTypeEnum models.Enumerator
				itemModel    models.Item
				taxModel     models.Tax
			)

			relatedItem.RelatedItemID = v.RelatedItemID
			relatedItem.ItemID = v.ItemID
			relatedItem.ChildItemID = v.ChildItemID
			relatedItem.Quantity = v.Quantity
			relatedItem.Code = v.Code
			relatedItem.Name = v.Name
			relatedItem.Description = v.Description
			relatedItem.ItemGroupID = v.ItemGroupID
			relatedItem.FourDPriceDynamicFormID = v.FourDPriceDynamicFormID
			relatedItem.ServiceTimeInMinutes = v.ServiceTimeInMinutes
			resultFindItemGroup := db.Where("ItemGroupID = ? ", v.ItemGroupID).First(&itemGroup)
			if resultFindItemGroup.RowsAffected > 0 {
				relatedItem.ItemGroupName = itemGroup.ItemGroupName
			}
			relatedItem.ItemType = v.ItemType

			db.Where("FieldName = ? AND Status = ?", "ItemType", v.ItemType).First(&itemTypeEnum)
			if itemTypeEnum.TranslationKey != "" && itemTypeEnum.TranslationKey != services.GetMessage(lang, itemTypeEnum.TranslationKey) {
				relatedItem.ItemTypeName = services.GetMessage(lang, itemTypeEnum.TranslationKey)
			} else {
				relatedItem.ItemTypeName = itemTypeEnum.Caption
			}

			resultFindItem := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ItemID = ?", v.ChildItemID).First(&itemModel)
			if resultFindItem.RowsAffected > 0 {
				relatedItem.UnitPrice = itemModel.UnitPrice
				relatedItem.TaxID = itemModel.TaxID
				relatedItem.IsTrackedAsInventory = itemModel.IsTrackedAsInventory
				relatedItem.QuantityOnHand = itemModel.QuantityOnHand
				relatedItem.ErpKey = itemModel.ErpKey
				relatedItem.Cost = itemModel.Cost
				relatedItem.AutomaticallyIncludeInNewDocument = itemModel.AutomaticallyIncludeInNewDocument
				relatedItem.IsHidden = itemModel.IsHidden
			}
			resultFindTax := db.Where("TaxID = ? ", itemModel.TaxID).First(&taxModel)
			if resultFindTax.RowsAffected > 0 {
				relatedItem.TaxType = taxModel.TaxType
				relatedItem.TaxName = taxModel.TaxName
				relatedItem.TaxRate = taxModel.TaxRate
			}

			// @TODO check repeat
			_, existItemID := storeItemID[relatedItem.ChildItemID]
			if existItemID {
				return relatedItems
			}
			storeItemID[relatedItem.ChildItemID] = relatedItem.ChildItemID

			relatedItem.RelatedItems = GetRelatedItemByItemID(requestHeader, lang, relatedItem.ChildItemID, storeItemID)
			relatedItems = append(relatedItems, relatedItem)
		}
	}
	return relatedItems
}
