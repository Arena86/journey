package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// GetAllTaskScheduler func
func GetAllTaskScheduler(c *gin.Context) {
	funcLogName := "GetAllTaskScheduler"
	defer libs.RecoverError(c, funcLogName)
	var (
		status     = 200
		taskModels []models.TaskScheduler
		objSetting models.Timezone
		response   models.APIResponseData
		msg, data  interface{}
	)

	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	var bp = db
	arrString := []string{"Name", "Description"}
	bp = libs.FilterString(arrString, bp, c)
	bp.Find(&taskModels)
	resModels := make([]models.TaskSchedulerData, 0)
	db.First(&objSetting)
	for _, v := range taskModels {
		var (
			resModel        models.TaskSchedulerData
			afterTasksModel models.RunAfterTask
		)
		_, localOffset := time.Now().Zone()
		// Calculate TimeZone Offset
		if v.TaskExecuted != nil {
			taskExecuted := v.TaskExecuted.Add(-time.Duration(localOffset) * time.Second)
			v.TaskExecuted = &taskExecuted
		}
		if v.TaskEnded != nil {
			taskEnded := v.TaskEnded.Add(-time.Duration(localOffset) * time.Second)
			v.TaskEnded = &taskEnded
		}

		resModel = models.ConvertDBTaskSchedulerToTaskSchedulerData(v)
		resultFindAfter := db.Where("MainTask = ?", v.TaskID).First(&afterTasksModel)
		if resultFindAfter.RowsAffected > 0 {
			resModel.RunAfterTask = &afterTasksModel
		}
		resModels = append(resModels, resModel)
	}
	if status == 200 {
		data = resModels
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetTaskSchedulerByID func
func GetTaskSchedulerByID(c *gin.Context) {
	funcLogName := "GetTaskSchedulerByID"
	defer libs.RecoverError(c, funcLogName)
	var (
		status    = 200
		taskModel models.TaskScheduler
		response  models.APIResponseData
		msg, data interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultFind := db.Where("TaskID = ?", ID).First(&taskModel)
	if resultFind.RowsAffected > 0 {
		var (
			afterTasksModel models.RunAfterTask
		)
		resultFindAfter := db.Where("MainTask = ?", ID).First(&afterTasksModel)
		dataRes := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
		if resultFindAfter.RowsAffected > 0 {
			dataRes.RunAfterTask = &afterTasksModel
		}
		data = dataRes
	} else {
		status = 404
		msg = services.GetMessage(lang, "api.no_record_found")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateTaskScheduler func
func CreateTaskScheduler(c *gin.Context) {
	funcLogName := "CreateTaskScheduler"
	defer libs.RecoverError(c, funcLogName)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		status    = 200
		msg, data interface{}
		response  models.APIResponseData
		taskPOST  models.TaskSchedulerData
	)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	body, errBody := ioutil.ReadAll(c.Request.Body)
	if errBody == nil {
		json.Unmarshal([]byte(string(body)), &taskPOST)
		taskPOST.TaskID = 0
		taskModel := models.ConvertTaskSchedulerDataToDBTaskScheduler(taskPOST)
		// reset fields not need of runafter
		if taskModel.RunAfter {
			taskModel.TaskStartDate = nil
			taskModel.TaskEndDate = nil
			//taskModel.NextRun = nil
			taskModel.StartAtTime = nil
			taskModel.Repeat = nil
			taskModel.RepeatEvery = 0
			taskModel.PreviousDay = 0
			taskModel.RepeatOn = nil
			taskModel.RepeatOnDayMonth = 0
		}
		resultCreate := db.Create(&taskModel)
		if resultCreate.RowsAffected > 0 {
			if taskModel.IsRepeat {
				// sort
				repeatOn := ""
				if taskModel.RepeatOn != nil {
					repeatOn = *taskModel.RepeatOn
				}
				weekDayRepeatOn := strings.ToLower(repeatOn)
				arrDayRepeat := ConvertStringToArrayString(weekDayRepeatOn)
				if len(arrDayRepeat) > 0 {
					arrDayRepeat = UniqueDayRepeatInArray(arrDayRepeat)
					arrDayRepeat = SortArrayDayRepeat(arrDayRepeat)
					strRepeatOnSorted := strings.Join(arrDayRepeat, ",")
					taskModel.RepeatOn = &strRepeatOnSorted
					db.Save(&taskModel)
				}
				// update NextRun
				GetNextRunValueOnTaskScheduler(requestHeader, taskModel)
				resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
				data = resModel
			} else {
				if taskPOST.RunAfterTask != nil {
					if taskPOST.RunAfterTask.TaskID > 0 {
						taskPOST.RunAfterTask.MainTask = taskModel.TaskID
						taskPOST.RunAfterTask.RunAfterTaskID = 0
						db.Create(&taskPOST.RunAfterTask)
						// update NextRun for runafter task
						var mainTaskModel models.TaskScheduler
						resultFindMainTask := db.Where("TaskID = ?", taskPOST.RunAfterTask.TaskID).First(&mainTaskModel)
						if resultFindMainTask.RowsAffected > 0 {
							taskModel.NextRun = mainTaskModel.NextRun
							db.Save(&taskModel)
						}
					}
				}
				var (
					afterTasksModel models.RunAfterTask
				)
				resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
				resultFindAfter := db.Where("MainTask = ?", resModel.TaskID).First(&afterTasksModel)
				if resultFindAfter.RowsAffected > 0 {
					resModel.RunAfterTask = &afterTasksModel
				}
				data = resModel
			}
		} else {
			status = 500
			msg = resultCreate.Error.Error()
		}
	} else {
		status = 500
		msg = errBody.Error()
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateTaskScheduler API
func UpdateTaskScheduler(c *gin.Context) {
	funcLogName := "UpdateTaskScheduler"
	defer libs.RecoverError(c, funcLogName)
	var (
		status    = 200
		msg, data interface{}
		response  models.APIResponseData
		taskPOST  map[string]interface{}
		taskModel models.TaskScheduler
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultFind := db.Where("TaskID = ?", ID).First(&taskModel)
	if resultFind.RowsAffected > 0 {
		body, errBody := ioutil.ReadAll(c.Request.Body)
		if errBody == nil {
			json.Unmarshal([]byte(string(body)), &taskPOST)
			taskModel = models.ConvertTaskSchedulerDataToDBTaskSchedulerForUpdate(taskPOST, taskModel)
			if taskModel.RunAfterTask != nil {
				runAfterTaskModel := *taskModel.RunAfterTask
				if taskModel.TaskID == runAfterTaskModel.TaskID {
					status = 422
					msg = services.GetMessage(lang, "RUNAFTER_REPEATED")
				} else {
					// find run after of task
					resultFindRepeat := db.Where("TaskID = ? AND MainTask = ?", taskModel.TaskID, runAfterTaskModel.TaskID).First(&models.RunAfterTask{})
					if resultFindRepeat.RowsAffected > 0 {
						status = 422
						msg = services.GetMessage(lang, "RUNAFTER_REPEATED")
					}
				}
			}
			if status == 200 {
				// reset fields not need of runafter
				if taskModel.RunAfter {
					taskModel.TaskStartDate = nil
					taskModel.TaskEndDate = nil
					//taskModel.NextRun = nil
					taskModel.StartAtTime = nil
					taskModel.Repeat = nil
					taskModel.RepeatEvery = 0
					taskModel.PreviousDay = 0
					taskModel.RepeatOn = nil
					taskModel.RepeatOnDayMonth = 0
				}
				resultSave := db.Save(&taskModel)
				if resultSave.Error == nil {
					// update after task
					if taskModel.IsRepeat {
						// sort
						repeatOn := ""
						if taskModel.RepeatOn != nil {
							repeatOn = *taskModel.RepeatOn
						}
						weekDayRepeatOn := strings.ToLower(repeatOn)
						arrDayRepeat := ConvertStringToArrayString(weekDayRepeatOn)
						if len(arrDayRepeat) > 0 {
							arrDayRepeat = UniqueDayRepeatInArray(arrDayRepeat)
							arrDayRepeat = SortArrayDayRepeat(arrDayRepeat)
							strRepeatOnSorted := strings.Join(arrDayRepeat, ",")
							taskModel.RepeatOn = &strRepeatOnSorted
							db.Save(&taskModel)
						}
						// update NextRun
						GetNextRunValueOnTaskScheduler(requestHeader, taskModel)
						// update nextRun for after task
						var mainTaskModel models.TaskScheduler
						resultFindMainTask := db.Where("TaskID = ?", taskModel.TaskID).First(&mainTaskModel)
						if resultFindMainTask.RowsAffected > 0 {
							mapProcessTaskID := make(map[int]int)
							arrRepeatTaskID := GetRepeatTaskByID(db, taskModel.TaskID, mapProcessTaskID)
							db.Where("TaskID in (?)", arrRepeatTaskID).Model(models.TaskScheduler{}).Updates(map[string]interface{}{"NextRun": mainTaskModel.NextRun})
						}
						// delete run after
						db.Delete(models.RunAfterTask{}, "MainTask = ?", taskModel.TaskID)
						resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
						data = resModel
					} else {
						if taskModel.RunAfterTask != nil {
							currentAfterTask := *taskModel.RunAfterTask
							db.Delete(models.RunAfterTask{}, "MainTask = ? AND TaskID <> ?", taskModel.TaskID, currentAfterTask.TaskID)
							if currentAfterTask.TaskID > 0 {
								var (
									afterTaskModel models.RunAfterTask
								)
								resultFindAfer := db.Where("MainTask = ? AND TaskID = ?", taskModel.TaskID, currentAfterTask.TaskID).First(&afterTaskModel)
								if resultFindAfer.RowsAffected > 0 {
									afterTaskModel.TaskID = currentAfterTask.TaskID
									afterTaskModel.MainTask = taskModel.TaskID
									afterTaskModel.DelayInMinutes = currentAfterTask.DelayInMinutes
									afterTaskModel.DoNotRunIfMainTaskFails = currentAfterTask.DoNotRunIfMainTaskFails
									db.Save(&afterTaskModel)
								} else {
									afterTaskModel.TaskID = currentAfterTask.TaskID
									afterTaskModel.MainTask = taskModel.TaskID
									afterTaskModel.DelayInMinutes = currentAfterTask.DelayInMinutes
									afterTaskModel.DoNotRunIfMainTaskFails = currentAfterTask.DoNotRunIfMainTaskFails
									db.Create(&afterTaskModel)
								}
							}
							// update NextRun for runafter task
							var mainTaskModel models.TaskScheduler
							resultFindMainTask := db.Where("TaskID = ?", taskModel.RunAfterTask.TaskID).First(&mainTaskModel)
							if resultFindMainTask.RowsAffected > 0 {
								taskModel.NextRun = mainTaskModel.NextRun
								db.Save(&taskModel)
							}
						}
						var (
							afterTasksModel models.RunAfterTask
						)
						resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
						resultFindAfter := db.Where("MainTask = ?", resModel.TaskID).First(&afterTasksModel)
						if resultFindAfter.RowsAffected > 0 {
							resModel.RunAfterTask = &afterTasksModel
						}
						data = resModel
					}
				} else {
					status = 500
					msg = resultSave.Error.Error()
				}
			}
		} else {
			status = 500
			msg = errBody.Error()
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "NO_RECORD_FOUND")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteTaskScheduler API
func DeleteTaskScheduler(c *gin.Context) {
	funcLogName := "DeleteTaskScheduler"
	defer libs.RecoverError(c, funcLogName)
	var (
		status    = 200
		msg, data interface{}
		response  models.APIResponseData
		taskModel models.TaskScheduler
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultFind := db.Where("TaskID = ?", ID).First(&taskModel)
	if resultFind.RowsAffected > 0 {
		resultSave := db.Delete(&taskModel)
		if resultSave.Error == nil {
			// delete after task
			sqlDelete := `DELETE FROM runaftertasks WHERE MainTask = ?`
			db.Exec(sqlDelete, ID)
		} else {
			status = 500
			msg = resultSave.Error.Error()
		}
	} else {
		status = 404
		msg = services.GetMessage(lang, "NO_RECORD_FOUND")
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetTasksForRunAfter func
func GetTasksForRunAfter(c *gin.Context) {
	funcLogName := "GetTasksForRunAfter"
	defer libs.RecoverError(c, funcLogName)
	var (
		status     = 200
		response   models.APIResponseData
		taskModels []models.TaskScheduler
		data, msg  interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	/* arrTypes := []string{}
	typeScheduler := "" */
	/* vType, sType := c.GetQuery("type")
	if sType {
		//typeScheduler = vType
	} else {
		status = 422
		msg = services.GetMessage(lang, "FIELD_REQUIRED", "Type")
	} */
	/* if status == 200 {
		typeScheduler = strings.TrimSpace(typeScheduler)
		typeScheduler = strings.ToLower(typeScheduler)
		if typeScheduler == "" || !libs.InArrayString(typeScheduler, arrTypes) {
			status = 422
			msg = services.GetMessage(lang, "FIELD_INVALID", "Type")
		}
	} */
	if status == 200 {
		/* if !libs.InArrayString(typeScheduler, []string{TypeImportMasterdata, TypeImportTransaction, TypeAutomapping}) {
			db.Where("Type = ?", typeScheduler).Find(&taskModels)
		} else {
			if typeScheduler == TypeAutomapping {
				db.Where("Type in (?)", []string{TypeImportMasterdata, TypeImportTransaction}).Find(&taskModels)
			} else if typeScheduler == TypeImportTransaction {
				db.Where("Type in (?)", []string{TypeImportMasterdata}).Find(&taskModels)
			} else if typeScheduler == TypeImportMasterdata {
				db.Where("Type in (?)", []string{TypeImportTransaction}).Find(&taskModels)
			}
		} */

		//db = db.Debug()

		arrRepeatTaskID := make([]int, 0)

		tx := db
		vTaskID, sTaskID := c.GetQuery("TaskID")
		if sTaskID {
			if vTaskID != "" {
				tx = tx.Where("TaskID <> ?", vTaskID)
				// check repeated
				iTaskID, _ := strconv.Atoi(vTaskID)
				mapProcessTaskID := make(map[int]int)
				arrRepeatTaskID = GetRepeatTaskByID(db, iTaskID, mapProcessTaskID)
			}
		}
		if len(arrRepeatTaskID) > 0 {
			tx = tx.Where("TaskID not in (?)", arrRepeatTaskID)
		}
		tx.Find(&taskModels)
		resModels := make([]models.TaskSchedulerData, 0)
		for _, v := range taskModels {
			var (
				resModel        models.TaskSchedulerData
				afterTasksModel models.RunAfterTask
			)
			resModel = models.ConvertDBTaskSchedulerToTaskSchedulerData(v)
			resultFindAfter := db.Where("MainTask = ?", v.TaskID).First(&afterTasksModel)
			if resultFindAfter.RowsAffected > 0 {
				resModel.RunAfterTask = &afterTasksModel
			}
			resModels = append(resModels, resModel)
		}
		data = resModels
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ChangeStatusTaskScheduler func
func ChangeStatusTaskScheduler(c *gin.Context) {
	funcLogName := "ChangeStatusTaskScheduler"
	defer libs.RecoverError(c, funcLogName)
	var (
		status         = 200
		response       models.APIResponseData
		data, msg      interface{}
		taskStatusPOST models.TaskSchedulerStatusPOST
		taskModel      models.TaskScheduler
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	body, errBody := ioutil.ReadAll(c.Request.Body)
	if errBody == nil {
		json.Unmarshal([]byte(string(body)), &taskStatusPOST)
		resultFind := db.Where("TaskID = ?", taskStatusPOST.TaskID).First(&taskModel)
		if resultFind.RowsAffected > 0 {
			taskModel.Enabled = taskStatusPOST.Enable
			db.Save(&taskModel)
			resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
			data = resModel
		} else {
			status = 404
			msg = services.GetMessage(lang, "NO_RECORD_FOUND")
		}
	} else {
		status = 500
		msg = errBody.Error()
	}
	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// RunNow func
func RunNow(c *gin.Context) {
	funcLogName := "RunNow"
	defer libs.RecoverError(c, funcLogName)
	var (
		status    = 200
		response  models.APIResponseData
		taskModel models.TaskScheduler
		dbInfo    DatabaseInfo
		data, msg interface{}
		isRunning = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	taskID, err := strconv.Atoi(ID)
	for _, v := range RunTaskList {
		if err == nil {
			if v.TaskID == taskID && requestHeader.DBName == v.DBName {
				isRunning = true
				break
			}
		}
	}
	if !isRunning {
		resultFind := db.Where("TaskID = ?", ID).First(&taskModel)
		if resultFind.RowsAffected > 0 {
			db.Where("TaskID = ?", taskID).Model(models.TaskScheduler{}).Updates(map[string]interface{}{"IsCompleted": false})
			dbInfo.DBName = requestHeader.DBName
			dbInfo.DBUsername = requestHeader.DBUser
			dbInfo.DBPassword = requestHeader.DBPassword
			dbInfo.DBHost = requestHeader.DBServer
			dbInfo.DBPort = requestHeader.DBPort
			//startTime := time.Now()
			resetStatus := ResetIsCompletedAndErrorMessageOfMainTaskAndAfterTask(dbInfo, taskModel.TaskID)
			if resetStatus {
				/* cResponse := make(chan CronJobResponse)
				go CronJobProcessTask(cResponse, dbInfo, taskModel, startTime, startTime)
				<-cResponse */
			}

			/*
				vResponse := <-cResponse
				taskModel.TaskExecuted = &startTime
				if vResponse.Status != 200 {
					if vResponse.Msg != nil {
						errMsg := fmt.Sprintf("%v", vResponse.Msg)
						taskModel.TaskErrorMessage = &errMsg
						isCompleted = false
					}
				} else {
					taskModel.TaskErrorMessage = nil
				}
				taskModel.IsCompleted = isCompleted
				timeNow := time.Now()
				taskModel.TaskEnded = &timeNow
				db.Save(&taskModel)*/

			resModel := models.ConvertDBTaskSchedulerToTaskSchedulerData(taskModel)
			data = resModel
		} else {
			status = 404
			msg = services.GetMessage(lang, "NO_RECORD_FOUND")
		}
	} else {
		msg = services.GetMessage(lang, "THE_TASK_IS_RUNNING")
		status = 201
	}

	if status == 200 {
		msg = services.GetMessage(lang, "api.success")
	} else {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
