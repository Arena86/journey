package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetEnumeratorByFieldName godoc
// @Summary Get Enumerator By FieldName
// @Description Get Enumerator  By FieldName
// @Tags Enumerator
// @Accept  json
// @Produce  json
// @Param id path string true "Enumerator FieldName"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /report/{FieldName} [get]
func GetEnumeratorByFieldName(c *gin.Context) {
	defer libs.RecoverError(c, "GetEnumeratorByFieldName")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Enumerator
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	fieldName := c.Param("FieldName")
	var totalCount int64
	totalCount = 0
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ?", fieldName)
	bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	msg = services.GetMessage(lang, "api.success")
	responses := ConvertArrayEnumeratorToArrayResponse(resModels, lang)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetEnumByJobType godoc
// @Summary Get Enumerator By FieldName
// @Description Get Enumerator  By FieldName
// @Tags Enumerator
// @Accept  json
// @Produce  json
// @Param id path int true "Enumerator Status"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /report/{FieldName} [get]
func GetEnumByJobType(c *gin.Context) {
	defer libs.RecoverError(c, "GetEnumByJobType")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.Enumerator
		checkModel    models.Enumerator
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	statusParam := c.Param("status")
	strTravelChargeModeMatrix := ""
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ? AND Status = ?", "JobType", statusParam).First(&checkModel)
	if checkModel.TravelChargeModeMatrix != nil {
		strTravelChargeModeMatrix = *checkModel.TravelChargeModeMatrix
	}
	arrTravelChargeModeMatrix := libs.StringToArray(strTravelChargeModeMatrix)
	var totalCount int64
	totalCount = 0
	if len(arrTravelChargeModeMatrix) > 0 {
		var bp = db
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ? AND Status in (?)", "TravelChargeMode", arrTravelChargeModeMatrix)
		bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	}

	strResourceTypeMatrix := ""
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ? AND Status = ?", "ResourceMode", statusParam).First(&checkModel)
	if checkModel.ResourceTypeMatrix != nil {
		strResourceTypeMatrix = *checkModel.ResourceTypeMatrix
	}
	arrResourceTypeMatrix := libs.StringToArray(strResourceTypeMatrix)
	totalCount = 0
	if len(arrResourceTypeMatrix) > 0 {
		var bp = db
		bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND FieldName = ? AND Status in (?)", "ResourceType", arrResourceTypeMatrix)
		bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	}

	responses := ConvertArrayEnumeratorToArrayResponse(resModels, lang)
	msg = services.GetMessage(lang, "api.success")
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayEnumeratorToArrayResponse func
func ConvertArrayEnumeratorToArrayResponse(items []models.Enumerator, lang string) []models.EnumeratorResponse {
	responses := make([]models.EnumeratorResponse, 0)
	for _, item := range items {
		response := ConvertEnumeratorToResponse(item, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertEnumeratorToResponse func
func ConvertEnumeratorToResponse(item models.Enumerator, lang string) models.EnumeratorResponse {
	var (
		response models.EnumeratorResponse
	)
	response.EnumID = item.EnumID
	response.FieldName = item.FieldName
	response.Status = item.Status
	response.Sort = item.Sort
	if item.TranslationKey != "" && item.TranslationKey != services.GetMessage(lang, item.TranslationKey) {
		response.Caption = services.GetMessage(lang, item.TranslationKey)
	} else {
		response.Caption = item.Caption
	}
	response.CaptionColor = item.CaptionColor
	response.Icon = item.Icon
	response.TranslationKey = item.TranslationKey
	if item.TravelChargeModeMatrix != nil {
		strModeMatrix := *item.TravelChargeModeMatrix
		arrModeMatrix := libs.StringToArray(strModeMatrix)
		if len(arrModeMatrix) > 0 {
			response.TravelChargeModeMatrix = &arrModeMatrix
		}
	}
	if item.ResourceTypeMatrix != nil {
		strModeMatrix := *item.ResourceTypeMatrix
		arrModeMatrix := libs.StringToArray(strModeMatrix)
		if len(arrModeMatrix) > 0 {
			response.ResourceTypeMatrix = &arrModeMatrix
		}
	}
	return response
}
