package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// GetTrackAndTrace godoc
// @Summary GetTrackAndTrace
// @Description GetTrackAndTrace
// @Tags TrackAndTrace
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /trackandtrace/{trackandtracetoken} [get]
func GetTrackAndTrace(c *gin.Context) {
	defer libs.RecoverError(c, "GetTrackAndTrace")
	var (
		status                = libs.GetStatusSuccess()
		requestHeader         models.RequestHeader
		response              models.APIResponseData
		msg, data             interface{}
		resourceModel         models.Resource
		trackAndTraceResponse models.TrackAndTraceResponse
		resourceModeEnum      models.Enumerator
		resourceTypeEnum      models.Enumerator
		jobtaskStatusEnum     models.Enumerator
		jobtaskTypeEnum       models.Enumerator
		validateMsgError      string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	trackAndTraceToken := c.Param("trackandtracetoken")
	trackAndTraceTokenModel, errTrackAndTrace := libs.ConvertTokenToTrackAndTraceToken(trackAndTraceToken)
	if errTrackAndTrace == nil {
		resultFindResource := db.Where("ResourceID = ?", trackAndTraceTokenModel.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
		if resultFindResource.RowsAffected > 0 {
			trackAndTraceResponse.Resource.ResourceCode = resourceModel.ResourceCode
			trackAndTraceResponse.Resource.ResourceName = resourceModel.ResourceName
			trackAndTraceResponse.Resource.ResourceMode = resourceModel.ResourceMode
			resultEnum := db.Where("FieldName = ? AND Status = ?", "ResourceMode", resourceModel.ResourceMode).First(&resourceModeEnum)
			if resultEnum.RowsAffected > 0 {
				if resourceModeEnum.TranslationKey != "" && resourceModeEnum.TranslationKey != services.GetMessage(lang, resourceModeEnum.TranslationKey) {
					trackAndTraceResponse.Resource.ResourceModeName = services.GetMessage(lang, resourceModeEnum.TranslationKey)
				} else {
					trackAndTraceResponse.Resource.ResourceModeName = resourceModeEnum.Caption
				}
			}
			trackAndTraceResponse.Resource.ResourceColor = resourceModel.ResourceColor
			trackAndTraceResponse.Resource.ResourceType = resourceModel.ResourceType
			resultEnum = db.Where("FieldName = ? AND Status = ?", "ResourceType", resourceModel.ResourceType).First(&resourceTypeEnum)
			if resultEnum.RowsAffected > 0 {
				if resourceTypeEnum.TranslationKey != "" && resourceTypeEnum.TranslationKey != services.GetMessage(lang, resourceTypeEnum.TranslationKey) {
					trackAndTraceResponse.Resource.ResourceTypeName = services.GetMessage(lang, resourceTypeEnum.TranslationKey)
				} else {
					trackAndTraceResponse.Resource.ResourceTypeName = resourceTypeEnum.Caption
				}
			}
			trackAndTraceResponse.Resource.RegistrationNumber = resourceModel.RegistrationNumber
		} else {
			status = 404
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.resourceid_not_found"))
		}
	} else {
		status = 500
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, errTrackAndTrace.Error())
	}
	if status == 200 {
		var (
			precomputedModel models.PrecomputedRoute
		)
		resultFindPrecomputed := db.Where("TaskID = ?", trackAndTraceTokenModel.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&precomputedModel)
		if resultFindPrecomputed.RowsAffected > 0 {
			trackAndTraceResponse.PrecomputedRoutes.PrecomputedRoute = precomputedModel.PrecomputedRoute
			trackAndTraceResponse.PrecomputedRoutes.PrecomputedRouteWeb = precomputedModel.PrecomputedRouteWeb
		} else {
			status = 404
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.precomputedroute_not_found"))
		}
	}
	if status == 200 {
		var (
			jobtask models.JobTask
		)
		resultFindJobTask := db.Where("JobTaskID = ?", trackAndTraceTokenModel.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobtask)
		if resultFindJobTask.RowsAffected > 0 {
			if jobtask.Status != 4 { // Completed
				trackAndTraceResponse.JobTask.JobTaskID = jobtask.JobTaskID
				trackAndTraceResponse.JobTask.Status = jobtask.Status
				trackAndTraceResponse.JobTask.NavigationAddress = jobtask.NavigationAddress
				trackAndTraceResponse.JobTask.EstimatedArrivalDateTime = jobtask.EstimatedArrivalDateTime
				resultEnum := db.Where("FieldName = ? AND Status = ?", "JobTaskStatus", jobtask.Status).First(&jobtaskStatusEnum)
				if resultEnum.RowsAffected > 0 {
					if jobtaskStatusEnum.TranslationKey != "" && jobtaskStatusEnum.TranslationKey != services.GetMessage(lang, jobtaskStatusEnum.TranslationKey) {
						trackAndTraceResponse.JobTask.StatusName = services.GetMessage(lang, jobtaskStatusEnum.TranslationKey)
					} else {
						trackAndTraceResponse.JobTask.StatusName = jobtaskStatusEnum.Caption
					}
				}
				var (
					jobModel             models.Job
					businessPartnerModel models.BusinessPartner
					locationModel        models.Location
					phoneModel           models.Phone
				)
				resultFindJob := db.Where("JobID = ?", jobtask.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
				if resultFindJob.RowsAffected > 0 {
					timeZone := libs.GetTimeZoneByLocation(requestHeader, jobModel.LocationID)
					if trackAndTraceResponse.JobTask.EstimatedArrivalDateTime != nil {
						dEstimatedArrivalDateTime := *trackAndTraceResponse.JobTask.EstimatedArrivalDateTime
						dEstimatedArrivalDateTime = dEstimatedArrivalDateTime.Add(time.Duration(-timeZone.Offset) * time.Hour)
						trackAndTraceResponse.JobTask.EstimatedArrivalDateTime = &dEstimatedArrivalDateTime
					}

					trackAndTraceResponse.JobTask.JobType = jobModel.JobType
					resultEnum := db.Where("FieldName = ? AND Status = ?", "JobType", jobtask.JobType).First(&jobtaskTypeEnum)
					if resultEnum.RowsAffected > 0 {
						if jobtaskTypeEnum.TranslationKey != "" && jobtaskTypeEnum.TranslationKey != services.GetMessage(lang, jobtaskTypeEnum.TranslationKey) {
							trackAndTraceResponse.JobTask.JobTypeName = services.GetMessage(lang, jobtaskTypeEnum.TranslationKey)
						} else {
							trackAndTraceResponse.JobTask.JobTypeName = jobtaskTypeEnum.Caption
						}
					}
					trackAndTraceResponse.JobTask.JobNumber = jobModel.JobNumber
					resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", jobModel.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartnerModel)
					if resultFindBusinessPartner.RowsAffected > 0 {
						trackAndTraceResponse.JobTask.CompanyName = businessPartnerModel.CompanyName
					}
					resultFindLocation := db.Where("LocationID = ?", jobModel.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&locationModel)
					if resultFindLocation.RowsAffected > 0 {
						trackAndTraceResponse.JobTask.LocationName = locationModel.LocationName
					}
					resultFindPhone := db.Where("EntityID = ? AND Entity = ? AND PhoneTypeID = ?", jobModel.LocationID, models.Location{}.TableName(), 4).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&phoneModel)
					if resultFindPhone.RowsAffected > 0 {
						trackAndTraceResponse.JobTask.LocationPhone = phoneModel.PhoneNumber
					}
				}
			} else {
				status = 404
				validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.track_and_trace_completed"))
			}
		} else {
			status = 404
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.no_record_found"))
		}
	}
	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
		data = trackAndTraceResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetTrackAndTraceGPS godoc
// @Summary GetTrackAndTraceGPS
// @Description GetTrackAndTraceGPS
// @Tags TrackAndTrace
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /trackandtracegps/{trackandtracetoken} [get]
func GetTrackAndTraceGPS(c *gin.Context) {
	defer libs.RecoverError(c, "GetTrackAndTraceGPS")
	var (
		status                   = libs.GetStatusSuccess()
		requestHeader            models.RequestHeader
		response                 models.APIResponseData
		msg, data                interface{}
		resourceModel            models.Resource
		trackAndTraceGPSResponse models.TrackAndTraceGPSResponse
		validateMsgError         string
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	trackAndTraceToken := c.Param("trackandtracetoken")
	trackAndTraceTokenModel, errTrackAndTrace := libs.ConvertTokenToTrackAndTraceToken(trackAndTraceToken)
	if errTrackAndTrace == nil {
		resultFindResource := db.Where("ResourceID = ?", trackAndTraceTokenModel.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
		if resultFindResource.RowsAffected > 0 {
			trackAndTraceGPSResponse.CurrentLatitude, _ = strconv.ParseFloat(resourceModel.CurrentLatitude, 64)
			trackAndTraceGPSResponse.CurrentLongitude, _ = strconv.ParseFloat(resourceModel.CurrentLongitude, 64)
		} else {
			status = 404
			validateMsgError = libs.GetStringWithWordBetween(validateMsgError, services.GetMessage(lang, "api.resourceid_not_found"))
		}
	} else {
		status = 500
		validateMsgError = libs.GetStringWithWordBetween(validateMsgError, errTrackAndTrace.Error())
	}

	if validateMsgError != "" {
		msg = validateMsgError
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
		data = trackAndTraceGPSResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}
