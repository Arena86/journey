package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"

	"github.com/gin-gonic/gin"
)

// GetXeroContact godoc
// @Summary Get Xero Contact
// @Description Xero Contact
// @Tags XeroContact
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/contact [get]
func GetXeroContact(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroContact")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	representURL := "Contacts"
	arrQuery := libs.ParseParamsQuery(c)
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, arrQuery, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// GetXeroContactByID godoc
// @Summary Get Xero Contact By ID
// @Description Get Xero Contact By ID
// @Tags XeroContact
// @Accept  json
// @Produce  json
// @Param id path int true "XeroContact ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /xero/contact/{id} [get]
func GetXeroContactByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetXeroContactByID")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	ID := c.Param("id")
	representURL := "Contacts/" + ID
	resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "GET", representURL, nil, nil, nil)
	if resStatus == 200 {
		json.Unmarshal([]byte(string(resData)), &dataRes)
		data = dataRes
		msg = services.GetMessage(lang, "api.success")
	} else {
		status = resStatus
		msg = resMsg
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// CreateXeroContact godoc
// @Summary Create Xero Contact
// @Description Create Xero Contact
// @Tags XeroContact
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AddressType body []models.AddressTypeResponse true "Create Xero Contact"
// @Success 200 {object} models.APIResponseData
// @Router /xero/contact [post]
func CreateXeroContact(c *gin.Context) {
	defer libs.RecoverError(c, "CreateXeroContact")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		dataPOST      map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		json.Unmarshal([]byte(string(body)), &dataPOST)
		requestBody := dataPOST
		representURL := "Contacts"
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			data = dataRes
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateXeroContact godoc
// @Summary Update Xero Contact
// @Description Update Xero Contact
// @Tags XeroContact
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param XeroContact body []models.XeroContactResponse true "Update Xero Contact"
// @Success 200 {object} models.APIResponseData
// @Router /xero/contact/{id} [put]
func UpdateXeroContact(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateXeroContact")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		dataRes       map[string]interface{}
		dataPOST      map[string]interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	body, err := ioutil.ReadAll(c.Request.Body)
	if err == nil {
		ID := c.Param("id")
		json.Unmarshal([]byte(string(body)), &dataPOST)
		dataPOST["ContactID"] = ID
		requestBody := dataPOST
		representURL := "Contacts/" + ID
		resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
		if resStatus == 200 {
			json.Unmarshal([]byte(string(resData)), &dataRes)
			data = dataRes
			msg = services.GetMessage(lang, "api.success")
		} else {
			status = resStatus
			msg = resMsg
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
		}
	} else {
		status = 500
		msg = err.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateContactFromDatabaseToXero func
func UpdateContactFromDatabaseToXero(requestHeader models.RequestHeader, lang string, businessPartnerModels []models.BusinessPartner) []models.ProcessXeroResponse {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	processXeroResponses := make([]models.ProcessXeroResponse, 0)
	for _, bp := range businessPartnerModels {
		var (
			xeroContact         models.XeroContact
			xeroContactResponse models.XeroContactResponse
			requestBody         interface{}
			itemMsgError        string
			processXeroResponse models.ProcessXeroResponse
			status              = 200
			responseData        interface{}
		)
		xeroContact.ConvertDatabaseModelToXero(db, bp)
		ID := bp.ErpKey
		if ID != "" {
			representURL := "Contacts/" + ID
			requestBody = models.RemoveEmptyValueWhenPostToXeroContact(xeroContact)
			resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			status = resStatus
			if resStatus == 200 {
				// update to database
				json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
				if len(xeroContactResponse.Contacts) > 0 {
					var (
						arrSkipAddressID = make([]int, 0)
						arrSkipPhoneID   = make([]int, 0)
					)
					xeroContact := xeroContactResponse.Contacts[0]
					bp.ConvertXeroToDatabaseModel(db, bp.CreatedBy, xeroContact)
					if len(bp.Addresses) > 0 {
						validAddresses := make([]models.Address, 0)
						for _, address := range bp.Addresses {
							if address.AddressID > 0 {
								arrSkipAddressID = append(arrSkipAddressID, address.AddressID)
							}
							address.CreatedBy = bp.CreatedBy
							address.ModifiedBy = bp.ModifiedBy
							validAddresses = append(validAddresses, address)
						}
						bp.Addresses = validAddresses
					}
					if len(bp.Phones) > 0 {
						validPhones := make([]models.Phone, 0)
						for _, phone := range bp.Phones {
							if phone.PhoneID > 0 {
								arrSkipPhoneID = append(arrSkipPhoneID, phone.PhoneID)
							}
							phone.CreatedBy = bp.CreatedBy
							phone.ModifiedBy = bp.ModifiedBy
							validPhones = append(validPhones, phone)
						}
						bp.Phones = validPhones
					}
					resultSave := db.Save(&bp)
					if resultSave.Error != nil {
						status = 500
						itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
					} else {
						responseData = bp
						// @TODO delete address/phone
						if len(arrSkipAddressID) > 0 {
							db.Where("EntityID = ? AND Entity = ? AND AddressID not in (?)", bp.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrSkipAddressID).Model(&models.Address{}).Updates(models.Address{IsDeleted: true})
						} else {
							db.Where("EntityID = ? AND Entity = ?", bp.BusinessPartnerID, models.BusinessPartner{}.TableName()).Model(&models.Address{}).Updates(models.Address{IsDeleted: true})
						}
						if len(arrSkipPhoneID) > 0 {
							db.Where("EntityID = ? AND Entity = ? AND PhoneID not in (?)", bp.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrSkipPhoneID).Model(&models.Phone{}).Updates(models.Phone{IsDeleted: true})
						} else {
							db.Where("EntityID = ? AND Entity = ?", bp.BusinessPartnerID, models.BusinessPartner{}.TableName()).Model(&models.Phone{}).Updates(models.Phone{IsDeleted: true})
						}
						//db.Where("BusinessPartnerID = ?", bp.BusinessPartnerID).Delete(&models.BusinessPartnerLocation{})
					}
				}
			} else {
				if resMsg != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", resMsg))
				}
			}
		} else {
			// @TODO add new
			var (
				requestBody         interface{}
				xeroContactResponse models.XeroContactResponse
			)
			validXeroContacts := make([]map[string]interface{}, 0)
			validXeroContact := models.RemoveEmptyValueWhenPostToXeroContact(xeroContact)
			validXeroContacts = append(validXeroContacts, validXeroContact)
			dataPOST := make(map[string]interface{})
			dataPOST["Contacts"] = validXeroContacts
			representURL := "Contacts"
			requestBody = dataPOST
			resStatus, resMsg, resData := libs.RequestXero(requestHeader, lang, "POST", representURL, requestBody, nil, nil)
			if resStatus == 200 {
				json.Unmarshal([]byte(string(resData)), &xeroContactResponse)
				if len(xeroContactResponse.Contacts) > 0 {
					// add/update to database
					var (
						contactCompanyNameModel models.BusinessPartner
						arrSkipAddressID        = make([]int, 0)
						arrSkipPhoneID          = make([]int, 0)
					)
					xeroContact := xeroContactResponse.Contacts[0]
					var dbBP = db.Preload("Addresses", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
					dbBP = dbBP.Preload("Phones", "Entity = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", models.BusinessPartner{}.TableName())
					resultFindContactCode := dbBP.Where("CompanyName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", xeroContact.Name).First(&contactCompanyNameModel)
					if resultFindContactCode.RowsAffected > 0 {
						contactCompanyNameModel.ConvertXeroToDatabaseModel(db, bp.CreatedBy, xeroContact)
						contactCompanyNameModel.BusinessPartnerCode = bp.BusinessPartnerCode
						contactCompanyNameModel.Locations = bp.Locations
						contactCompanyNameModel.CreatedBy = bp.CreatedBy
						contactCompanyNameModel.ModifiedBy = bp.ModifiedBy
						if len(contactCompanyNameModel.Addresses) > 0 {
							validAddresses := make([]models.Address, 0)
							for _, address := range contactCompanyNameModel.Addresses {
								if address.AddressID > 0 {
									arrSkipAddressID = append(arrSkipAddressID, address.AddressID)
								}
								address.CreatedBy = bp.CreatedBy
								address.ModifiedBy = bp.ModifiedBy
								validAddresses = append(validAddresses, address)
							}
							contactCompanyNameModel.Addresses = validAddresses
						}
						if len(contactCompanyNameModel.Phones) > 0 {
							validPhones := make([]models.Phone, 0)
							for _, phone := range contactCompanyNameModel.Phones {
								if phone.PhoneID > 0 {
									arrSkipPhoneID = append(arrSkipPhoneID, phone.PhoneID)
								}
								phone.CreatedBy = bp.CreatedBy
								phone.ModifiedBy = bp.ModifiedBy
								validPhones = append(validPhones, phone)
							}
							contactCompanyNameModel.Phones = validPhones
						}
						resultSave := db.Save(&contactCompanyNameModel)
						if resultSave.Error != nil {
							status = 500
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
						} else {
							responseData = contactCompanyNameModel
							// @TODO delete address/phone
							if len(arrSkipAddressID) > 0 {
								db.Where("EntityID = ? AND Entity = ? AND AddressID not in (?)", contactCompanyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrSkipAddressID).Model(&models.Address{}).Updates(models.Address{IsDeleted: true})
							} else {
								db.Where("EntityID = ? AND Entity = ?", contactCompanyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Model(&models.Address{}).Updates(models.Address{IsDeleted: true})
							}
							if len(arrSkipPhoneID) > 0 {
								db.Where("EntityID = ? AND Entity = ? AND PhoneID not in (?)", contactCompanyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName(), arrSkipPhoneID).Model(&models.Phone{}).Updates(models.Phone{IsDeleted: true})
							} else {
								db.Where("EntityID = ? AND Entity = ?", contactCompanyNameModel.BusinessPartnerID, models.BusinessPartner{}.TableName()).Model(&models.Phone{}).Updates(models.Phone{IsDeleted: true})
							}
							//db.Where("BusinessPartnerID = ?", contactCompanyNameModel.BusinessPartnerID).Delete(&models.BusinessPartnerLocation{})
						}
					} else {
						contactCompanyNameModel = bp
						contactCompanyNameModel.ConvertXeroToDatabaseModel(db, bp.CreatedBy, xeroContact)
						contactCompanyNameModel.BusinessPartnerCode = bp.BusinessPartnerCode
						contactCompanyNameModel.Locations = bp.Locations
						contactCompanyNameModel.CreatedBy = bp.CreatedBy
						contactCompanyNameModel.ModifiedBy = bp.ModifiedBy
						if len(contactCompanyNameModel.Addresses) > 0 {
							validAddresses := make([]models.Address, 0)
							for _, address := range contactCompanyNameModel.Addresses {
								address.CreatedBy = bp.CreatedBy
								address.ModifiedBy = bp.ModifiedBy
								validAddresses = append(validAddresses, address)
							}
							contactCompanyNameModel.Addresses = validAddresses
						}
						if len(contactCompanyNameModel.Phones) > 0 {
							validPhones := make([]models.Phone, 0)
							for _, phone := range contactCompanyNameModel.Phones {
								phone.CreatedBy = bp.CreatedBy
								phone.ModifiedBy = bp.ModifiedBy
								validPhones = append(validPhones, phone)
							}
							contactCompanyNameModel.Phones = validPhones
						}
						resultCreate := db.Create(&contactCompanyNameModel)
						if resultCreate.Error != nil {
							status = 500
							itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
						} else {
							responseData = contactCompanyNameModel
						}
					}
				}
			} else {
				if resMsg != nil {
					status = 500
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, fmt.Sprintf("%v", resMsg))
				}
			}
		}
		processXeroResponse.Status = status
		processXeroResponse.Data = responseData
		processXeroResponse.Msg = itemMsgError
		processXeroResponses = append(processXeroResponses, processXeroResponse)
	}
	return processXeroResponses
}
