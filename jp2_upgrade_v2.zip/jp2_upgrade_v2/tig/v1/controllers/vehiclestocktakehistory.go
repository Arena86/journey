package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
	"gorm.io/gorm"
)

// GetVehicleStocktakeHistory godoc
// @Summary Get VehicleStocktakeHistory
// @Description Get VehicleStocktakeHistory
// @Tags VehicleStocktakeHistory
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param VehicleStocktakeID query integer false "VehicleStocktakeID"
// @Param ResourceID query integer false "ResourceID"
// @Param StocktakeDateFrom query string false "StocktakeDateFrom - yyyy-mm-dd"
// @Param StocktakeDateTo query string false "StocktakeDateTo - yyyy-mm-dd"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclestocktakehistory [get]
func GetVehicleStocktakeHistory(c *gin.Context) {
	defer libs.RecoverError(c, "VehicleStocktakeHistory")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.VehicleStocktakeHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Preload("Questions", func(db *gorm.DB) *gorm.DB {
		return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
	})
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"VehicleStocktakeID", "ResourceID"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{"StocktakeDate"}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayVehicleStocktakeHistoryToArrayResponse(requestHeader, resModels)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetVehicleStocktakeHistoryByID godoc
// @Summary Get VehicleStocktakeHistory By ID
// @Description Get VehicleStocktakeHistory By ID
// @Tags VehicleStocktakeHistory
// @Accept  json
// @Produce  json
// @Param id path int true "VehicleStocktakeHistory ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclestocktakehistory/{id} [get]
func GetVehicleStocktakeHistoryByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetVehicleStocktakeHistoryByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.VehicleStocktakeHistory
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Where("VehicleStocktakeHistoryID = ?", ID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertVehicleStocktakeHistoryToResponse(requestHeader, resModel)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateVehicleStocktakeHistory godoc
// @Summary Create VehicleStocktakeHistory
// @Description Create VehicleStocktakeHistory
// @Tags VehicleStocktakeHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleStocktakeHistory body models.VehicleStocktakeHistoryResponse true "Create VehicleStocktakeHistory"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclestocktakehistory [post]
func CreateVehicleStocktakeHistory(c *gin.Context) {
	defer libs.RecoverError(c, "CreateVehicleStocktakeHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	var (
		resModel models.VehicleStocktakeHistory
	)
	resModel.PassBodyJSONToModel(bp)
	// @TODO validate

	resModel.CreatedBy = accountKey
	validate, trans := services.GetValidatorTranslate()
	err := validate.Struct(resModel)
	if err != nil {
		var (
			errValid interface{}
		)
		errs := err.(validator.ValidationErrors)
		for _, e := range errs {
			errValid = e.Translate(trans)
		}
		errResponse := GetErrorResponseErrorMessage(0, errValid)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		var (
			itemMsgError string
		)
		for i := range resModel.Questions {
			resModel.Questions[i].CreatedBy = accountKey
		}
		// @TODO validate for details
		if itemMsgError == "" {
			resultCreate := db.Create(&resModel)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			} else {
				data = ConvertVehicleStocktakeHistoryToResponse(requestHeader, resModel)
				totalUpdatedRecord++
			}
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateVehicleStocktakeHistory godoc
// @Summary Update VehicleStocktakeHistory
// @Description Update VehicleStocktakeHistory
// @Tags VehicleStocktakeHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param VehicleStocktakeHistory body models.VehicleStocktakeHistoryResponse true "Update VehicleStocktakeHistory"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclestocktakehistory/{id} [put]
func UpdateVehicleStocktakeHistory(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateVehicleStocktakeHistory")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var bp map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&bp)
	sID := c.Param("id")
	id, _ := strconv.Atoi(sID)
	var (
		resModel models.VehicleStocktakeHistory
	)
	resultFind := db.Preload(
		"Questions",
		func(db *gorm.DB) *gorm.DB {
			return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
		},
	).Where("VehicleStocktakeHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
	if resultFind.RowsAffected > 0 {
		resModel.PassBodyJSONToModel(bp)
		// @ validate
		resModel.VehicleStocktakeHistoryID = id
		resModel.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(resModel)
		if err != nil {
			var (
				errValid interface{}
			)
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				errValid = e.Translate(trans)
			}
			errResponse := GetErrorResponseErrorMessage(0, errValid)
			errorsResponse = append(errorsResponse, errResponse)
		} else {
			var (
				itemMsgError string
			)
			//timeNow := time.Now()
			for i := range resModel.Questions {
				if resModel.Questions[i].VehicleStocktakeHistoryID <= 0 {
					resModel.Questions[i].CreatedBy = accountKey
				}
				resModel.Questions[i].ModifiedBy = accountKey
			}

			// @TODO validate for details
			if itemMsgError == "" {
				resultSave := db.Session(&gorm.Session{FullSaveAssociations: true}).Save(&resModel)
				if resultSave.Error != nil {
					itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultSave.Error.Error())
				} else {
					totalUpdatedRecord++
					// @TODO delete details
					arrQuestionSkipID := make([]int, 0)
					for _, v := range resModel.Questions {
						arrQuestionSkipID = append(arrQuestionSkipID, v.VehicleStocktakeQuestionHistoryID)
					}
					if len(arrQuestionSkipID) > 0 {
						db.Where("VehicleStocktakeHistoryID = ? AND VehicleStocktakeQuestionHistoryID not in (?)", resModel.VehicleStocktakeHistoryID, arrQuestionSkipID).Model(&models.VehicleStocktakeQuestionHistory{}).Updates(models.VehicleStocktakeQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					} else {
						db.Where("VehicleStocktakeHistoryID = ?", resModel.VehicleStocktakeHistoryID).Model(&models.VehicleStocktakeQuestionHistory{}).Updates(models.VehicleStocktakeQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
					}

					// set details empty
					resultRow := db.Preload(
						"Questions",
						func(db *gorm.DB) *gorm.DB {
							return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
						},
					).Where("VehicleStocktakeHistoryID = ?", id).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resModel)
					if resultRow.RowsAffected > 0 {
						responses := ConvertVehicleStocktakeHistoryToResponse(requestHeader, resModel)
						data = responses
					} else {
						errResponse := GetErrorResponseNotFound(lang, 0)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			}
			if itemMsgError != "" {
				errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, 1, errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteVehicleStocktakeHistory godoc
// @Summary Delete VehicleStocktakeHistory
// @Description Delete VehicleStocktakeHistory
// @Tags VehicleStocktakeHistory
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "VehicleStocktakeHistory ID"
// @Success 200 {object} models.APIResponseData
// @Router /vehiclestocktakehistory/{id} [delete]
func DeleteVehicleStocktakeHistory(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteVehicleStocktakeHistory")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.VehicleStocktakeHistory
		)
		resultFind := db.Preload(
			"Questions",
			func(db *gorm.DB) *gorm.DB {
				return db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("GroupName ASC")
			},
		).Where("VehicleStocktakeHistoryID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			resModel.IsDeleted = true
			resModel.ModifiedBy = accountKey
			deletedResult := db.Save(&resModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
				// @TODO delete detail
				arrDeleteHistoryID := make([]int, 0)
				for _, v := range resModel.Questions {
					arrDeleteHistoryID = append(arrDeleteHistoryID, v.VehicleStocktakeQuestionHistoryID)
				}
				if len(arrDeleteHistoryID) > 0 {
					db.Where("VehicleStocktakeQuestionHistoryID in (?)", arrDeleteHistoryID).Model(&models.VehicleStocktakeQuestionHistory{}).Updates(models.VehicleStocktakeQuestionHistory{IsDeleted: true, ModifiedBy: accountKey})
				}
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayVehicleStocktakeHistoryToArrayResponse func
func ConvertArrayVehicleStocktakeHistoryToArrayResponse(requestHeader models.RequestHeader, items []models.VehicleStocktakeHistory) []models.VehicleStocktakeHistoryResponse {
	responses := make([]models.VehicleStocktakeHistoryResponse, 0)
	for _, item := range items {
		response := ConvertVehicleStocktakeHistoryToResponse(requestHeader, item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertVehicleStocktakeHistoryToResponse func
func ConvertVehicleStocktakeHistoryToResponse(requestHeader models.RequestHeader, item models.VehicleStocktakeHistory) models.VehicleStocktakeHistoryResponse {
	var (
		response       models.VehicleStocktakeHistoryResponse
		stocktakeModel models.VehicleStocktake
		resource       models.Resource
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	response.VehicleStocktakeHistoryID = item.VehicleStocktakeHistoryID
	response.VehicleStocktakeID = item.VehicleStocktakeID
	resultFindStocktake := db.Where("VehicleStocktakeID = ?", item.VehicleStocktakeID).First(&stocktakeModel)
	if resultFindStocktake.RowsAffected > 0 {
		response.VehicleStocktakeName = stocktakeModel.VehicleStocktakeName
	}
	response.StocktakeDate = item.StocktakeDate
	response.Comment = item.Comment
	response.ResourceID = item.ResourceID
	resultFindResource := db.Where("ResourceID = ?", item.ResourceID).First(&resource)
	if resultFindResource.RowsAffected > 0 {
		response.ResourceCode = resource.ResourceCode
		response.ResourceName = resource.ResourceName
	}
	details := make([]models.VehicleStocktakeQuestionHistoryResponse, 0)
	for _, v := range item.Questions {
		var detail models.VehicleStocktakeQuestionHistoryResponse

		detail.VehicleStocktakeQuestionHistoryID = v.VehicleStocktakeQuestionHistoryID
		detail.VehicleStocktakeHistoryID = v.VehicleStocktakeHistoryID
		detail.GroupName = v.GroupName
		detail.Question = v.Question
		detail.Status = v.Status
		details = append(details, detail)
	}
	response.Questions = details

	return response
}
