package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"

	"gopkg.in/go-playground/validator.v9"
)

var (
	arrGlobalGrid models.ArrGlobalGrid
)

// GetGridByKey godoc
// @Summary Get Grid By Key
// @Description Get Grid By Key
// @Tags Grid
// @Accept  json
// @Produce  json
// @Param key path int true "Grid Key"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /grid/{key} [get]
func GetGridByKey(c *gin.Context) {
	defer libs.RecoverError(c, "GetGridByKey")
	var (
		status        = libs.GetStatusSuccess()
		grids         []models.Grid
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)

	// @TODO waiting post finished
	countCheckGetGrid := 0
	for {
		hasGetGrid := HasGetGrid(&arrGlobalGrid, accountKey)
		if hasGetGrid {
			break
		} else {
			time.Sleep(1 * time.Second)
		}
		countCheckGetGrid++
		if countCheckGetGrid >= 10 {
			status = 500
			msg = services.GetMessage(lang, "api.error")
			errResponse := GetErrorResponseErrorMessage(0, msg)
			errorsResponse = append(errorsResponse, errResponse)
			response.Status = status
			response.Message = msg
			response.Errors = errorsResponse
			responsesData := libs.RemoveNullResonseData(response)
			responsesData["data"] = nil
			responsesData["totalcount"] = 0
			libs.ResponseData(responsesData, c, status)
			return
		}
	}

	// Paging
	/*vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}*/
	//if !sLength {
	//		vLength = os.Getenv("PAGE_SIZE")
	//}
	key := c.Param("key")
	var totalCount int64
	totalCount = 0
	//var bp = db.Limit(vLength).Offset(vStart)
	var bp = db.Where("AccountKey = ?", accountKey)
	bp = bp.Where("GridKey = ?", key)
	resultRow := bp.Find(&grids).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(grids) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = ConvertGridToGridGET(requestHeader, db, grids, lang)
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// CreateGrid godoc
// @Summary Create Grid
// @Description Create Grid
// @Tags Grid
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Grid body []models.Grid true "Create Grid"
// @Success 200 {object} models.APIResponseData
// @Router /grid [post]
func CreateGrid(c *gin.Context) {
	defer libs.RecoverError(c, "CreateGrid")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Grid
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.Grid, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				grid models.Grid
			)
			grid.PassBodyJSONToModel(bp)
			resultFind := db.Where("AccountKey = ? AND GridKey = ? AND DataField = ?", accountKey, grid.GridKey, grid.DataField).First(&grid)
			grid.PassBodyJSONToModel(bp)
			grid.AccountKey = accountKey
			grid.Width = "100%"
			grid.Alignment = "left"
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(grid)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&grid)
				} else {
					db.Create(&grid)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, grid)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	data = dataResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateGridByKey godoc
// @Summary Update Grid By Key
// @Description Update Grid By Key
// @Tags Grid
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Grid body []models.Grid true "Create Grid"
// @Success 200 {object} models.APIResponseData
// @Router /grid/:key [put]
func UpdateGridByKey(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateGridByKey")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.Grid
		totalUpdatedRecord = 0
		totalRecord        = 0
	)

	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	// @TODO waiting post finished
	arrGlobalGrid.SetValueToGlobalObject(accountKey, false)

	key := c.Param("key")
	dataResponse = make([]models.Grid, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	resultFindKey := db.Where("GridKey = ?", key).First(&models.Grid{})
	if resultFindKey.RowsAffected > 0 {
		if len(objectsJSON) > 0 {
			var (
				rollbackGrids             []models.Grid
				hasRollBack               = false
				arrIDNeedDeleteAtRollBack = make([]int, 0)
			)
			db.Where("GridKey = ? AND AccountKey = ?", key, accountKey).Find(&rollbackGrids)
			db.Where("GridKey = ? AND AccountKey = ?", key, accountKey).Model(&models.Grid{}).Updates(map[string]interface{}{"Visible": false, "Width": "100%"})
			for k, bp := range objectsJSON {
				var (
					grid models.Grid
				)
				totalRecord = totalRecord + 1
				grid.PassBodyJSONToModel(bp)
				resultFind := db.Where("GridKey = ? AND DataField = ? AND AccountKey = ?", key, grid.DataField, accountKey).First(&grid)
				grid.PassBodyJSONToModel(bp)
				grid.AccountKey = accountKey
				grid.GridKey = key
				validate := validator.New()
				err := validate.Struct(grid)
				if err != nil {
					errResponse := GetErrorResponseErrorMessage(k, err.Error())
					errorsResponse = append(errorsResponse, errResponse)
					// @TODO rollback data
					hasRollBack = true
					break
				} else {
					if resultFind.RowsAffected > 0 {
						resultSave := db.Where("GridKey = ? AND DataField = ? AND AccountKey = ?", grid.GridKey, grid.DataField, accountKey).Save(&grid)
						if resultSave.Error != nil {
							errResponse := GetErrorResponseErrorMessage(k, resultSave.Error.Error())
							errorsResponse = append(errorsResponse, errResponse)
							// @TODO rollback data
							hasRollBack = true
							break
						} else {
							dataResponse = append(dataResponse, grid)
							totalUpdatedRecord++
						}
					} else {
						resultCreate := db.Create(&grid)
						if resultCreate.Error != nil {
							errResponse := GetErrorResponseErrorMessage(k, resultCreate.Error.Error())
							errorsResponse = append(errorsResponse, errResponse)
							// @TODO rollback data
							hasRollBack = true
							break
						} else {
							arrIDNeedDeleteAtRollBack = append(arrIDNeedDeleteAtRollBack, grid.GridID)
							dataResponse = append(dataResponse, grid)
							totalUpdatedRecord++
						}
					}
				}
			}
			if hasRollBack {
				if len(arrIDNeedDeleteAtRollBack) > 0 {
					db.Where("GridID in (?)", arrIDNeedDeleteAtRollBack).Delete(&models.Grid{})
				}
				for _, v := range rollbackGrids {
					db.Save(&v)
				}
				dataResponse = rollbackGrids
			}
		}
	} else {
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}

	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, totalRecord, errorsResponse, false)
	data = ConvertGridToGridGET(requestHeader, db, dataResponse, lang)

	// @TODO waiting post finished
	//time.Sleep(7 * time.Second)
	arrGlobalGrid.SetValueToGlobalObject(accountKey, true)

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ConvertGridToGridGET func
func ConvertGridToGridGET(requestHeader models.RequestHeader, db *gorm.DB, grids []models.Grid, lang string) []models.GridGET {
	gridsGET := make([]models.GridGET, 0)
	if len(grids) > 0 {
		for _, v := range grids {
			var (
				gridGET models.GridGET
			)
			gridGET.GridKey = v.GridKey
			gridGET.AccountKey = v.AccountKey
			gridGET.DataField = v.DataField
			if v.TranslationKey != "" && v.TranslationKey != services.GetMessage(lang, v.TranslationKey) {
				gridGET.Caption = services.GetMessage(lang, v.TranslationKey)
			} else {
				gridGET.Caption = v.Caption
			}

			// UDF
			if strings.HasPrefix(gridGET.DataField, "U_") {
				gridGET.DataField = "UDF." + gridGET.DataField
				var (
					udf                  models.UDF
					translationResponses []models.TranslationResponse
				)
				resultFind := db.Where("DataField = ? AND TableName = ?", gridGET.DataField, gridGET.GridKey).First(&udf)
				if resultFind.RowsAffected > 0 {
					translationResponses = make([]models.TranslationResponse, 0)
					translationResponses = GetTranslationResponse(requestHeader, models.UDF{}.TableName(), udf.UDFID)
					for _, v := range translationResponses {
						if strings.ToLower(v.Language) == lang {
							gridGET.Caption = v.Value
							break
						}
					}
				}
			}

			gridGET.Visible = v.Visible
			gridGET.VisibleIndex = v.VisibleIndex
			gridGET.Width = v.Width
			gridGET.Format = v.Format
			gridGET.DataType = v.DataType
			gridGET.Alignment = v.Alignment
			gridGET.ShowInColumnChooser = v.ShowInColumnChooser
			gridGET.AllowGrouping = v.AllowGrouping
			gridGET.SortIndex = v.SortIndex
			gridGET.SortOrder = v.SortOrder
			gridGET.NumberPrecision = v.NumberPrecision
			gridGET.CellTemplate = v.CellTemplate
			gridGET.EditCellTemplate = v.EditCellTemplate
			gridGET.GroupIndex = v.GroupIndex
			gridsGET = append(gridsGET, gridGET)
		}
	}
	return gridsGET
}

// HasGetGrid func
func HasGetGrid(arrGlobalGrid *models.ArrGlobalGrid, accountKey int) bool {
	var (
		vArrGlobalGrid models.ArrGlobalGrid
	)
	if arrGlobalGrid != nil {
		vArrGlobalGrid = *arrGlobalGrid
	}
	hasAccountKey := false
	statusValue := false
	for _, v := range vArrGlobalGrid.GlobalGrid {
		if v.AccountKey == accountKey {
			hasAccountKey = true
			if v.Status {
				statusValue = true
			}
			break
		}
	}
	if !hasAccountKey {
		return true
	}
	return statusValue
}
