package controllers

import (
	"encoding/json"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetItemGroup godoc
// @Summary Get Item Group
// @Description Get Item Group
// @Tags ItemGroup
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /itemgroup [get]
func GetItemGroup(c *gin.Context) {
	defer libs.RecoverError(c, "GetItemGroup")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.ItemGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}
	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	// Filter

	// end
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"ItemGroupName", "ItemGroupCode"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// UDFs
	arrQueries := libs.GetArrayQueryParamsUDFFields(c, requestHeader, models.ItemGroup{}.TableName())
	bp = libs.FilterUDFs(arrQueries, bp)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayItemGroupToArrayResponse(resModels)
	for i, b := range responses {
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.ItemGroup{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemGroupID", v.DataType, b.ItemGroupID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses[i].UDFs = udfResponses
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetItemGroupByID godoc
// @Summary Get Item Group By ID
// @Description Get Item Group By ID
// @Tags ItemGroup
// @Accept  json
// @Produce  json
// @Param id path int true "Item Group ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /itemgroup/{id} [get]
func GetItemGroupByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetItemGroupByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.ItemGroup
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND ItemGroupID = ?", ID).First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertItemGroupToResponse(resModel)
		var (
			udfModels []models.UDF
		)
		dbu := db
		dbu = dbu.Where("TableName = ?", models.ItemGroup{}.TableName())
		dbu = dbu.Order("Sort ASC")
		dbu = dbu.Find(&udfModels)
		udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
		responses.UDF = make(map[string]interface{}) // declare field as a map[string]string
		for k, v := range udfResponses {
			val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemGroupID", v.DataType, responses.ItemGroupID)
			udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
			responses.UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
		}
		responses.UDFs = udfResponses
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateItemGroup godoc
// @Summary Create Item Group
// @Description Create Item Group
// @Tags ItemGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ItemGroup body []models.ItemGroupResponse true "Create Item Group"
// @Success 200 {object} models.APIResponseData
// @Router /itemgroup [post]
func CreateItemGroup(c *gin.Context) {
	apiName := "CreateItemGroup"
	defer libs.RecoverError(c, apiName)
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.ItemGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.ItemGroup, 0)
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				obj models.ItemGroup
			)
			obj.PassBodyJSONToModel(bp)

			resultFindItemGroupCode := db.Where("ItemGroupCode = ? AND IsDeleted = 0", obj.ItemGroupCode).First(&models.ItemGroup{})
			if resultFindItemGroupCode.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemgroupcode_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFindItemGroupName := db.Where("ItemGroupName = ? AND IsDeleted = 0", obj.ItemGroupName).First(&models.ItemGroup{})
			if resultFindItemGroupName.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemgroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			obj.CreatedBy = accountKey
			obj.ModifiedBy = accountKey
			// @TODO validate
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(obj)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				resultCreate := db.Create(&obj)
				if resultCreate.Error != nil {
					if itemMsgError == "" {
						itemMsgError = resultCreate.Error.Error()
					} else {
						itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
					}
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, obj)
					// @TODO process for UDFs
					arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
					// @TODO update data for UDFs
					errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ItemGroupID", obj.ItemGroupID)
					if len(errUDFs) > 0 {
						for _, e := range errUDFs {
							if itemMsgError == "" {
								itemMsgError = e.Error()
							} else {
								itemMsgError = itemMsgError + "\n" + e.Error()
							}
						}
					}
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, true)
	var (
		objs []models.ItemGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ItemGroupID)
	}
	if len(arrID) > 0 {
		db.Where("ItemGroupID in (?)", arrID).Find(&objs)
		dataResponses := ConvertArrayItemGroupToArrayResponse(objs)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.ItemGroup{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string
			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemGroupID", v.DataType, b.ItemGroupID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateItemGroup godoc
// @Summary Update Item Group
// @Description Update Item Group
// @Tags ItemGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param ItemGroup body []models.ItemGroup true "Update Item Group"
// @Success 200 {object} models.APIResponseData
// @Router /itemgroup [put]
func UpdateItemGroup(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateItemGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.ItemGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.ItemGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.ItemGroup
			)
			putModel.PassBodyJSONToModel(bp)

			resultFindItemGroupCode := db.Where("ItemGroupCode = ? AND IsDeleted = 0 AND ItemGroupID <> ?", putModel.ItemGroupCode, putModel.ItemGroupID).First(&models.ItemGroup{})
			if resultFindItemGroupCode.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemgroupcode_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFindItemGroupName := db.Where("ItemGroupName = ? AND IsDeleted = 0 AND ItemGroupID <> ?", putModel.ItemGroupName, putModel.ItemGroupID).First(&models.ItemGroup{})
			if resultFindItemGroupName.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.itemgroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("ItemGroupID = ?", putModel.ItemGroupID).First(&putModel)
			if resultFind.RowsAffected > 0 {
				putModel.PassBodyJSONToModel(bp)
				putModel.ModifiedBy = accountKey
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(putModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultSave := db.Save(&putModel)
					if resultSave.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultSave.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, putModel)
						// @TODO process for UDFs
						arrUDFs := libs.GetArrayUDFResponseFromJSON(bp)
						// @TODO update data for UDFs
						errUDFs := libs.UpdateToSQLByArrayUDFs(requestHeader, arrUDFs, "ItemGroupID", putModel.ItemGroupID)
						if len(errUDFs) > 0 {
							for _, e := range errUDFs {
								if itemMsgError == "" {
									itemMsgError = e.Error()
								} else {
									itemMsgError = itemMsgError + "\n" + e.Error()
								}
							}
						}
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.ItemGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.ItemGroupID)
	}
	if len(arrID) > 0 {
		db.Where("ItemGroupID in (?)", arrID).Find(&resModels)
		dataResponses := ConvertArrayItemGroupToArrayResponse(resModels)
		for i, b := range dataResponses {
			var (
				udfModels []models.UDF
			)
			dbu := db
			dbu = dbu.Where("TableName = ?", models.ItemGroup{}.TableName())
			dbu = dbu.Order("Sort ASC")
			dbu = dbu.Find(&udfModels)
			udfResponses := ConvertArrayUDFToArrayResponse(udfModels, lang, requestHeader)
			dataResponses[i].UDF = make(map[string]interface{}) // declare field as a map[string]string

			for k, v := range udfResponses {
				val := libs.GetValueOfUDF(requestHeader, v.TableNameObj, v.DataField, "ItemGroupID", v.DataType, b.ItemGroupID)
				udfResponses[k].Value = libs.ConvertDataTypeUDFValue(val, v.DataType)
				dataResponses[i].UDF[v.DataField] = libs.ConvertDataTypeUDFValue(val, v.DataType)
			}
			dataResponses[i].UDFs = udfResponses
		}
		data = dataResponses
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteItemGroup godoc
// @Summary Delete Item Group
// @Description Delete Item Group
// @Tags ItemGroup
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Item Group ID"
// @Success 200 {object} models.APIResponseData
// @Router /itemgroup/{id} [delete]
func DeleteItemGroup(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteItemGroup")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			resModel models.ItemGroup
		)
		resultFind := db.Where("ItemGroupID = ?", id).First(&resModel)
		if resultFind.RowsAffected > 0 {
			statusDelete := resModel.ValidateDelete(db, lang)
			if statusDelete.Status == 200 {
				resModel.IsDeleted = true
				resModel.ModifiedBy = accountKey
				deletedResult := db.Save(&resModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
				}
			} else {
				errResponse := GetErrorResponseErrorMessage(k, statusDelete.Message)
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}

	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, true)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayItemGroupToArrayResponse func
func ConvertArrayItemGroupToArrayResponse(items []models.ItemGroup) []models.ItemGroupResponse {
	responses := make([]models.ItemGroupResponse, 0)
	for _, item := range items {
		response := ConvertItemGroupToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertItemGroupToResponse func
func ConvertItemGroupToResponse(item models.ItemGroup) models.ItemGroupResponse {
	var (
		response models.ItemGroupResponse
	)
	response.ItemGroupID = item.ItemGroupID
	response.ItemGroupName = item.ItemGroupName
	response.ItemGroupCode = item.ItemGroupCode
	return response
}
