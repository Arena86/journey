package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// SmartScheduling godoc
// @Summary SmartScheduling
// @Description SmartScheduling
// @Tags Route
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AdvancedPED body models.AdvancedPEDResponse true "Create SmartScheduling"
// @Success 200 {object} models.APIResponseData
// @Router /smartscheduling [post]
func SmartScheduling(c *gin.Context) {
	defer libs.RecoverError(c, "SmartScheduling")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
		graphHopperJSON   models.GraphHopperJSON
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse = make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	// In body has one item not array
	var (
		routerJPJSON                   models.GraphHopperJPJSON
		timeStart, timeEnd             int64
		arrVehicles                    = make([]models.GraphHopperVehicle, 0)
		returnToDepot                  = true
		arrVehiclesType                = make([]models.GraphHopperVehicleTypeJSON, 0)
		arrVehiclesTypeID              = make([]int, 0)
		arrServices                    = make([]models.GraphHopperServiceJSON, 0)
		arrShipments                   = make([]models.GraphHopperShipmentJSON, 0)
		arrRelations                   = make([]models.GraphHoppeRelations, 0)
		mappingResourceAndResourceType = make(map[int]int) // map[resourceid]resourcetype
	)
	json.NewDecoder(c.Request.Body).Decode(&routerJPJSON)

	fmt.Printf("routerJPJSON: %+v\n", routerJPJSON)

	/* apiKey := "65c338c0-d609-4338-aa5e-a3447cad2025"
	url := "https://graphhopper.com/api/1/vrp/optimize"
	networkDataProvider := "openstreetmap" */

	graphHopperConfig := libs.GetGraphHopper(accountKey)
	apiKey := graphHopperConfig.APIKey
	url := graphHopperConfig.APIURL + "/optimize"
	networkDataProvider := graphHopperConfig.NetworkDataProvider

	params := make(map[string]interface{})
	params["key"] = apiKey
	headers := make(map[string]interface{})
	headers["Content-Type"] = "application/json"

	graphHopperJSON.Objectives = routerJPJSON.Objectives
	var routing models.GraphHopperConfigurationRouting
	routing.CalcPoints = graphHopperConfig.CalcPoints
	routing.ConsiderTraffic = routerJPJSON.ConsiderTraffic
	routing.SnapPreventions = routerJPJSON.SnapPreventions
	routing.NetworkDataProvider = networkDataProvider

	var configuration models.GraphHopperConfiguration
	configuration.Routing = &routing
	graphHopperJSON.Configuration = &configuration

	dTimeStart, sTimeStart := libs.ConvertStringToDateTime(routerJPJSON.TimeStart)
	if sTimeStart == nil {
		timeStart = dTimeStart.Unix()
	}
	dTimeEnd, sTimeEnd := libs.ConvertStringToDateTime(routerJPJSON.TimeEnd)
	if sTimeEnd == nil {
		timeEnd = dTimeEnd.Unix()
	}

	fmt.Println("timeStart: ", timeStart)
	fmt.Println("timeEnd: ", timeEnd)
	timeWindowObj := models.GraphHopperTimeWindowJSON{Earliest: timeStart, Latest: timeEnd}
	timeWindowGraphHopper := []models.GraphHopperTimeWindowJSON{timeWindowObj}

	for _, resourceID := range routerJPJSON.ResourceIDs {
		var (
			vehicleObj     models.GraphHopperVehicle
			vehicleTypeObj models.GraphHopperVehicleTypeJSON
			resourceModel  models.Resource
			locationModel  models.Location
			startAddress   models.GraphHopperAddressJSON
			//arrBreakVehicleObj = make([]models.GraphHopperDriveTimeBreakJSON, 0)
			breakVehicleObj models.GraphHopperDriveTimeBreakJSON
		)
		resultFindResource := db.Where("ResourceID = ?", resourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&resourceModel)
		if resultFindResource.RowsAffected > 0 {
			//Vehicles
			vehicleObj.VehicleID = strconv.Itoa(resourceID)
			resourceTypeName := libs.MappingResourceTypeToGraphHopper(resourceModel.ResourceType)
			vehicleObj.TypeID = strconv.Itoa(resourceModel.ResourceType)
			resultFindLocation := db.Where("LocationID = ?", resourceModel.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&locationModel)
			if resultFindLocation.RowsAffected > 0 {
				startAddress.LocationID = strconv.Itoa(locationModel.LocationID)
				if locationModel.Longitude != nil {
					startAddress.Lon = *locationModel.Longitude
				}
				if locationModel.Latitude != nil {
					startAddress.Lat = *locationModel.Latitude
				}
				startAddress.Name = locationModel.LocationName
				vehicleObj.StartAddress = &startAddress
				if locationModel.BackToDepot {
					vehicleObj.EndAddress = &startAddress
				}
				if resourceModel.UseMaxDrivingTime {
					breakVehicleObj.Duration = int64(resourceModel.BreakDuration)
					breakVehicleObj.MaxDrivingTime = int64(resourceModel.MaxDrivingTime)
					breakVehicleObj.InitialDrivingTime = int64(resourceModel.InitialDrivingTime)
					vehicleObj.Break = &breakVehicleObj
					//arrBreakVehicleObj = append(arrBreakVehicleObj, breakVehicleObj)
				}

				returnToDepot = locationModel.BackToDepot
				vehicleObj.ReturnToDepot = returnToDepot
				vehicleObj.EarliestStart = timeStart
				vehicleObj.LatestEnd = timeEnd
				vehicleObj.MaxDistance = resourceModel.MaxDistance
				vehicleObj.MaxDrivingTime = resourceModel.TotalMaxDrivingTime
				vehicleObj.MaxJobs = resourceModel.MaxJobs
				vehicleObj.MinJobs = resourceModel.MinJobs
			}
			vehicleObj.EarliestStart = timeStart
			vehicleObj.LatestEnd = timeEnd
			vehicleObj.MoveToEndAddress = false
			arrVehicles = append(arrVehicles, vehicleObj)
			//VehiclesType
			if !libs.InArrayInteger(resourceModel.ResourceType, arrVehiclesTypeID) {
				// check exist resource id
				arrVehiclesTypeID = append(arrVehiclesTypeID, resourceModel.ResourceType)
				vehicleTypeObj.TypeID = strconv.Itoa(resourceModel.ResourceType)
				vehicleTypeObj.Profile = resourceTypeName
				vehicleTypeObj.ConsiderTraffic = routerJPJSON.ConsiderTraffic
				vehicleTypeObj.NetworkDataProvider = networkDataProvider
				arrVehiclesType = append(arrVehiclesType, vehicleTypeObj)
			}
			// mapping resource type
			_, hasResource := mappingResourceAndResourceType[resourceModel.ResourceID]
			if !hasResource {
				mappingResourceAndResourceType[resourceModel.ResourceID] = resourceModel.ResourceType
			}
		}
	}
	graphHopperJSON.Vehicles = arrVehicles
	graphHopperJSON.VehicleTypes = arrVehiclesType
	for _, jobID := range routerJPJSON.JobIDs {
		var (
			jobModel         models.Job
			serviceObj       models.GraphHopperServiceJSON
			shipmentObj      models.GraphHopperShipmentJSON
			jobTaskModels    []models.JobTask
			durationJobTasks int64
			//arrResourceTypeName     []string
			//resourceModels          []models.Resource
			//scheduleModels          []models.Schedule
			//arrResourceIDOnSchedule []int
			arrAllowedVehicle []string
		)
		resultFindJob := db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
		if resultFindJob.RowsAffected > 0 {
			db.Where("JobID = ?", jobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobTaskModels)
			for _, jobTaskVar := range jobTaskModels {
				durationJobTasks = durationJobTasks + int64(jobTaskVar.ServiceTimeInMinutes)
			}
			jobTypeName, _ := libs.GetEnum(requestHeader, jobModel.JobType, "JobType", lang)
			for keyResource, keyResourceType := range mappingResourceAndResourceType {
				if keyResourceType == jobModel.ResourceType {
					sKeyResource := strconv.Itoa(keyResource)
					if !libs.InArrayString(sKeyResource, arrAllowedVehicle) {
						arrAllowedVehicle = append(arrAllowedVehicle, sKeyResource)
					}
				}
			}

			if jobModel.JobType != 4 { // @TOTO Not Pickup & Delivery Job
				if jobModel.JobType == 6 { // @TOTO Check Multiple Job
					var (
						jobMultiple models.JobMultiple
						mJob        models.Job
						mJobTask    []models.JobTask
					)
					resultFindPrimaryJob := db.Preload(
						"JobMultiple",
						"IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1",
					).Where("JobID = ?", jobModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&mJob)
					if resultFindPrimaryJob.RowsAffected > 0 && mJob.JobMultiple != nil {

						jobMultiple = *mJob.JobMultiple
						resultFindJobTask := db.Where("JobID = ?", jobMultiple.PrimaryJobID).
							Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&mJobTask)
						if resultFindJobTask.RowsAffected > 0 {
							durationJobTasks := int64(mJobTask[0].ServiceTimeInMinutes)
							serviceObj = GeneratedService(mJob, jobTypeName, mJobTask[0], durationJobTasks, timeWindowGraphHopper, routerJPJSON, arrAllowedVehicle)
							arrServices = append(arrServices, serviceObj)
						}
					}
				} else if jobModel.JobType == 9 { // @TOTO Check Combined Job
					var (
						mJobSelections []models.JobSelection
						jobCombined    models.JobCombined
					)
					resultFindPrimaryJob := db.Where("JobID = ?", jobModel.JobID).
						Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("Sort ASC").Find(&mJobSelections)
					if resultFindPrimaryJob.RowsAffected > 0 {
						// @TOTO Add relation
						var (
							allService      []string
							sequenceService []string
						)
						db.Where("JobID = ?", jobModel.JobID).
							Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobCombined)
						for _, relatedJob := range mJobSelections {
							var (
								mJob models.Job
							)
							resultFindJob := db.Preload("JobTasks", "IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").
								Where("JobID = ?", relatedJob.RelatedJobID).
								Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&mJob)
							if resultFindJob.RowsAffected > 0 {
								jobTypeName, _ := libs.GetEnum(requestHeader, mJob.JobType, "JobType", lang)
								if mJob.JobType != 4 {
									durationJobTasks := int64(mJob.JobTasks[0].ServiceTimeInMinutes)
									serviceObj = GeneratedService(mJob, jobTypeName, mJob.JobTasks[0], durationJobTasks, timeWindowGraphHopper, routerJPJSON, arrAllowedVehicle)
									arrServices = append(arrServices, serviceObj)
								} else {
									shipmentObj = GeneratedShipment(mJob.JobTasks, timeWindowGraphHopper)
									shipmentObj.ID = strconv.Itoa(mJob.JobID)
									shipmentObj.Name = jobTypeName
									shipmentObj.Priority = int32(mJob.Priority)
									if routerJPJSON.UseAllowedVehicles {
										shipmentObj.AllowedVehicles = arrAllowedVehicle
									}
									arrShipments = append(arrShipments, shipmentObj)
								}
								allService = append(allService, strconv.Itoa(mJob.JobID))
								if relatedJob.HasSequence {
									sequenceService = append(sequenceService, strconv.Itoa(mJob.JobID))
								}
							}
						}
						if jobCombined.JobCombinedID > 0 {
							if jobCombined.OnTheSameRoute && len(allService) > 1 {
								var relation models.GraphHoppeRelations
								relation.Type = "in_same_route"
								relation.IDs = allService
								arrRelations = append(arrRelations, relation)
							}
							if (jobCombined.Sequence == "in_sequence" ||
								jobCombined.Sequence == "in_direct_sequence") && len(sequenceService) > 1 {
								var relation models.GraphHoppeRelations
								relation.Type = jobCombined.Sequence
								relation.IDs = sequenceService
								arrRelations = append(arrRelations, relation)
							}
						}
					}
				} else {
					serviceObj = GeneratedService(jobModel, jobTypeName, jobTaskModels[0], durationJobTasks, timeWindowGraphHopper, routerJPJSON, arrAllowedVehicle)
					arrServices = append(arrServices, serviceObj)
				}

			} else {
				shipmentObj = GeneratedShipment(jobTaskModels, timeWindowGraphHopper)
				shipmentObj.ID = strconv.Itoa(jobModel.JobID)
				shipmentObj.Name = jobTypeName
				shipmentObj.Priority = int32(jobModel.Priority)
				if routerJPJSON.UseAllowedVehicles {
					shipmentObj.AllowedVehicles = arrAllowedVehicle
				}
				arrShipments = append(arrShipments, shipmentObj)
			}
		}
	}
	graphHopperJSON.Services = arrServices
	graphHopperJSON.Shipments = arrShipments
	graphHopperJSON.Relations = arrRelations
	res2B, _ := json.Marshal(graphHopperJSON)
	fmt.Println("graphHopperJSON: ", string(res2B))
	fmt.Println("url: ", url)
	statusRes, msgRes, dataRes := libs.RequestAPI(lang, "POST", url, graphHopperJSON, params, headers)
	fmt.Println("statusRes: ", statusRes)
	fmt.Println("msgRes: ", msgRes)
	fmt.Println("dataRes: ", string(dataRes))
	if statusRes == 200 {
		var graphHopperResponse map[string]interface{}
		json.Unmarshal(dataRes, &graphHopperResponse)
		graphHopperResponse["request"] = string(res2B)
		data = graphHopperResponse
		msg = services.GetMessage(lang, "api.success")
	} else {
		fmt.Println("graphHopperJSON", string(res2B))
		var (
			errorGraphHopper models.GraphHopperError
			errMsg           string
		)
		if len(dataRes) > 0 {
			json.Unmarshal(dataRes, &errorGraphHopper)
			for _, errHint := range errorGraphHopper.Hints {
				errMsg = libs.GetStringWithWordBetween(errMsg, errHint.Message)
			}
			if errMsg == "" {
				errMsg = errorGraphHopper.Message
			}
		} else {
			errMsg = fmt.Sprintf("%v", msgRes)
		}
		msg = errMsg
		status = statusRes
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GeneratedService(jobModel models.Job, jobTypeName string,
	jobTaskProcessing models.JobTask, durationJobTasks int64,
	timeWindowGraphHopper []models.GraphHopperTimeWindowJSON,
	routerJPJSON models.GraphHopperJPJSON, arrAllowedVehicle []string) models.GraphHopperServiceJSON {
	var (
		serviceObj models.GraphHopperServiceJSON
	)
	serviceObj.ID = strconv.Itoa(jobModel.JobID)
	serviceObj.Type = "service"
	serviceObj.Priority = int32(jobModel.Priority)
	serviceObj.Name = jobTypeName
	var serviceAddress models.GraphHopperAddressJSON
	serviceAddress.LocationID = strconv.Itoa(jobTaskProcessing.JobTaskID)
	if jobTaskProcessing.Longitude != nil {
		serviceAddress.Lon = *jobTaskProcessing.Longitude
	}
	if jobTaskProcessing.Latitude != nil {
		serviceAddress.Lat = *jobTaskProcessing.Latitude
	}
	serviceAddress.Name = jobTaskProcessing.NavigationAddress
	serviceObj.Address = &serviceAddress
	serviceObj.Duration = durationJobTasks * 60
	serviceObj.TimeWindows = timeWindowGraphHopper
	if routerJPJSON.UseAllowedVehicles {
		serviceObj.AllowedVehicles = arrAllowedVehicle
	}
	return serviceObj

}
func GeneratedShipment(jobTaskModels []models.JobTask, timeWindowGraphHopper []models.GraphHopperTimeWindowJSON) models.GraphHopperShipmentJSON {
	var (
		shipmentObj models.GraphHopperShipmentJSON
	)
	for _, jobTaskVar := range jobTaskModels {
		if jobTaskVar.JobType == 2 {
			// pickup
			var (
				pickupObj        models.GraphHopperPickupOrDeliveryJSON
				pickupAddressObj models.GraphHopperAddressJSON
			)
			pickupAddressObj.LocationID = strconv.Itoa(jobTaskVar.JobTaskID)
			if jobTaskVar.Longitude != nil {
				pickupAddressObj.Lon = *jobTaskVar.Longitude
			}
			if jobTaskVar.Latitude != nil {
				pickupAddressObj.Lat = *jobTaskVar.Latitude
			}
			pickupAddressObj.Name = jobTaskVar.NavigationAddress
			pickupObj.Address = &pickupAddressObj
			pickupObj.Duration = int64(jobTaskVar.ServiceTimeInMinutes) * 60
			pickupObj.TimeWindows = timeWindowGraphHopper
			shipmentObj.Pickup = &pickupObj
		} else if jobTaskVar.JobType == 3 {
			// delivery
			var (
				deliveryObj        models.GraphHopperPickupOrDeliveryJSON
				deliveryAddressObj models.GraphHopperAddressJSON
			)
			deliveryAddressObj.LocationID = strconv.Itoa(jobTaskVar.JobTaskID)
			if jobTaskVar.Longitude != nil {
				deliveryAddressObj.Lon = *jobTaskVar.Longitude
			}
			if jobTaskVar.Latitude != nil {
				deliveryAddressObj.Lat = *jobTaskVar.Latitude
			}
			deliveryAddressObj.Name = jobTaskVar.NavigationAddress
			deliveryObj.Address = &deliveryAddressObj
			deliveryObj.Duration = int64(jobTaskVar.ServiceTimeInMinutes) * 60
			deliveryObj.TimeWindows = timeWindowGraphHopper
			shipmentObj.Delivery = &deliveryObj
		}
	}
	return shipmentObj
}

// GetSmartScheduling godoc
// @Summary GetSmartScheduling
// @Description GetSmartScheduling
// @Tags Route
// @Accept  json
// @Produce  json
// @Param graphhopperjobid path int true "graph hopper job id"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /smartscheduling/{graphhopperjobid} [get]
func GetSmartScheduling(c *gin.Context) {
	defer libs.RecoverError(c, "GetSmartScheduling")
	var (
		status   = libs.GetStatusSuccess()
		response models.APIResponseData
		msg      interface{}
		data     interface{}
	)
	statusCheckHeader, ResponseCheckHeader, _ := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	graphHopperJobID := c.Param("graphhopperjobid")
	graphHopperConfig := libs.GetGraphHopper(accountKey)
	apiKey := graphHopperConfig.APIKey
	url := graphHopperConfig.APIURL + "/solution/" + graphHopperJobID
	//networkDataProvider := graphHopperConfig.NetworkDataProvider

	params := make(map[string]interface{})
	params["key"] = apiKey
	headers := make(map[string]interface{})
	headers["Content-Type"] = "application/json"

	statusRes, _, dataRes := libs.RequestAPI(lang, "GET", url, nil, params, headers)
	if statusRes == 200 {
		var graphHopperResponse models.GraphHopperResponseSuccess
		json.Unmarshal(dataRes, &graphHopperResponse)
		//fmt.Println("graphHopperResponse: ", string(dataRes))
		if len(graphHopperResponse.Solution.UnAssigned.Details) > 0 {
			for graphResKey, graphResDetail := range graphHopperResponse.Solution.UnAssigned.Details {
				graphHopperResponse.Solution.UnAssigned.Details[graphResKey].Reason = GetTranslationMessageCodeFromGraphHopperToJP(lang, graphResDetail.Code, graphResDetail.Reason)
			}
		}
		data = graphHopperResponse
		msg = services.GetMessage(lang, "api.success")
	} else {
		var (
			errorGraphHopper models.GraphHopperError
		)
		json.Unmarshal(dataRes, &errorGraphHopper)
		msg = errorGraphHopper.Message
		status = statusRes
		for keyHint, errHint := range errorGraphHopper.Hints {
			errResponse := GetErrorResponseErrorMessage(keyHint, errHint.Message)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// ScheduleSmartScheduling godoc
// @Summary ScheduleSmartScheduling
// @Description ScheduleSmartScheduling
// @Tags Route
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AdvancedPED body models.AdvancedPEDResponse true "Create ScheduleSmartScheduling"
// @Success 200 {object} models.APIResponseData
// @Router /schedule/smartscheduling [post]
func ScheduleSmartScheduling(c *gin.Context) {
	defer libs.RecoverError(c, "GetSmartScheduling")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	//locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	var graphHopperResponse models.GraphHopperResponseSuccess

	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &graphHopperResponse)

	if len(graphHopperResponse.Solution.UnAssigned.Details) > 0 {
		for graphResKey, graphResDetail := range graphHopperResponse.Solution.UnAssigned.Details {
			graphHopperResponse.Solution.UnAssigned.Details[graphResKey].Reason = GetTranslationMessageCodeFromGraphHopperToJP(lang, graphResDetail.Code, graphResDetail.Reason)
		}
	}

	if graphHopperResponse.Status == "finished" {
		// auto schedule
		for _, routeObj := range graphHopperResponse.Solution.Routes {
			for _, activitieObj := range routeObj.Activities {
				if activitieObj.Type == "start" || activitieObj.Type == "end" {
					continue
				}
				var (
					objectsJSON = make(map[string]interface{})
					taskModel   models.JobTask
					jobModel    models.Job
					jobID       int
					//jobStatus   int
					locationID int
				)
				resourceID, _ := strconv.Atoi(routeObj.VehicleID)
				jobTaskID, _ := strconv.Atoi(activitieObj.LocationID)
				startTime := activitieObj.ArrTime
				dStartTime := time.Unix(startTime, 0).UTC()
				sStartTime := dStartTime.Format("2006-01-02 15:04:05")
				/* fmt.Println("startTime UNIX: ", startTime)
				fmt.Println("startTime Time: ", dStartTime)
				fmt.Println("startTime Time Convert: ", sStartTime)
				fmt.Println() */
				endTime := activitieObj.EndTime
				dEndTime := time.Unix(endTime, 0).UTC()
				sEndTime := dEndTime.Format("2006-01-02 15:04:05")
				resultFindJobTask := db.Where("JobTaskID = ?", jobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&taskModel)
				if resultFindJobTask.RowsAffected > 0 {
					jobID = taskModel.JobID
					resultFindJob := db.Where("JobID = ?", taskModel.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobModel)
					if resultFindJob.RowsAffected > 0 {
						locationID = jobModel.LocationID
					}
				}
				objectsJSON["ScheduleStartDate"] = sStartTime
				objectsJSON["ScheduleEndDate"] = sEndTime
				objectsJSON["ResourceID"] = resourceID
				objectsJSON["UserID"] = 0
				objectsJSON["JobID"] = jobID
				objectsJSON["JobTaskID"] = jobTaskID
				objectsJSON["LocationID"] = locationID
				AutoScheduleAfterCallGraphHopper(c, objectsJSON)
			}
		}
		msg = services.GetMessage(lang, "api.success")
		//data = graphHopperResponse
	} else {
		status = 422
		msg = services.GetMessage(lang, "graphhopper.job_not_finished")
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// SmartSchedulingSchedule godoc
// @Summary SmartSchedulingSchedule
// @Description SmartSchedulingSchedule
// @Tags Route
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param AdvancedPED body models.AdvancedPEDResponse true "Create ScheduleSmartScheduling"
// @Success 200 {object} models.APIResponseData
// @Router /smartschedulingschedule [post]
func SmartSchedulingSchedule(c *gin.Context) {
	defer libs.RecoverError(c, "SmartSchedulingSchedule")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		arrSmartSchedule   []models.SmartSchedulingSchedule
		totalUpdatedRecord = 0
		schedules          []models.Schedule
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))

	objectsJSON, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(objectsJSON)), &arrSmartSchedule)
	for _, sc := range arrSmartSchedule {
		var (
			schedule     models.Schedule
			itemMsgError string
			job          models.Job
			jobTask      models.JobTask
		)
		db.Where("JobTaskID = ?", sc.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
		schedule.JobID = jobTask.JobID
		schedule.LocationID = locationID
		schedule.JobTaskID = sc.JobTaskID
		schedule.ResourceID = sc.ResourceID
		schedule.ScheduleStartDate = sc.ScheduleStartDate
		schedule.ScheduleEndDate = sc.ScheduleEndDate
		schedule.ModifiedBy = accountKey
		schedule.CreatedBy = accountKey
		resultCreate := db.Create(&schedule)
		if resultCreate.Error != nil {
			itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
		} else {
			totalUpdatedRecord++
			var (
				precomputedRoute models.PrecomputedRoute
			)
			// update schedule start date & end date
			if jobTask.JobTaskID > 0 {
				jobTask.ModifiedBy = accountKey
				jobTask.ScheduleStartDateTime = &schedule.ScheduleStartDate
				jobTask.ScheduleEndDateTime = &schedule.ScheduleEndDate
				db.Save(&jobTask)

				precomputedRoute.TaskID = jobTask.JobTaskID
				precomputedRoute.PrecomputedRoute = sc.PreComputedRoute
				precomputedRoute.PrecomputedRouteWeb = sc.PreComputedRoute
				db.Where("TaskID = ?", jobTask.JobTaskID).Delete(&models.PrecomputedRoute{})
				db.Create(&precomputedRoute)

				resultFindJob := db.Where("JobID = ?", jobTask.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
				if resultFindJob.RowsAffected > 0 {
					UpdateJobStatus(requestHeader, schedule.JobID, 1, accountKey, c)
				}
			}

			schedules = append(schedules, schedule)
		}
		if itemMsgError != "" {
			errResponse := GetErrorResponseErrorMessage(0, itemMsgError)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	data = ConvertArraySchedulesToArrayResponse(requestHeader, schedules, lang)
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(arrSmartSchedule), errorsResponse, false)

	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

func GetTranslationMessageCodeFromGraphHopperToJP(lang string, code int32, reason string) string {
	var message string
	switch code {
	case 1:
		message = services.GetMessage(lang, "graphhopper.code_1")
	case 2:
		message = services.GetMessage(lang, "graphhopper.code_2")
	case 3:
		message = services.GetMessage(lang, "graphhopper.code_3")
	case 4:
		message = services.GetMessage(lang, "graphhopper.code_4")
	case 21:
		message = services.GetMessage(lang, "graphhopper.code_21")
	case 22:
		message = services.GetMessage(lang, "graphhopper.code_22")
	case 23:
		message = services.GetMessage(lang, "graphhopper.code_23")
	case 24:
		message = services.GetMessage(lang, "graphhopper.code_24")
	case 25:
		message = services.GetMessage(lang, "graphhopper.code_25")
	case 26:
		message = services.GetMessage(lang, "graphhopper.code_26")
	case 27:
		message = services.GetMessage(lang, "graphhopper.code_27")
	case 28:
		message = services.GetMessage(lang, "graphhopper.code_28")
	case 50:
		message = services.GetMessage(lang, "graphhopper.code_50")
	default:
		message = reason
	}
	return message
}

func AutoScheduleAfterCallGraphHopper(c *gin.Context, objectsJSON map[string]interface{}) string {
	var (
		schedule     models.Schedule
		itemMsgError string
	)
	lang := services.GetLanguageKey(c)
	statusCheckHeader, _, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		itemMsgError = services.GetMessage(lang, "api.header_request_error")
	} else {
		db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

		accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
		schedule.PassBodyJSONToModel(objectsJSON)
		schedule.CreatedBy = accountKey
		schedule.ModifiedBy = accountKey
		validate, trans := services.GetValidatorTranslate()
		err := validate.Struct(schedule)
		if err != nil {
			errs := err.(validator.ValidationErrors)
			for _, e := range errs {
				itemMsgError = e.Translate(trans)
			}
		}
		if itemMsgError == "" {
			resultCreate := db.Create(&schedule)
			if resultCreate.Error != nil {
				itemMsgError = libs.GetStringWithWordBetween(itemMsgError, resultCreate.Error.Error())
			}
		}
		if itemMsgError == "" {
			var (
				job     models.Job
				jobTask models.JobTask
			)
			// update job status = 1=Scheduled by jobid on schedules table
			resultFindJob := db.Where("JobID = ?", schedule.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
			if resultFindJob.RowsAffected > 0 {
				UpdateJobStatus(requestHeader, schedule.JobID, 1, accountKey, c)
			}
			// update schedule start date & end date
			resultFindJobTask := db.Where("JobTaskID = ?", schedule.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
			if resultFindJobTask.RowsAffected > 0 {
				jobTask.ModifiedBy = accountKey
				jobTask.ScheduleStartDateTime = &schedule.ScheduleStartDate
				jobTask.ScheduleEndDateTime = &schedule.ScheduleEndDate
				db.Save(&jobTask)
			}
			// Update additional users
			UpdateAdditionalUser(accountKey, schedule, requestHeader, objectsJSON)
		}
	}
	return itemMsgError
}
