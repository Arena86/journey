package controllers

import (
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// GetExternalResource godoc
// @Summary GetExternalResource
// @Description GetExternalResource
// @Tags Resource
// @Accept  json
// @Produce  json
// @Param ShowInScheduler query bool false "ShowInScheduler"
// @Param IsCompany query bool false "IsCompany"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /externalresource [get]
/// iscompany => true , get all resource <> location id header
/// iscompany => false, location id header > get group > get all resource in group <> location id header
/// response
/// schedule by resourceid, locationid
func GetExternalResource(c *gin.Context) {
	defer libs.RecoverError(c, "GetExternalResource")
	var (
		status          = libs.GetStatusSuccess()
		requestHeader   models.RequestHeader
		response        models.APIResponseData
		msg             interface{}
		data            interface{}
		resModels       []models.Resource
		showInScheduler = false
		isCompany       = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND ResourceMode IN (1,2)")

	vShowInScheduler, sShowInScheduler := libs.GetQueryParam("ShowInScheduler", c)
	if sShowInScheduler {
		showInScheduler, _ = strconv.ParseBool(vShowInScheduler)
	}
	bp = bp.Where("ShowInScheduler = ?", showInScheduler)
	vIsCompany, sIsCompany := libs.GetQueryParam("IsCompany", c)
	if sIsCompany {
		isCompany, _ = strconv.ParseBool(vIsCompany)
	}
	if isCompany {
		bp = bp.Where("LocationID <> ?", locationID)
	} else {
		var (
			location       models.Location
			locations      []models.Location
			arrLocationsID = make([]int, 0)
		)
		resultFindLocation := db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
		if resultFindLocation.RowsAffected > 0 {
			db.Where("LocationGroupID = ?", location.LocationGroupID).Find(&locations)
			for _, location := range locations {
				// get location in group <> locationid on header
				if location.LocationID != locationID {
					arrLocationsID = append(arrLocationsID, location.LocationID)
				}
			}
		}
		if len(arrLocationsID) <= 0 {
			arrLocationsID = append(arrLocationsID, -1)
		}
		bp = bp.Where("LocationID in (?)", arrLocationsID)
	}
	var totalCount int64
	totalCount = 0
	bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	data = ConvertArrayResourceToArrayExternalResourceResponse(requestHeader, resModels, c, lang)
	msg = services.GetMessage(lang, "api.success")
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetAvailableUser godoc
// @Summary GetAvailableUser
// @Description GetAvailableUser
// @Tags User
// @Accept  json
// @Produce  json
// @Param OnlyExternal query bool false "OnlyExternal"
// @Param IsCompany query bool false "IsCompany"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /availableuser [get]
/// onlyexternal > false > get all user by locationid header
/// onlyexternal > true > check iscompany and not get user by locationid header
/// response
/// schedule by userid, locationid
func GetAvailableUser(c *gin.Context) {
	defer libs.RecoverError(c, "GetAvailableUser")
	var (
		status        = libs.GetStatusSuccess()
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		data          interface{}
		resModels     []models.User
		onlyExternal  = false
		isCompany     = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	locationID, _ := strconv.Atoi(c.Request.Header.Get("locationid"))
	//locationGroupID, _ := strconv.Atoi(c.Request.Header.Get("locationgroupid"))

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1")

	vOnlyExternal, sOnlyExternal := libs.GetQueryParam("OnlyExternal", c)
	if sOnlyExternal {
		onlyExternal, _ = strconv.ParseBool(vOnlyExternal)
	}
	// filter firstname, lastname
	vFirstName, sFirstName := libs.GetQueryParam("FirstName", c)
	vLastName, sLastName := libs.GetQueryParam("LastName", c)
	if sFirstName && sLastName {
		bp = bp.Where("FirstName like ? OR LastName like ?", "%"+vFirstName+"%", "%"+vLastName+"%")
	} else if sFirstName {
		bp = bp.Where("FirstName like ?", "%"+vFirstName+"%")
	} else if sLastName {
		bp = bp.Where("LastName like ?", "%"+vLastName+"%")
	}

	if !onlyExternal {
		bp = bp.Where("LocationID = ?", locationID)
	} else {
		vIsCompany, sIsCompany := libs.GetQueryParam("IsCompany", c)
		if sIsCompany {
			isCompany, _ = strconv.ParseBool(vIsCompany)
		}
		if isCompany {
			bp = bp.Where("LocationID <> ?", locationID)
		} else {
			var (
				location       models.Location
				locations      []models.Location
				arrLocationsID = make([]int, 0)
			)
			resultFindLocation := db.Where("LocationID = ?", locationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
			if resultFindLocation.RowsAffected > 0 {
				db.Where("LocationGroupID = ?", location.LocationGroupID).Find(&locations)
				for _, location := range locations {
					// get location in group <> locationid on header
					if location.LocationID != locationID {
						arrLocationsID = append(arrLocationsID, location.LocationID)
					}
				}
			}
			if len(arrLocationsID) <= 0 {
				arrLocationsID = append(arrLocationsID, -1)
			}
			bp = bp.Where("LocationID in (?)", arrLocationsID)
		}
	}

	// Soft
	bp = libs.SortDataOnParam(bp, c, "LocationName")
	locationNameSort := libs.GetSortValueFromKey(c, "LocationName")
	if locationNameSort != "" {
		dbS := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
		//

		var locations []models.Location
		arrLocationIDSort := make([]int, 0)
		dbS.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Order("LocationName " + locationNameSort).Find(&locations)
		for _, location := range locations {
			arrLocationIDSort = append(arrLocationIDSort, location.LocationID)
		}
		if len(arrLocationIDSort) > 0 {
			strJoin := libs.IntJoin(arrLocationIDSort)
			if strJoin != "" {
				bp = bp.Order("FIELD(LocationID," + strJoin + ")")
			}
		}
	}
	var totalCount int64
	totalCount = 0
	bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	data = ConvertArrayUserToArrayAvailableUserResponse(requestHeader, resModels, c, lang)
	msg = services.GetMessage(lang, "api.success")
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayUserToArrayAvailableUserResponse func
func ConvertArrayUserToArrayAvailableUserResponse(requestHeader models.RequestHeader, items []models.User, c *gin.Context, lang string) []models.AvailableUser {
	responses := make([]models.AvailableUser, 0)
	for _, item := range items {
		response := ConvertUserToAvailableUserResponse(requestHeader, item, c, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertUserToAvailableUserResponse func
func ConvertUserToAvailableUserResponse(requestHeader models.RequestHeader, item models.User, c *gin.Context, lang string) models.AvailableUser {
	var (
		response                  models.AvailableUser
		location                  models.Location
		schedules                 []models.Schedule
		externalResourceSchedules = make([]models.ExternalResourceSchedule, 0)
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.UserID = item.UserID
	response.FirstName = item.FirstName
	response.LastName = item.LastName
	response.PhoneNumber = item.PhoneNumber
	response.Email = item.Email
	response.LocationID = item.LocationID
	resultFindLocation := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
	if resultFindLocation.RowsAffected > 0 {
		response.LocationName = location.LocationName
	}
	db.Where("UserID = ? AND LocationID = ?", item.UserID, item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&schedules)
	for _, schedule := range schedules {
		externalResourceSchedule := GetExternalSchedules(requestHeader, schedule, lang)
		externalResourceSchedules = append(externalResourceSchedules, externalResourceSchedule)
	}
	response.Schedules = externalResourceSchedules
	return response
}

// ConvertArrayResourceToArrayExternalResourceResponse func
func ConvertArrayResourceToArrayExternalResourceResponse(requestHeader models.RequestHeader, items []models.Resource, c *gin.Context, lang string) []models.ExternalResource {
	responses := make([]models.ExternalResource, 0)
	for _, item := range items {
		response := ConvertResourceToExternalResourceResponse(requestHeader, item, c, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertResourceToExternalResourceResponse func
func ConvertResourceToExternalResourceResponse(requestHeader models.RequestHeader, item models.Resource, c *gin.Context, lang string) models.ExternalResource {
	var (
		response                  models.ExternalResource
		location                  models.Location
		schedules                 []models.Schedule
		externalResourceSchedules = make([]models.ExternalResourceSchedule, 0)
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.ResourceID = item.ResourceID
	response.ResourceCode = item.ResourceCode
	response.ResourceName = item.ResourceName
	response.ResourceMode = item.ResourceMode
	response.ResourceModeName, response.ResourceModeIcon = libs.GetEnum(requestHeader, item.ResourceMode, "ResourceMode", lang)
	response.ResourceType = item.ResourceType
	response.ResourceTypeName, response.ResourceTypeIcon = libs.GetEnum(requestHeader, item.ResourceType, "ResourceType", lang)
	response.LocationID = item.LocationID
	resultFindLocation := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&location)
	if resultFindLocation.RowsAffected > 0 {
		response.LocationName = location.LocationName
	}
	db.Where("ResourceID = ? AND LocationID = ?", item.ResourceID, item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&schedules)
	for _, schedule := range schedules {
		externalResourceSchedule := GetExternalSchedules(requestHeader, schedule, lang)
		externalResourceSchedules = append(externalResourceSchedules, externalResourceSchedule)
	}
	response.Schedules = externalResourceSchedules
	return response
}

// GetExternalSchedules func
func GetExternalSchedules(requestHeader models.RequestHeader, schedule models.Schedule, lang string) models.ExternalResourceSchedule {
	var (
		externalResourceSchedule models.ExternalResourceSchedule
		job                      models.Job
		jobTask                  models.JobTask
		businessPartner          models.BusinessPartner
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	externalResourceSchedule.ScheduleID = schedule.ScheduleID
	externalResourceSchedule.ScheduleStartDate = schedule.ScheduleStartDate
	externalResourceSchedule.ScheduleEndDate = schedule.ScheduleEndDate
	externalResourceSchedule.JobID = schedule.JobID
	resultFindJob := db.Where("JobID = ?", schedule.JobID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&job)
	if resultFindJob.RowsAffected > 0 {
		externalResourceSchedule.JobNumber = job.JobNumber
		externalResourceSchedule.JobType = job.JobType
		externalResourceSchedule.JobTypeName, externalResourceSchedule.JobTypeIcon = libs.GetEnum(requestHeader, job.JobType, "JobType", lang)
		externalResourceSchedule.JobStatus = job.Status
		externalResourceSchedule.JobStatusName, externalResourceSchedule.JobStatusIcon = libs.GetEnum(requestHeader, job.Status, "JobStatus", lang)
		resultFindBusinessPartner := db.Where("BusinessPartnerID = ?", job.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&businessPartner)
		if resultFindBusinessPartner.RowsAffected > 0 {
			externalResourceSchedule.CompanyName = businessPartner.CompanyName
		}
	}
	externalResourceSchedule.JobTaskID = schedule.JobTaskID
	resultFindTask := db.Where("JobTaskID = ?", schedule.JobTaskID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&jobTask)
	if resultFindTask.RowsAffected > 0 {
		externalResourceSchedule.NavigationAddress = jobTask.NavigationAddress
		externalResourceSchedule.JobTaskJobType = jobTask.JobType
		externalResourceSchedule.JobTaskJobTypeName, externalResourceSchedule.JobTaskJobTypeIcon = libs.GetEnum(requestHeader, jobTask.JobType, "JobType", lang)
	}
	return externalResourceSchedule
}

// PowerbiAPIGetQuery godoc
// @Summary Powerbi API Get Query
// @Description Powerbi API Get Query
// @Tags Powerbi
// @Accept json
// @Produce json
// @Success 200 {object} models.APIResponseData
// @Router /powerbi/api/getquery [get]
func PowerbiAPIGetQuery(c *gin.Context) {
	defer libs.RecoverError(c, "PowerbiAPIGetQuery")
	var (
		status       = libs.GetStatusSuccess()
		response     models.APIResponseData
		msg          interface{}
		companyID    string
		responseData = gin.H{}
	)
	lang := services.GetLanguageKey(c)
	vToken, sToken := libs.GetQueryParam("token", c)
	if sToken {
		if vToken != os.Getenv("POWERBI_API_TOKEN") {
			status = 201
			msg = services.GetMessage(lang, "api.token_invalid")
		}
	} else {
		status = 201
		msg = services.GetMessage(lang, "api.token_required")
	}
	if status == 200 {
		vCompanyID, sCompanyID := libs.GetQueryParam("companyid", c)
		if !sCompanyID {
			status = 201
			msg = services.GetMessage(lang, "api.companyid_required")
		} else {
			companyID = vCompanyID
		}
	}
	if status == 200 {
		statusRee, msgRee, requestHeader := libs.GetDatabaseInfoByCompanyID(lang, companyID)
		if statusRee == 200 {
			db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
			var (
				val string
			)
			val, _ = c.GetQuery("query")
			//fmt.Println("val: ", val)
			//val = "select * from Users where UserId = 2"
			if val != "" {
				hasInvalidWord := false
				arrayInvalidWord := []string{"insert", "update", "delete"}
				sqlQuery := strings.ToLower(val)
				arrayQueryWord := strings.Split(sqlQuery, " ")
				for _, v := range arrayQueryWord {
					c := make(chan bool)
					go func(c chan bool, v string, arrayInvalidWord []string) {
						for _, m := range arrayInvalidWord {
							if strings.TrimSpace(v) == m {
								c <- true
							}
						}
						c <- false
					}(c, v, arrayInvalidWord)
					r := <-c
					if r {
						hasInvalidWord = true
					}
				}
				if hasInvalidWord {
					status = 201
					//msg = services.GetMessage(lang, "query has invalid word(insert, update, delete)")
					msg = services.GetMessage(lang, "api.query_has_invalid_word")
				} else {
					rows, errQuery := db.Raw(val).Rows()
					if errQuery == nil {
						ArrayQueryMap := make([]map[string]interface{}, 0)
						defer rows.Close()
						cols, _ := rows.Columns()
						mapColumsType := make(map[string]string)
						colsType, _ := rows.ColumnTypes()
						for _, ty := range colsType {
							if ty != nil {
								sqlColumType := *ty
								mapColumsType[sqlColumType.Name()] = sqlColumType.DatabaseTypeName()
							}
						}
						for rows.Next() {
							QueryMap := make(map[string]interface{})
							columns := make([]*string, len(cols))
							columnPointers := make([]interface{}, len(cols))
							for i := range columns {
								columnPointers[i] = &columns[i]
							}
							err := rows.Scan(columnPointers...)
							if err == nil {
								for i, colName := range cols {
									vColumName, sColumName := mapColumsType[colName]
									if sColumName && columns[i] != nil {
										QueryMap[colName] = libs.ConvertDatabaseValueToResponseValue(*columns[i], vColumName)
									} else {
										QueryMap[colName] = columns[i]
									}
								}
								ArrayQueryMap = append(ArrayQueryMap, QueryMap)
							} else {
								//logger.Println("err: ", err)
							}
						}
						msg = services.GetMessage(lang, "api.success")
						if len(ArrayQueryMap) > 0 {
							responseData = gin.H{
								"status": status,
								"msg":    msg,
								"data":   ArrayQueryMap,
							}
						} else {
							responseData = gin.H{
								"status": status,
								"msg":    msg,
								"data":   make([]string, 0),
							}
						}
					} else {
						status = 201
						msg = services.GetMessage(lang, "api.query_invalid")
					}
				}
			} else {
				status = 201
				msg = services.GetMessage(lang, "api.query_required")
			}
		} else {
			status = statusRee
			msg = msgRee
		}
	}
	if status == 200 {
		c.JSON(status, responseData["data"])
	} else {
		response.Status = status
		response.Message = msg
		responseData = libs.RemoveNullResonseData(response)
		libs.ResponseData(responseData, c, status)
	}
}
