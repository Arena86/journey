package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetLocationGroups godoc
// @Summary Get Location Group
// @Description Get Location Group
// @Tags Location Group
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /locationgroup [get]
func GetLocationGroups(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocationGroups")
	var (
		status         = libs.GetStatusSuccess()
		locationGroups []models.LocationGroup
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg            interface{}
		isArchived     = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)

	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)
	// Filter
	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"LocationGroupName"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&locationGroups).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(locationGroups) > 0 {
			msg = services.GetMessage(lang, "api.success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayLocationGroupToArrayResponseWithLocation(locationGroups, requestHeader)
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetLocationGroupByID godoc
// @Summary Get Location Group By ID
// @Description Get Location Group  By ID
// @Tags Location Group
// @Accept  json
// @Produce  json
// @Param id path int true "Location Group ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /locationgroup/{id} [get]
func GetLocationGroupByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetLocationGroupByID")
	var (
		status         = libs.GetStatusSuccess()
		locationGroups models.LocationGroup
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		responsesData  gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	resultRow := db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationGroupID = ?", ID).First(&locationGroups)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		responses := ConvertLocationGroupToResponseWithLocation(locationGroups, requestHeader)
		data = responses
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateLocationGroup godoc
// @Summary Create Location Group
// @Description Create Location Group
// @Tags Location Group
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param LocationGroup body []models.LocationGroupResponse true "Create LocationGroup"
// @Success 200 {object} models.APIResponseData
// @Router /locationgroup [post]
func CreateLocationGroup(c *gin.Context) {
	defer libs.RecoverError(c, "CreateLocationGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.LocationGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))

	dataResponse = make([]models.LocationGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, obj := range objectsJSON {
			var (
				locationGroup models.LocationGroup
			)
			locationGroup.PassBodyJSONToModel(obj)

			resultFindLocationGroup := db.Where("LocationGroupName = ? AND IsDeleted = 0", locationGroup.LocationGroupName).First(&models.LocationGroup{})
			if resultFindLocationGroup.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.locationgroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("LocationGroupID = ?", locationGroup.LocationGroupID).First(&locationGroup)
			locationGroup.PassBodyJSONToModel(obj)
			locationGroup.CreatedBy = accountKey
			locationGroup.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(locationGroup)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&locationGroup)
				} else {
					db.Create(&locationGroup)
				}
				totalUpdatedRecord++
				dataResponse = append(dataResponse, locationGroup)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.LocationGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.LocationGroupID)
	}
	if len(arrID) > 0 {
		db.Where("LocationGroupID in (?)", arrID).Find(&items)
		data = ConvertArrayLocationGroupToArrayResponse(items)
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// UpdateLocationGroup godoc
// @Summary Update Location Group
// @Description Update Location Group
// @Tags Location Group
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param LocationGroup body []models.LocationGroupResponse true "Create LocationGroup"
// @Success 200 {object} models.APIResponseData
// @Router /locationgroup [put]
func UpdateLocationGroup(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateLocationGroup")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.LocationGroup
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.LocationGroup, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, object := range objectsJSON {
			var (
				locationGroup models.LocationGroup
			)
			locationGroup.PassBodyJSONToModel(object)

			resultFindLocationGroup := db.Where("LocationGroupName = ? AND IsDeleted = 0 AND LocationGroupID <> ?", locationGroup.LocationGroupName, locationGroup.LocationGroupID).First(&models.LocationGroup{})
			if resultFindLocationGroup.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.locationgroupname_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("LocationGroupID = ?", locationGroup.LocationGroupID).First(&locationGroup)
			locationGroup.PassBodyJSONToModel(object)
			locationGroup.ModifiedBy = accountKey
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(locationGroup)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				if resultFind.RowsAffected > 0 {
					db.Save(&locationGroup)
				} else {
					db.Create(&locationGroup)
				}
				dataResponse = append(dataResponse, locationGroup)
				totalUpdatedRecord++
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		items []models.LocationGroup
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.LocationGroupID)
	}
	if len(arrID) > 0 {
		db.Where("LocationGroupID in (?)", arrID).Find(&items)
		data = ConvertArrayLocationGroupToArrayResponse(items)
	} else {
		data = dataResponse
	}

	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// DeleteLocationGroup godoc
// @Summary Delete Location Group
// @Description Delete Location Group
// @Tags Location Group
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "Location Group ID"
// @Success 200 {object} models.APIResponseData
// @Router /locationgroup/{id} [delete]
func DeleteLocationGroup(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteLocationGroup")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.LocationGroup
		)
		resultFind := db.Where("LocationGroupID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			if CanDeleteLocationGroup(requestHeader, uModel.LocationGroupID) {
				uModel.IsDeleted = true
				deletedResult := db.Save(&uModel)
				if deletedResult.Error != nil {
					errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					totalUpdatedRecord++
					// delete location use location group but not use locationid in another tables
					db.Where("LocationGroupID = ?", id).Model(&models.Location{}).Updates(models.Location{IsDeleted: true, ModifiedBy: accountKey})
				}
			} else {
				errResponse := GetErrorResponseValidate(lang, k, "api.locationgroup_used")
				errorsResponse = append(errorsResponse, errResponse)
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	responsesData := libs.RemoveNullResonseData(response)
	libs.ResponseData(responsesData, c, status)
}

// ConvertArrayLocationGroupToArrayResponse func
func ConvertArrayLocationGroupToArrayResponse(items []models.LocationGroup) []models.LocationGroupResponse {
	responses := make([]models.LocationGroupResponse, 0)
	for _, item := range items {
		response := ConvertLocationGroupToResponse(item)
		responses = append(responses, response)
	}
	return responses
}

// ConvertLocationGroupToResponse func
func ConvertLocationGroupToResponse(item models.LocationGroup) models.LocationGroupResponse {
	var (
		response models.LocationGroupResponse
	)
	response.LocationGroupID = item.LocationGroupID
	response.LocationGroupName = item.LocationGroupName
	response.IsArchived = item.IsArchived
	response.IsDeleted = item.IsDeleted
	return response
}

// ConvertArrayLocationGroupToArrayResponseWithLocation func
func ConvertArrayLocationGroupToArrayResponseWithLocation(items []models.LocationGroup, requestHeader models.RequestHeader) []models.LocationGroupResponseWithLocation {
	responses := make([]models.LocationGroupResponseWithLocation, 0)
	for _, item := range items {
		response := ConvertLocationGroupToResponseWithLocation(item, requestHeader)
		responses = append(responses, response)
	}
	return responses
}

// ConvertLocationGroupToResponseWithLocation func
func ConvertLocationGroupToResponseWithLocation(item models.LocationGroup, requestHeader models.RequestHeader) models.LocationGroupResponseWithLocation {
	var (
		response       models.LocationGroupResponseWithLocation
		locationModels []models.Location
	)
	response.LocationGroupID = item.LocationGroupID
	response.LocationGroupName = item.LocationGroupName

	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	db.Where("LocationGroupID = ? AND IFNULL(IsDeleted, 0) <> 1", item.LocationGroupID).Find(&locationModels)
	locationResponseModels := make([]models.LocationResponse, 0)
	for _, v := range locationModels {
		var locationResponseModel models.LocationResponse
		locationResponseModel.LocationID = v.LocationID
		locationResponseModel.LocationName = v.LocationName
		locationResponseModel.LocationGroupID = v.LocationGroupID
		locationResponseModel.IsDeleted = v.IsDeleted
		locationResponseModel.IsArchived = v.IsArchived
		locationResponseModels = append(locationResponseModels, locationResponseModel)
	}
	response.Locations = locationResponseModels
	response.IsArchived = item.IsArchived
	response.IsDeleted = item.IsDeleted
	return response
}

// CanDeleteLocationGroup func
func CanDeleteLocationGroup(requestHeader models.RequestHeader, locationGroupID int) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		locationModels []models.Location
	)
	// find in location
	arrLocationID := make([]int, 0)
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationGroupID = ?", locationGroupID).Find(&locationModels)
	if len(locationModels) <= 0 {
		return true
	}
	for _, l := range locationModels {
		arrLocationID = append(arrLocationID, l.LocationID)
	}
	if len(arrLocationID) <= 0 {
		return true
	}
	// find table use locationid
	if HasUseLocationIDInAnotherTables(requestHeader, arrLocationID) {
		return false
	}
	return true
}

// HasUseLocationIDInAnotherTables func
func HasUseLocationIDInAnotherTables(requestHeader models.RequestHeader, arrLocationID []int) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		bpLocationModels []models.BusinessPartnerLocation
		jobModels        []models.Job
		resourceModels   []models.Resource
		scheduleModels   []models.Schedule
		//customergroupModels []models.CustomerGroup
		userModels []models.User
	)

	if len(arrLocationID) <= 0 {
		return false
	}
	// businesspartnerlocations table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&bpLocationModels)
	if len(bpLocationModels) > 0 {
		return true
	}
	// jobs table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&jobModels)
	if len(jobModels) > 0 {
		return true
	}
	// resources table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&resourceModels)
	if len(resourceModels) > 0 {
		return true
	}
	// schedules table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&scheduleModels)
	if len(scheduleModels) > 0 {
		return true
	}
	// customergroups table
	/* db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&customergroupModels)
	if len(customergroupModels) > 0 {
		return true
	} */
	// users table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&userModels)
	if len(userModels) > 0 {
		return true
	}
	return false
}

// HasUseLocationIDInAnotherTables func
func HasUseLocationINBPTables(requestHeader models.RequestHeader, arrLocationID []int) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	var (
		bpLocationModels []models.BusinessPartnerLocation
	)

	if len(arrLocationID) <= 0 {
		return false
	}
	// businesspartnerlocations table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&bpLocationModels)
	if len(bpLocationModels) > 0 {
		return true
	}
	return false
}

// HasUseLocationIDInAnotherTables func
func HasUseLocationIDInUserTables(requestHeader models.RequestHeader, arrLocationID []int) bool {
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	var (
		userModels []models.User
	)

	if len(arrLocationID) <= 0 {
		return false
	}
	// users table
	db.Where("IFNULL(IsDeleted, 0) <> 1 AND LocationID IN (?)", arrLocationID).Find(&userModels)
	if len(userModels) > 0 {
		return true
	}
	return false
}
