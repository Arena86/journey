package controllers

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	smslogs "jpapi/tig/v1/logs/sms"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

// SendSMSTesting godoc
// @Summary SendSMSTesting
// @Description SendSMSTesting
// @Tags Testing
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param Tax body []string true "SendSMSTesting"
// @Success 200 {object} models.APIResponseData
// @Router /sendsmstesting [post]
func SendSMSTesting(c *gin.Context) {
	apiName := "SendSMSTesting"
	defer libs.RecoverError(c, apiName)
	var (
		status         = libs.GetStatusSuccess()
		requestHeader  models.RequestHeader
		response       models.APIResponseData
		msg, data      interface{}
		errorsResponse []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	if db != nil {

	}
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	// Convert json body to object

	type SendSMSObject struct {
		PhoneNumber string
		Content     string
	}

	smsServiceConfig := libs.GetSMSService(accountKey)

	var SendSMSJSON SendSMSObject
	body, _ := ioutil.ReadAll(c.Request.Body)
	json.Unmarshal([]byte(string(body)), &SendSMSJSON)
	var (
		bodyDataJSON []byte
	)
	if SendSMSJSON.PhoneNumber == "" {
		status = 422
		msg = "PhoneNumber is required"
	}
	if SendSMSJSON.Content == "" {
		status = 422
		msg = "Content is required"
	}
	if status == 200 {
		bodyContent := make(map[string][]models.MessageSMSPOST)
		messagesBody := make([]models.MessageSMSPOST, 0)

		var messageBody models.MessageSMSPOST
		messageBody.Content = SendSMSJSON.Content
		messageBody.DestinationNumber = SendSMSJSON.PhoneNumber
		messageBody.Format = "SMS"
		messageBody.DeliveryReport = true
		messagesBody = append(messagesBody, messageBody)
		bodyContent["messages"] = messagesBody
		vBodyDataJSON, sBodyDataJSON := json.Marshal(bodyContent)
		if sBodyDataJSON == nil {
			bodyDataJSON = vBodyDataJSON
			req, err := http.NewRequest("POST", smsServiceConfig.SMSURL, bytes.NewBuffer(bodyDataJSON))
			req.SetBasicAuth(smsServiceConfig.SMSKey, smsServiceConfig.SMSPassword)
			req.Header.Set("Content-Type", "application/json")
			req.Close = true
			client := &http.Client{}
			resp, err := client.Do(req)
			fmt.Println("bodyDataJSON: ", string(bodyDataJSON))
			/* fmt.Println("bodyDataJSON: ", string(bodyDataJSON))
			fmt.Println("req: ", req)
			fmt.Println("err: ", err)
			fmt.Println("resp: ", resp) */
			if err != nil {
				status = 500
				msg = err.Error()
			} else {
				body, _ := ioutil.ReadAll(resp.Body)
				if resp.StatusCode == 400 {
					var messages map[string]interface{}
					json.Unmarshal([]byte(string(body)), &messages)
					var resSMS interface{}
					resSMS = messages["message"]
					msg = fmt.Sprintf("%v", resSMS)
					fmt.Println("messages: ", msg)
				} else {
					var messages models.MessagesSMSResponse

					json.Unmarshal([]byte(string(body)), &messages)
					var resSMS interface{}
					if len(messages.Messages) <= 0 {
						msg = resp.Status
					} else {
						resSMS = messages.Messages[0]["status"]
						msg = fmt.Sprintf("%v", resSMS)
					}
					data = messages
				}
				status = resp.StatusCode
				if status == 202 {
					status = 200
				}
			}
		} else {
			status = 500
			msg = sBodyDataJSON.Error()
		}
	}

	if status != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	} else {
		if msg == nil {
			msg = services.GetMessage(lang, "api.success")
		}
	}

	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// TestingSendSMS api
func TestingSendSMS(c *gin.Context) {
	defer libs.RecoverError(c, "TestingSendSMS")
	var (
		status            = libs.GetStatusSuccess()
		requestHeader     models.RequestHeader
		response          models.APIResponseData
		msg, data, errors interface{}
		errorsResponse    []models.ErrorResponse
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	// Convert json body to object
	smsMatrixID := 1
	jobID := 1
	resStatus, resMsg, resSendSMS := SendSMSAfterProcessJob(requestHeader, accountKey, lang, smsMatrixID, jobID)

	// logger
	var smsLogger = smslogs.SMSLogger
	smsLogger.Println("jobID: ", jobID)
	smsLogger.Println("smsMatrixID: ", smsMatrixID)
	smsLogger.Println("resStatus: ", resStatus)
	smsLogger.Println("resMsg: ", resMsg)
	smsLogger.Printf("resSendSMS: %+v", resSendSMS)

	msg = resMsg
	if resStatus != 200 {
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	errors = errorsResponse
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}
