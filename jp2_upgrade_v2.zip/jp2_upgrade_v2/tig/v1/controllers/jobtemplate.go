package controllers

import (
	"encoding/json"
	jpdatabase "jpapi/tig/v1/databases/jp"
	libs "jpapi/tig/v1/helpers"
	"jpapi/tig/v1/models"
	"jpapi/tig/v1/services"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
	"gopkg.in/go-playground/validator.v9"
)

// GetJobTemplate godoc
// @Summary Get JobTemplate
// @Description Get JobTemplate
// @Tags JobTemplate
// @Accept  json
// @Produce  json
// @Param Start query string false "Start"
// @Param Length query string false "Length"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /jobtemplate [get]
func GetJobTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobTemplate")
	var (
		status        = libs.GetStatusSuccess()
		resModels     []models.JobTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg           interface{}
		isArchived    = false
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	lang := services.GetLanguageKey(c)
	errorsResponse := make([]models.ErrorResponse, 0)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	vIsArchived, sIsArchived := libs.GetQueryParam("isarchived", c)
	if sIsArchived {
		isArchived, _ = strconv.ParseBool(vIsArchived)
	}

	// Paging
	vStart, sStart := libs.GetQueryParam("Start", c)
	vLength, sLength := libs.GetQueryParam("Length", c)
	if !sStart {
		vStart = os.Getenv("PAGE_DEFAULT")
	} else {
		iStart, eStart := strconv.Atoi(vStart)
		if eStart == nil {
			iStart = iStart - 1
			if iStart < 0 {
				iStart = 0
			}
		}
		vStart = strconv.Itoa(iStart)
	}
	if !sLength {
		vLength = os.Getenv("PAGE_SIZE")
	}
	vStartInt, _ := strconv.Atoi(vStart)
	vLengthInt, _ := strconv.Atoi(vLength)
	var bp = db.Limit(vLengthInt).Offset(vStartInt)
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) = ?", isArchived)

	arrBool := []string{}
	bp = libs.FilterBool(arrBool, bp, c)
	arrString := []string{"JobTemplateName", "JobTemplateCode", "Description"}
	bp = libs.FilterString(arrString, bp, c)
	arrInteger := []string{"JobType"}
	bp = libs.FilterInteger(arrInteger, bp, c)
	arrDateTime := []string{}
	bp = libs.FilterDateTime(arrDateTime, bp, c)

	// Sort
	bp = libs.SortDataOnParam(bp, c)
	bp = bp.Order("Sort ASC")
	var totalCount int64
	totalCount = 0
	resultRow := bp.Find(&resModels).Limit(-1).Offset(-1).Count(&totalCount)
	if resultRow.Error == nil {
		if len(resModels) > 0 {
			msg = services.GetMessage(lang, "api.create_success")
		} else {
			msg = services.GetMessage(lang, "api.no_record_found")
		}
	} else {
		status = 500
		msg = resultRow.Error.Error()
		errResponse := GetErrorResponseErrorMessage(0, msg)
		errorsResponse = append(errorsResponse, errResponse)
	}
	responses := ConvertArrayJobTemplateToArrayResponse(resModels, requestHeader, lang)
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData := libs.RemoveNullResonseData(response)
	responsesData["data"] = responses
	responsesData["totalcount"] = totalCount
	libs.ResponseData(responsesData, c, status)
}

// GetJobTemplateByID godoc
// @Summary Get JobTemplate By ID
// @Description Get JobTemplate  By ID
// @Tags JobTemplate
// @Accept  json
// @Produce  json
// @Param id path int true "JobTemplate ID"
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Success 200 {object} models.APIResponseData
// @Router /jobtemplate/{id} [get]
func GetJobTemplateByID(c *gin.Context) {
	defer libs.RecoverError(c, "GetJobTemplateByID")
	var (
		status        = libs.GetStatusSuccess()
		resModel      models.JobTemplate
		requestHeader models.RequestHeader
		response      models.APIResponseData
		msg, data     interface{}
		responsesData gin.H
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	//accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse := make([]models.ErrorResponse, 0)
	ID := c.Param("id")
	var bp = db
	bp = bp.Where("IFNULL(IsDeleted, 0) <> 1 AND JobTemplateID = ?", ID)
	resultRow := bp.First(&resModel)
	if resultRow.RowsAffected > 0 {
		msg = services.GetMessage(lang, "api.success")
		itemsResponse := ConvertJobTemplateToResponse(resModel, requestHeader, lang)
		data = itemsResponse
	} else {
		msg = services.GetMessage(lang, "api.no_record_found")
		status = libs.GetStatusNotFound()
		errResponse := GetErrorResponseNotFound(lang, 0)
		errorsResponse = append(errorsResponse, errResponse)
	}
	response.Status = status
	response.Message = msg
	response.Errors = errorsResponse
	responsesData = libs.RemoveNullResonseData(response)
	responsesData["data"] = data
	libs.ResponseData(responsesData, c, status)
}

// CreateJobTemplate godoc
// @Summary Create JobTemplate
// @Description Create JobTemplate
// @Tags JobTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param JobTemplate body []models.JobTemplate true "Create JobTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /jobtemplate [post]
func CreateJobTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "CreateJobTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.JobTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	errorsResponse = make([]models.ErrorResponse, 0)
	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	dataResponse = make([]models.JobTemplate, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)
	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				postModel models.JobTemplate
			)
			postModel.PassBodyJSONToModel(bp)

			resultFindJobTemplate := db.Where("JobTemplateName = ? AND IsDeleted = 0", postModel.JobTemplateName).First(&models.JobTemplate{})
			if resultFindJobTemplate.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.jobtemplatename_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			postModel.CreatedBy = accountKey
			postModel.ModifiedBy = accountKey
			postModel.JobTemplateCode = strconv.Itoa(postModel.JobType) + "-" + strconv.Itoa(postModel.TravelChargeMode)
			validate, trans := services.GetValidatorTranslate()
			err := validate.Struct(postModel)
			if err != nil {
				var (
					errValid interface{}
				)
				errs := err.(validator.ValidationErrors)
				for _, e := range errs {
					errValid = e.Translate(trans)
				}
				errResponse := GetErrorResponseErrorMessage(k, errValid)
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				var (
					itemMsgError string
				)
				// @TODO validate for address
				resultCreate := db.Create(&postModel)
				if resultCreate.Error != nil {
					if itemMsgError == "" {
						itemMsgError = resultCreate.Error.Error()
					} else {
						itemMsgError = itemMsgError + "\n" + resultCreate.Error.Error()
					}
				} else {
					totalUpdatedRecord++
					dataResponse = append(dataResponse, postModel)
				}
				if itemMsgError != "" {
					errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
					errorsResponse = append(errorsResponse, errResponse)
				}
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("POST", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.JobTemplate
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.JobTemplateID)
	}
	if len(arrID) > 0 {
		db.Where("JobTemplateID in (?)", arrID).Find(&resModels)
		data = ConvertArrayJobTemplateToArrayResponse(resModels, requestHeader, lang)
	} else {
		data = dataResponse
	}

	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// UpdateJobTemplate godoc
// @Summary Update JobTemplate
// @Description Update JobTemplate
// @Tags JobTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param JobTemplate body []models.JobTemplate true "Update JobTemplate"
// @Success 200 {object} models.APIResponseData
// @Router /jobtemplate [put]
func UpdateJobTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "UpdateJobTemplate")
	var (
		status             = libs.GetStatusSuccess()
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		msg, data, errors  interface{}
		errorsResponse     []models.ErrorResponse
		dataResponse       []models.JobTemplate
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	dataResponse = make([]models.JobTemplate, 0)
	// Convert json body to object
	var objectsJSON []map[string]interface{}
	json.NewDecoder(c.Request.Body).Decode(&objectsJSON)

	if len(objectsJSON) > 0 {
		for k, bp := range objectsJSON {
			var (
				putModel models.JobTemplate
			)
			putModel.PassBodyJSONToModel(bp)

			resultFindJobTemplate := db.Where("JobTemplateName = ? AND IsDeleted = 0 AND JobTemplateID <> ? ", putModel.JobTemplateName, putModel.JobTemplateID).First(&models.JobTemplate{})
			if resultFindJobTemplate.RowsAffected > 0 {
				errResponse := GetErrorResponseValidate(lang, k, "api.jobtemplatename_exist")
				errorsResponse = append(errorsResponse, errResponse)
				continue
			}

			resultFind := db.Where("JobTemplateID = ?", putModel.JobTemplateID).First(&putModel)
			if resultFind.RowsAffected > 0 {
				putModel.PassBodyJSONToModel(bp)
				putModel.ModifiedBy = accountKey
				putModel.JobTemplateCode = strconv.Itoa(putModel.JobType) + "-" + strconv.Itoa(putModel.TravelChargeMode)
				validate, trans := services.GetValidatorTranslate()
				err := validate.Struct(putModel)
				if err != nil {
					var (
						errValid interface{}
					)
					errs := err.(validator.ValidationErrors)
					for _, e := range errs {
						errValid = e.Translate(trans)
					}
					errResponse := GetErrorResponseErrorMessage(k, errValid)
					errorsResponse = append(errorsResponse, errResponse)
				} else {
					var (
						itemMsgError string
					)
					resultSave := db.Save(&putModel)
					if resultSave.Error != nil {
						if itemMsgError == "" {
							itemMsgError = resultSave.Error.Error()
						} else {
							itemMsgError = itemMsgError + "\n" + resultSave.Error.Error()
						}
					} else {
						totalUpdatedRecord++
						dataResponse = append(dataResponse, putModel)
					}
					if itemMsgError != "" {
						errResponse := GetErrorResponseErrorMessage(k, itemMsgError)
						errorsResponse = append(errorsResponse, errResponse)
					}
				}
			} else {
				errResponse := GetErrorResponseNotFound(lang, k)
				errorsResponse = append(errorsResponse, errResponse)
			}
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("PUT", lang, totalUpdatedRecord, len(objectsJSON), errorsResponse, false)
	var (
		resModels []models.JobTemplate
	)
	arrID := make([]int, 0)
	for _, v := range dataResponse {
		arrID = append(arrID, v.JobTemplateID)
	}
	if len(arrID) > 0 {
		db.Where("JobTemplateID in (?)", arrID).Find(&resModels)
		data = ConvertArrayJobTemplateToArrayResponse(resModels, requestHeader, lang)
	} else {
		data = dataResponse
	}
	// Response Data
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = data
	libs.APIResponseData(response, c, status)
}

// DeleteJobTemplate godoc
// @Summary Delete JobTemplate
// @Description Delete JobTemplate
// @Tags JobTemplate
// @Accept  json
// @Produce  json
// @Param AccountKey header string true "Account Key header"
// @Param Token header string true "Token header"
// @Param Security header string true "Security header"
// @Param id path int true "JobTemplate ID"
// @Success 200 {object} models.APIResponseData
// @Router /jobtemplate/{id} [delete]
func DeleteJobTemplate(c *gin.Context) {
	defer libs.RecoverError(c, "DeleteJobTemplate")
	var (
		status             = libs.GetStatusSuccess()
		msg                interface{}
		requestHeader      models.RequestHeader
		response           models.APIResponseData
		errorsResponse     []models.ErrorResponse
		errors             interface{}
		totalUpdatedRecord = 0
	)
	statusCheckHeader, ResponseCheckHeader, requestHeader := libs.CheckHeaderInAPI(c)
	if statusCheckHeader != 200 {
		libs.ResponseData(ResponseCheckHeader, c, statusCheckHeader)
		return
	}
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)

	lang := services.GetLanguageKey(c)
	accountKey, _ := strconv.Atoi(c.Request.Header.Get("accountkey"))
	errorsResponse = make([]models.ErrorResponse, 0)
	strID := c.Param("id")
	arrID := libs.StringToArray(strID)
	for k, id := range arrID {
		var (
			uModel models.JobTemplate
		)
		resultFind := db.Where("JobTemplateID = ?", id).First(&uModel)
		if resultFind.RowsAffected > 0 {
			uModel.IsDeleted = true
			uModel.ModifiedBy = accountKey
			deletedResult := db.Save(&uModel)
			if deletedResult.Error != nil {
				errResponse := GetErrorResponseErrorMessage(k, deletedResult.Error.Error())
				errorsResponse = append(errorsResponse, errResponse)
			} else {
				totalUpdatedRecord++
			}
		} else {
			errResponse := GetErrorResponseNotFound(lang, k)
			errorsResponse = append(errorsResponse, errResponse)
		}
	}
	errors = errorsResponse
	status, msg = GetStatusState("DELETE", lang, totalUpdatedRecord, len(arrID), errorsResponse, false)
	response.Status = status
	response.Message = msg
	response.Errors = errors
	response.Data = nil
	libs.APIResponseData(response, c, status)
}

// ConvertArrayJobTemplateToArrayResponse func
func ConvertArrayJobTemplateToArrayResponse(items []models.JobTemplate, requestHeader models.RequestHeader, lang string) []models.JobTemplateResponse {
	responses := make([]models.JobTemplateResponse, 0)
	for _, item := range items {
		response := ConvertJobTemplateToResponse(item, requestHeader, lang)
		responses = append(responses, response)
	}
	return responses
}

// ConvertJobTemplateToResponse func
func ConvertJobTemplateToResponse(item models.JobTemplate, requestHeader models.RequestHeader, lang string) models.JobTemplateResponse {
	var (
		response             models.JobTemplateResponse
		jobTypeEnum          models.Enumerator
		formFlow             models.DraftFormFlow
		formFlowSecond       models.DraftFormFlow
		travelChargeModeEnum models.Enumerator
		travelChargeEnum     models.Enumerator
	)
	db := jpdatabase.CheckDBConnection(requestHeader.DBName, requestHeader.DBUser, requestHeader.DBPassword, requestHeader.DBServer, requestHeader.DBPort)
	//

	response.JobTemplateID = item.JobTemplateID
	response.JobTemplateName = item.JobTemplateName
	response.JobTemplateCode = item.JobTemplateCode
	response.Description = item.Description
	response.Icon = item.Icon
	response.JobType = item.JobType
	db.Where("FieldName = ? AND Status = ?", "JobType", item.JobType).First(&jobTypeEnum)
	if jobTypeEnum.TranslationKey != "" && jobTypeEnum.TranslationKey != services.GetMessage(lang, jobTypeEnum.TranslationKey) {
		response.JobTypeName = services.GetMessage(lang, jobTypeEnum.TranslationKey)
	} else {
		response.JobTypeName = jobTypeEnum.Caption
	}

	response.FormFlowID = item.FormFlowID
	db.Where("DraftFormFlowID = ?", item.FormFlowID).First(&formFlow)
	response.FormFlowName = formFlow.DraftFormFlowName
	response.FormFlowStatus = formFlow.Status
	response.FormFlowLastPublishedDate = formFlow.LastPublishedDate

	response.FormFlowSecondID = item.FormFlowSecondID
	db.Where("DraftFormFlowID = ?", item.FormFlowSecondID).First(&formFlowSecond)
	response.FormFlowSecondName = formFlowSecond.DraftFormFlowName
	response.FormFlowSecondStatus = formFlowSecond.Status
	response.FormFlowSecondLastPublishedDate = formFlowSecond.LastPublishedDate

	response.TravelChargeMode = item.TravelChargeMode
	db.Where("FieldName = ? AND Status = ?", "TravelChargeMode", item.TravelChargeMode).First(&travelChargeModeEnum)
	if travelChargeModeEnum.TranslationKey != "" && travelChargeModeEnum.TranslationKey != services.GetMessage(lang, travelChargeModeEnum.TranslationKey) {
		response.TravelChargeModeName = services.GetMessage(lang, travelChargeModeEnum.TranslationKey)
	} else {
		response.TravelChargeModeName = travelChargeModeEnum.Caption
	}

	response.TravelCharge = item.TravelCharge
	db.Where("FieldName = ? AND Status = ?", "TravelCharge", item.TravelCharge).First(&travelChargeEnum)
	if travelChargeEnum.TranslationKey != "" && travelChargeEnum.TranslationKey != services.GetMessage(lang, travelChargeEnum.TranslationKey) {
		response.TravelChargeName = services.GetMessage(lang, travelChargeEnum.TranslationKey)
	} else {
		response.TravelChargeName = travelChargeEnum.Caption
	}

	response.Sort = item.Sort
	response.ServiceTimeInMinutes = item.ServiceTimeInMinutes
	response.ServiceTimeInMinutesSecond = item.ServiceTimeInMinutesSecond
	return response
}
