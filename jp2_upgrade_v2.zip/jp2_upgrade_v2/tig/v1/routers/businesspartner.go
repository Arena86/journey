package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// BusinessPartner route
func BusinessPartner(r *gin.RouterGroup) {
	r.GET("", controllers.GetBusinessPartner)
	r.GET(":id", controllers.GetBusinessPartnerByID)
	r.POST("", controllers.CreateBusinessPartner)
	r.PUT("", controllers.UpdateBusinessPartner)
	r.DELETE(":id", controllers.DeleteBusinessPartner)
	//r.DELETE("", controllers.DeleteBusinessPartner)
}
