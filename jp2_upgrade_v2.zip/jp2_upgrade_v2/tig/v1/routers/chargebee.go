package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// ChargeBee route
func ChargeBee(r *gin.RouterGroup) {
	//r.GET("/customers", controllers.GetChargeBeeCustomers)
	r.GET("/customers", controllers.GetChargeBeeCustomerByCustomerID)
	//r.PUT("/customers/update/card", controllers.UpdateChargeBeeCustomerCard)
	r.DELETE("/customers/delete/card", controllers.DeleteChargeBeeCustomerCard)
	r.DELETE("/customers/card/:id", controllers.DeleteChargeBeeCustomerPaymentSource)
	r.POST("/customers/card", controllers.CreateChargeBeeCustomerPaymentSource)
	r.GET("/paymentsources", controllers.GetPaymentSourcesByCustomerID)
	r.PUT("/setprimarycard", controllers.AssignPaymentRoleByCustomerID)
	r.GET("/getinvoicecustomer", controllers.GetInvoiceByCustomerID)
	r.GET("/getcreditnotecustomer", controllers.GetCreditNoteByCustomerID)
	r.GET("/getinvoicepdf/:id", controllers.GetChargeBeeInvoiceAsPDFByID)
	r.GET("/getcreditnotepdf/:id", controllers.GetChargeBeeCreditNoteAsPDFByID)
	r.GET("/getcoupon/:couponcode", controllers.GetCouponByCode)
}
