package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// Dashboard route
func Dashboard(r *gin.RouterGroup) {
	r.GET(":id", controllers.GetDashboardByID)
}
