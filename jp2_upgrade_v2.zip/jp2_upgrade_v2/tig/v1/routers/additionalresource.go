package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AdditionalResource route
func AdditionalResource(r *gin.RouterGroup) {
	r.POST("", controllers.CreateAdditionalResource)
	r.PUT("", controllers.UpdateAdditionalResource)
	r.PUT("/delete", controllers.DeleteAdditionalResource)
}
