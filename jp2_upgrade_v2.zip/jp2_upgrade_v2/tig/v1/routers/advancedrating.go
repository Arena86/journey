package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AdvancedRating route
func AdvancedRating(r *gin.RouterGroup) {
	r.POST("", controllers.CreateAdvancedRating)
}
