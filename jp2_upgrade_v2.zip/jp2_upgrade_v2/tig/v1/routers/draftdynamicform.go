package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// DraftDynamicForm route
func DraftDynamicForm(r *gin.RouterGroup) {
	r.GET("", controllers.GetDraftDynamicForm)
	r.GET(":id", controllers.GetDraftDynamicFormByID)
	r.POST("", controllers.CreateDraftDynamicForm)
	r.PUT("", controllers.UpdateDraftDynamicForm)
	r.PUT("/publish/:id", controllers.PublishDraftDynamicForm)
	r.PUT("/restore/:id", controllers.RevertDraftDynamicForm)
	r.DELETE(":id", controllers.DeleteDraftDynamicForm)
}
