package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AuthorizationRoute route
func AuthorizationRoute(r *gin.RouterGroup) {
	r.GET("", controllers.GetAuthorization)
	r.GET("getauthrequestcount", controllers.GetRequestAuthorizationCount)
	r.GET("byid/:id", controllers.GetAuthorizationByID)
	r.POST("", controllers.CreateAuthorization)
}
