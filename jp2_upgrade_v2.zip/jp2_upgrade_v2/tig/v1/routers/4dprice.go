package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// FourDPrice route
func FourDPrice(r *gin.RouterGroup) {
	r.GET("", controllers.Get4DPrice)
	r.GET("/:id", controllers.Get4DPriceByID)
	r.POST("", controllers.Create4DPrice)
	r.PUT("/:id", controllers.Update4DPrice)
	r.DELETE("/:id", controllers.Delete4DPrice)
}
