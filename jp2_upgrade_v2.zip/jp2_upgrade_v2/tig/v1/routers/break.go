package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// BreakRoute route
func BreakRoute(r *gin.RouterGroup) {
	r.GET("", controllers.GetBreak)
	r.GET(":id", controllers.GetBreakByID)
	r.POST("", controllers.CreateBreak)
	r.PUT(":id", controllers.UpdateBreak)
	r.DELETE(":id", controllers.DeleteBreak)
}
