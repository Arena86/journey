package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// DeviceStatus route
func DeviceStatus(r *gin.RouterGroup) {
	r.GET("", controllers.GetDeviceStatus)
	r.POST("", controllers.CreateDeviceStatus)
}
