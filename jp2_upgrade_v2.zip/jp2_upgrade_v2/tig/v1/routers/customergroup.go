package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// CustomerGroup route
func CustomerGroup(r *gin.RouterGroup) {
	r.GET("", controllers.GetCustomerGroup)
	r.GET(":id", controllers.GetCustomerGroupByID)
	r.POST("", controllers.CreateCustomerGroup)
	r.PUT("", controllers.UpdateCustomerGroup)
	r.DELETE(":id", controllers.DeleteCustomerGroup)
}
