package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AddressType route
func AddressType(r *gin.RouterGroup) {
	r.GET("", controllers.GetAddressType)
	r.GET(":id", controllers.GetAddressTypeByID)
	r.POST("", controllers.CreateAddressType)
	r.PUT("", controllers.UpdateAddressType)
	r.DELETE(":id", controllers.DeleteAddressType)
	//r.DELETE("", controllers.DeleteAddressType)
}
