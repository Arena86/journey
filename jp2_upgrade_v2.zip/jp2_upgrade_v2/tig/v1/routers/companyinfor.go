package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// CompanyInfor route
func CompanyInfor(r *gin.RouterGroup) {
	//r.POST("", controllers.CreateCompanyInfor)
	r.PUT(":id", controllers.UpdateCompanyInfor)
}
