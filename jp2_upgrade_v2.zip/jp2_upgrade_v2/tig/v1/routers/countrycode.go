package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// CountryCode route
func CountryCode(r *gin.RouterGroup) {
	r.GET("", controllers.GetCountryCode)
	r.POST("", controllers.CreateCountryCode)
	r.DELETE(":id", controllers.DeleteCountryCode)
}
