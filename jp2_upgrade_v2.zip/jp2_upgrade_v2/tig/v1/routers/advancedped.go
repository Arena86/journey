package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AdvancedPED route
func AdvancedPED(r *gin.RouterGroup) {
	r.POST("", controllers.CreateAdvancedPED)
}
