package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AdvancedPhoto route
func AdvancedPhoto(r *gin.RouterGroup) {
	r.POST("", controllers.CreateAdvancedPhoto)
}
