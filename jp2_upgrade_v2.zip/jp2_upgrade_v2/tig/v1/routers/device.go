package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// Device route
func Device(r *gin.RouterGroup) {
	r.GET("", controllers.GetDevice)
	r.GET(":id", controllers.GetDeviceByID)
	r.POST("", controllers.CreateDevice)
	r.DELETE(":id", controllers.DeleteDevice)
}
