package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// DistancePriceList route
func DistancePriceList(r *gin.RouterGroup) {
	r.GET("", controllers.GetDistancePriceListOnlyMaster)
	r.GET("/details", controllers.GetDistancePriceListWithDetails)
	r.GET("/id/:id", controllers.GetDistancePriceListByID)
	r.POST("", controllers.CreateDistancePriceList)
	r.PUT("/:id", controllers.UpdateDistancePriceList)
	r.DELETE("/:id", controllers.DeleteDistancePriceList)
}
