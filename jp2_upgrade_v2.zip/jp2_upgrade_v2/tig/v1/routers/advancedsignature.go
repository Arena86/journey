package routers

import (
	"jpapi/tig/v1/controllers"

	"github.com/gin-gonic/gin"
)

// AdvancedSignature route
func AdvancedSignature(r *gin.RouterGroup) {
	r.POST("", controllers.CreateAdvancedSignature)
}
