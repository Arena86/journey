package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ItemMovement data
type ItemMovement struct {
	ItemMovementID int        `gorm:"column:ItemMovementID;primaryKey;autoIncrement;not null" json:"ItemMovementID"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobDetailID    int        `gorm:"column:JobDetailID" json:"JobDetailID"`
	Type           int        `gorm:"column:Type" json:"Type"`
	Quantity       float64    `gorm:"column:Quantity" json:"Quantity"`
}

// ItemMovementResponse data
type ItemMovementResponse struct {
	ItemMovementID int     `json:"ItemMovementID"`
	JobDetailID    int     `json:"JobDetailID"`
	Type           int     `json:"Type"`
	Quantity       float64 `json:"Quantity"`
}

// TableName func
func (ItemMovement) TableName() string {
	return "itemmovements"
}

// BeforeCreate func
func (object *ItemMovement) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ItemMovement) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ItemMovement) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	/* val, res = services.ConvertJSONValueToVariable("ItemMovementID", JSONObject)
	if res != nil {
		object.ItemMovementID, _ = strconv.Atoi(val)
	} */
	val, res = services.ConvertJSONValueToVariable("JobDetailID", JSONObject)
	if res != nil {
		object.JobDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Type", JSONObject)
	if res != nil {
		object.Type, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Quantity", JSONObject)
	if res != nil {
		object.Quantity, _ = strconv.ParseFloat(val, 64)
	}
	return
}
