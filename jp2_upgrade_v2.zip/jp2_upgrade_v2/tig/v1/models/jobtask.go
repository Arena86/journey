package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobTypeOnSite const
const JobTypeOnSite = 1

// JobTypePickup const
const JobTypePickup = 2

// JobTypeDelivery const
const JobTypeDelivery = 3

// JobTypePickupDelivery const
const JobTypePickupDelivery = 4

// JobTypeInStore const
const JobTypeInStore = 5

// JobTypeMultipleJob const
const JobTypeMultipleJob = 6

// JobTypeResourcePickUp const
const JobTypeResourcePickUp = 7

// JobTypeResourceDelivery const
const JobTypeResourceDelivery = 8

// JobTypeCombinedJob const
const JobTypeCombinedJob = 9

// JobTask data
type JobTask struct {
	JobTaskID                int        `gorm:"column:JobTaskID;primaryKey;autoIncrement;not null"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID                    int        `gorm:"column:JobID" json:"JobID"`
	FormFlowID               int        `gorm:"column:FormFlowID" json:"FormFlowID"`
	JobType                  int        `gorm:"column:JobType" json:"JobType"`
	ScheduleStartDateTime    *time.Time `gorm:"column:ScheduleStartDateTime" json:"ScheduleStartDateTime"`
	ScheduleEndDateTime      *time.Time `gorm:"column:ScheduleEndDateTime" json:"ScheduleEndDateTime"`
	DepartureDateTime        *time.Time `gorm:"column:DepartureDateTime" json:"DepartureDateTime"`
	EstimatedArrivalDateTime *time.Time `gorm:"column:EstimatedArrivalDateTime" json:"EstimatedArrivalDateTime"`
	ArrivalDateTime          *time.Time `gorm:"column:ArrivalDateTime" json:"ArrivalDateTime"`
	StartDateTime            *time.Time `gorm:"column:StartDateTime" json:"StartDateTime"`
	EndDateTime              *time.Time `gorm:"column:EndDateTime" json:"EndDateTime"`
	JobTimeInSeconds         int        `gorm:"column:JobTimeInSeconds" json:"JobTimeInSeconds"`
	NavigationAddress        string     `gorm:"column:NavigationAddress" json:"NavigationAddress"`
	Status                   int        `gorm:"column:Status" json:"Status"`
	AdditionalInformation    string     `gorm:"column:AdditionalInformation" json:"AdditionalInformation"`
	ServiceTimeInMinutes     int        `gorm:"column:ServiceTimeInMinutes" json:"ServiceTimeInMinutes"`
	Longitude                *float64   `gorm:"column:Longitude" json:"Longitude"`
	Latitude                 *float64   `gorm:"column:Latitude" json:"Latitude"`
	IsSuburb                 bool       `gorm:"column:IsSuburb" json:"IsSuburb"`
	IsFullAddress            bool       `gorm:"column:IsFullAddress" json:"IsFullAddress"`
}

// JobTaskResponse data
type JobTaskResponse struct {
	JobTaskID                int        `json:"JobTaskID"`
	JobID                    int        `json:"JobID"`
	FormFlowID               int        `json:"FormFlowID"`
	JobType                  int        `json:"JobType"`
	ScheduleStartDateTime    *time.Time `json:"ScheduleStartDateTime"`
	ScheduleEndDateTime      *time.Time `json:"ScheduleEndDateTime"`
	DepartureDateTime        *time.Time `json:"DepartureDateTime"`
	EstimatedArrivalDateTime *time.Time `json:"EstimatedArrivalDateTime"`
	JobTimeInSeconds         int        `json:"JobTimeInSeconds"`
	ArrivalDateTime          *time.Time `json:"ArrivalDateTime"`
	StartDateTime            *time.Time `json:"StartDateTime"`
	EndDateTime              *time.Time `json:"EndDateTime"`
	NavigationAddress        string     `json:"NavigationAddress"`
	Status                   int        `json:"Status"`
	AdditionalInformation    string     `json:"AdditionalInformation"`
	ServiceTimeInMinutes     int        `json:"ServiceTimeInMinutes"`
	Longitude                *float64   `json:"Longitude"`
	Latitude                 *float64   `json:"Latitude"`
	IsSuburb                 bool       `json:"IsSuburb"`
	IsFullAddress            bool       `json:"IsFullAddress"`
}

// JobTaskForSmartSchedulingResponse data
type JobTaskForSmartSchedulingResponse struct {
	JobID             int    `json:"JobID"`
	NavigationAddress string `json:"NavigationAddress"`
}

// JobTaskForJobResponse data
type JobTaskForJobResponse struct {
	JobTaskID                int        `json:"JobTaskID"`
	JobType                  int        `json:"JobType"`
	FormFlowID               *int       `json:"FormFlowID"`
	ScheduleStartDateTime    *time.Time `json:"ScheduleStartDateTime"`
	ScheduleEndDateTime      *time.Time `json:"ScheduleEndDateTime"`
	DepartureDateTime        *time.Time `json:"DepartureDateTime"`
	EstimatedArrivalDateTime *time.Time `json:"EstimatedArrivalDateTime"`
	ArrivalDateTime          *time.Time `json:"ArrivalDateTime"`
	StartDateTime            *time.Time `json:"StartDateTime"`
	EndDateTime              *time.Time `json:"EndDateTime"`
	Status                   int        `json:"Status"`
	AdditionalInformation    string     `json:"AdditionalInformation"`
	NavigationAddress        string     `json:"NavigationAddress"`
	ServiceTimeInMinutes     int        `json:"ServiceTimeInMinutes"`
	Longitude                *float64   `json:"Longitude"`
	Latitude                 *float64   `json:"Latitude"`
	IsSuburb                 bool       `json:"IsSuburb"`
	IsFullAddress            bool       `json:"IsFullAddress"`
}

// JobTaskForJobListResponse data
type JobTaskForJobListResponse struct {
	JobTaskID                int                     `json:"JobTaskID"`
	JobType                  int                     `json:"JobType"`
	JobTypeName              string                  `json:"JobTypeName"`
	JobTypeIcon              string                  `json:"JobTypeIcon"`
	NavigationAddress        string                  `json:"NavigationAddress"`
	ServiceTimeInMinutes     int                     `json:"ServiceTimeInMinutes"`
	FormFlowID               int                     `json:"FormFlowID"`
	Status                   int                     `json:"Status"`
	StatusName               string                  `json:"StatusName"`
	StatusIcon               string                  `json:"StatusIcon"`
	ScheduleStartDateTime    *time.Time              `json:"ScheduleStartDateTime"`
	ScheduleEndDateTime      *time.Time              `json:"ScheduleEndDateTime"`
	DepartureDateTime        *time.Time              `json:"DepartureDateTime"`
	EstimatedArrivalDateTime *time.Time              `json:"EstimatedArrivalDateTime"`
	ArrivalDateTime          *time.Time              `json:"ArrivalDateTime"`
	StartDateTime            *time.Time              `json:"StartDateTime"`
	EndDateTime              *time.Time              `json:"EndDateTime"`
	AdditionalInformation    string                  `json:"AdditionalInformation"`
	JobTimeInSeconds         int                     `json:"JobTimeInSeconds"`
	Longitude                *float64                `json:"Longitude"`
	Latitude                 *float64                `json:"Latitude"`
	IsSuburb                 bool                    `json:"IsSuburb"`
	IsFullAddress            bool                    `json:"IsFullAddress"`
	FourDPrice               []Job4DPriceResponse    `json:"FourDPrice"`
	FourDPriceForm           []FormUDTJSONFor4DPrice `json:"FourDPriceForm"`
}

// JobTaskForJobStatusResponse data
type JobTaskForJobStatusResponse struct {
	JobTaskID   int    `json:"JobTaskID"`
	JobType     int    `json:"JobType"`
	JobTypeName string `json:"JobTypeName"`
	Status      int    `json:"Status"`
	StatusName  string `json:"StatusName"`
}

// TableName func
func (JobTask) TableName() string {
	return "jobtasks"
}

// BeforeCreate func
func (object *JobTask) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobTask) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobTask) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowID", JSONObject)
	if res != nil {
		object.FormFlowID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobType", JSONObject)
	if res != nil {
		object.JobType, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleStartDateTime", JSONObject)
	if res != nil {
		vScheduleStartDateTime, sScheduleStartDateTime := services.ConvertStringToDateTime(val)
		if sScheduleStartDateTime == nil {
			object.ScheduleStartDateTime = &vScheduleStartDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleEndDateTime", JSONObject)
	if res != nil {
		vScheduleEndDateTime, sScheduleEndDateTime := services.ConvertStringToDateTime(val)
		if sScheduleEndDateTime == nil {
			object.ScheduleEndDateTime = &vScheduleEndDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("DepartureDateTime", JSONObject)
	if res != nil {
		vDepartureDateTime, sDepartureDateTime := services.ConvertStringToDateTime(val)
		if sDepartureDateTime == nil {
			object.DepartureDateTime = &vDepartureDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("EstimatedArrivalDateTime", JSONObject)
	if res != nil {
		vEstimatedArrivalDateTime, sEstimatedArrivalDateTime := services.ConvertStringToDateTime(val)
		if sEstimatedArrivalDateTime == nil {
			object.EstimatedArrivalDateTime = &vEstimatedArrivalDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("JobTimeInSeconds", JSONObject)
	if res != nil {
		object.JobTimeInSeconds, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ArrivalDateTime", JSONObject)
	if res != nil {
		vArrivalDateTime, sArrivalDateTime := services.ConvertStringToDateTime(val)
		if sArrivalDateTime == nil {
			object.ArrivalDateTime = &vArrivalDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("StartDateTime", JSONObject)
	if res != nil {
		vStartDateTime, sStartDateTime := services.ConvertStringToDateTime(val)
		if sStartDateTime == nil {
			object.StartDateTime = &vStartDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("EndDateTime", JSONObject)
	if res != nil {
		vEndDateTime, sEndDateTime := services.ConvertStringToDateTime(val)
		if sEndDateTime == nil {
			object.EndDateTime = &vEndDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("NavigationAddress", JSONObject)
	if res != nil {
		object.NavigationAddress = val
	}
	val, res = services.ConvertJSONValueToVariable("Address", JSONObject)
	if res != nil {
		object.NavigationAddress = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("AdditionalInformation", JSONObject)
	if res != nil {
		object.AdditionalInformation = val
	}
	val, res = services.ConvertJSONValueToVariable("ServiceTimeInMinutes", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.ServiceTimeInMinutes = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("Longitude", JSONObject)
	if res != nil {
		fLongitude, _ := strconv.ParseFloat(val, 64)
		object.Longitude = &fLongitude
	}
	val, res = services.ConvertJSONValueToVariable("Latitude", JSONObject)
	if res != nil {
		fLatitude, _ := strconv.ParseFloat(val, 64)
		object.Latitude = &fLatitude
	}
	val, res = services.ConvertJSONValueToVariable("IsSuburb", JSONObject)
	if res != nil {
		object.IsSuburb, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsFullAddress", JSONObject)
	if res != nil {
		object.IsFullAddress, _ = strconv.ParseBool(val)
	}
	return
}
