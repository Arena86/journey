package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FourDPriceDetail data
type FourDPriceDetail struct {
	FourDPriceDetailID int        `gorm:"column:4DPriceDetailID;primaryKey;not null"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FourDPriceID       int        `gorm:"column:4DPriceID" json:"FourDPriceID"`
	Dimension1         string     `gorm:"column:Dimension1" json:"Dimension1"`
	Dimension2         string     `gorm:"column:Dimension2" json:"Dimension2"`
	Dimension3         string     `gorm:"column:Dimension3" json:"Dimension3"`
	Dimension4         string     `gorm:"column:Dimension4" json:"Dimension4"`
	Price              float64    `gorm:"column:Price" json:"Price"`
	TriggerInspection  bool       `gorm:"column:TriggerInspection" json:"TriggerInspection"`
}

//FourDPriceDetailResponse data
type FourDPriceDetailResponse struct {
	FourDPriceDetailID int         `json:"FourDPriceDetailID"`
	FourDPriceID       int         `json:"FourDPriceID"`
	Dimension1         interface{} `json:"Dimension1"`
	Dimension2         interface{} `json:"Dimension2"`
	Dimension3         interface{} `json:"Dimension3"`
	Dimension4         interface{} `json:"Dimension4"`
	Price              float64     `json:"Price"`
	TriggerInspection  bool        `json:"TriggerInspection"`
}

// TableName func
func (FourDPriceDetail) TableName() string {
	return "4dpricedetails"
}

// BeforeCreate func
func (object *FourDPriceDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FourDPriceDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FourDPriceDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FourDPriceDetailID", JSONObject)
	if res != nil {
		object.FourDPriceDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceID", JSONObject)
	if res != nil {
		object.FourDPriceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension1", JSONObject)
	if res != nil {
		object.Dimension1 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension2", JSONObject)
	if res != nil {
		object.Dimension2 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension3", JSONObject)
	if res != nil {
		object.Dimension3 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension4", JSONObject)
	if res != nil {
		object.Dimension4 = val
	}
	val, res = services.ConvertJSONValueToVariable("Price", JSONObject)
	if res != nil {
		object.Price, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("TriggerInspection", JSONObject)
	if res != nil {
		object.TriggerInspection, _ = strconv.ParseBool(val)
	}

	return
}
