package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormUDTJSON str
type FormUDTJSON struct {
	JobID          interface{}      `json:"JobID"`
	JobTaskID      interface{}      `json:"JobTaskID"`
	FormPrimaryKey interface{}      `json:"FormPrimaryKey"`
	Controls       []FormUDTControl `json:"Controls"`
}

// FormUDTJSONForJob str
type FormUDTJSONFor4DPrice struct {
	JobID           interface{}      `json:"JobID"`
	JobTaskID       interface{}      `json:"JobTaskID"`
	DynamicFormID   interface{}      `json:"DynamicFormID"`
	FormPrimaryKey  interface{}      `json:"FormPrimaryKey"`
	JobTaskType     interface{}      `json:"JobTaskType"`
	JobTaskTypeName interface{}      `json:"JobTaskTypeName"`
	Key             interface{}      `json:"Key"`
	ItemID          interface{}      `json:"ItemID"`
	Controls        []FormUDTControl `json:"Controls"`
}

// FormUDTControl str
type FormUDTControl struct {
	FieldName interface{} `json:"FieldName"`
	Value     interface{} `json:"Value"`
}

// FormUDT data
type FormUDT struct {
	FormUDTID          int        `gorm:"column:FormUDTID;primaryKey;autoIncrement;not null" json:"FormUDTID"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DraftDynamicFormID int        `gorm:"column:DraftDynamicFormID" json:"DraftDynamicFormID"`
	TableNameObj       string     `gorm:"column:TableName" json:"TableName"`
	IsPublished        bool       `gorm:"column:IsPublished" json:"IsPublished"`
	FormUDFs           []FormUDF  `gorm:"foreignKey:FormUDTID;references:FormUDTID" json:"FormUDFs"`
}

// FormUDTResponse data
type FormUDTResponse struct {
	FormUDTID          int               `json:"FormUDTID"`
	DraftDynamicFormID int               `json:"DraftDynamicFormID"`
	TableNameObj       string            `json:"TableName"`
	IsPublished        bool              `json:"IsPublished"`
	FormUDFs           []FormUDFResponse `json:"FormUDFs"`
}

// TableName func
func (FormUDT) TableName() string {
	return "formudts"
}

// BeforeCreate func
func (object *FormUDT) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormUDT) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormUDT) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormUDTID", JSONObject)
	if res != nil {
		object.FormUDTID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DraftDynamicFormID", JSONObject)
	if res != nil {
		object.DraftDynamicFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TableName", JSONObject)
	if res != nil {
		object.TableNameObj = val
	}

	val, res = services.ConvertJSONValueToVariable("FormUDFs", JSONObject)
	if res != nil {
		var (
			formUDFs       []FormUDF
			objectFormUDFs []map[string]interface{}
		)
		formUDFs = make([]FormUDF, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectFormUDFs)
			if len(objectFormUDFs) > 0 {
				for _, obj := range objectFormUDFs {
					var (
						detail FormUDF
					)
					detail.PassBodyJSONToModel(obj)
					formUDFs = append(formUDFs, detail)
				}
			}
		}
		object.FormUDFs = formUDFs
	}
	return
}
