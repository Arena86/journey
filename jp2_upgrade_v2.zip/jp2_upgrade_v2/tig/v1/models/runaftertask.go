package models

import "time"

// RunAfterTask data
type RunAfterTask struct {
	RunAfterTaskID          int        `gorm:"column:RunAfterTaskID;primaryKey;autoIncrement;not null"`
	CreatedBy               int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate             *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy              int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate            *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted               bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                 bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived              bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TaskID                  int        `gorm:"column:TaskID"`
	MainTask                int        `gorm:"column:MainTask"`
	DelayInMinutes          int        `gorm:"column:DelayInMinutes"`
	DoNotRunIfMainTaskFails bool       `gorm:"column:DoNotRunIfMainTaskFails"`
}

// TableName func
func (RunAfterTask) TableName() string {
	return "runaftertasks"
}
