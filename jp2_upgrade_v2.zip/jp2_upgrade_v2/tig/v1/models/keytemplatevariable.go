package models

import (
	"time"
)

// KeyTemplateVariable data
type KeyTemplateVariable struct {
	TemplateVariableID  int        `gorm:"column:TemplateVariableID;primaryKey;autoIncrement;not null" json:"TemplateVariableID"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DataField           string     `gorm:"column:DataField" json:"DataField"`
	Type                string     `gorm:"column:Type" json:"Type"`
	TemplateVariableKey int        `gorm:"column:TemplateVariableKey" json:"TemplateVariableKey"`
	TranslationKey      string     `gorm:"column:TranslationKey" json:"TranslationKey"`
}

// KeyTemplateVariableResponse data
type KeyTemplateVariableResponse struct {
	TemplateVariableID  int    `json:"TemplateVariableID"`
	DataField           string `json:"DataField"`
	Type                string `json:"Type"`
	TemplateVariableKey int    `json:"TemplateVariableKey"`
	Caption             string `json:"Caption"`
}

// TableName func
func (KeyTemplateVariable) TableName() string {
	return "keytemplatevariables"
}
