package models

import "time"

// CronJobResponseRedisKey str
type CronJobResponseRedisKey struct {
	Status  int
	Message string
	Keys    []string
}

// CronJobResponseRedisData str
type CronJobResponseRedisData struct {
	Status  int
	Message string
	Data    ChatHistoryResponse
}

// ChatHistoryRedis str
type ChatHistoryRedis struct {
	DateTime   string `json:"datetime"`
	From       string `json:"from"`
	MessageKey string `json:"messagekey"`
	Message    string `json:"message"`
	Status     string `json:"status"`
	To         string `json:"to"`
}

// ChatHistoryResponse str
type ChatHistoryResponse struct {
	From             int
	To               int
	Status           int
	Message          string
	DateTime         *time.Time
	MessageKey       string
	FromFirstName    string
	FromLastName     string
	FromLocationName string
	ToFirstName      string
	ToLastName       string
	ToLocationName   string
}
