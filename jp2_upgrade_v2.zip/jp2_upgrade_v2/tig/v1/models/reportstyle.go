package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ReportStyleResponse data
type ReportStyleResponse struct {
	ReportStyleID       int     `json:"ReportStyleID"`
	ReportStyleName     string  `json:"ReportStyleName"`
	FontName            string  `json:"FontName"`
	FontSize            int     `json:"FontSize"`
	FontUnit            int     `json:"FontUnit"`
	FontBold            bool    `json:"FontBold"`
	FontItalic          bool    `json:"FontItalic"`
	FontUnderline       bool    `json:"FontUnderline"`
	FontStrikeout       bool    `json:"FontStrikeout"`
	TextAlignment       int     `json:"TextAlignment"`
	BackgroundColorRGBA string  `json:"BackgroundColorRGBA"`
	ForegroundColorRGBA string  `json:"ForegroundColorRGBA"`
	BorderColorRGBA     string  `json:"BorderColorRGBA"`
	BorderSides         int     `json:"BorderSides"`
	BorderWidth         float32 `json:"BorderWidth"`
	BorderDashStyle     int     `json:"BorderDashStyle"`
	PaddingLeft         int     `json:"PaddingLeft"`
	PaddingRight        int     `json:"PaddingRight"`
	PaddingBottom       int     `json:"PaddingBottom"`
	PaddingTop          int     `json:"PaddingTop"`
}

// ReportStyle data
type ReportStyle struct {
	ReportStyleID       int        `gorm:"column:ReportStyleID;primaryKey;autoIncrement;not null"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ReportStyleName     string     `gorm:"column:ReportStyleName" json:"ReportStyleName"`
	FontName            string     `gorm:"column:FontName" json:"FontName"`
	FontSize            int        `gorm:"column:FontSize" json:"FontSize"`
	FontUnit            int        `gorm:"column:FontUnit" json:"FontUnit"`
	FontBold            bool       `gorm:"column:FontBold" json:"FontBold"`
	FontItalic          bool       `gorm:"column:FontItalic" json:"FontItalic"`
	FontUnderline       bool       `gorm:"column:FontUnderline" json:"FontUnderline"`
	FontStrikeout       bool       `gorm:"column:FontStrikeout" json:"FontStrikeout"`
	TextAlignment       int        `gorm:"column:TextAlignment" json:"TextAlignment"`
	BackgroundColorRGBA string     `gorm:"column:BackgroundColorRGBA" json:"BackgroundColorRGBA"`
	ForegroundColorRGBA string     `gorm:"column:ForegroundColorRGBA" json:"ForegroundColorRGBA"`
	BorderColorRGBA     string     `gorm:"column:BorderColorRGBA" json:"BorderColorRGBA"`
	BorderSides         int        `gorm:"column:BorderSides" json:"BorderSides"`
	BorderWidth         float32    `gorm:"column:BorderWidth" json:"BorderWidth"`
	BorderDashStyle     int        `gorm:"column:BorderDashStyle" json:"BorderDashStyle"`
	PaddingLeft         int        `gorm:"column:PaddingLeft" json:"PaddingLeft"`
	PaddingRight        int        `gorm:"column:PaddingRight" json:"PaddingRight"`
	PaddingBottom       int        `gorm:"column:PaddingBottom" json:"PaddingBottom"`
	PaddingTop          int        `gorm:"column:PaddingTop" json:"PaddingTop"`
}

// TableName func
func (ReportStyle) TableName() string {
	return "reportstyles"
}

// BeforeCreate func
func (object *ReportStyle) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ReportStyle) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ReportStyle) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ReportStyleID", JSONObject)
	if res != nil {
		vReportStyleID, sReportStyleID := strconv.Atoi(val)
		if sReportStyleID == nil {
			object.ReportStyleID = vReportStyleID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ReportStyleName", JSONObject)
	if res != nil {
		object.ReportStyleName = val
	}
	val, res = services.ConvertJSONValueToVariable("FontName", JSONObject)
	if res != nil {
		object.FontName = val
	}
	val, res = services.ConvertJSONValueToVariable("FontSize", JSONObject)
	if res != nil {
		vFontSize, sFontSize := strconv.Atoi(val)
		if sFontSize == nil {
			object.FontSize = vFontSize
		}
	}
	val, res = services.ConvertJSONValueToVariable("FontUnit", JSONObject)
	if res != nil {
		vFontUnit, sFontUnit := strconv.Atoi(val)
		if sFontUnit == nil {
			object.FontUnit = vFontUnit
		}
	}
	val, res = services.ConvertJSONValueToVariable("FontBold", JSONObject)
	if res != nil {
		object.FontBold, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("FontItalic", JSONObject)
	if res != nil {
		object.FontItalic, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("FontUnderline", JSONObject)
	if res != nil {
		object.FontUnderline, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("FontStrikeout", JSONObject)
	if res != nil {
		object.FontStrikeout, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TextAlignment", JSONObject)
	if res != nil {
		vTextAlignment, sTextAlignment := strconv.Atoi(val)
		if sTextAlignment == nil {
			object.TextAlignment = vTextAlignment
		}
	}
	val, res = services.ConvertJSONValueToVariable("BackgroundColorRGBA", JSONObject)
	if res != nil {
		object.BackgroundColorRGBA = val
	}
	val, res = services.ConvertJSONValueToVariable("ForegroundColorRGBA", JSONObject)
	if res != nil {
		object.ForegroundColorRGBA = val
	}
	val, res = services.ConvertJSONValueToVariable("BorderColorRGBA", JSONObject)
	if res != nil {
		object.BorderColorRGBA = val
	}
	val, res = services.ConvertJSONValueToVariable("BorderSides", JSONObject)
	if res != nil {
		object.BorderSides, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("BorderWidth", JSONObject)
	if res != nil {
		vBorderWidth, _ := strconv.ParseFloat(val, 32)
		object.BorderWidth = float32(vBorderWidth)
	}
	val, res = services.ConvertJSONValueToVariable("BorderDashStyle", JSONObject)
	if res != nil {
		object.BorderDashStyle, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaddingLeft", JSONObject)
	if res != nil {
		object.PaddingLeft, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaddingRight", JSONObject)
	if res != nil {
		object.PaddingRight, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaddingBottom", JSONObject)
	if res != nil {
		object.PaddingBottom, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaddingTop", JSONObject)
	if res != nil {
		object.PaddingTop, _ = strconv.Atoi(val)
	}
	return
}
