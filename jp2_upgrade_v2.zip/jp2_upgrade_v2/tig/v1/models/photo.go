package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Photo data
type Photo struct {
	PhotoID      int        `gorm:"column:PhotoID;primaryKey;autoIncrement;not null"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TableNameObj string     `gorm:"column:TableName" json:"TableName"`
	RecordID     int        `gorm:"column:RecordID" json:"RecordID"`
	ImageKey     string     `gorm:"column:ImageKey" json:"ImageKey"`
	ImageURL     string     `gorm:"column:ImageUrl" json:"ImageUrl"`
	ImageSize    int        `gorm:"column:ImageSize" json:"ImageSize"`
	ETag         string     `gorm:"column:ETag" json:"ETag"`
	ReasonID     int        `gorm:"column:ReasonID" json:"ReasonID"`
	Comment      string     `gorm:"column:Comment" json:"Comment"`
	PositionX    float64    `gorm:"column:PositionX" json:"PositionX"`
	PositionY    float64    `gorm:"column:PositionY" json:"PositionY"`
}

// PhotoResponse data
type PhotoResponse struct {
	PhotoID      int     `json:"PhotoID"`
	TableNameObj string  `json:"TableName"`
	ImageKey     string  `json:"ImageKey"`
	ImageURL     string  `json:"ImageUrl"`
	ImageSize    int     `json:"ImageSize"`
	ETag         string  `json:"ETag"`
	ReasonID     int     `json:"ReasonID"`
	Reason       string  `json:"Reason"`
	Comment      string  `json:"Comment"`
	PositionX    float64 `json:"PositionX"`
	PositionY    float64 `json:"PositionY"`
}

// TableName func
func (Photo) TableName() string {
	return "photos"
}

// BeforeCreate func
func (object *Photo) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Photo) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Photo) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PhotoID", JSONObject)
	if res != nil {
		object.PhotoID, _ = strconv.Atoi(val)
	}
	// auto generate
	/* val, res = services.ConvertJSONValueToVariable("TableName", JSONObject)
	if res != nil {
		object.TableNameObj = val
	} */
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageKey", JSONObject)
	if res != nil {
		object.ImageKey = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageUrl", JSONObject)
	if res != nil {
		object.ImageURL = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageURL", JSONObject)
	if res != nil {
		object.ImageURL = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageSize", JSONObject)
	if res != nil {
		object.ImageSize, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ETag", JSONObject)
	if res != nil {
		object.ETag = val
	}
	val, res = services.ConvertJSONValueToVariable("PositionX", JSONObject)
	if res != nil {
		object.PositionX, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("PositionY", JSONObject)
	if res != nil {
		object.PositionY, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("RecordID", JSONObject)
	if res != nil {
		object.RecordID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ReasonID", JSONObject)
	if res != nil {
		object.ReasonID, _ = strconv.Atoi(val)
	}
	return
}
