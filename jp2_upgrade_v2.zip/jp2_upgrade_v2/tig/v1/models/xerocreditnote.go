package models

// XeroCreditNoteJPPOST str
type XeroCreditNoteJPPOST struct {
	Type             *string               `json:"Type,omitempty"`
	Contact          XeroInvoiceContact    `json:"Contact"`
	CreditNoteNumber *string               `json:"CreditNoteNumber,omitempty"`
	Reference        *string               `json:"Reference,omitempty"`
	BrandingThemeID  *string               `json:"BrandingThemeID,omitempty"`
	Date             *string               `json:"Date,omitempty"`
	DateString       *string               `json:"DateString,omitempty"`
	CurrencyCode     *string               `json:"CurrencyCode,omitempty"`
	Status           *string               `json:"Status,omitempty"`
	LineAmountTypes  *string               `json:"LineAmountTypes,omitempty"`
	LineItems        []XeroCreditNoteItem  `json:"LineItems"`
	Allocations      *XeroAllocationJPPOST `json:"Allocations"`
}

// XeroCreditNoteItem str
type XeroCreditNoteItem struct {
	Description    *string  `json:"Description,omitempty"`
	Quantity       *float64 `json:"Quantity,omitempty"`
	UnitAmount     *float64 `json:"UnitAmount,omitempty"`
	ItemCode       *string  `json:"ItemCode,omitempty"`
	AccountCode    *string  `json:"AccountCode,omitempty"`
	LineItemID     *string  `json:"LineItemID,omitempty"`
	TaxType        *string  `json:"TaxType,omitempty"`
	TaxAmount      *string  `json:"TaxAmount,omitempty"`
	LineAmount     *string  `json:"LineAmount,omitempty"`
	DiscountRate   *string  `json:"DiscountRate,omitempty"`
	DiscountAmount *string  `json:"DiscountAmount,omitempty"`
}
