package models

// EstimateEncrypt str
type EstimateEncrypt struct {
	JobID     int
	CompanyID string
	Token     string
	Language  string
}

// EstimatePOST str
type EstimatePOST struct {
	JobID             int    `json:"JobID" validate:"required"`
	ReportID          int    `json:"ReportID"`
	EmailAddress      string `json:"emailAddress" validate:"required,email"`
	AdditionalComment string `json:"AdditionalComment"`
	Language          string `json:"Language"`
}

// EstimateApprovalPOST str
type EstimateApprovalPOST struct {
	JobID     int    `json:"JobID" validate:"required"`
	JobToken  string `json:"JobToken" validate:"required"`
	Approved  bool   `json:"Approved"`
	Signature string `json:"Signature"`
	Comment   string `json:"Comment"`
}

// EstimateApprovalPOST str
type EstimateRejectPOST struct {
	JobID   int    `json:"JobID" validate:"required"`
	Comment string `json:"Comment"`
}
