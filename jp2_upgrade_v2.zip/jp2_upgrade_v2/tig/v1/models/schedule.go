package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ScheduleMappingResponse str
type ScheduleMappingResponse struct {
	JobID             int
	JobNumber         string
	ScheduleStartDate time.Time
	ScheduleEndDate   time.Time
	NavigationAddress string
	CompanyName       string
}

// ScheduleJobResponse str
type ScheduleJobResponse struct {
	ScheduleID int
	JobID      int
	JobNumber  string
	Status     int
	//JobTaskID         int
	//FormFlowID        int
	//ScheduleStartDate time.Time
	//ScheduleEndDate   time.Time
	NavigationAddress  string
	CompanyName        string
	InspectionForJobID int
	IsInspection       bool
	IsCombinedChild    bool
	IsMultipleChild    bool
	IsPrimaryJob       bool
}

// ScheduleJobTaskResponse str
type ScheduleJobTaskResponse struct {
	ScheduleID         int
	JobID              int
	JobNumber          string
	Status             int
	JobTaskID          int
	JobType            int
	JobTypeName        string
	FormFlowID         int
	ScheduleStartDate  time.Time
	ScheduleEndDate    time.Time
	NavigationAddress  string
	CompanyName        string
	InspectionForJobID int
	IsInspection       bool
	IsCombinedChild    bool
	IsMultipleChild    bool
	IsPrimaryJob       bool
}

// Schedule data
type Schedule struct {
	ScheduleID                int        `gorm:"column:ScheduleID;primaryKey;autoIncrement;not null"`
	CreatedBy                 int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ScheduleStartDate         time.Time  `gorm:"column:ScheduleStartDate" json:"ScheduleStartDate"`
	ScheduleEndDate           time.Time  `gorm:"column:ScheduleEndDate" json:"ScheduleEndDate"`
	LocationID                int        `gorm:"column:LocationID" json:"LocationID"`
	ResourceID                int        `gorm:"column:ResourceID" json:"ResourceID"`
	PrimaryResourceID         *int       `gorm:"column:PrimaryResourceID" json:"PrimaryResourceID"`
	UserID                    int        `gorm:"column:UserID" json:"UserID"`
	JobID                     int        `gorm:"column:JobID" json:"JobID"`
	JobTaskID                 int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	JourneyCode               *string    `gorm:"column:JourneyCode" json:"JourneyCode"`
	ScheduleStartDateTimeZone string     `gorm:"column:ScheduleStartDateTimeZone" json:"ScheduleStartDateTimeZone"`
	ScheduleEndDateTimeZone   string     `gorm:"column:ScheduleEndDateTimeZone" json:"ScheduleEndDateTimeZone"`
	IsReschedule              bool       `gorm:"column:IsReschedule" json:"IsReschedule"`
	RescheduleReasonID        int        `gorm:"column:RescheduleReasonID" json:"RescheduleReasonID"`
	RescheduleComment         string     `gorm:"column:RescheduleComment" json:"RescheduleComment"`
	RescheduleDateTime        *time.Time `gorm:"column:RescheduleDateTime" json:"RescheduleDateTime"`
	RescheduleUserID          int        `gorm:"column:RescheduleUserID" json:"RescheduleUserID "`
}

// ScheduleResponse data
type ScheduleResponse struct {
	ScheduleID                int                      `json:"ScheduleID"`
	ScheduleStartDate         time.Time                `json:"ScheduleStartDate"`
	ScheduleEndDate           time.Time                `json:"ScheduleEndDate"`
	LocationID                int                      `json:"LocationID"`
	ResourceID                int                      `json:"ResourceID"`
	PrimaryResourceID         *int                     `json:"PrimaryResourceID"`
	UserID                    int                      `json:"UserID"`
	FirstName                 string                   `json:"FirstName"`
	LastName                  string                   `json:"LastName"`
	JobID                     int                      `json:"JobID"`
	JobTaskID                 int                      `json:"JobTaskID"`
	JourneyCode               *string                  `json:"JourneyCode"`
	JobStatus                 int                      `json:"JobStatus"`
	JobStatusName             string                   `json:"JobStatusName"`
	JobStatusIcon             string                   `json:"JobStatusIcon"`
	JobSummary                JobSummary               `json:"JobSummary"`
	ScheduleStartDateTimeZone string                   `json:"ScheduleStartDateTimeZone"`
	ScheduleEndDateTimeZone   string                   `json:"ScheduleEndDateTimeZone"`
	AdditionalUsers           []AdditionalUserResponse `json:"AdditionalUsers"`
}

// TableName func
func (Schedule) TableName() string {
	return "schedules"
}

// BeforeCreate func
func (object *Schedule) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Schedule) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Schedule) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ScheduleID", JSONObject)
	if res != nil {
		object.ScheduleID, _ = strconv.Atoi(val)
	}

	val, res = services.ConvertJSONValueToVariable("ScheduleStartDate", JSONObject)
	if res != nil {
		vScheduleStartDate, sScheduleStartDate := services.ConvertStringToDateTime(val)
		if sScheduleStartDate == nil {
			object.ScheduleStartDate = vScheduleStartDate
		}
	}

	val, res = services.ConvertJSONValueToVariable("ScheduleEndDate", JSONObject)
	if res != nil {
		vScheduleEndDate, sScheduleEndDate := services.ConvertStringToDateTime(val)
		if sScheduleEndDate == nil {
			object.ScheduleEndDate = vScheduleEndDate
		}
	}

	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		object.UserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleStartDateTimeZone", JSONObject)
	if res != nil {
		object.ScheduleStartDateTimeZone = val
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleEndDateTimeZone", JSONObject)
	if res != nil {
		object.ScheduleEndDateTimeZone = val
	}
	val, res = services.ConvertJSONValueToVariable("PrimaryResourceID", JSONObject)
	if res != nil {
		primaryResourceID, _ := strconv.Atoi(val)
		object.PrimaryResourceID = &primaryResourceID
	}
	return
}
