package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"
)

// XeroConfig data
type XeroConfig struct {
	XeroConfigKey                int        `gorm:"column:XeroConfigKey;primaryKey;autoIncrement;not null" json:"XeroConfigKey"`
	BaseURL                      string     `gorm:"column:BaseURL" json:"BaseUrl"`
	IdentityURL                  string     `gorm:"column:IdentityURL" json:"IdentityUrl"`
	RedirectURI                  string     `gorm:"column:RedirectURI" json:"RedirectUri"`
	AuthorizationCode            string     `gorm:"column:AuthorizationCode"`
	AccessToken                  string     `gorm:"column:AccessToken"`
	RefreshToken                 string     `gorm:"column:RefreshToken"`
	TenantID                     string     `gorm:"column:TenantId" json:"TenantId"`
	ClientID                     string     `gorm:"column:ClientId" json:"ClientId"`
	ClientSecret                 string     `gorm:"column:ClientSecret" json:"ClientSecret"`
	IsActive                     bool       `gorm:"column:IsActive" json:"IsActive"`
	UseXeroPush                  bool       `gorm:"column:UseXeroPush" json:"UseXeroPush"`
	IntervalInSeconds            int        `gorm:"column:IntervalInSeconds" json:"IntervalInSeconds"`
	LastTimeItem                 *time.Time `gorm:"column:LastTimeItem" json:"LastTimeItem"`
	LastTimeCustomer             *time.Time `gorm:"column:LastTimeCustomer" json:"LastTimeCustomer"`
	InventoryAssetAccountCode    string     `gorm:"column:InventoryAssetAccountCode"`
	InventoryPurchaseAccountCode string     `gorm:"column:InventoryPurchaseAccountCode"`
	WebhookURL                   string     `gorm:"column:WebhookURL"`
	WebhookKey                   string     `gorm:"column:WebhookKey"`
	ReasonID                     int        `gorm:"column:ReasonID"`
	IsInvoiceEnabled             bool       `gorm:"column:IsInvoiceEnabled"`
	IsCreditNoteEnabled          bool       `gorm:"column:IsCreditNoteEnabled"`
	IsPostAfterJobCompleted      bool       `gorm:"column:IsPostAfterJobCompleted"`
	PostedInvoiceStatus          string     `gorm:"column:PostedInvoiceStatus"`
	Organisation                 string     `gorm:"column:Organisation"`
	Branding                     string     `gorm:"column:Branding"`
	InvoiceNumberGeneration      string     `gorm:"column:InvoiceNumberGeneration"`
	InvoiceDueDate               int        `gorm:"column:InvoiceDueDate"`
	CreditNoteNumberGeneration   string     `gorm:"column:CreditNoteNumberGeneration"`
	ItemSaleAccountCode          string     `gorm:"column:ItemSaleAccountCode"`
}

// XeroConfigResponse data
type XeroConfigResponse struct {
	XeroConfigKey                int              `json:"XeroConfigKey"`
	BaseURL                      string           `json:"BaseURL"`
	IdentityURL                  string           `json:"IdentityURL"`
	RedirectURI                  string           `json:"RedirectURI"`
	AuthorizationCode            string           `json:"AuthorizationCode"`
	TenantID                     string           `json:"TenantID"`
	ClientID                     string           `json:"ClientID"`
	ClientSecret                 string           `json:"ClientSecret"`
	Tenant                       []TenantResponse `json:"Tenants"`
	IsActive                     bool             `json:"IsActive"`
	UseXeroPush                  bool             `json:"UseXeroPush"`
	IntervalInSeconds            int              `json:"IntervalInSeconds"`
	InventoryAssetAccountCode    string           `json:"InventoryAssetAccountCode"`
	InventoryPurchaseAccountCode string           `json:"InventoryPurchaseAccountCode"`
	WebhookURL                   string           `json:"WebhookURL"`
	WebhookKey                   string           `json:"WebhookKey"`
	IsInvoiceEnabled             bool             `json:"IsInvoiceEnabled"`
	IsCreditNoteEnabled          bool             `json:"IsCreditNoteEnabled"`
	IsPostAfterJobCompleted      bool             `json:"IsPostAfterJobCompleted"`
	PostedInvoiceStatus          string           `json:"PostedInvoiceStatus"`
	Organisation                 string           `json:"Organisation"`
	Branding                     string           `json:"Branding"`
	InvoiceNumberGeneration      string           `json:"InvoiceNumberGeneration"`
	InvoiceDueDate               int              `json:"InvoiceDueDate"`
	CreditNoteNumberGeneration   string           `json:"CreditNoteNumberGeneration"`
	ItemSaleAccountCode          string           `json:"ItemSaleAccountCode"`
}

// TenantResponse str
type TenantResponse struct {
	TenantID   string `json:"TenantID"`
	TenantName string `json:"TenantName"`
}

// TableName func
func (XeroConfig) TableName() string {
	return "xeroconfig"
}

// PassBodyJSONToModel func
func (object *XeroConfig) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("XeroConfigKey", JSONObject)
	if res != nil {
		vXeroConfigKey, sXeroConfigKey := strconv.Atoi(val)
		if sXeroConfigKey == nil {
			object.XeroConfigKey = vXeroConfigKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("BaseURL", JSONObject)
	if res != nil {
		object.BaseURL = val
	}
	val, res = services.ConvertJSONValueToVariable("IdentityURL", JSONObject)
	if res != nil {
		object.IdentityURL = val
	}
	val, res = services.ConvertJSONValueToVariable("RedirectURI", JSONObject)
	if res != nil {
		object.RedirectURI = val
	}
	val, res = services.ConvertJSONValueToVariable("AuthorizationCode", JSONObject)
	if res != nil {
		object.AuthorizationCode = val
	}
	val, res = services.ConvertJSONValueToVariable("TenantID", JSONObject)
	if res != nil {
		object.TenantID = val
	}
	val, res = services.ConvertJSONValueToVariable("ClientID", JSONObject)
	if res != nil {
		object.ClientID = val
	}
	val, res = services.ConvertJSONValueToVariable("ClientSecret", JSONObject)
	if res != nil {
		object.ClientSecret = val
	}
	val, res = services.ConvertJSONValueToVariable("UseXeroPush", JSONObject)
	if res != nil {
		object.UseXeroPush, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IntervalInSeconds", JSONObject)
	if res != nil {
		vIntervalInSeconds, sIntervalInSeconds := strconv.Atoi(val)
		if sIntervalInSeconds == nil {
			object.IntervalInSeconds = vIntervalInSeconds
		}
	}
	val, res = services.ConvertJSONValueToVariable("InventoryAssetAccountCode", JSONObject)
	if res != nil {
		object.InventoryAssetAccountCode = val
	}
	val, res = services.ConvertJSONValueToVariable("InventoryPurchaseAccountCode", JSONObject)
	if res != nil {
		object.InventoryPurchaseAccountCode = val
	}
	val, res = services.ConvertJSONValueToVariable("WebhookURL", JSONObject)
	if res != nil {
		object.WebhookURL = val
	}
	val, res = services.ConvertJSONValueToVariable("WebhookKey", JSONObject)
	if res != nil {
		object.WebhookKey = val
	}
	val, res = services.ConvertJSONValueToVariable("IsInvoiceEnabled", JSONObject)
	if res != nil {
		object.IsInvoiceEnabled, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCreditNoteEnabled", JSONObject)
	if res != nil {
		object.IsCreditNoteEnabled, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsPostAfterJobCompleted", JSONObject)
	if res != nil {
		object.IsPostAfterJobCompleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("PostedInvoiceStatus", JSONObject)
	if res != nil {
		object.PostedInvoiceStatus = val
	}
	val, res = services.ConvertJSONValueToVariable("Organisation", JSONObject)
	if res != nil {
		object.Organisation = val
	}
	val, res = services.ConvertJSONValueToVariable("Branding", JSONObject)
	if res != nil {
		object.Branding = val
	}
	val, res = services.ConvertJSONValueToVariable("InvoiceNumberGeneration", JSONObject)
	if res != nil {
		object.InvoiceNumberGeneration = val
	}
	val, res = services.ConvertJSONValueToVariable("InvoiceDueDate", JSONObject)
	if res != nil {
		object.InvoiceDueDate, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("CreditNoteNumberGeneration", JSONObject)
	if res != nil {
		object.CreditNoteNumberGeneration = val
	}
	val, res = services.ConvertJSONValueToVariable("ItemSaleAccountCode", JSONObject)
	if res != nil {
		object.ItemSaleAccountCode = val
	}
	return
}
