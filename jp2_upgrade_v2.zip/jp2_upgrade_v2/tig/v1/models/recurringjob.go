package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

type RecurringJobJSON struct {
	JobID             int
	JobTaskID         int
	ResourceID        int
	ScheduleStartDate *time.Time `json:"ScheduleStartDate"`
	ScheduleEndDate   *time.Time `json:"ScheduleEndDate"`
}

// RecurringJob data
type RecurringJob struct {
	RecurringJobID int             `gorm:"column:RecurringJobID;primaryKey;autoIncrement;not null"`
	CreatedBy      int             `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time      `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int             `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time      `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool            `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool            `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool            `gorm:"column:IsArchived" json:"IsArchived"`
	JobID          int             `gorm:"column:JobID" json:"JobID"`
	StartDate      *time.Time      `gorm:"column:StartDate" json:"StartDate"`
	EndDate        *time.Time      `gorm:"column:EndDate" json:"EndDate"`
	ResourceID     int             `gorm:"column:ResourceID" json:"ResourceID"`
	IsInfinite     bool            `gorm:"column:IsInfinite" json:"IsInfinite"`
	IsPaused       bool            `gorm:"column:IsPaused" json:"IsPaused"`
	StartTime      time.Time       `gorm:"column:StartTime" json:"StartTime"`
	Frequency      int             `gorm:"column:Frequency" json:"Frequency"`
	WeekDay        string          `gorm:"column:WeekDay" json:"WeekDay"`
	MonthDay       int             `gorm:"column:MonthDay" json:"MonthDay"`
	MonthFSTFL     int             `gorm:"column:MonthFSTFL" json:"MonthFSTFL"`
	Every          int             `gorm:"column:Every" json:"Every"`
	Comment        string          `gorm:"column:Comment" json:"Comment"`
	RecurringSkips []RecurringSkip `gorm:"foreignKey:RecurringJobID;references:RecurringJobID" json:"recurringSkips"`
}

// RecurringJobResponse data
type RecurringJobResponse struct {
	RecurringJobID            int        `json:"RecurringJobID"`
	JobID                     int        `json:"JobID"`
	StartDate                 *time.Time `json:"StartDate"`
	EndDate                   *time.Time `json:"EndDate"`
	ResourceID                int        `json:"ResourceID"`
	ResourceName              string     `json:"ResourceName"`
	ResourceType              int        `json:"ResourceType"`
	ResourceTypeIcon          string     `json:"ResourceTypeIcon"`
	ResourceTypeName          string     `json:"ResourceTypeName"`
	ResourceColor             string     `json:"ResourceColor"`
	IsInfinite                bool       `json:"IsInfinite"`
	IsPaused                  bool       `json:"IsPaused"`
	StartTime                 time.Time  `json:"StartTime"`
	Frequency                 int        `json:"Frequency"`
	FrequencyName             string     `json:"FrequencyName"`
	FrequencyNameTranslated   string     `json:"FrequencyNameTranslated"`
	WeekDay                   []string   `json:"WeekDay"`
	MonthDay                  int        `json:"MonthDay"`
	MonthFSTFL                int        `json:"MonthFSTFL"`
	Every                     int        `json:"Every"`
	Comment                   string     `json:"Comment"`
	RecurringStatus           int        `json:"RecurringStatus"`
	RecurringStatusTranslated string     `json:"RecurringStatusTranslated"`
}

// TableName func
func (RecurringJob) TableName() string {
	return "recurringjobs"
}

// BeforeCreate func
func (object *RecurringJob) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *RecurringJob) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *RecurringJob) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("RecurringJobID", JSONObject)
	if res != nil {
		object.RecurringJobID, _ = strconv.Atoi(val)
	}
	/* val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	} */
	val, res = services.ConvertJSONValueToVariable("StartDate", JSONObject)
	if res != nil {
		vStartDate, sStartDate := services.ConvertStringToDateTime(val)
		if sStartDate == nil {
			object.StartDate = &vStartDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("EndDate", JSONObject)
	if res != nil {
		vEndDate, sEndDate := services.ConvertStringToDateTime(val)
		if sEndDate == nil {
			object.EndDate = &vEndDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsInfinite", JSONObject)
	if res != nil {
		object.IsInfinite, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsPaused", JSONObject)
	if res != nil {
		object.IsPaused, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("StartTime", JSONObject)
	if res != nil {
		vStartTime, sStartTime := services.ConvertStringToDateTime(val)
		if sStartTime == nil {
			sCurrentOnlyDate := time.Now().Format("2006-01-02")
			sOnlyTime := vStartTime.Format("15:04:05")
			sDateTime := sCurrentOnlyDate + " " + sOnlyTime
			object.StartTime, _ = services.ConvertStringToDateTime(sDateTime)
		}
	}
	val, res = services.ConvertJSONValueToVariable("Frequency", JSONObject)
	if res != nil {
		object.Frequency, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("WeekDay", JSONObject)
	if res != nil {
		var (
			sWeekDay   string
			arrWeekDay []string
		)
		weekDayJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(weekDayJSON, &arrWeekDay)
		}
		if len(arrWeekDay) > 0 {
			for i := range arrWeekDay {
				arrWeekDay[i] = strings.TrimSpace(arrWeekDay[i])
			}
			sWeekDay = strings.Join(arrWeekDay, ", ")
		}
		object.WeekDay = sWeekDay
	}
	val, res = services.ConvertJSONValueToVariable("MonthDay", JSONObject)
	if res != nil {
		object.MonthDay, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("MonthFSTFL", JSONObject)
	if res != nil {
		object.MonthFSTFL, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Every", JSONObject)
	if res != nil {
		object.Every, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	return
}
