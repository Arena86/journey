package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleStocktakeHistory data
type VehicleStocktakeHistory struct {
	VehicleStocktakeHistoryID int                               `gorm:"column:VehicleStocktakeHistoryID;primaryKey;autoIncrement;not null" json:"VehicleStocktakeHistoryID"`
	CreatedBy                 int                               `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time                        `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int                               `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time                        `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool                              `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool                              `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                bool                              `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleStocktakeID        int                               `gorm:"column:VehicleStocktakeID" json:"VehicleStocktakeID"`
	StocktakeDate             *time.Time                        `gorm:"column:StocktakeDate" json:"StocktakeDate"`
	Comment                   string                            `gorm:"column:Comment" json:"Comment"`
	ResourceID                int                               `gorm:"column:ResourceID" json:"ResourceID"`
	Questions                 []VehicleStocktakeQuestionHistory `gorm:"foreignKey:VehicleStocktakeHistoryID;references:VehicleStocktakeHistoryID" json:"Questions"`
}

// VehicleStocktakeHistoryResponse data
type VehicleStocktakeHistoryResponse struct {
	VehicleStocktakeHistoryID int                                       `json:"VehicleStocktakeHistoryID"`
	VehicleStocktakeID        int                                       `json:"VehicleStocktakeID"`
	VehicleStocktakeName      string                                    `json:"VehicleStocktakeName"`
	StocktakeDate             *time.Time                                `json:"StocktakeDate"`
	Comment                   string                                    `json:"Comment"`
	ResourceID                int                                       `json:"ResourceID"`
	ResourceCode              string                                    `json:"ResourceCode"`
	ResourceName              string                                    `json:"ResourceName"`
	Questions                 []VehicleStocktakeQuestionHistoryResponse `json:"Questions"`
}

// TableName func
func (VehicleStocktakeHistory) TableName() string {
	return "vehiclestocktakeshistory"
}

// BeforeCreate func
func (object *VehicleStocktakeHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleStocktakeHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleStocktakeHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeHistoryID", JSONObject)
	if res != nil {
		object.VehicleStocktakeHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeID", JSONObject)
	if res != nil {
		object.VehicleStocktakeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("StocktakeDate", JSONObject)
	if res != nil {
		vStocktakeDate, sStocktakeDate := services.ConvertStringToDateTime(val)
		if sStocktakeDate == nil {
			object.StocktakeDate = &vStocktakeDate
		} else {
			if val == "" {
				object.StocktakeDate = nil
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			questions     = make([]VehicleStocktakeQuestionHistory, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						question VehicleStocktakeQuestionHistory
					)
					question.PassBodyJSONToModel(obj)
					for _, v := range object.Questions {
						if v.VehicleStocktakeQuestionHistoryID > 0 && question.VehicleStocktakeQuestionHistoryID == v.VehicleStocktakeQuestionHistoryID {
							question = v
							question.PassBodyJSONToModel(obj)
							break
						}
					}
					questions = append(questions, question)
				}
			}
		}
		object.Questions = questions
	}
	return
}
