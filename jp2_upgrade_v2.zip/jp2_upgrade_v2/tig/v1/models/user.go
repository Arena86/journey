package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ResponseTemplatesCopy str
type ResponseTemplatesCopy struct {
	UserID int
	Error  error
}

// UserResponse str
type UserResponse struct {
	UserID            int    `json:"UserID"`
	AccountKey        int    `json:"AccountKey"`
	FirstName         string `json:"FirstName"`
	LastName          string `json:"LastName"`
	Email             string `json:"Email"`
	LocationID        int    `json:"LocationID"`
	LocationName      string `json:"LocationName"`
	LocationGroupName string `json:"LocationGroupName"`
	SecurityGroupID   int    `json:"SecurityGroupID"`
	IsMaster          bool   `json:"IsMaster"`
	Language          string `json:"Language"`
	LoginPIN          int    `json:"LoginPIN"`
	UsePIN            bool   `json:"UsePIN"`
	PhoneNumber       string `json:"PhoneNumber"`
	CountryCode       string `json:"CountryCode"`
	DeviceID          string `json:"DeviceId"`
	DeviceName        string `json:"DeviceName"`
	DeviceModel       string `json:"DeviceModel"`
	DeviceVersion     string `json:"DeviceVersion"`
	AppVersion        string `json:"AppVersion"`
	IsManager         bool   `json:"IsManager"`
	AllowPanicReset   bool   `json:"AllowPanicReset"`
	Menus             []int  `json:"Menus"`
}

// ScheduleUserResponse str
type ScheduleUserResponse struct {
	UserID            int    `json:"UserID"`
	AccountKey        int    `json:"AccountKey"`
	FirstName         string `json:"FirstName"`
	LastName          string `json:"LastName"`
	Email             string `json:"Email"`
	LocationID        int    `json:"LocationID"`
	LocationName      string `json:"LocationName"`
	LocationGroupName string `json:"LocationGroupName"`
	PhoneNumber       string `json:"PhoneNumber"`
	CountryCode       string `json:"CountryCode"`
}

// UserChatResponse str
type UserChatResponse struct {
	UserID            int    `json:"UserID"`
	AccountKey        int    `json:"AccountKey"`
	FirstName         string `json:"FirstName"`
	LastName          string `json:"LastName"`
	Email             string `json:"Email"`
	LocationID        int    `json:"LocationID"`
	LocationName      string `json:"LocationName"`
	LocationGroupName string `json:"LocationGroupName"`
	PhoneNumber       string `json:"PhoneNumber"`
	CountryCode       string `json:"CountryCode"`
}

// User data
type User struct {
	UserID          int        `gorm:"column:UserID;primaryKey;autoIncrement;not null" json:"UserID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	AccountKey      int        `gorm:"column:AccountKey" json:"AccountKey"`
	FirstName       string     `gorm:"column:FirstName" json:"FirstName"`
	LastName        string     `gorm:"column:LastName" json:"LastName"`
	Email           string     `gorm:"column:Email" json:"Email" validate:"required,email"`
	LocationID      int        `gorm:"column:LocationID" json:"LocationID"`
	SecurityGroupID int        `gorm:"column:SecurityGroupID" json:"SecurityGroupID"`
	IsMaster        bool       `gorm:"column:IsMaster" json:"IsMaster"`
	Language        string     `gorm:"column:Language" json:"Language"`
	LoginPIN        int        `gorm:"column:LoginPIN" json:"LoginPIN"`
	UsePIN          bool       `gorm:"column:UsePIN" json:"UsePIN"`
	CountryCode     string     `gorm:"column:CountryCode" json:"CountryCode"`
	PhoneNumber     string     `gorm:"column:PhoneNumber" json:"PhoneNumber"`
	DeviceID        string     `gorm:"column:DeviceId" json:"DeviceId"`
	DeviceName      string     `gorm:"column:DeviceName" json:"DeviceName"`
	DeviceModel     string     `gorm:"column:DeviceModel" json:"DeviceModel"`
	DeviceVersion   string     `gorm:"column:DeviceVersion" json:"DeviceVersion"`
	AppVersion      string     `gorm:"column:AppVersion" json:"AppVersion"`
	IsManager       bool       `gorm:"column:IsManager" json:"IsManager"`
	AllowPanicReset bool       `gorm:"column:AllowPanicReset" json:"AllowPanicReset"`
}

// TableName func
func (User) TableName() string {
	return "users"
}

// BeforeCreate func
func (object *User) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *User) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *User) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		vUserID, sUserID := strconv.Atoi(val)
		if sUserID == nil {
			object.UserID = vUserID
		}
	}
	val, res = services.ConvertJSONValueToVariable("AccountKey", JSONObject)
	if res != nil {
		vAccountKey, sAccountKey := strconv.Atoi(val)
		if sAccountKey == nil {
			object.AccountKey = vAccountKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("FirstName", JSONObject)
	if res != nil {
		object.FirstName = val
	}
	val, res = services.ConvertJSONValueToVariable("LastName", JSONObject)
	if res != nil {
		object.LastName = val
	}
	val, res = services.ConvertJSONValueToVariable("Email", JSONObject)
	if res != nil {
		object.Email = val
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		vLocationID, sLocationID := strconv.Atoi(val)
		if sLocationID == nil {
			object.LocationID = vLocationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("SecurityGroupID", JSONObject)
	if res != nil {
		vSecurityGroupID, sSecurityGroupID := strconv.Atoi(val)
		if sSecurityGroupID == nil {
			object.SecurityGroupID = vSecurityGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsMaster", JSONObject)
	if res != nil {
		object.IsMaster, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Language", JSONObject)
	if res != nil {
		object.Language = val
	}
	val, res = services.ConvertJSONValueToVariable("LoginPIN", JSONObject)
	if res != nil {
		object.LoginPIN, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UsePIN", JSONObject)
	if res != nil {
		object.UsePIN, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("PhoneNumber", JSONObject)
	if res != nil {
		object.PhoneNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("CountryCode", JSONObject)
	if res != nil {
		object.CountryCode = val
	}

	val, res = services.ConvertJSONValueToVariable("DeviceId", JSONObject)
	if res != nil {
		object.DeviceID = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceName", JSONObject)
	if res != nil {
		object.DeviceName = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceModel", JSONObject)
	if res != nil {
		object.DeviceModel = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceVersion", JSONObject)
	if res != nil {
		object.DeviceVersion = val
	}
	val, res = services.ConvertJSONValueToVariable("AppVersion", JSONObject)
	if res != nil {
		object.AppVersion = val
	}
	val, res = services.ConvertJSONValueToVariable("IsManager", JSONObject)
	if res != nil {
		object.IsManager, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("AllowPanicReset", JSONObject)
	if res != nil {
		object.AllowPanicReset, _ = strconv.ParseBool(val)
	}
	return
}
