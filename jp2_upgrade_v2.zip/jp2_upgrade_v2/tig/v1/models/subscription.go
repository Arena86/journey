package models

import "time"

// Subscription data
type SubscriptionJSON struct {
	SubscriptionKey                 int        `json:"SubscriptionKey"`
	PlanKey                         int        `json:"PlanKey"`
	CompanyID                       string     `json:"CompanyID"`
	ExpiryDate                      *time.Time `json:"ExpiryDate"`
	Platform                        float64    `json:"Platform"`
	MaxUsers                        int        `json:"MaxUsers"`
	MaxDynamicForms                 int        `json:"MaxDynamicForms"`
	MaxJobs                         int        `json:"MaxJobs"`
	IsLiveChat                      bool       `json:"IsLiveChat"`
	IsLiveView                      bool       `json:"IsLiveView"`
	IsReplayRoutes                  bool       `json:"IsReplayRoutes"`
	IsNotifications                 bool       `json:"IsNotifications"`
	IsAuthorizations                bool       `json:"IsAuthorizations"`
	IsReportDesigner                bool       `json:"IsReportDesigner"`
	ResourceQuantity                float64    `json:"ResourceQuantity"`
	PhysicalDeviceQuantity          float64    `json:"PhysicalDeviceQuantity"`
	AdditionalDeviceLicenseQuantity float64    `json:"AdditionalDeviceLicenseQuantity"`
	IsXeroIntegration               bool       `json:"IsXeroIntegration"`
	IsMicrosoftDynamics             bool       `json:"IsMicrosoftDynamics"`
	IsSmartScheduling               bool       `json:"IsSmartScheduling"`
	PlatformAmount                  float64    `json:"PlatformAmount"`
	MaxDynamicFormsAmount           float64    `json:"MaxDynamicFormsAmount"`
	MaxUsersAmount                  float64    `json:"MaxUsersAmount"`
	MaxJobsAmount                   float64    `json:"MaxJobsAmount"`
	LiveChatAmount                  float64    `json:"LiveChatAmount"`
	LiveViewAmount                  float64    `json:"LiveViewAmount"`
	ReplayRoutesAmount              float64    `json:"ReplayRoutesAmount"`
	NotificationsAmount             float64    `json:"NotificationsAmount"`
	AuthorizationsAmount            float64    `json:"AuthorizationsAmount"`
	ReportDesignerAmount            float64    `json:"ReportDesignerAmount"`
	ResourceAmount                  float64    `json:"ResourceAmount"`
	PhysicalDeviceAmount            float64    `json:"PhysicalDeviceAmount"`
	AdditionalDeviceLicenseAmount   float64    `json:"AdditionalDeviceLicenseAmount"`
	XeroIntegrationAmount           float64    `json:"XeroIntegrationAmount"`
	MicrosoftDynamicsAmount         float64    `json:"MicrosoftDynamicsAmount"`
	SmartSchedulingAmount           float64    `json:"SmartSchedulingAmount"`
	SmartSchedulingQuantity         float64    `json:"SmartSchedulingQuantity"`
}

// LicenseVerificationJSON data
type LicenseVerificationJSON struct {
	MaxUsers                        int     `json:"MaxUsers"`
	MaxDynamicForms                 int     `json:"MaxDynamicForms"`
	MaxJobs                         int     `json:"MaxJobs"`
	ResourceQuantity                float64 `json:"ResourceQuantity"`
	IsLiveChat                      bool    `json:"IsLiveChat"`
	IsLiveView                      bool    `json:"IsLiveView"`
	IsReplayRoutes                  bool    `json:"IsReplayRoutes"`
	IsNotifications                 bool    `json:"IsNotifications"`
	IsAuthorizations                bool    `json:"IsAuthorizations"`
	IsReportDesigner                bool    `json:"IsReportDesigner"`
	AdditionalDeviceLicenseQuantity float64 `json:"AdditionalDeviceLicenseQuantity"`
	IsXeroIntegration               bool    `json:"IsXeroIntegration"`
	IsMicrosoftDynamics             bool    `json:"IsMicrosoftDynamics"`
	IsSmartScheduling               bool    `json:"IsSmartScheduling"`
	SmartSchedulingQuantity         float64 `json:"SmartSchedulingQuantity"`
}
