package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DynamicForm data
type DynamicForm struct {
	DynamicFormID     int        `gorm:"column:DynamicFormID;primaryKey;not null"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived        bool       `gorm:"column:IsArchived"`
	FormName          string     `gorm:"column:FormName"`
	DesignP           *string    `gorm:"column:DesignP"`
	DesignL           *string    `gorm:"column:DesignL"`
	LastPublishedDate *time.Time `gorm:"column:LastPublishedDate" json:"LastPublishedDate"`
	FormStatus        string     `gorm:"column:FormStatus" json:"FormStatus"`
	Is4DPriceForm     bool       `gorm:"column:Is4DPriceForm" json:"Is4DPriceForm"`
	IsBreakForm       bool       `gorm:"column:IsBreakForm" json:"IsBreakForm"`
}

// DynamicFormResponse data
type DynamicFormResponse struct {
	DynamicFormID     int        `json:"DynamicFormID"`
	FormName          string     `json:"FormName"`
	DesignP           *string    `json:"DesignP"`
	DesignL           *string    `json:"DesignL"`
	LastPublishedDate *time.Time `json:"LastPublishedDate"`
	FormStatus        string     `json:"FormStatus"`
	Is4DPriceForm     bool       `json:"Is4DPriceForm"`
	IsBreakForm       bool       `json:"IsBreakForm"`
}

// TableName func
func (DynamicForm) TableName() string {
	return "dynamicforms"
}

// BeforeCreate func
func (object *DynamicForm) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DynamicForm) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DynamicForm) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DynamicFormID", JSONObject)
	if res != nil {
		object.DynamicFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormName", JSONObject)
	if res != nil {
		object.FormName = val
	}
	val, res = services.ConvertJSONValueToVariable("FormStatus", JSONObject)
	if res != nil {
		object.FormStatus = val
	}
	val, res = services.ConvertJSONValueToVariable("DesignP", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignP = &valJSON
		} else {
			object.DesignP = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("DesignL", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignL = &valJSON
		} else {
			object.DesignL = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Is4DPriceForm", JSONObject)
	if res != nil {
		object.Is4DPriceForm, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsBreakForm", JSONObject)
	if res != nil {
		object.IsBreakForm, _ = strconv.ParseBool(val)
	}
	return
}

// ConvertDraftToDynamicFrom func
func (object *DynamicForm) ConvertDraftToDynamicFrom(draft DraftDynamicForm) {
	object.CreatedBy = draft.CreatedBy
	object.ModifiedBy = draft.ModifiedBy
	object.DynamicFormID = draft.DraftDynamicFormID
	object.FormName = draft.FormName
	object.FormStatus = draft.FormStatus
	object.DesignP = draft.DesignP
	object.DesignL = draft.DesignL
	object.Is4DPriceForm = draft.Is4DPriceForm
	object.IsBreakForm = draft.IsBreakForm
	return
}

// RevertDraftDynamicForm func
func (object *DraftDynamicForm) RevertDraftFromDynamicForm(dynamicForm DynamicForm) {
	object.DesignP = dynamicForm.DesignP
	object.DesignL = dynamicForm.DesignL
	return
}
