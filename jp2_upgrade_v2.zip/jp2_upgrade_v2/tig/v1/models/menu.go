package models

import (
	"jpapi/tig/v1/services"
	"strconv"
)

// BySortResponseMenu str
type BySortResponseMenu []ResponseMenu

func (a BySortResponseMenu) Len() int           { return len(a) }
func (a BySortResponseMenu) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a BySortResponseMenu) Less(i, j int) bool { return a[i].Sort < a[j].Sort }

// ResponseMenu str
type ResponseMenu struct {
	ID       int            `json:"id"`
	Caption  string         `json:"caption"`
	Path     string         `json:"path"`
	Icon     string         `json:"icon"`
	IsChild  bool           `json:"isChild"`
	ParentID int            `json:"parentId"`
	Sort     int            `json:"sort"`
	Children []ResponseMenu `json:"children"`
}

// ChildMenu str
type ChildMenu struct {
	ID       int    `json:"id"`
	Path     string `json:"path"`
	Caption  string `json:"caption"`
	Icon     string `json:"icon"`
	IsChild  bool   `json:"isChild"`
	ParentID int    `json:"parentId"`
	Sort     int    `json:"sort"`
}

// Menu data
type Menu struct {
	MenuKey  int    `gorm:"column:MenuKey;primaryKey;not null" json:"MenuKey"`
	Path     string `gorm:"column:Path;type:nvarchar(255)"`
	Caption  string `gorm:"column:Caption;type:nvarchar(255)"`
	Icon     string `gorm:"column:Icon;type:nvarchar(255)"`
	IsChild  bool   `gorm:"column:IsChild;type:tinyint(4)"`
	ParentID int    `gorm:"column:ParentId;type:int"`
	Sort     int    `gorm:"column:Sort;type:int(11)"`
}

// TableName func
func (Menu) TableName() string {
	return "menus"
}

// PassBodyJSONToModel func
func (u *Menu) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("MenuKey", JSONObject)
	if res != nil {
		vMenuID, sMenuID := strconv.Atoi(val)
		if sMenuID == nil {
			u.MenuKey = vMenuID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Path", JSONObject)
	if res != nil {
		u.Path = val
	}
	val, res = services.ConvertJSONValueToVariable("Caption", JSONObject)
	if res != nil {
		u.Caption = val
	}
	val, res = services.ConvertJSONValueToVariable("Icon", JSONObject)
	if res != nil {
		u.Icon = val
	}
	return
}
