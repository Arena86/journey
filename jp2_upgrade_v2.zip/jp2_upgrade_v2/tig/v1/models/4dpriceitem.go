package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FourDPriceItem data
type FourDPriceItem struct {
	FourDPriceItemID int        `gorm:"column:4DPriceItemID;primaryKey;not null" json:"FourDPriceItemID"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ItemID           int        `gorm:"column:ItemID" json:"ItemID"`
	FourDPriceID     int        `gorm:"column:4DPriceID" json:"FourDPriceID"`
}

//FourDPriceItemResponse data
type FourDPriceItemResponse struct {
	FourDPriceItemID int    `json:"FourDPriceItemID"`
	ItemID           int    `json:"ItemID"`
	ItemCode         string `json:"ItemCode"`
	ItemName         string `json:"ItemName"`
	ItemDescription  string `json:"ItemDescription"`
	FourDPriceID     int    `json:"FourDPriceID"`
}

// TableName func
func (FourDPriceItem) TableName() string {
	return "4dpriceitems"
}

// BeforeCreate func
func (object *FourDPriceItem) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FourDPriceItem) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FourDPriceItem) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FourDPriceItemID", JSONObject)
	if res != nil {
		object.FourDPriceItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		object.ItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceID", JSONObject)
	if res != nil {
		object.FourDPriceID, _ = strconv.Atoi(val)
	}
	return
}
