package models

import (
	"time"

	"gorm.io/gorm"
)

// JobDynamicForm data
type JobDynamicForm struct {
	JobDynamicFormID int        `gorm:"column:JobDynamicFormID;primaryKey;not null"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived"`
	DynamicFormID    int        `gorm:"column:DynamicFormID"`
	FormName         string     `gorm:"column:FormName"`
	DesignP          *string    `gorm:"column:DesignP"`
	DesignL          *string    `gorm:"column:DesignL"`
}

// JobDynamicFormResponse data
type JobDynamicFormResponse struct {
	JobDynamicFormID int     `json:"JobDynamicFormID"`
	DynamicFormID    int     `json:"DynamicFormID"`
	FormName         string  `json:"FormName"`
	DesignP          *string `json:"DesignP"`
	DesignL          *string `json:"DesignL"`
}

// TableName func
func (JobDynamicForm) TableName() string {
	return "jobdynamicforms"
}

// BeforeCreate func
func (object *JobDynamicForm) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobDynamicForm) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobDynamicForm) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	/* var (
		res interface{}
		val string
	) */

	return
}
