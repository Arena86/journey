package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Reason data
type Reason struct {
	ReasonID     int        `gorm:"column:ReasonID;primaryKey;autoIncrement;not null"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ReasonEntity int        `gorm:"column:ReasonEntity" json:"ReasonEntity"`
	Reason       string     `gorm:"column:Reason" json:"Reason"`
	IsVisible    bool       `gorm:"column:IsVisible" json:"IsVisible"`
}

// ReasonResponse data
type ReasonResponse struct {
	ReasonID         int    `json:"ReasonID"`
	ReasonEntity     int    `json:"ReasonEntity"`
	ReasonEntityName string `json:"ReasonEntityName"`
	Reason           string `json:"Reason"`
}

// TableName func
func (Reason) TableName() string {
	return "reasons"
}

// BeforeCreate func
func (object *Reason) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Reason) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Reason) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ReasonID", JSONObject)
	if res != nil {
		object.ReasonID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Reason", JSONObject)
	if res != nil {
		object.Reason = val
	}
	val, res = services.ConvertJSONValueToVariable("ReasonEntity", JSONObject)
	if res != nil {
		object.ReasonEntity, _ = strconv.Atoi(val)
	}
	object.IsVisible = true
	return
}
