package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AdditionalUser data
type AdditionalUser struct {
	AdditionaluserID int        `gorm:"column:AdditionaluserID;primaryKey;autoIncrement;not null" json:"AdditionaluserID"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ScheduleID       int        `gorm:"column:ScheduleID" validate:"required" json:"ScheduleID"`
	UserID           int        `gorm:"column:UserID" validate:"required" json:"UserID"`
}

// AdditionalUserResponse data
type AdditionalUserResponse struct {
	UserID       int    `json:"UserID"`
	FirstName    string `json:"FirstName"`
	LastName     string `json:"LastName"`
	LocationName string `json:"LocationName"`
	Email        string `json:"Email"`
	PhoneNumber  string `json:"PhoneNumber"`
}

// TableName func
func (AdditionalUser) TableName() string {
	return "additionalusers"
}

// BeforeCreate func
func (object *AdditionalUser) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AdditionalUser) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AdditionalUser) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AdditionaluserID", JSONObject)
	if res != nil {
		object.AdditionaluserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleID", JSONObject)
	if res != nil {
		object.ScheduleID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		object.UserID, _ = strconv.Atoi(val)
	}
	return
}
