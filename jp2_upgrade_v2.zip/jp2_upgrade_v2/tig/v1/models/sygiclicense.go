package models

// SygicLicense str
type SygicLicense struct {
	SygicLicenseKey     int                  `json:"SygicLicenseKey"`
	APIURL              string               `json:"APIURL"`
	DownloadURL         string               `json:"DownloadURL"`
	APIKey              string               `json:"APIKey"`
	IsCurrentSubscriber bool                 `json:"IsCurrentSubscriber"`
	SygicLicenseDetails []SygicLicenseDetail `json:"SygicLicenseDetails"`
}

// SygicLicenseDetail data
type SygicLicenseDetail struct {
	SygicLicenseDetailKey int    `json:"SygicLicenseDetailKey"`
	SygicLicenseKey       int    `json:"SygicLicenseKey"`
	ProductID             string `json:"ProductId"`
	PurchasePeriod        string `json:"PurchasePeriod"`
	CountryCode           string `json:"CountryCode"`
}
