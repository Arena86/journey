package models

import "time"

// TomTomConfig str
type TomTomConfig struct {
	TomTomKey  int    `json:"TomTomKey"`
	APIBaseURL string `json:"APIBaseURL"`
	APIKey     string `json:"APIKey"`
}

// TomTomResponse str
type TomTomResponse struct {
	FormatVersion string        `json:"formatVersion"`
	Routes        []TomTomRoute `json:"routes"`
}

// TomTomResponse str
type TomTomResponseError struct {
	FormatVersion string `json:"formatVersion"`
	Error         struct {
		Description string `json:"description"`
	} `json:"error"`
	DetailedError struct {
		Message string `json:"message"`
		Code    string `json:"code"`
	} `json:"detailedError"`
}
type TomTomRoute struct {
	Latitude string  `json:"latitude"`
	Summary  Summary `json:"summary"`
	Legs     []leg   `json:"legs"`
}
type Summary struct {
	LengthInMeters                 int       `json:"lengthInMeters"`
	TravelTimeInSeconds            int       `json:"travelTimeInSeconds"`
	TrafficDelayInSeconds          int       `json:"trafficDelayInSeconds"`
	TrafficLengthInMeters          int       `json:"trafficLengthInMeters"`
	DepartureTime                  time.Time `json:"departureTime"`
	TravelTimeInSecoarrivalTimends time.Time `json:"arrivalTime"`
}
type leg struct {
	Summary Summary               `json:"summary"`
	Points  []TomTomResponsePoint `json:"points"`
}
type TomTomResponsePoint struct {
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}

type GeocodeResponse struct {
	Results []struct {
		Position struct {
			Lat float64 `json:"lat"`
			Lon float64 `json:"lon"`
		} `json:"position"`
	} `json:"results"`
}
