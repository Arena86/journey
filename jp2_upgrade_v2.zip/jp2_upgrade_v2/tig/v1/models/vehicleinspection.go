package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleInspection data
type VehicleInspection struct {
	VehicleInspectionID   int                              `gorm:"column:VehicleInspectionID;primaryKey;autoIncrement;not null" json:"VehicleInspectionID"`
	CreatedBy             int                              `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate           *time.Time                       `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy            int                              `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate          *time.Time                       `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted             bool                             `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit               bool                             `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived            bool                             `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleInspectionName string                           `gorm:"column:VehicleInspectionName" json:"VehicleInspectionName"`
	IsOdometerVisible     bool                             `gorm:"column:IsOdometerVisible" json:"IsOdometerVisible"`
	IsOdometerMandatory   bool                             `gorm:"column:IsOdometerMandatory" json:"IsOdometerMandatory"`
	IsRegoVisible         bool                             `gorm:"column:IsRegoVisible" json:"IsRegoVisible"`
	IsRegoMandatory       bool                             `gorm:"column:IsRegoMandatory" json:"IsRegoMandatory"`
	IsCommentVisible      bool                             `gorm:"column:IsCommentVisible" json:"IsCommentVisible"`
	IsCommentMandatory    bool                             `gorm:"column:IsCommentMandatory" json:"IsCommentMandatory"`
	QuestionGroups        []VehicleInspectionQuestionGroup `gorm:"foreignKey:VehicleInspectionID;references:VehicleInspectionID" json:"QuestionGroups"`
}

// VehicleInspectionResponse data
type VehicleInspectionResponse struct {
	VehicleInspectionID   int                                      `json:"VehicleInspectionID"`
	VehicleInspectionName string                                   `json:"VehicleInspectionName"`
	IsOdometerVisible     bool                                     `json:"IsOdometerVisible"`
	IsOdometerMandatory   bool                                     `json:"IsOdometerMandatory"`
	IsRegoVisible         bool                                     `json:"IsRegoVisible"`
	IsRegoMandatory       bool                                     `json:"IsRegoMandatory"`
	IsCommentVisible      bool                                     `json:"IsCommentVisible"`
	IsCommentMandatory    bool                                     `json:"IsCommentMandatory"`
	QuestionGroups        []VehicleInspectionQuestionGroupResponse `json:"QuestionGroups"`
	Questions             []VehicleInspectionQuestionResponse      `json:"Questions"`
	HistoryCount          int                                      `json:"HistoryCount"`
}

// TableName func
func (VehicleInspection) TableName() string {
	return "vehicleinspections"
}

// BeforeCreate func
func (object *VehicleInspection) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleInspection) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleInspection) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionID", JSONObject)
	if res != nil {
		object.VehicleInspectionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionName", JSONObject)
	if res != nil {
		object.VehicleInspectionName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsOdometerVisible", JSONObject)
	if res != nil {
		object.IsOdometerVisible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsOdometerMandatory", JSONObject)
	if res != nil {
		object.IsOdometerMandatory, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsRegoVisible", JSONObject)
	if res != nil {
		object.IsRegoVisible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsRegoMandatory", JSONObject)
	if res != nil {
		object.IsRegoMandatory, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCommentVisible", JSONObject)
	if res != nil {
		object.IsCommentVisible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCommentMandatory", JSONObject)
	if res != nil {
		object.IsCommentMandatory, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("QuestionGroups", JSONObject)
	if res != nil {
		var (
			details       []VehicleInspectionQuestionGroup
			objectDetails []map[string]interface{}
		)
		details = make([]VehicleInspectionQuestionGroup, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail VehicleInspectionQuestionGroup
					)
					detail.PassBodyJSONToModel(obj)
					details = append(details, detail)
				}
			}
		}
		object.QuestionGroups = details
	}

	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail VehicleInspectionQuestion
					)
					detail.PassBodyJSONToModel(obj)
					for i, questionGroup := range object.QuestionGroups {
						if questionGroup.InspectionQuestionGroupID == detail.InspectionQuestionGroupID {
							object.QuestionGroups[i].Questions = append(object.QuestionGroups[i].Questions, detail)
						}
					}
				}
			}
		}
	}
	return
}
