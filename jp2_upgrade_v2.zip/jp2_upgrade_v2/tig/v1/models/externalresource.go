package models

import "time"

// ExternalResourceSchedule str
type ExternalResourceSchedule struct {
	ScheduleID         int
	ScheduleStartDate  time.Time
	ScheduleEndDate    time.Time
	JobID              int
	JobNumber          string
	JobType            int
	JobTypeName        string
	JobTypeIcon        string
	JobStatus          int
	JobStatusName      string
	JobStatusIcon      string
	CompanyName        string
	JobTaskID          int
	JobTaskJobType     int
	JobTaskJobTypeName string
	JobTaskJobTypeIcon string
	NavigationAddress  string
}

// ExternalResource str
type ExternalResource struct {
	ResourceID       int
	ResourceCode     string
	ResourceName     string
	ResourceMode     int
	ResourceModeName string
	ResourceModeIcon string
	ResourceType     int
	ResourceTypeName string
	ResourceTypeIcon string
	LocationID       int
	LocationName     string
	Schedules        []ExternalResourceSchedule
}
