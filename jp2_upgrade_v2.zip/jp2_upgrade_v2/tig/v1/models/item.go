package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Item data
type Item struct {
	ItemID                            int           `gorm:"column:ItemID;primaryKey;autoIncrement;not null"`
	CreatedBy                         *int          `gorm:"column:CreatedBy"`
	CreatedDate                       *time.Time    `gorm:"column:CreatedDate"`
	ModifiedBy                        *int          `gorm:"column:ModifiedBy"`
	ModifiedDate                      *time.Time    `gorm:"column:ModifiedDate"`
	IsDeleted                         bool          `gorm:"column:IsDeleted"`
	IsAudit                           bool          `gorm:"column:IsAudit"`
	IsArchived                        bool          `gorm:"column:IsArchived"`
	ItemGroupID                       *int          `gorm:"column:ItemGroupID"`
	Code                              string        `gorm:"column:Code;type:varchar(255)"`
	Name                              string        `gorm:"column:Name;type:varchar(255)"`
	Description                       string        `gorm:"column:Description;type:varchar(255)"`
	UnitPrice                         float64       `gorm:"column:UnitPrice"`
	TaxID                             int           `gorm:"column:TaxID;type"`
	IsTrackedAsInventory              bool          `gorm:"column:IsTrackedAsInventory"`
	QuantityOnHand                    float64       `gorm:"column:QuantityOnHand"`
	ErpKey                            string        `gorm:"column:ErpKey"`
	Cost                              float64       `gorm:"column:Cost"`
	ItemType                          int           `gorm:"column:ItemType"`
	AutomaticallyIncludeInNewDocument bool          `gorm:"column:AutomaticallyIncludeInNewDocument"`
	IsHidden                          bool          `gorm:"column:IsHidden"`
	RelatedItems                      []RelatedItem `gorm:"foreignKey:ItemID;references:ItemID" json:"RelatedItems"`
	ItemPurchaseAccountCode           string        `gorm:"column:ItemPurchaseAccountCode"`
	ItemSaleAccountCode               string        `gorm:"column:ItemSaleAccountCode"`
	InventoryAssetAccountCode         string        `gorm:"column:InventoryAssetAccountCode"`
	IsIntegrationPending              bool          `gorm:"column:IsIntegrationPending"`
	IntegrationError                  string        `gorm:"column:IntegrationError"`
	FourDPriceDynamicFormID           *int          `gorm:"column:4DPriceDynamicFormID"`
	ServiceTimeInMinutes              int           `gorm:"column:ServiceTimeInMinutes" json:"ServiceTimeInMinutes"`
}

// ItemResponse data
type ItemResponse struct {
	ItemID                            int                    `json:"ItemID"`
	ItemGroupID                       *int                   `json:"ItemGroupID"`
	ItemGroupCode                     string                 `json:"ItemGroupCode"`
	ItemGroupName                     string                 `json:"ItemGroupName"`
	Code                              string                 `json:"Code"`
	Name                              string                 `json:"Name"`
	Description                       string                 `json:"Description"`
	UnitPrice                         float64                `json:"UnitPrice"`
	TaxID                             *int                   `json:"TaxID"`
	TaxType                           string                 `json:"TaxType"`
	TaxName                           string                 `json:"TaxName"`
	TaxRate                           float64                `json:"TaxRate"`
	IsTrackedAsInventory              bool                   `json:"IsTrackedAsInventory"`
	QuantityOnHand                    float64                `json:"QuantityOnHand"`
	ErpKey                            string                 `json:"ErpKey"`
	Cost                              float64                `json:"Cost"`
	ItemType                          int                    `json:"ItemType"`
	ItemTypeName                      string                 `json:"ItemTypeName"`
	AutomaticallyIncludeInNewDocument bool                   `json:"AutomaticallyIncludeInNewDocument"`
	IsHidden                          bool                   `json:"IsHidden"`
	UDFs                              []UDFResponse          `json:"UDFs"`
	UDF                               map[string]interface{} `json:"UDF"`
	RelatedItems                      []RelatedItemResponse  `json:"RelatedItems"`
	ItemPurchaseAccountCode           string                 `json:"ItemPurchaseAccountCode"`
	ItemSaleAccountCode               string                 `json:"ItemSaleAccountCode"`
	InventoryAssetAccountCode         string                 `json:"InventoryAssetAccountCode"`
	SurchargeParentItemID             int                    `json:"SurchargeParentItemID"`
	JobTaskType                       int                    `json:"JobTaskType"`
	FourDPriceDynamicFormID           *int                   `json:"FourDPriceDynamicFormID"`
	ServiceTimeInMinutes              int                    `json:"ServiceTimeInMinutes"`
}

type InspectionItemResponse struct {
	ItemID                  int    `json:"ItemID"`
	Code                    string `json:"Code"`
	Name                    string `json:"Name"`
	Description             string `json:"Description"`
	ItemType                int    `json:"ItemType"`
	SurchargeParentItemID   int    `json:"SurchargeParentItemID"`
	Key                     string `json:"Key"`
	FourDPriceDynamicFormID *int   `json:"FourDPriceDynamicFormID"`
	ServiceTimeInMinutes    int    `json:"ServiceTimeInMinutes"`
}
type InspectionItemsResponse struct {
	ItemID                  int                            `json:"ItemID"`
	Code                    string                         `json:"Code"`
	Name                    string                         `json:"Name"`
	Description             string                         `json:"Description"`
	ItemType                int                            `json:"ItemType"`
	SurchargeParentItemID   int                            `json:"SurchargeParentItemID"`
	Key                     string                         `json:"Key"`
	InspectionJob4DPrices   []InspectionFourDPriceResponse `json:"Job4DPrices"`
	FourDPriceDynamicFormID *int                           `json:"FourDPriceDynamicFormID"`
	ServiceTimeInMinutes    int                            `json:"ServiceTimeInMinutes"`
}

// HiddenItemPOST str
type HiddenItemPOST struct {
	ItemIDs []int `json:"ItemIDs"`
}

// TableName func
func (Item) TableName() string {
	return "items"
}

// BeforeCreate func
func (object *Item) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Item) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Item) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		object.ItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Code", JSONObject)
	if res != nil {
		object.Code = val
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}
	val, res = services.ConvertJSONValueToVariable("UnitPrice", JSONObject)
	if res != nil {
		vUnitPrice, sUnitPrice := strconv.ParseFloat(val, 64)
		if sUnitPrice == nil {
			object.UnitPrice = vUnitPrice
		}
	}
	val, res = services.ConvertJSONValueToVariable("TaxID", JSONObject)
	if res != nil {
		object.TaxID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsTrackedAsInventory", JSONObject)
	if res != nil {
		vIsTrackedAsInventory, sIsTrackedAsInventory := strconv.ParseBool(val)
		if sIsTrackedAsInventory == nil {
			object.IsTrackedAsInventory = vIsTrackedAsInventory
		}
	}
	val, res = services.ConvertJSONValueToVariable("QuantityOnHand", JSONObject)
	if res != nil {
		vQuantityOnHand, sQuantityOnHand := strconv.ParseFloat(val, 64)
		if sQuantityOnHand == nil {
			object.QuantityOnHand = vQuantityOnHand
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsDelete", JSONObject)
	if res != nil {
		vIsDeleted, sIsDeleted := strconv.ParseBool(val)
		if sIsDeleted == nil {
			object.IsDeleted = vIsDeleted
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsAudit", JSONObject)
	if res != nil {
		vIsAudit, sIsAudit := strconv.ParseBool(val)
		if sIsAudit == nil {
			object.IsAudit = vIsAudit
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("ItemGroupID", JSONObject)
	if res != nil {
		vItemGroupID, sItemGroupID := strconv.Atoi(val)
		if sItemGroupID == nil {
			object.ItemGroupID = &vItemGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ErpKey", JSONObject)
	if res != nil {
		object.ErpKey = val
	}
	val, res = services.ConvertJSONValueToVariable("Cost", JSONObject)
	if res != nil {
		object.Cost, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("ItemType", JSONObject)
	if res != nil {
		object.ItemType, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("AutomaticallyIncludeInNewDocument", JSONObject)
	if res != nil {
		vAutomaticallyIncludeInNewDocument, sAutomaticallyIncludeInNewDocument := strconv.ParseBool(val)
		if sAutomaticallyIncludeInNewDocument == nil {
			object.AutomaticallyIncludeInNewDocument = vAutomaticallyIncludeInNewDocument
		}
	}
	val, res = services.ConvertJSONValueToVariable("RelatedItems", JSONObject)
	if res != nil {
		var (
			objs    []RelatedItem
			objects []map[string]interface{}
		)
		objs = make([]RelatedItem, 0)
		objsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objsJSON, &objects)
			if len(objects) > 0 {
				for _, mObj := range objects {
					var (
						obj RelatedItem
					)
					obj.PassBodyJSONToModel(mObj)
					objs = append(objs, obj)
				}
			}
		}
		object.RelatedItems = objs
	}
	val, res = services.ConvertJSONValueToVariable("ItemPurchaseAccountCode", JSONObject)
	if res != nil {
		object.ItemPurchaseAccountCode = val
	}
	val, res = services.ConvertJSONValueToVariable("ItemSaleAccountCode", JSONObject)
	if res != nil {
		object.ItemSaleAccountCode = val
	}
	val, res = services.ConvertJSONValueToVariable("InventoryAssetAccountCode", JSONObject)
	if res != nil {
		object.InventoryAssetAccountCode = val
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceDynamicFormID", JSONObject)
	if res != nil {
		vFourDPriceDynamicFormID, sFourDPriceDynamicFormID := strconv.Atoi(val)
		if sFourDPriceDynamicFormID == nil {
			object.FourDPriceDynamicFormID = &vFourDPriceDynamicFormID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServiceTimeInMinutes", JSONObject)
	if res != nil {
		object.ServiceTimeInMinutes, _ = strconv.Atoi(val)
	}
	return
}
