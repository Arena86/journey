package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PaymentDetail data
type PaymentDetail struct {
	PaymentDetailID int        `gorm:"column:PaymentDetailID;primaryKey;autoIncrement;not null" json:"PaymentDetailID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	PaymentID       int        `gorm:"column:PaymentID" json:"PaymentID"`
	PaymentMethod   int        `gorm:"column:PaymentMethod" json:"PaymentMethod"`
	Amount          float64    `gorm:"column:Amount" json:"Amount"`
	OnlinePaymentID string     `gorm:"column:OnlinePaymentID" json:"OnlinePaymentID"`
	AssignedInvoice bool       `gorm:"column:AssignedInvoice" json:"AssignedInvoice"`
}

// PaymentDetailResponse data
type PaymentDetailResponse struct {
	PaymentDetailID   int     `json:"PaymentDetailID"`
	PaymentID         int     `json:"PaymentID"`
	PaymentMethod     int     `json:"PaymentMethod"`
	PaymentMethodName string  `json:"PaymentMethodName"`
	Amount            float64 `json:"Amount"`
	OnlinePaymentID   string  `json:"OnlinePaymentID"`
	AssignedInvoice   bool    `json:"AssignedInvoice"`
}

// TableName func
func (PaymentDetail) TableName() string {
	return "paymentdetails"
}

// BeforeCreate func
func (object *PaymentDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PaymentDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PaymentDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PaymentDetailID", JSONObject)
	if res != nil {
		object.PaymentDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaymentID", JSONObject)
	if res != nil {
		object.PaymentID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaymentMethod", JSONObject)
	if res != nil {
		object.PaymentMethod, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Amount", JSONObject)
	if res != nil {
		object.Amount, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("OnlinePaymentID", JSONObject)
	if res != nil {
		object.OnlinePaymentID = val
	}
	val, res = services.ConvertJSONValueToVariable("AssignedInvoice", JSONObject)
	if res != nil {
		object.AssignedInvoice, _ = strconv.ParseBool(val)
	}
	return
}
