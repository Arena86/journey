package models

import "time"

// JSONInProgressJob str
type JSONInProgressJob struct {
	JobID        int    `json:"JobID"`
	Reschedule   bool   `json:"Reschedule"`
	Complete     bool   `json:"Complete"`
	ReasonID     int    `json:"ReasonID"`
	Comment      string `json:"Comment"`
	CompleteDate string `json:"CompleteDate"`
	SendSMS      bool   `json:"SendSMS"`
	Invoice      bool   `json:"Invoice"`
	CompleteJob  bool   `json:"CompleteJob"`
	JobTaskID    int    `json:"JobTaskID"`
}

// InProgressJobResponse str
type InProgressJobResponse struct {
	JobID       int                          `json:"JobID"`
	JobNumber   string                       `json:"JobNumber"`
	Status      int                          `json:"Status"`
	StatusName  string                       `json:"StatusName"`
	StatusIcon  string                       `json:"StatusIcon"`
	JobDate     *time.Time                   `json:"JobDate"`
	JobType     int                          `json:"JobType"`
	JobTypeName string                       `json:"JobTypeName"`
	JobTypeIcon string                       `json:"JobTypeIcon"`
	CompanyName string                       `json:"CompanyName"`
	FirstName   string                       `json:"FirstName"`
	LastName    string                       `json:"LastName"`
	LocationID  int                          `json:"LocationID"`
	JobTasks    *[]JobTaskForJobListResponse `json:"jobTasks,omitempty"`
	JobTotal    JobTotalResponse             `json:"jobTotals"`
}

// JobIDList str
type JobIDList struct {
	JobID []int `json:"JobID"`
}

// JobInProgress str
type JobInProgress struct {
	JobID              int            `json:"JobID"`
	JobNumber          string         `json:"JobNumber"`
	ScheduleID         int            `json:"ScheduleID"`
	ScheduleStartDate  time.Time      `json:"ScheduleStartDate"`
	JobTaskID          int            `json:"JobTaskID"`
	InProgressStatus   string         `json:"InProgressStatus"`
	JobTaskStatus      string         `json:"JobTaskStatus"`
	JobStatus          int            `json:"JobStatus"`
	JobStatusName      string         `json:"JobStatusName"`
	TaskStatus         int            `json:"TaskStatus"`
	TaskStatusName     string         `json:"TaskStatusName"`
	UserID             int            `json:"UserID"`
	ResourceID         int            `json:"ResourceID"`
	JourneyCode        string         `json:"JourneyCode"`
	FormFlowID         int            `json:"FormFlowID"`
	InspectionForJobID int            `json:"InspectionForJobID"`
	IsInspection       bool           `json:"IsInspection"`
	JobCurrentForm     JobCurrentForm `json:"Form"`
}

// JobCurrentForm str
type JobCurrentForm struct {
	Form      string `json:"Form"`
	FormTitle string `json:"FormTitle"`
}

// JobListResponse str
type JobListResponse struct {
	JobID            int    `json:"JobID"`
	JobType          int    `json:"JobType"`
	JobTypeName      string `json:"JobTypeName"`
	JobTypeIcon      string `json:"JobTypeIcon"`
	LocationID       int    `json:"LocationID"`
	Status           int    `json:"Status"`
	StatusName       string `json:"StatusName"`
	StatusIcon       string `json:"StatusIcon"`
	InProgressStatus string `json:"InProgressStatus"`
	JobTaskStatus    string `json:"JobTaskStatus"`

	EstimateDate         *time.Time             `json:"EstimateDate"`
	InvoiceDate          *time.Time             `json:"InvoiceDate"`
	CreditNoteDate       *time.Time             `json:"CreditNoteDate"`
	EstimateDueDate      *time.Time             `json:"EstimateDueDate"`
	InvoiceDueDate       *time.Time             `json:"InvoiceDueDate"`
	CustomerApprovalDate *time.Time             `json:"CustomerApprovalDate"`
	ManagerApprovalDate  *time.Time             `json:"ManagerApprovalDate"`
	RejectedDate         *time.Time             `json:"RejectedDate"`
	EstimatedDistance    float64                `json:"EstimatedDistance"`
	EstimatedTravelTime  float64                `json:"EstimatedTravelTime"`
	UDF                  map[string]interface{} `json:"UDF"`
	UDFs                 []UDFResponse          `json:"UDFs"`
	// Task 1
	JobTaskID                int        `json:"JobTaskID"`
	NavigationAddress        string     `json:"NavigationAddress"`
	ServiceTimeInMinutes     int        `json:"ServiceTimeInMinutes"`
	FormFlowID               int        `json:"FormFlowID"`
	TaskJobType              int        `json:"TaskJobType"`
	TaskJobTypeName          string     `json:"TaskJobTypeName"`
	TaskJobTypeIcon          string     `json:"TaskJobTypeIcon"`
	TaskStatus               int        `json:"TaskStatus"`
	TaskStatusName           string     `json:"TaskStatusName"`
	TaskStatusIcon           string     `json:"TaskStatusIcon"`
	ScheduleStartDateTime    *time.Time `json:"ScheduleStartDateTime"`
	ScheduleEndDateTime      *time.Time `json:"ScheduleEndDateTime"`
	DepartureDateTime        *time.Time `json:"DepartureDateTime"`
	EstimatedArrivalDateTime *time.Time `json:"EstimatedArrivalDateTime"`
	ArrivalDateTime          *time.Time `json:"ArrivalDateTime"`
	StartDateTime            *time.Time `json:"StartDateTime"`
	EndDateTime              *time.Time `json:"EndDateTime"`
	AdditionalInformation    string     `json:"AdditionalInformation"`
	JobTimeInSeconds         int        `json:"JobTimeInSeconds"`

	// Task 2
	Task2JobTaskID                int        `json:"Task2JobTaskID"`
	Task2NavigationAddress        string     `json:"Task2NavigationAddress"`
	Task2ServiceTimeInMinutes     int        `json:"Task2ServiceTimeInMinutes"`
	Task2FormFlowID               int        `json:"Task2FormFlowID"`
	Task2JobType                  int        `json:"Task2JobType"`
	Task2JobTypeName              string     `json:"Task2JobTypeName"`
	Task2JobTypeIcon              string     `json:"Task2JobTypeIcon"`
	Task2Status                   int        `json:"Task2Status"`
	Task2StatusName               string     `json:"Task2StatusName"`
	Task2StatusIcon               string     `json:"Task2StatusIcon"`
	Task2ScheduleStartDateTime    *time.Time `json:"Task2ScheduleStartDateTime"`
	Task2ScheduleEndDateTime      *time.Time `json:"Task2ScheduleEndDateTime"`
	Task2DepartureDateTime        *time.Time `json:"Task2DepartureDateTime"`
	Task2EstimatedArrivalDateTime *time.Time `json:"Task2EstimatedArrivalDateTime"`
	Task2ArrivalDateTime          *time.Time `json:"Task2ArrivalDateTime"`
	Task2StartDateTime            *time.Time `json:"Task2StartDateTime"`
	Task2EndDateTime              *time.Time `json:"Task2EndDateTime"`
	Task2AdditionalInformation    string     `json:"Task2AdditionalInformation"`
	Task2JobTimeInSeconds         int        `json:"Task2JobTimeInSeconds"`
}

// InProgressUserResponse str
type InProgressUserResponse struct {
	UserID           int             `json:"UserID"`
	ResourceID       int             `json:"ResourceID"`
	AccountKey       int             `json:"AccountKey"`
	FirstName        string          `json:"FirstName"`
	LastName         string          `json:"LastName"`
	LocationName     string          `json:"LocationName"`
	PhoneNumber      string          `json:"PhoneNumber"`
	CountryCode      string          `json:"CountryCode"`
	ResourceName     string          `json:"ResourceName"`
	ResourceType     int             `json:"ResourceType"`
	ResourceTypeName string          `json:"ResourceTypeName"`
	ResourceCode     string          `json:"ResourceCode"`
	ResourceColor    string          `json:"ResourceColor"`
	InProgressJobs   []InProgressJob `json:"Jobs"`
}

// InProgressUserResponse str
type InProgressJob struct {
	JobID              int                 `json:"JobID"`
	JobNumber          string              `json:"JobNumber"`
	JobType            int                 `json:"JobType"`
	JobTypeName        string              `json:"JobTypeName"`
	JobTypeIcon        string              `json:"JobTypeIcon"`
	LocationID         int                 `json:"LocationID"`
	Status             int                 `json:"Status"`
	StatusName         string              `json:"StatusName"`
	StatusIcon         string              `json:"StatusIcon"`
	InProgressStatus   string              `json:"InProgressStatus"`
	JobTaskStatus      string              `json:"JobTaskStatus"`
	InProgressJobTasks []InProgressJobTask `json:"JobTasks"`
}

// InProgressUserResponse str
type InProgressJobTask struct {
	JobTaskID         int    `json:"JobTaskID"`
	NavigationAddress string `json:"NavigationAddress"`
	TaskJobType       int    `json:"TaskJobType"`
	TaskJobTypeName   string `json:"TaskJobTypeName"`
	TaskJobTypeIcon   string `json:"TaskJobTypeIcon"`
	TaskStatus        int    `json:"TaskStatus"`
	TaskStatusName    string `json:"TaskStatusName"`
	TaskStatusIcon    string `json:"TaskStatusIcon"`
}

// InspectionJobResponse str
type InspectionJobResponse struct {
	JobID                   int        `json:"JobID"`
	JobNumber               string     `json:"JobNumber"`
	Status                  int        `json:"Status"`
	JobTaskType             int        `json:"JobTaskType"`
	StatusName              string     `json:"StatusName"`
	SurchargeParentItemKeys []string   `json:"SurchargeParentItemKeys"`
	SchedulerStartDate      *time.Time `json:"SchedulerStartDate"`
	CompleteDate            *time.Time `json:"CompleteDate"`
}

// InspectionJobForSkip str
type InspectionJobForSkip struct {
	JobID             int    `json:"JobID"`
	JobNumber         string `json:"JobNumber"`
	InspectionJobType int    `json:"InspectionJobType"`
}
