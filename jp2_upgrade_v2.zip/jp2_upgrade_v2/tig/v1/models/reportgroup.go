package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ReportGroupResponse data
type ReportGroupResponse struct {
	ReportGroupID   int    `json:"ReportGroupID"`
	ReportGroupName string `json:"ReportGroupName"`
	IsSystem        bool   `json:"IsSystem"`
}

// ReportGroup data
type ReportGroup struct {
	ReportGroupID   int        `gorm:"column:ReportGroupID;primaryKey;autoIncrement;not null"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ReportGroupName string     `gorm:"column:ReportGroupName" json:"ReportGroupName"`
	IsSystem        bool       `gorm:"column:IsSystem" json:"IsSystem"`
}

// TableName func
func (ReportGroup) TableName() string {
	return "reportgroups"
}

// BeforeCreate func
func (object *ReportGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ReportGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ReportGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ReportGroupID", JSONObject)
	if res != nil {
		vReportGroupID, sReportGroupID := strconv.Atoi(val)
		if sReportGroupID == nil {
			object.ReportGroupID = vReportGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ReportGroupName", JSONObject)
	if res != nil {
		object.ReportGroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsSystem", JSONObject)
	if res != nil {
		object.IsSystem, _ = strconv.ParseBool(val)
	}
	return
}
