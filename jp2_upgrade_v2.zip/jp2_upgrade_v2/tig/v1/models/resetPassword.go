package models

import "time"

// ResetPasswordPOST str
type ResetPasswordPOST struct {
	Token       string `json:"token"`
	NewPassword string `json:"newpassword"`
	Mode        string `json:"mode"`
}

// ResetPasswordLinkPOST str
type ResetPasswordLinkPOST struct {
	Email string `json:"email"`
	Mode  string `json:"mode"`
}

// ResetPassword str
type ResetPassword struct {
	ResetPasswordID int       `gorm:"column:ResetPasswordId;primaryKey;autoIncrement;not null"`
	UserID          int       `gorm:"column:UserId;not null"`
	Token           string    `gorm:"column:Token;not null"`
	ResetDate       time.Time `gorm:"column:ResetDate;not null"`
	ExpiredDate     time.Time `gorm:"column:ExpiredDate;not null"`
	Mode            string    `gorm:"column:Mode;not null"`
	Status          bool      `gorm:"column:Status;not null"`
}

// TableName func
func (ResetPassword) TableName() string {
	return "resetpassword"
}
