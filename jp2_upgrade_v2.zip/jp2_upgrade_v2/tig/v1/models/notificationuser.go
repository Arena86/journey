package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// NotificationUser data
type NotificationUser struct {
	NotificationUserID int        `gorm:"column:NotificationUserID;primaryKey;autoIncrement;not null" json:"NotificationUserID"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived         bool       `gorm:"column:IsArchived"`
	NotificationID     int        `gorm:"column:NotificationID" json:"NotificationID"`
	AccountKey         int        `gorm:"column:AccountKey" json:"AccountKey"`
	Status             int        `gorm:"column:Status" json:"Status"`
	ReadStatus         bool       `gorm:"column:ReadStatus" json:"ReadStatus"`
}

// NotificationUserResponse data
type NotificationUserResponse struct {
	NotificationUserID int  `json:"NotificationUserID"`
	NotificationID     int  `json:"NotificationID"`
	AccountKey         int  `json:"AccountKey"`
	Status             int  `json:"Status"`
	ReadStatus         bool `json:"ReadStatus"`
}

// TableName func
func (NotificationUser) TableName() string {
	return "notificationusers"
}

// BeforeCreate func
func (object *NotificationUser) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *NotificationUser) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *NotificationUser) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("NotificationUserID", JSONObject)
	if res != nil {
		object.NotificationUserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("NotificationID", JSONObject)
	if res != nil {
		object.NotificationID, _ = strconv.Atoi(val)
	}
	/* val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.Atoi(val)
	} */
	return
}
