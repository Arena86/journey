package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// SchedulerUserResourceResponse str
type SchedulerUserResourceResponse struct {
	SchedulerUserID int
	UserID          int
	ResourceID      int
	SchedulerDate   string
	LocationID      int
	FirstName       string
	LastName        string
	PhoneNumber     string
	Email           string
}

// SchedulerResourceResponse str
type SchedulerResourceResponse struct {
	SchedulerDate string
	LocationID    int
	IsReserved    bool
	IsExternal    bool
	ResourceID    int
}

// Resource data
type Resource struct {
	ResourceID           int        `gorm:"column:ResourceID;primaryKey;autoIncrement;not null"`
	IsArchived           bool       `gorm:"column:IsArchived"`
	CreatedBy            int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate          *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy           int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate         *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted            bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit              bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ResourceCode         string     `gorm:"column:ResourceCode" json:"ResourceCode"`
	ResourceName         string     `gorm:"column:ResourceName" json:"ResourceName"`
	ResourceMode         int        `gorm:"column:ResourceMode" json:"ResourceMode"`
	ResourceColor        string     `gorm:"column:ResourceColor" json:"ResourceColor"`
	UserID               int        `gorm:"column:UserID" json:"UserID"`
	ResourceType         int        `gorm:"column:ResourceType" json:"ResourceType"`
	RegistrationNumber   string     `gorm:"column:RegistrationNumber" json:"RegistrationNumber"`
	CubicMeter           int        `gorm:"column:CubicMeter" json:"CubicMeter"`
	MaxLoadingWeight     int        `gorm:"column:MaxLoadingWeight" json:"MaxLoadingWeight"`
	SquareMeter          int        `gorm:"column:SquareMeter" json:"SquareMeter"`
	Level                string     `gorm:"column:Level" json:"Level"`
	NavigationAddress    string     `gorm:"column:NavigationAddress" json:"NavigationAddress"`
	CurrentLatitude      string     `gorm:"column:CurrentLatitude" json:"CurrentLatitude"`
	CurrentLongitude     string     `gorm:"column:CurrentLongitude" json:"CurrentLongitude"`
	ShowInScheduler      bool       `gorm:"column:ShowInScheduler" json:"ShowInScheduler"`
	VehicleInspectionID  int        `gorm:"column:VehicleInspectionID" json:"VehicleInspectionID"`
	VehicleInspectionDay string     `gorm:"column:VehicleInspectionDay" json:"VehicleInspectionDay"`
	VehicleStocktakeID   int        `gorm:"column:VehicleStocktakeID" json:"VehicleStocktakeID"`
	VehicleStocktakeDay  string     `gorm:"column:VehicleStocktakeDay" json:"VehicleStocktakeDay"`
	BuyPriceByHour       float64    `gorm:"column:BuyPriceByHour" json:"BuyPriceByHour"`
	SellPriceByHour      float64    `gorm:"column:SellPriceByHour" json:"SellPriceByHour"`
	LocationID           int        `gorm:"column:LocationID" json:"LocationID"`
	Note                 string     `gorm:"column:Note" json:"Note"`
	MaxDistance          int        `gorm:"column:MaxDistance" json:"MaxDistance"`
	MaxDrivingTime       int        `gorm:"column:MaxDrivingTime" json:"MaxDrivingTime"`
	MaxJobs              int        `gorm:"column:MaxJobs" json:"MaxJobs"`
	MinJobs              int        `gorm:"column:MinJobs" json:"MinJobs"`
	UseMaxDrivingTime    bool       `gorm:"column:UseMaxDrivingTime" json:"UseMaxDrivingTime"`
	BreakDuration        int        `gorm:"column:BreakDuration" json:"BreakDuration"`
	TotalMaxDrivingTime  int        `gorm:"column:TotalMaxDrivingTime" json:"TotalMaxDrivingTime"`
	InitialDrivingTime   int        `gorm:"column:InitialDrivingTime" json:"InitialDrivingTime"`
	VehicleLength        int        `gorm:"column:VehicleLength" json:"VehicleLength"`
}

// ResourceResponse data
type ResourceResponse struct {
	ResourceID             int                             `json:"ResourceID"`
	ResourceCode           string                          `json:"ResourceCode"`
	ResourceName           string                          `json:"ResourceName"`
	ResourceMode           int                             `json:"ResourceMode"`
	ResourceModeName       string                          `json:"ResourceModeName"`
	ResourceColor          string                          `json:"ResourceColor"`
	ResourceType           int                             `json:"ResourceType"`
	ResourceTypeName       string                          `json:"ResourceTypeName"`
	Icon                   string                          `json:"Icon"`
	RegistrationNumber     string                          `json:"RegistrationNumber"`
	CubicMeter             int                             `json:"CubicMeter"`
	MaxLoadingWeight       int                             `json:"MaxLoadingWeight"`
	SquareMeter            int                             `json:"SquareMeter"`
	Level                  string                          `json:"Level"`
	NavigationAddress      string                          `json:"NavigationAddress"`
	CurrentLatitude        string                          `json:"CurrentLatitude"`
	CurrentLongitude       string                          `json:"CurrentLongitude"`
	ShowInScheduler        bool                            `json:"ShowInScheduler"`
	VehicleInspectionID    int                             `json:"VehicleInspectionID"`
	VehicleInspectionDay   []int                           `json:"VehicleInspectionDay"`
	VehicleStocktakeID     int                             `json:"VehicleStocktakeID"`
	VehicleStocktakeDay    []int                           `json:"VehicleStocktakeDay"`
	BuyPriceByHour         float64                         `json:"BuyPriceByHour"`
	SellPriceByHour        float64                         `json:"SellPriceByHour"`
	LocationID             int                             `json:"LocationID"`
	UDFs                   []UDFResponse                   `json:"UDFs"`
	UDF                    map[string]interface{}          `json:"UDF"`
	InspectionHistoryCount int                             `json:"InspectionHistoryCount"`
	StocktakeHistoryCount  int                             `json:"StocktakeHistoryCount"`
	Note                   string                          `json:"Note"`
	SchedulerUsers         []SchedulerUserResourceResponse `json:"SchedulerUsers"`
	SchedulerResources     []SchedulerResourceResponse     `json:"SchedulerResources"`
	MaxDistance            int                             `json:"MaxDistance"`
	MaxDrivingTime         int                             `json:"MaxDrivingTime"`
	MaxJobs                int                             `json:"MaxJobs"`
	MinJobs                int                             `json:"MinJobs"`
	UseMaxDrivingTime      bool                            `json:"UseMaxDrivingTime"`
	BreakDuration          int                             `json:"BreakDuration"`
	TotalMaxDrivingTime    int                             `json:"TotalMaxDrivingTime"`
	InitialDrivingTime     int                             `json:"InitialDrivingTime"`
	VehicleLength          int                             `json:"VehicleLength"`
}

// AppResourceResponse data
type AppResourceResponse struct {
	ResourceID             int                    `json:"ResourceID"`
	ResourceCode           string                 `json:"ResourceCode"`
	ResourceName           string                 `json:"ResourceName"`
	ResourceMode           int                    `json:"ResourceMode"`
	ResourceModeName       string                 `json:"ResourceModeName"`
	ResourceColor          string                 `json:"ResourceColor"`
	UserID                 int                    `json:"UserID"`
	ResourceType           int                    `json:"ResourceType"`
	ResourceTypeName       string                 `json:"ResourceTypeName"`
	Icon                   string                 `json:"Icon"`
	RegistrationNumber     string                 `json:"RegistrationNumber"`
	CubicMeter             int                    `json:"CubicMeter"`
	MaxLoadingWeight       int                    `json:"MaxLoadingWeight"`
	SquareMeter            int                    `json:"SquareMeter"`
	Level                  string                 `json:"Level"`
	NavigationAddress      string                 `json:"NavigationAddress"`
	CurrentLatitude        string                 `json:"CurrentLatitude"`
	CurrentLongitude       string                 `json:"CurrentLongitude"`
	ShowInScheduler        bool                   `json:"ShowInScheduler"`
	VehicleInspectionID    int                    `json:"VehicleInspectionID"`
	VehicleInspectionDay   []int                  `json:"VehicleInspectionDay"`
	VehicleStocktakeID     int                    `json:"VehicleStocktakeID"`
	VehicleStocktakeDay    []int                  `json:"VehicleStocktakeDay"`
	BuyPriceByHour         float64                `json:"BuyPriceByHour"`
	SellPriceByHour        float64                `json:"SellPriceByHour"`
	LocationID             int                    `json:"LocationID"`
	UDFs                   []UDFResponse          `json:"UDFs"`
	UDF                    map[string]interface{} `json:"UDF"`
	Email                  string                 `json:"Email"`
	FirstName              string                 `json:"FirstName"`
	LastName               string                 `json:"LastName"`
	PhoneNumber            string                 `json:"PhoneNumber"`
	InspectionHistoryCount int                    `json:"InspectionHistoryCount"`
	StocktakeHistoryCount  int                    `json:"StocktakeHistoryCount"`
	Note                   string                 `json:"Note"`
}

// ResourceAppResponse data
type ResourceAppResponse struct {
	Resources          []AppResourceResponse `json:"Resources"`
	UnAssignedResource int                   `json:"UnAssignedResource"`
}

// TableName func
func (Resource) TableName() string {
	return "resources"
}

// BeforeCreate func
func (object *Resource) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Resource) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Resource) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		vResourceID, sResourceID := strconv.Atoi(val)
		if sResourceID == nil {
			object.ResourceID = vResourceID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceCode", JSONObject)
	if res != nil {
		object.ResourceCode = val
	}
	val, res = services.ConvertJSONValueToVariable("ResourceName", JSONObject)
	if res != nil {
		object.ResourceName = val
	}
	val, res = services.ConvertJSONValueToVariable("ResourceMode", JSONObject)
	if res != nil {
		vResourceMode, sResourceMode := strconv.Atoi(val)
		if sResourceMode == nil {
			object.ResourceMode = vResourceMode
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceColor", JSONObject)
	if res != nil {
		object.ResourceColor = val
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		vUserID, sUserID := strconv.Atoi(val)
		if sUserID == nil {
			object.UserID = vUserID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceType", JSONObject)
	if res != nil {
		vResourceType, sResourceType := strconv.Atoi(val)
		if sResourceType == nil {
			object.ResourceType = vResourceType
		}
	}
	val, res = services.ConvertJSONValueToVariable("RegistrationNumber", JSONObject)
	if res != nil {
		object.RegistrationNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("CubicMeter", JSONObject)
	if res != nil {
		vCubicMeter, sCubicMeter := strconv.Atoi(val)
		if sCubicMeter == nil {
			object.CubicMeter = vCubicMeter
		}
	}
	val, res = services.ConvertJSONValueToVariable("MaxLoadingWeight", JSONObject)
	if res != nil {
		vMaxLoadingWeight, sMaxLoadingWeight := strconv.Atoi(val)
		if sMaxLoadingWeight == nil {
			object.MaxLoadingWeight = vMaxLoadingWeight
		}
	}
	val, res = services.ConvertJSONValueToVariable("SquareMeter", JSONObject)
	if res != nil {
		vSquareMeter, sSquareMeter := strconv.Atoi(val)
		if sSquareMeter == nil {
			object.SquareMeter = vSquareMeter
		}
	}
	val, res = services.ConvertJSONValueToVariable("Level", JSONObject)
	if res != nil {
		object.Level = val
	}
	val, res = services.ConvertJSONValueToVariable("NavigationAddress", JSONObject)
	if res != nil {
		object.NavigationAddress = val
	}
	val, res = services.ConvertJSONValueToVariable("CurrentLatitude", JSONObject)
	if res != nil {
		object.CurrentLatitude = val
	}
	val, res = services.ConvertJSONValueToVariable("CurrentLongitude", JSONObject)
	if res != nil {
		object.CurrentLongitude = val
	}
	val, res = services.ConvertJSONValueToVariable("ShowInScheduler", JSONObject)
	if res != nil {
		object.ShowInScheduler, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionID", JSONObject)
	if res != nil {
		object.VehicleInspectionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionDay", JSONObject)
	if res != nil {
		var resources ResourceResponse
		vJSON, errJSON := json.Marshal(JSONObject)
		if errJSON == nil {
			json.Unmarshal(vJSON, &resources)
		}
		if len(resources.VehicleInspectionDay) > 0 {
			valuesText := make([]string, 0)
			for i := range resources.VehicleInspectionDay {
				number := resources.VehicleInspectionDay[i]
				text := strconv.Itoa(number)
				valuesText = append(valuesText, text)
			}
			object.VehicleInspectionDay = strings.Join(valuesText, ", ")
		}
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeID", JSONObject)
	if res != nil {
		object.VehicleStocktakeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeDay", JSONObject)
	if res != nil {
		var resources ResourceResponse
		vJSON, errJSON := json.Marshal(JSONObject)
		if errJSON == nil {
			json.Unmarshal(vJSON, &resources)
		}
		if len(resources.VehicleStocktakeDay) > 0 {
			valuesText := make([]string, 0)
			for i := range resources.VehicleStocktakeDay {
				number := resources.VehicleStocktakeDay[i]
				text := strconv.Itoa(number)
				valuesText = append(valuesText, text)
			}
			object.VehicleStocktakeDay = strings.Join(valuesText, ", ")
		}
	}
	val, res = services.ConvertJSONValueToVariable("BuyPriceByHour", JSONObject)
	if res != nil {
		object.BuyPriceByHour, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("SellPriceByHour", JSONObject)
	if res != nil {
		object.SellPriceByHour, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		vLocationID, sLocationID := strconv.Atoi(val)
		if sLocationID == nil {
			object.LocationID = vLocationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Note", JSONObject)
	if res != nil {
		object.Note = val
	}
	val, res = services.ConvertJSONValueToVariable("MaxDistance", JSONObject)
	if res != nil {
		object.MaxDistance, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("MaxDrivingTime", JSONObject)
	if res != nil {
		object.MaxDrivingTime, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("MaxJobs", JSONObject)
	if res != nil {
		object.MaxJobs, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("MinJobs", JSONObject)
	if res != nil {
		object.MinJobs, _ = strconv.Atoi(val)
	}

	val, res = services.ConvertJSONValueToVariable("UseMaxDrivingTime", JSONObject)
	if res != nil {
		object.UseMaxDrivingTime, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("BreakDuration", JSONObject)
	if res != nil {
		object.BreakDuration, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TotalMaxDrivingTime", JSONObject)
	if res != nil {
		object.TotalMaxDrivingTime, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("InitialDrivingTime", JSONObject)
	if res != nil {
		object.InitialDrivingTime, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleLength", JSONObject)
	if res != nil {
		object.VehicleLength, _ = strconv.Atoi(val)
	}

	return
}

// GenerateDefaultValue func
func (object *Resource) GenerateDefaultValue(sequencyModel DocumentSequency, resourcePrefix Prefix) {
	if object.ResourceCode == "" {
		if resourcePrefix.DocumentSequence != "" {
			firstConfig := resourcePrefix.Prefix
			lenConfig := resourcePrefix.Length
			sqCode := sequencyModel.ResourceCode
			object.ResourceCode = services.GenerateDefaultValueWithConfigLength(firstConfig, lenConfig, sqCode)
		}
	}
	return
}
