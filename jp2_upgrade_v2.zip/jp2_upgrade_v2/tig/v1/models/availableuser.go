package models

// AvailableUser str
type AvailableUser struct {
	UserID       int
	FirstName    string
	LastName     string
	PhoneNumber  string
	Email        string
	LocationID   int
	LocationName string
	Schedules    []ExternalResourceSchedule
}
