package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AddressType data
type AddressType struct {
	AddressTypeID   int        `gorm:"column:AddressTypeID;primaryKey"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived      bool       `gorm:"column:IsArchived"`
	AddressTypeName string     `gorm:"column:AddressTypeName"`
	IsDefault       bool       `gorm:"column:IsDefault"`
	TranslationKey  string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	ERP             string     `gorm:"column:Erp" json:"Erp"`
	IsLocation      bool       `gorm:"column:IsLocation"`
	IsDepot         bool       `gorm:"column:IsDepot" json:"IsDepot"`
}

// AddressTypeResponse data
type AddressTypeResponse struct {
	AddressTypeID   int    `json:"AddressTypeID"`
	AddressTypeName string `json:"AddressTypeName"`
	ERP             string `json:"Erp"`
	IsLocation      bool   `json:"IsLocation"`
	IsDepot         bool   `json:"IsDepot"`
	IsDefault       bool   `json:"IsDefault"`
}

// TableName func
func (AddressType) TableName() string {
	return "addresstypes"
}

// BeforeCreate func
func (object *AddressType) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AddressType) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AddressType) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AddressTypeID", JSONObject)
	if res != nil {
		vAddressTypeID, sAddressTypeID := strconv.Atoi(val)
		if sAddressTypeID == nil {
			object.AddressTypeID = vAddressTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("AddressTypeName", JSONObject)
	if res != nil {
		object.AddressTypeName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsDefault", JSONObject)
	if res != nil {
		object.IsDefault, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsAudit", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	val, res = services.ConvertJSONValueToVariable("Erp", JSONObject)
	if res != nil {
		object.ERP = val
	}
	val, res = services.ConvertJSONValueToVariable("IsLocation", JSONObject)
	if res != nil {
		object.IsLocation, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDepot", JSONObject)
	if res != nil {
		object.IsDepot, _ = strconv.ParseBool(val)
	}

	return
}
