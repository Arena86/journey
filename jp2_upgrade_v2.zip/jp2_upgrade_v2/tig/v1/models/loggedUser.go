package models

import "time"

// ParamsLoggedUser data
type ParamsLoggedUser struct {
	DBName      string `json:"DatabaseID"`
	DBUser      string `json:"DBUsername"`
	DBPassword  string `json:"DBPassword"`
	AccountKey  int    `json:"AccountKey"`
	ExpiredDate string `json:"ExpiredDate"`
	Token       string `json:"Token"`
	Host        string `json:"Host"`
	DBPort      string `json:"DBPort"`
	Mode        string `json:"Mode"`
}

// DBLoggedUser data
type DBLoggedUser struct {
	LoggedKey   int        `gorm:"column:LoggedKey;primaryKey;autoIncrement;not null"`
	AccountKey  string     `gorm:"column:AccountKey;not null;type:nvarchar(50)"`
	Token       string     `gorm:"column:Token;type:nvarchar(100);"`
	DeviceToken string     `gorm:"column:DeviceToken;type:nvarchar(100);"`
	ExpiredDate *time.Time `gorm:"column:ExpiredDate;type:nvarchar(45)"`
}

// TableName func
func (DBLoggedUser) TableName() string {
	return "loggedusers"
}
