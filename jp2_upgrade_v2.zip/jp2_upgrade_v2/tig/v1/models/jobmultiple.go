package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobMultiple data
type JobMultiple struct {
	JobMultipleID int        `gorm:"column:JobMultipleID;primaryKey;autoIncrement;not null"`
	IsArchived    bool       `gorm:"column:IsArchived"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID         int        `gorm:"column:JobID" json:"JobID"`
	PrimaryJobID  int        `gorm:"column:PrimaryJobID" json:"PrimaryJobID"`
	Sort          int        `gorm:"-" json:"Sort"`
}

// JobMultipleRequest data
type JobMultipleRequest struct {
	PrimaryJobID *int          `json:"PrimaryJobID"`
	MultipleJobs []JobMultiple `json:"MultipleJobs"`
}

// JobMultipleResponse data
type JobMultipleResponse struct {
	PrimaryJobID *int                   `json:"PrimaryJobID"`
	MultipleJobs []JobSelectionResponse `json:"MultipleJobs"`
}

// TableName func
func (JobMultiple) TableName() string {
	return "jobmultiples"
}

// BeforeCreate func
func (object *JobMultiple) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobMultiple) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobMultiple) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobMultipleID", JSONObject)
	if res != nil {
		object.JobMultipleID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PrimaryJobID", JSONObject)
	if res != nil {
		object.PrimaryJobID, _ = strconv.Atoi(val)
	}

	return
}
