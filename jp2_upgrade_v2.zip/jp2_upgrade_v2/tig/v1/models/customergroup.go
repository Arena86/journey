package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// CustomerGroup data
type CustomerGroup struct {
	CustomerGroupID   int        `gorm:"column:CustomerGroupID;primaryKey;autoIncrement;not null" json:"CustomerGroupID"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived        bool       `gorm:"column:IsArchived"`
	CustomerGroupName string     `gorm:"column:CustomerGroupName;" validate:"required" json:"CustomerGroupName"`
	PriceListID       *int       `gorm:"column:PriceListID" json:"PriceListID"`
}

// CustomerGroupResponse data
type CustomerGroupResponse struct {
	CustomerGroupID   int                   `json:"CustomerGroupID"`
	CustomerGroupName string                `json:"CustomerGroupName"`
	PriceListID       *int                  `json:"PriceListID"`
	PriceListName     *string               `json:"PriceListName"`
	Translations      []TranslationResponse `json:"Translations"`
}

// TableName func
func (CustomerGroup) TableName() string {
	return "customergroups"
}

// BeforeCreate func
func (object *CustomerGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *CustomerGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *CustomerGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("CustomerGroupID", JSONObject)
	if res != nil {
		vCustomerGroupID, sCustomerGroupID := strconv.Atoi(val)
		if sCustomerGroupID == nil {
			object.CustomerGroupID = vCustomerGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("CustomerGroupName", JSONObject)
	if res != nil {
		object.CustomerGroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("PriceListID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.PriceListID = &vParse
		}
	}
	return
}
