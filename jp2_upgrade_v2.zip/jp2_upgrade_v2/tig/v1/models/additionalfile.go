package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AdditionalFile data
type AdditionalFile struct {
	AdditionalFileID int        `gorm:"column:AdditionalFileID;primaryKey;autoIncrement;not null"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobID            int        `gorm:"column:JobID" json:"JobID"`
	Name             string     `gorm:"column:Name" json:"Name"`
	FileURL          string     `gorm:"column:FileURL" json:"FileURL"`
	FileSize         int        `gorm:"column:FileSize" json:"FileSize"`
	FileKey          string     `gorm:"column:FileKey" json:"FileKey"`
	ETag             string     `gorm:"column:ETag" json:"ETag"`
	Type             string     `gorm:"column:Type" json:"Type"`
}

// AdditionalFileResponse data
type AdditionalFileResponse struct {
	AdditionalFileID int    `json:"AdditionalFileID"`
	JobID            int    `json:"JobID"`
	JobNumber        string `json:"JobNumber"`
	Name             string `json:"Name"`
	FileURL          string `json:"FileURL"`
	FileSize         int    `json:"FileSize"`
	FileKey          string `json:"FileKey"`
	ETag             string `json:"ETag"`
	Type             string `json:"Type"`
}

// TableName func
func (AdditionalFile) TableName() string {
	return "additionalfiles"
}

// BeforeCreate func
func (object *AdditionalFile) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AdditionalFile) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AdditionalFile) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AdditionalFileID", JSONObject)
	if res != nil {
		object.AdditionalFileID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("FileKey", JSONObject)
	if res != nil {
		object.FileKey = val
	}
	val, res = services.ConvertJSONValueToVariable("FileURL", JSONObject)
	if res != nil {
		object.FileURL = val
	}
	val, res = services.ConvertJSONValueToVariable("FileSize", JSONObject)
	if res != nil {
		object.FileSize, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ETag", JSONObject)
	if res != nil {
		object.ETag = val
	}
	val, res = services.ConvertJSONValueToVariable("Type", JSONObject)
	if res != nil {
		object.Type = val
	}
	return
}
