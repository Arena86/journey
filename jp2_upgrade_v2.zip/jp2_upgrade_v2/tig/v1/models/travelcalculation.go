package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// TravelCalculation data
type TravelCalculation struct {
	TravelCalculationID   int        `gorm:"column:TravelCalculationID;primaryKey;autoIncrement;not null" json:"TravelCalculationID"`
	CreatedBy             int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate           *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy            int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate          *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted             bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit               bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived            bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TravelCalculationMode string     `gorm:"column:TravelCalculationMode" json:"TravelCalculationMode"`
	JobID                 int        `gorm:"column:JobID" json:"JobID"`
	ItemID                int        `gorm:"column:ItemID" json:"ItemID"`
	TravelDistanceAmount  float64    `gorm:"column:TravelDistanceAmount" json:"TravelDistanceAmount"`
	TravelTimeAmount      float64    `gorm:"column:TravelTimeAmount" json:"TravelTimeAmount"`
}

// TravelCalculationResponse data
type TravelCalculationResponse struct {
	TravelCalculationMode string                            `json:"TravelCalculationMode"`
	Calculations          []TravelCalculationDetailResponse `json:"Calculations"`
}

// TravelCalculationDetailResponse data
type TravelCalculationDetailResponse struct {
	ItemID               int     `json:"ItemID"`
	ItemCode             string  `json:"ItemCode"`
	Description          string  `json:"Description"`
	TravelDistanceAmount float64 `json:"TravelDistanceAmount"`
	TravelTimeAmount     float64 `json:"TravelTimeAmount"`
}

// TableName func
func (TravelCalculation) TableName() string {
	return "travelcalculation"
}

// BeforeCreate func
func (object *TravelCalculation) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *TravelCalculation) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *TravelCalculation) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TravelCalculationID", JSONObject)
	if res != nil {
		vTravelCalculationID, sTravelCalculationID := strconv.Atoi(val)
		if sTravelCalculationID == nil {
			object.TravelCalculationID = vTravelCalculationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		vJobID, sJobID := strconv.Atoi(val)
		if sJobID == nil {
			object.JobID = vJobID
		}
	}

	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		vItemID, sItemID := strconv.Atoi(val)
		if sItemID == nil {
			object.ItemID = vItemID
		}
	}

	val, res = services.ConvertJSONValueToVariable("TravelDistanceAmount", JSONObject)
	if res != nil {
		vTravelDistanceAmount, sTravelDistanceAmount := strconv.ParseFloat(val, 64)
		if sTravelDistanceAmount == nil {
			object.TravelDistanceAmount = vTravelDistanceAmount
		}
	}
	val, res = services.ConvertJSONValueToVariable("TravelTimeAmount", JSONObject)
	if res != nil {
		vTravelTimeAmount, sTravelTimeAmount := strconv.ParseFloat(val, 64)
		if sTravelTimeAmount == nil {
			object.TravelTimeAmount = vTravelTimeAmount
		}
	}
	val, res = services.ConvertJSONValueToVariable("TravelCalculationMode	", JSONObject)
	if res != nil {
		object.TravelCalculationMode = val
	}
	return
}
