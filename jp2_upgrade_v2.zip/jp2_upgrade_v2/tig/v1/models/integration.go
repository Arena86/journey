package models

import (
	"time"

	"gorm.io/gorm"
)

// Integration data
type Integration struct {
	IntegrationID int        `gorm:"column:IntegrationID;primaryKey;autoIncrement;not null"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Name          string     `gorm:"column:Name" json:"Name"`
	Version       string     `gorm:"column:Version" json:"Version"`
	Edition       string     `gorm:"column:Edition" json:"Edition"`
	ReleaseDate   time.Time  `gorm:"column:ReleaseDate" json:"ReleaseDate"`
	IsLicensed    bool       `gorm:"column:IsLicensed" json:"IsLicensed"`
	Endpoint      string     `gorm:"column:Endpoint" json:"Endpoint"`
}

// IntegrationResponse data
type IntegrationResponse struct {
	IntegrationID int       `json:"IntegrationID"`
	Name          string    `json:"Name"`
	Version       string    `json:"Version"`
	Edition       string    `json:"Edition"`
	ReleaseDate   time.Time `json:"ReleaseDate"`
	IsLicensed    bool      `json:"IsLicensed"`
	Endpoint      string    `json:"Endpoint"`
}

// TableName func
func (Integration) TableName() string {
	return "integrations"
}

// BeforeCreate func
func (object *Integration) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Integration) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Integration) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
	/* res interface{}
	val string */
	)

	return
}
