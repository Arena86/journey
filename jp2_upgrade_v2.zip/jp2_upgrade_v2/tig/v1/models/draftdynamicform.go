package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DraftDynamicForm data
type DraftDynamicForm struct {
	DraftDynamicFormID int        `gorm:"column:DraftDynamicFormID;primaryKey;autoIncrement;not null"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool       `gorm:"column:IsArchived"`
	FormName           string     `gorm:"column:FormName" validate:"required"`
	DesignP            *string    `gorm:"column:DesignP"`
	DesignL            *string    `gorm:"column:DesignL"`
	LastPublishedDate  *time.Time `gorm:"column:LastPublishedDate" json:"LastPublishedDate"`
	Status             int        `gorm:"column:Status" json:"Status"`
	FormStatus         string     `gorm:"column:FormStatus" json:"FormStatus"`
	Is4DPriceForm      bool       `gorm:"column:Is4DPriceForm"`
	IsBreakForm        bool       `gorm:"column:IsBreakForm"`
}

// DraftDynamicFormResponse data
type DraftDynamicFormResponse struct {
	DraftDynamicFormID int               `json:"DraftDynamicFormID"`
	FormName           string            `json:"FormName"`
	DesignP            *string           `json:"DesignP"`
	DesignL            *string           `json:"DesignL"`
	LastPublishedDate  *time.Time        `json:"LastPublishedDate"`
	Status             int               `json:"Status"`
	FormStatus         string            `json:"FormStatus"`
	Is4DPriceForm      bool              `json:"Is4DPriceForm"`
	IsBreakForm        bool              `json:"IsBreakForm"`
	FormUDFs           []FormUDFResponse `json:"FormUDFs"`
}

// TableName func
func (DraftDynamicForm) TableName() string {
	return "draftdynamicforms"
}

// BeforeCreate func
func (object *DraftDynamicForm) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
//func (object *DraftDynamicForm) BeforeUpdate(db *gorm.DB) (err error) {
//	TimeNow := time.Now()
//	object.ModifiedDate = &TimeNow
//}

// PassBodyJSONToModel func
func (object *DraftDynamicForm) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DraftDynamicFormID", JSONObject)
	if res != nil {
		object.DraftDynamicFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormName", JSONObject)
	if res != nil {
		object.FormName = val
	}
	val, res = services.ConvertJSONValueToVariable("FormStatus", JSONObject)
	if res != nil {
		object.FormStatus = val
	}
	val, res = services.ConvertJSONValueToVariable("DesignP", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignP = &valJSON
		} else {
			object.DesignP = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("DesignL", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignL = &valJSON
		} else {
			object.DesignL = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Is4DPriceForm", JSONObject)
	if res != nil {
		object.Is4DPriceForm, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsBreakForm", JSONObject)
	if res != nil {
		object.IsBreakForm, _ = strconv.ParseBool(val)
	}
	return
}
