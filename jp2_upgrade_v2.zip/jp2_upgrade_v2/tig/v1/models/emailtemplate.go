package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// EmailTemplate data
type EmailTemplate struct {
	EmailTemplateID     int        `gorm:"column:EmailTemplateID;primaryKey;autoIncrement;not null" json:"EmailTemplateID"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Name                string     `gorm:"column:Name" json:"Name"`
	Subject             string     `gorm:"column:Subject" json:"Subject"`
	TemplateVariableKey int        `gorm:"column:TemplateVariableKey" json:"TemplateVariableKey"`
	Body                string     `gorm:"column:Body" json:"Body"`
}

// EmailTemplateResponse data
type EmailTemplateResponse struct {
	EmailTemplateID         int    `json:"EmailTemplateID"`
	Name                    string `json:"Name"`
	Subject                 string `json:"Subject"`
	TemplateVariableKey     int    `json:"TemplateVariableKey"`
	TemplateVariableKeyName string `json:"TemplateVariableKeyName"`
	Body                    string `json:"Body"`
}

// TableName func
func (EmailTemplate) TableName() string {
	return "emailtemplates"
}

// BeforeCreate func
func (object *EmailTemplate) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *EmailTemplate) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *EmailTemplate) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("EmailTemplateID", JSONObject)
	if res != nil {
		vEmailTemplateID, sEmailTemplateID := strconv.Atoi(val)
		if sEmailTemplateID == nil {
			object.EmailTemplateID = vEmailTemplateID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("Subject", JSONObject)
	if res != nil {
		object.Subject = val
	}
	val, res = services.ConvertJSONValueToVariable("TemplateVariableKey", JSONObject)
	if res != nil {
		vTemplateVariableKey, sTemplateVariableKey := strconv.Atoi(val)
		if sTemplateVariableKey == nil {
			object.TemplateVariableKey = vTemplateVariableKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("Body", JSONObject)
	if res != nil {
		object.Body = val
	}
	return
}
