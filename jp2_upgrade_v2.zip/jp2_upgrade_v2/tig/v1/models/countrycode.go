package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// CountryCode data
type CountryCode struct {
	CountryCodeID  int        `gorm:"column:CountryCodeID;primaryKey"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	Country        string     `gorm:"column:Country"`
	CountryName    string     `gorm:"column:CountryName"`
	CountryCode    string     `gorm:"column:CountryCode" json:"CountryCode"`
	PhoneDigitsMin int        `gorm:"column:PhoneDigitsMin" json:"PhoneDigitsMin"`
	PhoneDigitsMax int        `gorm:"column:PhoneDigitsMax" json:"PhoneDigitsMax"`
}

// CountryCodeResponse data
type CountryCodeResponse struct {
	CountryCodeID  int    `json:"CountryCodeID"`
	Country        string `json:"Country"`
	CountryName    string `json:"CountryName"`
	CountryCode    string `json:"CountryCode"`
	PhoneDigitsMin int    `json:"PhoneDigitsMin"`
	PhoneDigitsMax int    `json:"PhoneDigitsMax"`
}

// TableName func
func (CountryCode) TableName() string {
	return "countrycodes"
}

// BeforeCreate func
func (object *CountryCode) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *CountryCode) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *CountryCode) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("CountryCodeID ", JSONObject)
	if res != nil {
		object.CountryCodeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Country", JSONObject)
	if res != nil {
		object.Country = val
	}
	val, res = services.ConvertJSONValueToVariable("CountryName", JSONObject)
	if res != nil {
		object.CountryName = val
	}
	val, res = services.ConvertJSONValueToVariable("CountryCode", JSONObject)
	if res != nil {
		object.CountryCode = val
	}
	val, res = services.ConvertJSONValueToVariable("PhoneDigitsMin", JSONObject)
	if res != nil {
		object.PhoneDigitsMin, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PhoneDigitsMax", JSONObject)
	if res != nil {
		object.PhoneDigitsMax, _ = strconv.Atoi(val)
	}
	return
}
