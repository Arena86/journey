package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AdvancedRating data
type AdvancedRating struct {
	AdvancedRatingID int        `gorm:"column:AdvancedRatingID;primaryKey"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobID            int        `gorm:"column:JobID" json:"JobID"`
	JobTaskID        int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	FormID           string     `gorm:"column:FormID" json:"FormID"`
	ButtonID         int        `gorm:"column:ButtonID" json:"ButtonID"`
	Comment          string     `gorm:"column:Comment" json:"Comment"`
	Rate             float64    `gorm:"column:Rate" json:"Rate"`
	IsReschedule     bool       `gorm:"column:IsReschedule" json:"IsReschedule"`
	RescheduleDate   *time.Time `gorm:"column:RescheduleDate" json:"RescheduleDate"`
	//Images           []Photo    `gorm:"foreignKey:RecordID;references:AdvancedRatingID" json:"Images"`
}

// AdvancedRatingResponse data
type AdvancedRatingResponse struct {
	AdvancedRatingID int     `json:"AdvancedRatingID"`
	JobID            int     `json:"JobID"`
	JobTaskID        int     `json:"JobTaskID"`
	FormID           string  `json:"FormID"`
	ButtonID         int     `json:"ButtonID"`
	Comment          string  `json:"Comment"`
	Rate             float64 `json:"Rate"`
	//Images           []PhotoResponse `json:"Images"`
}

// TableName func
func (AdvancedRating) TableName() string {
	return "advancedratings"
}

// BeforeCreate func
func (object *AdvancedRating) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AdvancedRating) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AdvancedRating) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AdvancedRatingID", JSONObject)
	if res != nil {
		object.AdvancedRatingID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormID", JSONObject)
	if res != nil {
		object.FormID = val
	}
	val, res = services.ConvertJSONValueToVariable("ButtonID", JSONObject)
	if res != nil {
		object.ButtonID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("Rate", JSONObject)
	if res != nil {
		object.Rate, _ = strconv.ParseFloat(val, 64)
	}
	/* val, res = services.ConvertJSONValueToVariable("Images", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			photos        = make([]Photo, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail Photo
					)
					detail.PassBodyJSONToModel(obj)
					for _, v := range object.Images {
						if v.PhotoID > 0 && detail.PhotoID == v.PhotoID {
							detail = v
							detail.PassBodyJSONToModel(obj)
							break
						}
					}
					photos = append(photos, detail)
				}
			}
		}
		object.Images = photos
	} */

	return
}
