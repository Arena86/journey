package models

// XeroEventResponse str
type XeroEventResponse struct {
	Events             []XeroEventItem `json:"events"`
	FirstEventSequence int             `json:"firstEventSequence"`
	LastEventSequence  int             `json:"lastEventSequence"`
	Entropy            string          `json:"entropy"`
}

// XeroEventItem str
type XeroEventItem struct {
	ResourceURL   string `json:"resourceUrl"`
	ResourceID    string `json:"resourceId"`
	EventDateUTC  string `json:"eventDateUtc"`
	EventType     string `json:"eventType"`
	EventCategory string `json:"eventCategory"`
	TenantID      string `json:"tenantId"`
	TenantType    string `json:"tenantType"`
}

// ProcessXeroResponse str
type ProcessXeroResponse struct {
	Status int
	Data   interface{}
	Msg    interface{}
}

// RefreshAccessTokenPOST str
type RefreshAccessTokenPOST struct {
	RefreshToken string `json:"refresh_token"`
}

// RetrieveAccessTokenPOST str
type RetrieveAccessTokenPOST struct {
	AuthorizationCode string `json:"authorization_code"`
}

// RetrieveAccessTokenResponse str
type RetrieveAccessTokenResponse struct {
	IDToken      string `json:"id_token"`
	AccessToken  string `json:"access_token"`
	ExpiresIn    int    `json:"expires_in"`
	TokenType    string `json:"token_type"`
	RefreshToken string `json:"refresh_token"`
	Scope        string `json:"scope"`
}

// XeroErrorResponse str
type XeroErrorResponse struct {
	Error string `json:"error"`
}

// XeroConnectionResponse str
type XeroConnectionResponse struct {
	ID             string `json:"id"`
	AuthEventID    string `json:"authEventId"`
	TenantID       string `json:"tenantId"`
	TenantType     string `json:"tenantType"`
	TenantName     string `json:"tenantName"`
	CreatedDateUtc string `json:"createdDateUtc"`
	UpdatedDateUtc string `json:"updatedDateUtc"`
}

// XeroErrorConnectionResponse str
type XeroErrorConnectionResponse struct {
	Type       string      `json:"Type"`
	Title      string      `json:"Title"`
	Status     int         `json:"Status"`
	Detail     string      `json:"Detail"`
	Instance   string      `json:"Instance"`
	Extensions interface{} `json:"Extensions"`
}

// XeroErrorPostResponse str
type XeroErrorPostResponse struct {
	ErrorNumber int         `json:"ErrorNumber"`
	Type        string      `json:"Type"`
	Message     string      `json:"Message"`
	Elements    interface{} `json:"Elements"`
}

// XeroErrorPostElementResponse str
type XeroErrorPostElementResponse struct {
	ValidationErrors []XeroErrorPostElementValidationErrorResponse
}

// XeroErrorPostElementValidationErrorResponse str
type XeroErrorPostElementValidationErrorResponse struct {
	Message string
}

// XeroTenantResponse str
type XeroTenantResponse struct {
	TenantID   string `json:"TenantId"`
	TenantName string `json:"TenantName"`
}

// XeroIntegrationStatus data
type XeroIntegrationStatus struct {
	IsActive                   bool   `json:"IsActive"`
	IsCreditNoteEnabled        bool   `json:"IsCreditNoteEnabled"`
	IsInvoiceEnabled           bool   `json:"IsInvoiceEnabled"`
	UseXeroPush                bool   `json:"UseXeroPush"`
	IntervalInSeconds          int    `json:"IntervalInSeconds"`
	IsPostAfterJobCompleted    bool   `json:"IsPostAfterJobCompleted"`
	PostedInvoiceStatus        string `json:"PostedInvoiceStatus"`
	InvoiceNumberGeneration    string `json:"InvoiceNumberGeneration"`
	InvoiceDueDate             int    `json:"InvoiceDueDate"`
	CreditNoteNumberGeneration string `json:"CreditNoteNumberGeneration"`
}

// XeroOrganisation data
type XeroOrganisation struct {
	Name      string `json:"Name"`
	ShortCode string `json:"ShortCode"`
}

// XeroBranding data
type XeroBranding struct {
	BrandingThemeID string `json:"BrandingThemeID"`
	Name            string `json:"Name"`
	Type            string `json:"Type"`
	SortOrder       int    `json:"SortOrder"`
}
