package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormCheckListQuestionGroup data
type FormCheckListQuestionGroup struct {
	FormCheckListQuestionGroupID string                  `gorm:"column:FormCheckListQuestionGroupID;primaryKey;not null"`
	CreatedBy                    int                     `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                  *time.Time              `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                   int                     `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                 *time.Time              `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                    bool                    `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                      bool                    `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                   bool                    `gorm:"column:IsArchived" json:"IsArchived"`
	FormCheckListID              int                     `gorm:"column:FormCheckListID" json:"FormCheckListID"`
	GroupName                    string                  `gorm:"column:GroupName" json:"GroupName"`
	Sort                         int                     `gorm:"column:Sort" json:"Sort"`
	Questions                    []FormCheckListQuestion `gorm:"foreignKey:FormCheckListQuestionGroupID;references:FormCheckListQuestionGroupID" json:"Questions"`
}

// FormCheckListQuestionGroupResponse data
type FormCheckListQuestionGroupResponse struct {
	FormCheckListQuestionGroupID string `json:"FormCheckListQuestionGroupID"`
	FormCheckListID              int    `json:"FormCheckListID"`
	GroupName                    string `json:"GroupName"`
	Sort                         int    `json:"Sort"`
}

// TableName func
func (FormCheckListQuestionGroup) TableName() string {
	return "formchecklistquestiongroups"
}

// BeforeCreate func
func (object *FormCheckListQuestionGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormCheckListQuestionGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormCheckListQuestionGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormCheckListQuestionGroupID", JSONObject)
	if res != nil {
		object.FormCheckListQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListID", JSONObject)
	if res != nil {
		object.FormCheckListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		object.Sort, _ = strconv.Atoi(val)
	}

	return
}
