package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Logo data
type Logo struct {
	LogoID        int        `gorm:"column:LogoID;primaryKey"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	LogoData      *string    `gorm:"column:LogoData" json:"LogoData"`
	ResizableArea bool       `gorm:"column:ResizableArea" json:"ResizableArea"`
	Width         int        `gorm:"column:Width" json:"Width"`
	Height        int        `gorm:"column:Height" json:"Height"`
}

// LogoResponse data
type LogoResponse struct {
	LogoID        int     `json:"LogoID"`
	LogoData      *string `json:"LogoData"`
	ResizableArea bool    `json:"ResizableArea"`
	Width         int     `json:"Width"`
	Height        int     `json:"Height"`
}

// TableName func
func (Logo) TableName() string {
	return "logos"
}

// BeforeCreate func
func (object *Logo) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Logo) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Logo) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("LogoID", JSONObject)
	if res != nil {
		object.LogoID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LogoData", JSONObject)
	if res != nil {
		logoData := val
		object.LogoData = &logoData
	} else {
		object.LogoData = nil
	}
	val, res = services.ConvertJSONValueToVariable("ResizableArea", JSONObject)
	if res != nil {
		object.ResizableArea, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Width", JSONObject)
	if res != nil {
		object.Width, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Height", JSONObject)
	if res != nil {
		object.Height, _ = strconv.Atoi(val)
	}
	return
}
