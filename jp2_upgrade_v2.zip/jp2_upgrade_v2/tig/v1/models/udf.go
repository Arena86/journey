package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// ClientTypeSTRING const
const ClientTypeSTRING = "string"

// ClientTypeINTEGER const
const ClientTypeINTEGER = "integer"

// ClientTypeDECIMAL const
const ClientTypeDECIMAL = "decimal"

// ClientTypeBOOLEAN const
const ClientTypeBOOLEAN = "boolean"

// ClientTypeDATE const
const ClientTypeDATE = "date"

// ClientTypeDATETIME const
const ClientTypeDATETIME = "datetime"

// ClientTypeTIME const
const ClientTypeTIME = "time"

// UDFQueryResponseValue func
type UDFQueryResponseValue struct {
	FieldName string
	Value     interface{}
}

// UDFQueryResponse func
type UDFQueryResponse struct {
	DataType string `json:"DataType"`
	DateType string `json:"DateType"`
	Value    []UDFQueryResponseValue
}

// UDFResponse str
type UDFResponse struct {
	UDFID           int                   `json:"UDFID"`
	TableNameObj    string                `json:"TableName"`
	DataField       string                `json:"DataField"`
	Label           string                `json:"Label"`
	DataType        string                `json:"DataType"`
	DefaultValue    string                `json:"DefaultValue"`
	MaxLength       int                   `json:"MaxLength"`
	IsRequired      bool                  `json:"IsRequired"`
	Widget          string                `json:"Widget"`
	Value           interface{}           `json:"Value"`
	Visible         bool                  `json:"Visible"`
	Sort            int                   `json:"Sort"`
	InSearch        bool                  `json:"InSearch"`
	InList          bool                  `json:"InList"`
	Options         string                `json:"Options"`
	UDFKey          string                `json:"UDFKey"`
	NumberPrecision int                   `json:"NumberPrecision"`
	DateType        string                `json:"DateType"`
	Alignment       string                `json:"Alignment"`
	AllowGrouping   bool                  `json:"AllowGrouping"`
	Translations    []TranslationResponse `json:"Translations"`
}

// UDF data
type UDF struct {
	UDFID           int        `gorm:"column:UDFID;primaryKey;autoIncrement;not null" json:"UDFID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TableNameObj    string     `gorm:"column:TableName" json:"TableName" validate:"required"`
	DataField       string     `gorm:"column:DataField" json:"DataField" validate:"required"`
	Label           string     `gorm:"column:Label" json:"Label"`
	DataType        string     `gorm:"column:DataType" json:"DataType" validate:"required"`
	DefaultValue    string     `gorm:"column:DefaultValue" json:"DefaultValue"`
	MaxLength       int        `gorm:"column:MaxLength" json:"MaxLength"`
	IsRequired      bool       `gorm:"column:IsRequired" json:"IsRequired"`
	Widget          string     `gorm:"column:Widget" json:"Widget"`
	Visible         bool       `gorm:"column:Visible" json:"Visible"`
	Sort            int        `gorm:"column:Sort" json:"Sort"`
	InSearch        bool       `gorm:"column:InSearch" json:"InSearch"`
	InList          bool       `gorm:"column:InList" json:"InList"`
	Options         string     `gorm:"column:Options" json:"Options"`
	UDFKey          string     `gorm:"column:UDFKey" json:"UDFKey" validate:"required"`
	NumberPrecision int        `gorm:"column:NumberPrecision" json:"NumberPrecision"`
	DateType        string     `gorm:"column:DateType" json:"DateType"`
	Alignment       string     `gorm:"column:Alignment" json:"Alignment"`
	AllowGrouping   bool       `gorm:"column:AllowGrouping" json:"AllowGrouping"`
}

// TableName func
func (UDF) TableName() string {
	return "udfs"
}

// BeforeCreate func
func (object *UDF) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *UDF) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *UDF) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("UDFID", JSONObject)
	if res != nil {
		vUDFID, sUDFID := strconv.Atoi(val)
		if sUDFID == nil {
			object.UDFID = vUDFID
		}
	}
	val, res = services.ConvertJSONValueToVariable("TableName", JSONObject)
	if res != nil {
		object.TableNameObj = val
	}
	val, res = services.ConvertJSONValueToVariable("DataField", JSONObject)
	if res != nil {
		object.DataField = services.ApplyFormatForDataField(val)
	}
	val, res = services.ConvertJSONValueToVariable("Label", JSONObject)
	if res != nil {
		object.Label = val
	}
	val, res = services.ConvertJSONValueToVariable("DataType", JSONObject)
	if res != nil {
		object.DataType = val
	}
	val, res = services.ConvertJSONValueToVariable("Widget", JSONObject)
	if res != nil {
		object.Widget = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultValue", JSONObject)
	if res != nil {
		object.DefaultValue = val
	}
	val, res = services.ConvertJSONValueToVariable("MaxLength", JSONObject)
	if res != nil {
		vMaxLength, sMaxLength := strconv.Atoi(val)
		if sMaxLength == nil {
			object.MaxLength = vMaxLength
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsRequired", JSONObject)
	if res != nil {
		object.IsRequired, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Visible", JSONObject)
	if res != nil {
		object.Visible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	val, res = services.ConvertJSONValueToVariable("InSearch", JSONObject)
	if res != nil {
		object.InSearch, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("InList", JSONObject)
	if res != nil {
		object.InList, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Options", JSONObject)
	if res != nil {
		object.Options = val
	}
	val, res = services.ConvertJSONValueToVariable("UDFKey", JSONObject)
	if res != nil {
		object.UDFKey = val
	}
	val, res = services.ConvertJSONValueToVariable("NumberPrecision", JSONObject)
	if res != nil {
		vNumberPrecision, sNumberPrecision := strconv.Atoi(val)
		if sNumberPrecision == nil {
			object.NumberPrecision = vNumberPrecision
		}
	}
	val, res = services.ConvertJSONValueToVariable("DateType", JSONObject)
	if res != nil {
		object.DateType = val
	}
	val, res = services.ConvertJSONValueToVariable("Alignment", JSONObject)
	if res != nil {
		object.Alignment = val
	}
	val, res = services.ConvertJSONValueToVariable("AllowGrouping", JSONObject)
	if res != nil {
		object.AllowGrouping, _ = strconv.ParseBool(val)
	}
	return
}

// PassBodyJSONToModelForUpdate func
func (object *UDF) PassBodyJSONToModelForUpdate(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("UDFID", JSONObject)
	if res != nil {
		vUDFID, sUDFID := strconv.Atoi(val)
		if sUDFID == nil {
			object.UDFID = vUDFID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Label", JSONObject)
	if res != nil {
		object.Label = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultValue", JSONObject)
	if res != nil {
		object.DefaultValue = val
	}
	val, res = services.ConvertJSONValueToVariable("IsRequired", JSONObject)
	if res != nil {
		object.IsRequired, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Visible", JSONObject)
	if res != nil {
		object.Visible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	val, res = services.ConvertJSONValueToVariable("InSearch", JSONObject)
	if res != nil {
		object.InSearch, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("InList", JSONObject)
	if res != nil {
		object.InList, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Options", JSONObject)
	if res != nil {
		object.Options = val
	}
	val, res = services.ConvertJSONValueToVariable("UDFKey", JSONObject)
	if res != nil {
		object.UDFKey = val
	}
	val, res = services.ConvertJSONValueToVariable("NumberPrecision", JSONObject)
	if res != nil {
		vNumberPrecision, sNumberPrecision := strconv.Atoi(val)
		if sNumberPrecision == nil {
			object.NumberPrecision = vNumberPrecision
		}
	}
	val, res = services.ConvertJSONValueToVariable("DateType", JSONObject)
	if res != nil {
		object.DateType = val
	}
	val, res = services.ConvertJSONValueToVariable("Alignment", JSONObject)
	if res != nil {
		object.Alignment = val
	}
	val, res = services.ConvertJSONValueToVariable("AllowGrouping", JSONObject)
	if res != nil {
		object.AllowGrouping, _ = strconv.ParseBool(val)
	}
	return
}

// GetSQLAlterNewField func
func GetSQLAlterNewField(udfModel UDF) string {
	sql := `ALTER TABLE `
	sql = sql + udfModel.TableNameObj + ` ADD `
	lowerCaseType := strings.ToLower(udfModel.DataType)
	maxLength := udfModel.MaxLength
	switch lowerCaseType {
	case ClientTypeSTRING:
		{
			if maxLength > 0 {
				sql = sql + ` ` + udfModel.DataField + ` ` + `varchar` + `(` + strconv.Itoa(maxLength) + `)`
			} else {
				sql = sql + ` ` + udfModel.DataField + ` ` + `varchar` + `(50)`
			}
			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	case ClientTypeINTEGER:
		{
			if maxLength > 0 {
				sql = sql + ` ` + udfModel.DataField + ` ` + `int` + `(` + strconv.Itoa(maxLength) + `)`
			} else {
				sql = sql + ` ` + udfModel.DataField + ` ` + `int` + ``
			}

			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	case ClientTypeDECIMAL:
		{
			sql = sql + ` ` + udfModel.DataField + ` ` + `decimal` + `(18,5)`
			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	case ClientTypeBOOLEAN:
		{
			sql = sql + ` ` + udfModel.DataField + ` ` + `tinyint(1)`
			if udfModel.DefaultValue != "" {
				hasDefaultValue := 0
				vDefaultValue, sDefaultValue := strconv.ParseBool(udfModel.DefaultValue)
				if sDefaultValue == nil {
					if vDefaultValue {
						hasDefaultValue = 1
					}
				}
				sql = sql + ` DEFAULT '` + strconv.Itoa(hasDefaultValue) + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	case ClientTypeDATE:
		{
			sql = sql + ` ` + udfModel.DataField + ` ` + `datetime`
			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	case ClientTypeDATETIME:
		{
			sql = sql + ` ` + udfModel.DataField + ` ` + `datetime`
			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	default:
		{
			sql = sql + ` ` + udfModel.DataField + ` ` + lowerCaseType
			if udfModel.DefaultValue != "" {
				sql = sql + ` DEFAULT '` + udfModel.DefaultValue + `'`
			} else {
				sql = sql + ` DEFAULT NULL`
			}
		}
	}
	sql = sql + `;`
	return sql
}
