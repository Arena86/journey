package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Phone data
type Phone struct {
	PhoneID      int        `gorm:"column:PhoneID;primaryKey;autoIncrement;not null" json:"PhoneID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	PhoneTypeID  int        `gorm:"column:PhoneTypeID" json:"PhoneTypeID"`
	CountryCode  string     `gorm:"column:CountryCode;type:varchar(10)" json:"CountryCode"`
	//AreaCode     string     `gorm:"column:AreaCode;type:varchar(10)" json:"PhoneNumber"`
	PhoneNumber string `gorm:"column:PhoneNumber;type:varchar(50)" json:"PhoneNumber"`
	Extension   string `gorm:"column:Extension;type:varchar(200)" json:"Extension"`
	IsArchived  bool   `gorm:"column:IsArchived" json:"IsArchived"`
	EntityID    int    `gorm:"column:EntityID" json:"EntityID"`
	Entity      string `gorm:"column:Entity" json:"Entity"`
	IsDefault   bool   `gorm:"column:IsDefault" json:"IsDefault"`
}

// PhoneResponse data
type PhoneResponse struct {
	PhoneID          int    `json:"PhoneID"`
	PhoneTypeID      int    `json:"PhoneTypeID"`
	PhoneTypeName    string `json:"PhoneTypeName"`
	CountryCode      string `json:"CountryCode"`
	PhoneNumber      string `json:"PhoneNumber" `
	Extension        string `json:"Extension"`
	EntityID         int    `json:"EntityID"`
	Entity           string `json:"Entity"`
	IsDeleted        bool   `json:"IsDeleted"`
	IsArchived       bool   `json:"IsArchived"`
	IsDepot          bool   `json:"IsDepot"`
	IsLocation       bool   `json:"IsLocation"`
	IsDefault        bool   `json:"IsDefault"`
	IsDefaultContact bool   `json:"IsDefaultContact"`
}

// PhonesRequest data
type PhonesRequest struct {
	PhoneRequest []PhoneResponse
}

// TableName func
func (Phone) TableName() string {
	return "phones"
}

// BeforeCreate func
func (object *Phone) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Phone) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Phone) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PhoneID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.PhoneID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("PhoneTypeID", JSONObject)
	if res != nil {
		vPhoneTypeID, sPhoneTypeID := strconv.Atoi(val)
		if sPhoneTypeID == nil {
			object.PhoneTypeID = vPhoneTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("CountryCode", JSONObject)
	if res != nil {
		object.CountryCode = val
	}
	val, res = services.ConvertJSONValueToVariable("PhoneNumber", JSONObject)
	if res != nil {
		object.PhoneNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("Extension", JSONObject)
	if res != nil {
		object.Extension = val
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDefaultContact", JSONObject)
	if res != nil {
		object.IsDefault, _ = strconv.ParseBool(val)
	}
	return
}
