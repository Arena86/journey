package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleInspectionHistory data
type VehicleInspectionHistory struct {
	VehicleInspectionHistoryID int                                `gorm:"column:VehicleInspectionHistoryID;primaryKey;autoIncrement;not null" json:"VehicleInspectionHistoryID"`
	CreatedBy                  int                                `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                *time.Time                         `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                 int                                `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate               *time.Time                         `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                  bool                               `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                    bool                               `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                 bool                               `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleInspectionID        int                                `gorm:"column:VehicleInspectionID" json:"VehicleInspectionID"`
	InspectionDate             *time.Time                         `gorm:"column:InspectionDate" json:"InspectionDate"`
	Odometer                   float64                            `gorm:"column:Odometer" json:"Odometer"`
	Rego                       string                             `gorm:"column:Rego" json:"Rego"`
	Comment                    string                             `gorm:"column:Comment" json:"Comment"`
	ResourceID                 int                                `gorm:"column:ResourceID" json:"ResourceID"`
	Questions                  []VehicleInspectionQuestionHistory `gorm:"foreignKey:VehicleInspectionHistoryID;references:VehicleInspectionHistoryID" json:"Questions"`
}

// VehicleInspectionHistoryResponse data
type VehicleInspectionHistoryResponse struct {
	VehicleInspectionHistoryID int                                        `json:"VehicleInspectionHistoryID"`
	VehicleInspectionID        int                                        `json:"VehicleInspectionID"`
	VehicleInspectionName      string                                     `json:"VehicleInspectionName"`
	InspectionDate             *time.Time                                 `json:"InspectionDate"`
	Comment                    string                                     `json:"Comment"`
	Rego                       string                                     `json:"Rego"`
	Odometer                   float64                                    `json:"Odometer"`
	ResourceID                 int                                        `json:"ResourceID"`
	ResourceCode               string                                     `json:"ResourceCode"`
	ResourceName               string                                     `json:"ResourceName"`
	Questions                  []VehicleInspectionQuestionHistoryResponse `json:"Questions"`
}

// TableName func
func (VehicleInspectionHistory) TableName() string {
	return "vehicleinspectionshistory"
}

// BeforeCreate func
func (object *VehicleInspectionHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleInspectionHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleInspectionHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionHistoryID", JSONObject)
	if res != nil {
		object.VehicleInspectionHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionID", JSONObject)
	if res != nil {
		object.VehicleInspectionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("Rego", JSONObject)
	if res != nil {
		object.Rego = val
	}
	val, res = services.ConvertJSONValueToVariable("Odometer", JSONObject)
	if res != nil {
		vOdometer, sOdometer := strconv.ParseFloat(val, 64)
		if sOdometer == nil {
			object.Odometer = vOdometer
		}
	}
	val, res = services.ConvertJSONValueToVariable("InspectionDate", JSONObject)
	if res != nil {
		vInspectionDate, sInspectionDate := services.ConvertStringToDateTime(val)
		if sInspectionDate == nil {
			object.InspectionDate = &vInspectionDate
		} else {
			if val == "" {
				object.InspectionDate = nil
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			questions     = make([]VehicleInspectionQuestionHistory, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						question VehicleInspectionQuestionHistory
					)
					question.PassBodyJSONToModel(obj)
					for _, v := range object.Questions {
						if v.VehicleInspectionQuestionHistoryID > 0 && question.VehicleInspectionQuestionHistoryID == v.VehicleInspectionQuestionHistoryID {
							question = v
							question.PassBodyJSONToModel(obj)
							break
						}
					}
					questions = append(questions, question)
				}
			}
		}
		object.Questions = questions
	}
	return
}
