package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Break data
type Break struct {
	BreakID             int        `gorm:"column:BreakID;primaryKey;autoIncrement;not null" json:"BreakID"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	UserID              int        `gorm:"column:UserID" json:"UserID"`
	JobTaskID           int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	FromDateTime        *time.Time `gorm:"column:FromDateTime" json:"FromDateTime"`
	ToDateTime          *time.Time `gorm:"column:ToDateTime" json:"ToDateTime"`
	TotalBreakInSeconds int        `gorm:"column:TotalBreakInSeconds" json:"TotalBreakInSeconds"`
	Closed              bool       `gorm:"column:Closed" json:"Closed"`
}

// BreakResponse data
type BreakResponse struct {
	BreakID             int        `json:"BreakID"`
	UserID              int        `json:"UserID"`
	JobTaskID           int        `json:"JobTaskID"`
	FromDateTime        *time.Time `json:"FromDateTime"`
	ToDateTime          *time.Time `json:"ToDateTime"`
	TotalBreakInSeconds int        `json:"TotalBreakInSeconds"`
	Closed              bool       `json:"Closed"`
}

// TableName func
func (Break) TableName() string {
	return "breaks"
}

// BeforeCreate func
func (object *Break) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Break) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Break) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("BreakID", JSONObject)
	if res != nil {
		object.BreakID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		object.UserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FromDateTime", JSONObject)
	if res != nil {
		vFromDateTime, sFromDateTime := services.ConvertStringToDateTime(val)
		if sFromDateTime == nil {
			object.FromDateTime = &vFromDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("ToDateTime", JSONObject)
	if res != nil {
		vToDateTime, sToDateTime := services.ConvertStringToDateTime(val)
		if sToDateTime == nil {
			object.ToDateTime = &vToDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("TotalBreakInSeconds", JSONObject)
	if res != nil {
		object.TotalBreakInSeconds, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Closed", JSONObject)
	if res != nil {
		object.Closed, _ = strconv.ParseBool(val)
	}
	return
}
