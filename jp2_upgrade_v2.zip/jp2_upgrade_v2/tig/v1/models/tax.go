package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Tax data
type Tax struct {
	TaxID        int        `gorm:"column:TaxID;primaryKey;autoIncrement;not null" json:"TaxID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TaxType      string     `gorm:"column:TaxType" json:"TaxType" validate:"required"`
	TaxName      string     `gorm:"column:TaxName" json:"TaxName" validate:"required"`
	TaxRate      float64    `gorm:"column:TaxRate" json:"TaxRate"`
}

// TaxResponse data
type TaxResponse struct {
	TaxID   int     `json:"TaxID"`
	TaxType string  `json:"TaxType"`
	TaxName string  `json:"TaxName"`
	TaxRate float64 `json:"TaxRate"`
}

// TableName func
func (Tax) TableName() string {
	return "taxes"
}

// BeforeCreate func
func (object *Tax) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Tax) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Tax) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TaxID", JSONObject)
	if res != nil {
		object.TaxID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaxType", JSONObject)
	if res != nil {
		object.TaxType = val
	}
	val, res = services.ConvertJSONValueToVariable("TaxName", JSONObject)
	if res != nil {
		object.TaxName = val
	}
	val, res = services.ConvertJSONValueToVariable("TaxRate", JSONObject)
	if res != nil {
		object.TaxRate, _ = strconv.ParseFloat(val, 64)
	}
	return
}
