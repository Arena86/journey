package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DistancePriceListDetail data
type DistancePriceListDetail struct {
	DistancePriceListDetailID int        `gorm:"column:DistancePriceListDetailID;primaryKey;autoIncrement;not null" json:"DistancePriceListDetailID"`
	CreatedBy                 int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DistancePriceListID       int        `gorm:"column:DistancePriceListID" json:"DistancePriceListID"`
	Description               string     `gorm:"column:Description" json:"Description"`
	FromUnit                  int        `gorm:"column:FromUnit" json:"FromUnit"`
	ToUnit                    int        `gorm:"column:ToUnit" json:"ToUnit"`
	Rate                      float64    `gorm:"column:Rate" json:"Rate"`
	IsRateByRange             bool       `gorm:"column:IsRateByRange" json:"IsRateByRange"`
	DiscountPercent           float64    `gorm:"column:DiscountPercent" json:"DiscountPercent"`
	BufferPercent             float64    `gorm:"column:BufferPercent" json:"BufferPercent"`
}

// DistancePriceListDetailResponse data
type DistancePriceListDetailResponse struct {
	DistancePriceListDetailID int     `json:"DistancePriceListDetailID"`
	DistancePriceListID       int     `json:"DistancePriceListID"`
	Description               string  `json:"Description"`
	FromUnit                  int     `json:"FromUnit"`
	ToUnit                    int     `json:"ToUnit"`
	Rate                      float64 `json:"Rate"`
	IsRateByRange             bool    `json:"IsRateByRange"`
	DiscountPercent           float64 `json:"DiscountPercent"`
	BufferPercent             float64 `json:"BufferPercent"`
}

// TableName func
func (DistancePriceListDetail) TableName() string {
	return "distancepricelistdetails"
}

// BeforeCreate func
func (object *DistancePriceListDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DistancePriceListDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DistancePriceListDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DistancePriceListDetailID", JSONObject)
	if res != nil {
		object.DistancePriceListDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DistancePriceListID", JSONObject)
	if res != nil {
		object.DistancePriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}
	val, res = services.ConvertJSONValueToVariable("FromUnit", JSONObject)
	if res != nil {
		object.FromUnit, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ToUnit", JSONObject)
	if res != nil {
		object.ToUnit, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Rate", JSONObject)
	if res != nil {
		object.Rate, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("IsRateByRange", JSONObject)
	if res != nil {
		object.IsRateByRange, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("DiscountPercent", JSONObject)
	if res != nil {
		object.DiscountPercent, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("BufferPercent", JSONObject)
	if res != nil {
		object.BufferPercent, _ = strconv.ParseFloat(val, 64)
	}
	return
}
