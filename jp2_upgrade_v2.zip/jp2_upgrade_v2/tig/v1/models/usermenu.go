package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// UserMenu data
type UserMenu struct {
	UserMenuID   int        `gorm:"column:UserMenuID;primaryKey;autoIncrement;not null" json:"UserMenuID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived"`
	UserID       int        `gorm:"column:UserID" json:"UserID"`
	MenuID       int        `gorm:"column:MenuID" json:"MenuID"`
}

// UserMenuResponse data
type UserMenuResponse struct {
	UserMenuID int `json:"UserMenuID"`
	UserID     int `json:"UserID"`
	MenuID     int `json:"MenuID"`
}

// TableName func
func (UserMenu) TableName() string {
	return "userdevicemenus"
}

// BeforeCreate func
func (object *UserMenu) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *UserMenu) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *UserMenu) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("UserMenuID", JSONObject)
	if res != nil {
		object.UserMenuID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		object.UserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("MenuID", JSONObject)
	if res != nil {
		object.MenuID, _ = strconv.Atoi(val)
	}
	return
}
