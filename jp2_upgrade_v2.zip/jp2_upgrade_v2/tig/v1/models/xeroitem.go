package models

import "gorm.io/gorm"

// XeroItemResponse str
type XeroItemResponse struct {
	ID           string `json:"Id"`
	Items        []XeroItem
	DateTimeUTC  string
	ProviderName string
	Status       string
}

// XeroItem str
type XeroItem struct {
	ItemID                    string
	Code                      string
	Name                      string
	IsPurchased               bool
	IsSold                    bool
	Description               string
	PurchaseDescription       string
	PurchaseDetails           XeroItemPurchaseDetail
	SalesDetails              XeroItemSalesDetail
	IsTrackedAsInventory      bool
	InventoryAssetAccountCode string
	TotalCostPool             float64
	QuantityOnHand            float64
	UpdatedDateUTC            string
	UnitPrice                 float64
	AccountCode               string
	COGSAccountCode           string
	TaxType                   string
}

// XeroItemPurchaseDetail str
type XeroItemPurchaseDetail struct {
	XeroItemDetail
}

// XeroItemSalesDetail str
type XeroItemSalesDetail struct {
	XeroItemDetail
}

// XeroItemDetail str
type XeroItemDetail struct {
	UnitPrice       float64
	AccountCode     string
	TaxType         string
	COGSAccountCode string
}

// ConvertXeroToDatabaseModel func
func (object *Item) ConvertXeroToDatabaseModel(xero XeroItem) {
	object.ErpKey = xero.ItemID
	object.Code = xero.Code
	object.Name = xero.Name
	object.Description = xero.Description
	object.IsTrackedAsInventory = xero.IsTrackedAsInventory
	if xero.IsTrackedAsInventory {
		object.ItemType = 1
	} else {
		object.ItemType = 2
	}
	object.UnitPrice = xero.SalesDetails.UnitPrice
	object.Cost = xero.PurchaseDetails.UnitPrice
	object.QuantityOnHand = xero.QuantityOnHand
	object.ItemPurchaseAccountCode = xero.PurchaseDetails.COGSAccountCode
	object.ItemSaleAccountCode = xero.SalesDetails.AccountCode
	object.InventoryAssetAccountCode = xero.InventoryAssetAccountCode
	return
}

// ConvertDatabaseModelToXero func
func (object *XeroItem) ConvertDatabaseModelToXero(db *gorm.DB, item Item, taxModel Tax) {
	object.ItemID = item.ErpKey
	object.Code = item.Code
	object.Name = item.Name
	object.Description = item.Description
	object.IsTrackedAsInventory = item.IsTrackedAsInventory
	object.SalesDetails.UnitPrice = item.UnitPrice
	if item.IsTrackedAsInventory {
		var (
			xeroConfig XeroConfig
		)
		resultFindXeroConfig := db.First(&xeroConfig)
		if resultFindXeroConfig.RowsAffected > 0 {
			object.InventoryAssetAccountCode = xeroConfig.InventoryAssetAccountCode
			object.PurchaseDetails.COGSAccountCode = xeroConfig.InventoryPurchaseAccountCode
		}
	}
	object.PurchaseDetails.UnitPrice = item.Cost
	object.QuantityOnHand = item.QuantityOnHand
	if taxModel.TaxID > 0 && taxModel.TaxType != "" {
		object.SalesDetails.TaxType = taxModel.TaxType
	}
}

// RemoveEmptyValueWhenPostToXeroItem func
func RemoveEmptyValueWhenPostToXeroItem(xeroModel XeroItem) map[string]interface{} {
	xero := make(map[string]interface{})
	if xeroModel.ItemID != "" {
		xero["ItemID"] = xeroModel.ItemID
	}
	if xeroModel.Code != "" {
		xero["Code"] = xeroModel.Code
	}
	if xeroModel.Name != "" {
		xero["Name"] = xeroModel.Name
	}
	xero["IsPurchased"] = true
	xero["IsSold"] = true
	if xeroModel.Description != "" {
		xero["Description"] = xeroModel.Description
	}
	if xeroModel.PurchaseDescription != "" {
		xero["PurchaseDescription"] = xeroModel.PurchaseDescription
	}

	purchaseDetails := make(map[string]interface{})
	if xeroModel.PurchaseDetails.UnitPrice >= 0 {
		purchaseDetails["UnitPrice"] = xeroModel.PurchaseDetails.UnitPrice
	}
	if xeroModel.PurchaseDetails.AccountCode != "" {
		purchaseDetails["AccountCode"] = xeroModel.PurchaseDetails.AccountCode
	}
	if xeroModel.PurchaseDetails.TaxType != "" {
		purchaseDetails["TaxType"] = xeroModel.PurchaseDetails.TaxType
	}
	if xeroModel.PurchaseDetails.COGSAccountCode != "" {
		purchaseDetails["COGSAccountCode"] = xeroModel.PurchaseDetails.COGSAccountCode
	}

	xero["PurchaseDetails"] = purchaseDetails
	//xero["PurchaseDetails"] = xeroModel.PurchaseDetails

	saleDetails := make(map[string]interface{})
	if xeroModel.SalesDetails.UnitPrice >= 0 {
		saleDetails["UnitPrice"] = xeroModel.SalesDetails.UnitPrice
	}
	if xeroModel.SalesDetails.AccountCode != "" {
		saleDetails["AccountCode"] = xeroModel.SalesDetails.AccountCode
	}
	if xeroModel.SalesDetails.TaxType != "" {
		saleDetails["TaxType"] = xeroModel.SalesDetails.TaxType
	}
	if xeroModel.SalesDetails.COGSAccountCode != "" {
		saleDetails["COGSAccountCode"] = xeroModel.SalesDetails.COGSAccountCode
	}
	xero["SalesDetails"] = saleDetails
	//xero["SalesDetails"] = xeroModel.SalesDetails

	xero["IsTrackedAsInventory"] = xeroModel.IsTrackedAsInventory
	if xeroModel.InventoryAssetAccountCode != "" {
		xero["InventoryAssetAccountCode"] = xeroModel.InventoryAssetAccountCode
	}
	xero["TotalCostPool"] = xeroModel.TotalCostPool
	xero["QuantityOnHand"] = xeroModel.QuantityOnHand
	xero["UnitPrice"] = xeroModel.UnitPrice
	if xeroModel.AccountCode != "" {
		xero["AccountCode"] = xeroModel.AccountCode
	}
	if xeroModel.COGSAccountCode != "" {
		xero["COGSAccountCode"] = xeroModel.COGSAccountCode
	}
	if xeroModel.TaxType != "" {
		xero["TaxType"] = xeroModel.TaxType
	}
	return xero
}
