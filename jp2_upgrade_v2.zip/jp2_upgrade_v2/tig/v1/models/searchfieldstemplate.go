package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SearchFieldsTemplate data
type SearchFieldsTemplate struct {
	SearchFieldTemplateID         int        `gorm:"column:SearchFieldTemplateID;primaryKey;autoIncrement;not null" json:"SearchFieldTemplateID"`
	CreatedBy                     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TableNameObj                  string     `gorm:"column:TableName" json:"TableName"`
	SearchFieldKey                string     `gorm:"column:SearchFieldKey" json:"SearchFieldKey"`
	Parameter                     string     `gorm:"column:Parameter" json:"Parameter"`
	Label                         string     `gorm:"column:Label" json:"Label"`
	MaxLength                     int        `gorm:"column:MaxLength" json:"MaxLength"`
	Widget                        string     `gorm:"column:Widget" json:"Widget"`
	Value                         string     `gorm:"column:Value" json:"Value"`
	Visible                       bool       `gorm:"column:Visible" json:"Visible"`
	Sort                          int        `gorm:"column:Sort" json:"Sort"`
	TranslationKey                string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	SearchFieldNameTranslationKey string     `gorm:"column:SearchFieldNameTranslationKey" json:"SearchFieldNameTranslationKey"`
	IsEnum                        bool       `gorm:"column:IsEnum" json:"IsEnum"`
	Options                       string     `gorm:"column:Options" json:"Options"`
	DateType                      string     `gorm:"column:DateType" json:"DateType"`
	Operator                      string     `gorm:"column:Operator" json:"Operator"`
}

// SearchFieldsTemplateResponse data
type SearchFieldsTemplateResponse struct {
	SearchFieldTemplateID int         `json:"SearchFieldTemplateID"`
	TableNameObj          string      `json:"TableName"`
	Parameter             string      `json:"Parameter"`
	Label                 string      `json:"Label"`
	MaxLength             int         `json:"MaxLength"`
	Widget                string      `json:"Widget"`
	Value                 interface{} `json:"Value"`
	Visible               bool        `json:"Visible"`
	Sort                  int         `json:"Sort"`
	Options               string      `json:"Options"`
	DataType              string      `json:"DataType"`
	NumberPrecision       int         `json:"NumberPrecision"`
	DataField             string      `json:"DataField"`
	Alignment             string      `json:"Alignment"`
	DateType              string      `json:"DateType"`
	SearchFieldName       string      `json:"SearchFieldName"`
	SearchFieldKey        string      `json:"SearchFieldKey"`
	Operator              string      `json:"Operator"`
}

// TableName func
func (SearchFieldsTemplate) TableName() string {
	return "searchfieldstemplates"
}

// BeforeCreate func
func (object *SearchFieldsTemplate) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SearchFieldsTemplate) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SearchFieldsTemplate) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SearchFieldTemplateID", JSONObject)
	if res != nil {
		vSearchFieldTemplateID, sSearchFieldTemplateID := strconv.Atoi(val)
		if sSearchFieldTemplateID == nil {
			object.SearchFieldTemplateID = vSearchFieldTemplateID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Value", JSONObject)
	if res != nil {
		object.Value = val
	}
	val, res = services.ConvertJSONValueToVariable("Operator", JSONObject)
	if res != nil {
		object.Operator = val
	}
	val, res = services.ConvertJSONValueToVariable("SearchFieldNameTranslationKey", JSONObject)
	if res != nil {
		object.SearchFieldNameTranslationKey = val
	}
	val, res = services.ConvertJSONValueToVariable("Visible", JSONObject)
	if res != nil {
		object.Visible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	return
}

// ConvertSearchFieldTemplatesToSearchField func
func ConvertSearchFieldTemplatesToSearchField(accountKey int, defaultSearchFieldTemplates []SearchFieldsTemplate) []SearchField {
	searchFields := make([]SearchField, 0)
	for _, dsft := range defaultSearchFieldTemplates {
		var searchField SearchField
		searchField.AccountKey = accountKey
		searchField.CreatedBy = accountKey
		searchField.ModifiedBy = accountKey
		searchField.SearchFieldKey = dsft.SearchFieldKey
		searchField.Parameter = dsft.Parameter
		searchField.TableNameObj = dsft.TableNameObj
		searchField.Label = dsft.Label
		searchField.MaxLength = dsft.MaxLength
		searchField.Widget = dsft.Widget
		searchField.Value = dsft.Value
		searchField.Visible = dsft.Visible
		searchField.Sort = dsft.Sort
		searchField.TranslationKey = dsft.TranslationKey
		searchField.IsEnum = dsft.IsEnum
		searchField.Options = dsft.Options
		searchField.DateType = dsft.DateType
		searchField.Operator = dsft.Operator
		searchFields = append(searchFields, searchField)
	}
	return searchFields
}
