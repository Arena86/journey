package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Job4DPrice data
type Job4DPrice struct {
	Job4DPriceID               int        `gorm:"column:Job4DPriceID;primaryKey;not null"`
	CreatedBy                  int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                 int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate               *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                  bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                    bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                 bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FourDPriceID               int        `gorm:"column:4DPriceID" json:"FourDPriceID"`
	JobID                      int        `gorm:"column:JobID" json:"JobID"`
	JobTaskID                  int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	ItemID                     int        `gorm:"column:ItemID" json:"ItemID"`
	SurchargeItemID            int        `gorm:"column:SurchargeItemID" json:"SurchargeItemID"`
	Dimension1                 string     `gorm:"column:Dimension1" json:"Dimension1"`
	Dimension2                 string     `gorm:"column:Dimension2" json:"Dimension2"`
	Dimension3                 string     `gorm:"column:Dimension3" json:"Dimension3"`
	Dimension4                 string     `gorm:"column:Dimension4" json:"Dimension4"`
	TriggerInspection          bool       `gorm:"column:TriggerInspection" json:"TriggerInspection"`
	TriggerInspectionCompleted bool       `gorm:"column:TriggerInspectionCompleted" json:"TriggerInspectionCompleted"`
	Key                        string     `gorm:"column:Key" json:"Key"`
	TriggerInspectionMode      *int       `gorm:"column:TriggerInspectionMode" json:"TriggerInspectionMode"`
}

// Job4DPriceResponse data
type Job4DPriceResponse struct {
	Job4DPriceID               int         `json:"Job4DPriceID"`
	FourDPriceID               int         `json:"FourDPriceID"`
	JobID                      int         `json:"JobID"`
	JobTaskID                  int         `json:"JobTaskID"`
	ItemID                     int         `json:"ItemID"`
	SurchargeItemID            int         `json:"SurchargeItemID"`
	Dimension1                 interface{} `json:"Dimension1"`
	Dimension2                 interface{} `json:"Dimension2"`
	Dimension3                 interface{} `json:"Dimension3"`
	Dimension4                 interface{} `json:"Dimension4"`
	TriggerInspection          bool        `json:"TriggerInspection"`
	TriggerInspectionCompleted bool        `json:"TriggerInspectionCompleted"`
	Key                        string      `json:"Key"`
	TriggerInspectionMode      *int        `json:"TriggerInspectionMode"`
	JobTaskType                int         `json:"JobTaskType"`
}

// InspectionJob4DPrice data
type InspectionJob4DPrice struct {
	Job4DPriceID               int         `json:"Job4DPriceID"`
	FourDPriceID               int         `json:"FourDPriceID"`
	JobID                      int         `json:"JobID"`
	JobTaskID                  int         `json:"JobTaskID"`
	ItemID                     int         `json:"ItemID"`
	SurchargeItemID            int         `json:"SurchargeItemID"`
	Dimension1                 interface{} `json:"Dimension1"`
	Dimension2                 interface{} `json:"Dimension2"`
	Dimension3                 interface{} `json:"Dimension3"`
	Dimension4                 interface{} `json:"Dimension4"`
	TriggerInspection          bool        `json:"TriggerInspection"`
	TriggerInspectionCompleted bool        `json:"TriggerInspectionCompleted"`
	Key                        string      `json:"Key"`
	TriggerInspectionMode      *int        `json:"TriggerInspectionMode"`
}

// TableName func
func (Job4DPrice) TableName() string {
	return "job4dprices"
}

// BeforeCreate func
func (object *Job4DPrice) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Job4DPrice) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Job4DPrice) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("Job4DPriceID", JSONObject)
	if res != nil {
		object.Job4DPriceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceID", JSONObject)
	if res != nil {
		object.FourDPriceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		object.ItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("SurchargeItemID", JSONObject)
	if res != nil {
		object.SurchargeItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension1", JSONObject)
	if res != nil {
		object.Dimension1 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension2", JSONObject)
	if res != nil {
		object.Dimension2 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension3", JSONObject)
	if res != nil {
		object.Dimension3 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension4", JSONObject)
	if res != nil {
		object.Dimension4 = val
	}
	val, res = services.ConvertJSONValueToVariable("TriggerInspection", JSONObject)
	if res != nil {
		object.TriggerInspection, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TriggerInspectionCompleted", JSONObject)
	if res != nil {
		object.TriggerInspectionCompleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Key", JSONObject)
	if res != nil {
		object.Key = val
	}
	val, res = services.ConvertJSONValueToVariable("TriggerInspectionMode", JSONObject)
	if res != nil {
		vTriggerInspectionMode, sTriggerInspectionMode := strconv.Atoi(val)
		if sTriggerInspectionMode == nil {
			object.TriggerInspectionMode = &vTriggerInspectionMode
		}
	}
	return
}
