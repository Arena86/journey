package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SupportAccess data
type SupportAccess struct {
	SupportAccessID int        `gorm:"column:SupportAccessID;primaryKey;autoIncrement;not null" json:"SupportAccessID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FirstName       string     `gorm:"column:FirstName" json:"FirstName"`
	LastName        string     `gorm:"column:LastName" json:"LastName"`
	DateTime        *time.Time `gorm:"column:DateTime" json:"DateTime"`
	Type            string     `gorm:"column:Type" json:"Type"`
	ClientOffSet    int        `gorm:"column:ClientOffSet" json:"ClientOffSet"`
}

// SupportAccessResponse data
type SupportAccessResponse struct {
	SupportAccessID int        `json:"SupportAccessID"`
	FirstName       string     `json:"FirstName"`
	LastName        string     `json:"LastName"`
	DateTime        *time.Time `json:"DateTime"`
	Type            string     `json:"Type"`
	ClientOffSet    int        `json:"ClientOffSet"`
}

// TableName func
func (SupportAccess) TableName() string {
	return "supportaccess"
}

// BeforeCreate func
func (object *SupportAccess) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SupportAccess) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SupportAccess) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SupportAccessID", JSONObject)
	if res != nil {
		object.SupportAccessID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FirstName", JSONObject)
	if res != nil {
		object.FirstName = val
	}
	val, res = services.ConvertJSONValueToVariable("LastName", JSONObject)
	if res != nil {
		object.LastName = val
	}
	val, res = services.ConvertJSONValueToVariable("DateTime", JSONObject)
	if res != nil {
		vDateTime, sDateTime := services.ConvertStringToDateTime(val)
		if sDateTime == nil {
			object.DateTime = &vDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("Type", JSONObject)
	if res != nil {
		object.Type = val
	}
	val, res = services.ConvertJSONValueToVariable("ClientOffSet", JSONObject)
	if res != nil {
		object.ClientOffSet, _ = strconv.Atoi(val)
	}
	return
}
