package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PrefixResponse data
type PrefixResponse struct {
	PrefixID         int    `json:"PrefixID"`
	DocumentSequence string `json:"DocumentSequence"`
	Prefix           string `json:"Prefix"`
	Length           int    `json:"Length"`
}

// Prefix data
type Prefix struct {
	PrefixID         int        `gorm:"column:PrefixID;primaryKey;autoIncrement;not null"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DocumentSequence string     `gorm:"column:DocumentSequence" json:"DocumentSequence"`
	Prefix           string     `gorm:"column:Prefix" json:"Prefix" validate:"max=5,min=1"`
	Length           int        `gorm:"column:Length" json:"Length" validate:"max=10,min=5"`
}

// TableName func
func (Prefix) TableName() string {
	return "prefixes"
}

// BeforeCreate func
func (object *Prefix) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Prefix) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Prefix) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PrefixID", JSONObject)
	if res != nil {
		object.PrefixID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DocumentSequence", JSONObject)
	if res != nil {
		object.DocumentSequence = val
	}
	val, res = services.ConvertJSONValueToVariable("Prefix", JSONObject)
	if res != nil {
		object.Prefix = val
	}
	val, res = services.ConvertJSONValueToVariable("Length", JSONObject)
	if res != nil {
		object.Length, _ = strconv.Atoi(val)
	}
	return
}

// PUTPassBodyJSONToModel func
func (object *Prefix) PUTPassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PrefixID", JSONObject)
	if res != nil {
		object.PrefixID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Prefix", JSONObject)
	if res != nil {
		object.Prefix = val
	}
	val, res = services.ConvertJSONValueToVariable("Length", JSONObject)
	if res != nil {
		object.Length, _ = strconv.Atoi(val)
	}
	return
}
