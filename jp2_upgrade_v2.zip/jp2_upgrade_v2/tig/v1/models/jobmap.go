package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobMap data
type JobMap struct {
	JobMapID     int        `gorm:"column:JobMapID;primaryKey;autoIncrement;not null" json:"JobMapID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	JobID        int        `gorm:"column:JobID"`
	JobMapImage  string     `gorm:"column:JobMapImage;" json:"JobMapImage"`
}

// JobMapImageResponse data
type JobMapImageResponse struct {
	JobMapID    int    `json:"JobMapID"`
	JobID       string `json:"JobID"`
	JobMapImage *int   `json:"JobMapImage"`
}

// TableName func
func (JobMap) TableName() string {
	return "jobmaps"
}

// BeforeCreate func
func (object *JobMap) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobMap) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobMap) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobMapID", JSONObject)
	if res != nil {
		vJobMapID, sJobMapID := strconv.Atoi(val)
		if sJobMapID == nil {
			object.JobMapID = vJobMapID
		}
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		vJobID, sJobID := strconv.Atoi(val)
		if sJobID == nil {
			object.JobID = vJobID
		}
	}

	val, res = services.ConvertJSONValueToVariable("JobMapImage", JSONObject)
	if res != nil {
		object.JobMapImage = val
	}
	return
}
