package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobFileConfig data
type JobFileConfig struct {
	JobFileConfigKey  int        `gorm:"column:JobFileConfigKey;primaryKey;autoIncrement;not null"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived        bool       `gorm:"column:IsArchived" json:"IsArchived"`
	APIURL            string     `gorm:"column:APIURL" json:"APIURL"`
	UserName          string     `gorm:"column:UserName" json:"UserName"`
	Password          string     `gorm:"column:Password" json:"Password"`
	IsActive          bool       `gorm:"column:IsActive" json:"IsActive"`
	IntervalInSeconds int        `gorm:"column:IntervalInSeconds" json:"IntervalInSeconds"`
	ExportQueueID     int        `gorm:"column:ExportQueueID" json:"ExportQueueID"`
	AccessToken       string     `gorm:"column:AccessToken" json:"AccessToken"`
}

// JobFileConfigResponse data
type JobFileConfigResponse struct {
	JobFileConfigKey  int    `json:"JobFileConfigKey"`
	APIURL            string `json:"APIURL"`
	UserName          string `json:"UserName"`
	Password          string `json:"Password"`
	IsActive          bool   `json:"IsActive"`
	IntervalInSeconds int    `json:"IntervalInSeconds"`
}

// TableName func
func (JobFileConfig) TableName() string {
	return "jobfileconfig"
}

// BeforeCreate func
func (object *JobFileConfig) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobFileConfig) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobFileConfig) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobFileConfigKey", JSONObject)
	if res != nil {
		object.JobFileConfigKey, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("APIURL", JSONObject)
	if res != nil {
		object.APIURL = val
	}
	val, res = services.ConvertJSONValueToVariable("UserName", JSONObject)
	if res != nil {
		object.UserName = val
	}
	val, res = services.ConvertJSONValueToVariable("Password", JSONObject)
	if res != nil {
		object.Password = val
	}
	val, res = services.ConvertJSONValueToVariable("IsActive", JSONObject)
	if res != nil {
		object.IsActive, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IntervalInSeconds", JSONObject)
	if res != nil {
		object.IntervalInSeconds, _ = strconv.Atoi(val)
	}

	return
}
