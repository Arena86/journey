package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobSearchField data
type JobSearchField struct {
	JobSearchFieldID int        `gorm:"column:JobSearchFieldID;primaryKey;autoIncrement;not null" json:"JobSearchFieldID"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FieldName        string     `gorm:"column:FieldName" json:"FieldName"`
	Caption          string     `gorm:"column:Caption" json:"Caption"`
	TranslationKey   string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	IsSelected       bool       `gorm:"column:IsSelected" json:"IsSelected"`
}

// JobSearchFieldResponse data
type JobSearchFieldResponse struct {
	JobSearchFieldID int    `json:"JobSearchFieldID"`
	FieldName        string `json:"FieldName"`
	Caption          string `json:"Caption"`
	IsSelected       bool   `json:"IsSelected"`
}

// TableName func
func (JobSearchField) TableName() string {
	return "jobsearchfields"
}

// BeforeCreate func
func (object *JobSearchField) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobSearchField) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobSearchField) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobSearchFieldID", JSONObject)
	if res != nil {
		object.JobSearchFieldID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsSelected", JSONObject)
	if res != nil {
		object.IsSelected, _ = strconv.ParseBool(val)
	}
	return
}
