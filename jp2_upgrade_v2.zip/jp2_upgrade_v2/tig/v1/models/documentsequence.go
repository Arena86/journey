package models

import (
	"time"

	"gorm.io/gorm"
)

// JobNumber const
const JobNumber = "JobNumber"

// EstimateNumber const
const EstimateNumber = "EstimateNumber"

// InvoiceNumber const
const InvoiceNumber = "InvoiceNumber"

// CreditNoteNumber const
const CreditNoteNumber = "CreditNoteNumber"

// DocumentSequency data
type DocumentSequency struct {
	DocumentSequenceID int        `gorm:"column:DocumentSequenceID;primaryKey;autoIncrement;not null"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobNumber          int        `gorm:"column:JobNumber" json:"JobNumber"`
	EstimateNumber     int        `gorm:"column:EstimateNumber" json:"EstimateNumber"`
	InvoiceNumber      int        `gorm:"column:InvoiceNumber" json:"InvoiceNumber"`
	CreditNoteNumber   int        `gorm:"column:CreditNoteNumber" json:"CreditNoteNumber"`
	CustomerCode       int        `gorm:"column:CustomerCode" json:"CustomerCode"`
	VendorCode         int        `gorm:"column:VendorCode" json:"VendorCode"`
	ContractorCode     int        `gorm:"column:ContractorCode" json:"ContractorCode"`
	ResourceCode       int        `gorm:"column:ResourceCode" json:"ResourceCode"`
}

// DocumentSequencyResponse data
type DocumentSequencyResponse struct {
	DocumentSequenceID int `json:"DocumentSequenceID"`
	JobNumber          int `json:"JobNumber"`
	EstimateNumber     int `json:"EstimateNumber"`
	InvoiceNumber      int `json:"InvoiceNumber"`
	CreditNoteNumber   int `json:"CreditNoteNumber"`
	CustomerCode       int `json:"CustomerCode"`
	VendorCode         int `json:"VendorCode"`
	ContractorCode     int `json:"ContractorCode"`
	ResourceCode       int `json:"ResourceCode"`
}

// TableName func
func (DocumentSequency) TableName() string {
	return "documentsequences"
}

// BeforeCreate func
func (object *DocumentSequency) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DocumentSequency) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DocumentSequency) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	/* var (
		res interface{}
		val string
	) */

	return
}
