package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// LegalDocument data
type LegalDocument struct {
	LegalDocumentID int        `gorm:"column:LegalDocumentID;primaryKey"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Name            string     `gorm:"column:Name" json:"Name"`
	DisplayName     string     `gorm:"column:DisplayName" json:"DisplayName"`
	Content         string     `gorm:"column:Content" json:"Content"`
	TranslationKey  string     `gorm:"column:TranslationKey" json:"TranslationKey"`
}

// LegalDocumentResponse data
type LegalDocumentResponse struct {
	LegalDocumentID int    `json:"LegalDocumentID"`
	Name            string `json:"Name"`
	DisplayName     string `json:"DisplayName"`
	Content         string `json:"Content"`
}

// TableName func
func (LegalDocument) TableName() string {
	return "legaldocuments"
}

// BeforeCreate func
func (object *LegalDocument) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *LegalDocument) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *LegalDocument) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("LegalDocumentID", JSONObject)
	if res != nil {
		object.LegalDocumentID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("DisplayName", JSONObject)
	if res != nil {
		object.DisplayName = val
	}
	val, res = services.ConvertJSONValueToVariable("Content", JSONObject)
	if res != nil {
		object.Content = val
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	return
}
