package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormFlow data
type FormFlow struct {
	FormFlowID        int             `gorm:"column:FormFlowID;primaryKey;not null"`
	CreatedBy         int             `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time      `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int             `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time      `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool            `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool            `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived        bool            `gorm:"column:IsArchived"`
	FormFlowName      string          `gorm:"column:FormFlowName"`
	FormFlow          *string         `gorm:"column:FormFlow"`
	Navigation        *string         `gorm:"column:Navigation"`
	AdvancedForms     *string         `gorm:"column:AdvancedForms"`
	SubFormFlows      *string         `gorm:"column:SubFormFlows"`
	FormConditions    []FormCondition `gorm:"foreignKey:FormFlowID;references:FormFlowID" json:"FormConditions"`
	LastPublishedDate *time.Time      `gorm:"column:LastPublishedDate" json:"LastPublishedDate"`
}

// FormFlowResponse data
type FormFlowResponse struct {
	FormFlowID        int                     `json:"FormFlowID"`
	FormFlowName      string                  `json:"FormFlowName"`
	FormFlow          *string                 `json:"FormFlow"`
	Navigation        *string                 `json:"Navigation"`
	AdvancedForms     *string                 `json:"AdvancedForms"`
	SubFormFlows      *string                 `json:"SubFormFlows"`
	FormConditions    []FormConditionResponse `json:"FormConditions"`
	LastPublishedDate *time.Time              `json:"LastPublishedDate"`
}

// FormFlowResponseMaster data
type FormFlowResponseMaster struct {
	FormFlowID   int    `json:"FormFlowID"`
	FormFlowName string `json:"FormFlowName"`
}

// TableName func
func (FormFlow) TableName() string {
	return "formflows"
}

// BeforeCreate func
func (object *FormFlow) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormFlow) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormFlow) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormFlowID", JSONObject)
	if res != nil {
		object.FormFlowID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowName", JSONObject)
	if res != nil {
		object.FormFlowName = val
	}
	val, res = services.ConvertJSONValueToVariable("FormFlow", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.FormFlow = &valJSON
		} else {
			object.FormFlow = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Navigation", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.Navigation = &valJSON
		} else {
			object.Navigation = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("AdvancedForms", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.AdvancedForms = &valJSON
		} else {
			object.AdvancedForms = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("SubFormFlows", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.SubFormFlows = &valJSON
		} else {
			object.SubFormFlows = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("FormConditions", JSONObject)
	if res != nil {
		var (
			details       []FormCondition
			objectDetails []map[string]interface{}
		)
		details = make([]FormCondition, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail FormCondition
					)
					detail.PassBodyJSONToModel(obj)
					details = append(details, detail)
				}
			}
		}
		object.FormConditions = details
	}

	return
}

// ConvertDraftToFormFlow func
func (object *FormFlow) ConvertDraftToFormFlow(draft DraftFormFlow) {
	object.FormFlowID = draft.DraftFormFlowID
	object.FormFlowName = draft.DraftFormFlowName
	object.FormFlow = draft.DraftFormFlow
	object.Navigation = draft.DraftNavigation
	object.AdvancedForms = draft.AdvancedForms
	object.SubFormFlows = draft.SubFormFlows
	return
}
