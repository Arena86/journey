package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PEDSerie data
type PEDSerie struct {
	PEDSerieID   int              `gorm:"column:PEDSerieID;primaryKey;autoIncrement;not null"`
	CreatedBy    int              `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time       `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int              `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time       `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool             `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool             `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool             `gorm:"column:IsArchived" json:"IsArchived"`
	Name         string           `gorm:"column:Name" json:"Name"`
	SerieDetails []PEDSerieDetail `gorm:"foreignKey:PEDSerieID;references:PEDSerieID" json:"SerieDetails"`
}

// PEDSerieResponse data
type PEDSerieResponse struct {
	PEDSerieID   int                      `json:"PEDSerieID"`
	Name         string                   `json:"Name"`
	SerieDetails []PEDSerieDetailResponse `json:"SerieDetails"`
}

// TableName func
func (PEDSerie) TableName() string {
	return "pedseries"
}

// BeforeCreate func
func (object *PEDSerie) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PEDSerie) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PEDSerie) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PEDSerieID", JSONObject)
	if res != nil {
		object.PEDSerieID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("SerieDetails", JSONObject)
	if res != nil {
		var (
			details       []PEDSerieDetail
			objectDetails []map[string]interface{}
		)
		details = make([]PEDSerieDetail, 0)
		detailsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(detailsJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, objDetail := range objectDetails {
					var (
						detail PEDSerieDetail
					)
					detail.PassBodyJSONToModel(objDetail)
					for _, v := range object.SerieDetails {
						if detail.PEDSerieDetailID == v.PEDSerieDetailID {
							detail = v
							detail.PassBodyJSONToModel(objDetail)
							break
						}
					}
					details = append(details, detail)
				}
			}
		}
		object.SerieDetails = details
	}
	return
}
