package models

// JobFormNavigationResponse str
type JobFormNavigationResponse struct {
	HasPayment bool                `json:"HasPayment"`
	Tasks      []JobFormNavigation `json:"Tasks"`
}

// JobFormNavigation str
type JobFormNavigation struct {
	Task       JobFormNavigationTask      `json:"Task"`
	Forms      []JobFormNavigationForm    `json:"Forms"`
	BreakForms []BreakFormsNavigationForm `json:"BreakForms"`
}

// JobFormNavigationTask str
type JobFormNavigationTask struct {
	TaskID      int    `json:"TaskID"`
	JobType     int    `json:"JobType"`
	JobTypeName string `json:"JobTypeName"`
}

// JobFormNavigationForm str
type JobFormNavigationForm struct {
	Form         string `json:"Form"`
	OriginalForm int    `json:"OriginalForm"`
	FormTitle    string `json:"FormTitle"`
	Sort         int    `json:"Sort"`
}

// BreakFormsNavigationForm str
type BreakFormsNavigationForm struct {
	Form         string `json:"Form"`
	OriginalForm int    `json:"OriginalForm"`
	FormTitle    string `json:"FormTitle"`
	Sort         int    `json:"Sort"`
	Type         string `json:"Type"`
}

// FormFlowNavigation str
type FormFlowNavigation struct {
	ToForm   string `json:"toForm"`
	FromForm string `json:"fromForm"`
}
