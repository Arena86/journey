package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DeviceStatus data
type DeviceStatus struct {
	DeviceStatusID int        `gorm:"column:DeviceStatusID;primaryKey"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	UserID         int        `gorm:"column:UserID" json:"UserID"`
	ScheduleDate   *time.Time `gorm:"column:ScheduleDate" json:"ScheduleDate"`
	Value          string     `gorm:"column:Value" json:"Value"`
}

// DeviceStatusResponse data
type DeviceStatusResponse struct {
	UserID       int        `json:"UserID"`
	Value        string     `json:"Value"`
	ScheduleDate *time.Time `json:"ScheduleDate"`
}

// TableName func
func (DeviceStatus) TableName() string {
	return "devicestatus"
}

// BeforeCreate func
func (object *DeviceStatus) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DeviceStatus) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DeviceStatus) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DeviceStatusID", JSONObject)
	if res != nil {
		vAddressTypeID, sAddressTypeID := strconv.Atoi(val)
		if sAddressTypeID == nil {
			object.DeviceStatusID = vAddressTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		vUserID, sUserID := strconv.Atoi(val)
		if sUserID == nil {
			object.UserID = vUserID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Value", JSONObject)
	if res != nil {
		object.Value = val
	}
	val, res = services.ConvertJSONValueToVariable("ScheduleDate", JSONObject)
	if res != nil {
		vScheduleDate, sScheduleDate := services.ConvertStringToDateTime(val)
		if sScheduleDate == nil {
			object.ScheduleDate = &vScheduleDate
		}
	}
	return
}
