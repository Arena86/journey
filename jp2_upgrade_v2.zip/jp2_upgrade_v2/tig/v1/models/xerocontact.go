package models

import (
	"encoding/json"
	"strings"

	"gorm.io/gorm"
)

// XeroContactResponse str
type XeroContactResponse struct {
	ID           string `json:"Id"`
	Contacts     []XeroContact
	DateTimeUTC  string
	ProviderName string
	Status       string
}

// XeroContact str
type XeroContact struct {
	ContactID                 string
	ContactStatus             string
	Name                      string
	FirstName                 string
	LastName                  string
	EmailAddress              string
	SkypeUserName             string
	BankAccountDetails        string
	TaxNumber                 string
	AccountsReceivableTaxType string
	AccountsPayableTaxType    string
	Addresses                 []XeroContactAddress
	Phones                    []XeroContactPhone
	UpdatedDateUTC            string
	IsSupplier                bool
	IsCustomer                bool
	DefaultCurrency           string
}

// XeroContactAddress str
type XeroContactAddress struct {
	AddressType  string
	AddressLine1 string
	AddressLine2 string
	AddressLine3 string
	AddressLine4 string
	City         string
	Region       string
	PostalCode   string
	Country      string
	AttentionTo  string
}

// XeroContactPhone str
type XeroContactPhone struct {
	PhoneType        string
	PhoneNumber      string
	PhoneAreaCode    string
	PhoneCountryCode string
}

// ConvertXeroToDatabaseModel func
func (object *BusinessPartner) ConvertXeroToDatabaseModel(db *gorm.DB, accountKey int, xero XeroContact) {
	object.ErpKey = xero.ContactID
	object.CompanyName = xero.Name
	object.FirstName = xero.FirstName
	object.LastName = xero.LastName
	object.EmailAddress = xero.EmailAddress
	object.TaxNumber = xero.TaxNumber
	object.DefaultCurrency = xero.DefaultCurrency
	object.IsCustomer = xero.IsCustomer
	object.IsVendor = xero.IsSupplier
	object.IsContractor = xero.IsSupplier

	if !xero.IsSupplier {
		object.IsCustomer = true
	}
	addresses := make([]Address, 0)
	if len(xero.Addresses) > 0 {
		for _, a := range xero.Addresses {
			var address Address
			var addressType AddressType
			resultFindAddressTypeID := db.Where("AddressTypeName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Erp = ?", a.AddressType, "xero").First(&addressType)
			if resultFindAddressTypeID.RowsAffected <= 0 {
				addressType.AddressTypeName = a.AddressType
				addressType.ERP = "xero"
				addressType.IsDefault = true
				addressType.CreatedBy = accountKey
				addressType.ModifiedBy = accountKey
				db.Create(&addressType)
			}
			for _, pbAddress := range object.Addresses {
				if pbAddress.AddressTypeID == addressType.AddressTypeID {
					address = pbAddress
					break
				}
			}
			address.Entity = BusinessPartner{}.TableName()
			address.AddressLine1 = a.AddressLine1
			address.AddressLine2 = a.AddressLine2
			address.AddressLine3 = a.AddressLine3
			address.AddressLine4 = a.AddressLine4
			address.City = a.City
			address.State = a.Region
			address.PostalCode = a.PostalCode
			address.Country = a.Country
			address.AttentionTo = a.AttentionTo
			address.AddressTypeID = addressType.AddressTypeID
			if addressType.AddressTypeName == "STREET" {
				address.IsDepot = true
			}
			if addressType.AddressTypeName == "POBOX" {
				address.IsBilling = true
			}
			addresses = append(addresses, address)
		}
	}
	object.Addresses = addresses
	phones := make([]Phone, 0)
	if len(xero.Phones) > 0 {
		for _, p := range xero.Phones {
			var phone Phone
			var phoneType PhoneType
			resultFindPhoneTypeID := db.Where("PhoneTypeName = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Erp = ?", p.PhoneType, "xero").First(&phoneType)
			if resultFindPhoneTypeID.RowsAffected <= 0 {
				phoneType.PhoneTypeName = p.PhoneType
				phoneType.ERP = "xero"
				phone.IsDefault = true
				phoneType.CreatedBy = accountKey
				phoneType.ModifiedBy = accountKey
				db.Create(&phoneType)
			}
			for _, pbPhone := range object.Phones {
				if pbPhone.PhoneTypeID == phoneType.PhoneTypeID {
					phone = pbPhone
					break
				}
			}
			phone.Entity = BusinessPartner{}.TableName()
			// @TODO Calculate Phone Number
			// if phonenumber has error then => update extension field
			// if not map get default from setting to update CountryCode
			sCalculate, newCountryCode, newPhoneNumber := CalculatePhoneNumberFunc(db, p)
			if sCalculate {
				phone.PhoneNumber = newPhoneNumber
				phone.CountryCode = newCountryCode
				//phone.AreaCode = p.PhoneAreaCode
			} else {
				//phone.PhoneNumber = p.PhoneNumber
				phone.PhoneNumber = ""
				phone.CountryCode = p.PhoneCountryCode
				//phone.AreaCode = p.PhoneAreaCode
				phone.Extension = p.PhoneAreaCode + p.PhoneNumber
			}

			phone.PhoneTypeID = phoneType.PhoneTypeID
			if phoneType.PhoneTypeName == "MOBILE" {
				phone.IsDefault = true
			}
			phones = append(phones, phone)
		}
	}
	object.Phones = phones
	return
}

// ConvertDatabaseModelToXero func
func (object *XeroContact) ConvertDatabaseModelToXero(db *gorm.DB, item BusinessPartner) {
	object.ContactID = item.ErpKey
	object.Name = item.CompanyName
	object.FirstName = item.FirstName
	object.LastName = item.LastName
	object.EmailAddress = item.EmailAddress
	object.TaxNumber = item.TaxNumber
	object.DefaultCurrency = item.DefaultCurrency
	object.IsCustomer = item.IsCustomer
	if item.IsVendor || item.IsContractor {
		object.IsSupplier = true
	} else {
		object.IsSupplier = false
	}
	addresses := make([]XeroContactAddress, 0)
	if len(item.Addresses) > 0 {
		for _, a := range item.Addresses {
			var address XeroContactAddress
			address.AddressLine1 = a.AddressLine1
			address.AddressLine2 = a.AddressLine2
			address.AddressLine3 = a.AddressLine3
			address.AddressLine4 = a.AddressLine4
			address.City = a.City
			address.Region = a.State
			address.PostalCode = a.PostalCode
			address.Country = a.Country
			address.AttentionTo = a.AttentionTo

			var addressType AddressType
			resultFindAddressType := db.Where("AddressTypeID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Erp = ?", a.AddressTypeID, "xero").First(&addressType)
			if resultFindAddressType.RowsAffected > 0 {
				address.AddressType = addressType.AddressTypeName
			} else {
				address.AddressType = "STREET"
			}
			addresses = append(addresses, address)
		}
	}
	object.Addresses = addresses

	phones := make([]XeroContactPhone, 0)
	if len(item.Phones) > 0 {
		for _, p := range item.Phones {
			var phone XeroContactPhone
			// Calculate Phone Number
			//phone.PhoneNumber = strings.Replace(p.PhoneNumber, p.AreaCode, "", -1)
			phone.PhoneNumber = p.PhoneNumber
			//phone.PhoneAreaCode = p.AreaCode
			phone.PhoneCountryCode = p.CountryCode

			var phoneType PhoneType
			resultFindPhoneType := db.Where("PhoneTypeID = ? AND IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1 AND Erp = ?", p.PhoneTypeID, "xero").First(&phoneType)
			if resultFindPhoneType.RowsAffected > 0 {
				phone.PhoneType = phoneType.PhoneTypeName
			} else {
				phone.PhoneType = "MOBILE"
			}
			phones = append(phones, phone)
		}
	}
	object.Phones = phones
}

// RemoveEmptyValueWhenPostToXeroContact func
func RemoveEmptyValueWhenPostToXeroContact(xeroModel XeroContact) map[string]interface{} {
	xero := make(map[string]interface{})
	if xeroModel.ContactID != "" {
		xero["ContactID"] = xeroModel.ContactID
	}
	if xeroModel.ContactStatus != "" {
		xero["ContactStatus"] = xeroModel.ContactStatus
	}
	if xeroModel.Name != "" {
		xero["Name"] = xeroModel.Name
	}
	if xeroModel.FirstName != "" {
		xero["FirstName"] = xeroModel.FirstName
	}
	if xeroModel.LastName != "" {
		xero["LastName"] = xeroModel.LastName
	}
	if xeroModel.EmailAddress != "" {
		xero["EmailAddress"] = xeroModel.EmailAddress
	}
	if xeroModel.SkypeUserName != "" {
		xero["SkypeUserName"] = xeroModel.SkypeUserName
	}
	if xeroModel.BankAccountDetails != "" {
		xero["BankAccountDetails"] = xeroModel.BankAccountDetails
	}
	if xeroModel.TaxNumber != "" {
		xero["TaxNumber"] = xeroModel.TaxNumber
	}
	if xeroModel.AccountsReceivableTaxType != "" {
		xero["AccountsReceivableTaxType"] = xeroModel.AccountsReceivableTaxType
	}
	if xeroModel.AccountsPayableTaxType != "" {
		xero["AccountsPayableTaxType"] = xeroModel.AccountsPayableTaxType
	}
	xero["IsSupplier"] = xeroModel.IsSupplier
	xero["IsCustomer"] = xeroModel.IsCustomer
	if xeroModel.DefaultCurrency != "" {
		xero["DefaultCurrency"] = xeroModel.DefaultCurrency
	}
	if len(xeroModel.Addresses) > 0 {
		xero["Addresses"] = xeroModel.Addresses
	}
	if len(xeroModel.Phones) > 0 {
		xero["Phones"] = xeroModel.Phones
	}
	return xero
}

// CalculatePhoneNumberFunc func
func CalculatePhoneNumberFunc(db *gorm.DB, xeroPhone XeroContactPhone) (bool, string, string) {
	var (
		countryCodeModels     []CountryCode
		countryCodeDefault    CountryCode
		countryShortOnSetting string
		settingModel          Setting
		statusCalculate       = false
		newPhoneNumber        string
	)
	//
	if xeroPhone.PhoneNumber != "" {
		db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&countryCodeModels)
		if xeroPhone.PhoneCountryCode != "" {
			for _, countryCode := range countryCodeModels {
				if xeroPhone.PhoneCountryCode == countryCode.CountryCode {
					countryCodeDefault = countryCode
				}
			}
		}
		if countryCodeDefault.CountryCodeID <= 0 {
			resultFindCountryShortOnSetting := db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&settingModel)
			if resultFindCountryShortOnSetting.RowsAffected > 0 {
				if settingModel.Value != nil {
					var (
						settingValue SettingValue
					)
					err := json.Unmarshal([]byte(*settingModel.Value), &settingValue)
					if err == nil {

					}
				}
			}
			// @TODO hardcode to test
			countryShortOnSetting = "au"
			db.Where("Country = ?", countryShortOnSetting).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&countryCodeDefault)
		}
		if countryCodeDefault.CountryCodeID > 0 {
			sNumeric, vPhoneNumber := IsNumericPhoneNumber(xeroPhone.PhoneNumber)
			//fmt.Println("vPhoneNumber: ", vPhoneNumber)
			if sNumeric {
				newPhoneNumber = vPhoneNumber
				newPhoneNumber = RemoveLeadingZero(newPhoneNumber)
				//fmt.Println("newPhoneNumber: ", newPhoneNumber)
				if len(newPhoneNumber) <= countryCodeDefault.PhoneDigitsMax {
					concatenateAreaNewPhoneNumber := xeroPhone.PhoneAreaCode + newPhoneNumber
					//fmt.Println("concatenateAreaNewPhoneNumber: ", concatenateAreaNewPhoneNumber)
					minusLength := len(concatenateAreaNewPhoneNumber) - countryCodeDefault.PhoneDigitsMin
					//fmt.Println("minusLength: ", minusLength)
					if minusLength == 0 {
						// equal
						statusCalculate = true
					} else if minusLength == -1 {
						// less than 1 number
						concatenateAreaNewPhoneNumber = "0" + concatenateAreaNewPhoneNumber
						statusCalculate = true
					} else if minusLength > 0 {
						// greater than more
						if len(concatenateAreaNewPhoneNumber) <= countryCodeDefault.PhoneDigitsMax {
							statusCalculate = true
						}
					}
					if statusCalculate {
						//newPhoneNumber = countryCodeDefault.CountryCode + concatenateAreaNewPhoneNumber
						newPhoneNumber = concatenateAreaNewPhoneNumber
					}
				}
			}
		}
	}
	if statusCalculate {
		return true, countryCodeDefault.CountryCode, newPhoneNumber
	}
	return false, "", ""
}

/**
below functions can not add to libs
in model file can not call libs function
**/

// IsNumericPhoneNumber func
func IsNumericPhoneNumber(phoneNumber string) (bool, string) {
	// remove space leading & trailing
	phoneNumber = strings.TrimSpace(phoneNumber)
	// remove all space
	phoneNumber = strings.Replace(phoneNumber, " ", "", -1)
	// remove special letter
	phoneNumber = StrReplaceWithArray(phoneNumber, []string{"-"}, []string{""})
	if IsNumeric(phoneNumber) {
		return true, phoneNumber
	}
	return false, phoneNumber
}

// IsNumeric func
func IsNumeric(s string) bool {
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

// RemoveLeadingZero func
func RemoveLeadingZero(s string) string {
	if len(s) > 0 {
		if s[0:1] == "0" {
			return strings.TrimPrefix(s, s[0:1])
		}
	}
	return s
}

// StrReplaceWithArray func
func StrReplaceWithArray(str string, original []string, replacement []string) string {
	for i, toreplace := range original {
		r := strings.NewReplacer(toreplace, replacement[i])
		str = r.Replace(str)
	}
	return str
}
