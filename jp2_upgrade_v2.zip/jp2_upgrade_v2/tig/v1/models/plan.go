package models

// PlanJSON str
type PlanJSON struct {
	PlanKey int `json:"PlanKey"`
}
