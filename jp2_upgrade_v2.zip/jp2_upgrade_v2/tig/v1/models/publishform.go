package models

// PublishFormItem str
type PublishFormItem struct {
	FormID int    `json:"formId"`
	Name   string `json:"name"`
}
