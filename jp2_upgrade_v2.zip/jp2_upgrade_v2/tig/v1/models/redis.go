package models

// RedisDatabaseServerResponse str
type RedisDatabaseServerResponse struct {
	RedisServer       string `json:"RedisServer"`
	RedisPort         string `json:"RedisPort"`
	RedisPassword     string `json:"RedisPassword"`
	RedisDatabaseChat int    `json:"RedisDatabaseChat"`
	RedisDatabaseGPS  int    `json:"RedisDatabaseGPS"`
}

// DynamoDatabaseServerResponse str
type DynamoDatabaseServerResponse struct {
	CompanyID        string `json:"CompanyID"`
	AccessKeyID      string `json:"AccessKeyID"`
	SecretAccessKey  string `json:"SecretAccessKey"`
	Region           string `json:"Region"`
	DatabaseNameGPS  string `json:"DatabaseNameGPS"`
	DatabaseNameChat string `json:"DatabaseNameChat"`
}
