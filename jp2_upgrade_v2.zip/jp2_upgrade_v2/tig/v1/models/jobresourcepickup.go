package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobResourcePickup data
type JobResourcePickup struct {
	JobResourcePickupID   int        `gorm:"column:JobResourcePickupID;primaryKey;autoIncrement;not null"`
	IsArchived            bool       `gorm:"column:IsArchived"`
	CreatedBy             int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate           *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy            int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate          *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted             bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit               bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID                 int        `gorm:"column:JobID" json:"JobID"`
	JobTaskID             int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	AddressTypeID         int        `gorm:"column:AddressTypeID" json:"AddressTypeID"`
	Address               string     `gorm:"column:Address" json:"Address"`
	BusinessPartnerID     int        `gorm:"column:BusinessPartnerID" json:"BusinessPartnerID"`
	ContactDetails        string     `gorm:"column:ContactDetails" json:"ContactDetails"`
	CountryCode           string     `gorm:"column:CountryCode" json:"CountryCode"`
	ContactPhoneNumber    string     `gorm:"column:ContactPhoneNumber" json:"ContactPhoneNumber"`
	IsBussinessPartner    bool       `gorm:"column:IsBussinessPartner" json:"IsBussinessPartner"`
	PreferredDateTime     *time.Time `gorm:"column:PreferredDateTime" json:"PreferredDateTime"`
	Note                  string     `gorm:"column:Note" json:"Note"`
	AdditionalInformation string     `gorm:"column:AdditionalInformation" json:"AdditionalInformation"`
}

// JobResourcePickupResponse data
type JobResourcePickupResponse struct {
	AddressTypeID         int                  `json:"AddressTypeID"`
	Address               string               `json:"Address"`
	BusinessPartnerID     *int                 `json:"BusinessPartnerID"`
	ContactDetails        string               `json:"ContactDetails"`
	CountryCode           string               `json:"CountryCode"`
	ContactPhoneNumber    string               `json:"ContactPhoneNumber"`
	IsBussinessPartner    bool                 `json:"IsBussinessPartner"`
	PreferredDateTime     *time.Time           `json:"PreferredDateTime"`
	Note                  string               `json:"Note"`
	AdditionalInformation string               `json:"AdditionalInformation"`
	ServiceTimeInMinutes  int                  `json:"ServiceTimeInMinutes"`
	Addresses             []AddressJobResponse `json:"Addresses"`
	IsSuburb              bool                 `json:"IsSuburb"`
	IsFullAddress         bool                 `json:"IsFullAddress"`
}

// TableName func
func (JobResourcePickup) TableName() string {
	return "jobresourcepickups"
}

// BeforeCreate func
func (object *JobResourcePickup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobResourcePickup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobResourcePickup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobResourcePickupID", JSONObject)
	if res != nil {
		object.JobResourcePickupID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("AddressTypeID", JSONObject)
	if res != nil {
		object.AddressTypeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Address", JSONObject)
	if res != nil {
		object.Address = val
	}
	val, res = services.ConvertJSONValueToVariable("AdditionalInformation", JSONObject)
	if res != nil {
		object.AdditionalInformation = val
	}
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerID", JSONObject)
	if res != nil {
		object.BusinessPartnerID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ContactDetails", JSONObject)
	if res != nil {
		object.ContactDetails = val
	}
	val, res = services.ConvertJSONValueToVariable("CountryCode", JSONObject)
	if res != nil {
		object.CountryCode = val
	}
	val, res = services.ConvertJSONValueToVariable("ContactPhoneNumber", JSONObject)
	if res != nil {
		object.ContactPhoneNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("IsBussinessPartner", JSONObject)
	if res != nil {
		object.IsBussinessPartner, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("PreferredDateTime", JSONObject)
	if res != nil {
		vPreferredDateTime, sPreferredDateTime := services.ConvertStringToDateTime(val)
		if sPreferredDateTime == nil {
			object.PreferredDateTime = &vPreferredDateTime
		}
	}
	val, res = services.ConvertJSONValueToVariable("Note", JSONObject)
	if res != nil {
		object.Note = val
	}

	return
}
