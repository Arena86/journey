package models

// TrackAndTraceToken str
type TrackAndTraceToken struct {
	ResourceID int `json:"resourceid"`
	JobTaskID  int `json:"jobtaskid"`
	AccountKey int `json:"accountkey"`
}

// SMSServiceConfig str
type SMSServiceConfig struct {
	SMSServiceKey int    `json:"SMSServiceKey"`
	SMSKey        string `json:"SMSKey"`
	SMSPassword   string `json:"SMSPassword"`
	SMSURL        string `json:"SMSUrl"`
}

// SendSMSResponse str
type SendSMSResponse struct {
	Status      int
	Message     string
	PhoneNumber string
	Type        string
}

// PhoneAndMessageOfManager str
type PhoneAndMessageOfManager struct {
	PhoneNumber string
	MessageBody string
	User        User
}

// MessagesSMSResponse str
type MessagesSMSResponse struct {
	// @TODO response: `{"messages":[{"message_id":"e501af2a-82c5-4b71-a7f6-c9010a3fb0be"}]}`
	Messages []map[string]interface{}
}

// MessageSMSPOST str
type MessageSMSPOST struct {
	Content           string `json:"content"`
	DestinationNumber string `json:"destination_number"`
	Format            string `json:"format"`
	DeliveryReport    bool   `json:"delivery_report"`
}
