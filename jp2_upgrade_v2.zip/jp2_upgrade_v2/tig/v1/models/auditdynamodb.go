package models

import "time"

const AuditDocTypeJob = "j"
const AuditDocTypeEstimate = "e"
const AuditTypeInsert = "i"
const AuditTypeUpdate = "u"
const AuditTypeDelete = "d"

type AuditDynamoDB struct {
	AuditID       string
	AuditDateTime int
	JobID         int
	UserID        int
	DocType       string
	Type          string
	ObjectJson    string
}

type AuditDynamoDBResponse struct {
	AuditID       string
	AuditDateTime *time.Time
	JobID         int
	UserID        int
	DocType       string
	Type          string
	ObjectJson    string
}
