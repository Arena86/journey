package models

// XeroTaxResponse str
type XeroTaxResponse struct {
	ID           string `json:"Id"`
	TaxRates     []XeroTax
	DateTimeUTC  string
	ProviderName string
	Status       string
}

// XeroTax str
type XeroTax struct {
	Name                  string
	TaxType               string
	CanApplyToAssets      bool
	CanApplyToEquity      bool
	CanApplyToExpenses    bool
	CanApplyToLiabilities bool
	CanApplyToRevenue     bool
	DisplayTaxRate        float64
	EffectiveRate         float64
	Status                string
	TaxComponents         []XeroTaxComponent
}

// XeroTaxComponent str
type XeroTaxComponent struct {
	Name             string
	Rate             float64
	IsCompound       bool
	IsNonRecoverable bool
}

// ConvertXeroToDatabaseModel func
func (object *Tax) ConvertXeroToDatabaseModel(xero XeroTax) {
	object.TaxType = xero.TaxType
	object.TaxName = xero.Name
	object.TaxRate = xero.DisplayTaxRate
}
