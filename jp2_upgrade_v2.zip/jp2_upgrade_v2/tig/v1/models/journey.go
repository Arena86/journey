package models

import (
	"time"

	"gorm.io/gorm"
)

// JourneyDELETE data
type JourneyDELETE struct {
	JourneyIDs []int `json:"JourneyIDs"`
}

// JourneyBodyJSON str
type JourneyBodyJSON struct {
	/* ScheduleID        int
	ResourceID        int
	ScheduleStartDate *time.Time `json:"ScheduleStartDate"`
	ScheduleEndDate   *time.Time `json:"ScheduleEndDate"`
	Schedule          *Schedule  `json:"Schedule"` */

	ScheduleID                int                      `json:"ScheduleID"`
	ResourceID                int                      `json:"ResourceID"`
	ScheduleStartDate         *time.Time               `json:"ScheduleStartDate"`
	ScheduleEndDate           *time.Time               `json:"ScheduleEndDate"`
	LocationID                int                      `json:"LocationID"`
	UserID                    int                      `json:"UserID"`
	FirstName                 string                   `json:"FirstName"`
	LastName                  string                   `json:"LastName"`
	JobID                     int                      `json:"JobID"`
	JobTaskID                 int                      `json:"JobTaskID"`
	JourneyCode               *string                  `json:"JourneyCode"`
	JobStatus                 int                      `json:"JobStatus"`
	JobStatusName             string                   `json:"JobStatusName"`
	JobStatusIcon             string                   `json:"JobStatusIcon"`
	JobSummary                JobSummary               `json:"JobSummary"`
	ScheduleStartDateTimeZone string                   `json:"ScheduleStartDateTimeZone"`
	ScheduleEndDateTimeZone   string                   `json:"ScheduleEndDateTimeZone"`
	AdditionalUsers           []AdditionalUserResponse `json:"AdditionalUsers"`
}

// Journey data
type Journey struct {
	JourneyID                int        `gorm:"column:JourneyID;primaryKey;autoIncrement;not null"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JourneyCode              string     `gorm:"column:JourneyCode" json:"JourneyCode"`
	ResourceID               int        `gorm:"column:ResourceID" json:"ResourceID"`
	LocationID               int        `gorm:"column:LocationID" json:"LocationID"`
	StartJourneyDateTime     *time.Time `gorm:"column:StartJourneyDateTime" json:"StartJourneyDateTime"`
	EndJourneyDateTime       *time.Time `gorm:"column:EndJourneyDateTime" json:"EndJourneyDateTime"`
	StartBackToDepotDateTime *time.Time `gorm:"column:StartBackToDepotDateTime" json:"StartBackToDepotDateTime"`
	EndBackToDepotDateTime   *time.Time `gorm:"column:EndBackToDepotDateTime" json:"EndBackToDepotDateTime"`
	Status                   int        `gorm:"column:Status" json:"Status"`
}

// JourneyResponse data
type JourneyResponse struct {
	JourneyID                int                     `json:"JourneyID"`
	JourneyCode              string                  `json:"JourneyCode"`
	ResourceID               int                     `json:"ResourceID"`
	ResourceName             string                  `json:"ResourceName"`
	LocationID               int                     `json:"LocationID"`
	StartJourneyDateTime     *time.Time              `json:"StartJourneyDateTime"`
	EndJourneyDateTime       *time.Time              `json:"EndJourneyDateTime"`
	StartBackToDepotDateTime *time.Time              `json:"StartBackToDepotDateTime"`
	EndBackToDepotDateTime   *time.Time              `json:"EndBackToDepotDateTime"`
	JourneyDetails           []JourneyDetailResponse `json:"JourneyDetails"`
	Status                   int                     `json:"Status"`
}

// JourneyTimeJSON str
type JourneyTimeJSON struct {
	StartJourneyDateTime     *time.Time `json:"StartJourneyDateTime"`
	EndJourneyDateTime       *time.Time `json:"EndJourneyDateTime"`
	StartBackToDepotDateTime *time.Time `json:"StartBackToDepotDateTime"`
	EndBackToDepotDateTime   *time.Time `json:"EndBackToDepotDateTime"`
}

// JourneyListResponse data
type JourneyListResponse struct {
	JourneyCode          string     `json:"JourneyCode"`
	ResourceID           int        `json:"ResourceID"`
	ResourceName         string     `json:"ResourceName"`
	StartJourneyDateTime *time.Time `json:"StartJourneyDateTime"`
	EndJourneyDateTime   *time.Time `json:"EndJourneyDateTime"`
	Status               int        `json:"Status"`
	StatusName           string     `json:"StatusName"`
}

// JourneyDeletionResponse data
type JourneyDeletionResponse struct {
	JourneyID            int        `json:"JourneyID"`
	JourneyCode          string     `json:"JourneyCode"`
	ResourceID           int        `json:"ResourceID"`
	ResourceName         string     `json:"ResourceName"`
	StartJourneyDateTime *time.Time `json:"StartJourneyDateTime"`
	EndJourneyDateTime   *time.Time `json:"EndJourneyDateTime"`
}

// TableName func
func (Journey) TableName() string {
	return "journeys"
}

// BeforeCreate func
func (object *Journey) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Journey) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Journey) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	/* var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JourneyID", JSONObject)
	if res != nil {
		object.JourneyID, _ = strconv.Atoi(val)
	} */
	return
}
