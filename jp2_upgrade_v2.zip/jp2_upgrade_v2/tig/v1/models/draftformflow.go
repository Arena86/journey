package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DraftFormConditionGroupByConditionID str
type DraftFormConditionGroupByConditionID struct {
	ConditionID string
	Groups      []DraftFormConditionGroupByConditionGroup
}

// DraftFormConditionGroupByConditionGroup str
type DraftFormConditionGroupByConditionGroup struct {
	ConditionGroup      string
	DraftFormConditions []DraftFormCondition
}

// DraftFormConditionOnDraftFormFlowResponse str
type DraftFormConditionOnDraftFormFlowResponse struct {
	//DraftFormConditionID int                                              `json:"DraftFormConditionID"`
	ConditionID     string                                           `json:"ConditionID"`
	ConditionName   string                                           `json:"ConditionName"`
	DefaultToForm   string                                           `json:"DefaultToForm"`
	ConditionGroups []DraftFormConditionGroupOnDraftFormFlowResponse `json:"ConditionGroups"`
}

// DraftFormConditionGroupOnDraftFormFlowResponse str
type DraftFormConditionGroupOnDraftFormFlowResponse struct {
	ConditionGroup string                                                    `json:"ConditionGroup"`
	ToForm         string                                                    `json:"ToForm"`
	Sort           int                                                       `json:"Sort"`
	Conditions     []DraftFormConditionGroupConditionOnDraftFormFlowResponse `json:"Conditions"`
}

// DraftFormConditionGroupConditionOnDraftFormFlowResponse str
type DraftFormConditionGroupConditionOnDraftFormFlowResponse struct {
	DraftFormConditionID int    `json:"DraftFormConditionID"`
	Operator             string `json:"Operator"`
	FormID               int    `json:"FormID"`
	DataField            string `json:"DataField"`
	ControlID            string `json:"ControlID"`
	ConditionCode        string `json:"ConditionCode"`
	ConditionValue       string `json:"ConditionValue"`
}

// DraftFormFlow data
type DraftFormFlow struct {
	DraftFormFlowID     int                  `gorm:"column:DraftFormFlowID;primaryKey;autoIncrement;not null"`
	CreatedBy           int                  `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time           `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int                  `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time           `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool                 `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool                 `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool                 `gorm:"column:IsArchived"`
	DraftFormFlowName   string               `gorm:"column:DraftFormFlowName"`
	DraftFormFlow       *string              `gorm:"column:DraftFormFlow"`
	DraftNavigation     *string              `gorm:"column:DraftNavigation"`
	AdvancedForms       *string              `gorm:"column:AdvancedForms"`
	SubFormFlows        *string              `gorm:"column:SubFormFlows"`
	LastPublishedDate   *time.Time           `gorm:"column:LastPublishedDate" json:"LastPublishedDate"`
	DraftFormConditions []DraftFormCondition `gorm:"foreignKey:FormFlowID;references:DraftFormFlowID" json:"DraftFormConditions"`
	Status              int                  `gorm:"column:Status" json:"Status"`
}

// DraftFormFlowResponse data
type DraftFormFlowResponse struct {
	DraftFormFlowID     int                                         `json:"DraftFormFlowID"`
	DraftFormFlowName   string                                      `json:"DraftFormFlowName"`
	DraftFormFlow       *string                                     `json:"DraftFormFlow"`
	DraftNavigation     *string                                     `json:"DraftNavigation"`
	AdvancedForms       *string                                     `json:"AdvancedForms"`
	SubFormFlows        *string                                     `json:"SubFormFlows"`
	DraftFormConditions []DraftFormConditionOnDraftFormFlowResponse `json:"DraftFormConditions"`
	LastPublishedDate   *time.Time                                  `json:"LastPublishedDate"`
	Status              int                                         `json:"Status"`
}

// DraftFormFlowJSON data
type DraftFormFlowJSON struct {
	Data DraftFormFlowData `json:"data"`
}

// DraftFormFlowData data
type DraftFormFlowData struct {
	Shapes []Shape `json:"shapes"`
}

// Shape data
type Shape struct {
	ShapeType string `json:"type"`
	Text      string `json:"text"`
}

// DraftFormFlowResponseMaster data
type DraftFormFlowResponseMaster struct {
	DraftFormFlowID   int        `json:"DraftFormFlowID"`
	DraftFormFlowName string     `json:"DraftFormFlowName"`
	LastPublishedDate *time.Time `json:"LastPublishedDate"`
	Status            int        `json:"Status"`
}

// TableName func
func (DraftFormFlow) TableName() string {
	return "draftformflows"
}

// BeforeCreate func
func (object *DraftFormFlow) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// RevertDraftFromFormFlow func
func (object *DraftFormFlow) RevertDraftFromFormFlow(formFlow FormFlow) {
	object.DraftFormFlow = formFlow.FormFlow
	object.DraftNavigation = formFlow.Navigation
	object.AdvancedForms = formFlow.AdvancedForms
	object.SubFormFlows = formFlow.SubFormFlows
	return
}

// BeforeUpdate func
//func (object *DraftFormFlow) BeforeUpdate(db *gorm.DB) (err error) {
//TimeNow := time.Now()
//object.ModifiedDate = &TimeNow
//}

// PassBodyJSONToModel func
func (object *DraftFormFlow) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DraftFormFlowID", JSONObject)
	if res != nil {
		object.DraftFormFlowID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DraftFormFlowName", JSONObject)
	if res != nil {
		object.DraftFormFlowName = val
	}
	val, res = services.ConvertJSONValueToVariable("DraftFormFlow", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DraftFormFlow = &valJSON
		} else {
			object.DraftFormFlow = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("DraftNavigation", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DraftNavigation = &valJSON
		} else {
			object.DraftNavigation = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("AdvancedForms", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.AdvancedForms = &valJSON
		} else {
			object.AdvancedForms = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("SubFormFlows", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.SubFormFlows = &valJSON
		} else {
			object.SubFormFlows = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("DraftFormConditions", JSONObject)
	if res != nil {
		var (
			details                   []DraftFormCondition
			draftFormConditionObjects = make([]DraftFormConditionOnDraftFormFlowResponse, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &draftFormConditionObjects)
			for _, objectByConditionID := range draftFormConditionObjects {
				for _, objectByConditionGroup := range objectByConditionID.ConditionGroups {
					for _, objectCondition := range objectByConditionGroup.Conditions {
						var detail DraftFormCondition
						detail.ConditionID = objectByConditionID.ConditionID
						detail.DefaultToForm = objectByConditionID.DefaultToForm
						detail.ToForm = objectByConditionGroup.ToForm
						detail.ConditionGroup = objectByConditionGroup.ConditionGroup
						detail.Sort = objectByConditionGroup.Sort
						detail.DraftFormConditionID = objectCondition.DraftFormConditionID
						detail.FormID = objectCondition.FormID
						detail.Operator = objectCondition.Operator
						detail.DataField = objectCondition.DataField
						detail.ControlID = objectCondition.ControlID
						detail.ConditionCode = objectCondition.ConditionCode
						detail.ConditionValue = objectCondition.ConditionValue
						details = append(details, detail)
					}
				}
			}
		}
		object.DraftFormConditions = details
	}
	return
}
