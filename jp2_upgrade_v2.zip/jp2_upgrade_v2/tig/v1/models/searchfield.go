package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SearchField data
type SearchField struct {
	SearchFieldID  int        `gorm:"column:SearchFieldID;primaryKey;autoIncrement;not null" json:"SearchFieldID"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TableNameObj   string     `gorm:"column:TableName" json:"TableName"`
	SearchFieldKey string     `gorm:"column:SearchFieldKey" json:"SearchFieldKey"`
	Parameter      string     `gorm:"column:Parameter" json:"Parameter"`
	Label          string     `gorm:"column:Label" json:"Label"`
	MaxLength      int        `gorm:"column:MaxLength" json:"MaxLength"`
	Widget         string     `gorm:"column:Widget" json:"Widget"`
	Value          string     `gorm:"column:Value" json:"Value"`
	Visible        bool       `gorm:"column:Visible" json:"Visible"`
	Sort           int        `gorm:"column:Sort" json:"Sort"`
	TranslationKey string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	AccountKey     int        `gorm:"column:AccountKey" json:"AccountKey"`
	IsEnum         bool       `gorm:"column:IsEnum" json:"IsEnum"`
	FieldName      string     `gorm:"column:FieldName" json:"FieldName"`
	Options        string     `gorm:"column:Options" json:"Options"`
	DateType       string     `gorm:"column:DateType" json:"DateType"`
	Operator       string     `gorm:"column:Operator" json:"Operator"`
}

// SearchFieldResponse data
type SearchFieldResponse struct {
	SearchFieldID   int              `json:"SearchFieldID"`
	TableNameObj    string           `json:"TableName"`
	Parameter       string           `json:"Parameter"`
	Label           string           `json:"Label"`
	MaxLength       int              `json:"MaxLength"`
	Widget          string           `json:"Widget"`
	Value           interface{}      `json:"Value"`
	Visible         bool             `json:"Visible"`
	Sort            int              `json:"Sort"`
	AccountKey      int              `json:"AccountKey"`
	Options         string           `json:"Options"`
	DataType        string           `json:"DataType"`
	NumberPrecision int              `json:"NumberPrecision"`
	DataField       string           `json:"DataField"`
	Alignment       string           `json:"Alignment"`
	DateType        string           `json:"DateType"`
	Operator        string           `json:"Operator"`
	FieldName       string           `json:"FieldName"`
	IsEnum          bool             `json:"IsEnum"`
	EnumDataSource  []EnumDataSource `json:"EnumDataSource"`
}

// EnumDataSource data
type EnumDataSource struct {
	Status  int    `json:"Status"`
	Caption string `json:"Caption"`
}

// TableName func
func (SearchField) TableName() string {
	return "searchfields"
}

// BeforeCreate func
func (object *SearchField) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SearchField) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SearchField) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SearchFieldID", JSONObject)
	if res != nil {
		vSearchFieldID, sSearchFieldID := strconv.Atoi(val)
		if sSearchFieldID == nil {
			object.SearchFieldID = vSearchFieldID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Value", JSONObject)
	if res != nil {
		object.Value = val
	}
	val, res = services.ConvertJSONValueToVariable("Operator", JSONObject)
	if res != nil {
		object.Operator = val
	}
	val, res = services.ConvertJSONValueToVariable("Visible", JSONObject)
	if res != nil {
		object.Visible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	return
}
