package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DistancePriceList data
type DistancePriceList struct {
	DistancePriceListID      int                       `gorm:"column:DistancePriceListID;primaryKey;autoIncrement;not null" json:"DistancePriceListID"`
	CreatedBy                int                       `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time                `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int                       `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time                `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool                      `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool                      `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool                      `gorm:"column:IsArchived" json:"IsArchived"`
	DistancePriceListName    string                    `gorm:"column:DistancePriceListName" json:"DistancePriceListName" validate:"required"`
	IsIncludeTax             bool                      `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
	TaxID                    int                       `gorm:"column:TaxID" json:"TaxID"`
	DistancePriceListDetails []DistancePriceListDetail `gorm:"foreignKey:DistancePriceListID;references:DistancePriceListID" json:"DistancePriceListDetails"`
}

// DistancePriceListResponse data
type DistancePriceListResponse struct {
	DistancePriceListID      int                               `json:"DistancePriceListID"`
	DistancePriceListName    string                            `json:"DistancePriceListName"`
	IsIncludeTax             bool                              `json:"IsIncludeTax"`
	TaxID                    int                               `json:"TaxID"`
	DistancePriceListDetails []DistancePriceListDetailResponse `json:"DistancePriceListDetails"`
}

// DistancePriceListResponseMaster data
type DistancePriceListResponseMaster struct {
	DistancePriceListID   int    `json:"DistancePriceListID"`
	DistancePriceListName string `json:"DistancePriceListName"`
	IsIncludeTax          bool   `json:"IsIncludeTax"`
	TaxID                 int    `json:"TaxID"`
}

// TableName func
func (DistancePriceList) TableName() string {
	return "distancepricelists"
}

// BeforeCreate func
func (object *DistancePriceList) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DistancePriceList) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DistancePriceList) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DistancePriceListID", JSONObject)
	if res != nil {
		object.DistancePriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DistancePriceListName", JSONObject)
	if res != nil {
		object.DistancePriceListName = val
	}
	val, res = services.ConvertJSONValueToVariable("DistancePriceListDetails", JSONObject)
	if res != nil {
		var (
			distancePriceListDetails       []DistancePriceListDetail
			objectDistancePriceListDetails []map[string]interface{}
		)
		distancePriceListDetails = make([]DistancePriceListDetail, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDistancePriceListDetails)
			if len(objectDistancePriceListDetails) > 0 {
				for _, obj := range objectDistancePriceListDetails {
					var (
						detail DistancePriceListDetail
					)
					detail.PassBodyJSONToModel(obj)
					distancePriceListDetails = append(distancePriceListDetails, detail)
				}
			}
		}
		object.DistancePriceListDetails = distancePriceListDetails
	}
	val, res = services.ConvertJSONValueToVariable("IsIncludeTax", JSONObject)
	if res != nil {
		object.IsIncludeTax, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaxID", JSONObject)
	if res != nil {
		object.TaxID, _ = strconv.Atoi(val)
	}

	return
}
