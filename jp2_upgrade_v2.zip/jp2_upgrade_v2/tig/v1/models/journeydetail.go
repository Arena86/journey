package models

import (
	"time"

	"gorm.io/gorm"
)

// JourneyDetail data
type JourneyDetail struct {
	JourneyDetailID int        `gorm:"column:JourneyDetailID;primaryKey;autoIncrement;not null"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JourneyID       int        `gorm:"column:JourneyID" json:"JourneyID"`
	ScheduleID      int        `gorm:"column:ScheduleID" json:"ScheduleID"`
}

// JourneyDetailResponse data
type JourneyDetailResponse struct {
	JourneyDetailID int `json:"JourneyDetailID"`
	JourneyID       int `json:"JourneyID"`
	ScheduleID      int `json:"ScheduleID"`
}

// TableName func
func (JourneyDetail) TableName() string {
	return "journeydetails"
}

// BeforeCreate func
func (object *JourneyDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JourneyDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JourneyDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	/* var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JourneyDetailID", JSONObject)
	if res != nil {
		object.JourneyDetailID, _ = strconv.Atoi(val)
	} */
	return
}
