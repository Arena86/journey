package models

// RoutexlConfig data
type RoutexlConfig struct {
	RoutexlConfigKey int    `gorm:"column:RoutexlConfigKey;primaryKey;autoIncrement;not null"`
	RoutexlURL       string `gorm:"column:RoutexlUrl;type:nvarchar(100)"`
	UserName         string `gorm:"column:UserName;type:nvarchar(100);not null"`
	Password         string `gorm:"column:Password;type:nvarchar(100);not null"`
}

// TableName func
func (RoutexlConfig) TableName() string {
	return "routexlconfig"
}

// Tour data
type Tour []struct {
	Address      string `json:"address"`
	Lat          string `json:"lat"`
	Lng          string `json:"lng"`
	ServiceTime  string `json:"servicetime"`
	Restrictions Restriction
}

// Restriction data
type Restriction struct {
	Before string `json:"before"`
	Due    string `json:"due"`
	Ready  string `json:"ready"`
	After  string `json:"after"`
}

// RoutexlResponse data
type RoutexlResponse struct {
	ID       string `json:"id"`
	Count    int    `json:"Count"`
	Feasible bool   `json:"feasible"`
	Remarks  string `json:"remarks"`
	Route    string `json:"route"`
}

// Route data
type Route struct {
	Name     string `json:"name"`
	Lat      int    `json:"lat"`
	Lng      bool   `json:"lng"`
	Arrival  int    `json:"arrival"`
	Distance int    `json:"distance"`
}
