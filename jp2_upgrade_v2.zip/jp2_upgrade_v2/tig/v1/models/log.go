package models

import (
	"time"
)

// ParamsDeleteLog data
type ParamsDeleteLog struct {
	FromDate string `json:"fromdate"`
	ToDate   string `json:"todate"`
}

// DBLog data
type DBLog struct {
	LogKey            int        `gorm:"column:LogKey;primaryKey;autoIncrement;not null"`
	LoggedDateTime    *time.Time `gorm:"column:LoggedDateTime;default:CURRENT_TIMESTAMP"`
	Source            string     `gorm:"column:Source;type:nvarchar(100);not null"`
	Type              string     `gorm:"column:Type;type:nvarchar(50);not null"`
	EventType         int        `gorm:"column:EventType;"`
	IsSystemException bool       `gorm:"column:IsSystemException;"`
	Message           string     `gorm:"column:Message;type:nvarchar(500);null"`
	Exception         string     `gorm:"column:Exception;type:nvarchar(60);null"`
	IsDeleted         bool       `gorm:"column:IsDeleted;type:tinyint(4);null"`
}

// TableName func
func (DBLog) TableName() string {
	return "logs"
}
