package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormCheckList data
type FormCheckList struct {
	FormCheckListID    int                          `gorm:"column:FormCheckListID;primaryKey;autoIncrement;not null"`
	CreatedBy          int                          `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time                   `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int                          `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time                   `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool                         `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool                         `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool                         `gorm:"column:IsArchived" json:"IsArchived"`
	FormCheckListName  string                       `gorm:"column:FormCheckListName" json:"FormCheckListName"`
	IsCommentVisible   bool                         `gorm:"column:IsCommentVisible" json:"IsCommentVisible"`
	IsCommentMandatory bool                         `gorm:"column:IsCommentMandatory" json:"IsCommentMandatory"`
	QuestionGroups     []FormCheckListQuestionGroup `gorm:"foreignKey:FormCheckListID;references:FormCheckListID" json:"QuestionGroups"`
}

// FormCheckListResponse data
type FormCheckListResponse struct {
	FormCheckListID    int                                  `json:"FormCheckListID"`
	FormCheckListName  string                               `json:"FormCheckListName"`
	IsCommentVisible   bool                                 `json:"IsCommentVisible"`
	IsCommentMandatory bool                                 `json:"IsCommentMandatory"`
	QuestionGroups     []FormCheckListQuestionGroupResponse `json:"QuestionGroups"`
	Questions          []FormCheckListQuestionResponse      `json:"Questions"`
}

// TableName func
func (FormCheckList) TableName() string {
	return "formchecklists"
}

// BeforeCreate func
func (object *FormCheckList) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormCheckList) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormCheckList) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormCheckListID", JSONObject)
	if res != nil {
		object.FormCheckListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListName", JSONObject)
	if res != nil {
		object.FormCheckListName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsCommentVisible", JSONObject)
	if res != nil {
		object.IsCommentVisible, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCommentMandatory", JSONObject)
	if res != nil {
		object.IsCommentMandatory, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("QuestionGroups", JSONObject)
	if res != nil {
		var (
			details       []FormCheckListQuestionGroup
			objectDetails []map[string]interface{}
		)
		details = make([]FormCheckListQuestionGroup, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail FormCheckListQuestionGroup
					)
					detail.PassBodyJSONToModel(obj)
					details = append(details, detail)
				}
			}
		}
		object.QuestionGroups = details
	}

	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail FormCheckListQuestion
					)
					detail.PassBodyJSONToModel(obj)
					for i, questionGroup := range object.QuestionGroups {
						if questionGroup.FormCheckListQuestionGroupID == detail.FormCheckListQuestionGroupID {
							object.QuestionGroups[i].Questions = append(object.QuestionGroups[i].Questions, detail)
						}
					}
				}
			}
		}
	}

	return
}
