package models

type StripeConfig struct {
	StripeKey int
	SecretKey string
}

type StripePaymentJP struct {
	Card struct {
		FirstName string
		LastName  string
		Number    string
		ExpMonth  int
		ExpYear   int
		CVC       string
	}
	Amount    float64
	Currency  string
	InvoiceID string
}

// StripeResponseError str
type StripeResponseError struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
}
