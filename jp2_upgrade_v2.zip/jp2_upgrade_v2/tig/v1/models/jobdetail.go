package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobDetailJSONResponse str
type JobDetailJSONResponse struct {
	JobDetailResponse
	ItemMovements []ItemMovementResponse `json:"ItemMovements"`
}

// JobDetail data
type JobDetail struct {
	JobDetailID             int        `gorm:"column:JobDetailID;primaryKey;autoIncrement;not null"`
	IsArchived              bool       `gorm:"column:IsArchived"`
	CreatedBy               int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate             *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy              int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate            *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted               bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                 bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID                   int        `gorm:"column:JobID" json:"JobID"`
	JobTaskType             *int       `gorm:"column:JobTaskType" json:"JobTaskType"`
	ItemID                  int        `gorm:"column:ItemID" json:"ItemID"`
	LineNum                 int        `gorm:"column:LineNum" json:"LineNum"`
	Code                    string     `gorm:"column:Code" json:"Code"`
	Description             string     `gorm:"column:Description" json:"Description"`
	UnitPrice               float64    `gorm:"column:UnitPrice" json:"UnitPrice"`
	Quantity                float64    `gorm:"column:Quantity" json:"Quantity"`
	TaxType                 string     `gorm:"column:TaxType" json:"TaxType"`
	TaxName                 string     `gorm:"column:TaxName" json:"TaxName"`
	TaxRate                 float64    `gorm:"column:TaxRate" json:"TaxRate"`
	DiscountAmount          float64    `gorm:"column:DiscountAmount" json:"DiscountAmount"`
	DiscountPercent         float64    `gorm:"column:DiscountPercent" json:"DiscountPercent"`
	BufferAmount            float64    `gorm:"column:BufferAmount" json:"BufferAmount"`
	BufferPercent           float64    `gorm:"column:BufferPercent" json:"BufferPercent"`
	LineTotal               float64    `gorm:"column:LineTotal" json:"LineTotal"`
	DiscountAmt             float64    `gorm:"column:DiscountAmt" json:"DiscountAmt"`
	BufferAmt               float64    `gorm:"column:BufferAmt" json:"BufferAmt"`
	LineTotalTax            float64    `gorm:"column:LineTotalTax" json:"LineTotalTax"`
	LineSubTotal            float64    `gorm:"column:LineSubTotal" json:"LineSubTotal"`
	LineTotalTaxExcluded    float64    `gorm:"column:LineTotalTaxExcluded" json:"LineTotalTaxExcluded"`
	QuantityPicked          float64    `gorm:"column:QuantityPicked" json:"QuantityPicked"`
	QuantityDelivered       float64    `gorm:"column:QuantityDelivered" json:"QuantityDelivered"`
	ParentItemID            int        `gorm:"column:ParentItemID" json:"ParentItemID"`
	SurchargeParentItemID   int        `gorm:"column:SurchargeParentItemID" json:"SurchargeParentItemID"`
	Key                     string     `gorm:"column:Key" json:"Key"`
	FourDPriceDynamicFormID *int       `gorm:"column:4DPriceDynamicFormID" json:"4DPriceDynamicFormID"`
	TriggerInspectionMode   *int       `gorm:"column:TriggerInspectionMode" json:"TriggerInspectionMode"`
}

// JobDetailResponse data
type JobDetailResponse struct {
	JobDetailID             int     `json:"JobDetailID"`
	JobID                   int     `json:"JobID"`
	JobTaskType             *int    `json:"JobTaskType"`
	ItemID                  int     `json:"ItemID"`
	Code                    string  `json:"Code"`
	LineNum                 int     `json:"LineNum"`
	Description             string  `json:"Description"`
	UnitPrice               float64 `json:"UnitPrice"`
	Quantity                float64 `json:"Quantity"`
	TaxType                 string  `json:"TaxType"`
	TaxName                 string  `json:"TaxName"`
	TaxRate                 float64 `json:"TaxRate"`
	DiscountAmount          float64 `json:"DiscountAmount"`
	DiscountPercent         float64 `json:"DiscountPercent"`
	BufferAmount            float64 `json:"BufferAmount"`
	BufferPercent           float64 `json:"BufferPercent"`
	LineTotal               float64 `json:"LineTotal"`
	DiscountAmt             float64 `json:"DiscountAmt"`
	BufferAmt               float64 `json:"BufferAmt"`
	LineTotalTax            float64 `json:"LineTotalTax"`
	LineSubTotal            float64 `json:"LineSubTotal"`
	LineTotalTaxExcluded    float64 `json:"LineTotalTaxExcluded"`
	QuantityPicked          float64 `json:"QuantityPicked"`
	QuantityDelivered       float64 `json:"QuantityDelivered"`
	ParentItemID            int     `json:"ParentItemID"`
	SurchargeParentItemID   int     `json:"SurchargeParentItemID"`
	Key                     string  `json:"Key"`
	ItemType                int     `json:"ItemType"`
	FourDPriceDynamicFormID *int    `json:"FourDPriceDynamicFormID"`
	TriggerInspectionMode   *int    `json:"TriggerInspectionMode"`
}

// JobDetailForJobResponse data
type JobDetailForJobResponse struct {
	JobDetailID           int                   `json:"JobDetailID"`
	LineNum               int                   `json:"LineNum"`
	Key                   string                `json:"Key"`
	ItemID                int                   `json:"ItemID"`
	Code                  string                `json:"Code"`
	Name                  string                `json:"Name"`
	Description           string                `json:"Description"`
	UnitPrice             float64               `json:"UnitPrice"`
	Quantity              float64               `json:"Quantity"`
	TaxRate               float64               `json:"TaxRate"`
	DiscountPercent       float64               `json:"DiscountPercent"`
	BufferPercent         float64               `json:"BufferPercent"`
	LineTotal             float64               `json:"LineTotal"`
	ParentItemID          int                   `json:"ParentItemID"`
	SurchargeParentItemID int                   `json:"SurchargeParentItemID"`
	RelatedItems          []RelatedItemResponse `json:"RelatedItems"`
	//IsUpdated       bool                  `json:"IsUpdated"`
	JobTaskType             *int `json:"JobTaskType"`
	FourDPriceDynamicFormID *int `json:"FourDPriceDynamicFormID"`
	TriggerInspectionMode   *int `json:"TriggerInspectionMode"`
	ServiceTimeInMinutes    int  `json:"ServiceTimeInMinutes"`
}

// TableName func
func (JobDetail) TableName() string {
	return "jobdetails"
}

// BeforeCreate func
func (object *JobDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobDetailID", JSONObject)
	if res != nil {
		object.JobDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		object.ItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Code", JSONObject)
	if res != nil {
		object.Code = val
	}
	val, res = services.ConvertJSONValueToVariable("LineNum", JSONObject)
	if res != nil {
		object.LineNum, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}
	val, res = services.ConvertJSONValueToVariable("UnitPrice", JSONObject)
	if res != nil {
		object.UnitPrice, _ = strconv.ParseFloat(val, 64)
	}

	val, res = services.ConvertJSONValueToVariable("Quantity", JSONObject)
	if res != nil {
		object.Quantity, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("TaxType", JSONObject)
	if res != nil {
		object.TaxType = val
	}
	val, res = services.ConvertJSONValueToVariable("TaxName", JSONObject)
	if res != nil {
		object.TaxName = val
	}
	val, res = services.ConvertJSONValueToVariable("TaxRate", JSONObject)
	if res != nil {
		object.TaxRate, _ = strconv.ParseFloat(val, 64)
	}

	val, res = services.ConvertJSONValueToVariable("DiscountAmount", JSONObject)
	if res != nil {
		object.DiscountAmount, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("DiscountPercent", JSONObject)
	if res != nil {
		object.DiscountPercent, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("BufferAmount", JSONObject)
	if res != nil {
		object.BufferAmount, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("BufferPercent", JSONObject)
	if res != nil {
		object.BufferPercent, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("LineTotal", JSONObject)
	if res != nil {
		object.LineTotal, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("DiscountAmt", JSONObject)
	if res != nil {
		object.DiscountAmt, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("BufferAmt", JSONObject)
	if res != nil {
		object.BufferAmt, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("LineTotalTax", JSONObject)
	if res != nil {
		object.LineTotalTax, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("LineSubTotal", JSONObject)
	if res != nil {
		object.LineSubTotal, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("LineTotalTaxExcluded", JSONObject)
	if res != nil {
		object.LineTotalTaxExcluded, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("QuantityPicked", JSONObject)
	if res != nil {
		object.QuantityPicked, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("QuantityDelivered", JSONObject)
	if res != nil {
		object.QuantityDelivered, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("ParentItemID", JSONObject)
	if res != nil {
		object.ParentItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("SurchargeParentItemID", JSONObject)
	if res != nil {
		object.SurchargeParentItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskType", JSONObject)
	if res != nil {
		jobTaskType, _ := strconv.Atoi(val)
		object.JobTaskType = &jobTaskType
	}
	val, res = services.ConvertJSONValueToVariable("Key", JSONObject)
	if res != nil {
		object.Key = val
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceDynamicFormID", JSONObject)
	if res != nil {
		fourDPriceDynamicFormID, _ := strconv.Atoi(val)
		object.FourDPriceDynamicFormID = &fourDPriceDynamicFormID
	}
	val, res = services.ConvertJSONValueToVariable("TriggerInspectionMode", JSONObject)
	if res != nil {
		triggerInspectionMode, _ := strconv.Atoi(val)
		object.TriggerInspectionMode = &triggerInspectionMode
	}
	return
}
