package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PrecomputedRouteResourceObject str
type PrecomputedRouteResourceObject struct {
	LocationID int
	ResourceID int
	Schedules  []Schedule
}

// PrecomputedRouteResourceResponse str
type PrecomputedRouteResourceResponse struct {
	Depot       ResourceDepotResponse        `json:"depot"`
	Resource    ResourceResourceResponse     `json:"resource"`
	Precomputes []ResourcePrecomputeResponse `json:"precomputes"`
}

// ResourceResourceResponse str
type ResourceResourceResponse struct {
	ResourceID    int    `json:"ResourceID"`
	ResourceName  string `json:"ResourceName"`
	ResourceColor string `json:"ResourceColor"`
}

// ResourceDepotResponse str
type ResourceDepotResponse struct {
	LocationName string `json:"LocationName"`
	Address      string `json:"Address"`
}

// ResourcePrecomputeResponse str
type ResourcePrecomputeResponse struct {
	JobNumber          string `json:"JobNumber"`
	CompanyName        string `json:"CompanyName"`
	TaskID             int    `json:"TaskID"`
	JobTaskJobTypeName string `json:"JobTaskJobTypeName"`
	NavigationAddress  string `json:"NavigationAddress"`
	Precompute         string `json:"Precompute"`
}

// PrecomputedRoute data
type PrecomputedRoute struct {
	PrecomputedRouteID  int        `gorm:"column:PrecomputedRouteID;primaryKey;autoIncrement;not null" json:"PrecomputedRouteID"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TaskID              int        `gorm:"column:TaskID" json:"TaskID"`
	PrecomputedRoute    string     `gorm:"column:PrecomputedRoute" json:"PrecomputedRoute"`
	PrecomputedRouteWeb string     `gorm:"column:PrecomputedRouteWeb" json:"PrecomputedRouteWeb"`
}

// PrecomputedRouteResponse data
type PrecomputedRouteResponse struct {
	PrecomputedRouteID  int    `json:"PrecomputedRouteID"`
	TaskID              int    `json:"TaskID"`
	PrecomputedRoute    string `json:"PrecomputedRoute"`
	PrecomputedRouteWeb string `json:"PrecomputedRouteWeb"`
}

// PrecomputedRouteSygicResponse data
type PrecomputedRouteSygicResponse struct {
	Name       string       `json:"name"`
	Version    string       `json:"version"`
	RouteParts []RouteParts `json:"routeParts"`
}

// PrecomputedRouteTomTomResponse data
type PrecomputedRouteTomTomResponse struct {
	Name       string             `json:"name"`
	Version    string             `json:"version"`
	RouteParts []TomTomRouteParts `json:"routeParts"`
}

// RouteParts data
type RouteParts struct {
	WaypointFrom *Waypoint `json:"waypointFrom,omitempty"`
	WaypointTo   Waypoint  `json:"waypointTo"`
	Roads        []Road    `json:"roads,omitempty"`
}

// Waypoint data
type Waypoint struct {
	Lat  int    `json:"lat"`
	Lon  int    `json:"lon"`
	Type string `json:"type"` //start, via, finish
}

// Road data
type Road struct {
	ID     int     `id:"id" json:"id"`
	Points []Point `json:"points"`
}

// Point data
type Point struct {
	Lat int `json:"lat"`
	Lon int `json:"lon"`
}

// Point data
type TomTomMapPoint struct {
	Lat float64 `json:"lat"`
	Lng float64 `json:"lng"`
}

// TomTomRoad data
type TomTomRoad struct {
	ID     int              `id:"id" json:"id"`
	Points []TomTomMapPoint `json:"points"`
}

// RouteParts data
type TomTomRouteParts struct {
	WaypointFrom *TomTomWaypoint `json:"waypointFrom,omitempty"`
	WaypointTo   TomTomWaypoint  `json:"waypointTo"`
	Roads        []TomTomRoad    `json:"roads,omitempty"`
}

// TomTomWaypoint data
type TomTomWaypoint struct {
	Lat  int    `json:"lat"`
	Lon  int    `json:"lon"`
	Type string `json:"type"` //start, via, finish
}

// TomTomPoint data
type TomTomPoint struct {
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}

// TableName func
func (PrecomputedRoute) TableName() string {
	return "precomputedroutes"
}

// BeforeCreate func
func (object *PrecomputedRoute) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PrecomputedRoute) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PrecomputedRoute) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PrecomputedRouteID", JSONObject)
	if res != nil {
		object.PrecomputedRouteID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaskID", JSONObject)
	if res != nil {
		object.TaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PrecomputedRoute", JSONObject)
	if res != nil {
		object.PrecomputedRoute = val
	}
	val, res = services.ConvertJSONValueToVariable("PrecomputedRouteWeb", JSONObject)
	if res != nil {
		object.PrecomputedRouteWeb = val
	}
	return
}
