package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// LocationPaymentMethod data
type LocationPaymentMethod struct {
	LocationPaymentMethodID int        `gorm:"column:LocationPaymentMethodID;primaryKey;autoIncrement;not null" json:"LocationPaymentMethodID"`
	CreatedBy               int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate             *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy              int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate            *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted               bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                 bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived              bool       `gorm:"column:IsArchived" json:"IsArchived"`
	LocationID              int        `gorm:"column:LocationID" json:"LocationID"`
	PaymentMethod           int        `gorm:"column:PaymentMethod" json:"PaymentMethod"`
	HasURL                  bool       `gorm:"column:HasUrl" json:"HasUrl"`
	URL                     string     `gorm:"column:Url" json:"Url"`
}

// LocationPaymentMethodResponse data
type LocationPaymentMethodResponse struct {
	LocationPaymentMethodID int    `json:"LocationPaymentMethodID"`
	LocationID              int    `json:"LocationID"`
	PaymentMethod           int    `json:"PaymentMethod"`
	HasURL                  bool   `json:"HasUrl"`
	URL                     string `json:"Url"`
	PaymentMethodName       string `json:"PaymentMethodName"`
}

// TableName func
func (LocationPaymentMethod) TableName() string {
	return "locationpaymentmethods"
}

// BeforeCreate func
func (object *LocationPaymentMethod) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *LocationPaymentMethod) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *LocationPaymentMethod) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("LocationPaymentMethodID", JSONObject)
	if res != nil {
		object.LocationPaymentMethodID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaymentMethod", JSONObject)
	if res != nil {
		object.PaymentMethod, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("HasUrl", JSONObject)
	if res != nil {
		object.HasURL, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Url", JSONObject)
	if res != nil {
		object.URL = val
	}

	return
}
