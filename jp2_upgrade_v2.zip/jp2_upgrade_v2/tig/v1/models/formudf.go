package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormUDF data
type FormUDF struct {
	FormUDFID    int        `gorm:"column:FormUDFID;primaryKey;autoIncrement;not null" json:"FormUDFID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FormUDTID    int        `gorm:"column:FormUDTID" json:"FormUDTID"`
	DataField    string     `gorm:"column:DataField" json:"DataField"`
	DataType     string     `gorm:"column:DataType" json:"DataType"`
	Length       int        `gorm:"column:Length" json:"Length"`
	IsPublished  bool       `gorm:"column:IsPublished" json:"IsPublished"`
	ControlID    string     `gorm:"column:ControlID" json:"ControlID"`
}

// FormUDFResponse data
type FormUDFResponse struct {
	DataField   string `json:"DataField"`
	DataType    string `json:"DataType"`
	Length      int    `json:"Length"`
	IsPublished bool   `json:"IsPublished"`
	ControlID   string `json:"ControlID"`
}

// TableName func
func (FormUDF) TableName() string {
	return "formudfs"
}

// BeforeCreate func
func (object *FormUDF) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormUDF) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormUDF) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormUDFID", JSONObject)
	if res != nil {
		object.FormUDFID, _ = strconv.Atoi(val)

	}
	val, res = services.ConvertJSONValueToVariable("FormUDTID", JSONObject)
	if res != nil {
		object.FormUDTID, _ = strconv.Atoi(val)

	}
	val, res = services.ConvertJSONValueToVariable("DataField", JSONObject)
	if res != nil {
		object.DataField = val

	}
	val, res = services.ConvertJSONValueToVariable("DataType", JSONObject)
	if res != nil {
		object.DataType = val

	}
	val, res = services.ConvertJSONValueToVariable("Length", JSONObject)
	if res != nil {
		object.Length, _ = strconv.Atoi(val)

	}
	return
}
