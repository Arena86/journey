package models

// ErrorResponseTypeError const
const ErrorResponseTypeError = "error"

// ErrorResponseTypeWarning const
const ErrorResponseTypeWarning = "warning"

// ErrorResponse str
type ErrorResponse struct {
	Index   int
	Message interface{}
	Type    string // waring, error
}
