package models

import (
	"encoding/json"
	"fmt"
	"strconv"
	"time"
)

// DateFormat const
const DateFormat = "2006-01-02"

// FullTimeFormat const
const FullTimeFormat = "2006-01-02T15:04:05Z"

// TimeFormat const
const TimeFormat = "15:04:05"

// DateTimeFormat const
const DateTimeFormat = "2006-01-02 15:04:05"

// TaskSchedulerStatusPOST str
type TaskSchedulerStatusPOST struct {
	TaskID int  `json:"TaskID"`
	Enable bool `json:"Enable"`
}

// ProcessingTask str
type ProcessingTask struct {
	TaskID int    `json:"TaskID"`
	DBName string `json:"DBName"`
}

// TaskSchedulerData data
type TaskSchedulerData struct {
	TaskID           int    `json:"TaskID"`
	Name             string `json:"Name"`
	Description      string `json:"Description"`
	TaskStartDate    string `json:"TaskStartDate"`
	TaskEndDate      string `json:"TaskEndDate"`
	Infinite         bool   `json:"Infinite"`
	Type             string `json:"Type"`
	Operation        string `json:"Operation"`
	IsRepeat         bool   `json:"IsRepeat"`
	RunAfter         bool   `json:"RunAfter"`
	Enabled          bool   `json:"Enabled"`
	NextRun          string `json:"NextRun"`
	FromDate         string `json:"FromDate"`
	ToDate           string `json:"ToDate"`
	StartAtTime      string `json:"StartAtTime"`
	Repeat           string `json:"Repeat"`
	RepeatEvery      int    `json:"RepeatEvery"`
	PreviousDay      int    `json:"PreviousDay"`
	RepeatOn         string `json:"RepeatOn"`
	RepeatOnDayMonth int    `json:"RepeatOnDayMonth"`
	TaskExecuted     string `json:"TaskExecuted"`
	TaskEnded        string `json:"TaskEnded"`
	IsCompleted      bool   `json:"IsCompleted"`
	TaskErrorMessage string `json:"TaskErrorMessage"`
	RunAfterTask     *RunAfterTask
}

// TaskScheduler data
type TaskScheduler struct {
	TaskID           int           `gorm:"column:TaskID;primaryKey;autoIncrement;not null"`
	CreatedBy        int           `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time    `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int           `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time    `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool          `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool          `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool          `gorm:"column:IsArchived" json:"IsArchived"`
	Name             *string       `gorm:"column:Name"`
	Description      *string       `gorm:"column:Description"`
	TaskStartDate    *time.Time    `gorm:"column:TaskStartDate"`
	TaskEndDate      *time.Time    `gorm:"column:TaskEndDate"`
	Infinite         bool          `gorm:"column:Infinite"`
	Type             *string       `gorm:"column:Type"`
	Operation        *string       `gorm:"column:Operation"`
	IsRepeat         bool          `gorm:"column:IsRepeat"`
	RunAfter         bool          `gorm:"column:RunAfter"`
	Enabled          bool          `gorm:"column:Enabled"`
	NextRun          *time.Time    `gorm:"column:NextRun"`
	FromDate         *time.Time    `gorm:"column:FromDate"`
	ToDate           *time.Time    `gorm:"column:ToDate"`
	StartAtTime      *[]uint8      `gorm:"column:StartAtTime"`
	Repeat           *string       `gorm:"column:Repeat"`
	RepeatEvery      int           `gorm:"column:RepeatEvery"`
	PreviousDay      int           `gorm:"column:PreviousDay"`
	RepeatOn         *string       `gorm:"column:RepeatOn"`
	RepeatOnDayMonth int           `gorm:"column:RepeatOnDayMonth"`
	TaskExecuted     *time.Time    `gorm:"column:TaskExecuted"`
	TaskEnded        *time.Time    `gorm:"column:TaskEnded"`
	IsCompleted      bool          `gorm:"column:IsCompleted"`
	TaskErrorMessage *string       `gorm:"column:TaskErrorMessage"`
	RunAfterTask     *RunAfterTask `gorm:"-"`
}

// TableName func
func (TaskScheduler) TableName() string {
	return "taskscheduler"
}

// ConvertDBTaskSchedulerToTaskSchedulerData func
func ConvertDBTaskSchedulerToTaskSchedulerData(dBModel TaskScheduler) TaskSchedulerData {
	var (
		resModel TaskSchedulerData
	)
	resModel.TaskID = dBModel.TaskID
	if dBModel.Name != nil {
		resModel.Name = *dBModel.Name
	}
	if dBModel.Description != nil {
		resModel.Description = *dBModel.Description
	}
	if dBModel.TaskStartDate != nil {
		taskStartDate := *dBModel.TaskStartDate
		resModel.TaskStartDate = taskStartDate.Format(DateFormat)
	}
	if dBModel.TaskEndDate != nil {
		taskEndDate := *dBModel.TaskEndDate
		resModel.TaskEndDate = taskEndDate.Format(DateFormat)
	}
	resModel.Infinite = dBModel.Infinite
	if dBModel.Type != nil {
		resModel.Type = *dBModel.Type
	}
	if dBModel.Operation != nil {
		resModel.Operation = *dBModel.Operation
	}
	resModel.IsRepeat = dBModel.IsRepeat
	resModel.RunAfter = dBModel.RunAfter
	resModel.Enabled = dBModel.Enabled
	if dBModel.NextRun != nil {
		nextRun := *dBModel.NextRun
		resModel.NextRun = nextRun.Format(DateFormat)
	}
	if dBModel.FromDate != nil {
		fromDate := *dBModel.FromDate
		resModel.FromDate = fromDate.Format(DateFormat)
	}
	if dBModel.ToDate != nil {
		toDate := *dBModel.ToDate
		resModel.ToDate = toDate.Format(DateFormat)
	}
	if dBModel.StartAtTime != nil {
		startAtTime := *dBModel.StartAtTime
		resModel.StartAtTime = string(startAtTime)
	}
	if dBModel.Repeat != nil {
		resModel.Repeat = *dBModel.Repeat
	}
	resModel.RepeatEvery = dBModel.RepeatEvery
	resModel.PreviousDay = dBModel.PreviousDay
	if dBModel.RepeatOn != nil {
		resModel.RepeatOn = *dBModel.RepeatOn
	}
	resModel.RepeatOnDayMonth = dBModel.RepeatOnDayMonth
	if dBModel.TaskExecuted != nil {
		taskExecuted := *dBModel.TaskExecuted
		resModel.TaskExecuted = taskExecuted.Format(FullTimeFormat)
	}
	if dBModel.TaskEnded != nil {
		taskEnded := *dBModel.TaskEnded
		resModel.TaskEnded = taskEnded.Format(FullTimeFormat)
	}
	resModel.IsCompleted = dBModel.IsCompleted
	if dBModel.TaskErrorMessage != nil {
		resModel.TaskErrorMessage = *dBModel.TaskErrorMessage
	}
	return resModel
}

// ConvertTaskSchedulerDataToDBTaskScheduler func
func ConvertTaskSchedulerDataToDBTaskScheduler(dBModel TaskSchedulerData) TaskScheduler {
	var (
		resModel TaskScheduler
	)
	resModel.TaskID = dBModel.TaskID
	resModel.Name = &dBModel.Name
	resModel.Description = &dBModel.Description
	taskStartDate := dBModel.TaskStartDate
	if taskStartDate != "" {
		vTaskStartDate, sTaskStartDate := time.Parse(DateFormat, taskStartDate)
		if sTaskStartDate == nil {
			resModel.TaskStartDate = &vTaskStartDate
		}
	}
	taskEndDate := dBModel.TaskEndDate
	if taskEndDate != "" {
		vTaskEndDate, sTaskEndDate := time.Parse(DateFormat, taskEndDate)
		if sTaskEndDate == nil {
			resModel.TaskEndDate = &vTaskEndDate
		}
	}
	resModel.Infinite = dBModel.Infinite
	resModel.Type = &dBModel.Type
	resModel.Operation = &dBModel.Operation
	resModel.IsRepeat = dBModel.IsRepeat
	resModel.RunAfter = dBModel.RunAfter
	resModel.Enabled = dBModel.Enabled
	nextRun := dBModel.NextRun
	if nextRun != "" {
		vNextRun, sNextRun := time.Parse(DateFormat, nextRun)
		if sNextRun == nil {
			resModel.NextRun = &vNextRun
		}
	}
	fromDate := dBModel.FromDate
	if fromDate != "" {
		vFromDate, sFromDate := time.Parse(DateFormat, fromDate)
		if sFromDate == nil {
			resModel.FromDate = &vFromDate
		}
	}
	toDate := dBModel.ToDate
	if toDate != "" {
		vToDate, sToDate := time.Parse(DateFormat, toDate)
		if sToDate == nil {
			resModel.ToDate = &vToDate
		}
	}
	startAtTime := dBModel.StartAtTime
	if startAtTime != "" {
		vStartAtTime := []uint8(startAtTime)
		resModel.StartAtTime = &vStartAtTime
	}
	resModel.Repeat = &dBModel.Repeat
	resModel.RepeatEvery = dBModel.RepeatEvery
	resModel.PreviousDay = dBModel.PreviousDay
	resModel.RepeatOn = &dBModel.RepeatOn
	resModel.RepeatOnDayMonth = dBModel.RepeatOnDayMonth
	taskExecuted := dBModel.TaskExecuted
	if taskExecuted != "" {
		vTaskExecuted, sTaskExecuted := time.Parse(FullTimeFormat, taskExecuted)
		if sTaskExecuted == nil {
			resModel.TaskExecuted = &vTaskExecuted
		}
	}
	taskEnded := dBModel.TaskEnded
	if taskEnded != "" {
		vTaskEnded, sTaskEnded := time.Parse(FullTimeFormat, taskEnded)
		if sTaskEnded == nil {
			resModel.TaskEnded = &vTaskEnded
		}
	}
	resModel.IsCompleted = dBModel.IsCompleted
	resModel.TaskErrorMessage = &dBModel.TaskErrorMessage
	return resModel
}

// ConvertTaskSchedulerDataToDBTaskSchedulerForUpdate func
func ConvertTaskSchedulerDataToDBTaskSchedulerForUpdate(dataPOST map[string]interface{}, resModel TaskScheduler) TaskScheduler {
	var (
		res interface{}
		val string
	)
	if dataPOST != nil {
		res = dataPOST["Name"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strName := val
			resModel.Name = &strName
		}
		res = dataPOST["Description"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strDescription := val
			resModel.Description = &strDescription
		}
		res = dataPOST["TaskStartDate"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			taskStartDate := val
			vTaskStartDate, sTaskStartDate := time.Parse(DateFormat, taskStartDate)
			if sTaskStartDate == nil {
				resModel.TaskStartDate = &vTaskStartDate
			}
		}
		res = dataPOST["TaskEndDate"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			taskEndDate := val
			vTaskEndDate, sTaskEndDate := time.Parse(DateFormat, taskEndDate)
			if sTaskEndDate == nil {
				resModel.TaskEndDate = &vTaskEndDate
			}
		}
		res = dataPOST["Infinite"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			infinite := val
			vInfinite, sInfinite := strconv.ParseBool(infinite)
			if sInfinite == nil {
				resModel.Infinite = vInfinite
			}
		}
		res = dataPOST["Type"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			vType := val
			resModel.Type = &vType
		}
		res = dataPOST["Operation"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			vOperation := val
			resModel.Operation = &vOperation
		}
		res = dataPOST["IsRepeat"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strIsRepeat := val
			vIsRepeat, sIsRepeat := strconv.ParseBool(strIsRepeat)
			if sIsRepeat == nil {
				resModel.IsRepeat = vIsRepeat
			}
		}
		res = dataPOST["RunAfter"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strRunAfter := val
			vRunAfter, sRunAfter := strconv.ParseBool(strRunAfter)
			if sRunAfter == nil {
				resModel.RunAfter = vRunAfter
			}
		}
		res = dataPOST["Enabled"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strEnabled := val
			vEnabled, sEnabled := strconv.ParseBool(strEnabled)
			if sEnabled == nil {
				resModel.Enabled = vEnabled
			}
		}
		res = dataPOST["NextRun"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strNextRun := val
			vNextRun, sNextRun := time.Parse(DateFormat, strNextRun)
			if sNextRun == nil {
				resModel.NextRun = &vNextRun
			}
		}
		res = dataPOST["FromDate"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strFromDate := val
			vFromDate, sFromDate := time.Parse(DateFormat, strFromDate)
			if sFromDate == nil {
				resModel.FromDate = &vFromDate
			}
		}
		res = dataPOST["ToDate"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strToDate := val
			vToDate, sToDate := time.Parse(DateFormat, strToDate)
			if sToDate == nil {
				resModel.ToDate = &vToDate
			}
		}
		res = dataPOST["StartAtTime"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strStartAtTime := val
			vStartAtTime := []uint8(strStartAtTime)
			resModel.StartAtTime = &vStartAtTime
		}
		res = dataPOST["Repeat"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strRepeat := val
			resModel.Repeat = &strRepeat
		}
		res = dataPOST["RepeatEvery"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strRepeatEvery := val
			vRepeatEvery, sRepeatEvery := strconv.Atoi(strRepeatEvery)
			if sRepeatEvery == nil {
				resModel.RepeatEvery = vRepeatEvery
			}
		}
		res = dataPOST["PreviousDay"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strPreviousDay := val
			vPreviousDay, sPreviousDay := strconv.Atoi(strPreviousDay)
			if sPreviousDay == nil {
				resModel.PreviousDay = vPreviousDay
			}
		}
		res = dataPOST["RepeatOn"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strRepeatOn := val
			resModel.RepeatOn = &strRepeatOn
		}
		res = dataPOST["RepeatOnDayMonth"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strRepeatOnDayMonth := val
			vRepeatOnDayMonth, sRepeatOnDayMonth := strconv.Atoi(strRepeatOnDayMonth)
			if sRepeatOnDayMonth == nil {
				resModel.RepeatOnDayMonth = vRepeatOnDayMonth
			}
		}
		res = dataPOST["TaskExecuted"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strTaskExecuted := val
			vTaskExecuted, sTaskExecuted := time.Parse(FullTimeFormat, strTaskExecuted)
			if sTaskExecuted == nil {
				resModel.TaskExecuted = &vTaskExecuted
			}
		}
		res = dataPOST["TaskEnded"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strTaskEnded := val
			vTaskEnded, sTaskEnded := time.Parse(FullTimeFormat, strTaskEnded)
			if sTaskEnded == nil {
				resModel.TaskEnded = &vTaskEnded
			}
		}
		res = dataPOST["IsCompleted"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strIsCompleted := val
			vIsCompleted, sIsCompleted := strconv.ParseBool(strIsCompleted)
			if sIsCompleted == nil {
				resModel.IsCompleted = vIsCompleted
			}
		}
		res = dataPOST["TaskErrorMessage"]
		val = fmt.Sprintf("%v", res)
		if res != nil {
			strTaskErrorMessage := val
			resModel.TaskErrorMessage = &strTaskErrorMessage
		}

		if dataPOST["RunAfterTask"] != nil {
			var (
				taskModels RunAfterTask
			)
			bytTaskPOST, errTaskPOST := json.Marshal(dataPOST["RunAfterTask"])
			if errTaskPOST == nil {
				json.Unmarshal([]byte(bytTaskPOST), &taskModels)
				resModel.RunAfterTask = &taskModels
			}
		}
	}
	return resModel
}
