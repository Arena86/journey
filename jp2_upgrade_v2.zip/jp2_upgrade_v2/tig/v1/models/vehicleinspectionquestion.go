package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleInspectionQuestion data
type VehicleInspectionQuestion struct {
	InspectionQuestionID      int        `gorm:"column:InspectionQuestionID;primaryKey;autoIncrement;not null" json:"InspectionQuestionID"`
	CreatedBy                 int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                bool       `gorm:"column:IsArchived" json:"IsArchived"`
	InspectionQuestionGroupID string     `gorm:"column:InspectionQuestionGroupID" json:"InspectionQuestionGroupID"`
	Question                  string     `gorm:"column:Question" json:"Question"`
	IsPhotoEnable             bool       `gorm:"column:IsPhotoEnable" json:"IsPhotoEnable"`
	IsMandatory               bool       `gorm:"column:IsMandatory" json:"IsMandatory"`
}

// VehicleInspectionQuestionResponse data
type VehicleInspectionQuestionResponse struct {
	InspectionQuestionID      int    `json:"InspectionQuestionID"`
	InspectionQuestionGroupID string `json:"InspectionQuestionGroupID"`
	Question                  string `json:"Question"`
	IsPhotoEnable             bool   `json:"IsPhotoEnable"`
	IsMandatory               bool   `json:"IsMandatory"`
	RowID                     int    `json:"RowID"`
}

// TableName func
func (VehicleInspectionQuestion) TableName() string {
	return "vehicleinspectionquestions"
}

// BeforeCreate func
func (object *VehicleInspectionQuestion) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleInspectionQuestion) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleInspectionQuestion) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("InspectionQuestionID", JSONObject)
	if res != nil {
		object.InspectionQuestionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("InspectionQuestionGroupID", JSONObject)
	if res != nil {
		object.InspectionQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("IsPhotoEnable", JSONObject)
	if res != nil {
		object.IsPhotoEnable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsMandatory", JSONObject)
	if res != nil {
		object.IsMandatory, _ = strconv.ParseBool(val)
	}
	return
}
