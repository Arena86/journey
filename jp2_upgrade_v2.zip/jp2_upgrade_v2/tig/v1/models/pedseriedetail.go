package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PEDSerieDetail data
type PEDSerieDetail struct {
	PEDSerieDetailID int        `gorm:"column:PEDSerieDetailID;primaryKey;autoIncrement;not null"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	PEDSerieID       int        `gorm:"column:PEDSerieID" json:"PEDSerieID"`
	Name             string     `gorm:"column:Name" json:"Name"`
	Sort             int        `gorm:"column:Sort" json:"Sort"`
	ImageURL         string     `gorm:"column:ImageURL" json:"ImageURL"`
	ImageSize        int        `gorm:"column:ImageSize" json:"ImageSize"`
	ImageKey         string     `gorm:"column:ImageKey" json:"ImageKey"`
	ETag             string     `gorm:"column:ETag" json:"ETag"`
}

// PEDSerieDetailResponse data
type PEDSerieDetailResponse struct {
	PEDSerieDetailID int    `json:"PEDSerieDetailID"`
	PEDSerieID       int    `json:"PEDSerieID"`
	Name             string `json:"Name"`
	Sort             int    `json:"Sort"`
	ImageKey         string `json:"ImageKey"`
	ImageURL         string `json:"ImageURL"`
	ImageSize        int    `json:"ImageSize"`
	ETag             string `json:"ETag"`
}

// TableName func
func (PEDSerieDetail) TableName() string {
	return "pedseriedetails"
}

// BeforeCreate func
func (object *PEDSerieDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PEDSerieDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PEDSerieDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PEDSerieDetailID", JSONObject)
	if res != nil {
		object.PEDSerieDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PEDSerieID", JSONObject)
	if res != nil {
		object.PEDSerieID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		object.Sort, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ImageKey", JSONObject)
	if res != nil {
		object.ImageKey = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageURL", JSONObject)
	if res != nil {
		object.ImageURL = val
	}
	val, res = services.ConvertJSONValueToVariable("ImageSize", JSONObject)
	if res != nil {
		object.ImageSize, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ETag", JSONObject)
	if res != nil {
		object.ETag = val
	}
	return
}
