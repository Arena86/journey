package models

import "time"

// GraphHopperConfig str
type GraphHopperConfig struct {
	GraphHopperKey      int    `json:"GraphHopperKey"`
	APIURL              string `json:"APIURL"`
	APIKey              string `json:"APIKey"`
	NetworkDataProvider string `json:"NetworkDataProvider"`
	CalcPoints          bool   `json:"CalcPoints"`
}

// GraphHopperConfig str
type SmartSchedulingSchedule struct {
	JobTaskID         int       `json:"JobTaskID"`
	ResourceID        int       `json:"ResourceID"`
	ScheduleStartDate time.Time `json:"ScheduleStartDate"`
	ScheduleEndDate   time.Time `json:"ScheduleEndDate"`
	PreComputedRoute  string    `json:"PreComputedRoute"`
}
