package models

import (
	"time"

	"gorm.io/gorm"
)

// JobSelection data
type JobSelection struct {
	JobSelectionID int        `gorm:"column:JobSelectionID;primaryKey;autoIncrement;not null"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID          int        `gorm:"column:JobID" json:"JobID"`
	RelatedJobID   int        `gorm:"column:RelatedJobID" json:"RelatedJobID"`
	HasSequence    bool       `gorm:"column:HasSequence" json:"HasSequence"`
	Sort           int        `gorm:"column:Sort" json:"Sort"`
}

// JobSelectionResponse data
type JobSelectionResponse struct {
	JobID             int                          `json:"JobID"`
	JobType           int                          `json:"JobType"`
	JobTypeIcon       string                       `json:"JobTypeIcon"`
	JobTypeName       string                       `json:"JobTypeName"`
	Status            int                          `json:"Status"`
	StatusIcon        string                       `json:"StatusIcon"`
	StatusName        string                       `json:"StatusName"`
	TotalJob          float64                      `json:"TotalJob"`
	LocationID        int                          `json:"LocationID"`
	BusinessPartnerID int                          `json:"BusinessPartnerID"`
	JobHeader         JobSelectionHeaderResponse   `json:"jobHeader"`
	JobTotals         JobSelectionJobTotalResponse `json:"jobTotals"`
	JobTasks          []JobTaskSelectionResponse   `json:"jobTasks"`
	HasSequence       bool                         `json:"HasSequence"`
	Sort              int                          `json:"Sort"`
	IsCombinedChild   bool                         `json:"	IsCombinedChild"`
}

// JobTaskSelectionResponse data
type JobTaskSelectionResponse struct {
	JobType              int    `json:"JobType"`
	JobTypeIcon          string `json:"JobTypeIcon"`
	JobTypeName          string `json:"JobTypeName"`
	JobTaskID            int    `json:"JobTaskID"`
	ServiceTimeInMinutes int    `json:"ServiceTimeInMinutes"`
	Status               int    `json:"Status"`
	StatusName           string `json:"StatusName"`
	StatusIcon           string `json:"StatusIcon"`
	NavigationAddress    string `json:"NavigationAddress"`
}

// JobSelectionHeaderResponse data
type JobSelectionHeaderResponse struct {
	JobNumber        string     `json:"JobNumber"`
	JobDate          *time.Time `json:"JobDate"`
	CompanyName      string     `json:"CompanyName"`
	ResourceType     int        `json:"ResourceType"`
	ResourceTypeIcon string     `json:"ResourceTypeIcon"`
	ResourceTypeName string     `json:"ResourceTypeName"`
	Priority         int        `json:"Priority"`
	PriorityName     string     `json:"PriorityName"`
	PriorityIcon     string     `json:"PriorityIcon"`
}

// JobSelectionJobTotalResponse data
type JobSelectionJobTotalResponse struct {
	TotalJob float64 `json:"TotalJob"`
}

// TableName func
func (JobSelection) TableName() string {
	return "jobsselection"
}

// BeforeCreate func
func (object *JobSelection) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobSelection) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}
