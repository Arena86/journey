package models

// RoutexlTourPOST str
type RoutexlTourPOST struct {
	SkipOptimization bool          `json:"skipOptimization"`
	Type             string        `json:"type"`
	Locations        []RoutexlTour `json:"locations"`
}

// RoutexlTour str
type RoutexlTour struct {
	Address      string                  `json:"address"`
	Lat          string                  `json:"lat"`
	Lng          string                  `json:"lng"`
	Servicetime  *string                 `json:"servicetime,omitempty"`
	Restrictions *RoutexlTourRestriction `json:"restrictions,omitempty"`
}

// RoutexlTourRestriction str
type RoutexlTourRestriction struct {
	Ready  *int `json:"ready,omitempty"`
	After  *int `json:"after,omitempty"`
	Before *int `json:"before,omitempty"`
	Due    *int `json:"due,omitempty"`
}

// RouteXL data
type RouteXL struct {
	RouteXLUrl string `json:"RouteXLUrl"`
	UserName   string `json:"UserName"`
	Password   string `json:"Password"`
}

// RouteXLResponse data
type RouteXLResponse struct {
	Data RouteXL `json:"data"`
}
