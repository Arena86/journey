package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Address data
type Address struct {
	AddressID         int        `gorm:"column:AddressID;primaryKey;autoIncrement;not null" json:"AddressID"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	AddressTypeID     int        `gorm:"column:AddressTypeID" json:"AddressTypeID"`
	AddressLine1      string     `gorm:"column:AddressLine1;type:varchar(100)" json:"AddressLine1"`
	AddressLine2      string     `gorm:"column:AddressLine2;type:varchar(100)" json:"AddressLine2"`
	AddressLine3      string     `gorm:"column:AddressLine3;type:varchar(100)" json:"AddressLine3"`
	AddressLine4      string     `gorm:"column:AddressLine4;type:varchar(100)" json:"AddressLine4"`
	City              string     `gorm:"column:City;type:varchar(100)" json:"City"`
	PostalCode        string     `gorm:"column:PostalCode;type:varchar(10)" json:"PostalCode"`
	State             string     `gorm:"column:State;type:varchar(10)" json:"State"`
	Country           string     `gorm:"column:Country;type:varchar(10)" json:"Country"`
	AttentionTo       string     `gorm:"column:AttentionTo;type:varchar(10)" json:"AttentionTo"`
	IsArchived        bool       `gorm:"column:IsArchived" json:"IsArchived"`
	EntityID          int        `gorm:"column:EntityID" json:"EntityID"`
	Entity            string     `gorm:"column:Entity" json:"Entity"`
	IsBilling         bool       `gorm:"column:IsBilling" json:"IsBilling"`
	IsDepot           bool       `gorm:"column:IsDepot" json:"IsDepot"`
	NavigationAddress string     `gorm:"column:NavigationAddress" json:"NavigationAddress"`
}

// AddressResponse data
type AddressResponse struct {
	AddressID         int    `json:"AddressID"`
	AddressTypeID     int    `json:"AddressTypeID"`
	AddressTypeName   string `json:"AddressTypeName"`
	AddressLine1      string `json:"AddressLine1"`
	AddressLine2      string `json:"AddressLine2"`
	AddressLine3      string `json:"AddressLine3"`
	AddressLine4      string `json:"AddressLine4"`
	City              string `json:"City"`
	PostalCode        string `json:"PostalCode"`
	State             string `json:"State"`
	Country           string `json:"Country"`
	AttentionTo       string `json:"AttentionTo"`
	EntityID          int    `json:"EntityID"`
	Entity            string `json:"Entity"`
	NavigationAddress string `json:"NavigationAddress"`
	IsDeleted         bool   `json:"IsDeleted"`
	IsArchived        bool   `json:"IsArchived"`
	IsDepot           bool   `json:"IsDepot"`
	IsLocation        bool   `json:"IsLocation"`
	IsDefault         bool   `json:"IsDefault"`
	IsDefaultBilling  bool   `json:"IsDefaultBilling"`
	IsDefaultDepot    bool   `json:"IsDefaultDepot"`
}

// AddressJobResponse data
type AddressJobResponse struct {
	AddressTypeID     int    `json:"AddressTypeID"`
	AddressTypeName   string `json:"AddressTypeName"`
	NavigationAddress string `json:"NavigationAddress"`
}

// AddressesRequest data
type AddressesRequest struct {
	AddressRequest []AddressResponse
}

// TableName func
func (Address) TableName() string {
	return "addresses"
}

// BeforeCreate func
func (object *Address) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Address) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Address) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AddressID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.AddressID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("AddressTypeID", JSONObject)
	if res != nil {
		vAddressTypeID, sAddressTypeID := strconv.Atoi(val)
		if sAddressTypeID == nil {
			object.AddressTypeID = vAddressTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("AddressLine1", JSONObject)
	if res != nil {
		object.AddressLine1 = val
	}
	val, res = services.ConvertJSONValueToVariable("AddressLine2", JSONObject)
	if res != nil {
		object.AddressLine2 = val
	}
	val, res = services.ConvertJSONValueToVariable("AddressLine3", JSONObject)
	if res != nil {
		object.AddressLine3 = val
	}
	val, res = services.ConvertJSONValueToVariable("AddressLine4", JSONObject)
	if res != nil {
		object.AddressLine4 = val
	}
	val, res = services.ConvertJSONValueToVariable("City", JSONObject)
	if res != nil {
		object.City = val
	}
	val, res = services.ConvertJSONValueToVariable("PostalCode", JSONObject)
	if res != nil {
		object.PostalCode = val
	}
	val, res = services.ConvertJSONValueToVariable("State", JSONObject)
	if res != nil {
		object.State = val
	}
	val, res = services.ConvertJSONValueToVariable("Country", JSONObject)
	if res != nil {
		object.Country = val
	}
	val, res = services.ConvertJSONValueToVariable("AttentionTo", JSONObject)
	if res != nil {
		object.AttentionTo = val
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDefaultBilling", JSONObject)
	if res != nil {
		object.IsBilling, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDefaultDepot", JSONObject)
	if res != nil {
		object.IsDepot, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("NavigationAddress", JSONObject)
	if res != nil {
		object.NavigationAddress = val
	}
	return
}
