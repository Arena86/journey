package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ItemGroup data
type ItemGroup struct {
	ItemGroupID   int        `gorm:"column:ItemGroupID;primaryKey;autoIncrement;not null" json:"ItemGroupID"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ItemGroupName string     `gorm:"column:ItemGroupName" json:"ItemGroupName"`
	ItemGroupCode string     `gorm:"column:ItemGroupCode" json:"ItemGroupCode"`
}

// ItemGroupResponse data
type ItemGroupResponse struct {
	ItemGroupID   int                    `json:"ItemGroupID"`
	ItemGroupName string                 `json:"ItemGroupName"`
	ItemGroupCode string                 `json:"ItemGroupCode"`
	UDFs          []UDFResponse          `json:"UDFs"`
	UDF           map[string]interface{} `json:"UDF"`
}

// TableName func
func (ItemGroup) TableName() string {
	return "itemgroups"
}

// BeforeCreate func
func (object *ItemGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ItemGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ItemGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ItemGroupID", JSONObject)
	if res != nil {
		vItemGroupID, sItemGroupID := strconv.Atoi(val)
		if sItemGroupID == nil {
			object.ItemGroupID = vItemGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ItemGroupName", JSONObject)
	if res != nil {
		object.ItemGroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("ItemGroupCode", JSONObject)
	if res != nil {
		object.ItemGroupCode = val
	}
	return
}
