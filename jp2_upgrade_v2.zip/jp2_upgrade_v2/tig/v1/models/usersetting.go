package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// UserSettingValue str
type UserSettingValue struct {
	JobFormSettings struct {
		FormWidth string `json:"formWidth"` // 100%
	} `json:"jobFormSettings"`
	FormSetting struct {
		ShowColonAfterLabel bool   `json:"showColonAfterLabel"`
		LabelLocation       string `json:"labelLocation"`
		FormWidth           string `json:"formWidth"`
		DisplayUDF          bool   `json:"displayUDF"`
	} `json:"formSettings"`
	SearchFormSetting struct {
		ShowColonAfterLabel bool   `json:"showColonAfterLabel"`
		LabelLocation       string `json:"labelLocation"`
	} `json:"searchFormSettings"`
	UDFFormSettings struct {
		ShowColonAfterLabel bool   `json:"showColonAfterLabel"`
		LabelLocation       string `json:"labelLocation"`
	} `json:"udfFormSettings"`
	ListSetting struct {
		Paging struct {
			PageSize         int   `json:"pageSize"`
			AllowedPageSizes []int `json:"allowedPageSizes"`
		} `json:"paging"`
	} `json:"listSettings"`
}

// UserSetting data
type UserSetting struct {
	UserSettingsID int        `gorm:"column:UserSettingsID;primaryKey;autoIncrement;not null" json:"UserSettingsID"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	AccountKey     int        `gorm:"column:AccountKey" json:"AccountKey"`
	Value          *string    `gorm:"column:Value" json:"Value"`
}

// UserSettingResponse data
type UserSettingResponse struct {
	UserSettingsID int     `json:"UserSettingsID"`
	AccountKey     int     `json:"AccountKey"`
	Value          *string `json:"Value"`
}

// TableName func
func (UserSetting) TableName() string {
	return "usersettings"
}

// BeforeCreate func
func (object *UserSetting) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *UserSetting) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *UserSetting) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("UserSettingsID", JSONObject)
	if res != nil {
		vUserSettingsID, sUserSettingsID := strconv.Atoi(val)
		if sUserSettingsID == nil {
			object.UserSettingsID = vUserSettingsID
		}
	}
	val, res = services.ConvertJSONValueToVariable("AccountKey", JSONObject)
	if res != nil {
		vAccountKey, sAccountKey := strconv.Atoi(val)
		if sAccountKey == nil {
			object.AccountKey = vAccountKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("Value", JSONObject)
	if res != nil {
		valJSON := val
		object.Value = &valJSON
	}
	return
}
