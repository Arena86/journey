package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobCombined data
type JobCombined struct {
	JobCombinedID  int        `gorm:"column:JobCombinedID;primaryKey;autoIncrement;not null"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	JobID          int        `gorm:"column:JobID" json:"JobID"`
	HasSequence    bool       `gorm:"-" json:"HasSequence"`
	Sort           int        `gorm:"-" json:"Sort"`
	Note           string     `gorm:"column:Note" json:"Note"`
	OnTheSameRoute bool       `gorm:"column:OnTheSameRoute" json:"OnTheSameRoute"`
	Sequence       string     `gorm:"column:Sequence" json:"Sequence"`
}

// JobCombinedRequest data
type JobCombinedRequest struct {
	Note         string        `json:"Note"`
	CombinedJobs []JobCombined `json:"CombinedJobs"`
}

// JobCombinedResponse data
type JobCombinedResponse struct {
	Sequence       string                 `json:"Sequence"`
	OnTheSameRoute bool                   `json:"OnTheSameRoute"`
	Note           string                 `json:"Note"`
	CombinedJobs   []JobSelectionResponse `json:"CombinedJobs"`
}

// TableName func
func (JobCombined) TableName() string {
	return "jobcombineds"
}

// BeforeCreate func
func (object *JobCombined) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobCombined) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobCombined) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobCombinedID", JSONObject)
	if res != nil {
		object.JobCombinedID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Note", JSONObject)
	if res != nil {
		object.Note = val
	}
	val, res = services.ConvertJSONValueToVariable("OnTheSameRoute", JSONObject)
	if res != nil {
		object.OnTheSameRoute, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Sequence", JSONObject)
	if res != nil {
		object.Sequence = val
	}
	return
}
