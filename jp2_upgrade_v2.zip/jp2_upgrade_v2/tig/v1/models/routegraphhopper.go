package models

type GraphHopperResponseSuccess struct {
	Copyrights         []string `json:"copyrights"`
	JobID              string   `json:"job_id"`
	Status             string   `json:"status"`
	WaitingTimeInQueue int64    `json:"waiting_time_in_queue"`
	ProcessingTime     int64    `json:"processing_time"`
	Solution           struct {
		Costs            int32 `json:"costs"`
		Distance         int32 `json:"distance"`
		TransportTime    int64 `json:"transport_time"`
		CompletionTime   int64 `json:"completion_time"`
		MaxOperationTime int64 `json:"max_operation_time"`
		WaitingTime      int64 `json:"waiting_time"`
		ServiceDuration  int64 `json:"service_duration"`
		PreparationTime  int64 `json:"preparation_time"`
		NoVehicles       int32 `json:"no_vehicles"`
		NoUnassigned     int32 `json:"no_unassigned"`
		Routes           []struct {
			VehicleID       string  `json:"vehicle_id"`
			ShiftID         string  `json:"shift_id"`
			Distance        float64 `json:"distance"`
			TransportTime   float64 `json:"transport_time"`
			CompletionTime  float64 `json:"completion_time"`
			WaitingTime     float64 `json:"waiting_time"`
			ServiceDuration float64 `json:"service_duration"`
			PreparationTime float64 `json:"preparation_time"`
			Activities      []struct {
				Type       string `json:"type"`
				LocationID string `json:"location_id"`
				Address    struct {
					LocationID string  `json:"location_id"`
					Lat        float64 `json:"lat"`
					Lon        float64 `json:"lon"`
				} `json:"address"`
				ArrTime         int64   `json:"arr_time"`
				ArrDateTime     *string `json:"arr_date_time"`
				EndTime         int64   `json:"end_time"`
				EndDateTime     *string `json:"end_date_time"`
				Distance        int64   `json:"distance"`
				DrivingTime     int64   `json:"driving_time"`
				PreparationTime int64   `json:"preparation_time"`
				WaitingTime     int64   `json:"waiting_time"`
				LoadBefore      []int32 `json:"load_before,omitempty"`
				LoadAfter       []int32 `json:"load_after,omitempty"`
			} `json:"activities"`
			Points []struct {
				Coordinates [][]float64 `json:"coordinates"`
				Type        string      `json:"type"`
			} `json:"points,omitempty"`
		} `json:"routes"`
		UnAssigned struct {
			Services  []string `json:"services"`
			Shipments []string `json:"shipments"`
			Breaks    []string `json:"breaks"`
			Details   []struct {
				ID     string `json:"id"`
				Code   int32  `json:"code"`
				Reason string `json:"reason"`
			} `json:"details"`
		} `json:"unassigned"`
	} `json:"solution"`
}

type GraphHopperError struct {
	Message string `json:"message"`
	Hints   []struct {
		Message string `json:"message"`
	} `json:"hints"`
	Status string `json:"status"`
}

// GraphHopperJPJSON str
type GraphHopperJPJSON struct {
	ResourceIDs        []int                  `json:"resourceIDs,omitempty"`
	JobIDs             []int                  `json:"jobIDs,omitempty"`
	TimeStart          string                 `json:"timeStart,omitempty"`
	TimeEnd            string                 `json:"timeEnd,omitempty"`
	ConsiderTraffic    bool                   `json:"considerTraffic,omitempty"`
	SnapPreventions    []string               `json:"snapPreventions,omitempty"`
	UseAllowedVehicles bool                   `json:"useAllowedVehicles,omitempty"`
	Objectives         []GraphHopperObjective `json:"objectives,omitempty"`
}

// GraphHopperObjective str
type GraphHopperObjective struct {
	Type  string `json:"type,omitempty"`
	Value string `json:"value,omitempty"`
}

type GraphHopperVehicle struct {
	VehicleID        string                         `json:"vehicle_id,omitempty"`
	TypeID           string                         `json:"type_id,omitempty"`
	StartAddress     *GraphHopperAddressJSON        `json:"start_address,omitempty"`
	EndAddress       *GraphHopperAddressJSON        `json:"end_address,omitempty"`
	Break            *GraphHopperDriveTimeBreakJSON `json:"break,omitempty"`
	ReturnToDepot    bool                           `json:"return_to_depot"`
	EarliestStart    int64                          `json:"earliest_start,omitempty"`
	LatestEnd        int64                          `json:"latest_end,omitempty"`
	MaxDistance      int                            `json:"max_distance,omitempty"`
	MaxDrivingTime   int                            `json:"max_driving_time,omitempty"`
	MaxJobs          int                            `json:"max_jobs,omitempty"`
	MinJobs          int                            `json:"min_jobs,omitempty"`
	MoveToEndAddress bool                           `json:"move_to_end_address"`
}

type GraphHopperAddressJSON struct {
	LocationID string  `json:"location_id,omitempty"`
	Lon        float64 `json:"lon,omitempty"`
	Lat        float64 `json:"lat,omitempty"`
	Name       string  `json:"name,omitempty"`
}

type GraphHopperDriveTimeBreakJSON struct {
	Duration           int64 `json:"duration,omitempty"`
	MaxDrivingTime     int64 `json:"max_driving_time,omitempty"`
	InitialDrivingTime int64 `json:"initial_driving_time,omitempty"`
}

type GraphHopperVehicleTypeJSON struct {
	TypeID              string `json:"type_id,omitempty"`
	Profile             string `json:"profile,omitempty"`
	ConsiderTraffic     bool   `json:"consider_traffic"`
	NetworkDataProvider string `json:"network_data_provider,omitempty"`
}

type GraphHopperServiceJSON struct {
	ID              string                      `json:"id,omitempty"`
	Type            string                      `json:"type,omitempty"`
	Priority        int32                       `json:"priority,omitempty"`
	Name            string                      `json:"name,omitempty"`
	Address         *GraphHopperAddressJSON     `json:"address,omitempty"`
	Duration        int64                       `json:"duration,omitempty"`
	TimeWindows     []GraphHopperTimeWindowJSON `json:"time_windows,omitempty"`
	AllowedVehicles []string                    `json:"allowed_vehicles,omitempty"`
}

type GraphHopperTimeWindowJSON struct {
	Earliest int64 `json:"earliest,omitempty"`
	Latest   int64 `json:"latest,omitempty"`
}

type GraphHopperShipmentJSON struct {
	ID              string                           `json:"id,omitempty"`
	Pickup          *GraphHopperPickupOrDeliveryJSON `json:"pickup,omitempty"`
	Delivery        *GraphHopperPickupOrDeliveryJSON `json:"delivery,omitempty"`
	Name            string                           `json:"name,omitempty"`
	Priority        int32                            `json:"priority,omitempty"`
	AllowedVehicles []string                         `json:"allowed_vehicles,omitempty"`
}

type GraphHopperPickupOrDeliveryJSON struct {
	Address     *GraphHopperAddressJSON     `json:"address,omitempty"`
	Duration    int64                       `json:"duration,omitempty"`
	TimeWindows []GraphHopperTimeWindowJSON `json:"time_windows,omitempty"`
}

type GraphHopperConfiguration struct {
	Routing *GraphHopperConfigurationRouting `json:"routing,omitempty"`
}

type GraphHopperConfigurationRouting struct {
	CalcPoints          bool     `json:"calc_points"`
	ConsiderTraffic     bool     `json:"consider_traffic"`
	NetworkDataProvider string   `json:"network_data_provider,omitempty"`
	SnapPreventions     []string `json:"snap_preventions,omitempty"`
}
type GraphHoppeRelations struct {
	Type string   `json:"type"`
	IDs  []string `json:"ids"`
}
type GraphHopperJSON struct {
	Vehicles      []GraphHopperVehicle         `json:"vehicles,omitempty"`
	VehicleTypes  []GraphHopperVehicleTypeJSON `json:"vehicle_types,omitempty"`
	Services      []GraphHopperServiceJSON     `json:"services,omitempty"`
	Shipments     []GraphHopperShipmentJSON    `json:"shipments,omitempty"`
	Objectives    []GraphHopperObjective       `json:"objectives,omitempty"`
	Relations     []GraphHoppeRelations        `json:"relations,omitempty"`
	Configuration *GraphHopperConfiguration    `json:"configuration,omitempty"`
}
