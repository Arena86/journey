package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DynamicFormFlow data
type DynamicFormFlow struct {
	FormUDTFlowID int        `gorm:"column:FormUDTFlowID;primaryKey;autoIncrement;not null" json:"FormUDTFlowID"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DynamicFormID int        `gorm:"column:DynamicFormID" json:"DynamicFormID"`
	FormFlowID    int        `gorm:"column:FormFlowID" json:"FormFlowID"`
}

// DynamicFormFlowResponse data
type DynamicFormFlowResponse struct {
	FormUDTFlowID int `json:"FormUDTFlowID"`
	DynamicFormID int `json:"DynamicFormID"`
	FormFlowID    int `json:"FormFlowID"`
}

// TableName func
func (DynamicFormFlow) TableName() string {
	return "dynamicformflows"
}

// BeforeCreate func
func (object *DynamicFormFlow) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DynamicFormFlow) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DynamicFormFlow) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormUDTFlowID", JSONObject)
	if res != nil {
		object.FormUDTFlowID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DynamicFormID", JSONObject)
	if res != nil {
		object.DynamicFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowID", JSONObject)
	if res != nil {
		object.FormFlowID, _ = strconv.Atoi(val)
	}
	return
}
