package models

// SygicAPIRespone str
type SygicAPIRespone struct {
	SuccessfulCount int           `json:"successfulCount"`
	Errors          SygicAPIError `json:"errors"`
	Responses       interface{}   `json:"responses"`
	Message         string        `json:"message"`
}

// SygicAPIError str
type SygicAPIError struct {
	AlreadyActivated      []string `json:"alreadyActivated"`
	InvalidProduct        []string `json:"invalidProduct"`
	NotFound              []string `json:"notFound"`
	InvalidLicenseAction  []string `json:"invalidLicenseAction"`
	MaxRepairCountReached []string `json:"maxRepairCountReached"`
	AlreadyDeactivated    []string `json:"alreadyDeactivated"`
	NotEnoughLicenses     []string `json:"notEnoughLicenses"`
	ProductServerError    []string `json:"productServerError"`
}
