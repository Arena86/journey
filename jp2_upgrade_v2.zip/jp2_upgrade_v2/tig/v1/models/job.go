package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// LW const
const LW = "lw" // last week
// TW const
const TW = "tw" // this week from get all jobs
// NW const
const NW = "nw" // next week from get all jobs
// FT const
const FT = "ft" // Future from get all jobs
// TM const
const TM = "tm" // tomorrow - only tomorrow
// YD const
const YD = "yd" // only yester day
// PV const
const PV = "pv" // previous from yesterday and before -> yesterday -> past
// TD const
const TD = "td" // today

// Job str
type Job struct {
	JobID                       int                  `gorm:"column:JobID;primaryKey;autoIncrement;not null"`
	IsArchived                  bool                 `gorm:"column:IsArchived"`
	CreatedBy                   int                  `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                 *time.Time           `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                  int                  `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                *time.Time           `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                   bool                 `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                     bool                 `gorm:"column:IsAudit" json:"IsAudit"`
	JobDate                     *time.Time           `gorm:"column:JobDate" json:"JobDate"`
	JobNumber                   string               `gorm:"column:JobNumber" json:"JobNumber"`
	EstimateNumber              string               `gorm:"column:EstimateNumber" json:"EstimateNumber"`
	InvoiceNumber               string               `gorm:"column:InvoiceNumber" json:"InvoiceNumber"`
	CreditNoteNumber            string               `gorm:"column:CreditNoteNumber" json:"CreditNoteNumber"`
	IsJob                       bool                 `gorm:"column:IsJob" json:"IsJob"`
	IsEstimate                  bool                 `gorm:"column:IsEstimate" json:"IsEstimate"`
	IsInvoice                   bool                 `gorm:"column:IsInvoice" json:"IsInvoice"`
	IsCreditNote                bool                 `gorm:"column:IsCreditNote" json:"IsCreditNote"`
	JobType                     int                  `gorm:"column:JobType" json:"JobType"`
	TravelChargeMode            int                  `gorm:"column:TravelChargeMode" json:"TravelChargeMode"`
	TravelCharge                int                  `gorm:"column:TravelCharge" json:"TravelCharge"`
	LocationID                  int                  `gorm:"column:LocationID" json:"LocationID"`
	BusinessPartnerID           int                  `gorm:"column:BusinessPartnerID" json:"BusinessPartnerID"`
	Status                      int                  `gorm:"column:Status" json:"Status"`
	InProgressStatus            string               `gorm:"column:InProgressStatus" json:"InProgressStatus"`
	JobTaskStatus               string               `gorm:"column:JobTaskStatus" json:"JobTaskStatus"`
	EstimatedDistance           float64              `gorm:"column:EstimatedDistance" json:"EstimatedDistance"`
	EstimatedTravelTime         float64              `gorm:"column:EstimatedTravelTime" json:"EstimatedTravelTime"`
	Subtotal                    float64              `gorm:"column:Subtotal" json:"Subtotal"`
	TotalTax                    float64              `gorm:"column:TotalTax" json:"TotalTax"`
	TotalJob                    float64              `gorm:"column:TotalJob" json:"TotalJob"`
	Distance                    float64              `gorm:"column:Distance" json:"Distance"`
	DistanceCharge              float64              `gorm:"column:DistanceCharge" json:"DistanceCharge"`
	TravelTime                  float64              `gorm:"column:TravelTime" json:"TravelTime"`
	TravelTimeCharge            float64              `gorm:"column:TravelTimeCharge" json:"TravelTimeCharge"`
	Comment                     string               `gorm:"column:Comment" json:"Comment"`
	ResourceType                int                  `gorm:"column:ResourceType" json:"ResourceType"`
	ContactDetails              string               `gorm:"column:ContactDetails" json:"ContactDetails"`
	CountryCode                 string               `gorm:"column:CountryCode" json:"CountryCode"`
	ContactPhoneNumber          string               `gorm:"column:ContactPhoneNumber" json:"ContactPhoneNumber"`
	JobPickup                   *JobPickup           `gorm:"foreignKey:JobID;references:JobID" json:"jobPickup"`
	JobDelivery                 *JobDelivery         `gorm:"foreignKey:JobID;references:JobID" json:"jobDelivery"`
	JobOnSite                   *JobOnSite           `gorm:"foreignKey:JobID;references:JobID" json:"jobOnSite"`
	JobInStore                  *JobInStore          `gorm:"foreignKey:JobID;references:JobID" json:"jobInStore"`
	JobMultiple                 *JobMultiple         `gorm:"foreignKey:JobID;references:JobID" json:"jobMultiple"`
	JobCombined                 *JobCombined         `gorm:"foreignKey:JobID;references:JobID" json:"jobCombined"`
	JobResourcePickUp           *JobResourcePickup   `gorm:"foreignKey:JobID;references:JobID" json:"jobResourcePickUp"`
	JobResourceDelivery         *JobResourceDelivery `gorm:"foreignKey:JobID;references:JobID" json:"jobResourceDelivery"`
	JobDetails                  []JobDetail          `gorm:"foreignKey:JobID;references:JobID" json:"jobDetails"`
	JobTasks                    []JobTask            `gorm:"foreignKey:JobID;references:JobID" json:"jobTasks"`
	JobMap                      *JobMap              `gorm:"foreignKey:JobID;references:JobID" json:"jobMap"`
	TotalDiscountAmount         float64              `gorm:"column:TotalDiscountAmount" json:"TotalDiscountAmount"`
	TotalBufferAmount           float64              `gorm:"column:TotalBufferAmount" json:"TotalBufferAmount"`
	DistanceChargeTaxRate       float64              `gorm:"column:DistanceChargeTaxRate" json:"DistanceChargeTaxRate"`
	TravelTimeChargeTaxRate     float64              `gorm:"column:TravelTimeChargeTaxRate" json:"TravelTimeChargeTaxRate"`
	JobSelections               []JobSelection       `gorm:"foreignKey:JobID;references:JobID" json:"JobSelections"`
	EstimateDate                *time.Time           `gorm:"column:EstimateDate" json:"EstimateDate"`
	InvoiceDate                 *time.Time           `gorm:"column:InvoiceDate" json:"InvoiceDate"`
	CreditNoteDate              *time.Time           `gorm:"column:CreditNoteDate" json:"CreditNoteDate"`
	EstimateDueDate             *time.Time           `gorm:"column:EstimateDueDate" json:"EstimateDueDate"`
	InvoiceDueDate              *time.Time           `gorm:"column:InvoiceDueDate" json:"InvoiceDueDate"`
	CustomerApprovalDate        *time.Time           `gorm:"column:CustomerApprovalDate" json:"CustomerApprovalDate"`
	ManagerApprovalDate         *time.Time           `gorm:"column:ManagerApprovalDate" json:"ManagerApprovalDate"`
	RejectedDate                *time.Time           `gorm:"column:RejectedDate" json:"RejectedDate"`
	IsSent                      bool                 `gorm:"column:IsSent" json:"IsSent"`
	IsCustomerApproved          bool                 `gorm:"column:IsCustomerApproved" json:"IsCustomerApproved"`
	IsManagerApproved           bool                 `gorm:"column:IsManagerApproved" json:"IsManagerApproved"`
	IsRejected                  bool                 `gorm:"column:IsRejected" json:"IsRejected"`
	Token                       *string              `gorm:"column:Token" json:"Token"`
	Signature                   *string              `gorm:"column:Signature" json:"Signature"`
	SubmittedIP                 *string              `gorm:"column:SubmittedIP" json:"SubmittedIP"`
	JobFormsNavigation          *string              `gorm:"column:JobFormsNavigation" json:"JobFormsNavigation"`
	ErpInvoiceKey               *string              `gorm:"column:ErpInvoiceKey" json:"ErpInvoiceKey"`
	ErpInvoiceStatus            *string              `gorm:"column:ErpInvoiceStatus" json:"ErpInvoiceStatus"`
	ErpCreditNoteKey            *string              `gorm:"column:ErpCreditNoteKey" json:"ErpCreditNoteKey"`
	Priority                    int                  `gorm:"column:Priority" json:"Priority"`
	IsCombinedChild             bool                 `gorm:"column:IsCombinedChild" json:"IsCombinedChild"`
	IsMultipleChild             bool                 `gorm:"column:IsMultipleChild" json:"IsMultipleChild"`
	InvoiceMode                 int                  `gorm:"column:InvoiceMode" json:"InvoiceMode"`
	InvoiceTravelCostMode       int                  `gorm:"column:InvoiceTravelCostMode" json:"InvoiceTravelCostMode"`
	JobPrecomputedRoute         *string              `gorm:"column:JobPrecomputedRoute" json:"JobPrecomputedRoute"`
	IsRecurring                 bool                 `gorm:"column:IsRecurring" json:"IsRecurring"`
	RecurringJobID              int                  `gorm:"column:RecurringJobID" json:"RecurringJobID"`
	OptimizeJob                 bool                 `gorm:"column:OptimizeJob" json:"OptimizeJob"`
	ForcePaymentBeforeCompleted bool                 `gorm:"column:ForcePaymentBeforeCompleted" json:"ForcePaymentBeforeCompleted"`
	RecurringJob                *RecurringJob        `gorm:"foreignKey:JobID;references:JobID" json:"recurringJobs"`
	ExtraResources              string               `gorm:"column:ExtraResources" json:"ExtraResources"`
	InspectionForJobID          int                  `gorm:"column:InspectionForJobID" json:"InspectionForJobID"`
	IsInspection                bool                 `gorm:"column:IsInspection" json:"IsInspection"`
	SurchargeParentItemKeys     string               `gorm:"column:SurchargeParentItemKeys" json:"SurchargeParentItemKeys"`
	AdditionalFiles             []AdditionalFile     `gorm:"foreignKey:JobID;references:JobID" json:"AdditionalFiles"`
}

// JobResponse str
type JobResponse struct {
	JobID            int    `json:"JobID"`
	IsJob            bool   `json:"IsJob"`
	IsEstimate       bool   `json:"IsEstimate"`
	IsInvoice        bool   `json:"IsInvoice"`
	IsCreditNote     bool   `json:"IsCreditNote"`
	JobType          int    `json:"JobType"`
	JobTypeName      string `json:"JobTypeName"`
	JobTypeIcon      string `json:"JobTypeIcon"`
	TravelChargeMode int    `json:"TravelChargeMode"`
	LocationID       int    `json:"LocationID"`
	Status           int    `json:"Status"`
	StatusName       string `json:"StatusName"`
	StatusIcon       string `json:"StatusIcon"`
	InProgressStatus string `json:"InProgressStatus"`
	JobTaskStatus    string `json:"JobTaskStatus"`

	Signature   *string `json:"Signature"`
	SubmittedIP *string `json:"SubmittedIP"`

	JobHeader            JobHeaderResponse            `json:"jobHeader"`
	JobPickup            *JobPickupResponse           `json:"jobPickup"`
	JobDelivery          *JobDeliveryResponse         `json:"jobDelivery"`
	JobOnSite            *JobOnSiteResponse           `json:"jobOnSite"`
	JobInStore           *JobInStoreResponse          `json:"jobInStore"`
	JobDetails           []JobDetailForJobResponse    `json:"jobDetails"`
	JobMultiple          *JobMultipleResponse         `json:"jobMultiple"`
	JobCombined          *JobCombinedResponse         `json:"jobCombined"`
	JobResourcePickUp    *JobResourcePickupResponse   `json:"jobResourcePickUp"`
	JobResourceDelivery  *JobResourceDeliveryResponse `json:"jobResourceDelivery"`
	JobMap               JobMapResponse               `json:"jobMap"`
	JobComment           JobCommentResponse           `json:"jobComment"`
	JobTotal             JobTotalResponse             `json:"jobTotals"`
	JobTasks             *[]JobTaskForJobListResponse `json:"jobTasks,omitempty"`
	UDFs                 []UDFResponse                `json:"UDFs"`
	IsPickUp             bool                         `json:"isPickUp"`
	IsDelivery           bool                         `json:"isDelivery"`
	IsOnSite             bool                         `json:"isOnSite"`
	IsInStore            bool                         `json:"isInStore"`
	IsMultiple           bool                         `json:"isMultiple"`
	IsResourcePickUp     bool                         `json:"isResourcePickUp"`
	IsResourceDelivery   bool                         `json:"isResourceDelivery"`
	IsCombined           bool                         `json:"isCombined"`
	EstimateDate         *time.Time                   `json:"EstimateDate"`
	InvoiceDate          *time.Time                   `json:"InvoiceDate"`
	CreditNoteDate       *time.Time                   `json:"CreditNoteDate"`
	EstimateDueDate      *time.Time                   `json:"EstimateDueDate"`
	InvoiceDueDate       *time.Time                   `json:"InvoiceDueDate"`
	CustomerApprovalDate *time.Time                   `json:"CustomerApprovalDate"`
	ManagerApprovalDate  *time.Time                   `json:"ManagerApprovalDate"`
	RejectedDate         *time.Time                   `json:"RejectedDate"`
	IsSent               bool                         `json:"IsSent"`
	IsCustomerApproved   bool                         `json:"IsCustomerApproved"`
	IsManagerApproved    bool                         `json:"IsManagerApproved"`
	IsRejected           bool                         `json:"IsRejected"`
	JobFormsNavigation   JobFormNavigationResponse    `json:"JobFormsNavigation"`
	ErpInvoiceKey        *string                      `json:"ErpInvoiceKey"`
	ErpInvoiceStatus     *string                      `json:"ErpInvoiceStatus"`
	ErpCreditNoteKey     *string                      `json:"ErpCreditNoteKey"`
	EstimatedDistance    float64                      `json:"EstimatedDistance"`
	EstimatedTravelTime  float64                      `json:"EstimatedTravelTime"`

	IsCombinedChild           bool                        `json:"IsCombinedChild"`
	IsMultipleChild           bool                        `json:"IsMultipleChild"`
	InvoiceMode               int                         `json:"InvoiceMode"`
	InvoiceModeName           string                      `json:"InvoiceModeName"`
	InvoiceTravelCostMode     int                         `json:"InvoiceTravelCostMode"`
	InvoiceTravelCostModeName string                      `json:"InvoiceTravelCostModeName"`
	UDF                       map[string]interface{}      `json:"UDF"`
	JobPrecomputedRoute       *string                     `json:"JobPrecomputedRoute"`
	RecurringJob              *RecurringJobResponse       `json:"recurringJobs"`
	RecurringSkips            []RecurringSkipResponse     `json:"recurringSkips"`
	ExtraResources            []ExtraResourcesResponse    `json:"jobExtraResources"`
	InspectionForJobID        int                         `json:"InspectionForJobID"`
	IsInspection              bool                        `json:"IsInspection"`
	SurchargeParentItemKeys   string                      `json:"SurchargeParentItemKeys"`
	InspectionJobs            []InspectionJobDateResponse `json:"InspectionJobs"`
	AdditionalFiles           []AdditionalFileResponse    `json:"AdditionalFiles"`
}

type ExtraResourcesResponse struct {
	ResourceType     int    `json:"ResourceType"`
	ResourceTypeName string `json:"ResourceTypeName"`
	ResourceTypeIcon string `json:"ResourceTypeIcon"`
}

// InspectionJobResponse str
type InspectionJobDateResponse struct {
	JobID              int        `json:"JobID"`
	JobNumber          string     `json:"JobNumber"`
	ForJobTaskType     int        `json:"JobTaskType"`
	ForJobTaskTypeName string     `json:"JobTaskTypeName"`
	ForJobTaskTypeIcon string     `json:"JobTaskTypeIcon"`
	Address            string     `json:"Address"`
	ContactDetails     string     `json:"ContactDetails"`
	ContactPhoneNumber string     `json:"ContactPhoneNumber"`
	JobDate            *time.Time `json:"JobDate"`
}

// SelectJobResponse str
type SelectJobResponse struct {
	JobID []int `json:"JobID"`
}

// JobStatusResponse str
type JobStatusResponse struct {
	JobID            int                            `json:"JobID"`
	Status           int                            `json:"Status"`
	StatusName       string                         `json:"StatusName"`
	InProgressStatus string                         `json:"InProgressStatus"`
	JobTaskStatus    string                         `json:"JobTaskStatus"`
	JobTasks         *[]JobTaskForJobStatusResponse `json:"JobTasks,omitempty"`
}

// JobHeaderResponse str
type JobHeaderResponse struct {
	BusinessPartnerID           int               `json:"BusinessPartnerID"`
	JobDate                     *time.Time        `json:"JobDate"`
	EstimateDate                *time.Time        `json:"EstimateDate"`
	EstimateDueDate             *time.Time        `json:"EstimateDueDate"`
	JobNumber                   string            `json:"JobNumber"`
	EstimateNumber              string            `json:"EstimateNumber"`
	InvoiceNumber               string            `json:"InvoiceNumber"`
	CreditNoteNumber            string            `json:"CreditNoteNumber"`
	ContactDetails              string            `json:"ContactDetails"`
	CountryCode                 string            `json:"CountryCode"`
	ContactPhoneNumber          string            `json:"ContactPhoneNumber"`
	ResourceType                int               `json:"ResourceType"`
	ResourceTypeName            string            `json:"ResourceTypeName"`
	ResourceTypeIcon            string            `json:"ResourceTypeIcon"`
	CompanyName                 string            `json:"CompanyName"`
	EmailAddress                string            `json:"EmailAddress"`
	TravelCharge                int               `json:"TravelCharge"`
	TravelChargeName            string            `json:"TravelChargeName"`
	Priority                    int               `json:"Priority"`
	PriorityName                string            `json:"PriorityName"`
	PriorityIcon                string            `json:"PriorityIcon"`
	Addresses                   []AddressResponse `json:"Addresses"`
	Phones                      []PhoneResponse   `json:"Phones"`
	IsRecurring                 bool              `json:"IsRecurring"`
	RecurringJobID              int               `json:"RecurringJobID"`
	OptimizeJob                 bool              `json:"OptimizeJob"`
	ForcePaymentBeforeCompleted bool              `json:"ForcePaymentBeforeCompleted"`
}

// JobStatusObjectResponse data
type JobStatusObjectResponse struct {
	AddressType        string     `json:"AddressType"`
	Address            string     `json:"Address"`
	BusinessPartnerID  int        `json:"BusinessPartnerID"`
	ContactDetails     string     `json:"ContactDetails"`
	CountryCode        string     `json:"CountryCode"`
	ContactPhoneNumber string     `json:"ContactPhoneNumber"`
	IsBussinessPartner bool       `json:"IsBussinessPartner"`
	PreferredDateTime  *time.Time `json:"PreferredDateTime"`
}

// JobMapResponse str
type JobMapResponse struct {
	Distance         float64 `json:"Distance"`
	DistanceCharge   float64 `json:"DistanceCharge"`
	TravelTime       float64 `json:"TravelTime"`
	TravelTimeCharge float64 `json:"TravelTimeCharge"`
	JobMapImage      string  `json:"JobMapImage"`
}

// JobCommentResponse str
type JobCommentResponse struct {
	Comment string `json:"Comment"`
}

// JobTotalResponse str
type JobTotalResponse struct {
	Subtotal                float64 `json:"Subtotal"`
	TotalTax                float64 `json:"TotalTax"`
	TotalTravelAmount       float64 `json:"TotalTravelAmount"`
	TravelTimeTaxAmount     float64 `json:"TravelTimeTaxAmount"`
	TravelTimeChargeTaxRate float64 `json:"TravelTimeChargeTaxRate"`
	DistanceTaxAmount       float64 `json:"DistanceTaxAmount"`
	DistanceChargeTaxRate   float64 `json:"DistanceChargeTaxRate"`
	TotalDiscountAmount     float64 `json:"TotalDiscountAmount"`
	TotalBufferAmount       float64 `json:"TotalBufferAmount"`
	TotalJob                float64 `json:"TotalJob"`
}

// JobSummary data
type JobSummary struct {
	JobID              int            `json:"JobID"`
	JobNumber          string         `json:"JobNumber"`
	CompanyName        string         `json:"CompanyName"`
	FirstName          string         `json:"FirstName"`
	LastName           string         `json:"LastName"`
	JobType            int            `json:"JobType"`
	JobTypeName        string         `json:"JobTypeName"`
	JobTypeIcon        string         `json:"JobTypeIcon"`
	ContactDetails     string         `json:"ContactDetails"`
	CountryCode        string         `json:"CountryCode"`
	ContactPhoneNumber string         `json:"ContactPhoneNumber"`
	Comment            string         `json:"Comment"`
	JobDate            *time.Time     `json:"JobDate"`
	JobTask            JobTaskSummary `json:"JobTask"`
	Priority           int            `json:"Priority"`
	PriorityName       string         `json:"PriorityName"`
	PriorityIcon       string         `json:"PriorityIcon"`
	IsCombinedChild    bool           `json:"IsCombinedChild"`
	IsRecurring        bool           `json:"IsRecurring"`
	RecurringJobID     int            `json:"RecurringJobID"`
	OptimizeJob        bool           `json:"OptimizeJob"`
}

// JobTaskSummary data
type JobTaskSummary struct {
	JobType               int    `json:"JobType"`
	JobTypeName           string `json:"JobTypeName"`
	JobTypeIcon           string `json:"JobTypeIcon"`
	NavigationAddress     string `json:"NavigationAddress"`
	Status                int    `json:"Status"`
	StatusName            string `json:"StatusName"`
	StatusIcon            string `json:"StatusIcon"`
	ContactDetails        string `json:"ContactDetails"`
	CountryCode           string `json:"CountryCode"`
	ContactPhoneNumber    string `json:"ContactPhoneNumber"`
	AdditionalInformation string `json:"AdditionalInformation"`
	ServiceTimeInMinutes  int    `json:"ServiceTimeInMinutes"`
	PrecomputedRoute      string `json:"PrecomputedRoute"`
	PrecomputedRouteWeb   string `json:"PrecomputedRouteWeb"`
}

// TableName func
func (Job) TableName() string {
	return "jobs"
}

// BeforeCreate func
func (object *Job) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Job) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Job) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res      interface{}
		val      string
		jobTasks []JobTask
	)
	jobTasks = make([]JobTask, 0)
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsJob", JSONObject)
	if res != nil {
		object.IsJob, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsEstimate", JSONObject)
	if res != nil {
		object.IsEstimate, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsInvoice", JSONObject)
	if res != nil {
		object.IsInvoice, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCreditNote", JSONObject)
	if res != nil {
		object.IsCreditNote, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobType", JSONObject)
	if res != nil {
		object.JobType, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TravelChargeMode", JSONObject)
	if res != nil {
		object.TravelChargeMode, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("InProgressStatus", JSONObject)
	if res != nil {
		object.InProgressStatus = val
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskStatus", JSONObject)
	if res != nil {
		object.JobTaskStatus = val
	}
	val, res = services.ConvertJSONValueToVariable("jobHeader", JSONObject)
	if res != nil {
		var objectsJobHeader map[string]interface{}
		jobHeaderJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(jobHeaderJSON, &objectsJobHeader)
			val, res = services.ConvertJSONValueToVariable("BusinessPartnerID", objectsJobHeader)
			if res != nil {
				object.BusinessPartnerID, _ = strconv.Atoi(val)
			}
			val, res = services.ConvertJSONValueToVariable("JobDate", objectsJobHeader)
			if res != nil {
				vJobDate, sJobDate := services.ConvertStringToDateTime(val)
				if sJobDate == nil {
					object.JobDate = &vJobDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("EstimateDate", objectsJobHeader)
			if res != nil {
				vEstimateDate, sEstimateDate := services.ConvertStringToDateTime(val)
				if sEstimateDate == nil {
					object.EstimateDate = &vEstimateDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("InvoiceDate", objectsJobHeader)
			if res != nil {
				vInvoiceDate, sInvoiceDate := services.ConvertStringToDateTime(val)
				if sInvoiceDate == nil {
					object.InvoiceDate = &vInvoiceDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("CreditNoteDate", objectsJobHeader)
			if res != nil {
				vCreditNoteDate, sCreditNoteDate := services.ConvertStringToDateTime(val)
				if sCreditNoteDate == nil {
					object.CreditNoteDate = &vCreditNoteDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("EstimateDueDate", objectsJobHeader)
			if res != nil {
				vEstimateDueDate, sEstimateDueDate := services.ConvertStringToDateTime(val)
				if sEstimateDueDate == nil {
					object.EstimateDueDate = &vEstimateDueDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("InvoiceDueDate", objectsJobHeader)
			if res != nil {
				vInvoiceDueDate, sInvoiceDueDate := services.ConvertStringToDateTime(val)
				if sInvoiceDueDate == nil {
					object.InvoiceDueDate = &vInvoiceDueDate
				}
			}
			val, res = services.ConvertJSONValueToVariable("JobNumber", objectsJobHeader)
			if res != nil {
				object.JobNumber = val
			}
			val, res = services.ConvertJSONValueToVariable("EstimateNumber", objectsJobHeader)
			if res != nil {
				object.EstimateNumber = val
			}
			val, res = services.ConvertJSONValueToVariable("InvoiceNumber", objectsJobHeader)
			if res != nil {
				object.InvoiceNumber = val
			}
			val, res = services.ConvertJSONValueToVariable("CreditNoteNumber", objectsJobHeader)
			if res != nil {
				object.CreditNoteNumber = val
			}
			val, res = services.ConvertJSONValueToVariable("ContactDetails", objectsJobHeader)
			if res != nil {
				object.ContactDetails = val
			}
			val, res = services.ConvertJSONValueToVariable("CountryCode", objectsJobHeader)
			if res != nil {
				object.CountryCode = val
			}
			val, res = services.ConvertJSONValueToVariable("ContactPhoneNumber", objectsJobHeader)
			if res != nil {
				object.ContactPhoneNumber = val
			}
			val, res = services.ConvertJSONValueToVariable("ResourceType", objectsJobHeader)
			if res != nil {
				object.ResourceType, _ = strconv.Atoi(val)
			}
			val, res = services.ConvertJSONValueToVariable("TravelCharge", objectsJobHeader)
			if res != nil {
				object.TravelCharge, _ = strconv.Atoi(val)
			}
			val, res = services.ConvertJSONValueToVariable("Priority", objectsJobHeader)
			if res != nil {
				object.Priority, _ = strconv.Atoi(val)
			}
			val, res = services.ConvertJSONValueToVariable("IsRecurring", objectsJobHeader)
			if res != nil {
				object.IsRecurring, _ = strconv.ParseBool(val)
			}
			val, res = services.ConvertJSONValueToVariable("RecurringJobID", objectsJobHeader)
			if res != nil {
				object.RecurringJobID, _ = strconv.Atoi(val)
			}
			val, res = services.ConvertJSONValueToVariable("OptimizeJob", objectsJobHeader)
			if res != nil {
				object.OptimizeJob, _ = strconv.ParseBool(val)
			}
			val, res = services.ConvertJSONValueToVariable("ForcePaymentBeforeCompleted", objectsJobHeader)
			if res != nil {
				object.ForcePaymentBeforeCompleted, _ = strconv.ParseBool(val)
			}
		}
	}

	val, res = services.ConvertJSONValueToVariable("isPickUp", JSONObject)
	if res != nil {
		isPickUp, _ := strconv.ParseBool(val)
		if isPickUp {
			val, res = services.ConvertJSONValueToVariable("jobPickup", JSONObject)
			if res != nil {
				var objectsJobPickup map[string]interface{}
				jobPickupJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobPickupJSON, &objectsJobPickup)
					if object.JobPickup != nil {
						jobPickup := *object.JobPickup
						jobPickup.PassBodyJSONToModel(objectsJobPickup)
						object.JobPickup = &jobPickup
					} else {
						var jobPickup JobPickup
						jobPickup.PassBodyJSONToModel(objectsJobPickup)
						object.JobPickup = &jobPickup
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobPickup)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isDelivery", JSONObject)
	if res != nil {
		isDelivery, _ := strconv.ParseBool(val)
		if isDelivery {
			val, res = services.ConvertJSONValueToVariable("jobDelivery", JSONObject)
			if res != nil {
				var objectsJobDelivery map[string]interface{}
				jobDeliveryJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobDeliveryJSON, &objectsJobDelivery)
					if object.JobDelivery != nil {
						jobDelivery := *object.JobDelivery
						jobDelivery.PassBodyJSONToModel(objectsJobDelivery)
						object.JobDelivery = &jobDelivery
					} else {
						var jobDelivery JobDelivery
						jobDelivery.PassBodyJSONToModel(objectsJobDelivery)
						object.JobDelivery = &jobDelivery
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobDelivery)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isOnSite", JSONObject)
	if res != nil {
		isOnSite, _ := strconv.ParseBool(val)
		if isOnSite {
			val, res = services.ConvertJSONValueToVariable("jobOnSite", JSONObject)
			if res != nil {
				var objectsJobOnSite map[string]interface{}
				jobOnSiteJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobOnSiteJSON, &objectsJobOnSite)
					if object.JobOnSite != nil {
						jobOnSite := *object.JobOnSite
						jobOnSite.PassBodyJSONToModel(objectsJobOnSite)
						object.JobOnSite = &jobOnSite
					} else {
						var jobOnSite JobOnSite
						jobOnSite.PassBodyJSONToModel(objectsJobOnSite)
						object.JobOnSite = &jobOnSite
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobOnSite)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isInStore", JSONObject)
	if res != nil {
		isInStore, _ := strconv.ParseBool(val)
		if isInStore {
			val, res = services.ConvertJSONValueToVariable("jobInStore", JSONObject)
			if res != nil {
				var objectsJobInStore map[string]interface{}
				jobInStoreJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobInStoreJSON, &objectsJobInStore)
					if object.JobInStore != nil {
						jobInStore := *object.JobInStore
						jobInStore.PassBodyJSONToModel(objectsJobInStore)
						object.JobInStore = &jobInStore
					} else {
						var jobInStore JobInStore
						jobInStore.PassBodyJSONToModel(objectsJobInStore)
						object.JobInStore = &jobInStore
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobInStore)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("jobDetails", JSONObject)
	if res != nil {
		var (
			jobDetails       []JobDetail
			objectsJobDetail []map[string]interface{}
		)
		jobDetails = make([]JobDetail, 0)
		jobDetailsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(jobDetailsJSON, &objectsJobDetail)
			if len(objectsJobDetail) > 0 {
				for _, objDetail := range objectsJobDetail {
					var (
						jobDetail JobDetail
					)
					jobDetail.PassBodyJSONToModel(objDetail)
					for _, v := range object.JobDetails {
						if jobDetail.JobDetailID == v.JobDetailID {
							jobDetail = v
							jobDetail.PassBodyJSONToModel(objDetail)
							break
						}
					}
					jobDetails = append(jobDetails, jobDetail)
				}
			}
		}
		object.JobDetails = jobDetails
	}
	val, res = services.ConvertJSONValueToVariable("isMultiple", JSONObject)
	if res != nil {
		isMultiple, _ := strconv.ParseBool(val)
		if isMultiple {
			val, res = services.ConvertJSONValueToVariable("jobMultiple", JSONObject)
			if res != nil {
				var objectsJobMultiple map[string]interface{}
				jobMultipleJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobMultipleJSON, &objectsJobMultiple)
					if object.JobMultiple != nil {
						jobMultiple := *object.JobMultiple
						jobMultiple.PassBodyJSONToModel(objectsJobMultiple)
						object.JobMultiple = &jobMultiple
					} else {
						var jobMultiple JobMultiple
						jobMultiple.PassBodyJSONToModel(objectsJobMultiple)
						object.JobMultiple = &jobMultiple
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobMultiple)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isCombined", JSONObject)
	if res != nil {
		isCombined, _ := strconv.ParseBool(val)
		if isCombined {
			val, res = services.ConvertJSONValueToVariable("jobCombined", JSONObject)
			if res != nil {
				var objectsJobCombined map[string]interface{}
				jobCombinedJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobCombinedJSON, &objectsJobCombined)
					if object.JobCombined != nil {
						jobCombined := *object.JobCombined
						jobCombined.PassBodyJSONToModel(objectsJobCombined)
						object.JobCombined = &jobCombined
					} else {
						var jobCombined JobCombined
						jobCombined.PassBodyJSONToModel(objectsJobCombined)
						object.JobCombined = &jobCombined
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobCombined)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isResourcePickUp", JSONObject)
	if res != nil {
		isResourcePickUp, _ := strconv.ParseBool(val)
		if isResourcePickUp {
			val, res = services.ConvertJSONValueToVariable("jobResourcePickUp", JSONObject)
			if res != nil {
				var objectsJobResourcePickUp map[string]interface{}
				jobResourcePickUpJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobResourcePickUpJSON, &objectsJobResourcePickUp)
					if object.JobResourcePickUp != nil {
						jobResourcePickUp := *object.JobResourcePickUp
						jobResourcePickUp.PassBodyJSONToModel(objectsJobResourcePickUp)
						object.JobResourcePickUp = &jobResourcePickUp
					} else {
						var jobResourcePickUp JobResourcePickup
						jobResourcePickUp.PassBodyJSONToModel(objectsJobResourcePickUp)
						object.JobResourcePickUp = &jobResourcePickUp
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobResourcePickUp)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("isResourceDelivery", JSONObject)
	if res != nil {
		isResourceDelivery, _ := strconv.ParseBool(val)
		if isResourceDelivery {
			val, res = services.ConvertJSONValueToVariable("jobResourceDelivery", JSONObject)
			if res != nil {
				var objectsJobResourceDelivery map[string]interface{}
				jobResourceDeliveryJSON, err := json.Marshal(res)
				if err == nil {
					json.Unmarshal(jobResourceDeliveryJSON, &objectsJobResourceDelivery)
					if object.JobResourceDelivery != nil {
						jobResourceDelivery := *object.JobResourceDelivery
						jobResourceDelivery.PassBodyJSONToModel(objectsJobResourceDelivery)
						object.JobResourceDelivery = &jobResourceDelivery
					} else {
						var jobResourceDelivery JobResourceDelivery
						jobResourceDelivery.PassBodyJSONToModel(objectsJobResourceDelivery)
						object.JobResourceDelivery = &jobResourceDelivery
					}

					// Update Job Task
					var (
						jobTask JobTask
					)
					jobTask.PassBodyJSONToModel(objectsJobResourceDelivery)
					if jobTask.JobType != 0 {
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}
		}
	}

	val, res = services.ConvertJSONValueToVariable("jobMap", JSONObject)
	if res != nil {
		var (
			objectsJobMap map[string]interface{}
			jobMap        JobMap
		)
		jobMapJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(jobMapJSON, &objectsJobMap)
			val, res = services.ConvertJSONValueToVariable("Distance", objectsJobMap)
			if res != nil {
				object.Distance, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("DistanceCharge", objectsJobMap)
			if res != nil {
				object.DistanceCharge, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TravelTime", objectsJobMap)
			if res != nil {
				object.TravelTime, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TravelTimeCharge", objectsJobMap)
			if res != nil {
				object.TravelTimeCharge, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("JobMapImage", objectsJobMap)
			if res != nil {
				jobMap.JobMapImage = val
				object.JobMap = &jobMap
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("jobComment", JSONObject)
	if res != nil {
		var objectsJobComment map[string]interface{}
		jobCommentJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(jobCommentJSON, &objectsJobComment)
			val, res = services.ConvertJSONValueToVariable("Comment", objectsJobComment)
			if res != nil {
				object.Comment = val
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("jobTotals", JSONObject)
	if res != nil {
		var objectsJobTotal map[string]interface{}
		jobTotalJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(jobTotalJSON, &objectsJobTotal)
			val, res = services.ConvertJSONValueToVariable("Subtotal", objectsJobTotal)
			if res != nil {
				object.Subtotal, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TotalTax", objectsJobTotal)
			if res != nil {
				object.TotalTax, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TravelTimeChargeTaxRate", objectsJobTotal)
			if res != nil {
				object.TravelTimeChargeTaxRate, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("DistanceChargeTaxRate", objectsJobTotal)
			if res != nil {
				object.DistanceChargeTaxRate, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TotalDiscountAmount", objectsJobTotal)
			if res != nil {
				object.TotalDiscountAmount, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TotalBufferAmount", objectsJobTotal)
			if res != nil {
				object.TotalBufferAmount, _ = strconv.ParseFloat(val, 64)
			}
			val, res = services.ConvertJSONValueToVariable("TotalJob", objectsJobTotal)
			if res != nil {
				object.TotalJob, _ = strconv.ParseFloat(val, 64)
			}
		}
	}
	if len(jobTasks) == 0 {
		val, res = services.ConvertJSONValueToVariable("jobTasks", JSONObject)
		if res != nil {
			var (
				jobTasks       []JobTask
				objectsJobTask []map[string]interface{}
			)
			jobTasks = make([]JobTask, 0)
			jobTasksJSON, err := json.Marshal(res)
			if err == nil {
				json.Unmarshal(jobTasksJSON, &objectsJobTask)
				if len(objectsJobTask) > 0 {
					for _, objDetail := range objectsJobTask {
						var (
							jobTask JobTask
						)
						jobTask.PassBodyJSONToModel(objDetail)
						for _, v := range object.JobTasks {
							if jobTask.JobTaskID == v.JobTaskID {
								jobTask = v
								jobTask.PassBodyJSONToModel(objDetail)
								break
							}
						}
						jobTasks = append(jobTasks, jobTask)
					}
				}
			}

		}
	}

	if len(jobTasks) > 0 {
		object.JobTasks = jobTasks
	}

	val, res = services.ConvertJSONValueToVariable("CustomerApprovalDate", JSONObject)
	if res != nil {
		vCustomerApprovalDate, sCustomerApprovalDate := services.ConvertStringToDateTime(val)
		if sCustomerApprovalDate == nil {
			object.CustomerApprovalDate = &vCustomerApprovalDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("ManagerApprovalDate", JSONObject)
	if res != nil {
		vManagerApprovalDate, sManagerApprovalDate := services.ConvertStringToDateTime(val)
		if sManagerApprovalDate == nil {
			object.ManagerApprovalDate = &vManagerApprovalDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("RejectedDate", JSONObject)
	if res != nil {
		vRejectedDate, sRejectedDate := services.ConvertStringToDateTime(val)
		if sRejectedDate == nil {
			object.RejectedDate = &vRejectedDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsSent", JSONObject)
	if res != nil {
		object.IsSent, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCustomerApproved", JSONObject)
	if res != nil {
		object.IsCustomerApproved, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsManagerApproved", JSONObject)
	if res != nil {
		object.IsManagerApproved, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsRejected", JSONObject)
	if res != nil {
		object.IsRejected, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("InvoiceMode", JSONObject)
	if res != nil {
		object.InvoiceMode, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCombinedChild", JSONObject)
	if res != nil {
		object.IsCombinedChild, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("InvoiceTravelCostMode", JSONObject)
	if res != nil {
		object.InvoiceTravelCostMode, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsMultipleChild", JSONObject)
	if res != nil {
		object.IsMultipleChild, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobPrecomputedRoute", JSONObject)
	if res != nil {
		valJSON := val
		object.JobPrecomputedRoute = &valJSON
	}

	if object.IsRecurring {
		val, res = services.ConvertJSONValueToVariable("recurringJobs", JSONObject)
		if res != nil {
			//fmt.Printf("object.RecurringJob.RecurringSkips: %+v\n", object.RecurringJob.RecurringSkips)
			var oldRecurringJob RecurringJob
			if object.RecurringJob != nil {
				oldRecurringJob = *object.RecurringJob
			}

			var objectsRecurringJobs map[string]interface{}
			recurringJobsJSON, err := json.Marshal(res)
			if err == nil {
				json.Unmarshal(recurringJobsJSON, &objectsRecurringJobs)
				if object.RecurringJob != nil {
					recurringJob := *object.RecurringJob
					recurringJob.PassBodyJSONToModel(objectsRecurringJobs)
					object.RecurringJob = &recurringJob
				} else {
					var recurringJob RecurringJob
					recurringJob.PassBodyJSONToModel(objectsRecurringJobs)
					object.RecurringJob = &recurringJob
				}
				//
				var newRecurringSkips = make([]RecurringSkip, 0)
				val, res = services.ConvertJSONValueToVariable("recurringSkips", JSONObject)
				if res != nil {
					var objectsRecurringSkips = make([]map[string]interface{}, 0)
					var oldRecurringSkips = make([]RecurringSkip, 0)
					recurringSkipsJSON, err := json.Marshal(res)
					if err == nil {
						if oldRecurringJob.RecurringJobID > 0 {
							oldRecurringSkips = oldRecurringJob.RecurringSkips
						}
						//fmt.Printf("oldRecurringSkips: %+v\n", oldRecurringSkips)
						json.Unmarshal(recurringSkipsJSON, &objectsRecurringSkips)
						for _, objectsRecurringSkip := range objectsRecurringSkips {
							var newNecurringSkip RecurringSkip
							newNecurringSkip.PassBodyJSONToModel(objectsRecurringSkip)
							//fmt.Printf("newNecurringSkip: %+v\n", newNecurringSkip)
							for _, oldRecurringSkip := range oldRecurringSkips {
								if oldRecurringSkip.RecurringSkipID == newNecurringSkip.RecurringSkipID {
									newNecurringSkip = oldRecurringSkip
									newNecurringSkip.PassBodyJSONToModel(objectsRecurringSkip)
									break
								}
							}
							newRecurringSkips = append(newRecurringSkips, newNecurringSkip)
						}
					}
				}
				//fmt.Printf("newRecurringSkips: %+v\n", newRecurringSkips)
				object.RecurringJob.RecurringSkips = newRecurringSkips
			}
		} else {
			object.RecurringJob = nil
		}
	} else {
		object.RecurringJob = nil
		object.OptimizeJob = true
	}
	val, res = services.ConvertJSONValueToVariable("jobExtraResources", JSONObject)
	if res != nil {
		var (
			resourceTypes = make([]int, 0)
		)
		resourceTypesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(resourceTypesJSON, &resourceTypes)
			if len(resourceTypes) > 0 {
				object.ExtraResources = services.IntJoin(resourceTypes)
			}
		}
	}

	val, res = services.ConvertJSONValueToVariable("InspectionForJobID", JSONObject)
	if res != nil {
		object.InspectionForJobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsInspection", JSONObject)
	if res != nil {
		object.IsInspection, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("AdditionalFiles", JSONObject)
	if res != nil {
		var (
			additionalFiles []AdditionalFile
			objectsAddFile  []map[string]interface{}
		)
		additionalFiles = make([]AdditionalFile, 0)
		additionalFilesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(additionalFilesJSON, &objectsAddFile)
			if len(objectsAddFile) > 0 {
				for _, objFile := range objectsAddFile {
					var (
						additionalFile AdditionalFile
					)
					additionalFile.PassBodyJSONToModel(objFile)
					for _, v := range object.AdditionalFiles {
						if additionalFile.AdditionalFileID == v.AdditionalFileID {
							additionalFile = v
							additionalFile.PassBodyJSONToModel(objFile)
							break
						}
					}
					additionalFiles = append(additionalFiles, additionalFile)
				}
			}
		}
		object.AdditionalFiles = additionalFiles
	}
	return
}

// GenerateDefaultValue func
func (object *Job) GenerateDefaultValue(sequencyModel DocumentSequency, jobNumPrefix, estimateNumPrefix, invoiceNumPrefix, creditNotePrefix Prefix) {
	if object.IsJob && object.JobNumber == "" {
		if jobNumPrefix.DocumentSequence != "" {
			jobNumberFirstConfig := jobNumPrefix.Prefix
			lenJobNumberConfig := jobNumPrefix.Length
			sqJobNumber := sequencyModel.JobNumber
			object.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)
		}
	}

	if object.IsEstimate && object.EstimateNumber == "" {
		if estimateNumPrefix.DocumentSequence != "" {
			estimateNumberFirstConfig := estimateNumPrefix.Prefix
			lenEstimateNumberConfig := estimateNumPrefix.Length
			sqEstimateNumber := sequencyModel.EstimateNumber
			object.EstimateNumber = services.GenerateDefaultValueWithConfigLength(estimateNumberFirstConfig, lenEstimateNumberConfig, sqEstimateNumber)
		}
	}

	if object.IsInvoice && object.InvoiceNumber == "" {
		if invoiceNumPrefix.DocumentSequence != "" {
			invoiceNumberFirstConfig := invoiceNumPrefix.Prefix
			lenInvoiceNumberConfig := invoiceNumPrefix.Length
			sqInvoiceNumber := sequencyModel.InvoiceNumber
			object.InvoiceNumber = services.GenerateDefaultValueWithConfigLength(invoiceNumberFirstConfig, lenInvoiceNumberConfig, sqInvoiceNumber)
		}
	}

	if object.IsCreditNote && object.CreditNoteNumber == "" {
		if creditNotePrefix.DocumentSequence != "" {
			creditNoteFirstConfig := creditNotePrefix.Prefix
			lenCreditNoteConfig := creditNotePrefix.Length
			sqCreditNote := sequencyModel.CreditNoteNumber
			object.CreditNoteNumber = services.GenerateDefaultValueWithConfigLength(creditNoteFirstConfig, lenCreditNoteConfig, sqCreditNote)
		}
	}

	return
}

// GenerateNewSequenceNumberIfExistInSameDay func
func (object *Job) GenerateNewSequenceNumberIfExistInSameDay(db *gorm.DB, jobNumPrefix, estimateNumPrefix, invoiceNumPrefix, creditNotePrefix Prefix) {
	today := time.Now().Format("2006-01-02")

	if object.JobNumber != "" {
		var (
			jobModels          []Job
			sequencyModel      DocumentSequency
			useCurrentSequence = false
		)
		for {
			db.Where("JobNumber = ?", object.JobNumber).
				Where("DATE_FORMAT(ModifiedDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", today).
				Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
			if len(jobModels) > 0 {
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
				if !useCurrentSequence {
					useCurrentSequence = true
				} else {
					sequencyModel.JobNumber = sequencyModel.JobNumber + 1
					db.Save(&sequencyModel)
				}
				if jobNumPrefix.DocumentSequence != "" {
					jobNumberFirstConfig := jobNumPrefix.Prefix
					lenJobNumberConfig := jobNumPrefix.Length
					sqJobNumber := sequencyModel.JobNumber
					object.JobNumber = services.GenerateDefaultValueWithConfigLength(jobNumberFirstConfig, lenJobNumberConfig, sqJobNumber)
				}
			} else {
				break
			}
		}
	}
	if object.EstimateNumber != "" {
		var (
			jobModels          []Job
			sequencyModel      DocumentSequency
			useCurrentSequence = false
		)
		for {
			db.Where("EstimateNumber = ?", object.EstimateNumber).Where("DATE_FORMAT(ModifiedDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", today).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
			if len(jobModels) > 0 {
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
				if !useCurrentSequence {
					useCurrentSequence = true
				} else {
					sequencyModel.EstimateNumber = sequencyModel.EstimateNumber + 1
					db.Save(&sequencyModel)
				}
				if estimateNumPrefix.DocumentSequence != "" {
					estimateNumberFirstConfig := estimateNumPrefix.Prefix
					lenEstimateNumberConfig := estimateNumPrefix.Length
					sqEstimateNumber := sequencyModel.EstimateNumber
					object.EstimateNumber = services.GenerateDefaultValueWithConfigLength(estimateNumberFirstConfig, lenEstimateNumberConfig, sqEstimateNumber)
				}
			} else {
				break
			}
		}
	}
	if object.InvoiceNumber != "" {
		var (
			jobModels          []Job
			sequencyModel      DocumentSequency
			useCurrentSequence = false
		)
		for {
			db.Where("InvoiceNumber = ?", object.InvoiceNumber).Where("DATE_FORMAT(ModifiedDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", today).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
			if len(jobModels) > 0 {
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
				if !useCurrentSequence {
					useCurrentSequence = true
				} else {
					sequencyModel.InvoiceNumber = sequencyModel.InvoiceNumber + 1
					db.Save(&sequencyModel)
				}
				if invoiceNumPrefix.DocumentSequence != "" {
					invoiceNumberFirstConfig := invoiceNumPrefix.Prefix
					lenInvoiceNumberConfig := invoiceNumPrefix.Length
					sqInvoiceNumber := sequencyModel.InvoiceNumber
					object.InvoiceNumber = services.GenerateDefaultValueWithConfigLength(invoiceNumberFirstConfig, lenInvoiceNumberConfig, sqInvoiceNumber)
				}
			} else {
				break
			}
		}
	}
	if object.CreditNoteNumber != "" {
		var (
			jobModels          []Job
			sequencyModel      DocumentSequency
			useCurrentSequence = false
		)
		for {
			db.Where("CreditNoteNumber = ?", object.CreditNoteNumber).Where("DATE_FORMAT(ModifiedDate,'%Y-%m-%d') = DATE_FORMAT(?,'%Y-%m-%d')", today).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").Find(&jobModels)
			if len(jobModels) > 0 {
				db.Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&sequencyModel)
				if !useCurrentSequence {
					useCurrentSequence = true
				} else {
					sequencyModel.CreditNoteNumber = sequencyModel.CreditNoteNumber + 1
					db.Save(&sequencyModel)
				}
				if creditNotePrefix.DocumentSequence != "" {
					creditNoteNumberFirstConfig := creditNotePrefix.Prefix
					lenCreditNoteNumberConfig := creditNotePrefix.Length
					sqCreditNoteNumber := sequencyModel.CreditNoteNumber
					object.CreditNoteNumber = services.GenerateDefaultValueWithConfigLength(creditNoteNumberFirstConfig, lenCreditNoteNumberConfig, sqCreditNoteNumber)
				}
			} else {
				break
			}
		}
	}
}
