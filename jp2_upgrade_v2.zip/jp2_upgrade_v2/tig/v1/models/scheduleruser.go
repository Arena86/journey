package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SchedulerUser data
type SchedulerUser struct {
	SchedulerUserID int        `gorm:"column:SchedulerUserID;primaryKey;autoIncrement;not null"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	UserID          int        `gorm:"column:UserID" validate:"required" json:"UserID"`
	ResourceID      int        `gorm:"column:ResourceID" validate:"required" json:"ResourceID"`
	LocationID      int        `gorm:"column:LocationID" validate:"required" json:"LocationID"`
	SchedulerDate   *time.Time `gorm:"column:SchedulerDate" validate:"required" json:"SchedulerDate"`
}

// SchedulerUserResponse data
type SchedulerUserResponse struct {
	SchedulerUserID int        `json:"SchedulerUserID"`
	UserID          int        `json:"UserID"`
	ResourceID      int        `json:"ResourceID"`
	LocationID      int        `json:"LocationID"`
	SchedulerDate   *time.Time `json:"SchedulerDate"`
}

// TableName func
func (SchedulerUser) TableName() string {
	return "schedulerusers"
}

// BeforeCreate func
func (object *SchedulerUser) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SchedulerUser) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SchedulerUser) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SchedulerUserID", JSONObject)
	if res != nil {
		object.SchedulerUserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("UserID", JSONObject)
	if res != nil {
		object.UserID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("SchedulerDate", JSONObject)
	if res != nil {
		vSchedulerDate, sSchedulerDate := services.ConvertStringToDateTime(val)
		if sSchedulerDate == nil {
			object.SchedulerDate = &vSchedulerDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	return
}
