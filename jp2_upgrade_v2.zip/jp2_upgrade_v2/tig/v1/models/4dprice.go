package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

const DimensionDataTypeInt = 0
const DimensionDataTypeBoolean = 1
const DimensionDataTypeFloat = 2

type CalcInspection4DPricePOST struct {
	JobID       int                     `json:"JobID"`
	JobTaskID   int                     `json:"JobTaskID"`
	ItemID      int                     `json:"ItemID"`
	Key         string                  `json:"Key"`
	FourDPrices []CalcInspection4DPrice `json:"FourDPrices"`
}

type CalcInspection4DPrice struct {
	Job4DPriceID    int         `json:"Job4DPriceID"`
	FourDPriceID    int         `json:"FourDPriceID"`
	SurchargeItemID int         `json:"SurchargeItemID"`
	Dimension1      interface{} `json:"Dimension1"`
	Dimension2      interface{} `json:"Dimension2"`
	Dimension3      interface{} `json:"Dimension3"`
	Dimension4      interface{} `json:"Dimension4"`
	Skip            bool        `json:"Skip"`
}

type FourDPricePOST struct {
	FourDPriceID int         `json:"FourDPriceID"`
	Dimension1   interface{} `json:"Dimension1"`
	Dimension2   interface{} `json:"Dimension2"`
	Dimension3   interface{} `json:"Dimension3"`
	Dimension4   interface{} `json:"Dimension4"`
	JobTaskType  int         `json:"JobTaskType"`
}
type FourDPricePOSTResponse struct {
	ItemID             int           `json:"ItemID"`
	FourDPriceID       int           `json:"FourDPriceID"`
	FourDPriceDetailID int           `json:"FourDPriceDetailID"`
	Dimension1         interface{}   `json:"Dimension1"`
	Dimension2         interface{}   `json:"Dimension2"`
	Dimension3         interface{}   `json:"Dimension3"`
	Dimension4         interface{}   `json:"Dimension4"`
	JobTaskType        int           `json:"JobTaskType"`
	TriggerInspection  bool          `json:"TriggerInspection"`
	Price              float64       `json:"Price"`
	SurchargeItem      *ItemResponse `json:"SurchargeItem"`
	SurchargeItemID    int           `json:"SurchargeItemID"`
}

// FourDPrice data
type FourDPrice struct {
	FourDPriceID               int                `gorm:"column:4DPriceID;primaryKey;not null"`
	CreatedBy                  int                `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                *time.Time         `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                 int                `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate               *time.Time         `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                  bool               `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                    bool               `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                 bool               `gorm:"column:IsArchived" json:"IsArchived"`
	FourDPriceName             string             `gorm:"column:4DPriceName" json:"FourDPriceName"`
	SurchargeItemID            int                `gorm:"column:SurchargeItemID" json:"SurchargeItemID"`
	TaxID                      int                `gorm:"column:TaxID" json:"TaxID"`
	IncludingTax               bool               `gorm:"column:IncludingTax" json:"IncludingTax"`
	DimensionName1             string             `gorm:"column:DimensionName1" json:"DimensionName1"`
	DimensionName2             string             `gorm:"column:DimensionName2" json:"DimensionName2"`
	DimensionName3             string             `gorm:"column:DimensionName3" json:"DimensionName3"`
	DimensionName4             string             `gorm:"column:DimensionName4" json:"DimensionName4"`
	Dimension1Enable           bool               `gorm:"column:Dimension1Enable" json:"Dimension1Enable"`
	Dimension2Enable           bool               `gorm:"column:Dimension2Enable" json:"Dimension2Enable"`
	Dimension3Enable           bool               `gorm:"column:Dimension3Enable" json:"Dimension3Enable"`
	Dimension4Enable           bool               `gorm:"column:Dimension4Enable" json:"Dimension4Enable"`
	Dimension1DataType         *int               `gorm:"column:Dimension1DataType" json:"Dimension1DataType"`
	Dimension2DataType         *int               `gorm:"column:Dimension2DataType" json:"Dimension2DataType"`
	Dimension3DataType         *int               `gorm:"column:Dimension3DataType" json:"Dimension3DataType"`
	Dimension4DataType         *int               `gorm:"column:Dimension4DataType" json:"Dimension4DataType"`
	FourDimensionsPriceDetails []FourDPriceDetail `gorm:"foreignKey:4DPriceID;references:4DPriceID" json:"FourDimensionsPriceDetails"`
	FourDimensionsItems        []FourDPriceItem   `gorm:"foreignKey:4DPriceID;references:4DPriceID" json:"FourDimensionsItems"`
}
type InspectionFourDPriceResponse struct {
	FourDPriceID       int                    `json:"FourDPriceID"`
	FourDPriceName     string                 `json:"FourDPriceName"`
	SurchargeItemID    int                    `json:"SurchargeItemID"`
	SurchargeItemCode  string                 `json:"SurchargeItemCode"`
	SurchargeItemName  string                 `json:"SurchargeItemName"`
	TaxID              int                    `json:"TaxID"`
	IncludingTax       bool                   `json:"IncludingTax"`
	DimensionName1     string                 `json:"DimensionName1"`
	DimensionName2     string                 `json:"DimensionName2"`
	DimensionName3     string                 `json:"DimensionName3"`
	DimensionName4     string                 `json:"DimensionName4"`
	Dimension1Enable   bool                   `json:"Dimension1Enable"`
	Dimension2Enable   bool                   `json:"Dimension2Enable"`
	Dimension3Enable   bool                   `json:"Dimension3Enable"`
	Dimension4Enable   bool                   `json:"Dimension4Enable"`
	Dimension1DataType *int                   `json:"Dimension1DataType"`
	Dimension2DataType *int                   `json:"Dimension2DataType"`
	Dimension3DataType *int                   `json:"Dimension3DataType"`
	Dimension4DataType *int                   `json:"Dimension4DataType"`
	Job4DPrices        []InspectionJob4DPrice `json:"Job4DPrices"`
}

// FourDPriceResponse data
type FourDPriceResponse struct {
	FourDPriceID               int                        `json:"FourDPriceID"`
	FourDPriceName             string                     `json:"FourDPriceName"`
	SurchargeItemID            int                        `json:"SurchargeItemID"`
	SurchargeItemCode          string                     `json:"SurchargeItemCode"`
	SurchargeItemName          string                     `json:"SurchargeItemName"`
	TaxID                      int                        `json:"TaxID"`
	IncludingTax               bool                       `json:"IncludingTax"`
	DimensionName1             string                     `json:"DimensionName1"`
	DimensionName2             string                     `json:"DimensionName2"`
	DimensionName3             string                     `json:"DimensionName3"`
	DimensionName4             string                     `json:"DimensionName4"`
	Dimension1Enable           bool                       `json:"Dimension1Enable"`
	Dimension2Enable           bool                       `json:"Dimension2Enable"`
	Dimension3Enable           bool                       `json:"Dimension3Enable"`
	Dimension4Enable           bool                       `json:"Dimension4Enable"`
	Dimension1DataType         *int                       `json:"Dimension1DataType"`
	Dimension2DataType         *int                       `json:"Dimension2DataType"`
	Dimension3DataType         *int                       `json:"Dimension3DataType"`
	Dimension4DataType         *int                       `json:"Dimension4DataType"`
	FourDimensionsPriceDetails []FourDPriceDetailResponse `json:"FourDimensionsPriceDetails"`
	FourDimensionsItems        []FourDPriceItemResponse   `json:"FourDimensionsItems"`
}

// TableName func
func (FourDPrice) TableName() string {
	return "4dprices"
}

// BeforeCreate func
func (object *FourDPrice) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FourDPrice) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FourDPrice) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FourDPriceID", JSONObject)
	if res != nil {
		object.FourDPriceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FourDPriceName", JSONObject)
	if res != nil {
		object.FourDPriceName = val
	}
	val, res = services.ConvertJSONValueToVariable("SurchargeItemID", JSONObject)
	if res != nil {
		object.SurchargeItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaxID", JSONObject)
	if res != nil {
		object.TaxID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IncludingTax", JSONObject)
	if res != nil {
		object.IncludingTax, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("DimensionName1", JSONObject)
	if res != nil {
		object.DimensionName1 = val
	}
	val, res = services.ConvertJSONValueToVariable("DimensionName2", JSONObject)
	if res != nil {
		object.DimensionName2 = val
	}
	val, res = services.ConvertJSONValueToVariable("DimensionName3", JSONObject)
	if res != nil {
		object.DimensionName3 = val
	}
	val, res = services.ConvertJSONValueToVariable("DimensionName4", JSONObject)
	if res != nil {
		object.DimensionName4 = val
	}
	val, res = services.ConvertJSONValueToVariable("Dimension1Enable", JSONObject)
	if res != nil {
		object.Dimension1Enable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension2Enable", JSONObject)
	if res != nil {
		object.Dimension2Enable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension3Enable", JSONObject)
	if res != nil {
		object.Dimension3Enable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension4Enable", JSONObject)
	if res != nil {
		object.Dimension4Enable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Dimension1DataType", JSONObject)
	if res != nil {
		dimension1DataType, errDimension1DataType := strconv.Atoi(val)
		if errDimension1DataType == nil {
			object.Dimension1DataType = &dimension1DataType
		}
	} else {
		if val == "<nil>" {
			object.Dimension1DataType = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Dimension2DataType", JSONObject)
	if res != nil {
		dimension2DataType, errDimension2DataType := strconv.Atoi(val)
		if errDimension2DataType == nil {
			object.Dimension2DataType = &dimension2DataType
		}
	} else {
		if val == "<nil>" {
			object.Dimension2DataType = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Dimension3DataType", JSONObject)
	if res != nil {
		dimension3DataType, errDimension3DataType := strconv.Atoi(val)
		if errDimension3DataType == nil {
			object.Dimension3DataType = &dimension3DataType
		}
	} else {
		if val == "<nil>" {
			object.Dimension3DataType = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("Dimension4DataType", JSONObject)
	if res != nil {
		dimension4DataType, errDimension4DataType := strconv.Atoi(val)
		if errDimension4DataType == nil {
			object.Dimension4DataType = &dimension4DataType
		}
	} else {
		if val == "<nil>" {
			object.Dimension4DataType = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("FourDimensionsPriceDetails", JSONObject)
	if res != nil {
		var (
			_4dPriceDetails = make([]FourDPriceDetail, 0)
			objectFormUDFs  []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectFormUDFs)
			if len(objectFormUDFs) > 0 {
				for _, obj := range objectFormUDFs {
					var (
						detail FourDPriceDetail
					)
					detail.PassBodyJSONToModel(obj)
					_4dPriceDetails = append(_4dPriceDetails, detail)
				}
			}
		}
		object.FourDimensionsPriceDetails = _4dPriceDetails
	}
	val, res = services.ConvertJSONValueToVariable("FourDimensionsItems", JSONObject)
	if res != nil {
		var (
			_4dPriceItems  = make([]FourDPriceItem, 0)
			objectFormUDFs []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectFormUDFs)
			if len(objectFormUDFs) > 0 {
				for _, obj := range objectFormUDFs {
					var (
						detail FourDPriceItem
					)
					detail.PassBodyJSONToModel(obj)
					_4dPriceItems = append(_4dPriceItems, detail)
				}
			}
		}
		object.FourDimensionsItems = _4dPriceItems
	}
	return
}
