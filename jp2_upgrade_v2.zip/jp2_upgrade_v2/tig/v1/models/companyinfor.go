package models

import (
	"jpapi/tig/v1/services"
	"time"

	"gorm.io/gorm"
)

// CompanyInfor data
type CompanyInfor struct {
	CompanyInforID int        `gorm:"column:CompanyInforID;primaryKey;autoIncrement;not null" json:"CompanyInforID"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	CompanyID      string     `gorm:"column:CompanyID;" json:"CompanyID"`
	TaxNumber      string     `gorm:"column:TaxNumber;" json:"TaxNumber"`
	Address        string     `gorm:"column:Address;" json:"Address"`
	SupportPhone   string     `gorm:"column:SupportPhone;" json:"SupportPhone"`
}

// CompanyInforResponse data
type CompanyInforResponse struct {
	CompanyInforID int    `json:"CompanyInforID"`
	CompanyID      string `json:"CompanyID"`
	TaxNumber      string `json:"TaxNumber"`
	Address        string `json:"Address"`
	SupportPhone   string `json:"SupportPhone"`
}

// TableName func
func (CompanyInfor) TableName() string {
	return "companiesinfor"
}

// BeforeCreate func
func (object *CompanyInfor) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *CompanyInfor) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *CompanyInfor) PassBodyJSONToModel(JSONObject map[string]interface{}) {

	return
}

// PassBodyJSONToModelPOST func
func (object *CompanyInfor) PassBodyJSONToModelPOST(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("CompanyID", JSONObject)
	if res != nil {
		object.CompanyID = val
	}

	return
}

// PassBodyJSONToModelUPDATE func
func (object *CompanyInfor) PassBodyJSONToModelUPDATE(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TaxNumber", JSONObject)
	if res != nil {
		object.TaxNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("Address", JSONObject)
	if res != nil {
		object.Address = val
	}
	val, res = services.ConvertJSONValueToVariable("SupportPhone", JSONObject)
	if res != nil {
		object.SupportPhone = val
	}

	return
}
