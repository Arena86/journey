package models

import "time"

type ChargeBeeConfig struct {
	ChargeBeeKey   int
	ConfigKey      string
	ConfigSiteName string
}

type ChargeBeeError struct {
	HTTPStatusCode int    `json:"http_status_code"`
	Message        string `json:"message"`
	Param          string `json:"param"`
	APIErrorCode   string `json:"api_error_code"`
	Type           string `json:"type"`
	ErrorCode      string `json:"error_code"`
}

type ChargeBeeCardInfo struct {
	FirstName   string
	LastName    string
	Number      string
	ExpiryMonth int
	ExpiryYear  int
	Cvv         string
}

type CBInvoiceResponse struct {
	InvoiceNumber           string    `json:"invoiceNumber"`
	FirstName               string    `json:"firstName"`
	LastName                string    `json:"lastName"`
	Date                    time.Time `json:"date"`
	DueDate                 time.Time `json:"dueDate"`
	PaidAt                  time.Time `json:"paidAt"`
	CurrencyCode            string    `json:"currencyCode"`
	PONumber                string    `json:"poNumber"`
	PriceType               string    `json:"priceType"`
	Recurring               bool      `json:"recurring"`
	Deleted                 bool      `json:"deleted"`
	FirstInvoice            bool      `json:"firstInvoice"`
	IsGifted                bool      `json:"isGifted"`
	Invoicetype             string    `json:"type"`
	Status                  string    `json:"status"`
	SubTotal                float64   `json:"subTotal"`
	Tax                     float64   `json:"tax"`
	Total                   float64   `json:"total"`
	SubTotalInLocalCurrency float64   `json:"subTotalInLocalCurrency"`
	TotalInLocalCurrency    float64   `json:"totalInLocalCurrency"`
	AmountAdjusted          float64   `json:"amountAdjusted"`
	AmountDue               float64   `json:"amountDue"`
	AmountPaid              float64   `json:"amountPaid"`
	AmountToCollect         float64   `json:"amountToCollect"`
	CreditsApplied          float64   `json:"creditsApplied"`
}
type CBCreditNoteResponse struct {
	CreditNoteNumber        string    `json:"creditNoteNumber"`
	ReferenceInvoiceNumber  string    `json:"referenceInvoiceNumber"`
	CreditNoteType          string    `json:"creditNoteType"`
	Date                    time.Time `json:"date"`
	RefundedAt              time.Time `json:"refundedAt"`
	CurrencyCode            string    `json:"currencyCode"`
	LocalCurrencyCode       string    `json:"localCurrencyCode"`
	PriceType               string    `json:"priceType"`
	Deleted                 bool      `json:"deleted"`
	Status                  string    `json:"status"`
	SubTotal                float64   `json:"subTotal"`
	Tax                     float64   `json:"tax"`
	Total                   float64   `json:"total"`
	CreditNoteObject        string    `json:"type"`
	SubTotalInLocalCurrency float64   `json:"subTotalInLocalCurrency"`
	TotalInLocalCurrency    float64   `json:"totalInLocalCurrency"`
	AmountAllocated         float64   `json:"amountAllocated"`
	AmountRefunded          float64   `json:"amountRefunded"`
	AmountAvailable         float64   `json:"amountAvailable"`
}

type CBCardResponse struct {
	FirstName   string `json:"FirstName"`
	LastName    string `json:"LastName"`
	Number      string `json:"Number"`
	ExpiryMonth int32  `json:"ExpiryMonth"`
	ExpiryYear  int32  `json:"ExpiryYear"`
	Brand       string `json:"Brand"`
}

type CBPaymentMethodResponse struct {
	PaymentMethodID string         `json:"paymentMethodID"`
	Card            CBCardResponse `json:"card"`
	CreatedAt       time.Time      `json:"createdAt"`
	CustomerID      string         `json:"customerID"`
	Deleted         bool           `json:"deleted"`
	IssuingCountry  string         `json:"issuingCountry"`
	Status          string         `json:"status"`
	ObjectType      string         `json:"type"`
	IsPrimary       bool           `json:"isPrimary"`
}
