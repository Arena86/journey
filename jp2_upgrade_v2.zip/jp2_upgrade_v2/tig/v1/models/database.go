package models

// ConnectionDatabase data
type ConnectionDatabase struct {
	DBServer   string
	DBPort     string
	DBUsername string
	DBPassword string
}

// RequestHeader data
type RequestHeader struct {
	DBServer       string `json:"dbhost"`
	DBPort         string `json:"dbport"`
	DBName         string `json:"dbname"`
	DBUser         string `json:"dbuser"`
	DBPassword     string `json:"dbpassword"`
	ServerIP       string `json:"serverendpoint"`
	ServerPort     string `json:"serverport"`
	ServerProtocol string `json:"serverprotocol"`
}
