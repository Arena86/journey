package models

import "time"

// TrackAndTraceGPSResponse str
type TrackAndTraceGPSResponse struct {
	CurrentLatitude  float64 `json:"CurrentLatitude"`
	CurrentLongitude float64 `json:"CurrentLongitude"`
}

// TrackAndTraceResponse str
type TrackAndTraceResponse struct {
	Resource          TrackAndTraceResource         `json:"resource"`
	PrecomputedRoutes TrackAndTracePrecomputedRoute `json:"precomputedroutes"`
	JobTask           TrackAndTracePTask            `json:"jobtask"`
}

// TrackAndTraceResource str
type TrackAndTraceResource struct {
	ResourceCode       string `json:"ResourceCode"`
	ResourceName       string `json:"ResourceName"`
	ResourceMode       int    `json:"ResourceMode"`
	ResourceModeName   string `json:"ResourceModeName"`
	ResourceColor      string `json:"ResourceColor"`
	ResourceType       int    `json:"ResourceType"`
	ResourceTypeName   string `json:"ResourceTypeName"`
	RegistrationNumber string `json:"RegistrationNumber"`
}

// TrackAndTracePrecomputedRoute str
type TrackAndTracePrecomputedRoute struct {
	PrecomputedRoute    string `json:"PrecomputedRoute"`
	PrecomputedRouteWeb string `json:"PrecomputedRouteWeb"`
}

// TrackAndTracePTask str
type TrackAndTracePTask struct {
	JobTaskID                int        `json:"JobTaskID"`
	Status                   int        `json:"Status"`
	StatusName               string     `json:"StatusName"`
	JobType                  int        `json:"JobType"`
	JobTypeName              string     `json:"JobTypeName"`
	JobNumber                string     `json:"JobNumber"`
	CompanyName              string     `json:"CompanyName"`
	NavigationAddress        string     `json:"NavigationAddress"`
	LocationName             string     `json:"LocationName"`
	LocationPhone            string     `json:"LocationPhone"`
	EstimatedArrivalDateTime *time.Time `json:"EstimatedArrivalDateTime"`
}
