package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// JobTemplate data
type JobTemplate struct {
	JobTemplateID              int        `gorm:"column:JobTemplateID;primaryKey;autoIncrement;not null" json:"JobTemplateID"`
	CreatedBy                  int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                 int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate               *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                  bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                    bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                 bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobTemplateName            string     `gorm:"column:JobTemplateName" json:"JobTemplateName"`
	JobTemplateCode            string     `gorm:"column:JobTemplateCode" json:"JobTemplateCode"`
	Description                string     `gorm:"column:Description" json:"Description"`
	Icon                       string     `gorm:"column:Icon" json:"Icon"`
	JobType                    int        `gorm:"column:JobType" json:"JobType"`
	TravelChargeMode           int        `gorm:"column:TravelChargeMode" json:"TravelChargeMode"`
	TravelCharge               int        `gorm:"column:TravelCharge" json:"TravelCharge"`
	FormFlowID                 int        `gorm:"column:FormFlowID" json:"FormFlowID"`
	FormFlowSecondID           int        `gorm:"column:FormFlowSecondID" json:"FormFlowSecondID"`
	ServiceTimeInMinutes       int        `gorm:"column:ServiceTimeInMinutes" json:"ServiceTimeInMinutes"`
	ServiceTimeInMinutesSecond int        `gorm:"column:ServiceTimeInMinutesSecond" json:"ServiceTimeInMinutesSecond"`
	Sort                       int        `gorm:"column:Sort" json:"Sort"`
}

// JobTemplateResponse data
type JobTemplateResponse struct {
	JobTemplateID                   int        `json:"JobTemplateID"`
	JobTemplateName                 string     `json:"JobTemplateName"`
	JobTemplateCode                 string     `json:"JobTemplateCode"`
	Description                     string     `json:"Description"`
	Icon                            string     `json:"Icon"`
	JobType                         int        `json:"JobType"`
	JobTypeName                     string     `json:"JobTypeName"`
	TravelChargeMode                int        `json:"TravelChargeMode"`
	TravelCharge                    int        `json:"TravelCharge"`
	TravelChargeModeName            string     `json:"TravelChargeModeName"`
	TravelChargeName                string     `json:"TravelChargeName"`
	FormFlowID                      int        `json:"FormFlowID"`
	FormFlowName                    string     `json:"FormFlowName"`
	FormFlowStatus                  int        `json:"FormFlowStatus"`
	FormFlowLastPublishedDate       *time.Time `json:"FormFlowLastPublishedDate"`
	FormFlowSecondID                int        `json:"FormFlowSecondID"`
	FormFlowSecondName              string     `json:"FormFlowSecondName"`
	FormFlowSecondStatus            int        `json:"FormFlowSecondStatus"`
	ServiceTimeInMinutes            int        `json:"ServiceTimeInMinutes"`
	ServiceTimeInMinutesSecond      int        `json:"ServiceTimeInMinutesSecond"`
	FormFlowSecondLastPublishedDate *time.Time `json:"FormFlowSecondLastPublishedDate"`
	Sort                            int        `json:"Sort"`
}

// TableName func
func (JobTemplate) TableName() string {
	return "jobtemplates"
}

// BeforeCreate func
func (object *JobTemplate) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *JobTemplate) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *JobTemplate) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("JobTemplateID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.JobTemplateID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("JobTemplateName", JSONObject)
	if res != nil {
		object.JobTemplateName = val
	}
	val, res = services.ConvertJSONValueToVariable("JobTemplateCode", JSONObject)
	if res != nil {
		object.JobTemplateCode = val
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}
	val, res = services.ConvertJSONValueToVariable("Icon", JSONObject)
	if res != nil {
		object.Icon = val
	}
	val, res = services.ConvertJSONValueToVariable("JobType", JSONObject)
	if res != nil {
		vJobType, sJobType := strconv.Atoi(val)
		if sJobType == nil {
			object.JobType = vJobType
		}
	}
	val, res = services.ConvertJSONValueToVariable("TravelChargeMode", JSONObject)
	if res != nil {
		vTravelChargeMode, sTravelChargeMode := strconv.Atoi(val)
		if sTravelChargeMode == nil {
			object.TravelChargeMode = vTravelChargeMode
		}
	}
	val, res = services.ConvertJSONValueToVariable("TravelCharge", JSONObject)
	if res != nil {
		object.TravelCharge, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.FormFlowID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowSecondID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.FormFlowSecondID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServiceTimeInMinutes", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.ServiceTimeInMinutes = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServiceTimeInMinutesSecond", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.ServiceTimeInMinutesSecond = vParse
		}
	}
	return
}
