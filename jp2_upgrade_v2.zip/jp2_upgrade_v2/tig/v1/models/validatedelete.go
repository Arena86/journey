package models

import (
	"jpapi/tig/v1/services"

	"gorm.io/gorm"
)

// ValidateDeleteStatus str
type ValidateDeleteStatus struct {
	Status  int
	Message string
}

// ValidateDeleteInterface interface
type ValidateDeleteInterface interface {
	ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus
}

// ValidateDelete funcc
func (item BusinessPartner) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in job
		resultFindJobs := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Job{})
		if resultFindJobs.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobpickups
		resultFindJobPickups := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobPickup{})
		if resultFindJobPickups.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobdeliveries
		resultFindJobDeliveries := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobDelivery{})
		if resultFindJobDeliveries.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobonsites
		resultFindJobOnSites := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobOnSite{})
		if resultFindJobOnSites.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobinstores
		resultFindJobInStores := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobInStore{})
		if resultFindJobInStores.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobresourcepickups
		resultFindJobResourcePickups := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobResourcePickup{})
		if resultFindJobResourcePickups.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	if status == 200 {
		// find in jobresourcedeliveries
		resultFindJobResourceDeliveries := db.Where("BusinessPartnerID = ?", item.BusinessPartnerID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobResourceDelivery{})
		if resultFindJobResourceDeliveries.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "BusinessPartner")
		}
	}
	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item Job) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if item.Status > 0 {
		status = 422
		if item.IsEstimate {
			msg = services.GetMessage(lang, "api.jobstatusgreaterzero")
		} else if item.IsJob {
			msg = services.GetMessage(lang, "api.estimatestatusgreaterzero")
		}
	}
	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item Resource) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in schedules
		resultFindSchedules := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Schedule{})
		if resultFindSchedules.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	if status == 200 {
		// find in vehiclestocktakeshistory
		resultFindVehicleStocktakesHistory := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&VehicleStocktakeHistory{})
		if resultFindVehicleStocktakesHistory.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	if status == 200 {
		// find in vehicleinspectionshistory
		resultFindVehicleInspectionsHistory := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&VehicleInspectionHistory{})
		if resultFindVehicleInspectionsHistory.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	if status == 200 {
		// find in journeys
		resultFindJourneys := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Journey{})
		if resultFindJourneys.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	if status == 200 {
		// find in additionalresources
		resultFindAdditionalResources := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&AdditionalResource{})
		if resultFindAdditionalResources.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	if status == 200 {
		// find in schedulerusers
		resultFindSchedulerUsers := db.Where("ResourceID = ?", item.ResourceID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&SchedulerUser{})
		if resultFindSchedulerUsers.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Resource")
		}
	}
	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item Item) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in servicepricelistdetails
		resultFindServicePriceListDetails := db.Where("ItemID = ?", item.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&ServicePriceListDetail{})
		if resultFindServicePriceListDetails.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Item")
		}
	}
	if status == 200 {
		// find in pricelistdetails
		resultFindPriceListDetails := db.Where("ItemID = ?", item.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&PriceListDetail{})
		if resultFindPriceListDetails.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Item")
		}
	}
	if status == 200 {
		// find in relateditems
		resultFindRelatedItems := db.Where("ItemID = ?", item.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&RelatedItem{})
		if resultFindRelatedItems.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Item")
		}
	}
	if status == 200 {
		// find in jobdetails
		resultFindJobDetails := db.Where("ItemID = ?", item.ItemID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&JobDetail{})
		if resultFindJobDetails.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Item")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item ItemGroup) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in items
		resultFindItems := db.Where("ItemGroupID = ?", item.ItemGroupID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Item{})
		if resultFindItems.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "ItemGroup")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item Location) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in businesspartnerlocations
		resultFindBusinesspartnerLocations := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&BusinessPartnerLocation{})
		if resultFindBusinesspartnerLocations.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in resources
		resultFindResources := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Resource{})
		if resultFindResources.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in schedules
		resultFindSchedules := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Schedule{})
		if resultFindSchedules.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in users
		resultFindUsers := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&User{})
		if resultFindUsers.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in jobs
		resultFindJobs := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Job{})
		if resultFindJobs.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in journeys
		resultFindJourneys := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Journey{})
		if resultFindJourneys.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in additionalresources
		resultFindAdditionalResources := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&AdditionalResource{})
		if resultFindAdditionalResources.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}
	if status == 200 {
		// find in schedulerusers
		resultFindSchedulerUsers := db.Where("LocationID = ?", item.LocationID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&SchedulerUser{})
		if resultFindSchedulerUsers.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Location")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item CustomerGroup) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in businesspartners
		resultFindBusinessPartners := db.Where("CustomerGroupID = ?", item.CustomerGroupID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&BusinessPartner{})
		if resultFindBusinessPartners.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "CustomerGroup")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item SecurityGroup) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in users
		resultFindUsers := db.Where("SecurityGroupID = ?", item.SecurityGroupID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&User{})
		if resultFindUsers.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "SecurityGroup")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item User) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in breaks
		resultFindBreaks := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Break{})
		if resultFindBreaks.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "User")
		}
	}
	if status == 200 {
		// find in resources
		resultFindResources := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Resource{})
		if resultFindResources.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "User")
		}
	}
	if status == 200 {
		// find in schedules
		resultFindSchedules := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Schedule{})
		if resultFindSchedules.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "User")
		}
	}
	if status == 200 {
		// find in schedulerusers
		resultFindSchedulerUsers := db.Where("UserID = ?", item.UserID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&SchedulerUser{})
		if resultFindSchedulerUsers.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "User")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item Tax) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in items
		resultFindItems := db.Where("TaxID = ?", item.TaxID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Item{})
		if resultFindItems.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "Tax")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}

// ValidateDelete funcc
func (item LocationGroup) ValidateDelete(db *gorm.DB, lang string) ValidateDeleteStatus {
	var (
		res    ValidateDeleteStatus
		status = 200
		msg    string
	)
	if status == 200 {
		// find in locations
		resultFindLocations := db.Where("LocationGroupID = ?", item.LocationGroupID).Where("IFNULL(IsDeleted, 0) <> 1 AND IFNULL(IsArchived, 0) <> 1").First(&Location{})
		if resultFindLocations.RowsAffected > 0 {
			status = 422
			msg = services.GetMessage(lang, "api.field_assigned", "LocationGroup")
		}
	}

	res.Status = status
	res.Message = msg
	return res
}
