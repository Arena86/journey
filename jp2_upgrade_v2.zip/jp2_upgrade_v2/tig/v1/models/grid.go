package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
)

// ArrGlobalGrid func
type ArrGlobalGrid struct {
	GlobalGrid []GlobalGrid
}

// SetValueToGlobalObject func
func (arrGlobalGrid *ArrGlobalGrid) SetValueToGlobalObject(accountKey int, value bool) {
	var (
		vArrGlobalGrid ArrGlobalGrid
	)
	if arrGlobalGrid != nil {
		vArrGlobalGrid = *arrGlobalGrid
	}
	hasAccountKey := false
	for i, v := range vArrGlobalGrid.GlobalGrid {
		if v.AccountKey == accountKey {
			hasAccountKey = true
			vArrGlobalGrid.GlobalGrid[i].Status = value
			break
		}
	}
	if !hasAccountKey {
		objGlobalGrid := GlobalGrid{AccountKey: accountKey, Status: value}
		vArrGlobalGrid.GlobalGrid = append(vArrGlobalGrid.GlobalGrid, objGlobalGrid)
	}
	arrGlobalGrid.GlobalGrid = vArrGlobalGrid.GlobalGrid
}

// GlobalGrid func
type GlobalGrid struct {
	AccountKey int
	Status     bool
}

// GridGET struct
type GridGET struct {
	GridKey             string `json:"GridKey"`
	AccountKey          int    `json:"AccountKey"`
	DataField           string `json:"DataField"`
	Caption             string `json:"Caption"`
	Visible             bool   `json:"Visible"`
	VisibleIndex        int    `json:"VisibleIndex"`
	Width               string `json:"Width"`
	Format              string `json:"Format"`
	DataType            string `json:"DataType"`
	ShowInColumnChooser bool   `json:"ShowInColumnChooser"`
	Alignment           string `json:"Alignment"`
	AllowGrouping       bool   `json:"AllowGrouping"`
	SortIndex           int    `json:"SortIndex"`
	SortOrder           string `json:"SortOrder"`
	NumberPrecision     int    `json:"NumberPrecision"`
	CellTemplate        string `json:"CellTemplate"`
	EditCellTemplate    string `json:"EditCellTemplate"`
	GroupIndex          *int   `json:"GroupIndex"`
}

// Grid data
type Grid struct {
	GridID              int    `gorm:"column:GridID;primaryKey;autoIncrement;not null" json:"GridID"`
	AccountKey          int    `gorm:"column:AccountKey" json:"AccountKey"`
	GridKey             string `gorm:"column:GridKey" json:"GridKey"`
	DataField           string `gorm:"column:DataField" json:"DataField"`
	Caption             string `gorm:"column:Caption" json:"Caption"`
	DataType            string `gorm:"column:DataType" json:"DataType"`
	Format              string `gorm:"column:Format" json:"Format"`
	VisibleIndex        int    `gorm:"column:VisibleIndex" json:"VisibleIndex"`
	Visible             bool   `gorm:"column:Visible" json:"Visible"`
	Width               string `gorm:"column:Width" json:"Width"`
	SortIndex           int    `gorm:"column:SortIndex" json:"SortIndex"`
	SortOrder           string `gorm:"column:SortOrder" json:"SortOrder"`
	ShowInColumnChooser bool   `gorm:"column:ShowInColumnChooser" json:"ShowInColumnChooser"`
	Alignment           string `gorm:"column:Alignment" json:"Alignment"`
	AllowGrouping       bool   `gorm:"column:AllowGrouping" json:"AllowGrouping"`
	TranslationKey      string `gorm:"column:TranslationKey" json:"TranslationKey"`
	NumberPrecision     int    `gorm:"column:NumberPrecision" json:"NumberPrecision"`
	CellTemplate        string `gorm:"column:CellTemplate" json:"CellTemplate"`
	EditCellTemplate    string `gorm:"column:EditCellTemplate" json:"EditCellTemplate"`
	GroupIndex          *int   `gorm:"column:GroupIndex" json:"GroupIndex"`
}

// TableName func
func (Grid) TableName() string {
	return "grids"
}

// PassBodyJSONToModel func
func (object *Grid) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("GridID", JSONObject)
	if res != nil {
		vGridID, sGridID := strconv.Atoi(val)
		if sGridID == nil {
			object.GridID = vGridID
		}
	}
	val, res = services.ConvertJSONValueToVariable("AccountKey", JSONObject)
	if res != nil {
		vAccountKey, sAccountKey := strconv.Atoi(val)
		if sAccountKey == nil {
			object.AccountKey = vAccountKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("GridKey", JSONObject)
	if res != nil {
		object.GridKey = val
	}
	val, res = services.ConvertJSONValueToVariable("DataField", JSONObject)
	if res != nil {
		val = strings.Replace(val, "UDF.", "", -1)
		object.DataField = val
	}
	val, res = services.ConvertJSONValueToVariable("Caption", JSONObject)
	if res != nil {
		object.Caption = val
	}
	val, res = services.ConvertJSONValueToVariable("DataType", JSONObject)
	if res != nil {
		object.DataType = val
	}
	val, res = services.ConvertJSONValueToVariable("Format", JSONObject)
	if res != nil {
		object.Format = val
	}
	val, res = services.ConvertJSONValueToVariable("VisibleIndex", JSONObject)
	if res != nil {
		vVisbleIndex, sVisbleIndex := strconv.Atoi(val)
		if sVisbleIndex == nil {
			object.VisibleIndex = vVisbleIndex
		}
	}
	val, res = services.ConvertJSONValueToVariable("Visible", JSONObject)
	if res != nil {
		vVisble, sVisble := strconv.ParseBool(val)
		if sVisble == nil {
			object.Visible = vVisble
		}
	}
	val, res = services.ConvertJSONValueToVariable("Width", JSONObject)
	if res != nil {
		object.Width = val
	}
	val, res = services.ConvertJSONValueToVariable("SortIndex", JSONObject)
	if res != nil {
		vSortIndex, sSortIndex := strconv.Atoi(val)
		if sSortIndex == nil {
			object.SortIndex = vSortIndex
		}
	}
	val, res = services.ConvertJSONValueToVariable("SortOrder", JSONObject)
	if res != nil {
		object.SortOrder = val
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	val, res = services.ConvertJSONValueToVariable("ShowInColumnChooser", JSONObject)
	if res != nil {
		vShowInColumnChooser, sShowInColumnChooser := strconv.ParseBool(val)
		if sShowInColumnChooser == nil {
			object.ShowInColumnChooser = vShowInColumnChooser
		}
	}
	val, res = services.ConvertJSONValueToVariable("Alignment", JSONObject)
	if res != nil {
		object.Alignment = val
	}
	val, res = services.ConvertJSONValueToVariable("AllowGrouping", JSONObject)
	if res != nil {
		vAllowGrouping, sAllowGrouping := strconv.ParseBool(val)
		if sAllowGrouping == nil {
			object.AllowGrouping = vAllowGrouping
		}
	}
	val, res = services.ConvertJSONValueToVariable("NumberPrecision", JSONObject)
	if res != nil {
		vPrecision, sPrecision := strconv.Atoi(val)
		if sPrecision == nil {
			object.NumberPrecision = vPrecision
		}
	}
	val, res = services.ConvertJSONValueToVariable("GroupIndex", JSONObject)
	if res != nil {
		vGroupIndex, sGroupIndex := strconv.Atoi(val)
		if sGroupIndex == nil {
			object.GroupIndex = &vGroupIndex
		}
	}
	return
}
