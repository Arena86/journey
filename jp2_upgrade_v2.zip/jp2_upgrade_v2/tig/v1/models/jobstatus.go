package models

// JobStatusMessage str
type JobStatusMessage struct {
	JobID int `json:"JobID"`
	//CompanyID string `json:"CompanyID"`
}
