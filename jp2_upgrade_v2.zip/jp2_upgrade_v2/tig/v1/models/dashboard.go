package models

import (
	"time"

	"gorm.io/gorm"
)

// Dashboard data
type Dashboard struct {
	DashboardID  int        `gorm:"column:DashboardID;primaryKey;autoIncrement;not null" json:"DashboardID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	QueryString  string     `gorm:"column:QueryString" json:"QueryString"`
}

// DashboardResponse data
type DashboardResponse struct {
	DashboardID int    `json:"DashboardID"`
	QueryString string `json:"QueryString"`
}

// TableName func
func (Dashboard) TableName() string {
	return "dashboards"
}

// BeforeCreate func
func (object *Dashboard) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Dashboard) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Dashboard) PassBodyJSONToModel(JSONObject map[string]interface{}) {

	return
}
