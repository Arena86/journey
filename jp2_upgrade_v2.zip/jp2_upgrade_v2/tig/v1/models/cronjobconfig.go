package models

import "time"

// CronjobConfig data
type CronjobConfig struct {
	CronJobConfigID int        `gorm:"column:CronJobConfigID;primaryKey;autoIncrement;not null" json:"CronJobConfigID"`
	TaskName        string     `gorm:"column:TaskName" json:"TaskName"`
	IsRun           bool       `gorm:"column:IsRun" json:"IsRun"`
	LastRunTime     *time.Time `gorm:"column:LastRunTime" json:"LastRunTime"`
}

// TableName func
func (CronjobConfig) TableName() string {
	return "cronjobconfig"
}

// PassBodyJSONToModel func
func (object *CronjobConfig) PassBodyJSONToModel(JSONObject map[string]interface{}) {

	return
}
