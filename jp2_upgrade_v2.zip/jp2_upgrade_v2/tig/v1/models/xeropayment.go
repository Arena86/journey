package models

type XeroPaymentPOST struct {
	Invoice struct {
		InvoiceID string `json:"InvoiceID"`
	} `json:"Invoice"`
	Account struct {
		Code      *string `json:"Code,omitempty"`
		AccountID *string `json:"AccountID,omitempty"`
	} `json:"Account"`
	Date      string  `json:"Date"`
	Amount    float64 `json:"Amount"`
	Reference *string `json:"Reference,omitempty"`
}

type XeroPaymentResponse struct {
	Payments []struct {
		Invoice struct {
			Status string `json:"Status"`
		} `json:"Invoice"`
	} `json:"Payments"`
}
