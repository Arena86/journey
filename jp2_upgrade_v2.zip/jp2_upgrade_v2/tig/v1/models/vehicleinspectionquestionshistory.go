package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleInspectionQuestionHistory data
type VehicleInspectionQuestionHistory struct {
	VehicleInspectionQuestionHistoryID int        `gorm:"column:VehicleInspectionQuestionHistoryID;primaryKey;autoIncrement;not null" json:"VehicleInspectionQuestionHistoryID"`
	CreatedBy                          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                         bool       `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleInspectionHistoryID         int        `gorm:"column:VehicleInspectionHistoryID" json:"VehicleInspectionHistoryID"`
	GroupName                          string     `gorm:"column:GroupName" json:"GroupName"`
	Question                           string     `gorm:"column:Question" json:"Question"`
	Status                             bool       `gorm:"column:Status" json:"Status"`
	Photos                             []Photo    `gorm:"foreignKey:RecordID;references:VehicleInspectionQuestionHistoryID" json:"Photos"`
}

// VehicleInspectionQuestionHistoryResponse data
type VehicleInspectionQuestionHistoryResponse struct {
	VehicleInspectionQuestionHistoryID int             `json:"VehicleInspectionQuestionHistoryID"`
	VehicleInspectionHistoryID         int             `json:"VehicleInspectionHistoryID"`
	GroupName                          string          `json:"GroupName"`
	Question                           string          `json:"Question"`
	Status                             bool            `json:"Status"`
	Photos                             []PhotoResponse `json:"Photos"`
}

// TableName func
func (VehicleInspectionQuestionHistory) TableName() string {
	return "vehicleinspectionquestionshistory"
}

// BeforeCreate func
func (object *VehicleInspectionQuestionHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleInspectionQuestionHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleInspectionQuestionHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionQuestionHistoryID", JSONObject)
	if res != nil {
		object.VehicleInspectionQuestionHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionHistoryID", JSONObject)
	if res != nil {
		object.VehicleInspectionHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Photos", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			photos        = make([]Photo, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail Photo
					)
					detail.PassBodyJSONToModel(obj)
					for _, v := range object.Photos {
						if v.PhotoID > 0 && detail.PhotoID == v.PhotoID {
							detail = v
							detail.PassBodyJSONToModel(obj)
							break
						}
					}
					photos = append(photos, detail)
				}
			}
		}
		object.Photos = photos
	}
	return
}
