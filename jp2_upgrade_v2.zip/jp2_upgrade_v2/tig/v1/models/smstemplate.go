package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// SMSTemplate data
type SMSTemplate struct {
	SMSTemplateID       int        `gorm:"column:SMSTemplateID;primaryKey;autoIncrement;not null" json:"SMSTemplateID"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Name                string     `gorm:"column:Name" json:"Name"`
	TemplateVariableKey int        `gorm:"column:TemplateVariableKey" json:"TemplateVariableKey"`
	Body                string     `gorm:"column:Body" json:"Body"`
}

// SMSTemplateResponse data
type SMSTemplateResponse struct {
	SMSTemplateID           int    `json:"SMSTemplateID"`
	Name                    string `json:"Name"`
	TemplateVariableKey     int    `json:"TemplateVariableKey"`
	TemplateVariableKeyName string `json:"TemplateVariableKeyName"`
	Body                    string `json:"Body"`
}

// TableName func
func (SMSTemplate) TableName() string {
	return "smstemplates"
}

// BeforeCreate func
func (object *SMSTemplate) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SMSTemplate) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SMSTemplate) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SMSTemplateID", JSONObject)
	if res != nil {
		vSMSTemplateID, sSMSTemplateID := strconv.Atoi(val)
		if sSMSTemplateID == nil {
			object.SMSTemplateID = vSMSTemplateID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("TemplateVariableKey", JSONObject)
	if res != nil {
		vTemplateVariableKey, sTemplateVariableKey := strconv.Atoi(val)
		if sTemplateVariableKey == nil {
			object.TemplateVariableKey = vTemplateVariableKey
		}
	}
	val, res = services.ConvertJSONValueToVariable("Body", JSONObject)
	if res != nil {
		val = strings.ReplaceAll(val, "<br>", "")
		val = strings.ReplaceAll(val, "\n\n", "\n")
		object.Body = val
	}
	return
}
