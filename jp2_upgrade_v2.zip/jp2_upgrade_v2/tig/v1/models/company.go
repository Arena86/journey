package models

// ParamsCreateCompany data
type ParamsCreateCompany struct {
	DatabaseID     string `json:"DatabaseID"`
	MasterUser     string `json:"MasterUser"`
	MasterPassword string `json:"MasterPassword"`
	Host           string `json:"Host"`
	DBPort         string `json:"DBPort"`
	DBUsername     string `json:"DBUsername"`
	DBPassword     string `json:"DBPassword"`
	CompanyName    string `json:"CompanyName"`
	CompanyID      string `json:"CompanyId"`
	AccountKey     int    `json:"AccountKey"`
	LocationID     int    `json:"LocationID"`
	Email          string `json:"Email"`
	FirstName      string `json:"FirstName"`
	LastName       string `json:"LastName"`
	IsMaster       bool   `json:"IsMaster"`
}

// ContactUs data
type ContactUs struct {
	Subject      string `json:"subject"`
	CompanyName  string `json:"companyname"`
	FirstName    string `json:"firstName"`
	LastName     string `json:"lastName"`
	Message      string `json:"message"`
	EmailAddress string `json:"emailAddress"`
}
