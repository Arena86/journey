package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// LanguageEN const
const LanguageEN = "en"

// LanguageIT const
const LanguageIT = "it"

// LanguageNL const
const LanguageNL = "nl"

// TranslationResponse func
type TranslationResponse struct {
	TranslationID int    `json:"TranslationID"`
	Language      string `json:"Language"`
	Value         string `json:"Value"`
}

// Translation data
type Translation struct {
	TranslationID int        `gorm:"column:TranslationID;primaryKey;autoIncrement;not null" json:"TranslationID"`
	CreatedBy     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TypeID        int        `gorm:"column:TypeID" json:"TypeID"`
	TypeName      string     `gorm:"column:TypeName" json:"TypeName"`
	EN            string     `gorm:"column:EN" json:"EN"`
	IT            string     `gorm:"column:IT" json:"IT"`
	NL            string     `gorm:"column:NL" json:"NL"`
}

// TableName func
func (Translation) TableName() string {
	return "translations"
}

// BeforeCreate func
func (object *Translation) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Translation) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Translation) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TranslationID", JSONObject)
	if res != nil {
		vTranslationID, sTranslationID := strconv.Atoi(val)
		if sTranslationID == nil {
			object.TranslationID = vTranslationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("TypeID", JSONObject)
	if res != nil {
		vTypeID, sTypeID := strconv.Atoi(val)
		if sTypeID == nil {
			object.TypeID = vTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("TypeName", JSONObject)
	if res != nil {
		object.TypeName = val
	}
	val, res = services.ConvertJSONValueToVariable("EN", JSONObject)
	if res != nil {
		object.EN = val
	}
	val, res = services.ConvertJSONValueToVariable("IT", JSONObject)
	if res != nil {
		object.IT = val
	}
	val, res = services.ConvertJSONValueToVariable("NL", JSONObject)
	if res != nil {
		object.NL = val
	}
	return
}
