package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PhoneType data
type PhoneType struct {
	PhoneTypeID    int        `gorm:"column:PhoneTypeID;primaryKey"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived"`
	PhoneTypeName  string     `gorm:"column:PhoneTypeName"`
	IsDefault      bool       `gorm:"column:IsDefault"`
	TranslationKey string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	ERP            string     `gorm:"column:Erp" json:"Erp"`
	IsLocation     bool       `gorm:"column:IsLocation"`
	IsDepot        bool       `gorm:"column:IsDepot" json:"IsDepot"`
}

// PhoneTypeResponse data
type PhoneTypeResponse struct {
	PhoneTypeID   int    `json:"PhoneTypeID"`
	PhoneTypeName string `json:"PhoneTypeName"`
	ERP           string `json:"Erp"`
	IsLocation    bool   `json:"IsLocation"`
	IsDepot       bool   `json:"IsDepot"`
	IsDefault     bool   `json:"IsDefault"`
}

// TableName func
func (PhoneType) TableName() string {
	return "phonetypes"
}

// BeforeCreate func
func (object *PhoneType) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PhoneType) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PhoneType) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PhoneTypeID", JSONObject)
	if res != nil {
		vPhoneTypeID, sPhoneTypeID := strconv.Atoi(val)
		if sPhoneTypeID == nil {
			object.PhoneTypeID = vPhoneTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("PhoneTypeName", JSONObject)
	if res != nil {
		object.PhoneTypeName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsDefault", JSONObject)
	if res != nil {
		object.IsDefault, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsAudit", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	val, res = services.ConvertJSONValueToVariable("Erp", JSONObject)
	if res != nil {
		object.ERP = val
	}
	val, res = services.ConvertJSONValueToVariable("IsLocation", JSONObject)
	if res != nil {
		object.IsLocation, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsDepot", JSONObject)
	if res != nil {
		object.IsDepot, _ = strconv.ParseBool(val)
	}

	return
}
