package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleStocktakeQuestionGroup data
type VehicleStocktakeQuestionGroup struct {
	StocktakeQuestionGroupID string                     `gorm:"column:StocktakeQuestionGroupID;primaryKey;not null" json:"StocktakeQuestionGroupID"`
	CreatedBy                int                        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time                 `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int                        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time                 `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool                       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool                       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool                       `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleStocktakeID       int                        `gorm:"column:VehicleStocktakeID" json:"VehicleStocktakeID"`
	GroupName                string                     `gorm:"column:GroupName" json:"GroupName"`
	Sort                     int                        `gorm:"column:Sort" json:"Sort"`
	Questions                []VehicleStocktakeQuestion `gorm:"foreignKey:StocktakeQuestionGroupID;references:StocktakeQuestionGroupID" json:"Questions"`
}

// VehicleStocktakeQuestionGroupResponse data
type VehicleStocktakeQuestionGroupResponse struct {
	StocktakeQuestionGroupID string `json:"StocktakeQuestionGroupID"`
	VehicleStocktakeID       int    `json:"VehicleStocktakeID"`
	GroupName                string `json:"GroupName"`
	Sort                     int    `json:"Sort"`
}

// OnlyVehicleStocktakeQuestionGroupResponse data
type OnlyVehicleStocktakeQuestionGroupResponse struct {
	StocktakeQuestionGroupID string                             `json:"StocktakeQuestionGroupID"`
	VehicleStocktakeID       int                                `json:"VehicleStocktakeID"`
	GroupName                string                             `json:"GroupName"`
	Sort                     int                                `json:"Sort"`
	Questions                []VehicleStocktakeQuestionResponse `json:"Questions"`
}

// TableName func
func (VehicleStocktakeQuestionGroup) TableName() string {
	return "vehiclestocktakequestiongroups"
}

// BeforeCreate func
func (object *VehicleStocktakeQuestionGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleStocktakeQuestionGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleStocktakeQuestionGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("StocktakeQuestionGroupID", JSONObject)
	if res != nil {
		object.StocktakeQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeID", JSONObject)
	if res != nil {
		object.VehicleStocktakeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		object.Sort, _ = strconv.Atoi(val)
	}
	return
}
