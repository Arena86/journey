package models

import (
	"time"

	"gorm.io/gorm"
)

// LookupFieldResponse data
type LookupFieldResponse struct {
	LookupFieldID    int    `json:"LookupFieldID"`
	TableNameObj     string `json:"TableName"`
	RelatedTableName string `json:"RelatedTableName"`
	FieldName        string `json:"FieldName"`
}

// LookupField data
type LookupField struct {
	LookupFieldID    int        `gorm:"column:LookupFieldID;primaryKey;autoIncrement;not null" json:"LookupFieldID"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	TableNameObj     string     `gorm:"column:TableName" json:"TableName"`
	RelatedTableName string     `gorm:"column:RelatedTableName" json:"RelatedTableName"`
	FieldName        string     `gorm:"column:FieldName" json:"FieldName"`
}

// TableName func
func (LookupField) TableName() string {
	return "lookupfields"
}

// BeforeCreate func
func (object *LookupField) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *LookupField) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *LookupField) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
	/* res interface{}
	val string */
	)

	return
}
