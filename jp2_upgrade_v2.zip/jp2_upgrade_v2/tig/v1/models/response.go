package models

// APIResponseData struct
type APIResponseData struct {
	Status  int         `json:"status"`
	Message interface{} `json:"msg"`
	Errors  interface{} `json:"errors"`
	Data    interface{} `json:"data"`
}
