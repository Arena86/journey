package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Notification data
type Notification struct {
	NotificationID   int        `gorm:"column:NotificationID;primaryKey;autoIncrement;not null" json:"NotificationID"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsArchived       bool       `gorm:"column:IsArchived"`
	ReasonID         int        `gorm:"column:ReasonID" json:"ReasonID"`
	Comment          string     `gorm:"column:Comment" json:"Comment"`
	Group            int        `gorm:"column:Group" json:"Group"`
	NotificationType int        `gorm:"column:NotificationType" json:"NotificationType"`
}

// NotificationResponse data
type NotificationResponse struct {
	NotificationID       int        `json:"NotificationID"`
	ReasonID             int        `json:"ReasonID"`
	ReasonName           string     `json:"ReasonName"`
	Comment              string     `json:"Comment"`
	NotificationType     int        `json:"NotificationType"`
	NotificationTypeName string     `json:"NotificationTypeName"`
	Group                int        `json:"Group"`
	GroupName            string     `json:"GroupName"`
	CreatedDate          *time.Time `json:"CreatedDate"`
	ReadStatus           bool       `json:"ReadStatus"`
}

// NotificationPOST data
type NotificationPOST struct {
	NotificationIDs []int `json:"NotificationIDs"`
}

// UnReadNotificationResponse data
type UnReadNotificationResponse struct {
	Count int `json:"Count"`
}

// TableName func
func (Notification) TableName() string {
	return "notifications"
}

// BeforeCreate func
func (object *Notification) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Notification) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Notification) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("NotificationID", JSONObject)
	if res != nil {
		vNotificationID, sNotificationID := strconv.Atoi(val)
		if sNotificationID == nil {
			object.NotificationID = vNotificationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ReasonID", JSONObject)
	if res != nil {
		vReasonID, sReasonID := strconv.Atoi(val)
		if sReasonID == nil {
			object.ReasonID = vReasonID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("NotificationType", JSONObject)
	if res != nil {
		vNotificationType, sNotificationType := strconv.Atoi(val)
		if sNotificationType == nil {
			object.NotificationType = vNotificationType
		}
	}
	val, res = services.ConvertJSONValueToVariable("Group", JSONObject)
	if res != nil {
		vGroup, sGroup := strconv.Atoi(val)
		if sGroup == nil {
			object.Group = vGroup
		}
	}
	return
}
