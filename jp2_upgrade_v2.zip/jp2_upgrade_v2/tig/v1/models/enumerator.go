package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Enumerator data
type Enumerator struct {
	EnumID                 int        `gorm:"column:EnumID;primaryKey;autoIncrement;not null" json:"EnumID"`
	CreatedBy              int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate            *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy             int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate           *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted              bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived             bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FieldName              string     `gorm:"column:FieldName" json:"FieldName"`
	Status                 int        `gorm:"column:Status" json:"Status"`
	Sort                   int        `gorm:"column:Sort" json:"Sort"`
	Caption                string     `gorm:"column:Caption" json:"Caption"`
	CaptionColor           string     `gorm:"column:CaptionColor" json:"CaptionColor"`
	Icon                   string     `gorm:"column:Icon" json:"Icon"`
	TranslationKey         string     `gorm:"column:TranslationKey" json:"TranslationKey"`
	TravelChargeModeMatrix *string    `gorm:"column:TravelChargeModeMatrix" json:"TravelChargeModeMatrix"`
	ResourceTypeMatrix     *string    `gorm:"column:ResourceTypeMatrix" json:"ResourceTypeMatrix"`
}

// EnumeratorResponse data
type EnumeratorResponse struct {
	EnumID                 int    `json:"EnumID"`
	FieldName              string `json:"FieldName"`
	Status                 int    `json:"Status"`
	Sort                   int    `json:"Sort"`
	Caption                string `json:"Caption"`
	CaptionColor           string `json:"CaptionColor"`
	Icon                   string `json:"Icon"`
	TranslationKey         string `json:"TranslationKey"`
	TravelChargeModeMatrix *[]int `json:"TravelChargeModeMatrix"`
	ResourceTypeMatrix     *[]int `json:"ResourceTypeMatrix"`
}

// TableName func
func (Enumerator) TableName() string {
	return "enums"
}

// BeforeCreate func
func (object *Enumerator) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Enumerator) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Enumerator) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("EnumID", JSONObject)
	if res != nil {
		vEnumID, sEnumID := strconv.Atoi(val)
		if sEnumID == nil {
			object.EnumID = vEnumID
		}
	}
	val, res = services.ConvertJSONValueToVariable("FieldName", JSONObject)
	if res != nil {
		object.FieldName = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		vStatus, sStatus := strconv.Atoi(val)
		if sStatus == nil {
			object.Status = vStatus
		}
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		vSort, sSort := strconv.Atoi(val)
		if sSort == nil {
			object.Sort = vSort
		}
	}
	val, res = services.ConvertJSONValueToVariable("Caption", JSONObject)
	if res != nil {
		object.Caption = val
	}
	val, res = services.ConvertJSONValueToVariable("CaptionColor", JSONObject)
	if res != nil {
		object.CaptionColor = val
	}
	val, res = services.ConvertJSONValueToVariable("Icon", JSONObject)
	if res != nil {
		object.Icon = val
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	return
}
