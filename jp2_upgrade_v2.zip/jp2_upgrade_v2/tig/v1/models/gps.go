package models

import "time"

// GPSMessage str
type GPSMessage struct {
	Key           string `json:"key"`
	AccountKey    string `json:"accountKey"`
	Lat           string `json:"lat"`
	Lng           string `json:"lng"`
	LocationID    string `json:"locationId"`
	ResourceID    string `json:"resourceId"`
	DateTime      string `json:"dateTime"`
	GpsSignal     string `json:"gpsSignal"`
	Street        string `json:"street"`
	City          string `json:"city"`
	SpeedLimit    string `json:"speedLimit"`
	Speeding      string `json:"speeding"`
	Eta           string `json:"eta"`
	LengthPassed  string `json:"lengthPassed"`
	LengthTotal   string `json:"lengthTotal"`
	TimeDelay     string `json:"timeDelay"`
	TimeRemaining string `json:"timeRemaining"`
	Traffic       string `json:"traffic"`
	VehicleSpeed  string `json:"vehicleSpeed"`
	Warning       string `json:"warning"`
	JourneyCode   string `json:"journeyCode"`
	CompanyID     string `json:"companyId"`
}

// GPSMessageResponse str
type GPSMessageResponse struct {
	Key           string    `json:"Key"`
	AccountKey    int       `json:"AccountKey"`
	Lat           float64   `json:"Lat"`
	Lng           float64   `json:"Lng"`
	LocationID    int       `json:"LocationID"`
	ResourceID    int       `json:"ResourceID"`
	GpsSignal     int       `json:"GpsSignal"`
	Street        string    `json:"Street"`
	City          string    `json:"City"`
	SpeedLimit    int       `json:"SpeedLimit"`
	Speeding      int       `json:"Speeding"`
	Eta           int       `json:"Eta"`
	LengthPassed  int       `json:"LengthPassed"`
	LengthTotal   int       `json:"LengthTotal"`
	TimeDelay     int       `json:"TimeDelay"`
	TimeRemaining int       `json:"TimeRemaining"`
	Traffic       int       `json:"Traffic"`
	VehicleSpeed  int       `json:"VehicleSpeed"`
	Warning       int       `json:"Warning"`
	DateTime      time.Time `json:"DateTime"`
	JourneyCode   string    `json:"JourneyCode"`
	CompanyID     string    `json:"CompanyID"`
}

// GPSResource str
type GPSResource struct {
	ResourceID  string `json:"resourceId"`
	AccountKey  string `json:"accountKey"`
	DateTime    string `json:"dateTime"`
	JourneyCode string `json:"journeyCode"`
	CompanyID   string `json:"companyId"`
}

// GPSResourceResponse str
type GPSResourceResponse struct {
	ResourceID  int    `json:"ResourceID"`
	AccountKey  int    `json:"AccountKey"`
	Date        string `json:"Date"`
	JourneyCode string `json:"JourneyCode"`
	CompanyID   string `json:"CompanyID"`
}
