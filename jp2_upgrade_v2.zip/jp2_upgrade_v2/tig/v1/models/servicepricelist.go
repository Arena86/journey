package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ServicePriceList data
type ServicePriceList struct {
	ServicePriceListID      int                      `gorm:"column:ServicePriceListID;primaryKey;autoIncrement;not null" json:"ServicePriceListID"`
	CreatedBy               int                      `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate             *time.Time               `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy              int                      `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate            *time.Time               `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted               bool                     `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                 bool                     `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived              bool                     `gorm:"column:IsArchived" json:"IsArchived"`
	ServicePriceListName    string                   `gorm:"column:ServicePriceListName" json:"ServicePriceListName" validate:"required"`
	ServicePriceListDetails []ServicePriceListDetail `gorm:"foreignKey:ServicePriceListID;references:ServicePriceListID" json:"ServicePriceListDetails"`
	IsIncludeTax            bool                     `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
}

// ServicePriceListResponse data
type ServicePriceListResponse struct {
	ServicePriceListID      int                              `json:"ServicePriceListID"`
	ServicePriceListName    string                           `json:"ServicePriceListName"`
	ServicePriceListDetails []ServicePriceListDetailResponse `json:"ServicePriceListDetails"`
	IsIncludeTax            bool                             `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
}

// ServicePriceListResponseMaster data
type ServicePriceListResponseMaster struct {
	ServicePriceListID   int    `json:"ServicePriceListID"`
	ServicePriceListName string `json:"ServicePriceListName"`
	IsIncludeTax         bool   `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
}

// TableName func
func (ServicePriceList) TableName() string {
	return "servicepricelists"
}

// BeforeCreate func
func (object *ServicePriceList) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ServicePriceList) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ServicePriceList) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ServicePriceListID", JSONObject)
	if res != nil {
		vServicePriceListID, sServicePriceListID := strconv.Atoi(val)
		if sServicePriceListID == nil {
			object.ServicePriceListID = vServicePriceListID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServicePriceListName", JSONObject)
	if res != nil {
		object.ServicePriceListName = val
	}

	val, res = services.ConvertJSONValueToVariable("ServicePriceListDetails", JSONObject)
	if res != nil {
		var (
			servicePriceListDetails       []ServicePriceListDetail
			objectServicePriceListDetails []map[string]interface{}
		)
		servicePriceListDetails = make([]ServicePriceListDetail, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectServicePriceListDetails)
			if len(objectServicePriceListDetails) > 0 {
				for _, obj := range objectServicePriceListDetails {
					var (
						detail ServicePriceListDetail
					)
					detail.PassBodyJSONToModel(obj)
					servicePriceListDetails = append(servicePriceListDetails, detail)
				}
			}
		}
		object.ServicePriceListDetails = servicePriceListDetails
	}
	val, res = services.ConvertJSONValueToVariable("IsIncludeTax", JSONObject)
	if res != nil {
		object.IsIncludeTax, _ = strconv.ParseBool(val)
	}
	return
}
