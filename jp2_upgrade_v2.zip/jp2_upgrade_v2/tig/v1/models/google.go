package models

// GoogleDistanceMatrixResponse str
type GoogleDistanceMatrixResponse struct {
	ErrorMessage         string                        `json:"error_message"`
	DestinationAddresses []string                      `json:"destination_addresses"`
	OriginAddresses      []string                      `json:"origin_addresses"`
	Rows                 []GoogleDistanceMatrixElement `json:"rows"`
	Status               string                        `json:"status"`
}

// GoogleDistanceMatrixElement str
type GoogleDistanceMatrixElement struct {
	Elements []GoogleDistanceMatrixElementItem `json:"elements"`
}

// GoogleDistanceMatrixElementItem str
type GoogleDistanceMatrixElementItem struct {
	Distance GoogleDistanceMatrixElementItemValue `json:"distance"`
	Duration GoogleDistanceMatrixElementItemValue `json:"duration"`
	Status   string                               `json:"status"`
}

// GoogleDistanceMatrixElementItemValue str
type GoogleDistanceMatrixElementItemValue struct {
	Text  string `json:"text"`
	Value int    `json:"value"`
}
