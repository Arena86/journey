package models

import (
	"time"

	"gorm.io/gorm"
)

// DeviceMenu data
type DeviceMenu struct {
	MenuID          int        `gorm:"column:MenuID;primaryKey;not null" json:"MenuID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived"`
	Code            string     `gorm:"column:Code" json:"Code"`
	Title           string     `gorm:"column:Title" json:"Title"`
	Description     string     `gorm:"column:Description" json:"Description"`
	Icon            string     `gorm:"column:Icon" json:"Icon"`
	Color           string     `gorm:"column:Color" json:"Color"`
	Image           string     `gorm:"column:Image" json:"Image"`
	TranslationKey1 string     `gorm:"column:TranslationKey1" json:"TranslationKey1"`
	TranslationKey2 string     `gorm:"column:TranslationKey2" json:"TranslationKey2"`
}

// DeviceMenuResponse data
type DeviceMenuResponse struct {
	MenuID      int    `json:"MenuID"`
	Code        string `json:"Code"`
	Title       string `json:"Title"`
	Description string `json:"Description"`
	Icon        string `json:"Icon"`
	Color       string `json:"Color"`
	Image       string `json:"Image"`
}

// TableName func
func (DeviceMenu) TableName() string {
	return "devicemenus"
}

// BeforeCreate func
func (object *DeviceMenu) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DeviceMenu) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DeviceMenu) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	return
}
