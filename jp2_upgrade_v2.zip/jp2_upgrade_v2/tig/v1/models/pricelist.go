package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PriceList data
type PriceList struct {
	PriceListID           int               `gorm:"column:PriceListID;primaryKey;autoIncrement;not null" json:"PriceListID"`
	CreatedBy             int               `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate           *time.Time        `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy            int               `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate          *time.Time        `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted             bool              `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit               bool              `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived            bool              `gorm:"column:IsArchived" json:"IsArchived"`
	PriceListName         string            `gorm:"column:PriceListName" json:"PriceListName"`
	IsSpecial             bool              `gorm:"column:IsSpecial" json:"IsSpecial"`
	FromDate              *time.Time        `gorm:"column:FromDate" json:"FromDate"`
	ToDate                *time.Time        `gorm:"column:ToDate" json:"ToDate"`
	SpecialToPricelistID  int               `gorm:"column:SpecialToPricelistID" json:"SpecialToPricelistID"`
	TravelCalculationMode int               `gorm:"column:TravelCalculationMode" json:"TravelCalculationMode"`
	PriceListDetails      []PriceListDetail `gorm:"foreignKey:PriceListID;references:PriceListID" json:"PriceListDetails"`
	IsIncludeTax          bool              `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
}

// PriceListResponse data
type PriceListResponse struct {
	PriceListID               int                       `json:"PriceListID"`
	PriceListName             string                    `json:"PriceListName"`
	IsSpecial                 bool                      `json:"IsSpecial"`
	FromDate                  *time.Time                `json:"FromDate"`
	ToDate                    *time.Time                `json:"ToDate"`
	SpecialToPricelistID      int                       `json:"SpecialToPricelistID"`
	TravelCalculationMode     int                       `json:"TravelCalculationMode"`
	TravelCalculationModeName string                    `json:"TravelCalculationModeName"`
	PriceListDetails          []PriceListDetailResponse `json:"PriceListDetails"`
	IsIncludeTax              bool                      `json:"IsIncludeTax"`
}

// PriceListResponseMaster data
type PriceListResponseMaster struct {
	PriceListID               int        `json:"PriceListID"`
	PriceListName             string     `json:"PriceListName"`
	IsSpecial                 bool       `json:"IsSpecial"`
	FromDate                  *time.Time `json:"FromDate"`
	ToDate                    *time.Time `json:"ToDate"`
	SpecialToPricelistID      int        `json:"SpecialToPricelistID"`
	TravelCalculationMode     int        `json:"TravelCalculationMode"`
	TravelCalculationModeName string     `json:"TravelCalculationModeName"`
	IsIncludeTax              bool       `json:"IsIncludeTax"`
}

// TableName func
func (PriceList) TableName() string {
	return "pricelists"
}

// BeforeCreate func
func (object *PriceList) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PriceList) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PriceList) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PriceListID", JSONObject)
	if res != nil {
		object.PriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PriceListName", JSONObject)
	if res != nil {
		object.PriceListName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsSpecial", JSONObject)
	if res != nil {
		object.IsSpecial, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("FromDate", JSONObject)
	if res != nil {
		vFromDate, sFromDate := services.ConvertStringToDateTime(val)
		if sFromDate == nil {
			object.FromDate = &vFromDate
		}
	}

	val, res = services.ConvertJSONValueToVariable("ToDate", JSONObject)
	if res != nil {
		vToDate, sToDate := services.ConvertStringToDateTime(val)
		if sToDate == nil {
			object.ToDate = &vToDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("SpecialToPricelistID", JSONObject)
	if res != nil {
		object.SpecialToPricelistID, _ = strconv.Atoi(val)
	}

	val, res = services.ConvertJSONValueToVariable("PriceListDetails", JSONObject)
	if res != nil {
		var (
			details []PriceListDetail
			objects []map[string]interface{}
		)
		details = make([]PriceListDetail, 0)
		detailsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(detailsJSON, &objects)
			if len(objects) > 0 {
				for _, obj := range objects {
					var (
						detail PriceListDetail
					)
					detail.PassBodyJSONToModel(obj)
					details = append(details, detail)
				}
			}
		}
		object.PriceListDetails = details
	}
	val, res = services.ConvertJSONValueToVariable("TravelCalculationMode", JSONObject)
	if res != nil {
		object.TravelCalculationMode, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsIncludeTax", JSONObject)
	if res != nil {
		object.IsIncludeTax, _ = strconv.ParseBool(val)
	}
	return
}
