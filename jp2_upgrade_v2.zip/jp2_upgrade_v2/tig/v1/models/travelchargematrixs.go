package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// TravelTimeChargeMatrix data
type TravelTimeChargeMatrix struct {
	TravelTimeChargeMatrixID int        `gorm:"column:TravelTimeChargeMatrixID;primaryKey;autoIncrement;not null" json:"TravelTimeChargeMatrixID"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Description              string     `gorm:"column:Description" json:"Description"`
	Unit                     int        `gorm:"column:Unit" json:"Unit"`
	Price                    float64    `gorm:"column:Price" json:"Price"`
	DiscountPercent          float64    `gorm:"column:DiscountPercent" json:"DiscountPercent"`
	BufferPercent            float64    `gorm:"column:BufferPercent" json:"BufferPercent"`
	IsIncludeTax             bool       `gorm:"column:IsIncludeTax" json:"IsIncludeTax"`
	TaxID                    int        `gorm:"column:TaxID" json:"TaxID"`
}

// TravelTimeChargeMatrixResponse data
type TravelTimeChargeMatrixResponse struct {
	TravelTimeChargeMatrixID int     `json:"TravelTimeChargeMatrixID"`
	Description              string  `gorm:"column:Description"`
	Unit                     int     `json:"Unit"`
	Price                    float64 `json:"Price"`
	DiscountPercent          float64 `json:"DiscountPercent"`
	BufferPercent            float64 `json:"BufferPercent"`
	IsIncludeTax             bool    `json:"IsIncludeTax"`
	TaxID                    int     `json:"TaxID"`
}

// TableName func
func (TravelTimeChargeMatrix) TableName() string {
	return "traveltimechargematrix"
}

// BeforeCreate func
func (object *TravelTimeChargeMatrix) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *TravelTimeChargeMatrix) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *TravelTimeChargeMatrix) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TravelTimeChargeMatrixID", JSONObject)
	if res != nil {
		vTravelTimeChargeMatrixID, sTravelTimeChargeMatrixID := strconv.Atoi(val)
		if sTravelTimeChargeMatrixID == nil {
			object.TravelTimeChargeMatrixID = vTravelTimeChargeMatrixID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}
	val, res = services.ConvertJSONValueToVariable("Unit", JSONObject)
	if res != nil {
		vUnit, sUnit := strconv.Atoi(val)
		if sUnit == nil {
			object.Unit = vUnit
		}
	}
	val, res = services.ConvertJSONValueToVariable("Price", JSONObject)
	if res != nil {
		vPrice, sPrice := strconv.ParseFloat(val, 64)
		if sPrice == nil {
			object.Price = vPrice
		}
	}
	val, res = services.ConvertJSONValueToVariable("DiscountPercent", JSONObject)
	if res != nil {
		vDiscountPercent, sDiscountPercent := strconv.ParseFloat(val, 64)
		if sDiscountPercent == nil {
			object.DiscountPercent = vDiscountPercent
		}
	}
	val, res = services.ConvertJSONValueToVariable("BufferPercent", JSONObject)
	if res != nil {
		vBufferPercent, sBufferPercent := strconv.ParseFloat(val, 64)
		if sBufferPercent == nil {
			object.BufferPercent = vBufferPercent
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsIncludeTax", JSONObject)
	if res != nil {
		object.IsIncludeTax, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaxID", JSONObject)
	if res != nil {
		object.TaxID, _ = strconv.Atoi(val)
	}
	return
}
