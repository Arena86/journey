package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Permission data
type Permission struct {
	PermissionID                  int        `gorm:"column:PermissionID;primaryKey;autoIncrement;not null" json:"PermissionID"`
	CreatedBy                     int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                   *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                    int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                  *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                     bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                       bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                    bool       `gorm:"column:IsArchived" json:"IsArchived"`
	SecurityGroupID               int        `gorm:"column:SecurityGroupID" json:"SecurityGroupID"`
	PermissionGroup               string     `gorm:"column:PermissionGroup" json:"PermissionGroup"`
	ReportID                      *int       `gorm:"column:ReportID" json:"ReportID"`
	PermissionGroupSort           int        `gorm:"column:PermissionGroupSort" json:"PermissionGroupSort"`
	Area                          string     `gorm:"column:Area" json:"Area"`
	AreaLabel                     string     `gorm:"column:AreaLabel" json:"AreaLabel"`
	CanAccess                     *bool      `gorm:"column:CanAccess" json:"CanAccess"`
	CanView                       *bool      `gorm:"column:CanView" json:"CanView"`
	CanCreate                     *bool      `gorm:"column:CanCreate" json:"CanCreate"`
	CanEdit                       *bool      `gorm:"column:CanEdit" json:"CanEdit"`
	CanDelete                     *bool      `gorm:"column:CanDelete" json:"CanDelete"`
	CanArchive                    *bool      `gorm:"column:CanArchive" json:"CanArchive"`
	CanPrint                      *bool      `gorm:"column:CanPrint" json:"CanPrint"`
	CanExport                     *bool      `gorm:"column:CanExport" json:"CanExport"`
	TranslationTypeID             int        `gorm:"column:TranslationTypeID" json:"TranslationTypeID"`
	PermissionGroupTranslationKey *string    `gorm:"column:PermissionGroupTranslationKey" json:"PermissionGroupTranslationKey"`
}

// PermissionResponse data
type PermissionResponse struct {
	PermissionID        int    `json:"PermissionID"`
	SecurityGroupID     int    `json:"SecurityGroupID"`
	PermissionGroup     string `json:"PermissionGroup"`
	ReportID            *int   `json:"ReportID"`
	PermissionGroupSort int    `json:"PermissionGroupSort"`
	Area                string `json:"Area"`
	AreaLabel           string `json:"AreaLabel"`
	CanAccess           *bool  `json:"CanAccess"`
	CanView             *bool  `json:"CanView"`
	CanCreate           *bool  `json:"CanCreate"`
	CanArchive          *bool  `json:"CanArchive"`
	CanEdit             *bool  `json:"CanEdit"`
	CanDelete           *bool  `json:"CanDelete"`
	CanPrint            *bool  `json:"CanPrint"`
	CanExport           *bool  `json:"CanExport"`
	TranslationTypeID   int    `json:"TranslationTypeID"`
	//Translations      []TranslationResponse `json:"Translations"`
}

// TableName func
func (Permission) TableName() string {
	return "permissions"
}

// BeforeCreate func
func (object *Permission) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Permission) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Permission) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PermissionID", JSONObject)
	if res != nil {
		vPermissionID, sPermissionID := strconv.Atoi(val)
		if sPermissionID == nil {
			object.PermissionID = vPermissionID
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsAudit", JSONObject)
	if res != nil {
		object.IsAudit, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("SecurityGroupID", JSONObject)
	if res != nil {
		vSecurityGroupID, sSecurityGroupID := strconv.Atoi(val)
		if sSecurityGroupID == nil {
			object.SecurityGroupID = vSecurityGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("PermissionGroup", JSONObject)
	if res != nil {
		object.PermissionGroup = val
	}
	val, res = services.ConvertJSONValueToVariable("ReportID", JSONObject)
	if res != nil {
		vReportID, sReportID := strconv.Atoi(val)
		if sReportID == nil {
			object.ReportID = &vReportID
		}
	}
	val, res = services.ConvertJSONValueToVariable("PermissionGroupSort", JSONObject)
	if res != nil {
		vPermissionGroupSort, sPermissionGroupSort := strconv.Atoi(val)
		if sPermissionGroupSort == nil {
			object.PermissionGroupSort = vPermissionGroupSort
		}
	}
	val, res = services.ConvertJSONValueToVariable("Area", JSONObject)
	if res != nil {
		object.Area = val
	}
	val, res = services.ConvertJSONValueToVariable("AreaLabel", JSONObject)
	if res != nil {
		object.AreaLabel = val
	}
	val, res = services.ConvertJSONValueToVariable("CanAccess", JSONObject)
	if res != nil {
		if val == "" {
			object.CanAccess = nil
		} else {
			bCanAccess, eCanAccess := strconv.ParseBool(val)
			if eCanAccess == nil {
				object.CanAccess = &bCanAccess
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanView", JSONObject)
	if res != nil {
		if val == "" {
			object.CanView = nil
		} else {
			bCanView, eCanView := strconv.ParseBool(val)
			if eCanView == nil {
				object.CanView = &bCanView
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanCreate", JSONObject)
	if res != nil {
		if val == "" {
			object.CanCreate = nil
		} else {
			bCanCreate, eCanCreate := strconv.ParseBool(val)
			if eCanCreate == nil {
				object.CanCreate = &bCanCreate
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanEdit", JSONObject)
	if res != nil {
		if val == "" {
			object.CanEdit = nil
		} else {
			bCanEdit, eCanEdit := strconv.ParseBool(val)
			if eCanEdit == nil {
				object.CanEdit = &bCanEdit
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanDelete", JSONObject)
	if res != nil {
		if val == "" {
			object.CanDelete = nil
		} else {
			bCanDelete, eCanDelete := strconv.ParseBool(val)
			if eCanDelete == nil {
				object.CanDelete = &bCanDelete
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanArchive", JSONObject)
	if res != nil {
		if val == "" {
			object.CanArchive = nil
		} else {
			bCanArchive, eCanArchive := strconv.ParseBool(val)
			if eCanArchive == nil {
				object.CanArchive = &bCanArchive
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanPrint", JSONObject)
	if res != nil {
		if val == "" {
			object.CanPrint = nil
		} else {
			bCanPrint, eCanPrint := strconv.ParseBool(val)
			if eCanPrint == nil {
				object.CanPrint = &bCanPrint
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("CanExport", JSONObject)
	if res != nil {
		if val == "" {
			object.CanExport = nil
		} else {
			bCanExport, eCanExport := strconv.ParseBool(val)
			if eCanExport == nil {
				object.CanExport = &bCanExport
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("TranslationTypeID", JSONObject)
	if res != nil {
		vTranslationTypeID, sTranslationTypeID := strconv.Atoi(val)
		if sTranslationTypeID == nil {
			object.TranslationTypeID = vTranslationTypeID
		}
	}
	return
}
