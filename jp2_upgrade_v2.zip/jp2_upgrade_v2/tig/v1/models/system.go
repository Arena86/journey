package models

// ReportServerResponse str
type ReportServerResponse struct {
	Msg    string
	Status int
	Data   string
}

// GetPriceResponse str
type GetPriceResponse struct {
	BusinessPartnerID        int                   `json:"BusinessPartnerID"`
	TotalJob                 float64               `json:"TotalJob"`
	TotalTax                 float64               `json:"TotalTax"`
	SubTotal                 float64               `json:"SubTotal"`
	TotalDiscountAmount      float64               `json:"TotalDiscountAmount"`
	TotalBufferAmount        float64               `json:"TotalBufferAmount"`
	Items                    []GetPriceItem        `json:"Items"`
	TravelDistanceAmount     float64               `json:"TravelDistanceAmount"`
	TravelTimeAmount         float64               `json:"TravelTimeAmount"`
	TravelDistance           float64               `json:"TravelDistance"`
	TravelTime               float64               `json:"TravelTime"`
	TotalTravelAmount        float64               `json:"TotalTravelAmount"`
	DistanceChargeTaxRate    float64               `json:"DistanceChargeTaxRate"`
	TravelTimeChargeTaxRate  float64               `json:"TravelTimeChargeTaxRate"`
	TravelTimeTaxAmount      float64               `json:"TravelTimeTaxAmount"`
	DistanceTaxAmount        float64               `json:"DistanceTaxAmount"`
	TravelCalculation        PriceListTravelMatrix `json:"TravelCalculation"`
	DistanceChargeIncludeTax bool                  `json:"DistanceChargeIncludeTax"`
	TravelTimeIncludeTax     bool                  `json:"TravelTimeIncludeTax"`
	PriceListIncludeTax      bool                  `json:"PriceListIncludeTax"`
	ServiceIncludeTax        bool                  `json:"ServiceIncludeTax"`
}

// GetPricePOST str
type GetPricePOST struct {
	BusinessPartnerID    int            `json:"BusinessPartnerID"`
	ChargeTravelDistance bool           `json:"ChargeTravelDistance"`
	ChargeTravelTime     bool           `json:"ChargeTravelTime"`
	Items                []GetPriceItem `json:"Items"`
	TravelDistance       float64        `json:"TravelDistance"`
	TravelTime           float64        `json:"TravelTime"`
}

// JobFullAddressRequest str
type JobFullAddressRequest struct {
	JobID              int    `json:"JobID"`
	JobTaskID          int    `json:"JobTaskID"`
	Address            string `json:"Address"`
	ContactDetails     string `json:"ContactDetails"`
	ContactPhoneNumber string `json:"ContactPhoneNumber"`
}

// GetPriceItem str
type GetPriceItem struct {
	ItemID                int     `json:"ItemID"`
	LineNum               int     `json:"LineNum"`
	ItemCode              string  `json:"ItemCode"`
	TaxRate               float64 `json:"TaxRate"`
	UnitPrice             float64 `json:"UnitPrice"`
	Quantity              float64 `json:"Quantity"`
	DiscountAmount        float64 `json:"DiscountAmount"`
	DiscountPercent       float64 `json:"DiscountPercent"`
	BufferAmount          float64 `json:"BufferAmount"`
	BufferPercent         float64 `json:"BufferPercent"`
	LineTotal             float64 `json:"LineTotal"`
	LineTotalTax          float64 `json:"LineTotalTax"`
	LineSubTotal          float64 `json:"LineSubTotal"`
	LineTotalTaxExcluded  float64 `json:"LineTotalTaxExcluded"`
	ParentItemID          int     `json:"ParentItemID"`
	SurchargeParentItemID int     `json:"SurchargeParentItemID"`
	IsUpdated             bool    `json:"IsUpdated"`
}

// GetPriceServiceItem str
type GetPriceServiceItem struct {
	ItemID               int     `json:"ItemID"`
	ItemCode             string  `json:"ItemCode"`
	UnitPrice            float64 `json:"UnitPrice"`
	TaxRate              float64 `json:"TaxRate"`
	Quantity             float64 `json:"Quantity"`
	DiscountAmount       float64 `json:"DiscountAmount"`
	DiscountPercent      float64 `json:"DiscountPercent"`
	BufferAmount         float64 `json:"BufferAmount"`
	BufferPercent        float64 `json:"BufferPercent"`
	LineTotal            float64 `json:"LineTotal"`
	LineTotalTax         float64 `json:"LineTotalTax"`
	LineSubTotal         float64 `json:"LineSubTotal"`
	LineTotalTaxExcluded float64 `json:"LineTotalTaxExcluded"`
}

// PriceFromPriceList str
type PriceFromPriceList struct {
	PriceListName   string
	ItemID          int
	Price           float64
	DiscountPercent float64
	BufferPercent   float64
	ServicePrice    []ServicePriceFromPriceList
	DistancePrice   []DistancePriceFromPriceList
}

// ServicePriceFromPriceList func
type ServicePriceFromPriceList struct {
	Price           float64
	DefaultQuantity float64
	DiscountPercent float64
	BufferPercent   float64
}

// DistancePriceFromPriceList func
type DistancePriceFromPriceList struct {
	FromUnit        int
	ToUnit          int
	Rate            float64
	IsRateByRange   bool
	DiscountPercent float64
	BufferPercent   float64
}

// PriceFromItem str
type PriceFromItem struct {
	ItemID    int
	UnitPrice float64
}

// UnlockScreenResponse str
type UnlockScreenResponse struct {
	Unlock bool `json:"Unlock"`
}

// ServerREEResponse str
type ServerREEResponse struct {
	Status int         `json:"status"`
	Msg    interface{} `json:"msg"`
}

// UnlockScreenPASS str
type UnlockScreenPASS struct {
	Password   string `json:"password"`
	AccountKey int    `json:"accountkey"`
}

// UnlockScreenPOST str
type UnlockScreenPOST struct {
	Password string `json:"Password"`
}

// PriceListTravelMatrix data
type PriceListTravelMatrix struct {
	TravelCalculationMode   string                    `json:"TravelCalculationMode"`
	TravelCalculationDetail []TravelCalculationDetail `json:"TravelMatrix"`
}

// TravelCalculationDetail data
type TravelCalculationDetail struct {
	ItemID               int     `json:"ItemID"`
	ItemCode             string  `json:"ItemCode"`
	ItemName             string  `json:"ItemName"`
	Description          string  `json:"Description"`
	TravelDistanceAmount float64 `json:"TravelDistanceAmount"`
	TravelTimeAmount     float64 `json:"TravelTimeAmount"`
}

// ArchiveRequest str
type ArchiveRequest struct {
	IDs   []int  `json:"IDs"`
	Table string `json:"Table"`
}
