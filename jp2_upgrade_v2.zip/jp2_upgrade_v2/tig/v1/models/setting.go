package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SettingValue str
type SettingValue struct {
	Languages []struct {
		Code  string `json:"code"`
		Name  string `json:"name"`
		Icon  string `json:"icon"`
		Value string `json:"value"`
	} `json:"languages,omitempty"`
	Security struct {
		UseLockScreen           bool `json:"useLockScreen"`
		InactivityTime          int  `json:"inactivityTime"`
		PreventF5BrowserRefresh bool `json:"preventF5BrowserRefresh"`
		MaxImageSizeForUpload   int  `json:"maxImageSizeForUpload"`
	} `json:"security"`
	LookupSearch struct {
		ShowSearchWhenNotFound bool `json:"showSearchWhenNotFound"`
		ShowSearchButton       bool `json:"showSearchButton"`
	} `json:"lookupSearch"`
	PriceLists struct {
		DistancePriceList struct {
			DistanceUnit     string `json:"distanceUnit"`
			DistanceUnitName string `json:"distanceUnitName"`
		} `json:"distancePriceList"`
		FDPricesInspectionServiceItem     int    `json:"fDPricesInspectionServiceItem"`
		FDPricesInspectionServiceItemCode string `json:"fDPricesInspectionServiceItemCode"`
		FDPricesInspectionJobTemplate     *int   `json:"fDPricesInspectionJobTemplate"`
		Show4DPriceAfterItemLookup        bool   `json:"show4DPriceAfterItemLookup"`
		SurchargeItemBackgroundColor      string `json:"surchargeItemBackgroundColor"`
		ShowAllDimensionOnDevice          bool   `json:"showAllDimensionOnDevice"`
		FourDPriceFormDesktopOnly         bool   `json:"fDPriceFormDesktopOnly"`
	} `json:"priceLists"`
	DynamicForms struct {
		FormPadding                int    `json:"formPadding"`
		ControlsPadding            int    `json:"controlsPadding"`
		DeviceSpaceBackgroundColor string `json:"deviceSpaceBackgroundColor"`
	} `json:"dynamicForms"`
	Scheduler struct {
		Paging struct {
			PageSize         int   `json:"pageSize"`
			AllowedPageSizes []int `json:"allowedPageSizes"`
		} `json:"paging"`
		Jobs struct {
			DefaultPeriod string `json:"defaultPeriod"`
		} `json:"jobs"`
		RoutesOptimization struct {
			DefaultAdditionalTimeInMinutes int           `json:"defaultAdditionalTimeInMinutes"`
			DefaultAvoidOptions            []interface{} `json:"defaultAvoidOptions"`
			DefaultRouteType               string        `json:"defaultRouteType"`
			ConsiderTraffic                bool          `json:"considerTraffic"`
			OptimizeRoutes                 bool          `json:"optimizeRoutes"`
		} `json:"routesOptimization"`
		DayViewColumnWidth          string `json:"dayViewColumnWidth"`
		Show24Hours                 bool   `json:"show24Hours"`
		JobsOutsideBusinessHours    string `json:"jobsOutsideBusinessHours"`
		NonBusinessHoursColor       string `json:"nonBusinessHoursColor"`
		RecurringScheduleRemoveMode int    `json:"recurringScheduleRemoveMode"`
	} `json:"scheduler"`
	Job struct {
		Map struct {
			DefaultResourceType int           `json:"defaultResourceType"`
			DefaultAvoid        []interface{} `json:"defaultAvoid"`
			Traffic             bool          `json:"traffic"`
		} `json:"map"`
		Totals struct {
			DisplayLineTotalAndSubtotalWithTax bool `json:"displayLineTotalAndSubtotalWithTax"`
		} `json:"totals"`
		Jobs struct {
			DefaultPeriod           string `json:"defaultPeriod"`
			MinServiceTimeInMinutes int    `json:"minServiceTimeInMinutes"`
		} `json:"jobs"`
		General struct {
			UsePreferredTime         bool `json:"usePreferredTime"`
			IsPreferredTimeMandatory bool `json:"isPreferredTimeMandatory"`
		} `json:"general"`
		ShowTodayJobInProgress bool `json:"showTodayJobInProgress"`
	} `json:"job"`
	Resources struct {
		UseLimitedColors bool `json:"useLimitedColors"`
	} `json:"resources"`
	Estimate struct {
		Map struct {
			DefaultResourceType int           `json:"defaultResourceType"`
			DefaultAvoid        []interface{} `json:"defaultAvoid"`
			Traffic             bool          `json:"traffic"`
		} `json:"map"`
		Totals struct {
			DisplayLineTotalAndSubtotalWithTax bool `json:"displayLineTotalAndSubtotalWithTax"`
		} `json:"totals"`
		Email struct {
			DefaultTemplate int  `json:"defaultTemplate"`
			AttachDocument  bool `json:"attachDocument"`
		} `json:"email"`
		General struct {
			EstimateValidDuration    int  `json:"estimateValidDuration"`
			UsePreferredTime         bool `json:"usePreferredTime"`
			IsPreferredTimeMandatory bool `json:"isPreferredTimeMandatory"`
		} `json:"general"`
		AllowManagerApprovalWithoutCustomerApproval bool `json:"allowManagerApprovalWithoutCustomerApproval"`
		UseSuburbAsDefault                          bool `json:"useSuburbAsDefault"`
	} `json:"estimate"`
	Localization struct {
		Localization string `json:"localization"`
		Currency     string `json:"currency"`
	} `json:"localization"`
	Map struct {
		MarkerIcon    string  `json:"markerIcon"`
		MarkerSize    int     `json:"markerSize"`
		MarkerOpacity float64 `json:"markerOpacity"`
	} `json:"map"`
	LiveChat struct {
		ChatHistoryDays int `json:"chatHistoryDays"`
		LastChatPaging  struct {
			PageSize int `json:"pageSize"`
		} `json:"lastChatPaging"`
		ContactPaging struct {
			PageSize int `json:"pageSize"`
		} `json:"contactPaging"`
	} `json:"liveChat"`
	General struct {
		CollapseLeftMenu            bool   `json:"collapseLeftMenu"`
		Theme                       int    `json:"theme"`
		DefaultPhonesCountryCode    string `json:"defaultPhonesCountryCode"`
		ExportToExcelWithAutoFilter bool   `json:"exportToExcelWithAutoFilter"`
	} `json:"general"`
	Items struct {
		LookupHiddenItems           bool   `json:"lookupHiddenItems"`
		RelatedItemBackgroundColor  string `json:"relatedItemBackgroundColor"`
		DefaultServiceTimeInMinutes int    `json:"defaultServiceTimeInMinutes"`
		UseItemServiceTime          bool   `json:"useItemServiceTime"`
	} `json:"items"`
	LiveView struct {
		DriverObjectOpacity float64 `json:"driverObjectOpacity"`
		DriverObjectScale   float64 `json:"driverObjectScale"`
		DriverObjectStroke  int     `json:"driverObjectStroke"`
		RouteLineWidth      int     `json:"routeLineWidth"`
		RouteLineOpacity    float64 `json:"routeLineOpacity"`
	} `json:"liveView"`
	ReplayRoute struct {
		GpsRouteColor       string  `json:"gpsRouteColor"`
		DriverObjectOpacity float64 `json:"driverObjectOpacity"`
		DriverObjectScale   float64 `json:"driverObjectScale"`
		DriverObjectStroke  int     `json:"driverObjectStroke"`
		GpsRouteLineOpacity float64 `json:"gpsRouteLineOpacity"`
		GpsRouteLineWidth   int     `json:"gpsRouteLineWidth"`
		RouteLineWidth      int     `json:"routeLineWidth"`
		RouteLineOpacity    float64 `json:"routeLineOpacity"`
		UseResourceColor    bool    `json:"useResourceColor"`
		SpeedSteps          int     `json:"speedSteps"`
	} `json:"replayRoute"`
	SmartScheduling struct {
		DefaultDays  float64 `json:"defaultDays"`
		MinResources float64 `json:"minResources"`
		MinRoutes    int     `json:"minRoutes"`
	} `json:"smartScheduling"`
	QuickCustomer struct {
		IsEmailAddressMandatory  bool `json:"isEmailAddressMandatory"`
		IsCountryMandatory       bool `json:"isCountryMandatory"`
		IsPhoneNumberMandatory   bool `json:"isPhoneNumberMandatory"`
		IsPriceListsMandatory    bool `json:"isPriceListsMandatory"`
		IsCustomerGroupMandatory bool `json:"isCustomerGroupMandatory"`
		IsLastNameMandatory      bool `json:"isLastNameMandatory"`
	} `json:"quickCustomer"`
	Notifications struct {
		CustomerEstimateApproval         int  `json:"customerEstimateApproval"`
		IsCustomerEstimateApprovalActive bool `json:"isCustomerEstimateApprovalActive"`
		JobInspectionCreation            int  `json:"jobInspectionCreation"`
		IsJobInspectionCreationActive    bool `json:"isJobInspectionCreationActive"`
		JobInspectionCompleted           int  `json:"jobInspectionCompleted"`
		IsJobInspectionCompletedActive   bool `json:"isJobInspectionCompletedActive"`
		CustomerEstimateRejected         int  `json:"customerEstimateRejected"`
		IsCustomerEstimateRejectedActive bool `json:"isCustomerEstimateRejectedActive"`
	} `json:"notifications"`
}

// AppSettingValue str
type AppSettingValue struct {
	DynamicForms struct {
		FormPadding                int    `json:"formPadding"`
		ControlsPadding            int    `json:"controlsPadding"`
		DeviceSpaceBackgroundColor string `json:"deviceSpaceBackgroundColor"`
	} `json:"dynamicForms"`
	LiveChat struct {
		ChatHistoryDays int `json:"chatHistoryDays"`
		LastChatPaging  struct {
			PageSize int `json:"pageSize"`
		} `json:"lastChatPaging"`
		ContactPaging struct {
			PageSize int `json:"pageSize"`
		} `json:"contactPaging"`
	} `json:"liveChat"`
	Security struct {
		UseLockScreen         bool `json:"useLockScreen"`
		InactivityTime        int  `json:"inactivityTime"`
		MaxImageSizeForUpload int  `json:"maxImageSizeForUpload"`
	} `json:"security"`
}

// Setting data
type Setting struct {
	SettingsID   int        `gorm:"column:SettingsID;primaryKey;autoIncrement;not null" json:"SettingsID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Value        *string    `gorm:"column:Value" json:"Value"`
}

// SettingResponse data
type SettingResponse struct {
	SettingsID int     `json:"SettingsID"`
	Value      *string `json:"Value"`
}

// TableName func
func (Setting) TableName() string {
	return "settings"
}

// BeforeCreate func
func (object *Setting) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Setting) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Setting) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SettingsID", JSONObject)
	if res != nil {
		vSettingsID, sSettingsID := strconv.Atoi(val)
		if sSettingsID == nil {
			object.SettingsID = vSettingsID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Value", JSONObject)
	if res != nil {
		valJSON := val
		object.Value = &valJSON
	}
	return
}
