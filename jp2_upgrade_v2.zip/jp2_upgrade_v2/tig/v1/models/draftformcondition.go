package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DraftFormCondition data
type DraftFormCondition struct {
	DraftFormConditionID int        `gorm:"column:DraftFormConditionID;primaryKey;autoIncrement;not null"`
	CreatedBy            int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate          *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy           int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate         *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted            bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit              bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived           bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ConditionID          string     `gorm:"column:ConditionID" json:"ConditionID"`
	FormID               int        `gorm:"column:FormID" json:"FormID"`
	ToForm               string     `gorm:"column:ToForm" json:"ToForm"`
	DefaultToForm        string     `gorm:"column:DefaultToForm" json:"DefaultToForm"`
	FormFlowID           int        `gorm:"column:FormFlowID" json:"FormFlowID"`
	Operator             string     `gorm:"column:Operator" json:"Operator"`
	DataField            string     `gorm:"column:DataField" json:"DataField"`
	ControlID            string     `gorm:"column:ControlID" json:"ControlID"`
	ConditionCode        string     `gorm:"column:ConditionCode" json:"ConditionCode"`
	ConditionValue       string     `gorm:"column:ConditionValue" json:"ConditionValue"`
	ConditionGroup       string     `gorm:"column:ConditionGroup" json:"ConditionGroup"`
	Sort                 int        `gorm:"column:Sort" json:"Sort"`
}

// DraftFormConditionResponse data
type DraftFormConditionResponse struct {
	DraftFormConditionID int    `json:"DraftFormConditionID"`
	ConditionID          string `json:"ConditionID"`
	FormID               int    `json:"FormID"`
	ToForm               string `json:"ToForm"`
	DefaultToForm        string `json:"DefaultToForm"`
	FormFlowID           int    `json:"FormFlowID"`
	Operator             string `json:"Operation"`
	ControlID            string `json:"ControlID"`
	DataField            string `json:"DataField"`
	ConditionCode        string `json:"Condition"`
	ConditionValue       string `json:"ConditionValue"`
	ConditionGroup       string `json:"ConditionGroup"`
	Sort                 int    `json:"Sort"`
}

// DataFieldResponse data
type DataFieldResponse struct {
	Name     string `json:"Name"`
	DataType string `json:"DataType"`
	Value    string `json:"Value"`
}

// TableName func
func (DraftFormCondition) TableName() string {
	return "draftformconditions"
}

// BeforeCreate func
func (object *DraftFormCondition) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DraftFormCondition) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DraftFormCondition) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DraftFormConditionID", JSONObject)
	if res != nil {
		object.DraftFormConditionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ConditionID", JSONObject)
	if res != nil {
		object.ConditionID = val
	}
	val, res = services.ConvertJSONValueToVariable("FormID", JSONObject)
	if res != nil {
		object.FormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ToForm", JSONObject)
	if res != nil {
		object.ToForm = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultToForm", JSONObject)
	if res != nil {
		object.DefaultToForm = val
	}
	val, res = services.ConvertJSONValueToVariable("FormFlowID", JSONObject)
	if res != nil {
		object.FormFlowID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Operator", JSONObject)
	if res != nil {
		object.Operator = val
	}
	val, res = services.ConvertJSONValueToVariable("DataField", JSONObject)
	if res != nil {
		object.DataField = val
	}
	val, res = services.ConvertJSONValueToVariable("ControlID", JSONObject)
	if res != nil {
		object.ControlID = val
	}
	val, res = services.ConvertJSONValueToVariable("ConditionCode", JSONObject)
	if res != nil {
		object.ConditionCode = val
	}
	val, res = services.ConvertJSONValueToVariable("ConditionValue", JSONObject)
	if res != nil {
		object.ConditionValue = val
	}
	val, res = services.ConvertJSONValueToVariable("ConditionGroup", JSONObject)
	if res != nil {
		object.ConditionGroup = val
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		object.Sort, _ = strconv.Atoi(val)
	}
	return
}
