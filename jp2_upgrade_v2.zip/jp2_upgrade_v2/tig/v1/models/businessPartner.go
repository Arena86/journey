package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// BusinessPartner data
type BusinessPartner struct {
	BusinessPartnerID      int                       `gorm:"column:BusinessPartnerID;primaryKey;autoIncrement;not null" json:"BusinessPartnerID"`
	BusinessPartnerCode    string                    `gorm:"column:BusinessPartnerCode;type:varchar(100)" json:"BusinessPartnerCode"`
	ErpKey                 string                    `gorm:"column:ErpKey;type:varchar(100)" json:"ErpKey"`
	CreatedBy              int                       `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate            *time.Time                `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy             int                       `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate           *time.Time                `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted              bool                      `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                bool                      `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived             bool                      `gorm:"column:IsArchived" json:"IsArchived"`
	CompanyName            string                    `gorm:"column:CompanyName;type:varchar(100)" json:"CompanyName"`
	FirstName              string                    `gorm:"column:FirstName;type:varchar(100)" json:"FirstName"`
	LastName               string                    `gorm:"column:LastName;type:varchar(100)" json:"LastName"`
	EmailAddress           string                    `gorm:"column:EmailAddress;type:varchar(100)" json:"EmailAddress"`
	IsVendor               bool                      `gorm:"column:IsVendor" json:"IsVendor"`
	IsCustomer             bool                      `gorm:"column:IsCustomer" json:"IsCustomer"`
	IsContractor           bool                      `gorm:"column:IsContractor" json:"IsContractor"`
	TaxNumber              string                    `gorm:"column:TaxNumber;type:varchar(100)" json:"TaxNumber"`
	DefaultCurrency        string                    `gorm:"column:DefaultCurrency;type:varchar(10)" json:"DefaultCurrency"`
	PriceListID            *int                      `gorm:"column:PriceListID" json:"PriceListID"`
	DefaultDiscountPercent float64                   `gorm:"column:DefaultDiscountPercent" json:"DefaultDiscountPercent"`
	IsPrivate              bool                      `gorm:"column:IsPrivate" json:"IsPrivate"`
	Note                   string                    `gorm:"column:Note" json:"Note"`
	CustomerGroupID        int                       `gorm:"column:CustomerGroupID" json:"CustomerGroupID"`
	Addresses              []Address                 `gorm:"foreignKey:EntityID;references:BusinessPartnerID" json:"Addresses"`
	Phones                 []Phone                   `gorm:"foreignKey:EntityID;references:BusinessPartnerID" json:"Phones"`
	Locations              []BusinessPartnerLocation `gorm:"foreignKey:BusinessPartnerID;references:BusinessPartnerID" json:"Locations"`
	CustomerGroups         *CustomerGroup            `gorm:"foreignKey:CustomerGroupID;references:CustomerGroupID" json:"CustomerGroups"`
	LocationID             string                    `gorm:"column:LocationID" json:"LocationID"`
	IsIntegrationPending   bool                      `gorm:"column:IsIntegrationPending"`
	IntegrationError       string                    `gorm:"column:IntegrationError"`
}

// BusinessPartnerResponse data
type BusinessPartnerResponse struct {
	BusinessPartnerID      int                    `json:"BusinessPartnerID"`
	BusinessPartnerCode    string                 `json:"BusinessPartnerCode"`
	ErpKey                 string                 `json:"ErpKey"`
	CompanyName            string                 `json:"CompanyName"`
	FirstName              string                 `json:"FirstName"`
	LastName               string                 `json:"LastName"`
	EmailAddress           string                 `json:"EmailAddress"`
	IsVendor               bool                   `json:"IsVendor"`
	IsCustomer             bool                   `json:"IsCustomer"`
	IsContractor           bool                   `json:"IsContractor"`
	TaxNumber              string                 `json:"TaxNumber"`
	DefaultCurrency        string                 `json:"DefaultCurrency"`
	PriceListID            *int                   `json:"PriceListID"`
	PriceListName          string                 `json:"PriceListName"`
	DefaultDiscountPercent float64                `json:"DefaultDiscountPercent"`
	IsPrivate              bool                   `json:"IsPrivate"`
	Addresses              []AddressResponse      `json:"Addresses"`
	Phones                 []PhoneResponse        `json:"Phones"`
	LocationIDs            []int                  `json:"LocationIDs"`
	IsDeleted              bool                   `json:"IsDeleted"`
	IsAudit                bool                   `json:"IsAudit"`
	IsArchived             bool                   `json:"IsArchived"`
	Note                   string                 `json:"Note"`
	CustomerGroupID        *int                   `json:"CustomerGroupID"`
	CustomerGroupName      string                 `json:"CustomerGroupName"`
	UDFs                   []UDFResponse          `json:"UDFs"`
	UDF                    map[string]interface{} `json:"UDF"`
}

// BusinessPartnersRequest data
type BusinessPartnersRequest struct {
	BusinessPartnerRequest []BusinessPartnerResponse
}

// TableName func
func (BusinessPartner) TableName() string {
	return "businesspartners"
}

// BeforeCreate func
func (object *BusinessPartner) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *BusinessPartner) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *BusinessPartner) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.BusinessPartnerID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerCode", JSONObject)
	if res != nil {
		object.BusinessPartnerCode = val
	}
	val, res = services.ConvertJSONValueToVariable("ErpKey", JSONObject)
	if res != nil {
		object.ErpKey = val
	}
	val, res = services.ConvertJSONValueToVariable("CompanyName", JSONObject)
	if res != nil {
		object.CompanyName = val
	}
	val, res = services.ConvertJSONValueToVariable("FirstName", JSONObject)
	if res != nil {
		object.FirstName = val
	}
	val, res = services.ConvertJSONValueToVariable("LastName", JSONObject)
	if res != nil {
		object.LastName = val
	}
	val, res = services.ConvertJSONValueToVariable("EmailAddress", JSONObject)
	if res != nil {
		object.EmailAddress = val
	}
	val, res = services.ConvertJSONValueToVariable("IsVendor", JSONObject)
	if res != nil {
		object.IsVendor, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsCustomer", JSONObject)
	if res != nil {
		object.IsCustomer, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsPrivate", JSONObject)
	if res != nil {
		object.IsPrivate, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsContractor", JSONObject)
	if res != nil {
		object.IsContractor, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TaxNumber", JSONObject)
	if res != nil {
		object.TaxNumber = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultCurrency", JSONObject)
	if res != nil {
		object.DefaultCurrency = val
	}
	val, res = services.ConvertJSONValueToVariable("PriceListID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.PriceListID = &vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("DefaultDiscountPercent", JSONObject)
	if res != nil {
		vParse, sParse := strconv.ParseFloat(val, 64)
		if sParse == nil {
			object.DefaultDiscountPercent = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Addresses", JSONObject)
	if res != nil {
		var (
			addresses      []Address
			objectsAddress []map[string]interface{}
		)
		addresses = make([]Address, 0)
		addressJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(addressJSON, &objectsAddress)
			if len(objectsAddress) > 0 {
				for _, objAddress := range objectsAddress {
					var (
						address Address
					)
					address.PassBodyJSONToModel(objAddress)
					addresses = append(addresses, address)
				}
			}
		}
		object.Addresses = addresses
	}
	val, res = services.ConvertJSONValueToVariable("Phones", JSONObject)
	if res != nil {
		var (
			phones       []Phone
			objectsPhone []map[string]interface{}
		)
		phones = make([]Phone, 0)
		phonesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(phonesJSON, &objectsPhone)
			if len(objectsPhone) > 0 {
				for _, objPhone := range objectsPhone {
					var (
						phone Phone
					)
					phone.PassBodyJSONToModel(objPhone)
					phones = append(phones, phone)
				}
			}
		}
		object.Phones = phones
	}
	/* val, res = services.ConvertJSONValueToVariable("Locations", JSONObject)
	if res != nil {
		var (
			locations       []BusinessPartnerLocation
			objectsLocation []map[string]interface{}
		)
		locations = make([]BusinessPartnerLocation, 0)
		locationsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(locationsJSON, &objectsLocation)
			if len(objectsLocation) > 0 {
				for _, objLocation := range objectsLocation {
					var (
						businessPartnerLocation BusinessPartnerLocation
					)
					businessPartnerLocation.PassBodyJSONToModel(objLocation)
					locations = append(locations, businessPartnerLocation)
				}
			}
		}
		object.Locations = locations
	} */
	val, res = services.ConvertJSONValueToVariable("Note", JSONObject)
	if res != nil {
		object.Note = val
	}
	val, res = services.ConvertJSONValueToVariable("CustomerGroupID", JSONObject)
	if res != nil {
		vCustomerGroupID, sCustomerGroupID := strconv.Atoi(val)
		if sCustomerGroupID == nil {
			object.CustomerGroupID = vCustomerGroupID
		}
	}
	return
}

// GenerateDefaultValue func
func (object *BusinessPartner) GenerateDefaultValue(sequencyModel DocumentSequency, customerPrefix, vendorPrefix, contractorPrefix Prefix) {
	if object.BusinessPartnerCode == "" {
		if object.IsVendor {
			if vendorPrefix.DocumentSequence != "" {
				firstConfig := vendorPrefix.Prefix
				lenConfig := vendorPrefix.Length
				sqCode := sequencyModel.VendorCode
				object.BusinessPartnerCode = services.GenerateDefaultValueWithConfigLength(firstConfig, lenConfig, sqCode)
			}
		} else if object.IsCustomer {
			if customerPrefix.DocumentSequence != "" {
				firstConfig := customerPrefix.Prefix
				lenConfig := customerPrefix.Length
				sqCode := sequencyModel.CustomerCode
				object.BusinessPartnerCode = services.GenerateDefaultValueWithConfigLength(firstConfig, lenConfig, sqCode)
			}
		} else if object.IsContractor {
			if contractorPrefix.DocumentSequence != "" {
				firstConfig := contractorPrefix.Prefix
				lenConfig := contractorPrefix.Length
				sqCode := sequencyModel.ContractorCode
				object.BusinessPartnerCode = services.GenerateDefaultValueWithConfigLength(firstConfig, lenConfig, sqCode)
			}
		}
	}
	return
}
