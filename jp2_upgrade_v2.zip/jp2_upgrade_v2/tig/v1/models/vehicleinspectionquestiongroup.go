package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleInspectionQuestionGroup data
type VehicleInspectionQuestionGroup struct {
	InspectionQuestionGroupID string                      `gorm:"column:InspectionQuestionGroupID;primaryKey;not null" json:"InspectionQuestionGroupID"`
	CreatedBy                 int                         `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time                  `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int                         `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time                  `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool                        `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool                        `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                bool                        `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleInspectionID       int                         `gorm:"column:VehicleInspectionID" json:"VehicleInspectionID"`
	GroupName                 string                      `gorm:"column:GroupName" json:"GroupName"`
	Sort                      int                         `gorm:"column:Sort" json:"Sort"`
	Questions                 []VehicleInspectionQuestion `gorm:"foreignKey:InspectionQuestionGroupID;references:InspectionQuestionGroupID" json:"Questions"`
}

// VehicleInspectionQuestionGroupResponse data
type VehicleInspectionQuestionGroupResponse struct {
	InspectionQuestionGroupID string `json:"InspectionQuestionGroupID"`
	VehicleInspectionID       int    `json:"VehicleInspectionID"`
	GroupName                 string `json:"GroupName"`
	Sort                      int    `json:"Sort"`
}

// OnlyQuestionGroupResponse data
type OnlyQuestionGroupResponse struct {
	InspectionQuestionGroupID string                              `json:"InspectionQuestionGroupID"`
	VehicleInspectionID       int                                 `json:"VehicleInspectionID"`
	GroupName                 string                              `json:"GroupName"`
	Sort                      int                                 `json:"Sort"`
	Questions                 []VehicleInspectionQuestionResponse `json:"Questions"`
}

// TableName func
func (VehicleInspectionQuestionGroup) TableName() string {
	return "vehicleinspectionquestiongroups"
}

// BeforeCreate func
func (object *VehicleInspectionQuestionGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleInspectionQuestionGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleInspectionQuestionGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("InspectionQuestionGroupID", JSONObject)
	if res != nil {
		object.InspectionQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("VehicleInspectionID", JSONObject)
	if res != nil {
		object.VehicleInspectionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Sort", JSONObject)
	if res != nil {
		object.Sort, _ = strconv.Atoi(val)
	}

	return
}
