package models

// LicenseProduct str
type LicenseProduct struct {
	CompanyID                       string  `json:"CompanyID"`
	MaxMonthlyJobs                  int     `json:"MaxJobs"`
	MaxDynamicForm                  int     `json:"MaxDynamicForms"`
	ResourceQuantity                float64 `json:"ResourceQuantity"`
	MaxUser                         float64 `json:"MaxUsers"`
	IsSmartScheduling               bool    `json:"IsSmartScheduling"`
	SmartSchedulingQuantity         float64 `json:"SmartSchedulingQuantity"`
	AdditionalDeviceLicenseQuantity float64 `json:"AdditionalDeviceLicenseQuantity"`
	IsXero                          bool    `json:"IsXero"`
	IsMicrosoftDynamic              bool    `json:"IsMicrosoftDynamic"`
	IsLiveChat                      bool    `json:"IsLiveChat"`
	IsReplayRoutes                  bool    `json:"IsReplayRoutes"`
	IsReportDesigner                bool    `json:"IsReportDesigner"`
	ExpiryDate                      string  `json:"ExpiryDate"` // UTC
	PhysicalDeviceQuantity          float64 `json:"PhysicalDeviceQuantity"`
	PhysicalDeviceAmount            float64 `json:"PhysicalDeviceAmount"`
}
