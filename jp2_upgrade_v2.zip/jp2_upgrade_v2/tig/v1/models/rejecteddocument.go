package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// RejectedDocument data
type RejectedDocument struct {
	RejectedDocumentID int        `gorm:"column:RejectedDocumentID;primaryKey;autoIncrement;not null"`
	CreatedBy          int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate        *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy         int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate       *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted          bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit            bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived         bool       `gorm:"column:IsArchived" json:"IsArchived"`
	BusinessPartnerID  int        `gorm:"column:BusinessPartnerID" json:"BusinessPartnerID"`
	JobID              int        `gorm:"column:JobID" json:"JobID"`
	DocumentType       int        `gorm:"column:DocumentType" json:"DocumentType"`
	RejectedDate       *time.Time `gorm:"column:RejectedDate" json:"RejectedDate"`
	TotalDocument      float64    `gorm:"column:TotalDocument" json:"TotalDocument"`
	Comment            string     `gorm:"column:Comment" json:"Comment"`
	Entity             string     `gorm:"column:Entity" json:"Entity"`
}

// RejectedDocumentResponse data
type RejectedDocumentResponse struct {
	RejectedDocumentID int        `json:"RejectedDocumentID"`
	BusinessPartnerID  int        `json:"BusinessPartnerID"`
	JobID              int        `json:"JobID"`
	DocumentType       int        `json:"DocumentType"`
	RejectedDate       *time.Time `json:"RejectedDate"`
	TotalDocument      float64    `json:"TotalDocument"`
	Comment            string     `json:"Comment"`
	Entity             string     `json:"Entity"`
}

// TableName func
func (RejectedDocument) TableName() string {
	return "rejecteddocuments"
}

// BeforeCreate func
func (object *RejectedDocument) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *RejectedDocument) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *RejectedDocument) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("RejectedDocumentID", JSONObject)
	if res != nil {
		object.RejectedDocumentID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerID", JSONObject)
	if res != nil {
		object.BusinessPartnerID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DocumentType", JSONObject)
	if res != nil {
		object.DocumentType, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("RejectedDate", JSONObject)
	if res != nil {
		vRejectedDate, sRejectedDate := services.ConvertStringToDateTime(val)
		if sRejectedDate == nil {
			object.RejectedDate = &vRejectedDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("TotalDocument", JSONObject)
	if res != nil {
		object.TotalDocument, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("Entity", JSONObject)
	if res != nil {
		object.Entity = val
	}
	return
}
