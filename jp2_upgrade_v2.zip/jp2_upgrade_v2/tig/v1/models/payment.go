package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Payment data
type Payment struct {
	PaymentID      int             `gorm:"column:PaymentID;primaryKey;autoIncrement;not null" json:"PaymentID"`
	CreatedBy      int             `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time      `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int             `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time      `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool            `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool            `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool            `gorm:"column:IsArchived" json:"IsArchived"`
	JobID          int             `gorm:"column:JobID" json:"JobID"`
	PaymentDetails []PaymentDetail `gorm:"foreignKey:PaymentID;references:PaymentID" json:"PaymentDetails"`
	Card           Card            `gorm:"-" json:"Card"`
	Amount         float64         `gorm:"-" json:"Amount"`
}

// Payment data
type PaymentRequest struct {
	PaymentMethod     int     `json:"PaymentMethod"`
	Card              Card    `json:"Card"`
	Amount            float64 `json:"Amount"`
	Currency          string  `json:"Currency"`
	PaymentMethodName string  `json:"PaymentMethodName"`
}

type Card struct {
	FirstName string
	LastName  string
	Number    string
	ExpMonth  int
	ExpYear   int
	CVC       string
}

// PaymentResponse data
type PaymentResponse struct {
	PaymentID      int                     `json:"PaymentID"`
	JobID          int                     `json:"JobID"`
	PaymentDetails []PaymentDetailResponse `json:"PaymentDetails"`
}

// PaymentResponseMaster data
type PaymentResponseMaster struct {
}

// TableName func
func (Payment) TableName() string {
	return "payments"
}

// BeforeCreate func
func (object *Payment) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Payment) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Payment) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PaymentID", JSONObject)
	if res != nil {
		object.PaymentID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PaymentDetails", JSONObject)
	if res != nil {
		var (
			paymentDetails       = make([]PaymentDetail, 0)
			objectPaymentDetails []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectPaymentDetails)
			if len(objectPaymentDetails) > 0 {
				for _, obj := range objectPaymentDetails {
					var (
						detail PaymentDetail
					)
					detail.PassBodyJSONToModel(obj)
					for _, detailObj := range object.PaymentDetails {
						if detail.PaymentDetailID == detailObj.PaymentDetailID {
							detail = detailObj
							detail.PassBodyJSONToModel(obj)
							break
						}
					}
					paymentDetails = append(paymentDetails, detail)
				}
			}
		}
		object.PaymentDetails = paymentDetails
	}
	return
}
