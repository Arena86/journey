package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DynamicFormDesign data
type DynamicFormDesign struct {
	DynamicFormDesignID int        `gorm:"column:DynamicFormDesignID;primaryKey;autoIncrement;not null"`
	CreatedBy           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit             bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived          bool       `gorm:"column:IsArchived"`
	DynamicFormID       int        `gorm:"column:DynamicFormID"`
	Orientation         string     `gorm:"column:Orientation"`
	DesignP             *string    `gorm:"column:DesignP"`
	DesignL             *string    `gorm:"column:DesignL"`
}

// DynamicFormDesignResponse data
type DynamicFormDesignResponse struct {
	DynamicFormDesignID int     `json:"DynamicFormDesignID"`
	DynamicFormID       int     `json:"DynamicFormID"`
	Orientation         string  `json:"Orientation"`
	DesignP             *string `json:"DesignP"`
	DesignL             *string `json:"DesignL"`
}

// TableName func
func (DynamicFormDesign) TableName() string {
	return "dynamicformdesigns"
}

// BeforeCreate func
func (object *DynamicFormDesign) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *DynamicFormDesign) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *DynamicFormDesign) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DynamicFormDesignID", JSONObject)
	if res != nil {
		object.DynamicFormDesignID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DynamicFormID", JSONObject)
	if res != nil {
		object.DynamicFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Orientation", JSONObject)
	if res != nil {
		object.Orientation = val
	}
	val, res = services.ConvertJSONValueToVariable("DesignP", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignP = &valJSON
		} else {
			object.DesignP = nil
		}
	}
	val, res = services.ConvertJSONValueToVariable("DesignL", JSONObject)
	if res != nil {
		if val != "" {
			valJSON := val
			object.DesignL = &valJSON
		} else {
			object.DesignL = nil
		}
	}
	return
}
