package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Timezone data
type Timezone struct {
	TimeZoneID   int        `gorm:"column:TimeZoneID;primaryKey;autoIncrement;not null" json:"TimeZoneID"`
	CreatedBy    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Name         string     `gorm:"column:Name" json:"Name"`
	Offset       float64    `gorm:"column:Offset" json:"Offset"`
	CountryCode  string     `gorm:"column:CountryCode" json:"CountryCode"`
	DateFormat   string     `gorm:"column:DateFormat" json:"DateFormat"`
	TimeFormat   string     `gorm:"column:TimeFormat" json:"TimeFormat"`
}

// TimezoneResponse data
type TimezoneResponse struct {
	TimeZoneID  int     `json:"TimeZoneID"`
	Name        string  `json:"Name"`
	Offset      float64 `json:"Offset"`
	CountryCode string  `json:"CountryCode"`
	DateFormat  string  `json:"DateFormat"`
	TimeFormat  string  `json:"TimeFormat"`
}

// TableName func
func (Timezone) TableName() string {
	return "timezones"
}

// BeforeCreate func
func (object *Timezone) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Timezone) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Timezone) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("TimeZoneID", JSONObject)
	if res != nil {
		object.TimeZoneID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("Offset", JSONObject)
	if res != nil {
		object.Offset, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("CountryCode", JSONObject)
	if res != nil {
		object.CountryCode = val
	}
	val, res = services.ConvertJSONValueToVariable("DateFormat", JSONObject)
	if res != nil {
		object.DateFormat = val
	}
	val, res = services.ConvertJSONValueToVariable("TimeFormat", JSONObject)
	if res != nil {
		object.TimeFormat = val
	}
	return
}
