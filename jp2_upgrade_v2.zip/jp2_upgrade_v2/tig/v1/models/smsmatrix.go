package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SMSMatrix data
type SMSMatrix struct {
	SMSMatrixID    int        `gorm:"column:SMSMatrixID;primaryKey"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Caption        string     `gorm:"column:Caption" json:"Caption"`
	Enabled        bool       `gorm:"column:Enabled" json:"Enabled"`
	SMSTemplate    int        `gorm:"column:SMSTemplate" json:"SMSTemplate"`
	Managers       bool       `gorm:"column:Managers" json:"Managers"`
	AssignedUser   bool       `gorm:"column:AssignedUser" json:"AssignedUser"`
	Customer       bool       `gorm:"column:Customer" json:"Customer"`
	Task           bool       `gorm:"column:Task" json:"Task"`
	Task2          bool       `gorm:"column:Task2" json:"Task2"`
	TranslationKey string     `gorm:"column:TranslationKey" json:"TranslationKey"`
}

// SMSMatrixResponse data
type SMSMatrixResponse struct {
	SMSMatrixID    int    `json:"SMSMatrixID"`
	Caption        string `json:"Caption"`
	Enabled        bool   `json:"Enabled"`
	SMSTemplate    int    `json:"SMSTemplate"`
	Managers       bool   `json:"Managers"`
	AssignedUser   bool   `json:"AssignedUser"`
	Customer       bool   `json:"Customer"`
	Task           bool   `json:"Task"`
	Task2          bool   `json:"Task2"`
	TranslationKey string `json:"TranslationKey"`
}

// TableName func
func (SMSMatrix) TableName() string {
	return "smsmatrix"
}

// BeforeCreate func
func (object *SMSMatrix) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SMSMatrix) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SMSMatrix) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SMSMatrixID", JSONObject)
	if res != nil {
		object.SMSMatrixID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Caption", JSONObject)
	if res != nil {
		object.Caption = val
	}
	val, res = services.ConvertJSONValueToVariable("Enabled", JSONObject)
	if res != nil {
		object.Enabled, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("SMSTemplate", JSONObject)
	if res != nil {
		object.SMSTemplate, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Managers", JSONObject)
	if res != nil {
		object.Managers, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("AssignedUser", JSONObject)
	if res != nil {
		object.AssignedUser, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Customer", JSONObject)
	if res != nil {
		object.Customer, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Task", JSONObject)
	if res != nil {
		object.Task, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Task2", JSONObject)
	if res != nil {
		object.Task2, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("TranslationKey", JSONObject)
	if res != nil {
		object.TranslationKey = val
	}
	return
}
