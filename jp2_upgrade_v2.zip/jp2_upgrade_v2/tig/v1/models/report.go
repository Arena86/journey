package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Report data
type Report struct {
	ReportID       int        `gorm:"column:ReportID;primaryKey;autoIncrement;not null" json:"ReportID"`
	CreatedBy      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ReportName     string     `gorm:"column:ReportName" json:"ReportName"`
	ReportGroupID  int        `gorm:"column:ReportGroupID" json:"ReportGroupID"`
	ReportTypeID   int        `gorm:"column:ReportTypeID" json:"ReportTypeID"`
	DocumentTypeID int        `gorm:"column:DocumentTypeID" json:"DocumentTypeID"`
	IsDefault      bool       `gorm:"column:IsDefault" json:"IsDefault"`
	Report         string     `gorm:"column:Report" json:"Report"`
}

// ReportResponse data
type ReportResponse struct {
	ReportID        int                   `json:"ReportID"`
	ReportName      string                `json:"ReportName"`
	ReportGroupID   int                   `json:"ReportGroupID"`
	ReportGroupName string                `json:"ReportGroupName"`
	ReportTypeID    int                   `json:"ReportTypeID"`
	DocumentTypeID  int                   `json:"DocumentTypeID"`
	Caption         string                `json:"Caption"`
	IsDefault       bool                  `json:"IsDefault"`
	Report          string                `json:"Report"`
	Translations    []TranslationResponse `json:"Translations"`
}

// ReportResponseForGetAll data
type ReportResponseForGetAll struct {
	ReportID   int    `json:"ReportID"`
	ReportName string `json:"ReportName"`
	IsDefault  bool   `json:"IsDefault"`
}

// TableName func
func (Report) TableName() string {
	return "reports"
}

// BeforeCreate func
func (object *Report) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Report) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Report) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ReportID", JSONObject)
	if res != nil {
		vReportID, sReportID := strconv.Atoi(val)
		if sReportID == nil {
			object.ReportID = vReportID
		}
	}

	val, res = services.ConvertJSONValueToVariable("ReportName", JSONObject)
	if res != nil {
		object.ReportName = val
	}
	val, res = services.ConvertJSONValueToVariable("ReportGroupID", JSONObject)
	if res != nil {
		vReportGroupID, sReportGroupID := strconv.Atoi(val)
		if sReportGroupID == nil {
			object.ReportGroupID = vReportGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ReportTypeID", JSONObject)
	if res != nil {
		vReportTypeID, sReportTypeID := strconv.Atoi(val)
		if sReportTypeID == nil {
			object.ReportTypeID = vReportTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("DocumentTypeID", JSONObject)
	if res != nil {
		vDocumentTypeID, sDocumentTypeID := strconv.Atoi(val)
		if sDocumentTypeID == nil {
			object.DocumentTypeID = vDocumentTypeID
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsDefault", JSONObject)
	if res != nil {
		object.IsDefault, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Report", JSONObject)
	if res != nil {
		object.Report = val
	}

	return
}
