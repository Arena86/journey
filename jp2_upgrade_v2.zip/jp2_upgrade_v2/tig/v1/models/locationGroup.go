package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// LocationGroupResponseWithLocation data
type LocationGroupResponseWithLocation struct {
	LocationGroupID   int                `json:"LocationGroupID"`
	IsDeleted         bool               `json:"IsDeleted"`
	LocationGroupName string             `json:"LocationGroupName"`
	IsArchived        bool               `json:"IsArchived"`
	Locations         []LocationResponse `json:"Locations"`
}

// LocationGroupResponse data
type LocationGroupResponse struct {
	LocationGroupID   int    `json:"LocationGroupID"`
	IsDeleted         bool   `json:"IsDeleted"`
	LocationGroupName string `json:"LocationGroupName"`
	IsArchived        bool   `json:"IsArchived"`
}

// LocationGroup data
type LocationGroup struct {
	LocationGroupID   int        `gorm:"column:LocationGroupID;primaryKey;autoIncrement;not null" json:"LocationGroupID"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	LocationGroupName string     `gorm:"column:LocationGroupName;type:varchar(20)" json:"LocationGroupName" validate:"required"`
	IsArchived        bool       `gorm:"column:IsArchived" json:"IsArchived"`
}

// TableName func
func (LocationGroup) TableName() string {
	return "locationgroups"
}

// BeforeCreate func
func (object *LocationGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *LocationGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *LocationGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("LocationGroupID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.LocationGroupID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("LocationGroupName", JSONObject)
	if res != nil {
		object.LocationGroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	return
}
