package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

type RecurringSkipPOST struct {
	FromDate string `json:"fromDate"`
	ToDate   string `json:"toDate"`
}

// RecurringSkip data
type RecurringSkip struct {
	RecurringSkipID int        `gorm:"column:RecurringSkipID;primaryKey;autoIncrement;not null"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	RecurringJobID  int        `gorm:"column:RecurringJobID" json:"RecurringJobID"`
	SkipFromDate    time.Time  `gorm:"column:SkipFromDate" json:"SkipFromDate"`
	SkipToDate      time.Time  `gorm:"column:SkipToDate" json:"SkipToDate"`
}

// RecurringSkipResponse data
type RecurringSkipResponse struct {
	RecurringSkipID int       `json:"RecurringSkipID"`
	RecurringJobID  int       `json:"RecurringJobID"`
	SkipFromDate    time.Time `json:"SkipFromDate"`
	SkipToDate      time.Time `json:"SkipToDate"`
}

// TableName func
func (RecurringSkip) TableName() string {
	return "recurringskips"
}

// BeforeCreate func
func (object *RecurringSkip) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *RecurringSkip) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *RecurringSkip) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("RecurringSkipID", JSONObject)
	if res != nil {
		object.RecurringSkipID, _ = strconv.Atoi(val)
	}
	/* val, res = services.ConvertJSONValueToVariable("RecurringJobID", JSONObject)
	if res != nil {
		object.RecurringJobID, _ = strconv.Atoi(val)
	} */
	val, res = services.ConvertJSONValueToVariable("SkipFromDate", JSONObject)
	if res != nil {
		vSkipFromDate, sSkipFromDate := services.ConvertStringToDateTime(val)
		if sSkipFromDate == nil {
			object.SkipFromDate = vSkipFromDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("SkipToDate", JSONObject)
	if res != nil {
		vSkipToDate, sSkipToDate := services.ConvertStringToDateTime(val)
		if sSkipToDate == nil {
			object.SkipToDate = vSkipToDate
		}
	}
	return
}
