package models

// XeroAllocationJPPOST struct
type XeroAllocationJPPOST struct {
	InvoiceID *string  `json:"InvoiceID,omitempty"`
	Amount    *float64 `json:"Amount,omitempty"`
}

// XeroAllocationXeroPOST struct
type XeroAllocationXeroPOST struct {
	Amount  *float64 `json:"Amount,omitempty"`
	Invoice struct {
		InvoiceID string `json:"InvoiceID"`
	} `json:"Invoice"`
}
