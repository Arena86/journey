package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleStocktake data
type VehicleStocktake struct {
	VehicleStocktakeID   int                             `gorm:"column:VehicleStocktakeID;primaryKey;autoIncrement;not null" json:"VehicleStocktakeID"`
	CreatedBy            int                             `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate          *time.Time                      `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy           int                             `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate         *time.Time                      `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted            bool                            `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit              bool                            `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived           bool                            `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleStocktakeName string                          `gorm:"column:VehicleStocktakeName" json:"VehicleStocktakeName"`
	QuestionGroups       []VehicleStocktakeQuestionGroup `gorm:"foreignKey:VehicleStocktakeID;references:VehicleStocktakeID" json:"QuestionGroups"`
}

// VehicleStocktakeResponse data
type VehicleStocktakeResponse struct {
	VehicleStocktakeID   int                                     `json:"VehicleStocktakeID"`
	VehicleStocktakeName string                                  `json:"VehicleStocktakeName"`
	QuestionGroups       []VehicleStocktakeQuestionGroupResponse `json:"QuestionGroups"`
	Questions            []VehicleStocktakeQuestionResponse      `json:"Questions"`
	HistoryCount         int                                     `json:"HistoryCount"`
}

// TableName func
func (VehicleStocktake) TableName() string {
	return "vehiclestocktakes"
}

// BeforeCreate func
func (object *VehicleStocktake) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleStocktake) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleStocktake) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeID", JSONObject)
	if res != nil {
		object.VehicleStocktakeID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeName", JSONObject)
	if res != nil {
		object.VehicleStocktakeName = val
	}
	val, res = services.ConvertJSONValueToVariable("QuestionGroups", JSONObject)
	if res != nil {
		var (
			details       []VehicleStocktakeQuestionGroup
			objectDetails []map[string]interface{}
		)
		details = make([]VehicleStocktakeQuestionGroup, 0)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail VehicleStocktakeQuestionGroup
					)
					detail.PassBodyJSONToModel(obj)
					details = append(details, detail)
				}
			}
		}
		object.QuestionGroups = details
	}
	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail VehicleStocktakeQuestion
					)
					detail.PassBodyJSONToModel(obj)
					for i, questionGroup := range object.QuestionGroups {
						if questionGroup.StocktakeQuestionGroupID == detail.StocktakeQuestionGroupID {
							object.QuestionGroups[i].Questions = append(object.QuestionGroups[i].Questions, detail)
						}
					}
				}
			}
		}
	}
	return
}
