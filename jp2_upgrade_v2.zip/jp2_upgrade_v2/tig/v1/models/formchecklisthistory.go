package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormCheckListHistory data
type FormCheckListHistory struct {
	FormCheckListHistoryID int                            `gorm:"column:FormCheckListHistoryID;primaryKey;autoIncrement;not null"`
	CreatedBy              int                            `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate            *time.Time                     `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy             int                            `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate           *time.Time                     `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted              bool                           `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                bool                           `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived             bool                           `gorm:"column:IsArchived" json:"IsArchived"`
	FormCheckListID        int                            `gorm:"column:FormCheckListID" json:"FormCheckListID"`
	FormCheckListDate      *time.Time                     `gorm:"column:FormCheckListDate" json:"FormCheckListDate"`
	Comment                string                         `gorm:"column:Comment" json:"Comment"`
	JobID                  int                            `gorm:"column:JobID" json:"JobID"`
	JobTaskID              int                            `gorm:"column:JobTaskID" json:"JobTaskID"`
	FormID                 string                         `gorm:"column:FormID" json:"FormID"`
	ButtonID               int                            `gorm:"column:ButtonID" json:"ButtonID"`
	Questions              []FormCheckListQuestionHistory `gorm:"foreignKey:FormCheckListHistoryID;references:FormCheckListHistoryID" json:"Questions"`
}

// FormCheckListHistoryResponse data
type FormCheckListHistoryResponse struct {
	FormCheckListHistoryID int                                    `json:"FormCheckListHistoryID"`
	FormCheckListID        int                                    `json:"FormCheckListID"`
	FormCheckListName      string                                 `json:"FormCheckListName"`
	IsCommentVisible       bool                                   `json:"IsCommentVisible"`
	IsCommentMandatory     bool                                   `json:"IsCommentMandatory"`
	FormCheckListDate      *time.Time                             `json:"FormCheckListDate"`
	Comment                string                                 `json:"Comment"`
	JobID                  int                                    `json:"JobID"`
	JobTaskID              int                                    `json:"JobTaskID"`
	FormID                 string                                 `json:"FormID"`
	ButtonID               int                                    `json:"ButtonID"`
	Questions              []FormCheckListQuestionHistoryResponse `json:"Questions"`
}

// TableName func
func (FormCheckListHistory) TableName() string {
	return "formchecklistshistory"
}

// BeforeCreate func
func (object *FormCheckListHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormCheckListHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormCheckListHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormCheckListHistoryID", JSONObject)
	if res != nil {
		object.FormCheckListHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListID", JSONObject)
	if res != nil {
		object.FormCheckListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListDate", JSONObject)
	if res != nil {
		vFormCheckListDate, sFormCheckListDate := services.ConvertStringToDateTime(val)
		if sFormCheckListDate == nil {
			object.FormCheckListDate = &vFormCheckListDate
		} else {
			if val == "" {
				object.FormCheckListDate = nil
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("FormID", JSONObject)
	if res != nil {
		object.FormID = val
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ButtonID", JSONObject)
	if res != nil {
		object.ButtonID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Questions", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			questions     = make([]FormCheckListQuestionHistory, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						question FormCheckListQuestionHistory
					)
					question.PassBodyJSONToModel(obj)
					for _, v := range object.Questions {
						if v.FormCheckListQuestionHistoryID > 0 && question.FormCheckListQuestionHistoryID == v.FormCheckListQuestionHistoryID {
							question = v
							question.PassBodyJSONToModel(obj)
							break
						}
					}
					questions = append(questions, question)
				}
			}
		}
		object.Questions = questions
	}
	return
}
