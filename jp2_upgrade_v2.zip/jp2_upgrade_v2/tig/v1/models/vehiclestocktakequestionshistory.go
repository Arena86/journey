package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleStocktakeQuestionHistory data
type VehicleStocktakeQuestionHistory struct {
	VehicleStocktakeQuestionHistoryID int        `gorm:"column:VehicleStocktakeQuestionHistoryID;primaryKey;autoIncrement;not null" json:"VehicleStocktakeQuestionHistoryID"`
	CreatedBy                         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                        bool       `gorm:"column:IsArchived" json:"IsArchived"`
	VehicleStocktakeHistoryID         int        `gorm:"column:VehicleStocktakeHistoryID" json:"VehicleStocktakeHistoryID"`
	GroupName                         string     `gorm:"column:GroupName" json:"GroupName"`
	Question                          string     `gorm:"column:Question" json:"Question"`
	Status                            bool       `gorm:"column:Status" json:"Status"`
}

// VehicleStocktakeQuestionHistoryResponse data
type VehicleStocktakeQuestionHistoryResponse struct {
	VehicleStocktakeQuestionHistoryID int    `json:"VehicleStocktakeQuestionHistoryID"`
	VehicleStocktakeHistoryID         int    `json:"VehicleStocktakeHistoryID"`
	GroupName                         string `json:"GroupName"`
	Question                          string `json:"Question"`
	Status                            bool   `json:"Status"`
}

// TableName func
func (VehicleStocktakeQuestionHistory) TableName() string {
	return "vehiclestocktakequestionshistory"
}

// BeforeCreate func
func (object *VehicleStocktakeQuestionHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleStocktakeQuestionHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleStocktakeQuestionHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeQuestionHistoryID", JSONObject)
	if res != nil {
		object.VehicleStocktakeQuestionHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("VehicleStocktakeHistoryID", JSONObject)
	if res != nil {
		object.VehicleStocktakeHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.ParseBool(val)
	}
	return
}
