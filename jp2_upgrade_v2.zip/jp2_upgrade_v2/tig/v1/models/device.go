package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// DeviceLicenseJSON data
type DeviceLicenseJSON struct {
	DeviceID        string     `json:"DeviceID"`
	Status          int        `json:"Status"`
	ActivatedDate   *time.Time `json:"ActivatedDate"`
	DeactivatedDate *time.Time `json:"DeactivatedDate"`
}

// Device data
type Device struct {
	DeviceID        string     `gorm:"column:DeviceID;primaryKey;autoIncrement;not null" json:"DeviceID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	DeviceName      string     `gorm:"column:DeviceName" json:"DeviceName"`
	DeviceModel     string     `gorm:"column:DeviceModel" json:"DeviceModel"`
	OSVersion       string     `gorm:"column:OSVersion" json:"OSVersion"`
	PseudoUniqueID  string     `gorm:"column:PseudoUniqueID" json:"PseudoUniqueID"`
	WLANMACAddress  string     `gorm:"column:WLANMACAddress" json:"WLANMACAddress"`
	AppVersion      string     `gorm:"column:AppVersion" json:"AppVersion"`
	Status          int        `gorm:"column:Status" json:"Status"`
	ActivatedDate   *time.Time `gorm:"column:ActivatedDate" json:"ActivatedDate"`
	DeactivatedDate *time.Time `gorm:"column:DeactivatedDate" json:"DeactivatedDate"`
	Message         string     `gorm:"column:Message" json:"Message"`
}

// DeviceResponse data
type DeviceResponse struct {
	DeviceID        string     `json:"DeviceID"`
	DeviceName      string     `json:"DeviceName"`
	DeviceModel     string     `json:"DeviceModel"`
	OSVersion       string     `json:"OSVersion"`
	PseudoUniqueID  string     `json:"PseudoUniqueID"`
	WLANMACAddress  string     `json:"WLANMACAddress"`
	AppVersion      string     `json:"AppVersion"`
	Status          int        `json:"Status"`
	StatusName      string     `json:"StatusName"`
	ActivatedDate   *time.Time `json:"ActivatedDate"`
	DeactivatedDate *time.Time `json:"DeactivatedDate"`
	Message         string     `json:"Message"`
}

// TableName func
func (Device) TableName() string {
	return "devices"
}

// BeforeCreate func
func (object *Device) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Device) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Device) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DeviceID", JSONObject)
	if res != nil {
		object.DeviceID = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceName", JSONObject)
	if res != nil {
		object.DeviceName = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceModel", JSONObject)
	if res != nil {
		object.DeviceModel = val
	}
	val, res = services.ConvertJSONValueToVariable("OSVersion", JSONObject)
	if res != nil {
		object.OSVersion = val
	}
	val, res = services.ConvertJSONValueToVariable("PseudoUniqueID", JSONObject)
	if res != nil {
		object.PseudoUniqueID = val
	}
	val, res = services.ConvertJSONValueToVariable("WLANMACAddress", JSONObject)
	if res != nil {
		object.WLANMACAddress = val
	}
	val, res = services.ConvertJSONValueToVariable("AppVersion", JSONObject)
	if res != nil {
		object.AppVersion = val
	}
	val, res = services.ConvertJSONValueToVariable("ActivatedDate", JSONObject)
	if res != nil {
		vActivatedDate, sActivatedDate := services.ConvertStringToDateTime(val)
		if sActivatedDate == nil {
			object.ActivatedDate = &vActivatedDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("DeactivatedDate", JSONObject)
	if res != nil {
		vDeactivatedDate, sDeactivatedDate := services.ConvertStringToDateTime(val)
		if sDeactivatedDate == nil {
			object.DeactivatedDate = &vDeactivatedDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("Message", JSONObject)
	if res != nil {
		object.Message = val
	}
	return
}

// PassBodyJSONToModelDeviceLicense func
func (object *Device) PassBodyJSONToModelDeviceLicense(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("DeviceID", JSONObject)
	if res != nil {
		object.DeviceID = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceName", JSONObject)
	if res != nil {
		object.DeviceName = val
	}
	val, res = services.ConvertJSONValueToVariable("DeviceModel", JSONObject)
	if res != nil {
		object.DeviceModel = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ActivatedDate", JSONObject)
	if res != nil {
		vActivatedDate, sActivatedDate := services.ConvertStringToDateTime(val)
		if sActivatedDate == nil {
			object.ActivatedDate = &vActivatedDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("DeactivatedDate", JSONObject)
	if res != nil {
		vDeactivatedDate, sDeactivatedDate := services.ConvertStringToDateTime(val)
		if sDeactivatedDate == nil {
			object.DeactivatedDate = &vDeactivatedDate
		}
	}

	return
}
