package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormCheckListQuestion data
type FormCheckListQuestion struct {
	FormCheckListQuestionID      int        `gorm:"column:FormCheckListQuestionID;primaryKey;autoIncrement;not null"`
	CreatedBy                    int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                  *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                   int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                 *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                    bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                      bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                   bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FormCheckListQuestionGroupID string     `gorm:"column:FormCheckListQuestionGroupID" json:"FormCheckListQuestionGroupID"`
	Question                     string     `gorm:"column:Question" json:"Question"`
	IsPhotoEnable                bool       `gorm:"column:IsPhotoEnable" json:"IsPhotoEnable"`
	IsMandatory                  bool       `gorm:"column:IsMandatory" json:"IsMandatory"`
}

// FormCheckListQuestionResponse data
type FormCheckListQuestionResponse struct {
	FormCheckListQuestionID      int    `json:"FormCheckListQuestionID"`
	FormCheckListQuestionGroupID string `json:"FormCheckListQuestionGroupID"`
	Question                     string `json:"Question"`
	IsPhotoEnable                bool   `json:"IsPhotoEnable"`
	IsMandatory                  bool   `json:"IsMandatory"`
	RowID                        int    `json:"RowID"`
}

// TableName func
func (FormCheckListQuestion) TableName() string {
	return "formchecklistquestions"
}

// BeforeCreate func
func (object *FormCheckListQuestion) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormCheckListQuestion) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormCheckListQuestion) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormCheckListQuestionID", JSONObject)
	if res != nil {
		object.FormCheckListQuestionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListQuestionGroupID", JSONObject)
	if res != nil {
		object.FormCheckListQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("IsPhotoEnable", JSONObject)
	if res != nil {
		object.IsPhotoEnable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsMandatory", JSONObject)
	if res != nil {
		object.IsMandatory, _ = strconv.ParseBool(val)
	}

	return
}
