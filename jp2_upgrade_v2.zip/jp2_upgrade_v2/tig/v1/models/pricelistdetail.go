package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// PriceListDetail data
type PriceListDetail struct {
	PriceListDetailID        int        `gorm:"column:PriceListDetailID;primaryKey;autoIncrement;not null" json:"PriceListDetailID"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	PriceListID              int        `gorm:"column:PriceListID" json:"PriceListID"`
	ItemID                   int        `gorm:"column:ItemID" json:"ItemID"`
	ServicePriceListID       int        `gorm:"column:ServicePriceListID" json:"ServicePriceListID"`
	DistancePriceListID      int        `gorm:"column:DistancePriceListID" json:"DistancePriceListID"`
	TravelTimeChargeMatrixID int        `gorm:"column:TravelTimeChargeMatrixID" json:"TravelTimeChargeMatrixID"`
	Unit                     string     `gorm:"column:Unit" json:"Unit"`
	DefaultQuantity          float64    `gorm:"column:DefaultQuantity" json:"DefaultQuantity"`
	Price                    float64    `gorm:"column:Price" json:"Price"`
	DiscountPercent          float64    `gorm:"column:DiscountPercent" json:"DiscountPercent"`
	BufferPercent            float64    `gorm:"column:BufferPercent" json:"BufferPercent"`
}

// PriceListDetailResponse data
type PriceListDetailResponse struct {
	PriceListDetailID        int     `json:"PriceListDetailID"`
	PriceListID              int     `json:"PriceListID"`
	ItemID                   int     `json:"ItemID"`
	ItemName                 string  `json:"Name"`
	ItemCode                 string  `json:"ItemCode"`
	Description              string  `json:"Description"`
	ServicePriceListID       int     `json:"ServicePriceListID"`
	DistancePriceListID      int     `json:"DistancePriceListID"`
	Unit                     string  `json:"Unit"`
	DefaultQuantity          float64 `json:"DefaultQuantity"`
	Price                    float64 `json:"Price"`
	DiscountPercent          float64 `json:"DiscountPercent"`
	BufferPercent            float64 `json:"BufferPercent"`
	TravelTimeChargeMatrixID int     `json:"TravelTimeChargeMatrixID"`
}

// TableName func
func (PriceListDetail) TableName() string {
	return "pricelistdetails"
}

// BeforeCreate func
func (object *PriceListDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *PriceListDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *PriceListDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("PriceListDetailID", JSONObject)
	if res != nil {
		object.PriceListDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PriceListID", JSONObject)
	if res != nil {
		object.PriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		vItemID, sItemID := strconv.Atoi(val)
		if sItemID == nil {
			object.ItemID = vItemID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServicePriceListID", JSONObject)
	if res != nil {
		object.ServicePriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("DistancePriceListID", JSONObject)
	if res != nil {
		object.DistancePriceListID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("TravelTimeChargeMatrixID", JSONObject)
	if res != nil {
		object.TravelTimeChargeMatrixID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Unit", JSONObject)
	if res != nil {
		object.Unit = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultQuantity", JSONObject)
	if res != nil {
		object.DefaultQuantity, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("Price", JSONObject)
	if res != nil {
		object.Price, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("DiscountPercent", JSONObject)
	if res != nil {
		object.DiscountPercent, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("BufferPercent", JSONObject)
	if res != nil {
		object.BufferPercent, _ = strconv.ParseFloat(val, 64)
	}
	return
}
