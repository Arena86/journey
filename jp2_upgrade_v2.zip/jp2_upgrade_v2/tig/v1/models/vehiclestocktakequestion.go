package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// VehicleStocktakeQuestion data
type VehicleStocktakeQuestion struct {
	StocktakeQuestionID      int        `gorm:"column:StocktakeQuestionID;primaryKey;autoIncrement;not null" json:"StocktakeQuestionID"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	StocktakeQuestionGroupID string     `gorm:"column:StocktakeQuestionGroupID" json:"StocktakeQuestionGroupID"`
	Question                 string     `gorm:"column:Question" json:"Question"`
	Min                      float64    `gorm:"column:Min" json:"Min"`
	Max                      float64    `gorm:"column:Max" json:"Max"`
}

// VehicleStocktakeQuestionResponse data
type VehicleStocktakeQuestionResponse struct {
	StocktakeQuestionID      int     `json:"StocktakeQuestionID"`
	StocktakeQuestionGroupID string  `json:"StocktakeQuestionGroupID"`
	Question                 string  `json:"Question"`
	Min                      float64 `json:"Min"`
	Max                      float64 `json:"Max"`
	RowID                    int     `json:"RowID"`
}

// TableName func
func (VehicleStocktakeQuestion) TableName() string {
	return "vehiclestocktakequestions"
}

// BeforeCreate func
func (object *VehicleStocktakeQuestion) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *VehicleStocktakeQuestion) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *VehicleStocktakeQuestion) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("StocktakeQuestionID", JSONObject)
	if res != nil {
		object.StocktakeQuestionID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("StocktakeQuestionGroupID", JSONObject)
	if res != nil {
		object.StocktakeQuestionGroupID = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("Min", JSONObject)
	if res != nil {
		object.Min, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("Max", JSONObject)
	if res != nil {
		object.Max, _ = strconv.ParseFloat(val, 64)
	}
	return
}
