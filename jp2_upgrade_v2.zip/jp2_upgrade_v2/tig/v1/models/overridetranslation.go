package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// OverrideTranslationResponse func
type OverrideTranslationResponse struct {
	OverrideTranslationID int    `json:"OverrideTranslationID"`
	FieldName             string `json:"FieldName"`
	EN                    string `json:"EN"`
	IT                    string `json:"IT"`
	NL                    string `json:"NL"`
}

// OverrideTranslation data
type OverrideTranslation struct {
	OverrideTranslationID int        `gorm:"column:OverrideTranslationID;primaryKey;autoIncrement;not null" json:"OverrideTranslationID"`
	CreatedBy             int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate           *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy            int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate          *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted             bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit               bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived            bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FieldName             string     `gorm:"column:FieldName" validate:"required" json:"FieldName"`
	EN                    string     `gorm:"column:EN" json:"EN"`
	IT                    string     `gorm:"column:IT" json:"IT"`
	NL                    string     `gorm:"column:NL" json:"NL"`
}

// TableName func
func (OverrideTranslation) TableName() string {
	return "overridetranslations"
}

// BeforeCreate func
func (object *OverrideTranslation) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *OverrideTranslation) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *OverrideTranslation) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("OverrideTranslationID", JSONObject)
	if res != nil {
		vOverrideTranslationID, sOverrideTranslationID := strconv.Atoi(val)
		if sOverrideTranslationID == nil {
			object.OverrideTranslationID = vOverrideTranslationID
		}
	}
	val, res = services.ConvertJSONValueToVariable("FieldName", JSONObject)
	if res != nil {
		object.FieldName = val
	}
	val, res = services.ConvertJSONValueToVariable("EN", JSONObject)
	if res != nil {
		object.EN = val
	}
	val, res = services.ConvertJSONValueToVariable("IT", JSONObject)
	if res != nil {
		object.IT = val
	}
	val, res = services.ConvertJSONValueToVariable("NL", JSONObject)
	if res != nil {
		object.NL = val
	}
	return
}
