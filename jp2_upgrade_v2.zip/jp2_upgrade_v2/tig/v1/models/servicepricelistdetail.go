package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// ServicePriceListDetail data
type ServicePriceListDetail struct {
	ServicePriceListDetailID int        `gorm:"column:ServicePriceListDetailID;primaryKey;autoIncrement;not null" json:"ServicePriceListDetailID"`
	CreatedBy                int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate              *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy               int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate             *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                  bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived               bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ServicePriceListID       int        `gorm:"column:ServicePriceListID" json:"ServicePriceListID"`
	ItemID                   int        `gorm:"column:ItemID" json:"ItemID"`
	Unit                     string     `gorm:"column:Unit" json:"Unit"`
	DefaultQuantity          float64    `gorm:"column:DefaultQuantity" json:"DefaultQuantity"`
	Price                    float64    `gorm:"column:Price" json:"Price"`
	DiscountPercent          float64    `gorm:"column:DiscountPercent" json:"DiscountPercent"`
	BufferPercent            float64    `gorm:"column:BufferPercent" json:"BufferPercent"`
}

// ServicePriceListDetailResponse data
type ServicePriceListDetailResponse struct {
	ServicePriceListDetailID int     `json:"ServicePriceListDetailID"`
	ServicePriceListID       int     `json:"ServicePriceListID"`
	ItemID                   int     `json:"ItemID"`
	ItemName                 string  `json:"Name"`
	ItemCode                 string  `json:"ItemCode"`
	Description              string  `json:"Description"`
	Unit                     string  `json:"Unit"`
	DefaultQuantity          float64 `json:"DefaultQuantity"`
	Price                    float64 `json:"Price"`
	DiscountPercent          float64 `json:"DiscountPercent"`
	BufferPercent            float64 `json:"BufferPercent"`
}

// TableName func
func (ServicePriceListDetail) TableName() string {
	return "servicepricelistdetails"
}

// BeforeCreate func
func (object *ServicePriceListDetail) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *ServicePriceListDetail) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *ServicePriceListDetail) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("ServicePriceListDetailID", JSONObject)
	if res != nil {
		vServicePriceListDetailID, sServicePriceListDetailID := strconv.Atoi(val)
		if sServicePriceListDetailID == nil {
			object.ServicePriceListDetailID = vServicePriceListDetailID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServicePriceListID", JSONObject)
	if res != nil {
		vServicePriceListID, sServicePriceListID := strconv.Atoi(val)
		if sServicePriceListID == nil {
			object.ServicePriceListID = vServicePriceListID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ItemID", JSONObject)
	if res != nil {
		vItemID, sItemID := strconv.Atoi(val)
		if sItemID == nil {
			object.ItemID = vItemID
		}
	}
	val, res = services.ConvertJSONValueToVariable("Unit", JSONObject)
	if res != nil {
		object.Unit = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultQuantity", JSONObject)
	if res != nil {
		vDefaultQuantity, sDefaultQuantity := strconv.ParseFloat(val, 64)
		if sDefaultQuantity == nil {
			object.DefaultQuantity = vDefaultQuantity
		}
	}
	val, res = services.ConvertJSONValueToVariable("Price", JSONObject)
	if res != nil {
		vPrice, sPrice := strconv.ParseFloat(val, 64)
		if sPrice == nil {
			object.Price = vPrice
		}
	}
	val, res = services.ConvertJSONValueToVariable("DiscountPercent", JSONObject)
	if res != nil {
		vDiscountPercent, sDiscountPercent := strconv.ParseFloat(val, 64)
		if sDiscountPercent == nil {
			object.DiscountPercent = vDiscountPercent
		}
	}
	val, res = services.ConvertJSONValueToVariable("BufferPercent", JSONObject)
	if res != nil {
		vBufferPercent, sBufferPercent := strconv.ParseFloat(val, 64)
		if sBufferPercent == nil {
			object.BufferPercent = vBufferPercent
		}
	}
	return
}
