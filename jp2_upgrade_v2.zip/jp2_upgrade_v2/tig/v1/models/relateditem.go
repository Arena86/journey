package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// RelatedItem data
type RelatedItem struct {
	RelatedItemID           int        `gorm:"column:RelatedItemID;primaryKey;autoIncrement;not null" json:"RelatedItemID"`
	CreatedBy               int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate             *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy              int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate            *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted               bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                 bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived              bool       `gorm:"column:IsArchived" json:"IsArchived"`
	ItemID                  int        `gorm:"column:ItemID" json:"ItemID"`
	ChildItemID             int        `gorm:"column:ChildItemID" json:"ChildItemID"`
	Quantity                float64    `gorm:"column:Quantity" json:"Quantity"`
	ItemGroupID             *int       `gorm:"column:ItemGroupID"`
	Code                    string     `gorm:"column:Code;type:varchar(255)"`
	Name                    string     `gorm:"column:Name;type:varchar(255)"`
	Description             string     `gorm:"column:Description;type:varchar(255)"`
	ItemType                int        `gorm:"column:ItemType"`
	FourDPriceDynamicFormID *int       `gorm:"column:4DPriceDynamicFormID"`
	ServiceTimeInMinutes    int        `gorm:"column:ServiceTimeInMinutes" json:"ServiceTimeInMinutes"`
}

// RelatedItemResponse data
type RelatedItemResponse struct {
	RelatedItemID                     int                    `json:"RelatedItemID"`
	ChildItemID                       int                    `json:"ChildItemID"`
	ItemID                            int                    `json:"ItemID"`
	ItemGroupID                       *int                   `json:"ItemGroupID"`
	ItemGroupName                     string                 `json:"ItemGroupName"`
	Code                              string                 `json:"Code"`
	Name                              string                 `json:"Name"`
	Description                       string                 `json:"Description"`
	UnitPrice                         float64                `json:"UnitPrice"`
	TaxID                             int                    `json:"TaxID"`
	TaxType                           string                 `json:"TaxType"`
	TaxName                           string                 `json:"TaxName"`
	TaxRate                           float64                `json:"TaxRate"`
	IsTrackedAsInventory              bool                   `json:"IsTrackedAsInventory"`
	Quantity                          float64                `json:"Quantity"`
	QuantityOnHand                    float64                `json:"QuantityOnHand"`
	ErpKey                            string                 `json:"ErpKey"`
	Cost                              float64                `json:"Cost"`
	ItemType                          int                    `json:"ItemType"`
	ItemTypeName                      string                 `json:"ItemTypeName"`
	AutomaticallyIncludeInNewDocument bool                   `json:"AutomaticallyIncludeInNewDocument"`
	IsHidden                          bool                   `json:"IsHidden"`
	UDFs                              []UDFResponse          `json:"UDFs"`
	UDF                               map[string]interface{} `json:"UDF"`
	RelatedItems                      []RelatedItemResponse  `json:"RelatedItems"`
	FourDPriceDynamicFormID           *int                   `json:"FourDPriceDynamicFormID"`
	ServiceTimeInMinutes              int                    `json:"ServiceTimeInMinutes"`
}

// TableName func
func (RelatedItem) TableName() string {
	return "relateditems"
}

// BeforeCreate func
func (object *RelatedItem) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *RelatedItem) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *RelatedItem) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("RelatedItemID", JSONObject)
	if res != nil {
		object.RelatedItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ChildItemID", JSONObject)
	if res != nil {
		object.ChildItemID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Quantity", JSONObject)
	if res != nil {
		object.Quantity, _ = strconv.ParseFloat(val, 64)
	}
	val, res = services.ConvertJSONValueToVariable("Code", JSONObject)
	if res != nil {
		object.Code = val
	}
	val, res = services.ConvertJSONValueToVariable("Name", JSONObject)
	if res != nil {
		object.Name = val
	}
	val, res = services.ConvertJSONValueToVariable("Description", JSONObject)
	if res != nil {
		object.Description = val
	}

	val, res = services.ConvertJSONValueToVariable("ItemGroupID", JSONObject)
	if res != nil {
		vItemGroupID, sItemGroupID := strconv.Atoi(val)
		if sItemGroupID == nil {
			object.ItemGroupID = &vItemGroupID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ItemType", JSONObject)
	if res != nil {
		object.ItemType, _ = strconv.Atoi(val)
	}

	val, res = services.ConvertJSONValueToVariable("FourDPriceDynamicFormID", JSONObject)
	if res != nil {
		vFourDPriceDynamicFormID, sFourDPriceDynamicFormID := strconv.Atoi(val)
		if sFourDPriceDynamicFormID == nil {
			object.FourDPriceDynamicFormID = &vFourDPriceDynamicFormID
		}
	}
	val, res = services.ConvertJSONValueToVariable("ServiceTimeInMinutes", JSONObject)
	if res != nil {
		object.ServiceTimeInMinutes, _ = strconv.Atoi(val)
	}
	return
}
