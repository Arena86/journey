package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// Authorization data
type Authorization struct {
	AuthorizationID int        `gorm:"column:AuthorizationID;primaryKey;autoIncrement;not null" json:"AuthorizationID"`
	CreatedBy       int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate     *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy      int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate    *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted       bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit         bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived      bool       `gorm:"column:IsArchived" json:"IsArchived"`
	Type            int        `gorm:"column:Type" json:"Type"`
	JobID           int        `gorm:"column:JobID" json:"JobID"`
	LocationID      int        `gorm:"column:LocationID" json:"LocationID"`
	ReasonID        int        `gorm:"column:ReasonID" json:"ReasonID"`
	Comment         string     `gorm:"column:Comment" json:"Comment"`
	Status          int        `gorm:"column:Status" json:"Status"`
	ResponseComment string     `gorm:"column:ResponseComment" json:"ResponseComment"`
}

// AuthorizationResponse data
type AuthorizationResponse struct {
	AuthorizationID int        `json:"AuthorizationID"`
	Type            int        `json:"Type"`
	JobID           int        `json:"JobID"`
	JobNumber       string     `json:"JobNumber"`
	LocationID      int        `json:"LocationID"`
	LocationName    string     `json:"LocationName"`
	ReasonID        int        `json:"ReasonID"`
	ReasonName      string     `json:"ReasonName"`
	Comment         string     `json:"Comment"`
	Status          int        `json:"Status"`
	ResponseComment string     `json:"ResponseComment"`
	CreatedDate     *time.Time `json:"CreatedDate"`
	FullName        string     `json:"FullName"`
}

// AuthorizationResquestCount data
type AuthorizationResquestCount struct {
	Count int `json:"Count"`
}

// TableName func
func (Authorization) TableName() string {
	return "authorizations"
}

// BeforeCreate func
func (object *Authorization) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Authorization) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Authorization) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AuthorizationID", JSONObject)
	if res != nil {
		object.AuthorizationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Type", JSONObject)
	if res != nil {
		object.Type, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ReasonID", JSONObject)
	if res != nil {
		object.ReasonID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("Comment", JSONObject)
	if res != nil {
		object.Comment = val
	}
	val, res = services.ConvertJSONValueToVariable("ResponseComment", JSONObject)
	if res != nil {
		object.ResponseComment = val
	}
	return
}
