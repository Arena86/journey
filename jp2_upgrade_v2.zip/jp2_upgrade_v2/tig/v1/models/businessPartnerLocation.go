package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// BusinessPartnerLocation data
type BusinessPartnerLocation struct {
	BusinessPartnerLocationID int        `gorm:"column:BusinessPartnerLocationID;primaryKey;autoIncrement;not null" json:"BusinessPartnerLocationID"`
	CreatedBy                 int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate               *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate              *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                 bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                   bool       `gorm:"column:IsAudit" json:"IsAudit"`
	BusinessPartnerID         int        `gorm:"column:BusinessPartnerID" json:"BusinessPartnerID"`
	LocationGroupID           int        `gorm:"column:LocationGroupID" json:"LocationGroupID"`
	LocationID                int        `gorm:"column:LocationID" json:"LocationID"`
	IsArchived                bool       `gorm:"column:IsArchived" json:"IsArchived"`
}

// BusinessPartnerLocationResponse data
type BusinessPartnerLocationResponse struct {
	BusinessPartnerLocationID int    `json:"BusinessPartnerLocationID"`
	IsAudit                   bool   `json:"IsAudit"`
	IsDeleted                 bool   `json:"IsDeleted"`
	BusinessPartnerID         int    `json:"BusinessPartnerID"`
	LocationGroupID           int    `json:"LocationGroupID"`
	LocationGroupName         string `json:"LocationGroupName"`
	LocationID                int    `json:"LocationID"`
	LocationName              string `json:"LocationName"`
	IsArchived                bool   `json:"IsArchived"`
}

// TableName func
func (BusinessPartnerLocation) TableName() string {
	return "businesspartnerlocations"
}

// BeforeCreate func
func (object *BusinessPartnerLocation) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *BusinessPartnerLocation) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *BusinessPartnerLocation) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerLocationID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.BusinessPartnerLocationID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("BusinessPartnerID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.BusinessPartnerID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("LocationGroupID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.LocationGroupID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.LocationID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	return
}
