package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// LocationAssignPOST str
type LocationAssignPOST struct {
	BusinessPartnerID int   `json:"BusinessPartnerID"`
	Locations         []int `json:"Locations"`
} // LocationAssignPOST str
type LocationChangeLocationPOST struct {
	LocationID int   `json:"LocationID"`
	Locations  []int `json:"Locations"`
}
type LocationChangeUserLocationPOST struct {
	LocationID     int `json:"LocationID"`
	UserLocationID int `json:"UserLocationID"`
}

// LocationResponse data
type LocationResponse struct {
	LocationID                          int                    `json:"LocationID"`
	IsDeleted                           bool                   `json:"IsDeleted"`
	LocationName                        string                 `json:"LocationName"`
	LocationGroupID                     int                    `json:"LocationGroupID"`
	LocationGroupName                   string                 `json:"LocationGroupName"`
	IsArchived                          bool                   `json:"IsArchived"`
	IsMaster                            bool                   `json:"IsMaster"`
	Note                                string                 `json:"Note"`
	LocationMap                         string                 `json:"LocationMap"`
	StartDayHour                        *time.Time             `json:"StartDayHour"`
	EndDayHour                          *time.Time             `json:"EndDayHour"`
	Timezone                            string                 `json:"Timezone"`
	DefaultView                         string                 `json:"DefaultView"`
	FirstDayOfWeek                      int                    `json:"FirstDayOfWeek"`
	Longitude                           *float64               `json:"Longitude"`
	Latitude                            *float64               `json:"Latitude"`
	UDFs                                []UDFResponse          `json:"UDFs"`
	UDF                                 map[string]interface{} `json:"UDF"`
	Addresses                           []AddressResponse      `json:"Addresses"`
	Phones                              []PhoneResponse        `json:"Phones"`
	SchedulerViews                      []string               `json:"SchedulerViews"`
	UsePicking                          bool                   `json:"UsePicking"`
	BackToDepot                         bool                   `json:"BackToDepot"`
	AdditionalResourceLocationGroupOnly bool                   `json:"AdditionalResourceLocationGroupOnly"`
	ResourceModes                       []int                  `json:"ResourceModes"`
	ResourceTypes                       []int                  `json:"ResourceTypes"`
	TimeZoneID                          int                    `json:"TimeZoneID"`
	//TimeZone                            *TimezoneResponse `json:"TimeZone"`
	Offset                 float64 `json:"Offset"`
	CountryCode            string  `json:"CountryCode"`
	BreakInIntransitFormID int     `json:"BreakInIntransitFormID"`
	BreakInJobFormID       int     `json:"BreakInJobFormID"`
}

// LocationInformResponse data
type LocationInformResponse struct {
	LocationID             int               `json:"LocationID"`
	LocationName           string            `json:"LocationName"`
	Note                   string            `json:"Note"`
	StartDayHour           *time.Time        `json:"StartDayHour"`
	EndDayHour             *time.Time        `json:"EndDayHour"`
	Timezone               string            `json:"Timezone"`
	DefaultView            string            `json:"DefaultView"`
	FirstDayOfWeek         int               `json:"FirstDayOfWeek"`
	Longitude              *float64          `json:"Longitude"`
	Latitude               *float64          `json:"Latitude"`
	Addresses              []AddressResponse `json:"Addresses"`
	Phones                 []PhoneResponse   `json:"Phones"`
	SchedulerViews         []string          `json:"SchedulerViews"`
	UsePicking             bool              `json:"UsePicking"`
	BackToDepot            bool              `json:"BackToDepot"`
	ResourceModes          []int             `json:"ResourceModes"`
	ResourceTypes          []int             `json:"ResourceTypes"`
	BreakInIntransitFormID int               `json:"BreakInIntransitFormID"`
	BreakInJobFormID       int               `json:"BreakInJobFormID"`
	DateFormat             string            `json:"DateFormat"`
	TimeFormat             string            `json:"TimeFormat"`
}

// Location data
type Location struct {
	LocationID                          int        `gorm:"column:LocationID;primaryKey;autoIncrement;not null" json:"LocationID"`
	CreatedBy                           int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                         *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                          int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                        *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                           bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	LocationName                        string     `gorm:"column:LocationName;type:varchar(20)" json:"LocationName"`
	LocationGroupID                     int        `gorm:"column:LocationGroupID" json:"LocationGroupID" validate:"required"`
	IsArchived                          bool       `gorm:"column:IsArchived" json:"IsArchived"`
	IsMaster                            bool       `gorm:"column:IsMaster" json:"IsMaster"`
	Note                                string     `gorm:"column:Note" json:"Note"`
	StartDayHour                        *time.Time `gorm:"column:StartDayHour" json:"StartDayHour"`
	EndDayHour                          *time.Time `gorm:"column:EndDayHour" json:"EndDayHour"`
	Timezone                            string     `gorm:"column:Timezone" json:"Timezone"`
	DefaultView                         string     `gorm:"column:DefaultView" json:"DefaultView"`
	FirstDayOfWeek                      int        `gorm:"column:FirstDayOfWeek" json:"FirstDayOfWeek"`
	Latitude                            *float64   `gorm:"column:Latitude" json:"Latitude"`
	Longitude                           *float64   `gorm:"column:Longitude" json:"Longitude"`
	LocationMap                         string     `gorm:"column:LocationMap" json:"LocationMap"`
	SchedulerViews                      string     `gorm:"column:SchedulerViews" json:"SchedulerViews"`
	UsePicking                          bool       `gorm:"column:UsePicking" json:"UsePicking"`
	BackToDepot                         bool       `gorm:"column:BackToDepot" json:"BackToDepot"`
	AdditionalResourceLocationGroupOnly bool       `gorm:"column:AdditionalResourceLocationGroupOnly" json:"AdditionalResourceLocationGroupOnly"`
	Addresses                           []Address  `gorm:"foreignKey:EntityID;references:LocationID" json:"Addresses"`
	Phones                              []Phone    `gorm:"foreignKey:EntityID;references:LocationID" json:"Phones"`
	ResourceModes                       string     `gorm:"column:ResourceModes" json:"ResourceModes"`
	ResourceTypes                       string     `gorm:"column:ResourceTypes" json:"ResourceTypes"`
	TimeZoneID                          int        `gorm:"column:TimeZoneID" json:"TimeZoneID"`
	BreakInIntransitFormID              int        `gorm:"column:BreakInIntransitFormID" json:"BreakInIntransitFormID"`
	BreakInJobFormID                    int        `gorm:"column:BreakInJobFormID" json:"BreakInJobFormID"`
}

// TableName func
func (Location) TableName() string {
	return "locations"
}

// BeforeCreate func
func (object *Location) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *Location) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *Location) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.LocationID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("LocationName", JSONObject)
	if res != nil {
		object.LocationName = val
	}
	val, res = services.ConvertJSONValueToVariable("Note", JSONObject)
	if res != nil {
		object.Note = val
	}
	val, res = services.ConvertJSONValueToVariable("LocationMap", JSONObject)
	if res != nil {
		object.LocationMap = val
	}
	val, res = services.ConvertJSONValueToVariable("LocationGroupID", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.LocationGroupID = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsMaster", JSONObject)
	if res != nil {
		object.IsMaster, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("Addresses", JSONObject)
	if res != nil {
		var (
			addresses      []Address
			objectsAddress []map[string]interface{}
		)
		addresses = make([]Address, 0)
		addressJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(addressJSON, &objectsAddress)
			if len(objectsAddress) > 0 {
				for _, objAddress := range objectsAddress {
					var (
						address Address
					)
					address.PassBodyJSONToModel(objAddress)
					addresses = append(addresses, address)
				}
			}
		}
		object.Addresses = addresses
	}
	val, res = services.ConvertJSONValueToVariable("Phones", JSONObject)
	if res != nil {
		var (
			phones       []Phone
			objectsPhone []map[string]interface{}
		)
		phones = make([]Phone, 0)
		phonesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(phonesJSON, &objectsPhone)
			if len(objectsPhone) > 0 {
				for _, objPhone := range objectsPhone {
					var (
						phone Phone
					)
					phone.PassBodyJSONToModel(objPhone)
					phones = append(phones, phone)
				}
			}
		}
		object.Phones = phones
	}

	val, res = services.ConvertJSONValueToVariable("Timezone", JSONObject)
	if res != nil {
		object.Timezone = val
	}
	val, res = services.ConvertJSONValueToVariable("DefaultView", JSONObject)
	if res != nil {
		object.DefaultView = val
	}
	val, res = services.ConvertJSONValueToVariable("FirstDayOfWeek", JSONObject)
	if res != nil {
		vParse, sParse := strconv.Atoi(val)
		if sParse == nil {
			object.FirstDayOfWeek = vParse
		}
	}
	val, res = services.ConvertJSONValueToVariable("StartDayHour", JSONObject)
	if res != nil {
		vDate, sDate := services.ConvertStringToDateTime(val)
		if sDate == nil {
			object.StartDayHour = &vDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("EndDayHour", JSONObject)
	if res != nil {
		vDate, sDate := services.ConvertStringToDateTime(val)
		if sDate == nil {
			object.EndDayHour = &vDate
		}
	}

	val, res = services.ConvertJSONValueToVariable("Latitude", JSONObject)
	if res != nil {
		latitude, _ := strconv.ParseFloat(val, 64)
		object.Latitude = &latitude
	}

	val, res = services.ConvertJSONValueToVariable("Longitude", JSONObject)
	if res != nil {
		longitude, _ := strconv.ParseFloat(val, 64)
		object.Longitude = &longitude
	}

	val, res = services.ConvertJSONValueToVariable("SchedulerViews", JSONObject)
	if res != nil {
		var (
			schedulerViews = make([]string, 0)
		)
		schedulerViewsJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(schedulerViewsJSON, &schedulerViews)
			if len(schedulerViews) > 0 {
				object.SchedulerViews = strings.Join(schedulerViews, ",")
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("UsePicking", JSONObject)
	if res != nil {
		object.UsePicking, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("BackToDepot", JSONObject)
	if res != nil {
		object.BackToDepot, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("AdditionalResourceLocationGroupOnly", JSONObject)
	if res != nil {
		object.AdditionalResourceLocationGroupOnly, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("ResourceModes", JSONObject)
	if res != nil {
		var (
			resourceModes = make([]int, 0)
		)
		resourceModesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(resourceModesJSON, &resourceModes)
			if len(resourceModes) > 0 {
				object.ResourceModes = services.IntJoin(resourceModes)
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("ResourceTypes", JSONObject)
	if res != nil {
		var (
			resourceTypes = make([]int, 0)
		)
		resourceTypesJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(resourceTypesJSON, &resourceTypes)
			if len(resourceTypes) > 0 {
				object.ResourceTypes = services.IntJoin(resourceTypes)
			}
		}
	}
	val, res = services.ConvertJSONValueToVariable("TimeZoneID", JSONObject)
	if res != nil {
		object.TimeZoneID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("BreakInIntransitFormID", JSONObject)
	if res != nil {
		object.BreakInIntransitFormID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("BreakInJobFormID", JSONObject)
	if res != nil {
		object.BreakInJobFormID, _ = strconv.Atoi(val)
	}
	return
}
