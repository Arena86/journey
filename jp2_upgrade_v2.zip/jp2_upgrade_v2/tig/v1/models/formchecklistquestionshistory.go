package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// FormCheckListQuestionHistory data
type FormCheckListQuestionHistory struct {
	FormCheckListQuestionHistoryID int        `gorm:"column:FormCheckListQuestionHistoryID;primaryKey;autoIncrement;not null"`
	CreatedBy                      int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate                    *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy                     int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate                   *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted                      bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit                        bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived                     bool       `gorm:"column:IsArchived" json:"IsArchived"`
	FormCheckListHistoryID         int        `gorm:"column:FormCheckListHistoryID" json:"FormCheckListHistoryID"`
	GroupName                      string     `gorm:"column:GroupName" json:"GroupName"`
	Question                       string     `gorm:"column:Question" json:"Question"`
	Status                         bool       `gorm:"column:Status" json:"Status"`
	IsPhotoEnable                  bool       `gorm:"column:IsPhotoEnable" json:"IsPhotoEnable"`
	IsMandatory                    bool       `gorm:"column:IsMandatory" json:"IsMandatory"`
	Photos                         []Photo    `gorm:"foreignKey:RecordID;references:FormCheckListQuestionHistoryID" json:"Photos"`
}

// FormCheckListQuestionHistoryResponse data
type FormCheckListQuestionHistoryResponse struct {
	FormCheckListQuestionHistoryID int             `json:"FormCheckListQuestionHistoryID"`
	FormCheckListHistoryID         int             `json:"FormCheckListHistoryID"`
	GroupName                      string          `json:"GroupName"`
	Question                       string          `json:"Question"`
	Status                         bool            `json:"Status"`
	IsPhotoEnable                  bool            `json:"IsPhotoEnable"`
	IsMandatory                    bool            `json:"IsMandatory"`
	Photos                         []PhotoResponse `json:"Photos"`
}

// TableName func
func (FormCheckListQuestionHistory) TableName() string {
	return "formchecklistquestionshistory"
}

// BeforeCreate func
func (object *FormCheckListQuestionHistory) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *FormCheckListQuestionHistory) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *FormCheckListQuestionHistory) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("FormCheckListQuestionHistoryID", JSONObject)
	if res != nil {
		object.FormCheckListQuestionHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormCheckListHistoryID", JSONObject)
	if res != nil {
		object.FormCheckListHistoryID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("GroupName", JSONObject)
	if res != nil {
		object.GroupName = val
	}
	val, res = services.ConvertJSONValueToVariable("Question", JSONObject)
	if res != nil {
		object.Question = val
	}
	val, res = services.ConvertJSONValueToVariable("Status", JSONObject)
	if res != nil {
		object.Status, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsPhotoEnable", JSONObject)
	if res != nil {
		object.IsPhotoEnable, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsMandatory", JSONObject)
	if res != nil {
		object.IsMandatory, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("Photos", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			photos        = make([]Photo, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail Photo
					)
					detail.PassBodyJSONToModel(obj)
					for _, v := range object.Photos {
						if v.PhotoID > 0 && detail.PhotoID == v.PhotoID {
							detail = v
							detail.PassBodyJSONToModel(obj)
							break
						}
					}
					photos = append(photos, detail)
				}
			}
		}
		object.Photos = photos
	}
	return
}
