package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AdditionalResource data
type AdditionalResource struct {
	AdditionalResourceID int        `gorm:"column:AdditionalResourceID;primaryKey;autoIncrement;not null" json:"AdditionalResourceID"`
	CreatedBy            int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate          *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy           int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate         *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted            bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit              bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived           bool       `gorm:"column:IsArchived" json:"IsArchived"`
	LocationID           int        `gorm:"column:LocationID" validate:"required" json:"LocationID"`
	ResourceID           int        `gorm:"column:ResourceID" validate:"required" json:"ResourceID"`
	FromDate             *time.Time `gorm:"column:FromDate" validate:"required" json:"FromDate"`
	ToDate               *time.Time `gorm:"column:ToDate" validate:"required" json:"ToDate"`
}

// AdditionalResourceResponse data
type AdditionalResourceResponse struct {
	AdditionalResourceID int        `json:"AdditionalResourceID"`
	LocationID           int        `json:"LocationID"`
	ResourceID           int        `json:"ResourceID"`
	FromDate             *time.Time `json:"FromDate"`
	ToDate               *time.Time `json:"ToDate"`
}

// TableName func
func (AdditionalResource) TableName() string {
	return "additionalresources"
}

// BeforeCreate func
func (object *AdditionalResource) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AdditionalResource) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AdditionalResource) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AdditionalResourceID", JSONObject)
	if res != nil {
		object.AdditionalResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("LocationID", JSONObject)
	if res != nil {
		object.LocationID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ResourceID", JSONObject)
	if res != nil {
		object.ResourceID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FromDate", JSONObject)
	if res != nil {
		vFromDate, sFromDate := services.ConvertStringToDateTime(val)
		if sFromDate == nil {
			object.FromDate = &vFromDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("ToDate", JSONObject)
	if res != nil {
		vToDate, sToDate := services.ConvertStringToDateTime(val)
		if sToDate == nil {
			object.ToDate = &vToDate
		}
	}
	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	return
}
