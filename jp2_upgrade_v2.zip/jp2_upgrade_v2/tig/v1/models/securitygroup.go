package models

import (
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// SecurityGroup data
type SecurityGroup struct {
	SecurityGroupID   int        `gorm:"column:SecurityGroupID;primaryKey;autoIncrement;not null" json:"SecurityGroupID"`
	CreatedBy         int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate       *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy        int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate      *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted         bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit           bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived        bool       `gorm:"column:IsArchived" json:"IsArchived"`
	SecurityGroupName string     `gorm:"column:SecurityGroupName" json:"SecurityGroupName" validate:"required"`
	IsAdministrator   bool       `gorm:"column:IsAdministrator" json:"IsAdministrator"`
}

// SecurityGroupResponse data
type SecurityGroupResponse struct {
	SecurityGroupID   int    `json:"SecurityGroupID"`
	SecurityGroupName string `json:"SecurityGroupName"`
	IsAdministrator   bool   `json:"IsAdministrator"`
}

// TableName func
func (SecurityGroup) TableName() string {
	return "securitygroups"
}

// BeforeCreate func
func (object *SecurityGroup) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *SecurityGroup) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *SecurityGroup) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("SecurityGroupID", JSONObject)
	if res != nil {
		vSecurityGroupID, sSecurityGroupID := strconv.Atoi(val)
		if sSecurityGroupID == nil {
			object.SecurityGroupID = vSecurityGroupID
		}
	}
	/* val, res = services.ConvertJSONValueToVariable("IsArchived", JSONObject)
	if res != nil {
		object.IsArchived, _ = strconv.ParseBool(val)
	}

	val, res = services.ConvertJSONValueToVariable("IsDeleted", JSONObject)
	if res != nil {
		object.IsDeleted, _ = strconv.ParseBool(val)
	}
	val, res = services.ConvertJSONValueToVariable("IsAudit", JSONObject)
	if res != nil {
		object.IsAudit, _ = strconv.ParseBool(val)
	} */
	val, res = services.ConvertJSONValueToVariable("SecurityGroupName", JSONObject)
	if res != nil {
		object.SecurityGroupName = val
	}
	/* val, res = services.ConvertJSONValueToVariable("IsAdministrator", JSONObject)
	if res != nil {
		object.IsAdministrator, _ = strconv.ParseBool(val)
	} */
	return
}
