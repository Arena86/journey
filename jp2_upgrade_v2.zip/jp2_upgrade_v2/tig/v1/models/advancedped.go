package models

import (
	"encoding/json"
	"jpapi/tig/v1/services"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// AdvancedPED data
type AdvancedPED struct {
	AdvancedPEDID    int        `gorm:"column:AdvancedPEDID;primaryKey"`
	CreatedBy        int        `gorm:"column:CreatedBy" json:"CreatedBy"`
	CreatedDate      *time.Time `gorm:"column:CreatedDate" json:"CreatedDate"`
	ModifiedBy       int        `gorm:"column:ModifiedBy" json:"ModifiedBy"`
	ModifiedDate     *time.Time `gorm:"column:ModifiedDate" json:"ModifiedDate"`
	IsDeleted        bool       `gorm:"column:IsDeleted" json:"IsDeleted"`
	IsAudit          bool       `gorm:"column:IsAudit" json:"IsAudit"`
	IsArchived       bool       `gorm:"column:IsArchived" json:"IsArchived"`
	JobID            int        `gorm:"column:JobID" json:"JobID"`
	JobTaskID        int        `gorm:"column:JobTaskID" json:"JobTaskID"`
	PEDSerieDetailID int        `gorm:"column:PEDSerieDetailID" json:"PEDSerieDetailID"`
	FormID           string     `gorm:"column:FormID" json:"FormID"`
	ButtonID         int        `gorm:"column:ButtonID" json:"ButtonID"`
	ControlID        string     `gorm:"column:ControlID" json:"ControlID"`
	IsReschedule     bool       `gorm:"column:IsReschedule" json:"IsReschedule"`
	RescheduleDate   *time.Time `gorm:"column:RescheduleDate" json:"RescheduleDate"`
	Images           []Photo    `gorm:"foreignKey:RecordID;references:AdvancedPEDID" json:"Images"`
}

// AdvancedPEDResponse data
type AdvancedPEDResponse struct {
	AdvancedPEDID          int             `json:"AdvancedPEDID"`
	JobID                  int             `json:"JobID"`
	JobTaskID              int             `json:"JobTaskID"`
	PEDSerieDetailID       int             `json:"PEDSerieDetailID"`
	PEDSerieDetailName     string          `json:"PEDSerieDetailName"`
	PEDSerieDetailImageURL string          `json:"PEDSerieDetailImageURL"`
	FormID                 string          `json:"FormID"`
	ButtonID               int             `json:"ButtonID"`
	ControlID              string          `json:"ControlID"`
	Images                 []PhotoResponse `json:"Images"`
}

// TableName func
func (AdvancedPED) TableName() string {
	return "advancedpeds"
}

// BeforeCreate func
func (object *AdvancedPED) BeforeCreate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.CreatedDate = &TimeNow
	object.ModifiedDate = &TimeNow
	return
}

// BeforeUpdate func
func (object *AdvancedPED) BeforeUpdate(db *gorm.DB) (err error) {
	TimeNow := time.Now()
	object.ModifiedDate = &TimeNow
	return
}

// PassBodyJSONToModel func
func (object *AdvancedPED) PassBodyJSONToModel(JSONObject map[string]interface{}) {
	var (
		res interface{}
		val string
	)
	val, res = services.ConvertJSONValueToVariable("AdvancedPEDID", JSONObject)
	if res != nil {
		object.AdvancedPEDID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobID", JSONObject)
	if res != nil {
		object.JobID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("JobTaskID", JSONObject)
	if res != nil {
		object.JobTaskID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("PEDSerieDetailID", JSONObject)
	if res != nil {
		object.PEDSerieDetailID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("FormID", JSONObject)
	if res != nil {
		object.FormID = val
	}
	val, res = services.ConvertJSONValueToVariable("ButtonID", JSONObject)
	if res != nil {
		object.ButtonID, _ = strconv.Atoi(val)
	}
	val, res = services.ConvertJSONValueToVariable("ControlID", JSONObject)
	if res != nil {
		object.ControlID = val
	}
	val, res = services.ConvertJSONValueToVariable("Images", JSONObject)
	if res != nil {
		var (
			objectDetails []map[string]interface{}
			photos        = make([]Photo, 0)
		)
		objectJSON, err := json.Marshal(res)
		if err == nil {
			json.Unmarshal(objectJSON, &objectDetails)
			if len(objectDetails) > 0 {
				for _, obj := range objectDetails {
					var (
						detail Photo
					)
					detail.PassBodyJSONToModel(obj)
					for _, v := range object.Images {
						if v.PhotoID > 0 && detail.PhotoID == v.PhotoID {
							detail = v
							detail.PassBodyJSONToModel(obj)
							break
						}
					}
					photos = append(photos, detail)
				}
			}
		}
		object.Images = photos
	}

	return
}
