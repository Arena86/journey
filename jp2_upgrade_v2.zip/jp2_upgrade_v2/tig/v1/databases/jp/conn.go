package jpdatabase

import (
	"database/sql"
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"jpapi/tig/v1/models"
	"os"
	"strconv"
	"strings"
	"time"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var mapConnectionMySql = make(map[string]*gorm.DB)

// ConnectionMySQL func check connection
func ConnectionMySQL(conn models.ConnectionDatabase, dbName string) *gorm.DB {
	var hasConnection = false
	var ConnectionSeperate = "|"
	mysqlConnectionKey := conn.DBUsername + ConnectionSeperate + conn.DBPassword + ConnectionSeperate + conn.DBServer + ConnectionSeperate + dbName
	for mapKey, mapConn := range mapConnectionMySql {
		if mapKey == mysqlConnectionKey {
			if mapConn != nil {
				mysqlDB, errMysql := mapConn.DB()
				if errMysql == nil {
					errMysql = mysqlDB.Ping()
					if errMysql == nil {
						hasConnection = true
						return mapConn
					}
				}
			}
		}
	}

	if !hasConnection {
		charset := "%s:%s@tcp(%s:%s)/%s?charset=utf8&parseTime=True&loc=Local"
		connString := fmt.Sprintf(charset, conn.DBUsername, conn.DBPassword, conn.DBServer, conn.DBPort, dbName)
		for i := 1; i <= 10; i++ {
			sqlDB, _ := sql.Open("mysql", connString)
			gormDB, err := gorm.Open(mysql.New(mysql.Config{
				Conn: sqlDB,
			}), &gorm.Config{})
			//}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})

			// SetMaxIdleConns sets the maximum number of connections in the idle connection pool.
			sqlDB.SetMaxIdleConns(100)

			// SetMaxOpenConns sets the maximum number of open connections to the database.
			sqlDB.SetMaxOpenConns(1000)

			// SetConnMaxLifetime sets the maximum amount of time a connection may be reused.
			sqlDB.SetConnMaxLifetime(time.Hour)
			if err == nil {
				mapConnectionMySql[mysqlConnectionKey] = gormDB
				return gormDB
			}
			if i == 3 {
				panic(err.Error())
			}
		}
	}
	return nil
}

func ConnectToMySQL(conn models.ConnectionDatabase) *gorm.DB {

	charset := "%s:%s@tcp(%s:%s)/?charset=utf8&parseTime=True&loc=Local"
	connString := fmt.Sprintf(charset, conn.DBUsername, conn.DBPassword, conn.DBServer, conn.DBPort)
	for i := 1; i <= 10; i++ {
		sqlDB, _ := sql.Open("mysql", connString)
		gormDB, err := gorm.Open(mysql.New(mysql.Config{
			Conn: sqlDB,
		}), &gorm.Config{})
		//}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})

		// SetMaxIdleConns sets the maximum number of connections in the idle connection pool.
		sqlDB.SetMaxIdleConns(100)

		// SetMaxOpenConns sets the maximum number of open connections to the database.
		sqlDB.SetMaxOpenConns(1000)

		// SetConnMaxLifetime sets the maximum amount of time a connection may be reused.
		sqlDB.SetConnMaxLifetime(time.Hour)
		if err == nil {
			return gormDB
		}
		if i == 3 {
			panic(err.Error())
		}
	}
	return nil
}

// CheckDBConnection func
func CheckDBConnection(dbName string, dbUser string, dbPassword string, dbserver string, dbport string) *gorm.DB {
	var conn models.ConnectionDatabase
	conn.DBServer = dbserver
	conn.DBPort = dbport
	conn.DBUsername = dbUser
	conn.DBPassword = dbPassword
	db := ConnectionMySQL(conn, dbName)
	if db != nil {
		//errChooseDB := ChooseDatabase(db, dbName)
		//if errChooseDB != nil {
		//	panic(errChooseDB.Error())
		//return nil
		//}
		return db
	}
	return nil
}

// ConnectDB func
func ConnectDB(paramsConnectionDB models.ParamsCreateCompany) *gorm.DB {
	// Need to use root user to create new database
	var conn models.ConnectionDatabase
	conn.DBServer = paramsConnectionDB.Host
	conn.DBPort = paramsConnectionDB.DBPort
	conn.DBUsername = paramsConnectionDB.MasterUser
	conn.DBPassword = paramsConnectionDB.MasterPassword
	return ConnectToMySQL(conn)
}

// CreateDatabase func
func CreateDatabase(db *gorm.DB, databaseName string) error {
	conn := db.Begin()
	errCreateDB := conn.Exec("CREATE DATABASE IF NOT EXISTS " + databaseName).Error
	if errCreateDB != nil {
		conn.Rollback()
		return errCreateDB
	}
	return conn.Commit().Error
}

// ChooseDatabase func
func ChooseDatabase(db *gorm.DB, databaseName string) error {
	conn := db.Begin()
	errChooseDB := conn.Exec("USE " + databaseName).Error
	if errChooseDB != nil {
		conn.Commit()
	} else {
		conn.Rollback()
	}
	return errChooseDB
}

// DropDatabase func
func DropDatabase(db *gorm.DB, databaseName string) {
	conn := db.Begin()
	errDeleteDB := conn.Exec("DROP DATABASE IF EXISTS " + databaseName).Error
	if errDeleteDB != nil {
		conn.Rollback()
	}
	conn.Commit()
}

// CreateUser func
func CreateUser(db *gorm.DB, requestParams models.ParamsCreateCompany) error {
	conn := db.Begin()
	errCreateUser := conn.Exec("CREATE USER IF NOT EXISTS '" + requestParams.DBUsername + "'@'%' IDENTIFIED BY '" + requestParams.DBPassword + "'").Error
	if errCreateUser != nil {
		conn.Rollback()
		return errCreateUser
	}
	conn.Exec("FLUSH PRIVILEGES")
	return conn.Commit().Error
}

// PermissionUser func
func PermissionUser(db *gorm.DB, requestParams models.ParamsCreateCompany) error {
	conn := db.Begin()
	errPermission := conn.Exec("GRANT ALL PRIVILEGES ON " + requestParams.DatabaseID + ".* TO '" + requestParams.DBUsername + "'@'%'").Error
	if errPermission != nil {
		conn.Rollback()
		return errPermission
	}
	return conn.Commit().Error
}

// DropUserOfDatabase func
func DropUserOfDatabase(db *gorm.DB, dbUsername string) {
	db.Exec("DROP USER IF EXISTS '" + dbUsername + "'@'localhost'")
}

// CreateTableNewDB func
func CreateTableNewDB(db *gorm.DB, companyName string, companyID string) error {
	var (
		err    error
		tables XMLImportTable
	)
	conn := db.Begin()
	pathFile := "public/generation/databases_table.xml"
	xmlFile, err := os.Open(pathFile)
	if err == nil {
		byteValue, errRead := ioutil.ReadAll(xmlFile)
		if errRead == nil {
			xml.Unmarshal(byteValue, &tables)
			for _, v := range tables.Structure.Database.Tables {
				sqlTables := strings.TrimSpace(v)
				if sqlTables != "" {
					err := conn.Exec(sqlTables).Error
					if err != nil {
						break
					}
				}
			}
		} else {
			err = errRead
		}
	}
	if xmlFile != nil {
		defer xmlFile.Close()
	}
	if err != nil {
		conn.Rollback()
		return err
	}
	conn.Commit()
	return conn.Error
}

// GenerateDataWithAccountKey func
func GenerateDataWithAccountKey(db *gorm.DB, accountKey int, arrTabelName ...string) error {
	var (
		err   error
		datum XMLImportData
	)
	pathFile := "public/generation/databases_data.xml"
	xmlFile, err := os.Open(pathFile)
	if err == nil {
		byteValue, errRead := ioutil.ReadAll(xmlFile)
		if errRead == nil {
			xml.Unmarshal(byteValue, &datum)
			for _, v := range datum.Structure.Database.Datum {
				tableName := ""
				arrSplitValues := strings.Split(strings.TrimSpace(v), "VALUES")
				if len(arrSplitValues) > 0 {
					insertString := strings.TrimSpace(arrSplitValues[0])
					arrSplitBrackets := strings.Split(strings.TrimSpace(insertString), "(")
					if len(arrSplitBrackets) > 0 {
						insertString = arrSplitBrackets[0]
						arrSplitSpace := strings.Split(strings.TrimSpace(insertString), " ")
						if len(arrSplitSpace) > 0 {
							tableName = strings.TrimSpace(arrSplitSpace[len(arrSplitSpace)-1])
						}
					}
				}
				if tableName != "" {
					tableName = strings.ReplaceAll(tableName, "`", "")
				}
				if tableName != "" {
					tableName = strings.ToLower(tableName)
				}
				runScript := false
				if len(arrTabelName) > 0 {
					if tableName != "" {
						if InArrayString(tableName, arrTabelName) {
							runScript = true
						}
					}
				} else {
					runScript = true
				}
				if tableName != "" && runScript {
					var count int
					sql := ``
					if HasAccountKeyField(v) {
						sql = `SELECT COUNT(*) FROM ` + tableName + ` WHERE AccountKey = ?`
						sqlDB, errSqlDB := db.DB()
						if errSqlDB == nil {
							err = sqlDB.QueryRow(sql, accountKey).Scan(&count)
						} else {
							err = errSqlDB
						}
					} else {
						sql = `SELECT COUNT(*) FROM ` + tableName + ``
						sqlDB, errSqlDB := db.DB()
						if errSqlDB == nil {
							err = sqlDB.QueryRow(sql).Scan(&count)
						} else {
							err = errSqlDB
						}
					}
					if err == nil && count <= 0 {
						sqlData := v
						sqlData = strings.ReplaceAll(sqlData, "DefaultAccountKeyToReplace", strconv.Itoa(accountKey))
						err = db.Exec(sqlData).Error
					}
				}
			}
		}
	}
	if xmlFile != nil {
		defer xmlFile.Close()
	}
	return err
}

// Contains func
func Contains(a []string, x string) bool {
	for _, n := range a {
		if x == n {
			return true
		}
	}
	return false
}

// HasAccountKeyField func
func HasAccountKeyField(str string) bool {
	return strings.Contains(str, "`AccountKey`")
}

// InArrayString func
func InArrayString(i string, arr []string) bool {
	for _, v := range arr {
		if v == i {
			return true
		}
	}
	return false
}

// XMLImportTable str
type XMLImportTable struct {
	XMLName   xml.Name      `xml:"jp_database"`
	Structure DatabaseTable `xml:"structure_schemas"`
}

// DatabaseTable str
type DatabaseTable struct {
	Database Table `xml:"database"`
}

// Table str
type Table struct {
	Tables []string `xml:"table"`
}

// XMLImportData struct
type XMLImportData struct {
	XMLName   xml.Name     `xml:"jp_database"`
	Structure DatabaseData `xml:"structure_schemas"`
}

// DatabaseData str
type DatabaseData struct {
	Database Data `xml:"database"`
}

// Data str
type Data struct {
	Datum []string `xml:"data"`
}
