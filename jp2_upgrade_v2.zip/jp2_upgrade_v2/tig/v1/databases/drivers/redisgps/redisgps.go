package libsredisgps

import (
	"context"
	libs "jpapi/tig/v1/helpers"

	"github.com/go-redis/redis/v8"
)

// RedisClient var
var RedisClient *redis.Client

// Ctx var
var Ctx = context.Background()

// Connect func
func init() {
	RedisClient = redis.NewClient(&redis.Options{
		Addr:     libs.GetRedisAddr(),
		Password: libs.GetRedisPassword(),        // no password set
		DB:       libs.GetRedisDB("REDIS_DBGPS"), // use default DB
	})
}
