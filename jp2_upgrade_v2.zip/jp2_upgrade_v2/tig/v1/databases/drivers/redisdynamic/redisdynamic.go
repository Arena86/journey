package redisdynamic

import (
	"context"

	"github.com/go-redis/redis/v8"
)

// Ctx var
var Ctx = context.Background()

// GetRedisConnectionDynamic func
func GetRedisConnectionDynamic(server string, port string, pass string, db int) *redis.Client {
	addr := server + ":" + port
	return redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: pass, // no password set
		DB:       db,   // use default DB
	})
}
