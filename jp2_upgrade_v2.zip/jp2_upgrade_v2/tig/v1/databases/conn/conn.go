package conn

/* import (
	mysql "jpapi/tig/v1/databases/drivers"

	"gorm.io/gorm"
)

// Connect func
func Connect() *gorm.DB {
	return mysql.Connect()
} */
